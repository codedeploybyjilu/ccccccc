import React, { Component } from 'react'
import { Modal } from 'react-bootstrap'
import banner from '../images/full-banner.png'
import imgplaceholder from '../images/img-placeholder.svg'
import toastr from "toastr";
import { buttonEnglish, buttonArabic, APIBaseUrl, API_Path, LIVE_FILE_URL, productEnglish, productArabic } from '../const';
import { PostApi } from '../helper/APIService';
import loader from '../images/loader.gif'
import LanguageContext from "../contexts/languageContext";
import { ImageCompress } from '../Components/ImageCompress';

export default class Position5 extends Component {
    static contextType = LanguageContext;

    state = {
        banner1English: '',
        banner1Arabic: '',
        banner2English: '',
        banner2Arabic: '',
        banner3English: '',
        banner3Arabic: '',
        bannerUrl1: '',
        bannerUrl2: '',
        bannerUrl3: '',
        isLoading: false,
        maincategoryData: '',
        mainCategory1: '',
        mainCategory2: '',
        mainCategory3: '',
        categoryData: '',
        categoryData2: '',
        categoryData3: '',
        category: '',
        category2: '',
        category3: '',
        subCategoryData: '',
        subCategoryData2: '',
        subCategoryData3: '',
        subCategory: '',
        subCategory2: '',
        subCategory3: '',
        errorCatogory: '',
        errorSubCatogory: '',
        errorMainCatogory: '',
        isSaleItem1: false,
        SearchParams1: null,
        isSaleItem2: false,
        SearchParams2: null,
        isSaleItem3: false,
        SearchParams3: null,
    }

    componentDidMount() {
        // this.setState({ maincategoryData: this.props.masterCatagoryData })
        this.getMainCategoryData()
        this.getCategoryData(this.state.mainCategory1);
        this.getCategoryData(this.props.selectedCatagory.id)
    }
    getMainCategoryData = () => {

        let data = {};

        let path = API_Path.getMainCategory;
        const getMainCategoryPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        getMainCategoryPromise.then((res) => {
            if (res) {
                // console.log('res is :: ', res.data.data);
                this.setState({ maincategoryData: res.data.data });
            }
        });
    };
    handleChange1 = (e) => {
        if (e.target.name == "mainCategory1" || e.target.name == "mainCategory2" || e.target.name == "mainCategory3") {
            this.getCategoryData(e.target.value, e.target.name);
            this.setState({ mainCategory: e.target.value });
        }
        if (e.target.name == "category" || e.target.name == "category2" || e.target.name == "category3") {
            this.getSubCategoryData(e.target.value, e.target.name);
            this.setState({ category: e.target.value });
        }
        if (e.target.name == "subCategory") {
            this.setState({ subCategory: e.target.value }, () => {
                // this.getSizeGuideLine();
            });
        }
    };
    getCategoryData = (val, name) => {
        if (val) {

            let data = { main_category_id: val };
            let path = API_Path.getCategoryRelative;
            const getCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    if (name == 'mainCategory1') {
                        this.setState({ categoryData: res.data.data });
                    } else if (name == 'mainCategory2') {
                        this.setState({ categoryData2: res.data.data });
                    } else {
                        this.setState({ categoryData3: res.data.data });
                    }
                }
            });
        } else {

            let data = {};

            let path = API_Path.getCategory;
            const getCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    if (!name) {
                        this.setState({ categoryData: res.data.data, categoryData2: res.data.data, categoryData3: res.data.data });
                    } else {

                        if (name == 'mainCategory1') {
                            this.setState({ categoryData: res.data.data });
                        } else if (name == 'mainCategory2') {
                            this.setState({ categoryData2: res.data.data });
                        } else {
                            this.setState({ categoryData3: res.data.data });
                        }
                    }
                }
            });
        }
    };
    getSubCategoryData = (val, name) => {
        // console.log(val);
        if (val) {

            let data = { category_id: val };

            let path = API_Path.getSubCategoryRelative;
            const getSubCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getSubCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    // this.setState({ subCategoryData: res.data.data });
                    if (name == 'category') {
                        this.setState({ subCategoryData: res.data.data });
                    } else if (name == 'category2') {
                        this.setState({ subCategoryData2: res.data.data });
                    } else {
                        this.setState({ subCategoryData3: res.data.data });
                    }
                }
            });
        } else {

            let data = {};
            let path = API_Path.getSubCategory;
            const getSubCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getSubCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ subCategoryData: res.data.data });
                }
            });
        }
    };

    handleImageChange = (e, name) => {
        if (e.target.files.length > 0) {
            let fileName = e.target.name
            let file = e.target.files
            const image = new Image();
            let fr = new FileReader();

            fr.onload = function () {
                if (fr !== null && typeof fr.result == "string") {
                    image.src = fr.result;
                }
            };
            fr.readAsDataURL(e.target.files[0]);
            if (name === 'square') {
                image.onload = async () => {
                    const width = image.width;
                    console.log('width is :: ', width, image.height);
                    // if (image.width > 335 && image.width < 345 && image.height > 335 && image.height < 345) {
                    this.setState({ isLoading: true }, () => {
                        this.addImageToStorage(file, fileName)
                    })
                    // } else {
                    //     toastr.error('You can upload image of max size of 5mb. Image will be cropped to 340*340px.')
                    // }

                };
            } else if (name === 'rectangle') {
                image.onload = async () => {
                    const width = image.width;
                    console.log('width is :: ', width, image.height);
                    // if (image.width > 695 && image.width < 705 && image.height > 335 && image.height < 345) {
                    this.setState({ isLoading: true }, () => {
                        this.addImageToStorage(file, fileName)
                    })
                    // } else {
                    //     toastr.error('You can upload image of max size of 5mb. Image will be cropped to 700*340.')
                    // }

                };
            }
        }
    }

    handleChange = (e) => {
        if (this.state.errorMainCatogory) {
            this.setState({ errorMainCatogory: false })
        }
        if (this.state.errorCatogory) {
            this.setState({ errorCatogory: false })
        }
        if (this.state.errorSubCatogory) {
            this.setState({ errorSubCatogory: false })
        }
        console.log(e.target.name, "e.target.name");
        this.setState({ [e.target.name]: e.target.value }, () => {
            console.log(this.state.mainCategory1, "==========[]");
            if (this.state.category == '') {
                this.setState({ subCategory: '' })
            }
            if (this.state.category2 == '') {
                this.setState({ subCategory2: '' })
            }
            if (this.state.category3 == '') {
                this.setState({ subCategory3: '' })
            }
        })
    }

    makeid = (length) => {
        var result = '';
        var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var charactersLength = characters.length;
        for (var i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() *
                charactersLength));
        }
        return result;
    }

    addImageToStorage = async (files, name) => {


        console.log('files is :: ', files);

        let imgArr = await ImageCompress(files)
        var formData = new FormData;
        for (var i = 0; i < imgArr.length; i++) {
            formData.append('file', imgArr[i]);
        }
        console.log('form data ;: ', formData);
        let path = API_Path.addFileInS3
        const addFilePromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, formData));
        });

        addFilePromise.then((res) => {
            if (res) {
                console.log('res is :: ', res);
                this.setState({ [name]: res.data.data[0], isLoading: false }, () => {
                    if (this.state.banner1English !== '') {
                        document.getElementById('banner1EnglishPreview5').classList.add('imageUpload')
                    } else {
                        document.getElementById('banner1EnglishPreview5').classList.remove('imageUpload')
                    }
                    if (this.state.banner1Arabic !== '') {
                        document.getElementById('banner1ArabicPreview5').classList.add('imageUpload')
                    } else {
                        document.getElementById('banner1ArabicPreview5').classList.remove('imageUpload')
                    }
                    if (this.state.banner2English !== '') {
                        document.getElementById('banner2EnglishPreview5').classList.add('imageUpload')
                    } else {
                        document.getElementById('banner2EnglishPreview5').classList.remove('imageUpload')
                    }
                    if (this.state.banner2Arabic !== '') {
                        document.getElementById('banner2ArabicPreview5').classList.add('imageUpload')
                    } else {
                        document.getElementById('banner2ArabicPreview5').classList.remove('imageUpload')
                    }
                    if (this.state.banner3English !== '') {
                        document.getElementById('banner3EnglishPreview5').classList.add('imageUpload')
                    } else {
                        document.getElementById('banner3EnglishPreview5').classList.remove('imageUpload')
                    }
                    if (this.state.banner3Arabic !== '') {
                        document.getElementById('banner3ArabicPreview5').classList.add('imageUpload')
                    } else {
                        document.getElementById('banner3ArabicPreview5').classList.remove('imageUpload')
                    }
                })
            }
        });
    }

    handleSubmit = () => {
        let search1 = this.state.SearchParams1
        let search2 = this.state.SearchParams2
        let search3 = this.state.SearchParams3
        let prductId1
        let prductId2
        let prductId3
        let allcategories1
        let allcategories2
        let allcategories3
        if (this.state.bannerUrl1.includes('search=')) {
            // search1 = 'SALE'
        } else if (!this.state.bannerUrl1.includes('allcategories=')) {
            prductId1 = this.state.bannerUrl1.substr(this.state.bannerUrl1.lastIndexOf("-") + 1);
        } else {
            let params = this.state.bannerUrl1.split('?')[1]
            const url = new URLSearchParams(params);
            allcategories1 = url.get('allcategories').split('--');
        }
        if (this.state.bannerUrl2.includes('search=')) {
            // search2 = 'SALE'
        } else if (!this.state.bannerUrl2.includes('allcategories=')) {
            prductId2 = this.state.bannerUrl2.substr(this.state.bannerUrl2.lastIndexOf("-") + 1);
        } else {
            let params = this.state.bannerUrl2.split('?')[1]
            const url = new URLSearchParams(params);
            allcategories2 = url.get('allcategories').split('--');
        }
        if (this.state.bannerUrl3.includes('search=')) {
            // search3 = 'SALE'
        } else if (!this.state.bannerUrl3.includes('allcategories=')) {
            prductId3 = this.state.bannerUrl3.substr(this.state.bannerUrl3.lastIndexOf("-") + 1);
        } else {
            let params = this.state.bannerUrl3.split('?')[1]
            const url = new URLSearchParams(params);
            allcategories3 = url.get('allcategories').split('--');
        }
        let filters = {}
        let filters2 = {}
        let filters3 = {}
        let banner_url1 = this.state.bannerUrl1.split('?')[1]
        const query1 = new URLSearchParams(banner_url1);
        let banner_url2 = this.state.bannerUrl2.split('?')[1]
        const query2 = new URLSearchParams(banner_url2);
        let banner_url3 = this.state.bannerUrl3.split('?')[1]
        const query3 = new URLSearchParams(banner_url3);
        // ==============================make sure that below-params must same as mention in website (next.js) in filter page=========================================
        filters.size = Array.from(query1.getAll('SIZE'), (value) => parseInt(value.split('--')[1]))
        filters.colors = Array.from(query1.getAll('COLORS'), (value) => parseInt(value.split('--')[1]))
        filters.prices = Array.from(query1.getAll('PRICES'), (value) => parseInt(value.split('--')[1]))
        filters.discounts = Array.from(query1.getAll('DISCOUNTS'), (value) => parseInt(value.split('--')[1]))
        filters.occassion = Array.from(query1.getAll('OCCASSION'), (value) => parseInt(value.split('--')[1]))
        filters.neckline = Array.from(query1.getAll('NECKLINE'), (value) => parseInt(value.split('--')[1]))
        filters.sleeve = Array.from(query1.getAll('SLEEVE'), (value) => parseInt(value.split('--')[1]))
        filters.design = Array.from(query1.getAll('DESIGN'), (value) => parseInt(value.split('--')[1]))
        filters.waist = Array.from(query1.getAll('WAIST'), (value) => parseInt(value.split('--')[1]))
        filters.length = Array.from(query1.getAll('LENGTH'), (value) => parseInt(value.split('--')[1]))
        filters.fit = Array.from(query1.getAll('FIT'), (value) => parseInt(value.split('--')[1]))
        // ==============================make sure that below-params must same as mention in website (next.js) in filter page=========================================
        filters2.size = Array.from(query2.getAll('SIZE'), (value) => parseInt(value.split('--')[1]))
        filters2.colors = Array.from(query2.getAll('COLORS'), (value) => parseInt(value.split('--')[1]))
        filters2.prices = Array.from(query2.getAll('PRICES'), (value) => parseInt(value.split('--')[1]))
        filters2.discounts = Array.from(query2.getAll('DISCOUNTS'), (value) => parseInt(value.split('--')[1]))
        filters2.occassion = Array.from(query2.getAll('OCCASSION'), (value) => parseInt(value.split('--')[1]))
        filters2.neckline = Array.from(query2.getAll('NECKLINE'), (value) => parseInt(value.split('--')[1]))
        filters2.sleeve = Array.from(query2.getAll('SLEEVE'), (value) => parseInt(value.split('--')[1]))
        filters2.design = Array.from(query2.getAll('DESIGN'), (value) => parseInt(value.split('--')[1]))
        filters2.waist = Array.from(query2.getAll('WAIST'), (value) => parseInt(value.split('--')[1]))
        filters2.length = Array.from(query2.getAll('LENGTH'), (value) => parseInt(value.split('--')[1]))
        filters2.fit = Array.from(query2.getAll('FIT'), (value) => parseInt(value.split('--')[1]))
        // ==============================make sure that below-params must same as mention in website (next.js) in filter page=========================================
        filters3.size = Array.from(query3.getAll('SIZE'), (value) => parseInt(value.split('--')[1]))
        filters3.colors = Array.from(query3.getAll('COLORS'), (value) => parseInt(value.split('--')[1]))
        filters3.prices = Array.from(query3.getAll('PRICES'), (value) => parseInt(value.split('--')[1]))
        filters3.discounts = Array.from(query3.getAll('DISCOUNTS'), (value) => parseInt(value.split('--')[1]))
        filters3.occassion = Array.from(query3.getAll('OCCASSION'), (value) => parseInt(value.split('--')[1]))
        filters3.neckline = Array.from(query3.getAll('NECKLINE'), (value) => parseInt(value.split('--')[1]))
        filters3.sleeve = Array.from(query3.getAll('SLEEVE'), (value) => parseInt(value.split('--')[1]))
        filters3.design = Array.from(query3.getAll('DESIGN'), (value) => parseInt(value.split('--')[1]))
        filters3.waist = Array.from(query3.getAll('WAIST'), (value) => parseInt(value.split('--')[1]))
        filters3.length = Array.from(query3.getAll('LENGTH'), (value) => parseInt(value.split('--')[1]))
        filters3.fit = Array.from(query3.getAll('FIT'), (value) => parseInt(value.split('--')[1]))
        if (this.state.banner1English === '') {
            toastr.error('Please select English Banner for 1st Banner')
        } else if (this.state.banner1Arabic === '') {
            toastr.error('Please select Arabic Banner for 1st Banner')
        } else if (this.state.banner2English === '') {
            toastr.error('Please select English Banner for 2nd Banner')
        } else if (this.state.banner2Arabic === '') {
            toastr.error('Please select Arabic Banner for 2nd Banner')
        } else if (this.state.banner3English === '') {
            toastr.error('Please select English Banner for 2nd Banner')
        } else if (this.state.banner3Arabic === '') {
            toastr.error('Please select Arabic Banner for 2nd Banner')
        } else if (this.state.bannerUrl1 === '') {
            toastr.error('Please add link for redirection of banner 1')
        } else if (this.state.bannerUrl2 === '') {
            toastr.error('Please add link for redirection of banner 2')
        } else if (this.state.bannerUrl3 === '') {
            toastr.error('Please add link for redirection of banner 3')
        } else if (!allcategories1) {
            toastr.error('Please enter valid url for banner 1 , you can refer from the websit')
        } else if (!allcategories2) {
            toastr.error('Please enter valid url for banner 2 , you can refer from the websit')
        } else if (!allcategories3) {
            toastr.error('Please enter valid url for banner 3 , you can refer from the websit')
        }
        else {
            let data = {
                banner_1_english: this.state.banner1English,
                banner_1_arabic: this.state.banner1Arabic,
                banner_2_english: this.state.banner2English,
                banner_2_arabic: this.state.banner2Arabic,
                banner_3_english: this.state.banner3English,
                banner_3_arabic: this.state.banner3Arabic,
                banner_url_1: this.state.bannerUrl1,
                banner_url_2: this.state.bannerUrl2,
                banner_url_3: this.state.bannerUrl3,
                bannerId: this.makeid(10),
                status: '1',
                category: this.state.category,
                category_2: this.state.category2,
                category_3: this.state.category3,
                sub_category_name: allcategories1[2],
                sub_category_name_2: allcategories2[2],
                sub_category_name_3: allcategories3[2],
                sub_category: this.state.subCategory,
                sub_category_2: this.state.subCategory2,
                sub_category_3: this.state.subCategory3,
                main_category: this.state.mainCategory1,
                main_category: this.state.mainCategory2,
                main_category: this.state.mainCategory3,
                search: search1,
                search_2: search2,
                search_3: search3,
                product_id: prductId1,
                product_id_2: prductId2,
                product_id_3: prductId3,
                table_name: "five",
                filter: JSON.stringify(filters),
                filter_type: query1.get('sort-type'),
                filter2: JSON.stringify(filters2),
                filter_type2: query2.get('sort-type'),
                filter3: JSON.stringify(filters3),
                filter_type3: query3.get('sort-type'),
            }
            this.props.submitPosition5(data)
            this.setState({
                banner1English: '',
                banner1Arabic: '',
                banner2English: '',
                banner2Arabic: '',
                banner3English: '',
                banner3Arabic: '',
                bannerUrl1: '',
                bannerUrl2: '',
                bannerUrl3: '',
            })

        }
    }

    isSaleItem1 = (e) => {
        if (e.target.checked) {
            this.setState({ category: '', subCategory: '', SearchParams1: 'SALE' })
        } else {
            this.setState({ SearchParams1: null })
        }
        this.setState({ isSaleItem1: e.target.checked })
    }
    isSaleItem2 = (e) => {
        if (e.target.checked) {
            this.setState({ category2: '', subCategory2: '', SearchParams2: 'SALE' })
        } else {
            this.setState({ SearchParams2: null })
        }
        this.setState({ isSaleItem2: e.target.checked })
    }
    isSaleItem3 = (e) => {
        if (e.target.checked) {
            this.setState({ category3: '', subCategory3: '', SearchParams3: 'SALE' })
        } else {
            this.setState({ SearchParams3: null })
        }
        this.setState({ isSaleItem3: e.target.checked })
    }

    render() {
        let ButtonLanguage = this.context.language === "english" ? buttonEnglish : buttonArabic;
        let productLanguage = this.context.language === "english" ? productEnglish : productArabic;;
        return (<React.Fragment>
            {this.state.isLoading && (
                <div className="loader-main">
                    <div className="loader-inr">
                        <img src={loader} alt="" />
                    </div>
                </div>
            )}
            <Modal
                dialogClassName="modal-dialog-centered"
                className="edit-user-modal cust-modal"
                size="xl"
                ref={(el) => {
                    this.dialog = el
                }}
                show={this.props.show}
                onHide={this.props.closePosition5}
            >
                <Modal.Header>
                    <Modal.Title>
                        <h1 className="modal-title">{ButtonLanguage.add}</h1>
                    </Modal.Title>
                    <button
                        type="button"
                        onClick={this.props.closePosition5}
                        className="close btn-close"
                    ></button>
                </Modal.Header>
                <Modal.Body>
                    <div className="row">
                        <div className="col-md-12 avtar-txt m-0">
                            <p>Banner-1</p>
                        </div>
                        <div className="col-md-6">
                            <div className="img-upload py-3">
                                <div className="avatar-preview">
                                    <div id="imagePreview">
                                        <div className="banner-main-box-ad">
                                            <div>
                                                <img id='banner1EnglishPreview5' src={this.state.banner1English === '' ? imgplaceholder : this.state.banner1English} alt="" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="avtar-txt">
                                    <p>{ButtonLanguage.UploadyourbannerEnglishdesktop}</p>
                                    <span>{ButtonLanguage.uploadimagemaxsize} 340*340px.</span>
                                    <div className="avatar-edit">
                                        <input className="d-none" type="file" id="imageUpload1" name='banner1English' onChange={(e) => this.handleImageChange(e, 'square')} accept=".png, .jpg, .jpeg" />
                                        <label className="btn red-btn mt-3" htmlFor="imageUpload1">
                                            <i className="bi bi-upload me-2" />
                                            {ButtonLanguage.Uploadimage}
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <div className="img-upload py-3">
                                <div className="avatar-preview">
                                    <div id="imagePreview">
                                        <div className="banner-main-box-ad">
                                            <div>
                                                <img id='banner1ArabicPreview5' src={this.state.banner1Arabic === '' ? imgplaceholder : this.state.banner1Arabic} alt="" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="avtar-txt">
                                    <p>{ButtonLanguage.UploadyourbannerArabicdesktop}</p>
                                    <span>{ButtonLanguage.uploadimagemaxsize} 340*340px.</span>
                                    <div className="avatar-edit">
                                        <input className="d-none" type="file" id="imageUpload2" name='banner1Arabic' onChange={(e) => this.handleImageChange(e, 'square')} accept=".png, .jpg, .jpeg" />
                                        <label className="btn red-btn mt-3" htmlFor="imageUpload2">
                                            <i className="bi bi-upload me-2" />
                                            {ButtonLanguage.Uploadimage}
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/*<div class="col-xl-12 mb-3 ">
                            <div className='edit-banner-cust form-group d-flex align-items-center'>
                                <span id='ActiveUrl1' className='active'>{ButtonLanguage.ProductListing}</span>
                                <label class="switch mx-2 mb-0">
                                    <input type="checkbox" checked={this.state.SelectUrlType} onChange={this.handleCheckbox} />
                                    <div class="slider round"></div>
                                </label>
                                <span id='ActiveUrl2'>{ButtonLanguage.ProductPage}</span>
                            </div>
                        </div>*/}


                        <div className="col-md-12 form-group">
                            <label>{!this.state.SelectUrlType ? ButtonLanguage.ProductPage + " URL" : ButtonLanguage.ProductListing + " URL"}</label>
                            <input type="url" name='bannerUrl1' onChange={this.handleChange} className="form-control input-custom-class" />
                        </div>
                        <div className="col-md-12 cust-checkbox-new mb-3">
                            <label className="cust-chk-bx">
                                <input type="checkbox" onChange={this.isSaleItem1} />
                                <span className="cust-chkmark" />
                                For Sale Item
                            </label>
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.mainCategory}</label>
                            <select name="mainCategory1" value={this.state.mainCategory1} onChange={this.handleChange} onChangeCapture={this.handleChange1} className="form-select input-custom-class" >
                                <option>{this.props.selectedCatagory.english} | {this.props.selectedCatagory.arabic} </option>
                                {this.state.maincategoryData &&
                                    this.state.maincategoryData.length > 0 &&
                                    this.state.maincategoryData.map((item, i) => {
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                            {this.state.errorMainCatogory && <div className="input-feedback text-danger">{'Required'}</div>}
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.category}</label>
                            <select name="category" value={this.state.category} onChange={this.handleChange} onChangeCapture={this.handleChange1} className="form-select input-custom-class" disabled={this.state.isSaleItem1}>
                                <option value={''}>{productLanguage.SelectCategory} </option>
                                {this.state.categoryData &&
                                    this.state.categoryData.length > 0 &&
                                    this.state.categoryData.map((item, i) => {
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                            {this.state.errorCatogory && <div className="input-feedback text-danger">{'Required'}</div>}
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.subCategory}</label>
                            <select name="subCategory" value={this.state.subCategory} onChange={this.handleChange} onChangeCapture={this.handleChange1} className="form-select input-custom-class" disabled={this.state.isSaleItem1}>
                                <option>{productLanguage.SelectSubCategory}</option>
                                {this.state.subCategoryData &&
                                    this.state.subCategoryData.length > 0 &&
                                    this.state.subCategoryData.map((item, i) => {
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                            {this.state.errorSubCatogory && <div className="input-feedback text-danger">{'Required'}</div>}
                        </div>
                        <div className="col-md-12 avtar-txt m-0 border-top pt-2">
                            <p>Banner-2</p>
                        </div>
                        <div className="col-md-6">
                            <div className="img-upload py-3">
                                <div className="avatar-preview">
                                    <div id="imagePreview">
                                        <div className="banner-main-box-ad">
                                            <div>
                                                <img id='banner2EnglishPreview5' src={this.state.banner2English === '' ? imgplaceholder : this.state.banner2English} alt="" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="avtar-txt">
                                    <p>{ButtonLanguage.UploadyourbannerEnglishdesktop}</p>
                                    <span>{ButtonLanguage.uploadimagemaxsize} 700*340px.</span>
                                    <div className="avatar-edit">
                                        <input className="d-none" type="file" id="imageUpload3" name='banner2English' onChange={(e) => this.handleImageChange(e, 'rectangle')} accept=".png, .jpg, .jpeg" />
                                        <label className="btn red-btn mt-3" htmlFor="imageUpload3">
                                            <i className="bi bi-upload me-2" />
                                            {ButtonLanguage.Uploadimage}
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <div className="img-upload py-3">
                                <div className="avatar-preview">
                                    <div id="imagePreview">
                                        <div className="banner-main-box-ad">
                                            <div>
                                                <img id='banner2ArabicPreview5' src={this.state.banner2Arabic === '' ? imgplaceholder : this.state.banner2Arabic} alt="" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="avtar-txt">
                                    <p>{ButtonLanguage.UploadyourbannerArabicdesktop}</p>
                                    <span>{ButtonLanguage.uploadimagemaxsize} 700*340px.</span>
                                    <div className="avatar-edit">
                                        <input className="d-none" type="file" id="imageUpload4" name='banner2Arabic' onChange={(e) => this.handleImageChange(e, 'rectangle')} accept=".png, .jpg, .jpeg" />
                                        <label className="btn red-btn mt-3" htmlFor="imageUpload4">
                                            <i className="bi bi-upload me-2" />
                                            {ButtonLanguage.Uploadimage}
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/*<div class="col-xl-12 mb-3 ">
                            <div className='edit-banner-cust form-group d-flex align-items-center'>
                                <span id='ActiveUrl1' className='active'>{ButtonLanguage.ProductListing}</span>
                                <label class="switch mx-2 mb-0">
                                    <input type="checkbox" checked={this.state.SelectUrlType} onChange={this.handleCheckbox} />
                                    <div class="slider round"></div>
                                </label>
                                <span id='ActiveUrl2'>{ButtonLanguage.ProductPage}</span>
                            </div>
                        </div>*/}


                        <div className="col-md-12 form-group">
                            <label>{!this.state.SelectUrlType ? "Product Listing URL" : "Product Page URL"}</label>
                            <input type="url" name='bannerUrl2' onChange={this.handleChange} className="form-control input-custom-class" />
                        </div>
                        <div className="col-md-12 cust-checkbox-new mb-3">
                            <label className="cust-chk-bx">
                                <input type="checkbox" onChange={this.isSaleItem2} />
                                <span className="cust-chkmark" />
                                For Sale Item
                            </label>
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.mainCategory}</label>
                            <select name="mainCategory2" value={this.state.mainCategory2} onChange={this.handleChange} onChangeCapture={this.handleChange1} className="form-select input-custom-class" >
                                <option>{this.props.selectedCatagory.english} | {this.props.selectedCatagory.arabic} </option>
                                {this.state.maincategoryData &&
                                    this.state.maincategoryData.length > 0 &&
                                    this.state.maincategoryData.map((item, i) => {
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                            {this.state.errorMainCatogory && <div className="input-feedback text-danger">{'Required'}</div>}
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.category}</label>
                            <select name="category2" value={this.state.category2} onChange={this.handleChange} onChangeCapture={this.handleChange1} className="form-select input-custom-class" disabled={this.state.isSaleItem2}>
                                <option value={''}>{productLanguage.SelectCategory} </option>
                                {this.state.categoryData2 &&
                                    this.state.categoryData2.length > 0 &&
                                    this.state.categoryData2.map((item, i) => {
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                            {this.state.errorCatogory && <div className="input-feedback text-danger">{'Required'}</div>}
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.subCategory}</label>
                            <select name="subCategory2" value={this.state.subCategory2} onChange={this.handleChange} onChangeCapture={this.handleChange1} className="form-select input-custom-class" disabled={this.state.isSaleItem2}>
                                <option>{productLanguage.SelectSubCategory}</option>
                                {this.state.subCategoryData2 &&
                                    this.state.subCategoryData2.length > 0 &&
                                    this.state.subCategoryData2.map((item, i) => {
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                            {this.state.errorSubCatogory && <div className="input-feedback text-danger">{'Required'}</div>}
                        </div>
                        <div className="col-md-12 avtar-txt m-0 border-top pt-2">
                            <p>Banner-3</p>
                        </div>
                        <div className="col-md-6">
                            <div className="img-upload py-3">
                                <div className="avatar-preview">
                                    <div id="imagePreview">
                                        <div className="banner-main-box-ad">
                                            <div>
                                                <img id='banner3EnglishPreview5' src={this.state.banner3English === '' ? imgplaceholder : this.state.banner3English} alt="" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="avtar-txt">
                                    <p>{ButtonLanguage.UploadyourbannerEnglishdesktop}</p>
                                    <span>{ButtonLanguage.uploadimagemaxsize} 340*340px.</span>
                                    <div className="avatar-edit">
                                        <input className="d-none" type="file" id="imageUpload5" name='banner3English' onChange={(e) => this.handleImageChange(e, 'square')} accept=".png, .jpg, .jpeg" />
                                        <label className="btn red-btn mt-3" htmlFor="imageUpload5">
                                            <i className="bi bi-upload me-2" />
                                            {ButtonLanguage.Uploadimage}
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <div className="img-upload py-3">
                                <div className="avatar-preview">
                                    <div id="imagePreview">
                                        <div className="banner-main-box-ad">
                                            <div>
                                                <img id='banner3ArabicPreview5' src={this.state.banner3Arabic === '' ? imgplaceholder : this.state.banner3Arabic} alt="" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="avtar-txt">
                                    <p>{ButtonLanguage.UploadyourbannerArabicdesktop}</p>
                                    <span>{ButtonLanguage.uploadimagemaxsize} 340*340px.</span>
                                    <div className="avatar-edit">
                                        <input className="d-none" type="file" id="imageUpload6" name='banner3Arabic' onChange={(e) => this.handleImageChange(e, 'square')} accept=".png, .jpg, .jpeg" />
                                        <label className="btn red-btn mt-3" htmlFor="imageUpload6">
                                            <i className="bi bi-upload me-2" />
                                            {ButtonLanguage.Uploadimage}
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/*<div class="col-xl-12 mb-3 ">
                            <div className='edit-banner-cust form-group d-flex align-items-center'>
                                <span id='ActiveUrl1' className='active'>{ButtonLanguage.ProductListing}</span>
                                <label class="switch mx-2 mb-0">
                                    <input type="checkbox" checked={this.state.SelectUrlType} onChange={this.handleCheckbox} />
                                    <div class="slider round"></div>
                                </label>
                                <span id='ActiveUrl2'>{ButtonLanguage.ProductPage}</span>
                            </div>
                        </div>*/}


                        <div className="col-md-12 form-group">
                            <label>{!this.state.SelectUrlType ? ButtonLanguage.ProductListing + " URL" : ButtonLanguage.ProductPage + " URL"}</label>
                            <input type="url" name='bannerUrl3' onChange={this.handleChange} className="form-control input-custom-class" />
                        </div>
                        <div className="col-md-12 cust-checkbox-new mb-3">
                            <label className="cust-chk-bx">
                                <input type="checkbox" onChange={this.isSaleItem3} />
                                <span className="cust-chkmark" />
                                For Sale Item
                            </label>
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.mainCategory}</label>
                            <select name="mainCategory3" value={this.state.mainCategory3} onChange={this.handleChange} onChangeCapture={this.handleChange1} className="form-select input-custom-class" >
                                <option>{this.props.selectedCatagory.english} | {this.props.selectedCatagory.arabic} </option>
                                {this.state.maincategoryData &&
                                    this.state.maincategoryData.length > 0 &&
                                    this.state.maincategoryData.map((item, i) => {
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                            {this.state.errorMainCatogory && <div className="input-feedback text-danger">{'Required'}</div>}
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.category}</label>
                            <select name="category3" value={this.state.category3} onChange={this.handleChange} onChangeCapture={this.handleChange1} className="form-select input-custom-class" disabled={this.state.isSaleItem3}>
                                <option value={''}>{productLanguage.SelectCategory} </option>
                                {this.state.categoryData3 &&
                                    this.state.categoryData3.length > 0 &&
                                    this.state.categoryData3.map((item, i) => {
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                            {this.state.errorCatogory && <div className="input-feedback text-danger">{'Required'}</div>}
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.subCategory}</label>
                            <select name="subCategory3" value={this.state.subCategory3} onChange={this.handleChange} onChangeCapture={this.handleChange1} className="form-select input-custom-class" disabled={this.state.isSaleItem3}>
                                <option>{productLanguage.SelectSubCategory}</option>
                                {this.state.subCategoryData3 &&
                                    this.state.subCategoryData3.length > 0 &&
                                    this.state.subCategoryData3.map((item, i) => {
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                            {this.state.errorSubCatogory && <div className="input-feedback text-danger">{'Required'}</div>}
                        </div>
                    </div>
                    <div className="col-md-12 form-group">
                        <button onClick={this.handleSubmit} className="red-btn">{ButtonLanguage.submit}</button>
                    </div>
                </Modal.Body>
            </Modal>
        </React.Fragment>
        )
    }
}
