import React, { Component } from 'react'
import { Modal } from 'react-bootstrap'
import toastr from "toastr";
import { buttonEnglish, buttonArabic, API_Path, productEnglish, productArabic } from '../const'
import LanguageContext from "../contexts/languageContext";
import { PostApi } from '../helper/APIService';

export default class Position2 extends Component {
    static contextType = LanguageContext;
    state = {
        offerTextEnglish: '',
        offerTextArabic: '',
        bgColor: '',
        bannerUrl: '',
        maincategoryData: '',
        mainCategory: this.props.selectedCatagory.id,
        categoryData: '',
        category: '',
        subCategoryData: '',
        subCategory: '',
        errorCatogory: '',
        errorSubCatogory: '',
        errorMainCatogory: '',
        isSaleItem: false,
        SearchParams: null
    }

    componentDidMount() {
        this.setState({ maincategoryData: this.props.masterCatagoryData })
        this.getCategoryData(this.state.mainCategory);
        this.getMainCategoryData()
    }
    getMainCategoryData = () => {

        let data = {};

        let path = API_Path.getMainCategory;
        const getMainCategoryPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        getMainCategoryPromise.then((res) => {
            if (res) {
                // console.log('res is :: ', res.data.data);
                this.setState({ maincategoryData: res.data.data });
            }
        });
    };
    handleChange1 = (e) => {
        if (e.target.name == "mainCategory") {
            this.getCategoryData(e.target.value);
            this.setState({ mainCategory: e.target.value });
        }
        if (e.target.name == "category") {
            this.getSubCategoryData(e.target.value);
            this.setState({ category: e.target.value });
        }
        if (e.target.name == "subCategory") {
            this.setState({ subCategory: e.target.value }, () => {
                // this.getSizeGuideLine();
            });
        }
    };
    getCategoryData = (val) => {
        if (val) {

            let data = { main_category_id: val };
            let path = API_Path.getCategoryRelative;
            const getCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ categoryData: res.data.data });
                }
            });
        } else {

            let data = {};

            let path = API_Path.getCategory;
            const getCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ categoryData: res.data.data });
                }
            });
        }
    };
    getSubCategoryData = (val) => {
        // console.log(val);
        if (val) {

            let data = { category_id: val };

            let path = API_Path.getSubCategoryRelative;
            const getSubCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getSubCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ subCategoryData: res.data.data });
                }
            });
        } else {

            let data = {};
            let path = API_Path.getSubCategory;
            const getSubCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getSubCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ subCategoryData: res.data.data });
                }
            });
        }
    };
    makeid = (length) => {
        var result = '';
        var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var charactersLength = characters.length;
        for (var i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() *
                charactersLength));
        }
        return result;
    }

    handleChange = (e) => {
        if (this.state.errorMainCatogory) {
            this.setState({ errorMainCatogory: false })
        }
        if (this.state.errorCatogory) {
            this.setState({ errorCatogory: false })
        }
        if (this.state.errorSubCatogory) {
            this.setState({ errorSubCatogory: false })
        }
        this.setState({ [e.target.name]: e.target.value }, () => {
            if (this.state.category == '') {
                this.setState({ subCategory: '' })
            }
        })
    }

    handleCheckbox = (e) => {
        if (e.target.checked) {
            document.getElementById('ActiveUrl2').classList.add('active')
            document.getElementById('ActiveUrl1').classList.remove('active')
            this.setState({ SelectUrlType: true, searchSyntax: new URLSearchParams(this.state.bannerUrl.split('?')[1]).get('search') });
        } else {
            document.getElementById('ActiveUrl1').classList.add('active')
            document.getElementById('ActiveUrl2').classList.remove('active')
            this.setState({ SelectUrlType: false });
        }
        this.setState({ bannerUrl: "" }, () => {
            this.setState({ SelectUrlType: e.target.checked })
        })
    }

    handleSubmit = () => {
        let search = this.state.SearchParams
        let prductId
        let allcategories
        if (this.state.bannerUrl.includes('search=')) {
            // search = 'SALE'
        } else if (!this.state.bannerUrl.includes('allcategories=')) {
            prductId = this.state.bannerUrl.substr(this.state.bannerUrl.lastIndexOf("-") + 1);
        } else {
            let params = this.state.bannerUrl.split('?')[1]
            const url = new URLSearchParams(params);
            allcategories = url.get('allcategories').split('--');
        }
        let filters = {}
        let banner_url = this.state.bannerUrl.split('?')[1]
        const query = new URLSearchParams(banner_url);
        // ==============================make sure that below-params must same as mention in website (next.js) in filter page=========================================
        filters.size = Array.from(query.getAll('SIZE'), (value) => parseInt(value.split('--')[1]))
        filters.colors = Array.from(query.getAll('COLORS'), (value) => parseInt(value.split('--')[1]))
        filters.prices = Array.from(query.getAll('PRICES'), (value) => parseInt(value.split('--')[1]))
        filters.discounts = Array.from(query.getAll('DISCOUNTS'), (value) => parseInt(value.split('--')[1]))
        filters.occassion = Array.from(query.getAll('OCCASSION'), (value) => parseInt(value.split('--')[1]))
        filters.neckline = Array.from(query.getAll('NECKLINE'), (value) => parseInt(value.split('--')[1]))
        filters.sleeve = Array.from(query.getAll('SLEEVE'), (value) => parseInt(value.split('--')[1]))
        filters.design = Array.from(query.getAll('DESIGN'), (value) => parseInt(value.split('--')[1]))
        filters.waist = Array.from(query.getAll('WAIST'), (value) => parseInt(value.split('--')[1]))
        filters.length = Array.from(query.getAll('LENGTH'), (value) => parseInt(value.split('--')[1]))
        filters.fit = Array.from(query.getAll('FIT'), (value) => parseInt(value.split('--')[1]))
        if (this.state.offerTextEnglish === '') {
            toastr.error('Please add text of offer in english')
        } else if (this.state.offerTextArabic === '') {
            toastr.error('Please add text of offer in arabic')
        } else if (this.state.bgColor === '') {
            toastr.error('Please select Background color')
        } else if (this.state.bannerUrl === '') {
            toastr.error('Please add link for redirection')

        } else {
            let data = {
                offer_text_english: this.state.offerTextEnglish,
                offer_text_arabic: this.state.offerTextArabic,
                bg_color: this.state.bgColor,
                banner_url: this.state.bannerUrl,
                banner_id: this.makeid(10),
                status: '1',
                category: this.state.category,
                sub_category_name: allcategories ? allcategories[2] : allcategories,
                sub_category: this.state.subCategory,
                main_category: this.state.mainCategory,
                search: search,
                product_id: prductId,
                table_name: "two",
                filter: JSON.stringify(filters),
                filter_type: query.get('sort-type')
            }
            this.props.submitPosition2(data)
            this.setState({
                offerTextEnglish: '',
                offerTextArabic: '',
                bgColor: '',
                bannerUrl: '',
                mainCategory: undefined,
                category: '',
                subCategory: '',
            })
        }
    }

    isSaleItem = (e) => {
        if (e.target.checked) {
            this.setState({ category: '', subCategory: '', SearchParams: 'SALE' })
        } else {
            this.setState({ SearchParams: null })
        }
        this.setState({ isSaleItem: e.target.checked })
    }

    render() {
        let ButtonLanguage = this.context.language === "english" ? buttonEnglish : buttonArabic;
        let productLanguage = this.context.language === "english" ? productEnglish : productArabic;;
        return (
            <Modal
                dialogClassName="modal-dialog-centered"
                className="edit-user-modal cust-modal"
                // size="l"
                ref={(el) => {
                    this.dialog = el
                }}
                show={this.props.show}
                onHide={this.props.closePosition2}
            >
                <Modal.Header>
                    <Modal.Title>
                        <h1 className="modal-title">{ButtonLanguage.addOffer}</h1>
                    </Modal.Title>
                    <button
                        type="button"
                        onClick={this.props.closePosition2}
                        className="close btn-close"
                    ></button>
                </Modal.Header>
                <Modal.Body>
                    <div className="row">
                        <div className="col-md-12 form-group">
                            <label>{ButtonLanguage.AddofferTextEnglish}</label>
                            <input onChange={this.handleChange} type="text" value={this.state.offerTextEnglish} name='offerTextEnglish' className="form-control input-custom-class" placeholder="Ex. Get SAR 91 off on SAR 500, use code: ND91" />
                        </div>
                        <div className="col-md-12 form-group">
                            <label>{ButtonLanguage.AddofferTextArabic}</label>
                            <input onChange={this.handleChange} type="text" value={this.state.offerTextArabic} name='offerTextArabic' className="form-control input-custom-class" placeholder="Ex. Get SAR 91 off on SAR 500, use code: ND91" />
                        </div>
                        <div className="col-md-12 form-group">
                            <label>{ButtonLanguage.ChooseBackgroundColor}</label>
                            <input onChange={this.handleChange} type="color" value={this.state.bgColor} name='bgColor' className="form-control input-custom-class" />
                        </div>

                        {/*<div class="col-xl-12 mb-3 ">
                            <div className='edit-banner-cust form-group d-flex align-items-center'>
                                <span id='ActiveUrl1' className='active'>{ButtonLanguage.ProductListing}</span>
                                <label class="switch mx-2 mb-0">
                                    <input type="checkbox" checked={this.state.SelectUrlType} onChange={this.handleCheckbox} />
                                    <div class="slider round"></div>
                                </label>
                                <span id='ActiveUrl2'>{ButtonLanguage.ProductPage}</span>
                            </div>
                        </div>*/}


                        <div className="col-md-12 form-group">
                            <label>{!this.state.SelectUrlType ? ButtonLanguage.ProductListing + " URL" : ButtonLanguage.ProductPage + " URL"}</label>
                            <input type="url" name='bannerUrl' onChange={this.handleChange} className="form-control input-custom-class" />
                        </div>
                        <div className="col-md-12 cust-checkbox-new mb-3">
                            <label className="cust-chk-bx">
                                <input type="checkbox" onChange={this.isSaleItem} />
                                <span className="cust-chkmark" />
                                For Sale Item
                            </label>
                        </div>

                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.mainCategory}</label>
                            <select name="mainCategory" value={this.state.mainCategory} onChange={this.handleChange} onChangeCapture={this.handleChange1} className="form-select input-custom-class" >
                                <option>{this.props.selectedCatagory.english} | {this.props.selectedCatagory.arabic} </option>
                                {this.state.maincategoryData &&
                                    this.state.maincategoryData.length > 0 &&
                                    this.state.maincategoryData.map((item, i) => {
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                            {this.state.errorMainCatogory && <div className="input-feedback text-danger">{'Required'}</div>}
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.category}</label>
                            <select name="category" value={this.state.category} onChange={this.handleChange} onChangeCapture={this.handleChange1} className="form-select input-custom-class" disabled={this.state.isSaleItem}>
                                <option value={''}>{productLanguage.SelectCategory} </option>
                                {this.state.categoryData &&
                                    this.state.categoryData.length > 0 &&
                                    this.state.categoryData.map((item, i) => {
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                            {this.state.errorCatogory && <div className="input-feedback text-danger">{'Required'}</div>}
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.subCategory}</label>
                            <select name="subCategory" value={this.state.subCategory} onChange={this.handleChange} onChangeCapture={this.handleChange1} className="form-select input-custom-class" disabled={this.state.isSaleItem}>
                                <option>{productLanguage.SelectSubCategory}</option>
                                {this.state.subCategoryData &&
                                    this.state.subCategoryData.length > 0 &&
                                    this.state.subCategoryData.map((item, i) => {
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                            {this.state.errorSubCatogory && <div className="input-feedback text-danger">{'Required'}</div>}
                        </div>
                    </div>
                    <div className="col-md-12 form-group">
                        <button onClick={this.handleSubmit} className="red-btn">{ButtonLanguage.submit}</button>
                    </div>
                </Modal.Body>
            </Modal>
        )
    }
}
