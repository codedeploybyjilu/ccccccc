import React, { Component } from 'react'
import { Modal } from 'react-bootstrap'
import banner from '../images/full-banner.png'
import imgplaceholder from '../images/img-placeholder.svg'
import toastr from "toastr";
import { buttonEnglish, buttonArabic, APIBaseUrl, API_Path, LIVE_FILE_URL, productEnglish, productArabic } from '../const';
import { PostApi } from '../helper/APIService';
import loader from '../images/loader.gif'
import LanguageContext from "../contexts/languageContext";
import { ImageCompress } from '../Components/ImageCompress';


export default class EditPosition10 extends Component {
    static contextType = LanguageContext;
    state = {
        maincategoryData: '',
        mainCategory: this.props.data.main_category,
        categoryData: '',
        category: '',
        subCategoryData: '',
        subCategory: '',
        errorCatogory: '',
        errorSubCatogory: '',
        errorMainCatogory: '',
        pcEnglish: '',
        pcArabic: '',
        bannerUrl: '',
        isLoading: false,
        isSaleItem: false,
        SearchParams: null
    }

    componentDidMount() {
        this.setState({
            pcEnglish: this.props.data.pc_english,
            pcArabic: this.props.data.pc_arabic,
            bannerUrl: this.props.data.banner_url,
            // mainCategory: this.props.data.main_category,
            category: this.props.data.category,
            subCategory: this.props.data.sub_category
        }, () => {
            if (this.state.bannerUrl && this.state.bannerUrl.includes('filter')) {
                this.setState({ SelectUrlType: true, searchSyntax: new URLSearchParams(this.state.bannerUrl.split('?')[1]).get('search') });
            } else {
                this.setState({ SelectUrlType: false });
            }
            this.getMainCategoryData()
            this.getCategoryData(this.state.mainCategory)
            if (this.props.data.category) {
                this.getSubCategoryData(this.props.data.category)
            }
        })
    }

    componentDidUpdate(preProps) {
        if (preProps !== this.props) {
            this.setState({
                pcEnglish: this.props.data.pc_english,
                pcArabic: this.props.data.pc_arabic,
                bannerUrl: this.props.data.banner_url
            })
        }
    }

    handleImageChange = (e) => {
        let fileName = e.target.name
        let file = e.target.files
        const image = new Image();
        let fr = new FileReader();

        fr.onload = function () {
            if (fr !== null && typeof fr.result == "string") {
                image.src = fr.result;
            }
        };
        fr.readAsDataURL(e.target.files[0]);

        image.onload = async () => {
            const width = image.width;
            console.log('width is :: ', width, image.height);

            // if (image.width > 345 && image.width < 355 && image.height > 380 && image.height < 390) {
            this.setState({ isLoading: true }, () => {
                this.addImageToStorage(file, fileName)
            })
            // } else {
            //     toastr.error('You can upload image of max size of 5mb. Image will be cropped to 350*385px.')
            // }
        };

    }

    getMainCategoryData = () => {

        let data = {};

        let path = API_Path.getMainCategory;
        const getMainCategoryPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        getMainCategoryPromise.then((res) => {
            if (res) {
                // console.log('res is :: ', res.data.data);
                this.setState({ maincategoryData: res.data.data });
            }
        });
    };
    handleChange1 = (e) => {
        if (e.target.name == "mainCategory") {
            this.getCategoryData(e.target.value);
            this.setState({ mainCategory: e.target.value });
        }
        if (e.target.name == "category") {
            this.getSubCategoryData(e.target.value);
            this.setState({ category: e.target.value });
        }
        if (e.target.name == "subCategory") {
            this.setState({ subCategory: e.target.value }, () => {
                // this.getSizeGuideLine();
            });
        }
    };
    getCategoryData = (val) => {
        if (val) {

            let data = { main_category_id: val };
            let path = API_Path.getCategoryRelative;
            const getCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ categoryData: res.data.data });
                }
            });
        } else {

            let data = {};

            let path = API_Path.getCategory;
            const getCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ categoryData: res.data.data });
                }
            });
        }
    };
    getSubCategoryData = (val) => {
        // console.log(val);
        if (val) {

            let data = { category_id: val };

            let path = API_Path.getSubCategoryRelative;
            const getSubCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getSubCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ subCategoryData: res.data.data });
                }
            });
        } else {

            let data = {};
            let path = API_Path.getSubCategory;
            const getSubCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getSubCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ subCategoryData: res.data.data });
                }
            });
        }
    };
    handleChange = (e) => {
        // if (!this.state.SelectUrlType) {
        this.setState({ [e.target.name]: e.target.value }, () => {
            if (this.state.category == '') {
                this.setState({ subCategory: '' })
            }
        })
        // } else {
        //     let searchUrl = `${this.props.data.master_category}/filter?search=${e.target.value.split(' ').join('%20')}`;
        //     this.setState({ bannerUrl: searchUrl })
        // }
    }

    handleCheckbox = (e) => {
        if (e.target.checked) {
            document.getElementById('ActiveUrl2').classList.add('active')
            document.getElementById('ActiveUrl1').classList.remove('active')
        } else {
            document.getElementById('ActiveUrl1').classList.add('active')
            document.getElementById('ActiveUrl2').classList.remove('active')
        }
        this.setState({ bannerUrl: "" }, () => {
            this.setState({ SelectUrlType: e.target.checked })
        })
    }

    addImageToStorage = async (files, name) => {


        console.log('files is :: ', files);

        let imgArr = await ImageCompress(files)
        var formData = new FormData;
        for (var i = 0; i < imgArr.length; i++) {
            formData.append('file', imgArr[i]);
        }
        console.log('form data ;: ', formData);
        let path = API_Path.addFileInS3
        const addFilePromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, formData));
        });

        addFilePromise.then((res) => {
            if (res) {
                console.log('res is :: ', res);
                this.setState({ [name]: res.data.data[0], isLoading: false }, () => {
                    if (this.state.pcEnglish !== '') {
                        document.getElementById('pcEnglishPreview10').classList.add('imageUpload')
                    } else {
                        document.getElementById('pcEnglishPreview10').classList.remove('imageUpload')
                    }

                    if (this.state.pcArabic !== '') {
                        document.getElementById('pcArabicPreview10').classList.add('imageUpload')
                    } else {
                        document.getElementById('pcArabicPreview10').classList.remove('imageUpload')
                    }

                })
            }
        });
    }


    handleSubmit = () => {
        let search = this.state.SearchParams
        let prductId
        let allcategories
        if (this.state.bannerUrl.includes('search=')) {
            // search = 'SALE'
        } else if (!this.state.bannerUrl.includes('allcategories=')) {
            prductId = this.state.bannerUrl.substr(this.state.bannerUrl.lastIndexOf("-") + 1);
        } else {
            let params = this.state.bannerUrl.split('?')[1]
            const url = new URLSearchParams(params);
            allcategories = url.get('allcategories').split('--');
        }
        let filters = {}
        let banner_url = this.state.bannerUrl.split('?')[1]
        const query = new URLSearchParams(banner_url);
        // ==============================make sure that below-params must same as mention in website (next.js) in filter page=========================================
        filters.size = Array.from(query.getAll('SIZE'), (value) => parseInt(value.split('--')[1]))
        filters.colors = Array.from(query.getAll('COLORS'), (value) => parseInt(value.split('--')[1]))
        filters.prices = Array.from(query.getAll('PRICES'), (value) => parseInt(value.split('--')[1]))
        filters.discounts = Array.from(query.getAll('DISCOUNTS'), (value) => parseInt(value.split('--')[1]))
        filters.occassion = Array.from(query.getAll('OCCASSION'), (value) => parseInt(value.split('--')[1]))
        filters.neckline = Array.from(query.getAll('NECKLINE'), (value) => parseInt(value.split('--')[1]))
        filters.sleeve = Array.from(query.getAll('SLEEVE'), (value) => parseInt(value.split('--')[1]))
        filters.design = Array.from(query.getAll('DESIGN'), (value) => parseInt(value.split('--')[1]))
        filters.waist = Array.from(query.getAll('WAIST'), (value) => parseInt(value.split('--')[1]))
        filters.length = Array.from(query.getAll('LENGTH'), (value) => parseInt(value.split('--')[1]))
        filters.fit = Array.from(query.getAll('FIT'), (value) => parseInt(value.split('--')[1]))
        if (this.state.bannerUrl === '') {
            toastr.error('Please add link for redirection')
        } else {
            let data = {
                pc_english: this.state.pcEnglish,
                pc_arabic: this.state.pcArabic,
                banner_url: this.state.bannerUrl,
                banner_id: this.props.data.banner_id,
                status: '1',
                category: this.state.category,
                sub_category_name: allcategories ? allcategories[2] : allcategories,
                sub_category: this.state.subCategory,
                main_category: this.state.mainCategory,
                search: search,
                product_id: prductId,
                filter: JSON.stringify(filters),
                filter_type: query.get('sort-type')
            }
            this.setState({
                pcEnglish: '',
                mobileEnglish: '',
                pcArabic: '',
                mobileArabic: '',
                bannerUrl: ''
            }, () => {
                this.props.submitEditPosition10(data)
            })
        }
    }

    isSaleItem = (e) => {
        if (e.target.checked) {
            this.setState({ category: '', subCategory: '', SearchParams: 'SALE' })
        } else {
            this.setState({ SearchParams: null })
        }
        this.setState({ isSaleItem: e.target.checked })
    }

    render() {
        let ButtonLanguage = this.context.language === "english" ? buttonEnglish : buttonArabic;
        let productLanguage = this.context.language === "english" ? productEnglish : productArabic;;

        return (<React.Fragment>
            {this.state.isLoading && (
                <div className="loader-main">
                    <div className="loader-inr">
                        <img src={loader} alt="" />
                    </div>
                </div>
            )}
            <Modal
                dialogClassName="modal-dialog-centered"
                className="edit-user-modal cust-modal"
                size="xl"
                ref={(el) => {
                    this.dialog = el
                }}
                show={this.props.show}
                onHide={this.props.closeEditPosition10}
            >
                <Modal.Header>
                    <Modal.Title>
                        <h1 className="modal-title">{ButtonLanguage.edit}</h1>
                    </Modal.Title>
                    <button
                        type="button"
                        onClick={this.props.closeEditPosition10}
                        className="close btn-close"
                    ></button>
                </Modal.Header>
                <Modal.Body>
                    <div className="row">
                        <div className="col-md-6">
                            <div className="img-upload">
                                <div className="avatar-preview">
                                    <div id="imagePreview">
                                        <div className="banner-main-box-ad">
                                            <div>
                                                <img className='imageUpload' id='pcEnglishPreview10' src={this.state.pcEnglish === '' ? imgplaceholder : this.state.pcEnglish} alt="" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="avtar-txt">
                                    <p>{ButtonLanguage.UploadyourbannerEnglishdesktop}</p>
                                    <span>{ButtonLanguage.uploadimagemaxsize} 350*385px.</span>
                                    <div className="avatar-edit">
                                        <input className="d-none" type="file" id="imageUpload1" name='pcEnglish' onChange={this.handleImageChange} accept=".png, .jpg, .jpeg" />
                                        <label className="btn red-btn mt-3" htmlFor="imageUpload1">
                                            <i className="bi bi-upload me-2" />
                                            {ButtonLanguage.Changeimage}
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-md-6">
                            <div className="img-upload">
                                <div className="avatar-preview">
                                    <div id="imagePreview">
                                        <div className="banner-main-box-ad">
                                            <div>
                                                <img className='imageUpload' id='pcArabicPreview10' src={this.state.pcArabic === '' ? imgplaceholder : this.state.pcArabic} alt="" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="avtar-txt">
                                    <p>{ButtonLanguage.UploadyourbannerArabicdesktop}</p>
                                    <span>{ButtonLanguage.uploadimagemaxsize} 350*385px.</span>
                                    <div className="avatar-edit">
                                        <input className="d-none" type="file" id="imageUpload3" name='pcArabic' onChange={this.handleImageChange} accept=".png, .jpg, .jpeg" />
                                        <label className="btn red-btn mt-3" htmlFor="imageUpload3">
                                            <i className="bi bi-upload me-2" />
                                            {ButtonLanguage.Changeimage}
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>


                        {/* <div class="col-xl-12 mb-3 ">
                                <div className='edit-banner-cust form-group d-flex align-items-center'>
                                    <span id='ActiveUrl1' className='active'>{ButtonLanguage.ProductListing}</span>
                                    <label class="switch mx-2 mb-0">
                                        <input type="checkbox" onChange={this.handleCheckbox} />
                                        <div class="slider round"></div>
                                    </label>
                                    <span id='ActiveUrl2'>{ButtonLanguage.ProductPage}</span>
                                </div>
                            </div> */}


                        <div className="col-md-12 form-group">
                            <label>{!this.state.SelectUrlType ? ButtonLanguage.ProductListing + " URL" : ButtonLanguage.ProductPage + " URL"}</label>
                            <input type="url" name='bannerUrl' value={this.state.bannerUrl} onChange={this.handleChange} className="form-control input-custom-class" />
                        </div>
                        <div className="col-md-12 cust-checkbox-new mb-3">
                            <label className="cust-chk-bx">
                                <input type="checkbox" onChange={this.isSaleItem} />
                                <span className="cust-chkmark" />
                                For Sale Item
                            </label>
                        </div>


                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.mainCategory}</label>
                            <select name="mainCategory" value={this.state.mainCategory} onChange={this.handleChange} onChangeCapture={this.handleChange1} className="form-select input-custom-class" >
                                <option>{productLanguage.chooseMainCategory} </option>
                                {this.state.maincategoryData &&
                                    this.state.maincategoryData.length > 0 &&
                                    this.state.maincategoryData.map((item, i) => {
                                        // console.log(item, "itemm");
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.category}</label>
                            <select name="category" value={this.state.category} onChange={this.handleChange} onChangeCapture={this.handleChange1} className="form-select input-custom-class" disabled={this.state.isSaleItem}>
                                <option value={''}>{productLanguage.SelectCategory} </option>
                                {this.state.categoryData &&
                                    this.state.categoryData.length > 0 &&
                                    this.state.categoryData.map((item, i) => {
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                            {this.state.errorCatogory && <div className="input-feedback text-danger">{'Required'}</div>}
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.subCategory}</label>
                            <select name="subCategory" value={this.state.subCategory} onChange={this.handleChange} onChangeCapture={this.handleChange1} className="form-select input-custom-class" disabled={this.state.isSaleItem}>
                                <option>{productLanguage.SelectSubCategory}</option>
                                {this.state.subCategoryData &&
                                    this.state.subCategoryData.length > 0 &&
                                    this.state.subCategoryData.map((item, i) => {
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                            {this.state.errorSubCatogory && <div className="input-feedback text-danger">{'Required'}</div>}
                        </div>
                    </div>
                    <div className="col-md-12 form-group">
                        <button onClick={this.handleSubmit} className="red-btn">{ButtonLanguage.submit}</button>
                    </div>
                </Modal.Body>
            </Modal>
        </React.Fragment>
        )
    }
}
