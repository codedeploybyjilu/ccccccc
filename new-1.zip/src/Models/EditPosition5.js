import React, { Component } from 'react'
import { Modal } from 'react-bootstrap'
import banner from '../images/full-banner.png'
import imgplaceholder from '../images/img-placeholder.svg'
import toastr from "toastr";
import { PostApi } from '../helper/APIService';
import loader from '../images/loader.gif'

import { buttonEnglish, buttonArabic, APIBaseUrl, API_Path, productEnglish, productArabic } from '../const'
import LanguageContext from "../contexts/languageContext";
import { ImageCompress } from '../Components/ImageCompress';


export default class EditPosition5 extends Component {
    static contextType = LanguageContext;
    state = {
        maincategoryData: '',
        mainCategory: this.props.data.main_category,
        mainCategory2: this.props.data.main_category2,
        mainCategory3: this.props.data.main_category3,
        categoryData: '',
        categoryData2: '',
        categoryData3: '',
        category: '',
        subCategoryData: '',
        subCategoryData2: '',
        subCategoryData3: '',
        subCategory: '',
        subCategory2: '',
        category2: '',
        subCategory3: '',
        category3: '',
        errorCatogory: '',
        errorSubCatogory: '',
        errorMainCatogory: '',
        banner1English: '',
        banner1Arabic: '',
        banner2English: '',
        banner2Arabic: '',
        banner3English: '',
        banner3Arabic: '',
        bannerUrl1: '',
        bannerUrl2: '',
        bannerUrl3: '',
        isLoading: false,
        isSaleItem1: false,
        SearchParams1: null,
        isSaleItem2: false,
        SearchParams2: null,
        isSaleItem3: false,
        SearchParams3: null,
    }

    componentDidMount() {
        console.log("this.state.bannerUrl1", this.props.data)
        this.setState({
            banner1English: this.props.data.banner_1_english,
            banner1Arabic: this.props.data.banner_1_arabic,
            banner2English: this.props.data.banner_2_english,
            banner2Arabic: this.props.data.banner_2_arabic,
            banner3English: this.props.data.banner_3_english,
            banner3Arabic: this.props.data.banner_3_arabic,
            bannerUrl1: this.props.data.banner_url_1,
            bannerUrl2: this.props.data.banner_url_2,
            bannerUrl3: this.props.data.banner_url_3,
            // mainCategory: this.props.data.main_category,
            category: this.props.data.category,
            category2: this.props.data.category_2,
            category3: this.props.data.category_3,
            subCategory: this.props.data.sub_category,
            subCategory2: this.props.data.sub_category_2,
            subCategory3: this.props.data.sub_category_3
        }, () => {
            if (this.state.bannerUrl1 && this.state.bannerUrl1.includes('filter')) {
                this.setState({ SelectUrlType1: true, searchSyntax1: new URLSearchParams(this.state.bannerUrl1.split('?')[1]).get('search') });
            } else {
                this.setState({ SelectUrlType1: false });
            }
            if (this.state.bannerUrl2 && this.state.bannerUrl2.includes('filter')) {
                this.setState({ SelectUrlType2: true, searchSyntax2: new URLSearchParams(this.state.bannerUrl2.split('?')[1]).get('search') });
            } else {
                this.setState({ SelectUrlType2: false });
            }
            if (this.state.bannerUrl3 && this.state.bannerUrl3.includes('filter')) {
                this.setState({ SelectUrlType3: true, searchSyntax3: new URLSearchParams(this.state.bannerUrl3.split('?')[1]).get('search') });
            } else {
                this.setState({ SelectUrlType3: false });
            }
        })
        this.getMainCategoryData()
        this.getCategoryData(this.state.mainCategory)
        this.getCategoryData2(this.state.mainCategory2)
        this.getCategoryData3(this.state.mainCategory3)
        if (this.props.data.category) {
            this.getSubCategoryData(this.props.data.category)
            this.getSubCategoryData2(this.props.data.category_2)
            this.getSubCategoryData3(this.props.data.category_3)
        }
    }

    componentDidUpdate(preProps) {
        if (preProps !== this.props) {
            this.setState({
                banner1English: this.props.data.banner_1_english,
                banner1Arabic: this.props.data.banner_1_arabic,
                banner2English: this.props.data.banner_2_english,
                banner2Arabic: this.props.data.banner_2_arabic,
                banner3English: this.props.data.banner_3_english,
                banner3Arabic: this.props.data.banner_3_arabic,
                bannerUrl1: this.props.data.banner_url_1,
                bannerUrl2: this.props.data.banner_url_2,
                bannerUrl3: this.props.data.banner_url_3,
            })
        }
    }
    getMainCategoryData = () => {

        let data = {};

        let path = API_Path.getMainCategory;
        const getMainCategoryPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        getMainCategoryPromise.then((res) => {
            if (res) {
                // console.log('res is :: ', res.data.data);
                this.setState({ maincategoryData: res.data.data });
            }
        });
    };
    handleChangecapture = (e) => {
        if (e.target.name == 'mainCategory') {
            this.getCategoryData(e.target.value, e.target.name);
        } else if (e.target.name == 'mainCategory2') {
            this.getCategoryData2(e.target.value, e.target.name);
        } else if (e.target.name == "mainCategory3") {
            this.getCategoryData3(e.target.value, e.target.name);
        }
        if (e.target.name == 'category') {
            this.getSubCategoryData(e.target.value, e.target.name);
        } else if (e.target.name == 'category2') {
            this.getSubCategoryData2(e.target.value, e.target.name);
        } else if (e.target.name == "category3") {
            this.getSubCategoryData3(e.target.value, e.target.name);
        }
        if (e.target.name == "category" || e.target.name == "category2" || e.target.name == "category3") {
            // this.setState({ category: e.target.value });
        }
        if (e.target.name == "subCategory") {
            // this.setState({ subCategory: e.target.value }, () => {
            //     // this.getSizeGuideLine();
            // });
        }
    };
    getCategoryData = (val, name) => {
        if (val) {

            let data = { main_category_id: val };
            let path = API_Path.getCategoryRelative;
            const getCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ categoryData: res.data.data });
                }
            });
        } else {

            let data = {};

            let path = API_Path.getCategory;
            const getCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ categoryData: res.data.data });
                }
            });
        }
    };
    getCategoryData2 = (val, name) => {
        if (val) {

            let data = { main_category_id: val };
            let path = API_Path.getCategoryRelative;
            const getCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ categoryData2: res.data.data });
                }
            });
        } else {

            let data = {};

            let path = API_Path.getCategory;
            const getCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ categoryData2: res.data.data });
                }
            });
        }
    };
    getCategoryData3 = (val, name) => {
        if (val) {

            let data = { main_category_id: val };
            let path = API_Path.getCategoryRelative;
            const getCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ categoryData3: res.data.data });
                }
            });
        } else {

            let data = {};

            let path = API_Path.getCategory;
            const getCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ categoryData3: res.data.data });
                }
            });
        }
    };
    getSubCategoryData = (val, name) => {
        // console.log(val);
        if (val) {

            let data = { category_id: val };

            let path = API_Path.getSubCategoryRelative;
            const getSubCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getSubCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ subCategoryData: res.data.data });
                }
            });
        } else {

            let data = {};
            let path = API_Path.getSubCategory;
            const getSubCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getSubCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ subCategoryData: res.data.data });
                }
            });
        }
    };
    getSubCategoryData2 = (val, name) => {
        // console.log(val);
        if (val) {

            let data = { category_id: val };

            let path = API_Path.getSubCategoryRelative;
            const getSubCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getSubCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ subCategoryData2: res.data.data });
                }
            });
        } else {

            let data = {};
            let path = API_Path.getSubCategory;
            const getSubCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getSubCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ subCategoryData2: res.data.data });
                }
            });
        }
    };
    getSubCategoryData3 = (val, name) => {
        // console.log(val);
        if (val) {

            let data = { category_id: val };

            let path = API_Path.getSubCategoryRelative;
            const getSubCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getSubCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ subCategoryData3: res.data.data });
                }
            });
        } else {

            let data = {};
            let path = API_Path.getSubCategory;
            const getSubCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getSubCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ subCategoryData3: res.data.data });
                }
            });
        }
    };
    handleImageChange = (e, name) => {
        console.log('e :: ', e, ' name :: ', name);
        let fileName = e.target.name
        let file = e.target.files
        const image = new Image();
        let fr = new FileReader();

        fr.onload = function () {
            if (fr !== null && typeof fr.result == "string") {
                image.src = fr.result;
            }
        };
        fr.readAsDataURL(e.target.files[0]);
        if (name === 'square') {
            image.onload = async () => {
                const width = image.width;
                console.log('width is :: ', width, image.height);
                // if (image.width > 335 && image.width < 345 && image.height > 335 && image.height < 345) {
                this.setState({ isLoading: true }, () => {
                    this.addImageToStorage(file, fileName)
                })
                // } else {
                //     toastr.error('You can upload image of max size of 5mb. Image will be cropped to 340*340px.')
                // }

            };
        } else if (name === 'rectangle') {
            image.onload = async () => {
                const width = image.width;
                console.log('width is :: ', width, image.height);
                // if (image.width > 695 && image.width < 705 && image.height > 335 && image.height < 345) {
                this.setState({ isLoading: true }, () => {
                    this.addImageToStorage(file, fileName)
                })
                // } else {
                //     toastr.error('You can upload image of max size of 5mb. Image will be cropped to 700*340.')
                // }

            };
        }
    }

    handleChange1 = (e) => {
        this.setState({ [e.target.name]: e.target.value }, () => {
            if (this.state.category == '') {
                this.setState({ subCategory: '' })
            }
        })
    }

    handleChange2 = (e) => {
        this.setState({ [e.target.name]: e.target.value }, () => {
            if (this.state.category2 == '') {
                this.setState({ subCategory2: '' })
            }
        })
    }

    handleChange3 = (e) => {
        this.setState({ [e.target.name]: e.target.value }, () => {
            if (this.state.category3 == '') {
                this.setState({ subCategory3: '' })
            }
        })
    }

    handleCheckbox1 = (e) => {
        // if (e.target.checked) {
        //     document.getElementById('ActiveUrl2').classList.add('active')
        //     document.getElementById('ActiveUrl1').classList.remove('active')
        // } else {
        //     document.getElementById('ActiveUrl1').classList.add('active')
        //     document.getElementById('ActiveUrl2').classList.remove('active')
        // }
        // this.setState({ bannerUrl1: "" }, () => {
        //     this.setState({ SelectUrlType1: e.target.checked })
        // })
    }

    handleCheckbox2 = (e) => {
        // if (e.target.checked) {
        //     document.getElementById('ActiveUrl4').classList.add('active')
        //     document.getElementById('ActiveUrl3').classList.remove('active')
        // } else {
        //     document.getElementById('ActiveUrl3').classList.add('active')
        //     document.getElementById('ActiveUrl4').classList.remove('active')
        // }
        // this.setState({ bannerUrl2: "" }, () => {
        //     this.setState({ SelectUrlType2: e.target.checked })
        // })
    }

    handleCheckbox3 = (e) => {
        // if (e.target.checked) {
        //     document.getElementById('ActiveUrl6').classList.add('active')
        //     document.getElementById('ActiveUrl5').classList.remove('active')
        // } else {
        //     document.getElementById('ActiveUrl5').classList.add('active')
        //     document.getElementById('ActiveUrl6').classList.remove('active')
        // }
        // this.setState({ bannerUrl3: "" }, () => {
        //     this.setState({ SelectUrlType3: e.target.checked })
        // })
    }


    addImageToStorage = async (files, name) => {


        console.log('files is :: ', files);

        let imgArr = await ImageCompress(files)
        var formData = new FormData;
        for (var i = 0; i < imgArr.length; i++) {
            formData.append('file', imgArr[i]);
        }
        console.log('form data ;: ', formData);
        let path = API_Path.addFileInS3
        const addFilePromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, formData));
        });

        addFilePromise.then((res) => {
            if (res) {
                console.log('res is :: ', res);
                this.setState({ [name]: res.data.data[0], isLoading: false }, () => {
                    if (this.state.banner1English !== '') {
                        document.getElementById('banner1EnglishPreview5').classList.add('imageUpload')
                    } else {
                        document.getElementById('banner1EnglishPreview5').classList.remove('imageUpload')
                    }
                    if (this.state.banner1Arabic !== '') {
                        document.getElementById('banner1ArabicPreview5').classList.add('imageUpload')
                    } else {
                        document.getElementById('banner1ArabicPreview5').classList.remove('imageUpload')
                    }
                    if (this.state.banner2English !== '') {
                        document.getElementById('banner2EnglishPreview5').classList.add('imageUpload')
                    } else {
                        document.getElementById('banner2EnglishPreview5').classList.remove('imageUpload')
                    }
                    if (this.state.banner2Arabic !== '') {
                        document.getElementById('banner2ArabicPreview5').classList.add('imageUpload')
                    } else {
                        document.getElementById('banner2ArabicPreview5').classList.remove('imageUpload')
                    }
                    if (this.state.banner3English !== '') {
                        document.getElementById('banner3EnglishPreview5').classList.add('imageUpload')
                    } else {
                        document.getElementById('banner3EnglishPreview5').classList.remove('imageUpload')
                    }
                    if (this.state.banner3Arabic !== '') {
                        document.getElementById('banner3ArabicPreview5').classList.add('imageUpload')
                    } else {
                        document.getElementById('banner3ArabicPreview5').classList.remove('imageUpload')
                    }
                })
            }
        });
    }


    handleSubmit = () => {
        let search1 = this.state.SearchParams1
        let search2 = this.state.SearchParams2
        let search3 = this.state.SearchParams3
        let prductId1
        let prductId2
        let prductId3
        let allcategories1
        let allcategories2
        let allcategories3
        if (this.state.bannerUrl1.includes('search=')) {
            // search1 = 'SALE'
        } else if (!this.state.bannerUrl1.includes('allcategories=')) {
            prductId1 = this.state.bannerUrl1.substr(this.state.bannerUrl1.lastIndexOf("-") + 1);
        } else {
            console.log(this.state.bannerUrl1, "this.state.bannerUrl1");
            let params = this.state.bannerUrl1.split('?')[1]
            const url = new URLSearchParams(params);
            allcategories1 = url.get('allcategories').split('--');
        }
        if (this.state.bannerUrl2.includes('search=')) {
            // search2 = 'SALE'
        } else if (!this.state.bannerUrl2.includes('allcategories=')) {
            prductId2 = this.state.bannerUrl2.substr(this.state.bannerUrl2.lastIndexOf("-") + 1);
        } else {
            let params = this.state.bannerUrl2.split('?')[1]
            const url = new URLSearchParams(params);
            allcategories2 = url.get('allcategories').split('--');
        }
        if (this.state.bannerUrl3.includes('search=')) {
            // search3 = 'SALE'
        } else if (!this.state.bannerUrl3.includes('allcategories=')) {
            prductId3 = this.state.bannerUrl3.substr(this.state.bannerUrl3.lastIndexOf("-") + 1);
        } else {
            let params = this.state.bannerUrl3.split('?')[1]
            const url = new URLSearchParams(params);
            allcategories3 = url.get('allcategories').split('--');
        }
        let filters = {}
        let filters2 = {}
        let filters3 = {}
        let banner_url1 = this.state.bannerUrl1.split('?')[1]
        const query1 = new URLSearchParams(banner_url1);
        let banner_url2 = this.state.bannerUrl2.split('?')[1]
        const query2 = new URLSearchParams(banner_url2);
        let banner_url3 = this.state.bannerUrl3.split('?')[1]
        const query3 = new URLSearchParams(banner_url3);
        // ==============================make sure that below-params must same as mention in website (next.js) in filter page=========================================
        filters.size = Array.from(query1.getAll('SIZE'), (value) => parseInt(value.split('--')[1]))
        filters.colors = Array.from(query1.getAll('COLORS'), (value) => parseInt(value.split('--')[1]))
        filters.prices = Array.from(query1.getAll('PRICES'), (value) => parseInt(value.split('--')[1]))
        filters.discounts = Array.from(query1.getAll('DISCOUNTS'), (value) => parseInt(value.split('--')[1]))
        filters.occassion = Array.from(query1.getAll('OCCASSION'), (value) => parseInt(value.split('--')[1]))
        filters.neckline = Array.from(query1.getAll('NECKLINE'), (value) => parseInt(value.split('--')[1]))
        filters.sleeve = Array.from(query1.getAll('SLEEVE'), (value) => parseInt(value.split('--')[1]))
        filters.design = Array.from(query1.getAll('DESIGN'), (value) => parseInt(value.split('--')[1]))
        filters.waist = Array.from(query1.getAll('WAIST'), (value) => parseInt(value.split('--')[1]))
        filters.length = Array.from(query1.getAll('LENGTH'), (value) => parseInt(value.split('--')[1]))
        filters.fit = Array.from(query1.getAll('FIT'), (value) => parseInt(value.split('--')[1]))
        // ==============================make sure that below-params must same as mention in website (next.js) in filter page=========================================
        filters2.size = Array.from(query2.getAll('SIZE'), (value) => parseInt(value.split('--')[1]))
        filters2.colors = Array.from(query2.getAll('COLORS'), (value) => parseInt(value.split('--')[1]))
        filters2.prices = Array.from(query2.getAll('PRICES'), (value) => parseInt(value.split('--')[1]))
        filters2.discounts = Array.from(query2.getAll('DISCOUNTS'), (value) => parseInt(value.split('--')[1]))
        filters2.occassion = Array.from(query2.getAll('OCCASSION'), (value) => parseInt(value.split('--')[1]))
        filters2.neckline = Array.from(query2.getAll('NECKLINE'), (value) => parseInt(value.split('--')[1]))
        filters2.sleeve = Array.from(query2.getAll('SLEEVE'), (value) => parseInt(value.split('--')[1]))
        filters2.design = Array.from(query2.getAll('DESIGN'), (value) => parseInt(value.split('--')[1]))
        filters2.waist = Array.from(query2.getAll('WAIST'), (value) => parseInt(value.split('--')[1]))
        filters2.length = Array.from(query2.getAll('LENGTH'), (value) => parseInt(value.split('--')[1]))
        filters2.fit = Array.from(query2.getAll('FIT'), (value) => parseInt(value.split('--')[1]))
        // ==============================make sure that below-params must same as mention in website (next.js) in filter page=========================================
        filters3.size = Array.from(query3.getAll('SIZE'), (value) => parseInt(value.split('--')[1]))
        filters3.colors = Array.from(query3.getAll('COLORS'), (value) => parseInt(value.split('--')[1]))
        filters3.prices = Array.from(query3.getAll('PRICES'), (value) => parseInt(value.split('--')[1]))
        filters3.discounts = Array.from(query3.getAll('DISCOUNTS'), (value) => parseInt(value.split('--')[1]))
        filters3.occassion = Array.from(query3.getAll('OCCASSION'), (value) => parseInt(value.split('--')[1]))
        filters3.neckline = Array.from(query3.getAll('NECKLINE'), (value) => parseInt(value.split('--')[1]))
        filters3.sleeve = Array.from(query3.getAll('SLEEVE'), (value) => parseInt(value.split('--')[1]))
        filters3.design = Array.from(query3.getAll('DESIGN'), (value) => parseInt(value.split('--')[1]))
        filters3.waist = Array.from(query3.getAll('WAIST'), (value) => parseInt(value.split('--')[1]))
        filters3.length = Array.from(query3.getAll('LENGTH'), (value) => parseInt(value.split('--')[1]))
        filters3.fit = Array.from(query3.getAll('FIT'), (value) => parseInt(value.split('--')[1]))
        if (this.state.bannerUrl1 === '') {
            toastr.error('Please add link for redirection of banner 1')
        } else if (this.state.bannerUrl2 === '') {
            toastr.error('Please add link for redirection of banner 2')
        } else if (this.state.bannerUrl3 === '') {
            toastr.error('Please add link for redirection of banner 3')
        } else {
            let data = {
                banner_1_english: this.state.banner1English,
                banner_1_arabic: this.state.banner1Arabic,
                banner_2_english: this.state.banner2English,
                banner_2_arabic: this.state.banner2Arabic,
                banner_3_english: this.state.banner3English,
                banner_3_arabic: this.state.banner3Arabic,
                banner_url_1: this.state.bannerUrl1,
                banner_url_2: this.state.bannerUrl2,
                banner_url_3: this.state.bannerUrl3,
                banner_id: this.props.data.banner_id,
                status: '1',
                category: this.state.category,
                category_2: this.state.category2,
                category_3: this.state.category3,
                sub_category_name: allcategories1 ? allcategories1[2] : '',
                sub_category_name_2: allcategories2 ? allcategories2[2] : '',
                sub_category_name_3: allcategories3 ? allcategories3[2] : '',
                sub_category: this.state.subCategory,
                sub_category_2: this.state.subCategory2,
                sub_category_3: this.state.subCategory3,
                main_category: this.state.mainCategory,
                main_category2: this.state.mainCategory2,
                main_category3: this.state.mainCategory3,
                search: search1,
                search_2: search2,
                search_3: search3,
                product_id: prductId1,
                product_id_2: prductId2,
                product_id_3: prductId3,
                filter: JSON.stringify(filters),
                filter_type: query1.get('sort-type'),
                filter2: JSON.stringify(filters2),
                filter_type2: query2.get('sort-type'),
                filter3: JSON.stringify(filters3),
                filter_type3: query3.get('sort-type'),
            }
            this.props.submitEditPosition5(data)
            this.setState({
                banner1English: '',
                banner1Arabic: '',
                banner2English: '',
                banner2Arabic: '',
                banner3English: '',
                banner3Arabic: '',
                bannerUrl1: '',
                bannerUrl2: '',
                bannerUrl3: '',
            })

        }
    }

    isSaleItem1 = (e) => {
        if (e.target.checked) {
            this.setState({ category: '', subCategory: '', SearchParams1: 'SALE' })
        } else {
            this.setState({ SearchParams1: null })
        }
        this.setState({ isSaleItem1: e.target.checked })
    }
    isSaleItem2 = (e) => {
        if (e.target.checked) {
            this.setState({ category2: '', subCategory2: '', SearchParams2: 'SALE' })
        } else {
            this.setState({ SearchParams2: null })
        }
        this.setState({ isSaleItem2: e.target.checked })
    }
    isSaleItem3 = (e) => {
        if (e.target.checked) {
            this.setState({ category3: '', subCategory3: '', SearchParams3: 'SALE' })
        } else {
            this.setState({ SearchParams3: null })
        }
        this.setState({ isSaleItem3: e.target.checked })
    }

    render() {
        let ButtonLanguage = this.context.language === "english" ? buttonEnglish : buttonArabic;
        let productLanguage = this.context.language === "english" ? productEnglish : productArabic;;

        return (<React.Fragment>
            {this.state.isLoading && (
                <div className="loader-main">
                    <div className="loader-inr">
                        <img src={loader} alt="" />
                    </div>
                </div>
            )}
            <Modal
                dialogClassName="modal-dialog-centered"
                className="edit-user-modal cust-modal"
                size="xl"
                ref={(el) => {
                    this.dialog = el
                }}
                show={this.props.show}
                onHide={this.props.closeEditPosition5}
            >
                <Modal.Header>
                    <Modal.Title>
                        <h1 className="modal-title">{ButtonLanguage.edit}</h1>
                    </Modal.Title>
                    <button
                        type="button"
                        onClick={this.props.closeEditPosition5}
                        className="close btn-close"
                    ></button>
                </Modal.Header>
                <Modal.Body>
                    <div className="row">
                        <div className="col-md-12 avtar-txt m-0">
                            <p>Banner-1</p>
                        </div>
                        <div className="col-md-6">
                            <div className="img-upload py-3">
                                <div className="avatar-preview">
                                    <div id="imagePreview">
                                        <div className="banner-main-box-ad">
                                            <div>
                                                <img className='imageUpload' id='banner1EnglishPreview5' src={this.state.banner1English === '' ? imgplaceholder : this.state.banner1English} alt="" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="avtar-txt">
                                    <p>{ButtonLanguage.UploadyourbannerEnglishdesktop}</p>
                                    <span>{ButtonLanguage.uploadimagemaxsize} 340*340px.</span>
                                    <div className="avatar-edit">
                                        <input className="d-none" type="file" id="imageUpload1" name='banner1English' onChange={(e) => this.handleImageChange(e, 'square')} accept=".png, .jpg, .jpeg" />
                                        <label className="btn red-btn mt-3" htmlFor="imageUpload1">
                                            <i className="bi bi-upload me-2" />
                                            {ButtonLanguage.Uploadimage}
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <div className="img-upload py-3">
                                <div className="avatar-preview">
                                    <div id="imagePreview">
                                        <div className="banner-main-box-ad">
                                            <div>
                                                <img className='imageUpload' id='banner1ArabicPreview5' src={this.state.banner1Arabic === '' ? imgplaceholder : this.state.banner1Arabic} alt="" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="avtar-txt">
                                    <p>{ButtonLanguage.UploadyourbannerArabicdesktop}</p>
                                    <span>{ButtonLanguage.uploadimagemaxsize} 340*340px.</span>
                                    <div className="avatar-edit">
                                        <input className="d-none" type="file" id="imageUpload2" name='banner1Arabic' onChange={(e) => this.handleImageChange(e, 'square')} accept=".png, .jpg, .jpeg" />
                                        <label className="btn red-btn mt-3" htmlFor="imageUpload2">
                                            <i className="bi bi-upload me-2" />
                                            {ButtonLanguage.Uploadimage}
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-12 mb-3 ">
                            <div className='edit-banner-cust form-group d-flex align-items-center'>
                                <span id='ActiveUrl1' className='active'>{ButtonLanguage.ProductListing}</span>
                                <label class="switch mx-2 mb-0">
                                    <input type="checkbox" onChange={this.handleCheckbox1} />
                                    <div class="slider round"></div>
                                </label>
                                <span id='ActiveUrl2'>{ButtonLanguage.ProductPage}</span>
                            </div>
                        </div>


                        <div className="col-md-12 form-group">
                            <label>{!this.state.SelectUrlType ? ButtonLanguage.ProductListing + " URL" : ButtonLanguage.ProductPage + " URL"}</label>
                            <input type="url" name='bannerUrl1' value={this.state.bannerUrl1} onChange={this.handleChange1} className="form-control input-custom-class" />
                        </div>
                        <div className="col-md-12 cust-checkbox-new mb-3">
                            <label className="cust-chk-bx">
                                <input type="checkbox" onChange={this.isSaleItem1} />
                                <span className="cust-chkmark" />
                                For Sale Item
                            </label>
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.mainCategory}</label>
                            <select name="mainCategory" value={this.state.mainCategory} onChange={this.handleChange1} onChangeCapture={this.handleChangecapture} className="form-select input-custom-class" >
                                <option>{productLanguage.chooseMainCategory} </option>
                                {this.state.maincategoryData &&
                                    this.state.maincategoryData.length > 0 &&
                                    this.state.maincategoryData.map((item, i) => {
                                        // console.log(item, "itemm");
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.category}</label>
                            <select name="category" value={this.state.category} onChange={this.handleChange1} onChangeCapture={this.handleChangecapture} className="form-select input-custom-class" disabled={this.state.isSaleItem1}>
                                <option value={''}>{productLanguage.SelectCategory} </option>
                                {this.state.categoryData &&
                                    this.state.categoryData.length > 0 &&
                                    this.state.categoryData.map((item, i) => {
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                            {this.state.errorCatogory && <div className="input-feedback text-danger">{'Required'}</div>}
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.subCategory}</label>
                            <select name="subCategory" value={this.state.subCategory} onChange={this.handleChange1} onChangeCapture={this.handleChangecapture} className="form-select input-custom-class" disabled={this.state.isSaleItem1}>
                                <option>{productLanguage.SelectSubCategory}</option>
                                {this.state.subCategoryData &&
                                    this.state.subCategoryData.length > 0 &&
                                    this.state.subCategoryData.map((item, i) => {
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                            {this.state.errorSubCatogory && <div className="input-feedback text-danger">{'Required'}</div>}
                        </div>
                        <div className="col-md-12 avtar-txt m-0 border-top pt-2">
                            <p>Banner-2</p>
                        </div>
                        <div className="col-md-6">
                            <div className="img-upload py-3">
                                <div className="avatar-preview">
                                    <div id="imagePreview">
                                        <div className="banner-main-box-ad">
                                            <div>
                                                <img className='imageUpload' id='banner2EnglishPreview5' src={this.state.banner2English === '' ? imgplaceholder : this.state.banner2English} alt="" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="avtar-txt">
                                    <p>{ButtonLanguage.UploadyourbannerEnglishdesktop}</p>
                                    <span>{ButtonLanguage.uploadimagemaxsize} 700*340px.</span>
                                    <div className="avatar-edit">
                                        <input className="d-none" type="file" id="imageUpload3" name='banner2English' onChange={(e) => this.handleImageChange(e, 'rectangle')} accept=".png, .jpg, .jpeg" />
                                        <label className="btn red-btn mt-3" htmlFor="imageUpload3">
                                            <i className="bi bi-upload me-2" />
                                            {ButtonLanguage.Uploadimage}
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <div className="img-upload py-3">
                                <div className="avatar-preview">
                                    <div id="imagePreview">
                                        <div className="banner-main-box-ad">
                                            <div>
                                                <img className='imageUpload' id='banner2ArabicPreview5' src={this.state.banner2Arabic === '' ? imgplaceholder : this.state.banner2Arabic} alt="" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="avtar-txt">
                                    <p>{ButtonLanguage.UploadyourbannerArabicdesktop}</p>
                                    <span>{ButtonLanguage.uploadimagemaxsize} 700*340px.</span>
                                    <div className="avatar-edit">
                                        <input className="d-none" type="file" id="imageUpload4" name='banner2Arabic' onChange={(e) => this.handleImageChange(e, 'rectangle')} accept=".png, .jpg, .jpeg" />
                                        <label className="btn red-btn mt-3" htmlFor="imageUpload4">
                                            <i className="bi bi-upload me-2" />
                                            {ButtonLanguage.Uploadimage}
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-12 mb-3 ">
                            <div className='edit-banner-cust form-group d-flex align-items-center'>
                                <span id='ActiveUrl1' className='active'>{ButtonLanguage.ProductListing}</span>
                                <label class="switch mx-2 mb-0">
                                    <input type="checkbox" onChange={this.handleCheckbox2} />
                                    <div class="slider round"></div>
                                </label>
                                <span id='ActiveUrl2'>{ButtonLanguage.ProductPage}</span>
                            </div>
                        </div>


                        <div className="col-md-12 form-group">
                            <label>{!this.state.SelectUrlType ? ButtonLanguage.ProductListing + " URL" : ButtonLanguage.ProductPage + " URL"}</label>
                            <input type="url" name='bannerUrl2' value={this.state.bannerUrl2} onChange={this.handleChange2} className="form-control input-custom-class" />
                        </div>
                        <div className="col-md-12 cust-checkbox-new mb-3">
                            <label className="cust-chk-bx">
                                <input type="checkbox" onChange={this.isSaleItem2} />
                                <span className="cust-chkmark" />
                                For Sale Item
                            </label>
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.mainCategory}</label>
                            <select name="mainCategory2" value={this.state.mainCategory2} onChange={this.handleChange2} onChangeCapture={this.handleChangecapture} className="form-select input-custom-class" >
                                <option>{productLanguage.chooseMainCategory} </option>
                                {this.state.maincategoryData &&
                                    this.state.maincategoryData.length > 0 &&
                                    this.state.maincategoryData.map((item, i) => {
                                        // console.log(item, "itemm");
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.category}</label>
                            <select name="category2" value={this.state.category2} onChange={this.handleChange2} onChangeCapture={this.handleChangecapture} className="form-select input-custom-class" disabled={this.state.isSaleItem2}>
                                <option value={''}>{productLanguage.SelectCategory} </option>
                                {this.state.categoryData2 &&
                                    this.state.categoryData2.length > 0 &&
                                    this.state.categoryData2.map((item, i) => {
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                            {this.state.errorCatogory && <div className="input-feedback text-danger">{'Required'}</div>}
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.subCategory}</label>
                            <select name="subCategory2" value={this.state.subCategory2} onChange={this.handleChange2} onChangeCapture={this.handleChangecapture} className="form-select input-custom-class" disabled={this.state.isSaleItem2}>
                                <option>{productLanguage.SelectSubCategory}</option>
                                {this.state.subCategoryData2 &&
                                    this.state.subCategoryData2.length > 0 &&
                                    this.state.subCategoryData2.map((item, i) => {
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                            {this.state.errorSubCatogory && <div className="input-feedback text-danger">{'Required'}</div>}
                        </div>
                        <div className="col-md-12 avtar-txt m-0 border-top pt-2">
                            <p>Banner-3</p>
                        </div>
                        <div className="col-md-6">
                            <div className="img-upload py-3">
                                <div className="avatar-preview">
                                    <div id="imagePreview">
                                        <div className="banner-main-box-ad">
                                            <div>
                                                <img className='imageUpload' id='banner3EnglishPreview5' src={this.state.banner3English === '' ? imgplaceholder : this.state.banner3English} alt="" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="avtar-txt">
                                    <p>{ButtonLanguage.UploadyourbannerEnglishdesktop}</p>
                                    <span>{ButtonLanguage.uploadimagemaxsize} 340*340px.</span>
                                    <div className="avatar-edit">
                                        <input className="d-none" type="file" id="imageUpload5" name='banner3English' onChange={(e) => this.handleImageChange(e, 'square')} accept=".png, .jpg, .jpeg" />
                                        <label className="btn red-btn mt-3" htmlFor="imageUpload5">
                                            <i className="bi bi-upload me-2" />
                                            {ButtonLanguage.Uploadimage}
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <div className="img-upload py-3">
                                <div className="avatar-preview">
                                    <div id="imagePreview">
                                        <div className="banner-main-box-ad">
                                            <div>
                                                <img className='imageUpload' id='banner3ArabicPreview5' src={this.state.banner3Arabic === '' ? imgplaceholder : this.state.banner3Arabic} alt="" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="avtar-txt">
                                    <p>{ButtonLanguage.UploadyourbannerArabicdesktop}</p>
                                    <span>{ButtonLanguage.uploadimagemaxsize} 340*340px.</span>
                                    <div className="avatar-edit">
                                        <input className="d-none" type="file" id="imageUpload6" name='banner3Arabic' onChange={(e) => this.handleImageChange(e, 'square')} accept=".png, .jpg, .jpeg" />
                                        <label className="btn red-btn mt-3" htmlFor="imageUpload6">
                                            <i className="bi bi-upload me-2" />
                                            {ButtonLanguage.Uploadimage}
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-12 mb-3 ">
                            <div className='edit-banner-cust form-group d-flex align-items-center'>
                                <span id='ActiveUrl1' className='active'>{ButtonLanguage.ProductListing}</span>
                                <label class="switch mx-2 mb-0">
                                    <input type="checkbox" onChange={this.handleCheckbox3} />
                                    <div class="slider round"></div>
                                </label>
                                <span id='ActiveUrl2'>{ButtonLanguage.ProductPage}</span>
                            </div>
                        </div>


                        <div className="col-md-12 form-group">
                            <label>{!this.state.SelectUrlType ? ButtonLanguage.ProductListing + " URL" : ButtonLanguage.ProductPage + " URL"}</label>
                            <input type="url" name='bannerUrl3' value={this.state.bannerUrl3} onChange={this.handleChange3} className="form-control input-custom-class" />
                        </div>
                        <div className="col-md-12 cust-checkbox-new mb-3">
                            <label className="cust-chk-bx">
                                <input type="checkbox" onChange={this.isSaleItem3} />
                                <span className="cust-chkmark" />
                                For Sale Item
                            </label>
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.mainCategory}</label>
                            <select name="mainCategory3" value={this.state.mainCategory3} onChange={this.handleChange3} onChangeCapture={this.handleChangecapture} className="form-select input-custom-class" >
                                <option>{productLanguage.chooseMainCategory} </option>
                                {this.state.maincategoryData &&
                                    this.state.maincategoryData.length > 0 &&
                                    this.state.maincategoryData.map((item, i) => {
                                        // console.log(item, "itemm");
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.category}</label>
                            <select name="category3" value={this.state.category3} onChange={this.handleChange3} onChangeCapture={this.handleChangecapture} className="form-select input-custom-class" disabled={this.state.isSaleItem3}>
                                <option value={''}>{productLanguage.SelectCategory} </option>
                                {this.state.categoryData3 &&
                                    this.state.categoryData3.length > 0 &&
                                    this.state.categoryData3.map((item, i) => {
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                            {this.state.errorCatogory && <div className="input-feedback text-danger">{'Required'}</div>}
                        </div>
                        <div className="form-group col-xl-4 col-md-4">
                            <label>{productLanguage.subCategory}</label>
                            <select name="subCategory3" value={this.state.subCategory3} onChange={this.handleChange3} onChangeCapture={this.handleChangecapture} className="form-select input-custom-class" disabled={this.state.isSaleItem3}>
                                <option>{productLanguage.SelectSubCategory}</option>
                                {this.state.subCategoryData3 &&
                                    this.state.subCategoryData3.length > 0 &&
                                    this.state.subCategoryData3.map((item, i) => {
                                        return (
                                            <option value={item.id} key={i}>
                                                {item.english} | {item.arabic}
                                            </option>
                                        );
                                    })}
                            </select>
                            {this.state.errorSubCatogory && <div className="input-feedback text-danger">{'Required'}</div>}
                        </div>
                        <div className="col-md-12 form-group">
                            <button onClick={this.handleSubmit} className="red-btn">{ButtonLanguage.submit}</button>
                        </div>
                    </div>
                </Modal.Body>
            </Modal>
        </React.Fragment>
        )
    }
}
