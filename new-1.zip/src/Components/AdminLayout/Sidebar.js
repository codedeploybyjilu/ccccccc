import React, { Component } from "react";
import { Accordion } from "react-bootstrap";
import { Link, withRouter } from "react-router-dom";
import {
  SidebarArabic,
  SidebarEnglish,
  productArabic,
  productEnglish,
} from "../../const";
import LanguageContext from "../../contexts/languageContext";
import logo from "../../images/logo.svg";
import Arabiclogo from "../../images/arabic-logo.svg";
import { confirmAlert } from "react-confirm-alert";

class Sidebar extends Component {
  static contextType = LanguageContext;

  componentDidMount() {
    // console.log('language :: ', this.context.language);
  }

  handleLogout = () => {
    localStorage.removeItem("_a_token");
    this.props.history.push("/");
    // window.location.href = "/";
  };

  logout_conferm = () => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>
              {this.context.language === "english"
                ? SidebarEnglish.AreYouSure
                : SidebarArabic.AreYouSure}
            </h1>
            <p>
              {" "}
              {this.context.language === "english"
                ? SidebarEnglish.DoYouWantToLogOutFromThisPage
                : SidebarArabic.DoYouWantToLogOutFromThisPage}
            </p>
            <button className="btn red-btn me-2" onClick={onClose}>
              {this.context.language === "english"
                ? SidebarEnglish.NO
                : SidebarArabic.NO}
            </button>
            <button
              className="btn red-btn"
              onClick={() => {
                // this.finaly_delete_record(id);
                onClose();
                this.handleLogout();
              }}
            >
              {this.context.language === "english"
                ? SidebarEnglish.Yes
                : SidebarArabic.Yes}
            </button>
          </div>
        );
      },
    });
  };

  render() {
    let Language =
      this.context.language === "english" ? SidebarEnglish : SidebarArabic;
    let productLanguage =
      this.context.language === "english" ? productEnglish : productArabic;
    return (
      <React.Fragment>
        <div className="sidebar-main-section">
          <div className="brand-title">
            <Link to="dashboard">
              {this.context.language === "english" ? (
                <img src={logo} alt="" />
              ) : (
                <img src={Arabiclogo} alt="" />
              )}
            </Link>
          </div>
          <div className="sidebar-main-section-inner">
            <ul className="sidebar-main-inner-menu">
              <li>
                <Link to="/dashboard">
                  <bdi
                    className={
                      this.props.match.path.match("/dashboard") ||
                      this.props.match.path.match("/")?.input === "/"
                        ? "active"
                        : ""
                    }
                  >
                    <svg
                      width={20}
                      height={20}
                      viewBox="0 0 18 22"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <rect
                        x="0.75"
                        y="0.75"
                        width="6.5"
                        height="10.5"
                        rx="1.25"
                        stroke="#2D2D3B"
                        strokeWidth="1.5"
                      />
                      <rect
                        x="0.75"
                        y="14.75"
                        width="6.5"
                        height="6.5"
                        rx="1.25"
                        stroke="#2D2D3B"
                        strokeWidth="1.5"
                      />
                      <rect
                        x="10.75"
                        y="10.75"
                        width="6.5"
                        height="10.5"
                        rx="1.25"
                        stroke="#2D2D3B"
                        strokeWidth="1.5"
                      />
                      <rect
                        x="10.75"
                        y="0.75"
                        width="6.5"
                        height="6.5"
                        rx="1.25"
                        stroke="#2D2D3B"
                        strokeWidth="1.5"
                      />
                    </svg>
                    <span>{Language.dashboard}</span>
                  </bdi>
                </Link>
              </li>
              <li>
                <Link to="/team">
                  <bdi
                    className={
                      this.props.match.path.match("/team") ? "active" : ""
                    }
                  >
                    <svg
                      width={20}
                      height={20}
                      viewBox="0 0 20 20"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M9.99998 20C8.48804 20.0043 6.9952 19.6622 5.63598 19C5.13853 18.758 4.66191 18.4754 4.21098 18.155L4.07398 18.055C2.8338 17.1396 1.81985 15.9522 1.10998 14.584C0.375714 13.1679 -0.00511478 11.5952 -7.26474e-05 10C-7.26474e-05 4.47715 4.47713 0 9.99998 0C15.5228 0 20 4.47715 20 10C20.005 11.5944 19.6245 13.1664 18.891 14.582C18.1821 15.9494 17.1696 17.1364 15.931 18.052C15.4637 18.394 14.9679 18.6951 14.449 18.952L14.369 18.992C13.0089 19.6577 11.5142 20.0026 9.99998 20ZM9.99998 15C8.50145 14.9971 7.12764 15.834 6.44298 17.167C8.68437 18.2772 11.3156 18.2772 13.557 17.167V17.162C12.8715 15.8305 11.4976 14.9954 9.99998 15ZM9.99998 13C12.1661 13.0028 14.1634 14.1701 15.229 16.056L15.244 16.043L15.258 16.031L15.241 16.046L15.231 16.054C17.76 13.8691 18.6643 10.3423 17.4986 7.21011C16.333 4.07788 13.3431 2.00032 10.001 2.00032C6.65889 2.00032 3.66897 4.07788 2.50333 7.21011C1.33769 10.3423 2.24198 13.8691 4.77098 16.054C5.83724 14.169 7.83434 13.0026 9.99998 13ZM9.99998 12C7.79084 12 5.99998 10.2091 5.99998 8C5.99998 5.79086 7.79084 4 9.99998 4C12.2091 4 14 5.79086 14 8C14 9.06087 13.5786 10.0783 12.8284 10.8284C12.0783 11.5786 11.0608 12 9.99998 12ZM9.99998 6C8.89541 6 7.99998 6.89543 7.99998 8C7.99998 9.10457 8.89541 10 9.99998 10C11.1045 10 12 9.10457 12 8C12 6.89543 11.1045 6 9.99998 6Z"
                        fill="#2D2D3B"
                      />
                    </svg>
                    <span>{Language.team}</span>
                  </bdi>
                </Link>
              </li>
              <li>
                <Link to="/users">
                  <bdi
                    className={
                      this.props.match.path.match("/users") ? "active" : ""
                    }
                  >
                    <svg
                      width={20}
                      height={20}
                      viewBox="0 0 20 18"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M7 0C4.23858 0 2 2.23858 2 5C2 7.76142 4.23858 10 7 10C9.76142 10 12 7.76142 12 5C12 2.23858 9.76142 0 7 0ZM4 5C4 3.34315 5.34315 2 7 2C8.65685 2 10 3.34315 10 5C10 6.65685 8.65685 8 7 8C5.34315 8 4 6.65685 4 5Z"
                        fill="#2D2D3B"
                      />
                      <path
                        d="M14.9084 5.21828C14.6271 5.07484 14.3158 5.00006 14 5.00006V3.00006C14.6316 3.00006 15.2542 3.14956 15.8169 3.43645C15.8789 3.46805 15.9399 3.50121 16 3.5359C16.4854 3.81614 16.9072 4.19569 17.2373 4.65055C17.6083 5.16172 17.8529 5.75347 17.9512 6.37737C18.0496 7.00126 17.9987 7.63958 17.8029 8.24005C17.6071 8.84053 17.2719 9.38611 16.8247 9.83213C16.3775 10.2782 15.8311 10.6119 15.2301 10.8062C14.6953 10.979 14.1308 11.037 13.5735 10.9772C13.5046 10.9698 13.4357 10.9606 13.367 10.9496C12.7438 10.8497 12.1531 10.6038 11.6431 10.2319L11.6421 10.2311L12.821 8.61557C13.0761 8.80172 13.3717 8.92477 13.6835 8.97474C13.9953 9.02471 14.3145 9.00014 14.615 8.90302C14.9155 8.80591 15.1887 8.63903 15.4123 8.41602C15.6359 8.19302 15.8035 7.92024 15.9014 7.62001C15.9993 7.31978 16.0247 7.00063 15.9756 6.68869C15.9264 6.37675 15.8041 6.08089 15.6186 5.82531C15.4331 5.56974 15.1898 5.36172 14.9084 5.21828Z"
                        fill="#2D2D3B"
                      />
                      <path
                        d="M17.9981 18C17.9981 17.475 17.8947 16.9551 17.6938 16.47C17.4928 15.9849 17.1983 15.5442 16.8271 15.1729C16.4558 14.8017 16.0151 14.5072 15.53 14.3062C15.0449 14.1053 14.525 14.0019 14 14.0019V12C14.6821 12 15.3584 12.1163 16 12.3431C16.0996 12.3783 16.1983 12.4162 16.2961 12.4567C17.0241 12.7583 17.6855 13.2002 18.2426 13.7574C18.7998 14.3145 19.2417 14.9759 19.5433 15.7039C19.5838 15.8017 19.6217 15.9004 19.6569 16C19.8837 16.6416 20 17.3179 20 18H17.9981Z"
                        fill="#2D2D3B"
                      />
                      <path
                        d="M14 18H12C12 15.2386 9.76142 13 7 13C4.23858 13 2 15.2386 2 18H0C0 14.134 3.13401 11 7 11C10.866 11 14 14.134 14 18Z"
                        fill="#2D2D3B"
                      />
                    </svg>
                    <span>{Language.customer}</span>
                  </bdi>
                </Link>
              </li>
              <li>
                <div className="d-flex flex-column">
                  <Accordion
                    className={
                      this.props.match.path.match("/orders") ||
                      this.props.match.path.match("/order-details") ||
                      this.props.match.path.match("/abandoned-cart")
                        ? "sidebar-menu-collapse show"
                        : "sidebar-menu-collapse"
                    }
                  >
                    <Accordion.Item eventKey="0">
                      <Accordion.Header
                        className={
                          this.props.match.path.match("/order-details")
                            ? "active"
                            : ""
                        }
                      >
                        <bdi
                          onClick={() => {
                            this.props.history.push("/orders");
                          }}
                        >
                          <svg
                            width={20}
                            height={20}
                            viewBox="0 0 21 20"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M14.55 11C15.3 11 15.96 10.59 16.3 9.97L19.88 3.48C20.25 2.82 19.77 2 19.01 2H4.21L3.27 0H0V2H2L5.6 9.59L4.25 12.03C3.52 13.37 4.48 15 6 15H18V13H6L7.1 11H14.55ZM5.16 4H17.31L14.55 9H7.53L5.16 4ZM6 16C4.9 16 4.01 16.9 4.01 18C4.01 19.1 4.9 20 6 20C7.1 20 8 19.1 8 18C8 16.9 7.1 16 6 16ZM16 16C14.9 16 14.01 16.9 14.01 18C14.01 19.1 14.9 20 16 20C17.1 20 18 19.1 18 18C18 16.9 17.1 16 16 16Z"
                              fill="#2D2D3B"
                            />
                          </svg>

                          <span>{Language.orders}</span>
                        </bdi>
                      </Accordion.Header>
                      <Accordion.Body className="p-2">
                        <bdi
                          onClick={() => {
                            this.props.history.push("/orders");
                          }}
                          className={
                            this.props.match.path.match("/orders")
                              ? "active"
                              : ""
                          }
                        >
                          <span>{Language.OrderList}</span>
                        </bdi>
                        <bdi
                          onClick={() => {
                            this.props.history.push("/abandoned-cart");
                          }}
                          className={
                            this.props.match.path.match("/abandoned-cart")
                              ? "active"
                              : ""
                          }
                        >
                          <span>{Language.AbandonedCart}</span>
                        </bdi>
                        <bdi
                          onClick={() => {
                            this.props.history.push("/return-requests");
                          }}
                          className={
                            this.props.match.path.match("/return-requests")
                              ? "active"
                              : ""
                          }
                        >
                          <span>{Language.ReturnRequests}</span>
                        </bdi>
                      </Accordion.Body>
                    </Accordion.Item>
                  </Accordion>
                </div>
              </li>
              <li>
                <bdi
                  onClick={() => {
                    this.props.history.push("/location");
                  }}
                  className={
                    this.props.match.path.match("/location") ? "active" : ""
                  }
                >
                  <svg
                    width={20}
                    height={20}
                    viewBox="0 0 14 19"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M7 19C5.73693 17.9226 4.56619 16.7415 3.5 15.469C1.9 13.558 8.83662e-07 10.712 8.83662e-07 8C-0.00141728 5.16755 1.70425 2.61339 4.32107 1.5294C6.93789 0.445409 9.95007 1.04524 11.952 3.049C13.2685 4.35961 14.0059 6.14239 14 8C14 10.712 12.1 13.558 10.5 15.469C9.43382 16.7415 8.26307 17.9226 7 19ZM7 3C4.23995 3.00331 2.00331 5.23995 2 8C2 9.166 2.527 11.185 5.035 14.186C5.65314 14.9241 6.30902 15.6297 7 16.3C7.69105 15.6305 8.34724 14.9259 8.966 14.189C11.473 11.184 12 9.165 12 8C11.9967 5.23995 9.76006 3.00331 7 3ZM7 11C5.34315 11 4 9.65686 4 8C4 6.34315 5.34315 5 7 5C8.65686 5 10 6.34315 10 8C10 8.79565 9.68393 9.55872 9.12132 10.1213C8.55871 10.6839 7.79565 11 7 11Z"
                      fill="#2D2D3B"
                    />
                  </svg>

                  <span>{Language.ShippingZones}</span>
                </bdi>
              </li>
              <li className="position-relative">
                <div className="d-flex flex-column">
                  <Accordion
                    className={
                      this.props.match.path.match("/inventory") ||
                      this.props.match.path.match("/products") ||
                      this.props.match.path.match("/edit-product") ||
                      this.props.match.path.match("/add-product") ||
                      this.props.match.path.match("/draft") ||
                      this.props.match.path.match("/categories") ||
                      this.props.match.path.match("/productcategory") ||
                      this.props.match.path.match("/add-product") ||
                      this.props.match.path.match("/edit-product") ||
                      this.props.match.path.match("/product-details")
                        ? "sidebar-menu-collapse show"
                        : "sidebar-menu-collapse"
                    }
                  >
                    <Accordion.Item eventKey="0">
                      <Accordion.Header
                        className={
                          this.props.match.path.match("/add-product") ||
                          this.props.match.path.match("/edit-product") ||
                          this.props.match.path.match("/product-details")
                            ? "active"
                            : ""
                        }
                      >
                        <bdi
                          onClick={() => {
                            this.props.history.push("/products");
                          }}
                        >
                          <svg
                            width={20}
                            height={20}
                            viewBox="0 0 17 17"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M14.3889 0.628906H2.86891C2.45572 0.628906 2.08887 0.893291 1.95819 1.28535L0.678187 5.12535C0.645547 5.22321 0.628906 5.32574 0.628906 5.42891V15.0289C0.628906 15.5591 1.05873 15.9889 1.58891 15.9889H15.6689C16.1991 15.9889 16.6289 15.5591 16.6289 15.0289V5.42891C16.6289 5.32574 16.6123 5.22321 16.5796 5.12535L15.2996 1.28535C15.1689 0.893291 14.8021 0.628906 14.3889 0.628906ZM3.56087 2.54891H13.697L14.337 4.46891H2.92081L3.56087 2.54891ZM9.58891 6.38891V8.30891H7.66891V6.38891H9.58891ZM14.7089 14.0689H2.54891V6.38891H5.74891V9.26891C5.74891 9.79908 6.17873 10.2289 6.70891 10.2289H10.5489C11.0791 10.2289 11.5089 9.79908 11.5089 9.26891V6.38891H14.7089V14.0689Z"
                              fill="#2D2D3B"
                              stroke="#2D2D3B"
                              strokeWidth="0.1"
                            />
                          </svg>

                          <span>{Language.products}</span>
                        </bdi>
                      </Accordion.Header>
                      <Accordion.Body className="p-2">
                        <bdi
                          onClick={() => {
                            this.props.history.push("/products");
                          }}
                          className={
                            this.props.match.path.match("/products")
                              ? "active"
                              : ""
                          }
                        >
                          <span>{productLanguage.productList}</span>
                        </bdi>
                        <bdi
                          onClick={() => {
                            this.props.history.push("/categories");
                          }}
                          className={
                            this.props.match.path.match("/categories")
                              ? "active"
                              : ""
                          }
                        >
                          <span>{Language.Categories}</span>
                        </bdi>
                        {/* <bdi onClick={() => {
                          this.props.history.push("/inventory");
                        }} className={this.props.match.path.match("/inventory") ? "active" : ""}>
                          <span>{productLanguage.inventory}</span>
                        </bdi> */}

                        <bdi
                          onClick={() => {
                            this.props.history.push("/draft");
                          }}
                          className={
                            this.props.match.path.match("/draft")
                              ? "active"
                              : ""
                          }
                        >
                          <span>{productLanguage.draft}</span>
                        </bdi>
                        <bdi
                          onClick={() => {
                            this.props.history.push("/productcategory");
                          }}
                          className={
                            this.props.match.path.match("/productcategory")
                              ? "active"
                              : ""
                          }
                        >
                          <span>{productLanguage.attributes}</span>
                        </bdi>
                        <bdi
                          onClick={() => {
                            this.props.history.push("/frame-set");
                          }}
                          className={
                            this.props.match.path.match("/frame-set")
                              ? "active"
                              : ""
                          }
                        >
                          <span>{productLanguage.frameSet}</span>
                        </bdi>
                      </Accordion.Body>
                    </Accordion.Item>
                  </Accordion>
                </div>
              </li>
              <li className="position-relative">
                <div className="d-flex flex-column">
                  <Accordion
                    className={
                      this.props.match.path.match("/inventory") ||
                      this.props.match.path.match("/products") ||
                      this.props.match.path.match("/edit-product") ||
                      this.props.match.path.match("/add-product") ||
                      this.props.match.path.match("/draft") ||
                      this.props.match.path.match("/categories") ||
                      this.props.match.path.match("/productcategory") ||
                      this.props.match.path.match("/add-product") ||
                      this.props.match.path.match("/edit-product") ||
                      this.props.match.path.match("/product-details")
                        ? "sidebar-menu-collapse show"
                        : "sidebar-menu-collapse"
                    }
                  >
                    <Accordion.Item eventKey="0">
                      <Accordion.Header
                        className={
                          this.props.match.path.match("/create-user-segment") ||
                          this.props.match.path.match(
                            "/audience-segment-details"
                          )
                            ? "active"
                            : ""
                        }
                      >
                        <bdi
                          onClick={() => {
                            this.props.history.push("/audience-segment");
                          }}
                        >
                          <svg
                            width={20}
                            height={20}
                            viewBox="0 0 17 17"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M14.3889 0.628906H2.86891C2.45572 0.628906 2.08887 0.893291 1.95819 1.28535L0.678187 5.12535C0.645547 5.22321 0.628906 5.32574 0.628906 5.42891V15.0289C0.628906 15.5591 1.05873 15.9889 1.58891 15.9889H15.6689C16.1991 15.9889 16.6289 15.5591 16.6289 15.0289V5.42891C16.6289 5.32574 16.6123 5.22321 16.5796 5.12535L15.2996 1.28535C15.1689 0.893291 14.8021 0.628906 14.3889 0.628906ZM3.56087 2.54891H13.697L14.337 4.46891H2.92081L3.56087 2.54891ZM9.58891 6.38891V8.30891H7.66891V6.38891H9.58891ZM14.7089 14.0689H2.54891V6.38891H5.74891V9.26891C5.74891 9.79908 6.17873 10.2289 6.70891 10.2289H10.5489C11.0791 10.2289 11.5089 9.79908 11.5089 9.26891V6.38891H14.7089V14.0689Z"
                              fill="#2D2D3B"
                              stroke="#2D2D3B"
                              strokeWidth="0.1"
                            />
                          </svg>

                          <span>{"Marketing"}</span>
                        </bdi>
                      </Accordion.Header>
                      <Accordion.Body className="p-2">
                        <bdi
                          onClick={() => {
                            this.props.history.push("/audience-segment");
                          }}
                          className={
                            this.props.match.path.match("/audience-segment")
                              ? "active"
                              : ""
                          }
                        >
                          <span>{"Audience Segments"}</span>
                        </bdi>
                        <bdi
                          onClick={() => {
                            this.props.history.push("/campaign");
                          }}
                          className={
                            this.props.match.path.match("/campaign")
                              ? "active"
                              : ""
                          }
                        >
                          <span>{"campaign"}</span>
                        </bdi>
                        <bdi
                          onClick={() => {
                            this.props.history.push("/automations");
                          }}
                          className={
                            this.props.match.path.match("/automations")
                              ? "active"
                              : ""
                          }
                        >
                          <span>{"automations"}</span>
                        </bdi>
                      </Accordion.Body>
                    </Accordion.Item>
                  </Accordion>
                </div>
              </li>
              {/* <li className="position-relative">
                <div className="d-flex flex-column">
                  <Accordion
                    className={
                      this.props.match.path.match("/create-user-segment") ||
                        this.props.match.path.match("/audience-segment-details")
                        ? "sidebar-menu-collapse show"
                        : "sidebar-menu-collapse"
                    }
                  >
                    <Accordion.Item eventKey="0">
                      <Accordion.Header className={this.props.match.path.match("/create-user-segment") || this.props.match.path.match("/audience-segment-details") ? "active" : ""}>
                        <bdi
                          onClick={() => {
                            this.props.history.push("/audience-segment");
                          }}
                        >
                          <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M15.9079 0.551344C16.2672 0.671122 16.5281 0.98364 16.5816 1.35861L16.8291 3.09102L18.5615 3.3385C18.9365 3.39207 19.249 3.65289 19.3688 4.01223C19.4886 4.37156 19.3951 4.76773 19.1272 5.03556L15.9452 8.21754C15.6774 8.48537 15.2812 8.5789 14.9219 8.45912L13.3856 7.94701L10.2867 11.0459C9.89617 11.4364 9.26301 11.4364 8.87248 11.0459C8.48196 10.6554 8.48196 10.0222 8.87248 9.63168L11.9722 6.53191L11.461 4.99824C11.3412 4.6389 11.4348 4.24273 11.7026 3.9749L14.8846 0.79292C15.1524 0.525088 15.5486 0.431566 15.9079 0.551344ZM13.9074 6.01276L14.968 6.36631L16.2988 5.03556L15.8038 4.96485C15.3638 4.902 15.0181 4.5563 14.9553 4.11632L14.8846 3.62135L13.5538 4.9521L13.9074 6.01276ZM9.57959 3.50003C5.7136 3.50003 2.57959 6.63403 2.57959 10.5C2.57959 14.366 5.7136 17.5 9.57959 17.5C13.4456 17.5 16.5796 14.366 16.5796 10.5C16.5796 9.94774 17.0273 9.50003 17.5796 9.50003C18.1319 9.50003 18.5796 9.94774 18.5796 10.5C18.5796 15.4706 14.5502 19.5 9.57959 19.5C4.60903 19.5 0.57959 15.4706 0.57959 10.5C0.57959 5.52946 4.60903 1.50003 9.57959 1.50003C10.1319 1.50003 10.5796 1.94774 10.5796 2.50003C10.5796 3.05231 10.1319 3.50003 9.57959 3.50003ZM9.57959 7.50003C7.92274 7.50003 6.57959 8.84317 6.57959 10.5C6.57959 12.1569 7.92274 13.5 9.57959 13.5C11.2364 13.5 12.5796 12.1569 12.5796 10.5C12.5796 9.94774 13.0273 9.50003 13.5796 9.50003C14.1319 9.50003 14.5796 9.94774 14.5796 10.5C14.5796 13.2615 12.341 15.5 9.57959 15.5C6.81817 15.5 4.57959 13.2614 4.57959 10.5C4.57959 7.7386 6.81817 5.50003 9.57959 5.50003C10.1319 5.50003 10.5796 5.94774 10.5796 6.50003C10.5796 7.05231 10.1319 7.50003 9.57959 7.50003Z" fill="#2D2D3B"></path></svg>

                          <span>Marketing</span>
                        </bdi>
                      </Accordion.Header>
                      <Accordion.Body className="p-2">
                        <bdi onClick={() => {
                          this.props.history.push("/audience-segment");
                        }} className={this.props.match.path.match("/audience-segment") ? "active" : ""}>
                          <span>Audience Segments</span>
                        </bdi>
                        <bdi onClick={() => {
                          this.props.history.push("/campaign");
                        }} className={this.props.match.path.match("/campaign") ? "active" : ""}>
                          <span>Campaigns</span>
                        </bdi>
                        <bdi onClick={() => {
                          this.props.history.push("/automations");
                        }} className={this.props.match.path.match("/automations") ? "active" : ""}>
                          <span>Automations</span>
                        </bdi>
                      </Accordion.Body>
                    </Accordion.Item>
                  </Accordion>
                </div>
              </li> */}
              <li>
                <bdi
                  onClick={() => {
                    this.props.history.push("/sizeguideline");
                  }}
                  className={
                    this.props.match.path.match("/sizeguideline")
                      ? "active"
                      : ""
                  }
                >
                  <svg
                    width={20}
                    height={20}
                    viewBox="0 0 22 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M20 0H2C0.9 0 0 0.9 0 2V10C0 11.1 0.9 12 2 12H20C21.1 12 22 11.1 22 10V2C22 0.9 21.1 0 20 0ZM20 10H2V2H4V6H6V2H8V6H10V2H12V6H14V2H16V6H18V2H20V10Z"
                      fill="#2D2D3B"
                    />
                  </svg>

                  <span>{Language.sizeguideline}</span>
                </bdi>
              </li>
              {/* <li>
                <bdi
                  onClick={() => {
                    this.props.history.push("/notification");
                  }}
                  to="notification"
                  className={
                    this.props.match.path.match("/notification") ? "active" : ""
                  }
                >
                  <svg
                    width={20}
                    height={20}
                    viewBox="0 0 18 22"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M8.99998 21.8334C7.80336 21.8334 6.83331 20.8633 6.83331 19.6667H11.1666C11.1666 20.8633 10.1966 21.8334 8.99998 21.8334ZM17.6666 18.5834H0.333313V16.4167L2.49998 15.3334V9.37502C2.49998 5.62452 4.0394 3.19244 6.83331 2.52835V0.166687H11.1666V2.52835C13.9606 3.19135 15.5 5.62235 15.5 9.37502V15.3334L17.6666 16.4167V18.5834ZM8.99998 4.22919C7.67796 4.14382 6.403 4.7354 5.61456 5.80002C4.94024 6.86662 4.60938 8.11443 4.66665 9.37502V16.4167H13.3333V9.37502C13.3905 8.11444 13.0597 6.86665 12.3854 5.80002C11.597 4.7354 10.322 4.14382 8.99998 4.22919Z"
                      fill="#2D2D3B"
                    />
                  </svg>
                  <span>{Language.notification}</span>
                </bdi>
              </li> */}
              {/* <li>
                <bdi
                  onClick={() => {
                    this.props.history.push("/mailing-list");
                  }}
                  className={
                    this.props.match.path.match("/mailing-list") ? "active" : ""
                  }
                >
                  <svg
                    width={20}
                    height={20}
                    viewBox="0 0 20 16"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M18 16H2C0.89543 16 0 15.1046 0 14V1.913C0.0466084 0.842548 0.928533 -0.00101238 2 9.11911e-07H18C19.1046 9.11911e-07 20 0.895432 20 2V14C20 15.1046 19.1046 16 18 16ZM2 3.868V14H18V3.868L10 9.2L2 3.868ZM2.8 2L10 6.8L17.2 2H2.8Z"
                      fill="#2D2D3B"
                    />
                  </svg>
                  <span>{Language.mailingList}</span>
                </bdi>
              </li> */}
              <li>
                <bdi
                  onClick={() => {
                    this.props.history.push("/master");
                  }}
                  className={
                    this.props.match.path.match("/master") ? "active" : ""
                  }
                >
                  <svg
                    width={22}
                    height={24}
                    viewBox="0 0 22 24"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M20.473 12.2263C20.385 12.0462 20.385 11.8395 20.473 11.6594L21.2893 9.98957C21.7438 9.05982 21.3837 7.95166 20.4695 7.46663L18.8277 6.59549C18.6506 6.50153 18.5291 6.33432 18.4945 6.13688L18.1734 4.30615C17.9946 3.28685 17.0517 2.60191 16.0272 2.74686L14.1869 3.00717C13.9883 3.03521 13.7919 2.97135 13.6478 2.83196L12.312 1.53969C11.5681 0.820124 10.4029 0.820081 9.65916 1.53969L8.32329 2.83209C8.17916 2.97152 7.98274 3.03526 7.78415 3.0073L5.94385 2.74698C4.91904 2.60195 3.97652 3.28698 3.79771 4.30628L3.47661 6.13692C3.44195 6.3344 3.32051 6.50158 3.14342 6.59557L1.50158 7.46672C0.587439 7.9517 0.227355 9.05995 0.68182 9.9897L1.49803 11.6595C1.58609 11.8397 1.58609 12.0463 1.49803 12.2264L0.681777 13.8962C0.227313 14.826 0.587396 15.9341 1.50154 16.4191L3.14337 17.2903C3.32051 17.3842 3.44195 17.5515 3.47661 17.7489L3.79771 19.5796C3.96049 20.5075 4.75614 21.1583 5.67058 21.1582C5.76065 21.1582 5.85204 21.1519 5.94389 21.1389L7.78419 20.8786C7.98266 20.8504 8.1792 20.9144 8.32334 21.0538L9.65916 22.346C10.0311 22.7059 10.5082 22.8857 10.9855 22.8857C11.4627 22.8857 11.9401 22.7058 12.3119 22.346L13.6478 21.0538C13.7919 20.9144 13.9884 20.8507 14.1869 20.8786L16.0272 21.1389C17.0522 21.2839 17.9946 20.5989 18.1734 19.5796L18.4945 17.7489C18.5292 17.5515 18.6506 17.3843 18.8277 17.2903L20.4695 16.4191C21.3837 15.9342 21.7438 14.8259 21.2893 13.8962L20.473 12.2263ZM19.8779 15.3041L18.2361 16.1752C17.7126 16.453 17.3536 16.947 17.2512 17.5308L16.9301 19.3615C16.8696 19.7063 16.5508 19.938 16.204 19.889L14.3637 19.6287C13.7768 19.5456 13.1961 19.7344 12.7701 20.1465L11.4343 21.4387C11.1827 21.6821 10.7884 21.6821 10.5368 21.4387L9.20093 20.1464C8.84093 19.7982 8.37031 19.6095 7.879 19.6095C7.78898 19.6095 7.69823 19.6158 7.60736 19.6287L5.76706 19.889C5.42057 19.938 5.10148 19.7063 5.04095 19.3614L4.71981 17.5307C4.61739 16.947 4.25842 16.4529 3.73492 16.1752L2.09309 15.304C1.78378 15.1399 1.66196 14.765 1.81572 14.4504L2.63197 12.7806C2.8922 12.2482 2.8922 11.6375 2.63197 11.1051L1.81572 9.43525C1.66196 9.12069 1.78378 8.74578 2.09309 8.58168L3.73492 7.71054C4.25838 7.43274 4.61739 6.93869 4.71976 6.35496L5.04086 4.52428C5.10139 4.17941 5.42018 3.94773 5.76697 3.99672L7.60727 4.25704C8.19395 4.34009 8.77489 4.15129 9.20085 3.73927L10.5367 2.447C10.7883 2.20361 11.1825 2.20361 11.4342 2.447L12.7701 3.73927C13.196 4.15133 13.7769 4.34009 14.3636 4.25704L16.2039 3.99672C16.5505 3.94769 16.8695 4.17941 16.93 4.52428L17.2511 6.355C17.3535 6.93873 17.7125 7.43282 18.236 7.71054L19.8779 8.58168C20.1872 8.74578 20.309 9.12069 20.1552 9.43525L19.339 11.105C19.0787 11.6374 19.0787 12.2482 19.339 12.7806L20.1552 14.4504C20.309 14.765 20.1872 15.14 19.8779 15.3041Z"
                      fill="#2D2D3B"
                      stroke="#2D2D3B"
                      strokeWidth="0.5"
                    />
                    <path
                      d="M15.5971 7.3313C15.3507 7.08484 14.951 7.08484 14.7045 7.3313L6.374 15.6619C6.12753 15.9083 6.12753 16.308 6.374 16.5544C6.49723 16.6777 6.65877 16.7393 6.82026 16.7393C6.98175 16.7393 7.14332 16.6777 7.26652 16.5544L15.597 8.22391C15.8436 7.9774 15.8436 7.57782 15.5971 7.3313Z"
                      fill="#2D2D3B"
                      stroke="#2D2D3B"
                      strokeWidth="0.5"
                    />
                    <path
                      d="M8.46102 6.26268C7.185 6.26268 6.14685 7.30083 6.14685 8.57685C6.14685 9.85287 7.185 10.891 8.46102 10.891C9.73704 10.891 10.7752 9.85287 10.7752 8.57685C10.7752 7.30083 9.73704 6.26268 8.46102 6.26268ZM8.46102 9.62872C7.88101 9.62872 7.40915 9.15686 7.40915 8.57681C7.40915 7.9968 7.88101 7.52494 8.46102 7.52494C9.04103 7.52494 9.51293 7.9968 9.51293 8.57681C9.51289 9.15686 9.04103 9.62872 8.46102 9.62872Z"
                      fill="#2D2D3B"
                      stroke="#2D2D3B"
                      strokeWidth="0.5"
                    />
                    <path
                      d="M13.51 12.9948C12.2339 12.9948 11.1958 14.0329 11.1958 15.3089C11.1958 16.5849 12.2339 17.6231 13.51 17.6231C14.786 17.6231 15.8241 16.5849 15.8241 15.3089C15.8241 14.0329 14.786 12.9948 13.51 12.9948ZM13.51 16.3608C12.93 16.3608 12.4581 15.8889 12.4581 15.3089C12.4581 14.7289 12.9299 14.2571 13.51 14.2571C14.09 14.2571 14.5618 14.7289 14.5618 15.3089C14.5618 15.8889 14.09 16.3608 13.51 16.3608Z"
                      fill="#2D2D3B"
                      stroke="#2D2D3B"
                      strokeWidth="0.5"
                    />
                  </svg>
                  <span>{Language.master}</span>
                </bdi>
              </li>
              <li>
                <bdi
                  onClick={() => {
                    this.props.history.push("/marketing");
                  }}
                  className={
                    this.props.match.path.match("/marketing") ||
                    this.props.match.path.match("/add-coupon") ||
                    this.props.match.path.match("/edit-coupon") ||
                    this.props.match.path.match("/add-discount")
                      ? "active"
                      : ""
                  }
                >
                  <svg
                    width={20}
                    height={20}
                    viewBox="0 0 21 21"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M14.1913 9.07902C14.8349 10.1263 15.2136 11.3536 15.2136 12.6704C15.2136 16.4658 12.1262 19.5534 8.33024 19.5534C4.53423 19.5534 1.44683 16.4658 1.44683 12.6704C1.44683 8.8748 4.53423 5.7868 8.33024 5.7868C9.64644 5.7868 10.8743 6.16507 11.9213 6.80871L12.9727 5.75706C11.6445 4.8626 10.0478 4.33984 8.33024 4.33984C3.73735 4.33984 0 8.07693 0 12.6704C0 17.2637 3.73735 21.0002 8.33024 21.0002C12.9231 21.0002 16.6604 17.2637 16.6604 12.6704C16.6604 10.9527 16.1376 9.35516 15.2433 8.02776L14.1913 9.07902Z"
                      fill="#2D2D3B"
                    />
                    <path
                      d="M10.6665 8.06315C9.96422 7.70534 9.17163 7.49902 8.33012 7.49902C5.47796 7.49902 3.15869 9.81903 3.15869 12.6712C3.15869 15.5226 5.47796 17.8424 8.33012 17.8424C11.1823 17.8424 13.5023 15.5226 13.5023 12.6712C13.5023 11.8295 13.2959 11.0367 12.9371 10.3334L11.8294 11.4411C11.9663 11.828 12.0555 12.2382 12.0555 12.6711C12.0555 14.7247 10.3838 16.3955 8.33016 16.3955C6.27647 16.3955 4.60556 14.7246 4.60556 12.6711C4.60556 10.6171 6.27647 8.94581 8.33016 8.94581C8.76332 8.94581 9.17309 9.03451 9.55943 9.17084L10.6665 8.06315Z"
                      fill="#2D2D3B"
                    />
                    <path
                      d="M8.78608 10.5675C8.78668 10.5344 8.79453 10.5025 8.79728 10.4697C8.64605 10.4378 8.49063 10.4199 8.33031 10.4199C7.08766 10.4199 6.08008 11.4281 6.08008 12.6707C6.08008 13.9131 7.08761 14.9205 8.33031 14.9205C9.57291 14.9205 10.5805 13.9131 10.5805 12.6707C10.5805 12.51 10.5622 12.3536 10.531 12.2024C10.4979 12.2051 10.466 12.213 10.4336 12.2138L9.27055 13.3769C9.05024 13.5959 8.75853 13.7164 8.44831 13.7164C8.13888 13.7164 7.84639 13.5959 7.62449 13.3752C7.17086 12.9215 7.17086 12.1829 7.62449 11.7283L8.78608 10.5675Z"
                      fill="#2D2D3B"
                    />
                    <path
                      d="M20.9853 3.14992C20.9529 3.05041 20.8667 2.97858 20.7634 2.96304L18.3954 2.6318L18.0372 0.236789C18.0208 0.133199 17.9494 0.0473321 17.8499 0.014161C17.8216 0.00463451 17.792 0 17.7638 0C17.691 0 17.6196 0.0290515 17.5672 0.0816189L15.0154 2.6327C14.9533 2.69454 14.925 2.78251 14.9377 2.86868L15.1864 4.56603L9.75575 9.99686C9.52754 10.225 9.46459 10.5449 9.53956 10.837L8.1356 12.2396C7.96326 12.4125 7.96326 12.6911 8.1356 12.8636C8.22254 12.9497 8.33566 12.9928 8.44796 12.9928C8.56086 12.9928 8.67402 12.9497 8.76014 12.8636L10.1633 11.46C10.241 11.4803 10.32 11.4905 10.3991 11.4905C10.6182 11.4905 10.8358 11.412 11.0026 11.2442L16.4333 5.81387L18.131 6.06289C18.1438 6.06456 18.1579 6.06563 18.1707 6.06563C18.2441 6.06563 18.3147 6.03671 18.367 5.98436L20.9175 3.4322C20.9924 3.35831 21.0192 3.24952 20.9853 3.14992Z"
                      fill="#2D2D3B"
                    />
                  </svg>
                  <span>{Language.marketing}</span>
                </bdi>
              </li>
              {/* <li>
                <bdi
                  onClick={() => {
                    this.props.history.push("/error-log");
                  }}
                  className={
                    this.props.match.path.match("/error-log") ? "active" : ""
                  }
                >
                  <svg
                    width={20}
                    height={20}
                    viewBox="0 0 22 18"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M20.266 17.998H1.73301C1.37575 17.998 1.04563 17.8074 0.867 17.498C0.688374 17.1886 0.688376 16.8074 0.867007 16.498L10.133 0.498C10.3118 0.189111 10.6416 -0.001091 10.9985 -0.001091C11.3554 -0.001091 11.6852 0.189111 11.864 0.498L21.13 16.498C21.3085 16.8072 21.3086 17.1882 21.1303 17.4976C20.9519 17.8069 20.6221 17.9976 20.265 17.998H20.266ZM11 2.998L3.46901 15.998H18.533L11 2.998ZM11.995 11.999H9.99501V6.998H11.995V11.999Z"
                      fill="#2D2D3B"
                    />
                    <path d="M10 13H12V15H10V13Z" fill="#2D2D3B" />
                  </svg>
                  <span>{Language.errorLog}</span>
                </bdi>
              </li>
              <li>
                <bdi
                  onClick={() => {
                    this.props.history.push("/logs");
                  }}
                  className={
                    this.props.match.path.match("/logs") ? "active" : ""
                  }
                >
                  <svg
                    width={20}
                    height={20}
                    viewBox="0 0 21 18"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 0C7.03 0 3 4.03 3 9H0L3.89 12.89L3.96 13.03L8 9H5C5 5.13 8.13 2 12 2C15.87 2 19 5.13 19 9C19 12.87 15.87 16 12 16C10.07 16 8.32 15.21 7.06 13.94L5.64 15.36C7.27 16.99 9.51 18 12 18C16.97 18 21 13.97 21 9C21 4.03 16.97 0 12 0ZM11 5V10L15.25 12.52L16.02 11.24L12.5 9.15V5H11Z"
                      fill="#2D2D3B"
                    />
                  </svg>
                  <span>{Language.logs}</span>
                </bdi>
              </li>
              <li>
                <bdi
                  onClick={() => {
                    this.props.history.push("/device-information");
                  }}
                  className={
                    this.props.match.path.match("/device-information")
                      ? "active"
                      : ""
                  }
                >
                  <svg
                    width={20}
                    height={20}
                    viewBox="0 0 13 22"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M10.5 0H2.5C1.12 0 0 1.12 0 2.5V19.5C0 20.88 1.12 22 2.5 22H10.5C11.88 22 13 20.88 13 19.5V2.5C13 1.12 11.88 0 10.5 0ZM6.5 21C5.67 21 5 20.33 5 19.5C5 18.67 5.67 18 6.5 18C7.33 18 8 18.67 8 19.5C8 20.33 7.33 21 6.5 21ZM11 17H2V3H11V17Z"
                      fill="#2D2D3B"
                    />
                  </svg>
                  <span>{Language.deviceInfo}</span>
                </bdi>
              </li>
              <li>
                <bdi
                  onClick={() => {
                    this.props.history.push("/helpandsupport");
                  }}
                  className={
                    this.props.match.path.match("/helpandsupport")
                      ? "active"
                      : ""
                  }
                >
                  <svg
                    width={20}
                    height={20}
                    viewBox="0 0 20 20"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M10 20C4.47967 19.9939 0.00606237 15.5203 0 10V9.8C0.109931 4.30453 4.63459 -0.072041 10.1307 0.000882959C15.6268 0.0738069 20.0337 4.56889 19.9978 10.0653C19.9619 15.5618 15.4966 19.9989 10 20ZM9.984 18H10C14.4167 17.9956 17.9942 14.4127 17.992 9.99601C17.9898 5.57929 14.4087 2.00001 9.992 2.00001C5.57528 2.00001 1.99421 5.57929 1.992 9.99601C1.98979 14.4127 5.56729 17.9956 9.984 18ZM11 16H9V14H11V16ZM11 13H9C8.9684 11.6977 9.64614 10.4808 10.77 9.822C11.43 9.316 12 8.88 12 8C12 6.89543 11.1046 6 10 6C8.89543 6 8 6.89543 8 8H6V7.91C6.01608 6.48094 6.79333 5.16901 8.03897 4.4684C9.28461 3.76779 10.8094 3.78495 12.039 4.5134C13.2685 5.24186 14.0161 6.57094 14 8C13.9284 9.07902 13.3497 10.0603 12.44 10.645C11.6177 11.1612 11.0847 12.0328 11 13Z"
                      fill="#2D2D3B"
                    />
                  </svg>

                  <span>{Language.helpAndSupport}</span>
                </bdi>
              </li> */}
              <li>
                <bdi
                  onClick={() => {
                    this.props.history.push("/reports");
                  }}
                  className={
                    this.props.match.path.match("/reports") ? "active" : ""
                  }
                >
                  <svg
                    width={20}
                    height={20}
                    viewBox="0 0 16 20"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 17H10.2V11.7H12V17ZM8.4 17H6.6V10H8.4V17ZM4.8 17H3V13.5H4.8V17Z"
                      fill="#323232"
                    />
                    <path
                      d="M14 20H2C0.89543 20 0 19.1046 0 18V2C0 0.89543 0.89543 0 2 0H9C9.0109 0.000472319 9.02167 0.00249256 9.032 0.006C9.04177 0.00901724 9.05182 0.0110277 9.062 0.012C9.15019 0.0176532 9.23726 0.0347982 9.321 0.063L9.349 0.072C9.37167 0.079682 9.39373 0.0890412 9.415 0.1C9.52394 0.148424 9.62321 0.216185 9.708 0.3L15.708 6.3C15.7918 6.38479 15.8596 6.48406 15.908 6.593C15.918 6.615 15.925 6.638 15.933 6.661L15.942 6.687C15.9699 6.77039 15.9864 6.85718 15.991 6.945C15.9926 6.95418 15.9949 6.96322 15.998 6.972C15.9998 6.98122 16.0004 6.99062 16.0001 7V18C16.0001 19.1046 15.1046 20 14 20ZM2 2V18H14V8H9C8.44772 8 8 7.55228 8 7V2H2ZM10 3.414V6H12.586L10 3.414Z"
                      fill="#323232"
                    />
                  </svg>
                  <span>{Language.reports}</span>
                </bdi>
              </li>
              <li>
                <bdi
                  onClick={() => {
                    this.props.history.push("/settings");
                  }}
                  className={
                    this.props.match.path.match("/settings") ? "active" : ""
                  }
                >
                  <svg
                    width="18"
                    height="18"
                    viewBox="0 0 18 18"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M15.1918 9.8165C15.2251 9.54984 15.2501 9.28317 15.2501 8.99984C15.2501 8.7165 15.2251 8.44984 15.1918 8.18317L16.9501 6.80817C17.1084 6.68317 17.1501 6.45817 17.0501 6.27484L15.3834 3.3915C15.3084 3.25817 15.1668 3.18317 15.0168 3.18317C14.9668 3.18317 14.9168 3.1915 14.8751 3.20817L12.8001 4.0415C12.3668 3.70817 11.9001 3.43317 11.3918 3.22484L11.0751 1.0165C11.0501 0.816504 10.8751 0.666504 10.6668 0.666504H7.33344C7.12511 0.666504 6.95011 0.816504 6.92511 1.0165L6.60844 3.22484C6.10011 3.43317 5.63344 3.7165 5.20011 4.0415L3.12511 3.20817C3.07511 3.1915 3.02511 3.18317 2.97511 3.18317C2.83344 3.18317 2.69178 3.25817 2.61678 3.3915L0.95011 6.27484C0.841777 6.45817 0.891777 6.68317 1.05011 6.80817L2.80844 8.18317C2.77511 8.44984 2.75011 8.72484 2.75011 8.99984C2.75011 9.27484 2.77511 9.54984 2.80844 9.8165L1.05011 11.1915C0.891777 11.3165 0.85011 11.5415 0.95011 11.7248L2.61678 14.6082C2.69178 14.7415 2.83344 14.8165 2.98344 14.8165C3.03344 14.8165 3.08344 14.8082 3.12511 14.7915L5.20011 13.9582C5.63344 14.2915 6.10011 14.5665 6.60844 14.7748L6.92511 16.9832C6.95011 17.1832 7.12511 17.3332 7.33344 17.3332H10.6668C10.8751 17.3332 11.0501 17.1832 11.0751 16.9832L11.3918 14.7748C11.9001 14.5665 12.3668 14.2832 12.8001 13.9582L14.8751 14.7915C14.9251 14.8082 14.9751 14.8165 15.0251 14.8165C15.1668 14.8165 15.3084 14.7415 15.3834 14.6082L17.0501 11.7248C17.1501 11.5415 17.1084 11.3165 16.9501 11.1915L15.1918 9.8165ZM13.5418 8.3915C13.5751 8.64984 13.5834 8.82484 13.5834 8.99984C13.5834 9.17484 13.5668 9.35817 13.5418 9.60817L13.4251 10.5498L14.1668 11.1332L15.0668 11.8332L14.4834 12.8415L13.4251 12.4165L12.5584 12.0665L11.8084 12.6332C11.4501 12.8998 11.1084 13.0998 10.7668 13.2415L9.88344 13.5998L9.75011 14.5415L9.58344 15.6665H8.41678L8.25844 14.5415L8.12511 13.5998L7.24178 13.2415C6.88344 13.0915 6.55011 12.8998 6.21678 12.6498L5.45844 12.0665L4.57511 12.4248L3.51678 12.8498L2.93344 11.8415L3.83344 11.1415L4.57511 10.5582L4.45844 9.6165C4.43344 9.35817 4.41678 9.1665 4.41678 8.99984C4.41678 8.83317 4.43344 8.6415 4.45844 8.3915L4.57511 7.44984L3.83344 6.8665L2.93344 6.1665L3.51678 5.15817L4.57511 5.58317L5.44178 5.93317L6.19178 5.3665C6.55011 5.09984 6.89178 4.89984 7.23344 4.75817L8.11678 4.39984L8.25011 3.45817L8.41678 2.33317H9.57511L9.73344 3.45817L9.86678 4.39984L10.7501 4.75817C11.1084 4.90817 11.4418 5.09984 11.7751 5.34984L12.5334 5.93317L13.4168 5.57484L14.4751 5.14984L15.0584 6.15817L14.1668 6.8665L13.4251 7.44984L13.5418 8.3915ZM9.00011 5.6665C7.15844 5.6665 5.66678 7.15817 5.66678 8.99984C5.66678 10.8415 7.15844 12.3332 9.00011 12.3332C10.8418 12.3332 12.3334 10.8415 12.3334 8.99984C12.3334 7.15817 10.8418 5.6665 9.00011 5.6665ZM9.00011 10.6665C8.08344 10.6665 7.33344 9.9165 7.33344 8.99984C7.33344 8.08317 8.08344 7.33317 9.00011 7.33317C9.91678 7.33317 10.6668 8.08317 10.6668 8.99984C10.6668 9.9165 9.91678 10.6665 9.00011 10.6665Z"
                      fill="#18203A"
                    />
                  </svg>
                  <span>{Language.settings}</span>
                </bdi>
              </li>
            </ul>

            <ul className="mt-auto fix-log-div">
              <li>
                <button onClick={this.logout_conferm} className="btn">
                  <svg
                    width={20}
                    height={20}
                    viewBox="0 0 18 18"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M16 18H2C0.89543 18 0 17.1046 0 16V12H2V16H16V2H2V6H0V2C0 0.89543 0.89543 0 2 0H16C17.1046 0 18 0.89543 18 2V16C18 17.1046 17.1046 18 16 18ZM8 13V10H0V8H8V5L13 9L8 13Z"
                      fill="#2D2D3B"
                    />
                  </svg>
                  <span>{Language.logout}</span>
                </button>
              </li>
            </ul>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default withRouter(Sidebar);
