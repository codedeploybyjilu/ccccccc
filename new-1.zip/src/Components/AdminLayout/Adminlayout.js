import React, { Component } from 'react';
import Header from './Header';
import Footer from './Footer';
import Sidebar from './Sidebar';
// import { LanguageStore } from '../../contexts/languageContext';

class Adminlayout extends Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    removeLayer = () => {
        document.getElementById("dash-wrapper").classList.remove("toggled-custom-class")
    }



    render() {
        return (
            <React.Fragment>
                <div id="dash-wrapper" className="dash-wrapper admn-cust-style-new">
                    <main className="content-wrapper-section">
                        {/* <LanguageStore> */}
                        <Header />

                        {/* // logout={this.logout} */}

                        <Sidebar
                        // logout={this.logout}
                        />
                        {this.props.children}
                        <Footer />
                        <div className="overlay toggle-icon-main" onClick={this.removeLayer}></div>
                        {/* </LanguageStore> */}
                    </main>
                </div>
            </React.Fragment>
        );
    }
}

export default Adminlayout;