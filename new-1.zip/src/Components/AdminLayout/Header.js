import React, { Component } from 'react';
import Searchicon from '../../images/search-icon.svg'
import Noticon from '../../images/noti-icn.svg'
import Profile from '../../images/profile.png'
import togglicon from '../../images/toggle-icon.svg'
import logo from '../../images/logo.svg'
import LanguageContext from '../../contexts/languageContext'
import { confirmAlert } from 'react-confirm-alert';
import { Modal, ModalFooter, ModalTitle } from 'react-bootstrap';
import ModalHeader from 'react-bootstrap/esm/ModalHeader';
import { withRouter } from 'react-router-dom';
import { HeaderdArabic, HeaderEnglish, locationEnglish, locationArabic } from "../../const";



class Header extends Component {
    constructor(props) {
        super(props);
        this.state = {
            sign_out_show: false,
        }
    }

    static contextType = LanguageContext;
    profile_menu = () => {
        if (document.getElementById("profile_inner_menu")) {
            document.getElementById("profile_inner_menu").classList.toggle("active");
        }
        document.getElementById("noti_menu").classList.remove("active");
    }
    noti_menu = (e) => {

        if (document.getElementById("noti_menu")) {
            document.getElementById("noti_menu").classList.toggle("active");
        }
        document.getElementById("profile_inner_menu").classList.remove("active");
    }

    respo_submenu = () => {
        if (document.getElementById("respo_menu")) {
            document.getElementById("respo_menu").classList.toggle("active");
        }
        document.getElementById("search_menu_icn").classList.remove("active");
    }

    search_menu = () => {
        if (document.getElementById("search_menu_icn")) {
            document.getElementById("search_menu_icn").classList.toggle("active");
        }
        document.getElementById("respo_menu").classList.remove("active");
    }

    side_bar = () => {
        document.getElementById("dash-wrapper").classList.add("toggled-custom-class");
    }

    // sign_out = () => {
    // confirmAlert({
    //     customUI: ({ onClose }) => {
    //         return (
    //             <div className="custom-ui">
    //                 <h1>Are you sure?</h1>
    //                 <p>You want to signout from this profile?</p>
    //                 <button className="btn red-btn me-2" onClick={onClose}>
    //                     No
    //                 </button>
    //                 <a
    //                     href='/'
    //                     onClick={onClose}
    //                 >
    //                     <button
    //                         className="btn red-btn"
    //                     >
    //                         Yes
    //                     </button>
    //                 </a>
    //             </div>
    //         );
    //     },
    // });
    // }

    sign_out_show = () => {
        this.setState({ sign_out_show: true })
    }

    sign_out_close = () => {
        this.setState({ sign_out_show: false })
    }

    handleSignOut = () => {
        localStorage.removeItem('_a_token')
        this.props.history.push("/")
        // window.location.href = "/"
    }

    render() {
        let AdminRole = this.context.language === "english" ? HeaderEnglish : HeaderdArabic;
        let locationLanguage = this.context.language === "english" ? locationEnglish : locationArabic;
        return (
            <React.Fragment>
                <header className="header-fix-top-cust">
                    <nav className="navbar fixed-top">
                        <ul className="d-flex align-items-center mr-auto align-items-center hdr-top-box">
                            <li className="nav-item">
                                <div className="hdr-top-box-inr">
                                    <div className="toggle-icon-main toggle-icon-main-sec d-xl-none d-block" onClick={this.side_bar}>
                                        <img src={togglicon} alt="" />
                                    </div>
                                    <div className="d-xl-none d-block responsive-view-logo">
                                        <a href="dashboard">
                                            <img src={logo} alt="" />
                                        </a>
                                    </div>
                                    {/* <div className="d-md-none position-relative ms-auto pe-5 rtl-margin-header">
                                        <div className="hdr-top-box-inr-icon" onClick={this.search_menu}>
                                            <img src={Searchicon} alt="" />
                                        </div>
                                    </div> */}
                                    {/* <div className="d-md-block d-none position-relative">
                                        <div className="hdr-top-box-inr-icon">
                                            <img src={Searchicon} alt="" />
                                        </div>
                                        <input type="search" className="form-control" placeholder="Search Anything" />
                                    </div> */}
                                </div>
                            </li>
                            <li className="nav-item" onClick={this.respo_submenu}>
                                <svg xmlns="http://www.w3.org/2000/svg" width={25} height={25} fill="currentColor" className="bi bi-three-dots-vertical d-md-none d-block" viewBox="0 0 16 16">
                                    <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                </svg>
                            </li>
                        </ul>
                        <ul className="d-flex align-items-center align-items-center ml-auto responsive-view-menu" id="respo_menu">
                            <li>
                                <div className="btn red-btn" onClick={() => this.context.onLanguageChange(this.context.language === 'english' ? 'arabic' : 'english')}>
                                    {this.context.language === 'english' ? 'عربي' : 'English'}
                                </div>
                            </li>
                            <li className="nav-item right-nav-link-new notification-custom-main" id="noti_menu" onClick={this.noti_menu}>
                                <a href="javascript:void(0);" className="notification-click" >
                                    <img src={Noticon} alt="" />
                                    <span className="conout-number"></span>
                                </a>
                                <div className="notification-custom">
                                    <div className="notification-scroll">
                                        <ul className="notifcn-row-wrapper">
                                            <li >
                                                <a href="#">
                                                    <div className="snrs-notifcn-title">
                                                        New Message
                                                    </div>
                                                    <div className="snrs-notifcn_item-time">
                                                        2 hrs ago
                                                    </div>
                                                </a>
                                            </li>
                                            <li >
                                                <a href="#">
                                                    <div className="snrs-notifcn-title">
                                                        New order has been received
                                                    </div>
                                                    <div className="snrs-notifcn_item-time">
                                                        3 hrs ago
                                                    </div>
                                                </a>
                                            </li>
                                            <li >
                                                <a href="#">
                                                    <div className="snrs-notifcn-title">
                                                        Application has been reject
                                                    </div>
                                                    <div className="snrs-notifcn_item-time">
                                                        5 hrs ago
                                                    </div>
                                                </a>
                                            </li>
                                            <li >
                                                <a href="#">
                                                    <div className="snrs-notifcn-title">
                                                        Bruce's Party
                                                    </div>
                                                    <div className="snrs-notifcn_item-time">
                                                        5 hrs ago
                                                    </div>
                                                </a>
                                            </li>
                                            <li >
                                                <a href="#">
                                                    <div className="snrs-notifcn-title">
                                                        New Message
                                                    </div>
                                                    <div className="snrs-notifcn_item-time">
                                                        2 hrs ago
                                                    </div>
                                                </a>
                                            </li>
                                        </ul>
                                        <div className="p-3">
                                            <a href="/notification" className="notifcn-btn">view all</a>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li className="profile-inner-menu" id="profile_inner_menu" onClick={this.profile_menu}>
                                <a className="profile-click d-block header-user-profile-inner-cust" >
                                    <div className="pro-sec-cust">
                                        <img src={Profile} alt="" />
                                        <div>
                                            <p>Libsimarkah</p>
                                            <span>{this.context.language === "english" ? 'Admin' : 'مدير'}</span>
                                        </div>
                                        <div>
                                            <i className="bi bi-chevron-down" />
                                        </div>
                                    </div>
                                </a>
                                <div className="profile-inner-cust">
                                    <ul>
                                        <li>
                                            <a href="/profile"><svg xmlns="http://www.w3.org/2000/svg" width={20} height={20} fill="currentColor" className="bi bi-person-circle me-2" viewBox="0 0 16 16">
                                                <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
                                                <path fillRule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z" />
                                            </svg>
                                                {AdminRole.Myprofile}</a>
                                        </li>
                                        <li>
                                            <a className="border-0 cursor-pointer" onClick={() => this.sign_out_show()}>
                                                <svg xmlns="http://www.w3.org/2000/svg" width={20} height={20} fill="currentColor" className="bi bi-box-arrow-right me-2" viewBox="0 0 16 16">
                                                    <path fillRule="evenodd" d="M10 12.5a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v2a.5.5 0 0 0 1 0v-2A1.5 1.5 0 0 0 9.5 2h-8A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-2a.5.5 0 0 0-1 0v2z" />
                                                    <path fillRule="evenodd" d="M15.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 0 0-.708.708L14.293 7.5H5.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z" />
                                                </svg>
                                                {AdminRole.Logout}
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                        <div className="d-md-none">
                            <div className="search-form-wrapper" id="search_menu_icn">
                                <div className="search-bar" >
                                    <input type="text" className="form-control" placeholder={locationLanguage.search} />
                                </div>
                            </div>
                        </div>
                    </nav>
                </header>

                <Modal show={this.state.sign_out_show} className="cust-modal signout-modal" onHide={this.sign_out_close} size="md" centered>
                    <Modal.Body>
                        <div className='text-center p-4'>
                            <h5 className='fw-bold fs-3'>Are you sure?</h5>
                            <p className='fs-6'>You want to signout from this profile?</p>
                            <button className="btn red-btn me-2" onClick={this.sign_out_close}>
                                No
                            </button>
                            {/* <a
                                href='/'
                                onClick={this.handleSignOut}
                            > */}
                            <button
                                className="btn red-btn"
                                onClick={this.handleSignOut}
                            >
                                Yes
                            </button>
                            {/* </a> */}
                        </div>
                    </Modal.Body>
                </Modal>
            </React.Fragment >
        );
    }
}

export default withRouter(Header);