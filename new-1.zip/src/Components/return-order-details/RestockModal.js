import { useContext, useEffect, useState } from "react";
import { Modal } from "react-bootstrap";
import LanguageContext from "../../contexts/languageContext";
import toastr from "toastr";
import { PostApi } from "../../helper/APIService";
import { API_Path, orderArabic, orderEnglish } from "../../const";
import { CircularProgress } from "@material-ui/core";

const RestockModal = ({
  open,
  onClose,
  onSave,
  orderId,
  userId,
  acceptedProducts,
}) => {
  const context = useContext(LanguageContext);

  const [approving, setApproving] = useState(false);
  const [products, setProducts] = useState(acceptedProducts ?? []);

  const isEnglish = context.language === "english";

  useEffect(() => {
    setProducts(acceptedProducts ?? []);
  }, [acceptedProducts]);

  const title = isEnglish
    ? orderEnglish.markAsApproved
    : orderArabic.markAsApproved;

  const onProductSelect = (e, productId) => {
    setProducts((products) =>
      products.map((item) =>
        item.id === productId
          ? { ...item, selected: e.target.checked, restock: false }
          : item
      )
    );
  };

  const onProductRestock = (e, productId) => {
    setProducts((products) =>
      products.map((item) =>
        item.id === productId ? { ...item, restock: e.target.checked } : item
      )
    );
  };

  const onCancel = () => {
    reset();
    onClose();
  };

  const onSubmit = () => {
    const restockProducts = products.filter(({ restock }) => restock);
    const payload = {
      user_id: userId,
      return_order_id: orderId,
      return_orders: restockProducts.map(
        ({
          details: { id: product_id },
          id: order_product_id,
          return_order_id,
          order_id,
        }) => ({
          order_id,
          quantity: 1,
          product_id,
          return_order_id,
          order_product_id,
        })
      ),
    };

    // console.log("restock", payload);

    const path = API_Path.approveDelivery;

    const approveDeliveryPromise = new Promise((resolve) => {
      resolve(PostApi(path, payload));
    });

    setApproving(false);

    approveDeliveryPromise
      .then(({ data }) => {
        setApproving(false);
        if (data.success) {
          toastr.success(data.message);
          reset();
          onSave();
          return;
        }
        toastr.error(data.message);
      })
      .catch((err) => {
        toastr.error("Something went wrong");
        console.log(err);
        this.setState({ activeSpinnerBtn: false });
      });
  };

  const reset = () => {
    setProducts((products) =>
      products.map(({ selected, restock, ...item }) => item)
    );
  };

  return (
    <Modal
      size="lg"
      centered
      show={open}
      onHide={onClose}
      dialogClassName="restock-modal"
    >
      <Modal.Header className="px-0 mx-4">
        <Modal.Title style={{ fontWeight: 600, fontSize: 22 }}>
          {title}
        </Modal.Title>
      </Modal.Header>
      <Modal.Body className="px-0 mx-4">
        <h2 className="subtitle">{"Select items you want to receive"}</h2>

        <div className="custom-table restock-table">
          <div className="table-responsive dataTables_wrapper no-footer">
            <table width={"100%"}>
              <tbody>
                {products.map((item, i) => {
                  const { details } = item;
                  const selected = item.selected;
                  const title = isEnglish ? details.title_en : details.title_ar;
                  const color = isEnglish ? details.color_en : details.color_ar;
                  return (
                    <tr
                      className="order-checked"
                      id={"order-checked-id" + i}
                      key={i}
                    >
                      {/* {orderStatusValue == "1" || orderStatusValue == "2" ? ( */}

                      <td
                        width={50}
                        className="selection-cell position-relative"
                      >
                        <input
                          checked={selected}
                          onChange={(e) => {
                            onProductSelect(e, item.id);
                          }}
                          id={"cancel-checked" + i}
                          className="mx-auto"
                          type="checkbox"
                          name="CancelItem"
                        />
                      </td>

                      <td width={50}>
                        <div className="edit-option imgWidth">
                          <img
                            className="imgWidth border rounded "
                            src={
                              details.image !== null
                                ? details.image?.split(",")[0]
                                : ""
                            }
                            alt=""
                          />
                          <button className="edit-btn-class">
                            <a
                              href={"/edit-product/" + item.product_id}
                              rel="noreferrer"
                              target="_blank"
                            >
                              <i className="bi bi-pencil-fill"></i>
                            </a>
                          </button>
                        </div>
                      </td>
                      <td>
                        <p className="dark-red-txt fw-600 mb-0">{details.id}</p>
                        <p className="mb-0">{title}</p>
                        <p className="mb-0">{color}</p>
                      </td>

                      <td width={100}>
                        <input
                          disabled
                          type="number"
                          name="quantity"
                          value={item.quantity}
                          style={{ maxWidth: 40 }}
                          className="form-control text-center"
                          // onChange={handleChange}
                        />
                      </td>
                      <td>
                        <label className="restock-label">
                          <input
                            type="checkbox"
                            name="restockItem"
                            disabled={!selected}
                            checked={item.restock}
                            onChange={(e) => {
                              onProductRestock(e, item.id);
                            }}
                          />
                          Restock
                        </label>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </Modal.Body>
      <Modal.Footer className="px-0 mx-4">
        <button
          onClick={onCancel}
          disabled={approving}
          className="btn py-2 px-4 red-outlined-btn"
        >
          Cancel
        </button>
        <button
          onClick={onSubmit}
          disabled={approving}
          className="red-btn border-0 py-2 rounded ms-3 d-flex align-center"
        >
          {approving ? (
            // <div class="spinner-border text-light"></div>
            <CircularProgress size={24} color="#fff" />
          ) : (
            "Submit"
            // orderLanguage.CancelItem
          )}
        </button>
      </Modal.Footer>
    </Modal>
  );
};

export default RestockModal;
