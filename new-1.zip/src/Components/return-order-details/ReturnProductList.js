import { useContext } from "react";
import { orderArabic, orderEnglish } from "../../const";
import LanguageContext from "../../contexts/languageContext";

const ReturnProductList = ({
  products,
  onProductSelect,
  onSelectAllClick,
  selectedProducts,
}) => {
  const context = useContext(LanguageContext);
  const isEnglish = context.language === "english";

  let orderLanguage = isEnglish ? orderEnglish : orderArabic;

  const selectable = typeof onProductSelect === "function";

  const isAllSelected = selectable
    ? selectedProducts.length === products.length
    : false;

  return (
    <div className="custom-table">
      <div className="table-responsive dataTables_wrapper no-footer">
        <table>
          <thead>
            {products.length > 0 && (
              <tr>
                {/* {orderStatusValue == "1" || orderStatusValue == "2" ? ( */}
                {selectable && (
                  <th className="selection-cell-header">
                    <input
                      checked={isAllSelected}
                      onChange={onSelectAllClick}
                      id={"return-checked-all"}
                      className="mx-auto"
                      type="checkbox"
                      name="CancelItem"
                    />
                  </th>
                )}
                {/* ) : (
                  ""
                )} */}
                <th>{orderLanguage.Items}</th>
                <th>{orderLanguage.Details}</th>
                <th>{orderLanguage.Reason}</th>
                <th>{orderLanguage.Size}</th>
                <th>{orderLanguage.Price}</th>
                <th>{orderLanguage.Qty}</th>
                <th>{orderLanguage.Total}</th>
              </tr>
            )}
          </thead>
          <tbody>
            {products.length > 0 &&
              products.map((item, i) => {
                const { details } = item;
                const selected = selectable
                  ? selectedProducts.some(({ id }) => id === item.id)
                  : false;
                const title = isEnglish ? details.title_en : details.title_ar;
                const color = isEnglish ? details.color_en : details.color_ar;
                const size = isEnglish ? details.size_en : details.size_ar;
                return (
                  <tr
                    className="order-checked"
                    id={"order-checked-id" + i}
                    key={i}
                  >
                    {/* {orderStatusValue == "1" || orderStatusValue == "2" ? ( */}
                    {selectable && (
                      <td className="selection-cell position-relative">
                        <input
                          checked={selected}
                          onChange={(e) => {
                            onProductSelect(e, i, item.id);
                          }}
                          id={"cancel-checked" + i}
                          className="mx-auto"
                          type="checkbox"
                          name="CancelItem"
                        />
                        {/* <div className="request-select">
                          <div className="d-flex align-items-center">
                            <div>
                              <select
                                name="reasons"
                                onChange={(e) => {
                                  onReturnDetailsChange(e, item, "reason");
                                }}
                                className="form-select form-contol ms-2 w-auto"
                                value={reasons}
                              >
                                <option value={""}>
                                  {orderLanguage.SelectReason}
                                </option>
                                <option value={"By Request"}>
                                  {orderLanguage.ByRequest}
                                </option>
                                <option value={"Out of stock"}>
                                  {orderLanguage.OutOfStock}
                                </option>
                              </select>
                            </div>
                            <div>
                              <select
                                className="form-select form-contol ms-3 w-auto"
                                name="qtys"
                                value={qtys}
                                onChange={(e) =>
                                  onReturnDetailsChange(e, item, "qty")
                                }
                              >
                                {qty.map((q) => (
                                  <option>{q}</option>
                                ))}
                              </select>
                            </div>
                          </div>
                        </div> */}
                      </td>
                    )}

                    {/* ) : (
                      ""
                    )} */}
                    <td>
                      <div className="edit-option imgWidth">
                        <img
                          className="imgWidth border rounded "
                          src={
                            details.image !== null
                              ? details.image?.split(",")[0]
                              : ""
                          }
                          alt=""
                        />
                        <button className="edit-btn-class">
                          <a
                            href={"/edit-product/" + item.product_id}
                            rel="noreferrer"
                            target="_blank"
                          >
                            <i className="bi bi-pencil-fill"></i>
                          </a>
                        </button>
                      </div>
                    </td>

                    <td>
                      <p className="mb-0 fw-bold dark-red-txt">
                        {item.barcode}
                      </p>
                      <p className="dark-red-txt fw-600 mb-0">{details.id}</p>
                      <p className="mb-0">{title}</p>
                      <p className="mb-0">{color}</p>
                    </td>
                    <td>
                      <p className="mb-1">{item.return_reason}</p>
                      {item.return_images && (
                        <div className="d-flex gap-1">
                          <img
                            height={26}
                            alt="return product"
                            src={item.return_images}
                            style={{
                              border: "1px solid #EFEFEF",
                              borderRadius: "2px",
                            }}
                          />
                        </div>
                      )}
                    </td>
                    <td>{size}</td>
                    <td>
                      <div className="d-flex flex-column">
                        {details.discounted_price.toFixed(2)}
                        {/* {details.discount !== 0 && (
                          <span className="text-secondary text-decoration-line-through">
                            {details.product_price?.toFixed(2)}
                          </span>
                        )} */}
                      </div>
                    </td>
                    <td>{item.quantity}</td>
                    <td
                    // className={`${
                    //   detailData.discount_type == "percentage"
                    //     ? "fix-width-pattu"
                    //     : ""
                    // }`}
                    >
                      {details.product_price.toFixed(2)}
                      {/* {detailData.discount_type === "percentage" &&
                        (detailData.exclude_sale === 1 ? (
                          details.discount === 0 ? (
                            <span className="d-block table-total-price">
                              After Coupon:
                              {details.paymentable_price?.toFixed(2)}
                            </span>
                          ) : (
                            ""
                          )
                        ) : (
                          <span className="d-block table-total-price">
                            After Coupon:
                            {details.paymentable_price?.toFixed(2)}
                          </span>
                        ))} */}
                    </td>
                  </tr>
                );
              })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ReturnProductList;
