import createReactClass from 'create-react-class';
import React, { Component } from 'react';
import SpecificSizeGudeEl from './SpecificSizeGudeEl';
import SpecificSizeColumns from './SpecificSizeColumns';
import { API_Path, productArabic, productEnglish, sizeGuidelinesArabic, sizeGuidelinesEnglish } from '../const';
import { PostApi } from '../helper/APIService';
import LanguageContext from "../contexts/languageContext";

var SizeGuidelineData = []
var SizeGuidelineDatacol = []
var HowTOMeasureData = [];

const SizeGuidelineList = createReactClass({
    render: function () {
        if (this.props.variations) {

            SizeGuidelineData = this.props.variations;
            if (this.props.variations.length > 1)
                for (let i = 0; i < this.props.variations.length - 1; i++) {
                    if (document.getElementById("plus-row-" + i)) {
                        document.getElementById("plus-row-" + i).style.display = "none";
                    }
                }
        }
        const guidelineList = this.props.variations.map((val, i) => {
            let elm = React.createElement(SpecificSizeGudeEl, {
                formVals: val,
                index: i,
                setVal: (value, ind) => this.props.setVal(value, ind),
                removeElement: (ind) => this.props.removeElement(ind),
                addElement: (ind) => this.props.addElement(ind),
                columns: this.props.columns,
                count: this.props.columns.length,
                length: this.props.variations.length
            });
            return <React.Fragment key={i}>{elm}</React.Fragment>;
        });
        return guidelineList;
    },
});
const SizeGuidelineColumns = createReactClass({
    render: function () {
        if (this.props.variations) {
            SizeGuidelineDatacol = this.props.variations;
            if (this.props.variations.length > 1)
                for (let i = 0; i < this.props.variations.length - 1; i++) {
                    if (document.getElementById("plus-" + i)) {
                        document.getElementById("plus-" + i).style.display = "none";
                    }
                }
        }
        const guidelineList = this.props.variations.map((val, i) => {
            let elm = React.createElement(SpecificSizeColumns, {
                formVals: val,
                index: i,
                Data: this.props.variations,
                setVal: (value, ind, onchange) => this.props.setVal(value, ind, onchange),
                setVal2: (value, ind) => this.props.setVal2(value, ind),
                removeElement: (ind) => this.props.removeElement(ind),
                addElement: (value, ind) => this.props.addElement(value, ind),
                colValEn: 'english',
                colValAr: 'arabic',
            });
            return <React.Fragment key={i}>{elm}</React.Fragment>;
        });
        return guidelineList;
    },
});
class SpecificSizeGuide extends Component {
    static contextType = LanguageContext;
    constructor(props) {
        super(props)
        this.state = {
            sizeVariationRow: [
                {
                    row_id: 0
                }
            ],
            new_sizeVariationRow: {
                row_id: 0
            },
            sizeVariationCol: [
                {
                    col_id: 0,
                    english: 'Size',
                    arabic: 'مقاس'
                }
            ],
            new_sizeVariationCol:
            {
                col_id: 0,
            },
            howToMeasureData: '',
            howToMeasureDataArr: '',
            howToMeasureSelectedData: '',
            sizeGuideLineImg: '',
            finalSizeGuideData: {
                image: '',
                how_to_measure: [],
            },
            sizeGuideLineImgUrl: '',
            showData: false,
            // =============================for dev-only==============================
            changeLang: 'english'

        }
    }
    componentDidMount() {
        if (this.props.SizeData) {
            let size_data = this.props.SizeData
            this.setState({ sizeVariationRow: size_data.tableRow, sizeVariationCol: size_data.tableColumn, sizeGuideLineImgUrl: size_data.image, howToMeasureSelectedData: size_data.how_to_measure })
        }
        this.getHowToMeasureData()
    }

    getHowToMeasureData = () => {
        let data = {};

        let path = API_Path.gethowtomeasure;
        const getHowToMeasurePromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        getHowToMeasurePromise.then((res) => {
            if (res) {
                this.setState({ howToMeasureData: res.data.data }, () => {
                    if (this.props.SizeData) {
                        let size_data = this.props.SizeData
                        if (size_data.how_to_measure != '' && size_data.how_to_measure.length > 0) {
                            let sizemeasureArr = size_data.how_to_measure.map(val => val.id)
                            HowTOMeasureData = sizemeasureArr
                            this.setState({ howToMeasureDataArr: sizemeasureArr })
                        }
                    }
                });
            }
        });
    };
    handleMeasureChange = (e) => {
        if (!HowTOMeasureData.includes(e.target.value)) {
            HowTOMeasureData.push(e.target.value);
        }
        this.setState({ howToMeasureDataArr: HowTOMeasureData }, () => {
            let Parr = []
            this.state.howToMeasureDataArr.map((item, i) => {
                let filtered = this.state.howToMeasureData.filter((l) => parseInt(item) === l.id);
                Parr.push(filtered[0])
            })
            this.setState({ howToMeasureSelectedData: Parr }, () => {
                this.updateSIzeGuidData()
            })
        });
    }
    removeMeasure = (id) => {
        let filtered = this.state.howToMeasureDataArr.filter((item, i) => parseInt(item) !== id);
        HowTOMeasureData = filtered;
        let filtered2
        if (this.state.howToMeasureSelectedData.length > 0) {
            filtered2 = this.state.howToMeasureSelectedData.filter(obj => obj.id != id)
        } else {
            filtered2 = []
        }
        this.setState({ howToMeasureDataArr: filtered, howToMeasureSelectedData: filtered2 }, () => {
            this.updateSIzeGuidData()
        });
    };
    addsizeGuideLine = (e) => {
        this.setState({ sizeGuideLineImg: Object.values(e.target.files) }, () => {
            this.setState({ isLoading: true });
            this.addsizeGuideLineToStorage(this.state.sizeGuideLineImg);
        });
    };
    addsizeGuideLineToStorage = (files) => {

        var formData = new FormData();
        for (var i = 0; i < files.length; i++) {
            formData.append("file", files[i]);
        }

        let path = API_Path.addFileInS3;
        const addFilePromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, formData));
        });

        addFilePromise.then((res) => {
            if (res) {
                this.setState({ sizeGuideLineImgUrl: res.data.data[0] }, () => {
                    this.setState({ isLoading: false });
                    this.updateSIzeGuidData()
                    // document.getElementById('sizeGuideLineError').style.display = 'none'
                });
            }
        });
    };
    removesizeGuideLine = () => {
        this.setState({ sizeGuideLineImg: "", sizeGuideLineImgUrl: "" }, () => {
            this.updateSIzeGuidData()
        });
        document.getElementById("sizeGuideLineInput").value = "";
    };
    setVal = (val, index) => {
        let variations = this.state.sizeVariationRow;
        if (typeof variations[index] !== "undefined") {
            variations[index] = {
                ...variations[index],
                ...val,
            };
        }
        this.setState({
            sizeVariationRow: variations,
        }, () => {
            this.updateSIzeGuidData()
        });
    };
    addVariation = () => {
        let setNewRow = this.state.new_sizeVariationRow
        for (let i = 0; i < this.state.sizeVariationCol.length; i++) {
            if (i != 0) {
                setNewRow['col_' + this.state.sizeVariationCol[i].col_id] = ''
                setNewRow.size_en = ''
                setNewRow.size_ar = ''
            }
        }
        this.setState({ new_sizeVariationRow: setNewRow }, () => {
            this.setState({
                sizeVariationRow: [...this.state.sizeVariationRow, this.state.new_sizeVariationRow],
            }, () => {
                this.updateSIzeGuidData()
            });
        })
    };
    removeElement = (index) => {
        let variations = this.state.sizeVariationRow;
        if (variations.length > 1) {
            if (typeof variations[index] !== "undefined") {
                delete variations[index];
            }
            this.setState(
                {
                    sizeVariationRow: variations.filter(Boolean),
                },
                () => {
                    if (this.state.sizeVariationRow.length > 0) {
                        document.getElementById("plus-row-" + (this.state.sizeVariationRow.length - 1).toString()).style.display = "block";
                    }
                    this.updateSIzeGuidData()
                }
            );
        }
    };
    removeElementcol = (index) => {
        let variationscol = this.state.sizeVariationCol;
        if (variationscol.length > 1) {
            if (typeof variationscol[index] !== "undefined") {
                delete variationscol[index];
            }
            this.setState(
                {
                    sizeVariationCol: variationscol.filter(Boolean),
                },
                () => {
                    let colArr = this.state.sizeVariationCol
                    for (let i = 0; i < colArr.length; i++) {
                        colArr[i].col_id = i
                    }
                    this.setState({ sizeVariationCol: colArr }, () => {
                        let rowArr = this.state.sizeVariationRow

                        const modifiedArray = rowArr.map(obj => {
                            const newObj = { ...obj };
                            delete newObj['col_' + index];
                            return newObj;
                        });
                        for (let j = 0; j < modifiedArray.length; j++) {
                            const transformedArray = [];
                            for (let i = 1; i <= modifiedArray[j].columns; i++) {
                                const columnName = "col_" + i;
                                const columnValue = modifiedArray[j][columnName];
                                if (columnValue != undefined) {
                                    transformedArray.push({ [columnName]: columnValue });
                                }
                            }
                            const key = transformedArray.map(el => Object.values(el)[0])
                            const temArr = {}
                            for (let i = 0; i < transformedArray.length; i++) {
                                temArr['col_' + Number(i + 1)] = key[i]
                            }
                            for (let i = 1; i <= modifiedArray[j].columns; i++) {
                                const columnName = "col_" + i;
                                delete modifiedArray[j][columnName];
                            }
                            modifiedArray[j] = { ...temArr, ...modifiedArray[j] }
                            modifiedArray[j].columns = transformedArray.length
                        }
                        this.setState({ sizeVariationRow: modifiedArray }, () => {
                            this.updateSIzeGuidData()
                        })
                        if (this.state.sizeVariationCol.length > 0) {
                            document.getElementById("plus-" + (this.state.sizeVariationCol.length - 1).toString()).style.display = "block";
                        }

                    })
                }
            );
        }
    };
    setValcol = (val, index) => {
        let variations = this.state.sizeVariationCol;
        if (typeof variations[index] !== "undefined") {
            variations[index] = {
                ...variations[index],
                ...val,
            };
        }
        this.setState({
            sizeVariationCol: variations,
        }, () => {
            for (let i = 0; i < this.state.sizeVariationRow.length; i++) {
                this.state.sizeVariationRow[i].columns = this.state.sizeVariationCol.length - 1
            }
            this.updateSIzeGuidData()
        });
    }
    setValcol2 = (val, index) => {
        let variations = this.state.sizeVariationCol;
        if (typeof variations[index] !== "undefined") {
            variations[index] = {
                ...variations[index],
                ...val,
            };
        }
        const Colarray = variations
        let currentId = 0;
        for (let i = 0; i < Colarray.length; i++) {
            // if (i == index) {
            //     if (i != 0) {
            //         Colarray[i].english = ''
            //         Colarray[i].arabic = ''
            //     }
            // }
            if (Colarray[i].col_id !== currentId) {
                Colarray[i].col_id = currentId + 1;
            }
            currentId = Colarray[i].col_id;
        }
        let rowArr = this.state.sizeVariationRow
        // for (let i = 0; i < rowArr.length; i++) {
        //     rowArr[i]['col_' + index] = ''
        //     rowArr[i]['columns'] = Number(rowArr[i]['columns'] + 1)

        // }
        this.setState({ sizeVariationCol: Colarray, sizeVariationRow: rowArr }, () => {
            this.updateSIzeGuidData()
        })

    }
    addVariationcol = (val, index) => {

        this.setState({
            sizeVariationCol: [...this.state.sizeVariationCol, this.state.new_sizeVariationCol],
        }, () => {
            let variations = this.state.sizeVariationCol;
            if (typeof variations[Number(index)] !== "undefined") {
                variations[Number(index)] = {
                    ...variations[Number(index)],
                    ...val,
                };
            }
            const Colarray = variations
            // debugger
            // let currentId = 0;
            for (let i = 0; i < Colarray.length; i++) {
                if (i == Number(index + 1)) {
                    if (i != 0) {
                        Colarray[i].english = ''
                        Colarray[i].arabic = ''
                    }
                }
                // if (Colarray[i].col_id !== currentId) {
                //     Colarray[i].col_id = currentId + 1;
                // }
                // currentId = Colarray[i].col_id;
            }
            let rowArr = this.state.sizeVariationRow
            for (let i = 0; i < rowArr.length; i++) {
                rowArr[i]['col_' + Number(index + 1)] = ''
                rowArr[i]['columns'] = Number(rowArr[i]['columns'] + 1)

            }
            this.setState({ sizeVariationCol: Colarray, sizeVariationRow: rowArr }, () => {
                this.updateSIzeGuidData()
            })
        });
    }
    showData = () => {
        this.setState({ showData: true, changeLang: 'english' })
    }
    showDataAr = () => {
        this.setState({ changeLang: 'arabic' })
    }

    updateSIzeGuidData = () => {
        let updatedObj = this.state.finalSizeGuideData
        updatedObj.how_to_measure = this.state.howToMeasureSelectedData
        updatedObj.image = this.state.sizeGuideLineImgUrl
        updatedObj.tableColumn = this.state.sizeVariationCol
        updatedObj.tableRow = this.state.sizeVariationRow
        this.setState({
            finalSizeGuideData: updatedObj
        }, () => {
            this.props.getSizeGuidlineData(this.state.finalSizeGuideData)
        })
    }
    render() {
        let sizeGuidelinesLanguage = this.context.language === "english" ? sizeGuidelinesEnglish : sizeGuidelinesArabic;
        let productLanguage = this.context.language === "english" ? productEnglish : productArabic;
        return (
            <>
                <div className="row mt-3">
                    {" "}
                    <div className="col-md-12 mx-auto border py-2">
                        <div className="table-responsive cust-table-size verticle-class">
                            <table>
                                <tr>
                                    <SizeGuidelineColumns variations={this.state.sizeVariationCol} removeElement={(i) => this.removeElementcol(i)} addElement={(value, ind) => this.addVariationcol(value, ind)} columns={this.state.columns} setVal2={(val, ind) => this.setValcol2(val, ind)} setVal={(val, ind, onchange) => this.setValcol(val, ind, onchange)} />
                                </tr>
                                <SizeGuidelineList variations={this.state.sizeVariationRow} removeElement={(i) => this.removeElement(i)} addElement={(i) => this.addVariation(i)} columns={this.state.sizeVariationCol} setVal={(val, ind) => this.setVal(val, ind)} />
                            </table>
                        </div>
                    </div>
                </div>
                <div className="row mt-3">
                    <div className="col-md-6">
                        <div className="form-group ">
                            <label>{sizeGuidelinesLanguage.addSizeGuideline}</label>
                            <div className="d-flex flex-wrap">
                                <div className="upload-btn-wrapper mb-3">
                                    <span className="btn">{sizeGuidelinesLanguage.uploadAFile}</span>
                                    <input onChange={this.addsizeGuideLine} type="file" accept="image/*" id="sizeGuideLineInput" name="sizeGuideLineImg" />
                                </div>
                                {this.state.sizeGuideLineImgUrl !== "" && (
                                    <div className="img-preview ps-3 wdth-click-main">
                                        <ul className="justify-content-center">
                                            <div className="img-bdr-main">
                                                <div className="img-bdr-main-inr">
                                                    <li>
                                                        <div className="img-preview-main position-relative">
                                                            <img src={this.state.sizeGuideLineImgUrl} alt="" />
                                                            <div onClick={this.removesizeGuideLine} className="remove-img-btn">
                                                                <i className="bi bi-x-circle-fill"></i>
                                                            </div>
                                                        </div>
                                                    </li>
                                                </div>
                                            </div>
                                        </ul>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                    <div className="col-md-6 form-group">
                        <label>{sizeGuidelinesLanguage.Howtomeasure}</label>
                        <select name="howToMeasure" value={this.state.howToMeasure} onChange={this.handleMeasureChange} className="form-select input-custom-class">
                            <option value="">{sizeGuidelinesLanguage.SelectHowToMeasure}</option>
                            {this.state.howToMeasureData &&
                                this.state.howToMeasureData.length > 0 &&
                                this.state.howToMeasureData.map((item, i) => {
                                    return (
                                        <option value={item.id} key={i}>
                                            {this.context.language === "english" ? item.title_en : item.title_ar}
                                        </option>
                                    );
                                })}
                        </select>
                        <div className="cust-tag-div d-flex">
                            {this.state.howToMeasureDataArr &&
                                this.state.howToMeasureDataArr.map((item, i) => {
                                    let filtered = this.state.howToMeasureData.filter((l) => parseInt(item) === l.id);
                                    return (
                                        <ul key={i}>
                                            {filtered &&
                                                filtered.map((m, i) => {
                                                    return (
                                                        <li key={i}>
                                                            <span>{m.title_en}</span>
                                                            <mark onClick={() => this.removeMeasure(m.id)} className=" bg-transparent bi bi-x p-0"></mark>
                                                        </li>
                                                    );
                                                })}
                                        </ul>
                                    );
                                })}
                        </div>
                    </div>
                    {/* <div>
                        <button type='button' onClick={this.showData} className='white-btn btn-danger'>Show</button>
                        <button type='button' onClick={this.showDataAr} className='white-btn btn-danger'>Show in Arabic</button>
                    </div> */}
                    {/* {this.state.showData &&
                        (this.state.changeLang == 'english' ?
                            <div className='col-md-6'>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            {this.state.sizeVariationCol.length > 0 && this.state.sizeVariationCol.map((item, i) => {
                                                return (
                                                    item.english !== '' &&
                                                    <th scope="col">{item.english}</th>
                                                )
                                            })}
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {this.state.sizeVariationRow.length > 0 && this.state.sizeVariationRow.map((row, i) => {
                                            return (
                                                <tr>
                                                    {this.state.sizeVariationCol.length > 0 && this.state.sizeVariationCol.map((col, j) => {
                                                        return (
                                                            j == 0 ?
                                                                <th scope="row">{row.size_en}</th>
                                                                :
                                                                <td>{row['col_' + col.col_id]}</td>
                                                        )
                                                    })}
                                                </tr>

                                            )

                                        })}
                                    </tbody>
                                </table>
                            </div>
                            :
                            <div className='col-md-6'>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            {this.state.sizeVariationCol.length > 0 && this.state.sizeVariationCol.map((item, i) => {
                                                return (
                                                    item.arabic !== '' &&
                                                    <th scope="col" > {item.arabic}</th>
                                                )
                                            })}
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {this.state.sizeVariationRow.length > 0 && this.state.sizeVariationRow.map((row, i) => {
                                            return (
                                                <tr>
                                                    {this.state.sizeVariationCol.length > 0 && this.state.sizeVariationCol.map((col, j) => {
                                                        return (
                                                            j == 0 ?
                                                                <th scope="row">{row.size_ar}</th>
                                                                :
                                                                <td>{row['col_' + col.col_id]}</td>
                                                        )
                                                    })}
                                                </tr>

                                            )

                                        })}
                                    </tbody>
                                </table>
                            </div>
                        )
                    } */}
                </div >
            </>
        );
    }
}

export default SpecificSizeGuide;
