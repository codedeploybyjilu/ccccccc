import React, { Component } from 'react'

export default class Test extends Component {

    state = {
        one: '',
        two: '',
        three: '',
        four: '',
        five: '',
        columns: []
    }

    handleChange = (e) => {
        this.setState({ [e.target.name]: e.target.checked }, () => {
            console.log('one', this.state.one);
            console.log('two', this.state.two);
            console.log('three', this.state.three);
            console.log('four', this.state.four);
            console.log('five', this.state.five);
        })

    }

    handleSubmit = () => {
        let columnArray = []
        if (this.state.one == true) {
            columnArray.push('one')
        }
        if (this.state.two == true) {
            columnArray.push('two')
        }
        if (this.state.three == true) {
            columnArray.push('three')
        }
        if (this.state.four == true) {
            columnArray.push('four')
        }
        if (this.state.five == true) {
            columnArray.push('five')
        }
        console.log('array :: ', columnArray);
        this.setState({ columns: columnArray })
    }

    handePlus = () => {

    }

    render() {
        return (
            <div>
                <label className="container">One
                    <input onChange={this.handleChange} name='one' type="checkbox" />
                    <span className="checkmark"></span>
                </label>
                <label className="container">two
                    <input onChange={this.handleChange} name='two' type="checkbox" />
                    <span className="checkmark"></span>
                </label>
                <label className="container">three
                    <input onChange={this.handleChange} name='three' type="checkbox" />
                    <span className="checkmark"></span>
                </label>
                <label className="container">four
                    <input onChange={this.handleChange} name='four' type="checkbox" />
                    <span className="checkmark"></span>
                </label>
                <label className="container">five
                    <input onChange={this.handleChange} name='five' type="checkbox" />
                    <span className="checkmark"></span>
                </label>
                <button onClick={this.handleSubmit}>
                    Submit
                </button>

                <table>
                    <thead>
                        <tr>
                            <th>size</th>
                            {this.state.columns.length > 0 && this.state.columns.map((item, i) => {
                                return (
                                    <th key={i} >{item}</th>
                                )
                            })}
                            <th></th>
                        </tr>
                    </thead>

                    <tbody>
                        <tr>
                            <td><input type='text' /></td>
                            {this.state.columns.length > 0 && this.state.columns.map((item, i) => {
                                return (<td key={i}>
                                    <input type='number' />
                                </td>
                                )
                            })}
                            <td><button onClick={this.handePlus} >+</button></td>
                        </tr>



                    </tbody>
                </table>
            </div>
        )
    }
}
