import React, { Component } from 'react';
import toastr from "toastr";

class SpecificSizeGudeEl extends Component {
    componentDidMount() {
        // let obj = {}
        // this.props.columns.forEach(item => {
        //     let key = item.english
        //     let value = ''
        //     obj[key] = value
        // })
        // obj.row_id = this.props.index
        this.props.setVal({ row_id: this.props.index, columns: this.props.columns.length - 1 }, this.props.index)

    }
    render() {
        let productLanguage = '';
        if (this.props?.formVals) {
            const { formVals, index, setVal, removeElement, addElement, columns, length } = this.props;
            const inputAttr = (field) => ({
                value: formVals[field],
                onChange: (e) => {
                    if (field === 'events') {
                        this.handleEventChange(e);
                    }
                    if (field) {
                        // setVal([e.target.value], index);
                        setVal({ [field]: e.target.value }, index);
                    } else {
                        toastr.error('please enter sizeType')
                    }
                }

            })
            return (
                <tr className=''>
                    <td className="">
                        <div className='d-flex align-items-center'>
                            <input type='text' name="size" {...inputAttr('size_en')} placeholder={productLanguage.Entersize} className="form-control frnt-input-style me-2" />
                            <input type='text' name="size" {...inputAttr('size_ar')} placeholder={productLanguage.Entersize} className="form-control frnt-input-style" dir='rtl' />
                        </div>
                    </td>
                    {
                        columns.length > 0 && columns.map((item, i) => {
                            // console.log(formVals['col_' + item.col_id], "[]][");
                            return (
                                i != 0 &&
                                <td className="">
                                    <div className='d-flex align-items-center'>
                                        <input type='text' name="size" {...inputAttr('col_' + item.col_id)} placeholder={productLanguage.Entersize} className="form-control frnt-input-style text-center" />
                                    </div>
                                </td>
                            )
                        })
                    }
                    <div className="col-md-1 col-12 mt-2 pt-2 d-flex">
                        {/* {(index === 0) ? null : ( */}
                        <button id='removeButton'
                            className={"minues-mini-btn me-1 "}
                            onClick={() => removeElement(index)}
                        >-</button>
                        {/* )} */}
                        <button id={'plus-row-' + index} className='plus-mini-btn w-auto' onClick={() => addElement(index)} > +</button>
                    </div>
                </tr>
            )
        } else {
            return null;
        }
    }
}

export default SpecificSizeGudeEl;
