import React, { Component } from 'react'
import MUIDataTable from "mui-datatables";
export default class MUITable extends Component {
    render() {

        return (
            <MUIDataTable
                data={this.props.data}
                columns={this.props.columns}
                options={this.props.options}
            />
        );
    }
}
