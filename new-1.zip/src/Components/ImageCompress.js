export const ImageCompress = (imageArr) => {
    const promises = Object.values(imageArr).map(async (myValue) => {
        return MultipleImageCompress(myValue)
    });
    return Promise.all(promises);
}
const MultipleImageCompress = (file) => {
    return new Promise((resolve) => {
        const maxSize = 1 * 1024 * 1024;
        let image = file;
        let quality = 0.8;
        const img = new Image();
        img.src = URL.createObjectURL(image);
        img.onload = (e) => {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            const typeimg = image.type.split("/").pop()
            canvas.width = img.width;
            canvas.height = img.height;
            ctx.drawImage(img, 0, 0, img.width, img.height);
            let dataUrl = canvas.toDataURL("image/jpeg", quality);
            let compressedFile = dataURLtoFile(dataUrl, image.name);
            console.log(compressedFile.size, ">", image.size);
            while (compressedFile.size > image.size) {
                quality -= 0.05;
                dataUrl = canvas.toDataURL("image/jpeg", quality);
                compressedFile = dataURLtoFile(dataUrl, image.name);
            }
            while (compressedFile.size > maxSize) {
                // console.log(compressedFile.size, ";;;", image.size);
                quality -= 0.05;
                dataUrl = canvas.toDataURL("image/jpeg", quality);
                compressedFile = dataURLtoFile(dataUrl, image.name);
            }
            console.log(URL.createObjectURL(compressedFile), "compressedFile777");
            resolve(compressedFile)
        }
    })
}
function dataURLtoFile(dataURL, filename) {
    const arr = dataURL.split(',');
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
}
