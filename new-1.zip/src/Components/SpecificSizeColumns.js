import React, { Component } from 'react';

class SpecificSizeColumns extends Component {
    componentDidMount() {
        this.props.setVal2({ col_id: this.props.index }, this.props.index, false)

    }
    render() {
        let productLanguage = '';
        if (this.props?.formVals) {
            const { formVals, index, setVal, removeElement, addElement, columns, colValEn, colValAr } = this.props;
            // console.log('columns is :: ', columns);
            const inputAttr = (field) => ({
                value: formVals[field],
                onChange: (e) => {
                    if (field === 'events') {
                        this.handleEventChange(e);
                    }
                    // if(e.target)
                    setVal({ [field]: e.target.value, ...(field == colValEn && { ['col_' + index]: e.target.value }) }, index, true);
                    // setVal([e.target.value], index);
                }

            })
            return (
                <>

                    <td className="">
                        <div className=" mb-2 d-flex  justify-content-center">
                            {(index === 0) ? null : (
                                <button id='removeButton'
                                    className={"minues-mini-btn me-1 "}
                                    onClick={() => removeElement(index)}
                                >-</button>
                            )}
                            <button id={'plus-' + index} className='plus-mini-btn' onClick={() => addElement({ col_id: this.props.index }, this.props.index, false)} > +</button>
                        </div>
                        <div className='d-flex align-items-center'>
                            <input type='text' name="english" {...inputAttr(colValEn)} placeholder={productLanguage.Entersize} className="form-control frnt-input-style me-2" />
                            <input type='text' name="arabic" {...inputAttr(colValAr)} placeholder={productLanguage.Entersize} className="form-control frnt-input-style" dir='rtl' />
                        </div>
                    </td>

                </>

            )
        } else {
            return null;
        }
    }
}

export default SpecificSizeColumns;
