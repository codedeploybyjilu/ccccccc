import React, { useContext } from 'react';
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory, {
    PaginationProvider,
    SizePerPageDropdownStandalone,
    PaginationTotalStandalone,
    PaginationListStandalone
} from 'react-bootstrap-table2-paginator';
import filterFactory from 'react-bootstrap-table2-filter';
import ToolkitProvider, { CSVExport, ColumnToggle } from 'react-bootstrap-table2-toolkit';
import 'react-bootstrap-table2-filter/dist/react-bootstrap-table2-filter.min.css';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';
import LanguageContext from "../contexts/languageContext";

let languageData;

const { ToggleList } = ColumnToggle;
const { ExportCSVButton } = CSVExport;
// const { SearchBar } = Search;

const BootstrapTableWithExport = ({ ...tableProps }) => {

    return (
        <ToolkitProvider
            {...tableProps}
            exportCSV
            columnToggle
        >
            {
                props => (
                    <React.Fragment>
                        <ToggleList
                            className="d-none"
                            btnClassName="contact-data-table"
                            {...props.columnToggleProps}
                        />
                        {/* {window.location.href === `${APIBaseUrl}/users` && ( */}
                        {/* {window.location.href === `http://localhost:3000/users` && (
                            <div className="mx-auto mb-3 customer-search-bar position-relative">
                                <SearchBar placeholder="Search by name, phone or email" {...props.searchProps} />
                                <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M6.31802 1C5.26621 1 4.23803 1.31189 3.36349 1.89622C2.48894 2.48055 1.80732 3.31108 1.40481 4.28279C1.0023 5.2545 0.89699 6.32374 1.10219 7.3553C1.30738 8.38686 1.81388 9.33441 2.55761 10.0781C3.30135 10.8218 4.24893 11.3283 5.28052 11.5335C6.31212 11.7387 7.38139 11.6334 8.35313 11.2309C9.32487 10.8284 10.1554 10.1468 10.7398 9.27228C11.3241 8.39776 11.636 7.36961 11.636 6.31784C11.6359 4.90749 11.0756 3.55493 10.0783 2.55766C9.08102 1.56039 7.72842 1.00009 6.31802 1V1Z" stroke="#C4C4C4" stroke-width="1.875" stroke-miterlimit="10" />
                                    <path d="M10.2856 10.2803L13.9997 13.9942" stroke="#C4C4C4" stroke-width="1.875" stroke-miterlimit="10" stroke-linecap="round" />
                                </svg>
                            </div>
                        )} */}
                        <ExportCSVButton id="DataTableExportCSV" style={{ display: 'none' }}
                            className="hidden" {...props.csvProps}>{languageData === 'english' ? "Export CSV!!" : "تصدير CSV !!"}</ExportCSVButton>
                        <BootstrapTable {...props.baseProps} {...tableProps} />
                    </React.Fragment>
                )
            }
        </ToolkitProvider >
    );
}

const DataTableLoading = () => {
    return (
        <div id="DataTables_Table_1_processing" className="dataTables_processing"
            style={{ display: "none" }}>{languageData === 'english' ? "Processing..." : "يعالج..."}
        </div>
    );
};

// const DataLoading = () => (
//     <div id="DataTables_Table_3_processing" className="dataTables_processing"
//          style={{display: "block"}}>Processing...</div>
// );

const sizePerPageRenderer = ({ options, currSizePerPage, onSizePerPageChange }) => {
    return (
        <div className="dataTables_length" id="DataTables_Table_4_length">
            <label>
                {languageData === 'english' ? "Show" : "معروض"}
                <select className="btn-group" value={currSizePerPage} role="group"
                    onChange={(e) => onSizePerPageChange(e.target.value)}>
                    {
                        options.map((option) => (
                            <option key={option.text}>
                                {option.text}
                            </option>
                        ))
                    }
                </select> {languageData === 'english' ? "Entries" : "فئات"}
            </label>
        </div>
    )
};

const paginationTotalRenderer = (from, to, size) => (
    <span className="react-bootstrap-table-pagination-total dataTables_info">
        {languageData === 'english' ? "Showing" : "عرض"} {from} {languageData === 'english' ? "to" : "إلى"} {to} {languageData === 'english' ? "of" : "من"} {size} {languageData === 'english' ? "Entries" : "فئات"}
    </span>
);

const DataTable = ({
    loading,
    keyField,
    data,
    columns,
    defaultSorted,
    page,
    sizePerPage,
    onTableChange,
    language,
    totalSize,
    columns_hidden
}) => {
    languageData = language

    const sizePerPageList = [
        { text: '10', value: 10 },
        { text: '25', value: 25 },
        { text: '50', value: 50 },
        { text: '100', value: 100 }
    ];

    const options = {
        custom: true,
        paginationSize: 2,
        page,
        sizePerPage,
        totalSize,
        sizePerPageList,
        showTotal: true,
        sizePerPageRenderer,
        paginationTotalRenderer,
        firstPageText: languageData === 'english' ? 'First' : "أولاً",
        prePageText: languageData === 'english' ? 'Previous' : "الصفحة السابقة",
        nextPageText: languageData === 'english' ? 'Next' : "الصفحة التالية ",
        lastPageText: languageData === 'english' ? 'Last' : "الصفحة الأخيرة ",
    };

    const selectRow = {
        mode: 'checkbox',
        clickToSelect: true,
        clickToEdit: true,
        classes: '',
        colors: 'rgba(168, 26, 29, 0.1)'
    };

    return (
        <React.Fragment>
            <PaginationProvider
                pagination={paginationFactory(options)}
            >
                {
                    ({
                        paginationProps,
                        paginationTableProps
                    }) => (
                        <React.Fragment>
                            <SizePerPageDropdownStandalone {...paginationProps} />
                            {(!loading) || (<DataTableLoading />)}
                            <BootstrapTableWithExport
                                bordered={false}

                                dataTable
                                condensed
                                headerWrapperClasses="tableHead"
                                remote
                                loading={loading}
                                keyField={keyField}
                                data={data}
                                columns={columns}
                                columns_hidden={columns_hidden}
                                defaultSorted={defaultSorted}
                                filter={filterFactory()}
                                onTableChange={onTableChange}
                                noDataIndication={() => <React.Fragment>{languageData === 'english' ? "No data!" : "لايوجد بيانات!"}</React.Fragment>}
                                selectRow={selectRow}
                                // overlay={ overlayFactory({ spinner: (<DataLoading />), styles: {
                                //         overlay: (base) => ({
                                //             ...base,
                                //             background: "rgba(0, 0, 0, 0.2)"
                                //         })
                                //     } }) }
                                {...paginationTableProps}
                            />
                            <PaginationTotalStandalone
                                {...paginationProps}
                            />
                            <PaginationListStandalone
                                {...paginationProps}
                            />
                        </React.Fragment>
                    )
                }
            </PaginationProvider>
        </React.Fragment>
    );
}

export default DataTable;