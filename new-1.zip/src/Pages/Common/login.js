import React, { Component } from "react";
import { PostApi } from "../../helper/APIService";
import eyeCLose from "../../images/eye-close.svg";
import eyeOpen from "../../images/eye-show.svg";
// import jwt from 'jsonwebtoken';
import jwtSign from "jwt-encode";
import { jwtDecode } from "jwt-decode";
import publicIp from "public-ip";
import toastr from "toastr";
import LanguageContext from "../../contexts/languageContext";

import { API_Path, LoginEnglish, LoginArabic } from "../../const";
import { Link, withRouter } from "react-router-dom";

class Login extends Component {
  static contextType = LanguageContext;

  state = {
    email: "",
    password: "",
    ip: "",
  };

  componentDidMount() {
    let remember_me_token = localStorage.getItem("remember_token");
    if (remember_me_token !== null) {
      let temp = jwtDecode(remember_me_token);
      this.setState(
        { remember: true, email: temp.email, password: temp.password },
        () => {
          document.getElementById("remember").checked = true;
        }
      );
    }

    const IPPromise = new Promise((resolve, reject) => {
      resolve(publicIp.v4());
    });

    IPPromise.then((res) => {
      if (res) {
        this.setState({ ip: res });
      }
    });
  }

  password = () => {
    document.getElementById("passtoggler").classList.toggle("active");
    var x = document.getElementById("password");
    if (x.type === "password") {
      x.type = "text";
    } else {
      x.type = "password";
    }
  };

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  handleRememberCheckbox = (e) => {
    if (e.target.checked) {
      this.setState({ remember: true });
    } else {
      this.setState({ remember: false }, () => {
        localStorage.removeItem("remember_token");
      });
    }
  };

  handleLogin = () => {
    let path = API_Path.login;
    let data = {
      email: this.state.email,
      password: this.state.password,
      IPV4: this.state.ip,
    };

    const loginPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    const encode_token_jwt = (formData) => {
      const date = new Date();
      const time = date.getTime();
      const data = {
        exp: time + 3600,
        email: formData.email,
        password: formData.password,
        iat: time,
      };
      // console.log(time, "time", formData)
      const jwts = jwtSign(data, process.env.REACT_APP_JWT_SECRET);
      if (this.state.remember) {
        localStorage.setItem("remember_token", jwts);
      } else {
        localStorage.removeItem("remember_token");
      }
    };

    loginPromise.then((res) => {
      if (res) {
        console.log("res is :: ", res);
        if (res.data.success) {
          console.log(data, data);
          encode_token_jwt(data);
          localStorage.setItem("_a_token", res.data.token);
          toastr.success(res.data.message);
          this.props.history.push("/dashboard");
          // window.location.href = "/dashboard";
        } else {
          toastr.error(res.data.message);
        }
      }
    });
  };

  render() {
    // let Language = this.context.language === "english" ? TableFieldEnglish : TableFieldArabic;
    // let ButtonLanguage = this.context.language === "english" ? buttonEnglish : buttonArabic;
    // let titleLanguage = this.context.language === "english" ? titleEnglish : titleArabic;
    let LoginLanguage =
      this.context.language === "english" ? LoginEnglish : LoginArabic;
    return (
      <React.Fragment>
        <div className="container-fluid h-100">
          <div className="row align-items-center h-100">
            <div className="col-lg-6 p-0 d-lg-block d-none">
              <div className="log-main-benner-section position-relative text-center" />
            </div>
            <div className="col-lg-6 p-0">
              <div className="login-section-right-scroll">
                <div className="login-section-right-scroll-inr-class">
                  <div className="login-section-right">
                    <div className="text-center mb-4 logo-div-main">
                      <img src="assets/images/logo.svg" alt="" />
                    </div>
                    <div className="text-center login-section-right-top">
                      <h1>{LoginLanguage.LogIn}</h1>
                      <p>{LoginLanguage.WelcomeSignContinue}</p>Hello
                    </div>

                    <form className="pt-3 row me-0">
                      <div className="form-group col-12 ">
                        <label>{LoginLanguage.EmailAddress}</label>
                        <input
                          type="email"
                          name="email"
                          value={this.state.email}
                          onChange={this.handleChange}
                          className="form-control input-custom-class"
                          placeholder="Enter Your Email Address"
                        />
                      </div>
                      <div
                        className="form-group col-12 position-relative pass-main-click"
                        id="passtoggler"
                      >
                        <label>{LoginLanguage.Password}</label>
                        <input
                          type="password"
                          name="password"
                          value={this.state.password}
                          onChange={this.handleChange}
                          className="form-control input-custom-class"
                          placeholder="******"
                          id="password"
                        />
                        <label
                          className="input-right-icon pass-show-hide mb-0"
                          onClick={this.password}
                        >
                          <img
                            src={eyeCLose}
                            className="pass-close-image"
                            alt=""
                          />
                          <img
                            src={eyeOpen}
                            className="pass-show-image"
                            alt=""
                          />
                        </label>
                      </div>
                      <div className="form-group col-6">
                        <div className="cust-checkbox-new">
                          <label className="cust-chk-bx">
                            <input
                              type="checkbox"
                              id="remember"
                              name="remember"
                              value={this.state.remember}
                              onChange={this.handleRememberCheckbox}
                            />
                            <span className="cust-chkmark" />
                            {LoginLanguage.RememberMe}
                          </label>
                        </div>
                      </div>
                      <div className="form-group col-6  text-end">
                        <Link to={"forgot-password"} className="frt-link">
                          {LoginLanguage.ForgotPassword}
                        </Link>
                      </div>
                      <div className="form-group col-12 pt-3">
                        <button
                          type="button"
                          onClick={this.handleLogin}
                          className="btn-comn-main w-100 d-block"
                        >
                          {LoginLanguage.LogIn}
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default withRouter(Login);
