import React, { Component } from 'react';
import {Link} from "react-router-dom";

class ForgotPassword extends Component {

    state = {
        email: ''
    }

    handleForgotEmail = (e) => {
        this.setState({ email: e.target.value })
    }

    handleSubmit = () => {

    }

    render() {
        return (
            <React.Fragment>
                <div className="container-fluid h-100">
                    <div className="row align-items-center h-100">
                        <div className="col-lg-6 p-0 d-lg-block d-none">
                            <div className="log-main-benner-section position-relative text-center" >
                            </div>
                        </div>
                        <div className="col-lg-6 p-0">
                            <div className="login-section-right-scroll">
                                <div className="login-section-right-scroll-inr-class">
                                    <div className="login-section-right">
                                        <div className="text-center mb-4 logo-div-main">
                                            <img src="assets/images/logo.svg" alt="" />
                                        </div>
                                        <div className="text-center login-section-right-top">
                                            <h1>Forgot Password</h1>
                                            <p>Don't worry you can get back to us with a new password easily Mention your registered Email ID below.</p>
                                        </div>
                                        <form className="pt-3 row me-0">
                                            <div className="form-group col-12 ">
                                                <label>Email Address</label>
                                                <input type="email" onChange={this.handleForgotEmail} className="form-control input-custom-class" placeholder="example@gmail.com" />
                                            </div>
                                            <div className="form-group col-12 pt-3">
                                                <button type="button" onClick={this.handleSubmit} className="btn-comn-main w-100 d-block">Send Reset Link</button>
                                            </div>
                                            <div className="col-12 ftr-link">
                                                <p>Back to <Link to={""}>Log in</Link></p>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </React.Fragment>
        );
    }
}

export default ForgotPassword;