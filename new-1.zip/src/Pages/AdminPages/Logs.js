import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import {
  buttonArabic,
  buttonEnglish,
  TableFieldArabic,
  TableFieldEnglish,
  titleArabic,
  titleEnglish,
  SidebarEnglish,
  SidebarArabic,
  UserEnglish,
  UserArabic,
} from "../../const";
import LanguageContext from "../../contexts/languageContext";
import imgpro from "../../images/profile-log.png";

class Logs extends Component {
  static contextType = LanguageContext;

  render() {
    let Language =
      this.context.language === "english"
        ? TableFieldEnglish
        : TableFieldArabic;
    let titleLanguage =
      this.context.language === "english" ? titleEnglish : titleArabic;
    let buttonLanguage =
      this.context.language === "english" ? buttonEnglish : buttonArabic;
    let SidebarLanguage =
      this.context.language === "english" ? SidebarEnglish : SidebarArabic;
    let UserLanguage =
      this.context.language === "english" ? UserEnglish : UserArabic;

    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space">
            <div className="col-sm-5 text-sm-start text-center rtl-txt-start">
              <div className="common-header-txt">
                <h3>{SidebarLanguage.logs}</h3>
              </div>
            </div>
            <div className="col-sm-7 d-sm-flex align-items-end justify-content-end ">
              <div className="d-flex  user-sec align-items-center  ">
                <label className="me-2">{UserLanguage.From}:</label>
                <input type="date" className="white-btn me-2" />
              </div>
              <div className="d-flex user-sec align-items-center mt-2 mt-sm-0">
                <label className="me-2">{UserLanguage.To}:</label>
                <input type="date" className="white-btn me-2" />
              </div>
            </div>
          </div>
          <div className="row common-space">
            <div className="col-md-12">
              <div className="white-box">
                <div className="d-sm-flex cust-noti-page">
                  <div className="me-sm-4 me-0">
                    <img className="img-fluid" src={imgpro} alt="" />
                  </div>
                  <div>
                    <p>
                      <b>John Doe</b> added XXXXXXXX <b>sam</b> added inventory
                      10 to the Product
                    </p>
                    <span>5 hour ago</span>
                  </div>
                </div>
                <div className="d-sm-flex cust-noti-page">
                  <div className="me-sm-4 me-0">
                    <img className="img-fluid" src={imgpro} alt="" />
                  </div>
                  <div>
                    <p>
                      <b>John Doe</b> added XXXXXXXX <b>sam</b> added inventory
                      10 to the Product
                    </p>
                    <span>5 hour ago</span>
                  </div>
                </div>
                <div className="d-sm-flex cust-noti-page">
                  <div className="me-sm-4 me-0">
                    <img className="img-fluid" src={imgpro} alt="" />
                  </div>
                  <div>
                    <p>
                      <b>John Doe</b> added XXXXXXXX <b>sam</b> added inventory
                      10 to the Product
                    </p>
                    <span>5 hour ago</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Adminlayout>
    );
  }
}

export default Logs;
