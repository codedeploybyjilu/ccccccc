import React, { Component } from 'react';
import { Tab, Tabs } from 'react-bootstrap';
import Select from "react-select";

class IncludeVariationList extends Component {
    render() {

        // const options = [
        //     { value: 'chocolate', label: 'Chocolate' },
        //     { value: 'strawberry', label: 'Strawberry' },
        //     { value: 'vanilla', label: 'Vanilla' }
        // ]

        // const customStyles = {
        //     option: (provided, state) => ({
        //         ...provided,
        //         backgroundColor: "#fff",
        //         color: "#2d2d3b",
        //         ":hover": {
        //             color: "#a81a1c",
        //             backgroundColor: "#f4f1fc",
        //         },
        //     }),
        // };

        return (
            <div className="col-12 mt-3">
                <div><button className="border-0 p-0 bg-transparent mb-3 ortext-line">- OR</button></div>
                <div className="d-flex">
                    <div className="grey-border-box w-100 bg-transparent me-3">
                        <div className="row">

                            <div className="mb-3 col-md-6">
                                <label className="lbl-frnt-side">Events</label>
                                <select name="eventType" className="form-select input-custom-class">
                                    <option value="1">All app visitors</option>
                                    <option value="2">Customer Who visited specific product or collection</option>
                                    <option value="3">Visitor by time spent</option>
                                    <option value="4">Frequency</option>
                                    <option value="5">User Segment</option>
                                    <option value="6">Customer who have added product or collection to wishlist</option>
                                    <option value="7">Customer who have purchased product or collection</option>
                                    <option value="8">Customer who have placed an order</option>
                                    <option value="9">Customer adding to cart but not checking out</option>
                                    <option value="10">Customer who have not open app</option>
                                </select>
                            </div>

                            <div className="mb-3 col-md-6">
                                <div className="mb-3 col-12">
                                    <label className="lbl-frnt-side">Retention</label>
                                    <div className="d-flex align-items-center">
                                        <input type="number" name="retentionDays" min={1} placeholder="Days" className="form-control input-custom-class" />
                                        <span className="ms-2 white-space-no ">Days</span>
                                    </div>
                                    <div className="text-danger" style={{ display: "none" }}>
                                        Required !!
                                    </div>
                                </div>
                            </div>

                            <>
                                <div className="col-12 mb-3">
                                    <label className="lbl-frnt-side">Selection Type For Time Range</label>
                                    <select name="relation_type" className="form-select input-custom-class" >
                                        <option value="1">Percentile</option>
                                        <option value="2">Value</option>
                                    </select>
                                </div>
                                <div className="col-12">
                                    <div className="row">
                                        <div className="col-md-4 mb-3">
                                            <input type="text" value="Time" className="form-control input-custom-class" />
                                        </div>
                                        <div className="col-md-4 mb-3">
                                            <select name="relation" className="form-select input-custom-class">
                                                <option value=">">is greater than (&gt;)</option>
                                                <option value="=">equals (=)</option>
                                                <option value="<">is less than (&lt;)</option>
                                            </select>
                                        </div>
                                        <div className="col-md-4 mb-3">
                                            <input type="number" className="form-control input-custom-class" name="value" />
                                        </div>
                                    </div>
                                </div>
                                <div className="col-12 mb-3 ">
                                    <label className="lbl-frnt-side">Percentile</label>
                                    <select name="value" id="percentileSelect" className="form-select input-custom-class" >
                                        <option value="10">10%</option>
                                        <option value="20">20%</option>
                                        <option value="30">30%</option>
                                        <option value="40">40%</option>
                                        <option value="50">50%</option>
                                        <option value="60">60%</option>
                                        <option value="70">70%</option>
                                        <option value="80">80%</option>
                                        <option defaultValue="90">90%</option>
                                    </select>
                                </div>
                            </>

                            <>
                                <div className="col-12 mb-3">
                                    <label className="lbl-frnt-side">Selection Type For Frequency</label>
                                    <select name="relation_type" className="form-select input-custom-class" >
                                        <option value="1">Percentile</option>
                                        <option value="2">Value</option>
                                    </select>
                                </div>
                                <div className="col-12 mb-3">
                                    <div className="row">
                                        <div className="col-md-4 mb-3">
                                            <input type="text" value="Frequency" className="form-control input-custom-class" />
                                        </div>
                                        <div className="col-md-4 mb-3">
                                            <select name="relation" className="form-select input-custom-class">
                                                <option value=">">is greater than (&gt;)</option>
                                                <option value="=">equals (=)</option>
                                                <option value="<">is less than (&lt;)</option>
                                            </select>
                                        </div>
                                        <div className="col-md-4 mb-3">
                                            <input className="form-control input-custom-class" type="number" name="value" />
                                        </div>
                                    </div>
                                </div>
                                <div className="col-12 mb-3">
                                    <label className="lbl-frnt-side">Percentile</label>
                                    <select name="value" id="percentileSelect" className="form-select input-custom-class" >
                                        <option value="10">10%</option>
                                        <option value="20">20%</option>
                                        <option value="30">30%</option>
                                        <option value="40">40%</option>
                                        <option value="50">50%</option>
                                        <option value="60">60%</option>
                                        <option value="70">70%</option>
                                        <option value="80">80%</option>
                                        <option defaultValue="90">90%</option>
                                    </select>
                                </div>
                            </>

                            <div className="col-12 mb-3">
                                <div className="refine-by-section">
                                    <label className="lbl-frnt-side">select product or collection</label>
                                    <div className="row">
                                        <div className="col-12 tabs-prd-clt-new-all">
                                            <Tabs defaultActiveKey="product" transition={false} onSelect={() => this.setState({ SelectBox: null })}>
                                                <Tab eventKey="product" title="Product">
                                                    <div className="col-12 custom-dropdown-select d-inline-block align-middle">
                                                        <select className="form-select input-custom-class" id="">
                                                            <option selected>Choose...</option>
                                                            <option value="1">One</option>
                                                            <option value="2">Two</option>
                                                            <option value="3">Three</option>
                                                        </select>
                                                    </div>
                                                </Tab>
                                                <Tab eventKey="collection" title="Collection">
                                                    <div className="col-12 custom-dropdown-select d-inline-block align-middle">
                                                        <select className="form-select input-custom-class" id="">
                                                            <option selected>Choose...</option>
                                                            <option value="1">One</option>
                                                            <option value="2">Two</option>
                                                            <option value="3">Three</option>
                                                        </select>
                                                    </div>
                                                </Tab>
                                            </Tabs>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="mb-3 col-12">
                                <label className="lbl-frnt-side">Select Audiance</label>
                                <div className="custom-dropdown-select">
                                    <select className="form-select input-custom-class" id="">
                                        <option selected>Choose...</option>
                                        <option value="1">One</option>
                                        <option value="2">Two</option>
                                        <option value="3">Three</option>
                                    </select>
                                </div>
                            </div>

                            <div className="mb-3 col-12">
                                <div className="refine-by-section">
                                    <div className="d-flex align-items-center">
                                        <div className="header-sec mb-3">
                                            <span>
                                                Refine By - <bdi>Optional</bdi>
                                            </span>
                                        </div>
                                        <div className="text-end mb-3 cursor-pointer ms-auto">
                                            <i className="bi bi-x-lg"></i>
                                        </div>
                                    </div>
                                    <div className="col-12 mb-3">
                                        <label className="lbl-frnt-side">Selection Type</label>
                                        <select name="furtherSelectRange" className="form-select input-custom-class">
                                            <option value="1">Percentile</option>
                                            <option value="2">Value</option>
                                        </select>
                                    </div>
                                    <div className="col-12 mb-3">
                                        <label className="lbl-frnt-side">Percentile</label>
                                        <select name="furtherPercentile" id="percentileSelect" className="form-select input-custom-class">
                                            <option value="10">10%</option>
                                            <option value="20">20%</option>
                                            <option value="30">30%</option>
                                            <option value="40">40%</option>
                                            <option value="50">50%</option>
                                            <option value="60">60%</option>
                                            <option value="70">70%</option>
                                            <option value="80">80%</option>
                                            <option defaultValue="90">90%</option>
                                        </select>
                                    </div>
                                    <div className="row align-items-center">
                                        <div className="col-md-4 mb-3">
                                            <input type="text" className="form-control input-custom-class" />
                                        </div>
                                        <div className="col-md-4 mb-3">
                                            <select name="furtherRelation" className="form-select input-custom-class">
                                                <option value=">">is greater than (&gt;)</option>
                                                <option value="=">equals (=)</option>
                                                <option value="<">is less than (&lt;)</option>
                                            </select>
                                        </div>
                                        <div className="col-md-4 mb-3">
                                            <input type="number" className="form-control input-custom-class" name="furtheValue" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="">
                                <div className="mb-3 col-12">
                                    <select name="selectFurtherRefined" className="form-select input-custom-class">
                                        <option id="further-refine" selected hidden>
                                            Further refine by
                                        </option>
                                        <option value="frequency">Frequency</option>
                                        <option value="visitorTime">Visitor by time spent</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="ms-auto">
                        <button id="removeButton" className="border-0 p-0 bg-transparent">
                            <svg width="34" height="36" viewBox="0 0 34 36" fill="none">
                                <rect y="2" width="34" height="34" rx="4" fill="#FFE7E7" />
                                <path d="M21.1667 27.3334H12.8333C11.9129 27.3334 11.1667 26.5872 11.1667 25.6667V14.8334H9.5V13.1667H12.8333V12.3334C12.8333 11.4129 13.5795 10.6667 14.5 10.6667H19.5C20.4205 10.6667 21.1667 11.4129 21.1667 12.3334V13.1667H24.5V14.8334H22.8333V25.6667C22.8333 26.5872 22.0871 27.3334 21.1667 27.3334ZM12.8333 14.8334V25.6667H21.1667V14.8334H12.8333ZM14.5 12.3334V13.1667H19.5V12.3334H14.5ZM19.5 24H17.8333V16.5H19.5V24ZM16.1667 24H14.5V16.5H16.1667V24Z" fill="#EA5455" />
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
        );
    }
}

export default IncludeVariationList;