import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import plusicon from "../../images/plus-icn.svg";
import toastr from "toastr";
import LanguageContext from "../../contexts/languageContext";
import { Formik } from "formik";
import * as Yup from "yup";
import { API_Path, locationArabic, locationEnglish, productArabic, productEnglish } from "../../const";
import { PostApi } from "../../helper/APIService";
import { confirmAlert } from "react-confirm-alert";
import { withRouter } from "react-router-dom";

export class EditNewCity extends Component {
    static contextType = LanguageContext;

    constructor(props) {
        super(props);
        this.state = {
            deliveryTimeApprox: "",
            shippingCompany: "",
            shippingCharges: "",
            cityEnglish: "",
            cityArabic: "",
            codStatus: true,
            onlineStatus: true,
            cityStatus: true,
            idToEdit: "",
            status: 1,
            areaArray: [],
            areaId: "",
            cityId: "",
            shippingCompanyData: []
        };
        this.innerInput = React.createRef();
        this.runforms = React.createRef();
    }

    componentDidMount = () => {
        this.getShippingData();
        let id = window.location.href?.split('/')?.pop()
        this.setState({ cityId: id }, () => {
            this.getShippingCityById()
            this.getShippingAreaByCityId()
        })
    };

    getShippingCityById = () => {
        let data = {
            id: this.state.cityId
        };

        let path = API_Path.getShippingCityById;
        const getShippingCityByIdPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        getShippingCityByIdPromise.then((res) => {
            if (res.data.success) {
                let data = res.data.data[0]
                this.setState({ cityEnglish: data.english, cityArabic: data.arabic, shippingCompany: data.shipping_company, deliveryTimeApprox: data.delivery_time, shippingCharges: data.shipping_charge, codStatus: data.cod_status === 0 ? false : true, onlineStatus: data.online_status === 0 ? false : true, cityStatus: data.status === 0 ? false : true });
            }
        });
    }

    getShippingAreaByCityId = () => {
        let data = {
            city_id: this.state.cityId
        };

        let path = API_Path.getShippingAreaByCityId;
        const getShippingAreaByCityIdPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        getShippingAreaByCityIdPromise.then((res) => {
            if (res.data.success) {
                this.setState({ areaArray: res.data.data })
            }
        });
    }

    getShippingData = () => {

        let data = {};

        let path = API_Path.getShippingCompany;
        const getShippingDataPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        getShippingDataPromise.then((res) => {
            if (res) {
                this.setState({ shippingCompanyData: res.data.data }, () => {
                    this.setState({ shippingCompany: this.state.shippingCompanyData[0].id }, () => {
                        if (this.innerInput.current) {
                            this.innerInput.current.setFieldValue("shippingCompany", this.state.shippingCompany);
                        }
                    })
                });
            }
        });
    };

    handleCheckBox = (e) => {
        this.setState({ [e.target.name]: e.target.checked, status: e.target.checked ? 1 : 0 });
    };

    errorContainer = (form, field) => {
        return form.touched[field] && form.errors[field] ? <span className="error text-danger">{form.errors[field]}</span> : null;
    };

    formAttr = (form, field) => ({
        onBlur: form.handleBlur,
        onChange: form.handleChange,
        value: form.values[field],
    });

    // -----------area-----------------
    editAreaById = (id) => {
        let path = API_Path.getShippingAreaById;
        let data = {
            id: id,
        };
        const getShippingAreaByIdPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        getShippingAreaByIdPromise.then((res) => {
            if (res) {
                if (res.data.success) {
                    this.setState({ area_english: res.data.data[0]?.english, area_arabic: res.data.data[0]?.arabic, areaId: res.data.data[0]?.id })
                } else {
                    toastr.error(res.data.message);
                }
            }
        });
    };

    editItem = (formData, resetForm) => {
        let path = API_Path.editShippingArea;
        let data = {
            id: this.state.areaId,
            english: formData.area_english,
            arabic: formData.area_arabic
        };
        const getShippingAreaByIdPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        getShippingAreaByIdPromise.then((res) => {
            if (res) {
                if (res.data.success) {
                    toastr.success(res.data.message)
                    this.setState({ areaId: '', area_english: '', area_arabic: '' })
                    this.getShippingAreaByCityId();
                } else {
                    toastr.error(res.data.message);
                }
            }
        });
    };

    deleteItem = (id) => {
        let path = API_Path.deleteShippingArea;
        let data = {
            id: id,
        };
        const deleteAreaPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        deleteAreaPromise.then((res) => {
            if (res) {
                if (res.data.success) {
                    toastr.success(res.data.message);
                    this.getShippingAreaByCityId();
                } else {
                    toastr.error(res.data.message);
                }
            }
        });
    };

    delete_record = (id) => {
        confirmAlert({
            customUI: ({ onClose }) => {
                return (
                    <div className="custom-ui">
                        <h1>Are you sure?</h1>
                        <p>You want to delete this file?</p>
                        <button className="btn red-btn me-2" onClick={onClose}>
                            No
                        </button>
                        <button
                            className="btn red-btn"
                            onClick={() => {
                                this.deleteItem(id);
                                onClose();
                            }}
                        >
                            Yes, Delete it!
                        </button>
                    </div>
                );
            },
        });
    };

    submitAreaFormData = (formData, resetForm) => {
        let path = API_Path.addShippingArea;
        let data = {
            english: formData.area_english,
            arabic: formData.area_arabic,
            city_id: this.state.cityId,
        };
        const addAreaPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        addAreaPromise.then((res) => {
            if (res) {
                if (res.data.success) {
                    toastr.success(res.data.message);
                    this.getShippingAreaByCityId();
                    this.setState({ areaId: '', area_english: '', area_arabic: '' })
                } else {
                    toastr.error(res.data.message);
                }
            }
        });
    }
    // -----------------------------

    submitFormData = (formData, resetForm) => {
        let data = {
            english: formData.cityEnglish,
            arabic: formData.cityArabic,
            shipping_charge: formData.shippingCharges,
            delivery_time: formData.deliveryTimeApprox,
            shipping_company: formData.shippingCompany,
            cod_status: this.state.codStatus,
            online_status: this.state.onlineStatus,
            id: this.state.cityId
        };

        const editCityDataPromise = new Promise((resolve, reject) => {
            resolve(PostApi(API_Path.editShippingCity, data));
        });

        editCityDataPromise.then((res) => {
            if (res) {
                if (res.data.success) {
                    if (this.context.language === "english") {
                        toastr.success(res.data.message);
                    } else {
                        toastr.success('تم تعديل مدينة بنجاح')
                    }
                    this.props.history.push('/location')
                } else {
                    toastr.error(res.data.message)
                }
            }
        });
    }

    render() {
        let locationLanguage = this.context.language === "english" ? locationEnglish : locationArabic;
        let productLanguage = this.context.language === "english" ? productEnglish : productArabic;
        return (
            <Adminlayout>
                <div className="container-fluid">
                    <div className="row common-space">
                        <div className="col-lg-6 mb-lg-0 mb-3">
                            <div className="row">
                                <div className="col-12 mb-3">
                                    <div className="common-header-txt">
                                        <h3>{locationLanguage.Areasincludedinthiscity}</h3>
                                    </div>
                                </div>
                                <div className="col-12 form-group">
                                    <div className="white-box">
                                        <div className="row">
                                            <div className="col-12">
                                                <Formik
                                                    innerRef={this.runforms}
                                                    enableReinitialize
                                                    initialValues={{
                                                        area_english: this.state.area_english,
                                                        area_arabic: this.state.area_arabic,
                                                    }}
                                                    validationSchema={Yup.object({
                                                        area_english: Yup.string().required("Required."),
                                                        area_arabic: Yup.string().required("Required."),
                                                    })}
                                                    onSubmit={(formData, { resetForm }) => {
                                                        if (this.state.areaId !== '') {
                                                            this.editItem(formData, resetForm)
                                                        } else {
                                                            this.submitAreaFormData(formData, resetForm);
                                                        }
                                                    }}
                                                >
                                                    {(runform) => (
                                                        <form onSubmit={runform.handleSubmit} autoComplete="off" className="row align-items-end mb-3 me-0">
                                                            <div className="col-md-6 pe-0">
                                                                <label>{locationLanguage.AreaNameinEnglish}</label>
                                                                <input type="text" className="form-control input-custom-class mb-0" value={this.state.area_english} name="area_english" placeholder="Enter Area Name" {...this.formAttr(runform, "area_english")} />
                                                                {this.errorContainer(runform, "area_english")}
                                                            </div>
                                                            <div className="col-md-5 pe-0 mt-3 mt-md-0">
                                                                <label>{locationLanguage.AreaNameinArabic}</label>
                                                                <input type="text" dir="rtl" className="form-control input-custom-class mb-0" value={this.state.area_arabic} name="area_arabic" placeholder="أدخل اسم المنطقة" {...this.formAttr(runform, "area_arabic")} />
                                                                {this.errorContainer(runform, "area_arabic")}
                                                            </div>
                                                            <div className="col-md pe-0 mt-2 position-relative">
                                                                <button className="btn light-red-btn mb-0" type="submit">
                                                                    <img src={plusicon} alt={plusicon} />
                                                                </button>
                                                            </div>
                                                        </form>
                                                    )}
                                                </Formik>
                                            </div>
                                        </div>
                                        <div className="cust-select-cate-drop">
                                            <ul>
                                                {
                                                    this.state.areaArray?.length > 0 &&
                                                    this.state.areaArray?.map((item, i) => {
                                                        return (
                                                            <li className="d-flex justify-content-between" key={item.id}>
                                                                <div>
                                                                    <span>{item.english}</span>
                                                                    <bdi className="mx-2">|</bdi>
                                                                    <span>{item.arabic}</span>
                                                                </div>
                                                                <div>
                                                                    <bdi onClick={() => this.editAreaById(item.id)} className="cursor-pointer" title="edit">
                                                                        <i class="bi bi-pencil-square" />
                                                                    </bdi>
                                                                    <mark onClick={() => this.delete_record(item.id)} className="ms-3 bg-transparent bi bi-x p-0" title="delete" />
                                                                </div>
                                                            </li>
                                                        );
                                                    })}
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6">
                            <div className="row">
                                <div className="col-12 mb-3">
                                    <div className="d-flex align-items-center">
                                        <div className="common-header-txt">
                                            <h3>{locationLanguage.CityDetails}</h3>
                                        </div>
                                        {/* <label className="switch ms-auto pop-switch">
                                            <input name="cityStatus" type="checkbox" id="cityStatus" onChange={this.handleCheckBox} value={this.state.cityStatus} />
                                            <div className="slider round" />
                                            <span className="text" />
                                        </label> */}
                                    </div>
                                </div>
                                <div className="col-12">
                                    <div className="white-box">
                                        <Formik
                                            innerRef={this.runforms}
                                            enableReinitialize
                                            initialValues={{
                                                cityEnglish: this.state.cityEnglish,
                                                cityArabic: this.state.cityArabic,
                                                shippingCharges: this.state.shippingCharges,
                                                shippingCompany: this.state.shippingCompany,
                                                deliveryTimeApprox: this.state.deliveryTimeApprox,
                                            }}
                                            validationSchema={Yup.object({
                                                cityArabic: Yup.string().required("Required."),
                                                cityEnglish: Yup.string().required("Required."),
                                                // shippingCharges: Yup.number().required("Required."),
                                                // shippingCompany: Yup.string().required(`Required.`),
                                                // deliveryTimeApprox: Yup.string().required("Required."),
                                            })}
                                            onSubmit={(formData, { resetForm }) => {
                                                this.submitFormData(formData, resetForm);
                                            }}
                                        >
                                            {(runform) => (
                                                <form onSubmit={runform.handleSubmit} autoComplete="off">
                                                    <div className="row modal-form">
                                                        <div className="col-md-6 form-group">
                                                            <label>{locationLanguage.cityNameinEnglish}</label>
                                                            <input name="cityEnglish" value={this.state.cityEnglish} type="text" className="form-control" placeholder="Enter City Name In Eglish"  {...this.formAttr(runform, "cityEnglish")} />
                                                            {this.errorContainer(runform, "cityEnglish")}
                                                        </div>
                                                        <div className="col-md-6 form-group">
                                                            <label>{locationLanguage.cityNameinArabic}</label>
                                                            <input name="cityArabic" value={this.state.cityArabic} type="text" className="form-control" placeholder="Enter City Name In Arabic"  {...this.formAttr(runform, "cityArabic")} />
                                                            {this.errorContainer(runform, "cityArabic")}
                                                        </div>
                                                        <div className="col-md-6 form-group form-group d-flex align-items-center mb-3">
                                                            <label>{locationLanguage.COD}</label>
                                                            <label className="switch ms-auto pop-switch">
                                                                <input name="codStatus" checked={this.state.codStatus} id="cod-status" onChange={this.handleCheckBox} type="checkbox" />
                                                                <div className="slider round" />
                                                                <span className="text" />
                                                            </label>
                                                        </div>
                                                        <div className="col-md-6 form-group form-group d-flex align-items-center mb-3">
                                                            <label>{locationLanguage.onlinePayment}</label>
                                                            <label className="switch ms-auto pop-switch">
                                                                <input name="onlineStatus" checked={this.state.onlineStatus} id="online-status" onChange={this.handleCheckBox} type="checkbox" />
                                                                <div className="slider round" />
                                                                <span className="text" />
                                                            </label>
                                                        </div>
                                                        <div className="col-md-6 form-group">
                                                            <label>{locationLanguage.shippingCharges}(SR)</label>
                                                            <input name="shippingCharges" value={this.state.shippingCharges} type="number" className="form-control" placeholder="SR100"  {...this.formAttr(runform, "shippingCharges")} />
                                                        </div>
                                                        <div className="col-md-6 form-group">
                                                            <label>{locationLanguage.deliveryTimeApprox}</label>
                                                            <input name="deliveryTimeApprox" value={this.state.deliveryTimeApprox} type="number" className="form-control" {...this.formAttr(runform, "deliveryTimeApprox")} />
                                                        </div>
                                                        <div className="col-md-12 form-group">
                                                            <label>{locationLanguage.shippingCompany}({locationLanguage.Default})</label>
                                                            <select name="shippingCompany" {...this.formAttr(runform, "shippingCompany")} value={this.state.shippingCompany} className="form-select form-control">
                                                                {this.state.shippingCompanyData &&
                                                                    this.state.shippingCompanyData.map((item, i) => {
                                                                        return (
                                                                            <>
                                                                                <option value={item.id} key={i}>
                                                                                    {item.english}
                                                                                </option>
                                                                            </>
                                                                        );
                                                                    })}
                                                            </select>
                                                        </div>
                                                        <div className="col-md-12 text-end form-group my-3">
                                                            <button id="addCityData" type="submit" className="btn red-btn px-5 ">
                                                                {locationLanguage.save}
                                                            </button>
                                                        </div>
                                                    </div>
                                                </form>
                                            )}
                                        </Formik>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </Adminlayout>
        );
    }
}

export default withRouter(EditNewCity);
