import React, { Component } from 'react';
import Adminlayout from '../../Components/AdminLayout/Adminlayout';
import SearchIcon from "../../images/search-icon.svg";
import MUITable from "../../Components/MUITable";
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";
import { Dropdown, Modal } from 'react-bootstrap';

class Automations extends Component {
    constructor(props) {
        super(props);
        this.state = {
            automations_modal: false,
        }
    }

    automations_modal = () => {
        this.setState({ automations_modal: true })
    }

    automation_close = () => {
        this.setState({ automations_modal: false })
    }

    render() {
        const options = {
            selectableRows: false,
            responsive: "standard",
            searchOpen: false,
            search: false,
            searchAlwaysOpen: false,
            print: false,
            serverSide: true,
            pagination: true,
            rowsPerPageOptions: [50, 100, 300, 500],
        };

        const columns = [
            {
                name: "title",
                label: "Title",
            },
            {
                name: "description",
                label: "Description",
            },
            {
                name: "created_on",
                label: "created on",
            },
            {
                name: "status",
                label: "Status",
                options: {
                    customBodyRender: (value, tableMeta, updateValue) => {
                        return (
                            <div className='staus-span-tag-new status-completed'>
                                Active
                            </div>
                        );
                    },
                }
            },
            {
                name: "action",
                label: "Action",
                options: {
                    customBodyRender: (value, tableMeta, updateValue) => {
                        return (
                            <div>
                                <Dropdown className="cust-drop">
                                    <Dropdown.Toggle className="bg-transparent" id="dropdown-basic" align="end">
                                        <svg width={16} height={16} fill="currentColor" className="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                            <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                        </svg>
                                    </Dropdown.Toggle>
                                    <Dropdown.Menu>
                                        <Dropdown.Item href="/create-automation" className='d-flex align-item-center'>
                                            <svg width="16" height="16" fill="currentColor" class="bi bi-pencil-fill" viewBox="0 0 16 16">
                                                <path d="M12.854.146a.5.5 0 0 0-.707 0L10.5 1.793 14.207 5.5l1.647-1.646a.5.5 0 0 0 0-.708l-3-3zm.646 6.061L9.793 2.5 3.293 9H3.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.207l6.5-6.5zm-7.468 7.468A.5.5 0 0 1 6 13.5V13h-.5a.5.5 0 0 1-.5-.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.5-.5V10h-.5a.499.499 0 0 1-.175-.032l-.179.178a.5.5 0 0 0-.11.168l-2 5a.5.5 0 0 0 .65.65l5-2a.5.5 0 0 0 .168-.11l.178-.178z" />
                                            </svg>
                                            <span>Edit</span>
                                        </Dropdown.Item>
                                        <Dropdown.Item className='d-flex align-item-center'>
                                            <svg width="16" height="16" fill="currentColor" class="bi bi-trash3-fill" viewBox="0 0 16 16">
                                                <path d="M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5Zm-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5ZM4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 0-.998.06Zm6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528ZM8 4.5a.5.5 0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5Z" />
                                            </svg>
                                            <span>Delete</span>
                                        </Dropdown.Item>
                                    </Dropdown.Menu>
                                </Dropdown>
                            </div>
                        );
                    },
                }
            },
        ];

        const data = [
            ["Two Notification check", "Two Notification", "March 30, 2023 11:38 AM", "", ""],
            ["Two Notification check", "Two Notification", "March 30, 2023 11:38 AM", "", ""],
            ["Two Notification check", "Two Notification", "March 30, 2023 11:38 AM", "", ""],
            ["Two Notification check", "Two Notification", "March 30, 2023 11:38 AM", "", ""],
            ["Two Notification check", "Two Notification", "March 30, 2023 11:38 AM", "", ""],
        ];

        const theme = createMuiTheme({
            palette: {
                primary: {
                    light: "#757ce8",
                    main: "#a81a1c",
                    dark: "#002884",
                    contrastText: "#fff",
                },
                secondary: {
                    light: "#ff7961",
                    main: "#f44336",
                    dark: "#ba000d",
                    contrastText: "#000",
                },
            },
        });

        return (
            <Adminlayout>
                <div className="container-fluid">
                    <div className="row common-space">
                        <div className="col-sm-6 text-sm-start text-center rtl-txt-start">
                            <div className="common-header-txt mb-sm-0 mb-2">
                                <h3>
                                    Automations
                                </h3>
                            </div>
                        </div>
                        <div className='col-sm-6 text-sm-end text-center rtl-txt-end'>
                            <button onClick={() => this.automations_modal()} type='button' className='btn red-btn'>Create Automation</button>
                        </div>
                    </div>
                    <div className='row common-space'>
                        <div className='col-12'>
                            <div className='white-box'>
                                <div className="custom-table">
                                    <div className=" dataTables_wrapper no-footer">
                                        <MuiThemeProvider theme={theme}>
                                            <div className="right-menu table-over-fix-class ms-auto position-relative">
                                                <MUITable
                                                    columns={columns}
                                                    data={data}
                                                    options={options}
                                                />
                                                <div className="fix-search d-flex align-items-center">
                                                    <div className="position-relative search-sm-screen" id="search-menu">
                                                        <input type="search" name="search" className="form-control top-search ps-5 input-custom-class mb-0" placeholder="" />
                                                        <span className="search-icn position-absolute ms-3">
                                                            <img src={SearchIcon} alt="" />
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </MuiThemeProvider>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <Modal show={this.state.automations_modal} className="cust-modal signout-modal" onHide={this.automation_close} size="md" centered>
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">Create Automation</h1>
                        </Modal.Title>
                        <button
                            type="button"
                            onClick={this.automation_close}
                            className="close btn-close"
                        ></button>
                    </Modal.Header>
                    <Modal.Body>
                        <form className=''>
                            <div className='form-group mb-3'>
                                <label className='lbl-frnt-side'>Title</label>
                                <input type='text' className='form-control input-custom-class' placeholder='' />
                            </div>
                            <div className='form-group mb-3'>
                                <label className='lbl-frnt-side'>Description</label>
                                <textarea rows={5} className='form-control input-custom-class h-auto' placeholder=''></textarea>
                            </div>
                            <div className='form-group py-3 text-center'>
                                <button type='button' className='btn red-btn'>submit</button>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>
            </Adminlayout >
        );
    }
}

export default Automations;