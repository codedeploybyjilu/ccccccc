import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import DataTable from "../../Components/DataTable";
import { textFilter } from "react-bootstrap-table2-filter";
import { confirmAlert } from "react-confirm-alert";
import { Modal, Dropdown, ModalFooter } from "react-bootstrap";
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";
import SearchIcon from "../../images/search-icon.svg";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Link } from "react-router-dom";
import Moment from "moment";
import loader from "../../images/loader.gif";
import {
  API_Path,
  buttonArabic,
  productArabic,
  productEnglish,
  buttonEnglish,
  orderArabic,
  orderEnglish,
  DashboardArabic,
  DashboardEnglish,
  TableFieldArabic,
  TableFieldEnglish,
  titleArabic,
  titleEnglish,
  UserEnglish,
  UserArabic,
} from "../../const";
import LanguageContext from "../../contexts/languageContext";
import MUITable from "../../Components/MUITable";
import { PostApi } from "../../helper/APIService";

const paymentMethods = [
  { id: "CARDPAYMENT", name: "Card Payment" },
  { id: "APPLEPAY", name: "Apple Pay" },
  { id: "COD", name: "COD" },
  { id: "TABBY", name: "Tabby" },
  { id: "TAMARA", name: "Tamara" },
];

const theme = createMuiTheme({
  palette: {
    primary: {
      light: "#757ce8",
      main: "#a81a1c",
      dark: "#002884",
      contrastText: "#fff",
    },
    secondary: {
      light: "#ff7961",
      main: "#f44336",
      dark: "#ba000d",
      contrastText: "#000",
    },
  },
});

class Orders extends Component {
  static contextType = LanguageContext;
  constructor(props) {
    super(props);
    this.state = {
      changeStatus: false,
      AssignTeam: false,
      search_show: false,
      edit_show: false,
      search_val: "",
      page: 1,
      sizePerPage: 100,
      totalSize: 0,
      totalPage: 1,
      AllCity: "",
      AllArea: "",
      defaultSorted: [
        {
          dataField: "id",
          order: "desc",
        },
      ],
      order_data: [],
      CustomerFilterShippingCompany: null,
      CustomerFilterEmail: null,
      CustomerFilterCity: null,
      CustomerFilterArea: null,
      customFilterPaymentMethod: null,
      OrderFilterStaus: null,
      CustomerFilterName: null,
      NumberFilter: [],
      OrderStatus: null,
      CustomerFilterFromDate: null,
      CustomerFilterToDate: null,
      Order_Tab: "",
      Order_ids: "",
      paymentCheckedData: "",
      paymentcheckpopup: false,
      paymentCheckedloader: false,
      Loader: true,
      orderItemsData: [],
      orderItemsLoader: true,
      orderItemDataLoader: false,
      orderItemsPage: 1,
      hoverId: "",
      callITems: false,
    };
    this.getData = "";
    this.timeOut = "";
    this.itemsRef = React.createRef();
  }

  componentDidMount() {
    let url = window.location.href;
    if (url.includes("?")) {
      let idString = url.split("?")[1];
      this.setState({ search_val: idString.replaceAll("%20", " ") }, () => {
        setTimeout(() => {
          console.log(document.getElementById("all-order"), "[[=[");
          document.getElementById("all-order").checked = true;
        }, 1200);
        this.get_order_data(this.state.page, this.state.sizePerPage, "");
      });
    } else {
      this.get_order_data(this.state.page, this.state.sizePerPage, "1");
    }
    this.get_city_and_area();
    this.get_order_count();
  }

  edit_filterClose = () => {
    this.setState({ search_show: false });
  };

  editfilter_Show = (e) => {
    e.preventDefault();
    this.setState({ search_show: true });
  };

  filter_handleShow = (e) => {
    e.preventDefault();
    this.setState({ search_show: true });
  };

  // edit_handleShow = (e) => {
  //     e.preventDefault()
  //     this.setState({ edit_show: true });
  // }
  // edit_Close = () => {
  //     this.setState({ edit_show: false });
  // }

  // edit_Show = (e) => {
  //     e.preventDefault()
  //     this.setState({ edit_show: true });
  // }

  get_order_count = () => {
    new Promise((resolve) => {
      resolve(PostApi(API_Path.getOrderCount, {}));
    }).then((res) => {
      if (res) {
        if (res.data.success) {
          let Count_data = res.data.data;
          let order_tab = [
            {
              status: 1,
              labelEng: "Pending",
              labelArb: "في الإنتظار",
              id: "pending",
            },
            {
              status: 2,
              labelEng: "Prepared",
              labelArb: "تم التجهيز",
              id: "prepared",
            },
            {
              status: 3,
              labelEng: "Ready To Ship",
              labelArb: "جاحز للشحن",
              id: "ready-to-ship",
            },
            {
              status: 4,
              labelEng: "Shipped",
              labelArb: "تم الشحن",
              id: "shipped",
            },
            {
              status: 5,
              labelEng: "Delivered",
              labelArb: "تم التوصيل",
              id: "delivered",
            },
            {
              status: 6,
              labelEng: "Cancelled",
              labelArb: "ملغى",
              id: "cancelled",
            },
            // { status: 7, labelEng: 'Archieved', labelArb: 'تمت الأرشفة', id: 'archieved' },
            {
              status: 10,
              labelEng: "Refund",
              labelArb: "المسترد",
              id: "refund",
            },
            {
              status: 11,
              labelEng: "Pending Payment",
              labelArb: "في انتظار الدفع",
              id: "panding-payment",
            },
            {
              status: "",
              labelEng: "All Orders",
              labelArb: "الكل الطلبات",
              id: "all-order",
            },
          ];
          let AllCount = Count_data?.reduce((prev, cur) => {
            return prev + cur.count;
          }, 0);
          for (let i = 0; i < order_tab.length; i++) {
            let checked = Count_data?.findIndex(
              (e) => e.status === order_tab[i].status
            );
            if (checked != -1) {
              order_tab[i].count = Count_data[checked]?.count;
            } else {
              order_tab[i].count = AllCount;
            }
          }
          this.setState({ Order_Tab: order_tab }, () => {
            document.getElementById("pending").checked = true;
          });
        }
      }
    });
  };

  get_city_and_area = () => {
    let city_path = API_Path.getCityData;
    let area_path = API_Path.getArea;
    const getCity = new Promise((resolve) => {
      resolve(PostApi(city_path));
    });
    const getArea = new Promise((resolve) => {
      resolve(PostApi(area_path));
    });
    Promise.all([getCity, getArea]).then((res) => {
      if (res[0] && res[1]) {
        this.setState({ AllCity: res[0].data.data, AllArea: res[1].data.data });
      }
    });
  };

  get_order_data = (page, limit, status) => {
    const data = {
      sizePerPage: limit,
      page: page,
      defaultSorted: this.state.defaultSorted,
      searchText: this.state.search_val,
      state: status,
      order_id: this.state.NumberFilter,
      name: this.state.CustomerFilterName,
      pay_method: this.state.customFilterPaymentMethod,
      from: this.state.CustomerFilterFromDate,
      to: this.state.CustomerFilterToDate,
      city_id: this.state.CustomerFilterCity,
      area_id: this.state.CustomerFilterArea,
    };
    let path = API_Path.getOrder;

    const getOrderPromise = new Promise((resolve) => {
      resolve(PostApi(path, data));
    });
    getOrderPromise.then((res) => {
      if (res.data.success) {
        if (document.querySelector('button[aria-label="Close"]')) {
          document.querySelector('button[aria-label="Close"]').click();
        }
        this.setState({
          order_data: res.data.data,
          totalSize: res.data.totalRecord,
          Loader: false,
        });
      } else {
        this.setState({ order_data: [], Loader: false });
      }
    });
  };

  filterChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  filterStartDateChange = (e) => {
    this.setState({ CustomerFilterFromDate: Moment(e).format("YYYY-MM-DD") });
  };

  filterEndDateChange = (e) => {
    this.setState({ CustomerFilterToDate: Moment(e).format("YYYY-MM-DD") });
  };

  numberfilterChange = (e) => {
    if (e.target.value.includes(",")) {
      this.setState({ NumberFilter: e.target.value.split(",") });
    } else {
      this.setState({ NumberFilter: [e.target.value] });
    }
  };

  delete_record = (id) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>Are you sure?</h1>
            <p>You want to delete this file?</p>
            <button className="btn red-btn me-2" onClick={onClose}>
              No
            </button>
            <button
              className="btn red-btn"
              onClick={() => {
                this.finaly_delete_record(id);
                onClose();
              }}
            >
              Yes, Delete it!
            </button>
          </div>
        );
      },
    });
  };

  finaly_delete_record = (id) => {};

  changeStatus = () => {
    this.setState({ changeStatus: true });
  };

  changeStatusClose = () => {
    this.setState({ changeStatus: false });
  };

  AssignTeam = () => {
    this.setState({ AssignTeam: true });
  };

  AssignTeamClose = () => {
    this.setState({ AssignTeam: false });
  };

  PaymentCheckModal = () => {
    this.setState({ paymentcheckpopup: true });
  };
  PaymentCheckModalClose = () => {
    this.setState({ paymentcheckpopup: false }, () => {
      this.get_order_data(
        this.state.page,
        this.state.sizePerPage,
        this.state.OrderStatus
      );
    });
  };

  // onChangeTable = (action, tableState) => {
  //   switch (action) {
  //     case "changePage":
  //       this.changePage(tableState.page)
  //       break;

  //     default:
  //       break;
  //   }
  // }

  selectSatus = (e) => {
    this.setState({ Loader: true });
    // for (let i = 0; i < this.state.Order_Tab.length; i++) {
    //   if (document.getElementById(this.state.Order_Tab[i].id)) {
    //     document.getElementById(this.state.Order_Tab[i].id).checked = false
    //   }

    // }
    let status;
    switch (e.target.id) {
      case "pending":
        status = "1";
        break;
      case "prepared":
        status = "2";
        break;
      case "ready-to-ship":
        status = "3";
        break;
      case "shipped":
        status = "4";
        break;
      case "delivered":
        status = "5";
        break;
      case "cancelled":
        status = "6";
        break;
      case "archieved":
        status = "7";
        break;
      case "returned":
        status = "8";
        break;
      case "partially-returned":
        status = "9";
        break;
      case "refund":
        status = "10";
        break;
      case "panding-payment":
        status = "11";
        break;
      case "disputed":
        status = "12";
        break;

      default:
        break;
    }
    this.setState({ OrderStatus: status }, () => {
      this.get_order_data(
        this.state.page,
        this.state.sizePerPage,
        this.state.OrderStatus
      );
    });
  };

  filterType = (e) => {};

  clearFilter = () => {
    this.setState(
      {
        CustomerFilterShippingCompany: null,
        CustomerFilterEmail: null,
        CustomerFilterCity: null,
        CustomerFilterArea: null,
        OrderFilterStaus: null,
        CustomerFilterName: null,
        NumberFilter: [],
        OrderStatus: null,
        CustomerFilterFromDate: null,
        CustomerFilterToDate: null,
      },
      () => {
        this.get_order_data(
          this.state.page,
          this.state.sizePerPage,
          this.state.OrderStatus
        );
      }
    );
  };
  handleSearch = (e) => {
    this.setState({ search_val: e.target.value }, () => {
      clearTimeout(this.getData);
      this.getData = setTimeout(() => {
        this.get_order_data(
          this.state.page,
          this.state.sizePerPage,
          this.state.OrderStatus
        );
      }, 500);
    });
  };
  handlePaymentCheck = (id) => {
    this.setState({ paymentCheckedloader: true });
    this.PaymentCheckModal();
    let P_checkReq = {
      order_id: id,
    };
    new Promise((resolve) => {
      resolve(PostApi(API_Path.PaymentCheck, P_checkReq));
    }).then((res) => {
      if (res.data.success) {
        this.setState({
          paymentCheckedData: res.data.data,
          paymentCheckedloader: false,
        });
      }
    });
  };
  getOrderItems = (id) => {
    clearTimeout(this.timeOut);
    let reqData = {
      order_id: id,
      page: 1,
      sizePerPage: 7,
    };
    this.setState(
      {
        orderItemsPage: 1,
        orderItemsLoader: true,
        hoverId: id,
        callITems: false,
      },
      () => {
        this.timeOut = setTimeout(() => {
          new Promise((resolve) => {
            resolve(PostApi(API_Path.getItemsById, reqData));
          }).then((res) => {
            if (res.data.data.order_items.length > 0) {
              this.setState({
                orderItemsData: res.data.data.order_items,
                orderItemsLoader: false,
              });
            }
          });
          console.log(id, "idd");
        }, 1000);
      }
    );
  };
  clearEvent = () => {
    clearTimeout(this.timeOut);
  };
  ScrollItems = (e) => {
    const bottom =
      e.target.scrollHeight - e.target.scrollTop === e.target.clientHeight;
    // console.log(e.target.scrollHeight, ":: e.target.scrollHeight", e.target.scrollTop, '::e.target.scrollTop');
    // console.log(!this.state.callITems, "!this.state.callITems");
    if (!this.state.callITems) {
      // console.log(!this.state.callITems, "!this.state.callITems");
      if (e.target.scrollTop == 1) {
        this.setState({ orderItemDataLoader: true });
      }
      if (bottom) {
        this.setState(
          {
            orderItemsPage: this.state.orderItemsPage + 1,
            orderItemDataLoader: true,
          },
          () => {
            let reqData = {
              order_id: this.state.hoverId,
              page: this.state.orderItemsPage,
              sizePerPage: 7,
            };
            new Promise((resolve) => {
              resolve(PostApi(API_Path.getItemsById, reqData));
            }).then((res) => {
              if (res.data.data.order_items.length > 0) {
                let reData = [
                  ...this.state.orderItemsData,
                  ...res.data.data.order_items,
                ];
                this.setState({
                  orderItemsData: reData,
                  orderItemsLoader: false,
                });
              } else {
                this.setState({ orderItemDataLoader: false, callITems: true });
              }
            });

            console.log(this.state.orderItemsPage, "orderItemsPage");
          }
        );
      }
    }
    // if (this.itemsRef.current) {
    //   const { scrollTop, scrollHeight, clientHeight } = this.itemsRef.current;
    //   const isNearBottom = scrollTop - scrollHeight == clientHeight;

    //   if (isNearBottom) {
    //     console.log("Reached bottom");
    //     // DO SOMETHING HERE
    //   }
    // }
    // console.log(e, "[=][");
  };

  render() {
    let Language =
      this.context.language === "english"
        ? TableFieldEnglish
        : TableFieldArabic;
    let titleLanguage =
      this.context.language === "english" ? titleEnglish : titleArabic;
    let ButtonLanguage =
      this.context.language === "english" ? buttonEnglish : buttonArabic;
    let orderLanguage =
      this.context.language === "english" ? orderEnglish : orderArabic;
    let DashboardLanguage =
      this.context.language === "english" ? DashboardEnglish : DashboardArabic;
    let productLanguage =
      this.context.language === "english" ? productEnglish : productArabic;
    let userLanguage =
      this.context.language === "english" ? UserEnglish : UserArabic;
    let columns;
    if (this.state.OrderStatus == "11") {
      columns = [
        {
          label: orderLanguage.order,
          name: "id",
          options: {
            filter: true,
            customBodyRender: (value) => {
              return (
                <>
                  <Link to={"order-details/" + value}>
                    <a className="fw-bold dark-red-txt">{value}</a>
                  </Link>
                </>
              );
            },
          },
        },
        {
          label: orderLanguage.customerName,
          name: "first_name",
          options: {
            filter: true,
            customBodyRender: (value, tableMeta, updateValue) => {
              let data = this.state.order_data[tableMeta.rowIndex];
              let lastName = data.last_name ? data.last_name : "";
              const address = JSON.parse(data.address ?? "{}");
              // let id;
              // this.state.order_data && this.state.order_data.map((item) => id = item.id)
              return (
                <>
                  <div className="cust-drop hover-new position-relative">
                    <div className="order-cust-name d-flex align-items-center">
                      <div className="tble-name-fix">
                        {value + " " + lastName}
                      </div>
                      <bdi
                        className={`${
                          data.mark?.replace("Customer", " ").includes("New")
                            ? "new-class"
                            : data.mark
                                ?.replace("Customer", " ")
                                .includes("Bad")
                            ? "bad-class"
                            : data.mark
                                ?.replace("Customer", " ")
                                .includes("Premium")
                            ? "vip-class"
                            : ""
                        }`}
                      >
                        {data.mark.replace("Customer", " ").includes("New")
                          ? "New"
                          : data.mark.replace("Customer", " ").includes("Bad")
                          ? "Bad"
                          : data.mark
                              .replace("Customer", " ")
                              .includes("Premium")
                          ? "Vip"
                          : ""}
                      </bdi>
                      <i className="bi bi-chevron-down ms-2"></i>
                    </div>
                    <div className="hover-dropdown">
                      <div className="p-3 border-bottom">
                        <div className="name-text">{value}</div>
                        <div className="grey-text">
                          {address.area_en},{address.city_en}
                        </div>
                        <div className="grey-text">
                          {data.user_orders} Orders
                        </div>
                        <div className="red-txt text-decoration-underline">
                          {data.email}
                        </div>
                      </div>
                      <div className="p-3">
                        <a href={`user-details/${address.user_id}`}>
                          <button className="red-border-btn w-100">
                            {" "}
                            View Customer
                          </button>
                        </a>
                      </div>
                    </div>
                  </div>
                </>
              );
            },
          },
        },
        {
          label: orderLanguage.date,
          name: "createdat",
          options: {
            filter: true,
            customBodyRender: (value) => {
              return <>{Moment(value).format("DD/MM/YYYY hh:mm A")}</>;
            },
          },
        },
        {
          label: orderLanguage.cityArea,
          name: "CityName",
          options: {
            filter: true,
            customBodyRender: (value, tableMeta, updateValue) => {
              let data = this.state.order_data[tableMeta.rowIndex];
              const address = JSON.parse(data.address ?? "{}");
              // let id;
              // this.state.order_data && this.state.order_data.map((item) => id = item.id)
              if (this.context.language === "english") {
                return (
                  <span>
                    {address.city_en} - {address.area_en}
                  </span>
                );
              } else {
                return (
                  <span>
                    {address.city_ar} - {address.area_ar}
                  </span>
                );
              }
            },
          },
        },
        {
          label: orderLanguage.phoneNumber,
          name: "phone",
          options: {
            filter: true,
            customBodyRender: (value) => {
              if (value) {
                return (
                  <>
                    {value.substring(0, 3) !== "966"
                      ? 0 + value
                      : 0 + value.substring(0, 3)}
                  </>
                );
              }
            },
          },
        },
        {
          label: orderLanguage.value,
          name: "total_paymentable_price",
          options: {
            filter: true,
            sort: false,
            customBodyRender: (value) => {
              return <>{Number(value).toFixed(2) + " "}</>;
            },
          },
        },
        {
          label: orderLanguage.payMethod,
          name: "pay_method",
          options: {
            filter: true,
            sort: false,
            customBodyRender: (value, tableMeta, updateValue) => {
              let data = this.state.order_data[tableMeta.rowIndex];
              if (this.context.language === "english") {
                return (
                  <span>
                    {value === "COD"
                      ? "COD"
                      : value === "cardPayment"
                      ? "Card Payment"
                      : value === "APPLEPAY"
                      ? "Apple Pay"
                      : value}
                    {data.wallet_cost != 0 && (
                      <bdi className="ms-2">
                        <svg
                          width="26"
                          height="17"
                          viewBox="0 0 26 17"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M8.33128 9.52948L9.8615 4.70068H10.9013L12.4315 9.52948L14.1579 4.70068H15.4036L13.0102 11.4111H11.8625L10.4206 6.81268H10.3421L8.90021 11.4111H7.75255L5.35913 4.70068H6.60488L8.33128 9.52948Z"
                            fill="#2D2D3B"
                          />
                          <path
                            d="M2.8167 11.7773C2.8167 11.8812 2.73054 11.9655 2.62439 11.9655C2.51824 11.9655 2.43208 11.8812 2.43208 11.7773V10.2935C2.43208 10.1896 2.51824 10.1053 2.62439 10.1053C2.73054 10.1053 2.8167 10.1896 2.8167 10.2935V11.7773ZM2.62439 8.99784C2.73054 8.99784 2.8167 8.91352 2.8167 8.80963V7.32579C2.8167 7.2219 2.73054 7.13758 2.62439 7.13758C2.51824 7.13758 2.43208 7.2219 2.43208 7.32579V8.80963C2.43208 8.91352 2.51824 8.99784 2.62439 8.99784ZM4.18247 13.9285C3.73862 13.7719 3.35901 13.4772 3.11401 13.0985C3.05747 13.0108 2.93862 12.9845 2.84862 13.0402C2.75901 13.0955 2.73208 13.2122 2.78901 13.2999C3.07939 13.749 3.52785 14.0979 4.05208 14.2824C4.07362 14.2903 4.09554 14.2937 4.11708 14.2937C4.19593 14.2937 4.26978 14.2459 4.29785 14.1691C4.33401 14.0716 4.28247 13.9639 4.18247 13.9285ZM5.59247 2.05595H7.10862C7.21478 2.05595 7.30093 1.97163 7.30093 1.86774C7.30093 1.76385 7.21478 1.67953 7.10862 1.67953H5.59247C5.48631 1.67953 5.40016 1.76385 5.40016 1.86774C5.40016 1.97163 5.48631 2.05595 5.59247 2.05595ZM17.7221 2.05595H19.2382C19.3444 2.05595 19.4305 1.97163 19.4305 1.86774C19.4305 1.76385 19.3444 1.67953 19.2382 1.67953H17.7221C17.6159 1.67953 17.5298 1.76385 17.5298 1.86774C17.5298 1.97163 17.6159 2.05595 17.7221 2.05595ZM20.6063 2.33261C21.019 2.5611 21.3386 2.91531 21.5059 3.32937C21.5359 3.40314 21.6082 3.44832 21.6848 3.44832C21.7086 3.44832 21.7325 3.44417 21.7555 3.43514C21.8544 3.39675 21.9025 3.28758 21.8636 3.19085C21.664 2.69699 21.2848 2.27577 20.7959 2.00513C20.7032 1.95394 20.5863 1.98593 20.5336 2.0759C20.4817 2.16661 20.514 2.28142 20.6063 2.33261ZM2.62439 6.02979C2.73054 6.02979 2.8167 5.94547 2.8167 5.84158V4.35774C2.8167 4.25385 2.73054 4.16953 2.62439 4.16953C2.51824 4.16953 2.43208 4.25385 2.43208 4.35774V5.84158C2.43208 5.94584 2.51824 6.02979 2.62439 6.02979ZM7.13324 14.0554H5.61708C5.51093 14.0554 5.42478 14.1397 5.42478 14.2436C5.42478 14.3475 5.51093 14.4318 5.61708 14.4318H7.13324C7.23939 14.4318 7.32555 14.3475 7.32555 14.2436C7.32555 14.1397 7.23939 14.0554 7.13324 14.0554ZM2.83747 3.09222C2.86901 3.11142 2.90362 3.12046 2.93824 3.12046C3.00247 3.12046 3.06593 3.08884 3.10208 3.03124C3.34247 2.65031 3.71901 2.35143 4.16131 2.1907C4.26093 2.15457 4.3117 2.04616 4.27439 1.94867C4.23708 1.85155 4.1267 1.80149 4.02708 1.838C3.50478 2.02809 3.05978 2.38192 2.77478 2.834C2.71939 2.92171 2.74708 3.03764 2.83747 3.09222ZM21.7629 12.6532C21.6644 12.6163 21.5525 12.6645 21.5144 12.7616C21.3517 13.1772 21.0359 13.5348 20.6255 13.7678C20.5336 13.8201 20.5025 13.9353 20.5555 14.0253C20.5913 14.0855 20.6559 14.119 20.7221 14.119C20.7548 14.119 20.7879 14.1107 20.8182 14.0938C21.3044 13.8175 21.679 13.3921 21.8729 12.8964C21.9117 12.7993 21.8621 12.6905 21.7629 12.6532ZM16.2302 14.0554H14.714C14.6079 14.0554 14.5217 14.1397 14.5217 14.2436C14.5217 14.3475 14.6079 14.4318 14.714 14.4318H16.2302C16.3363 14.4318 16.4225 14.3475 16.4225 14.2436C16.4225 14.1397 16.3367 14.0554 16.2302 14.0554ZM19.2629 14.0554H17.7467C17.6405 14.0554 17.5544 14.1397 17.5544 14.2436C17.5544 14.3475 17.6405 14.4318 17.7467 14.4318H19.2629C19.369 14.4318 19.4552 14.3475 19.4552 14.2436C19.4552 14.1397 19.369 14.0554 19.2629 14.0554ZM14.6898 2.05595H16.2059C16.3121 2.05595 16.3982 1.97163 16.3982 1.86774C16.3982 1.76385 16.3121 1.67953 16.2059 1.67953H14.6898C14.5836 1.67953 14.4975 1.76385 14.4975 1.86774C14.4975 1.97163 14.5836 2.05595 14.6898 2.05595ZM8.62516 2.05595H10.1413C10.2475 2.05595 10.3336 1.97163 10.3336 1.86774C10.3336 1.76385 10.2475 1.67953 10.1413 1.67953H8.62516C8.51901 1.67953 8.43285 1.76385 8.43285 1.86774C8.43285 1.97163 8.51862 2.05595 8.62516 2.05595ZM13.1979 14.0554H11.6817C11.5755 14.0554 11.4894 14.1397 11.4894 14.2436C11.4894 14.3475 11.5755 14.4318 11.6817 14.4318H13.1979C13.304 14.4318 13.3902 14.3475 13.3902 14.2436C13.3902 14.1397 13.3044 14.0554 13.1979 14.0554ZM10.1655 14.0554H8.64939C8.54324 14.0554 8.45708 14.1397 8.45708 14.2436C8.45708 14.3475 8.54324 14.4318 8.64939 14.4318H10.1655C10.2717 14.4318 10.3579 14.3475 10.3579 14.2436C10.3579 14.1397 10.2717 14.0554 10.1655 14.0554ZM11.6575 2.05595H13.1736C13.2798 2.05595 13.3659 1.97163 13.3659 1.86774C13.3659 1.76385 13.2798 1.67953 13.1736 1.67953H11.6575C11.5513 1.67953 11.4652 1.76385 11.4652 1.86774C11.4652 1.97163 11.5509 2.05595 11.6575 2.05595ZM23.8498 10.6755V13.0443C23.8498 14.7047 22.4694 16.0557 20.7729 16.0557H3.7217C2.02516 16.0557 0.644775 14.7047 0.644775 13.0443V3.067C0.644775 1.40663 2.02516 0.0556641 3.7217 0.0556641H20.7729C22.4694 0.0556641 23.8498 1.40663 23.8498 3.067V5.4358C24.9075 5.89277 25.6448 6.89404 25.6448 8.05567C25.6448 9.21729 24.9075 10.2186 23.8498 10.6755ZM23.0805 10.898C22.9132 10.9243 22.7429 10.9413 22.5679 10.9413H22.0229V11.3602C22.0229 11.4641 21.9367 11.5484 21.8305 11.5484C21.7244 11.5484 21.6382 11.4641 21.6382 11.3602V10.9413H19.2344C17.5379 10.9413 16.1575 9.64678 16.1575 8.05529C16.1575 6.4638 17.5379 5.1693 19.2344 5.1693H21.6382V4.74921C21.6382 4.64532 21.7244 4.561 21.8305 4.561C21.9367 4.561 22.0229 4.64532 22.0229 4.74921V5.1693H22.5679C22.7429 5.1693 22.9136 5.18623 23.0805 5.21258V3.06625C23.0805 1.82069 22.0455 0.807746 20.7729 0.807746H3.7217C2.44901 0.807746 1.41401 1.82069 1.41401 3.06625V13.0436C1.41401 14.2891 2.44901 15.3021 3.7217 15.3021H20.7729C22.0455 15.3021 23.0805 14.2891 23.0805 13.0436V10.898ZM24.8755 8.05567C24.8755 6.87936 23.8405 5.92251 22.5679 5.92251H19.2344C17.9617 5.92251 16.9267 6.87936 16.9267 8.05567C16.9267 9.23197 17.9617 10.1888 19.2344 10.1888H22.5679C23.8405 10.1888 24.8755 9.23197 24.8755 8.05567ZM20.6848 8.05567C20.6848 8.78215 20.0809 9.37313 19.3386 9.37313C18.5963 9.37313 17.9925 8.78215 17.9925 8.05567C17.9925 7.32918 18.5963 6.7382 19.3386 6.7382C20.0809 6.7382 20.6848 7.32956 20.6848 8.05567ZM19.9155 8.05567C19.9155 7.74437 19.6567 7.49104 19.3386 7.49104C19.0205 7.49104 18.7617 7.74437 18.7617 8.05567C18.7617 8.36696 19.0205 8.62029 19.3386 8.62029C19.6567 8.62029 19.9155 8.36696 19.9155 8.05567Z"
                            fill="#2D2D3B"
                          />
                        </svg>
                      </bdi>
                    )}
                  </span>
                );
              } else {
                return (
                  <span>
                    {value === "COD"
                      ? "الدفع عند الإستلام"
                      : value === "cardPayment"
                      ? "بطاقة ائتمان"
                      : value === "APPLEPAY"
                      ? "أبل باي"
                      : "محفظة"}
                    {data.wallet_cost != 0 && (
                      <bdi className="ms-2">
                        <svg
                          width="26"
                          height="17"
                          viewBox="0 0 26 17"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M8.33128 9.52948L9.8615 4.70068H10.9013L12.4315 9.52948L14.1579 4.70068H15.4036L13.0102 11.4111H11.8625L10.4206 6.81268H10.3421L8.90021 11.4111H7.75255L5.35913 4.70068H6.60488L8.33128 9.52948Z"
                            fill="#2D2D3B"
                          />
                          <path
                            d="M2.8167 11.7773C2.8167 11.8812 2.73054 11.9655 2.62439 11.9655C2.51824 11.9655 2.43208 11.8812 2.43208 11.7773V10.2935C2.43208 10.1896 2.51824 10.1053 2.62439 10.1053C2.73054 10.1053 2.8167 10.1896 2.8167 10.2935V11.7773ZM2.62439 8.99784C2.73054 8.99784 2.8167 8.91352 2.8167 8.80963V7.32579C2.8167 7.2219 2.73054 7.13758 2.62439 7.13758C2.51824 7.13758 2.43208 7.2219 2.43208 7.32579V8.80963C2.43208 8.91352 2.51824 8.99784 2.62439 8.99784ZM4.18247 13.9285C3.73862 13.7719 3.35901 13.4772 3.11401 13.0985C3.05747 13.0108 2.93862 12.9845 2.84862 13.0402C2.75901 13.0955 2.73208 13.2122 2.78901 13.2999C3.07939 13.749 3.52785 14.0979 4.05208 14.2824C4.07362 14.2903 4.09554 14.2937 4.11708 14.2937C4.19593 14.2937 4.26978 14.2459 4.29785 14.1691C4.33401 14.0716 4.28247 13.9639 4.18247 13.9285ZM5.59247 2.05595H7.10862C7.21478 2.05595 7.30093 1.97163 7.30093 1.86774C7.30093 1.76385 7.21478 1.67953 7.10862 1.67953H5.59247C5.48631 1.67953 5.40016 1.76385 5.40016 1.86774C5.40016 1.97163 5.48631 2.05595 5.59247 2.05595ZM17.7221 2.05595H19.2382C19.3444 2.05595 19.4305 1.97163 19.4305 1.86774C19.4305 1.76385 19.3444 1.67953 19.2382 1.67953H17.7221C17.6159 1.67953 17.5298 1.76385 17.5298 1.86774C17.5298 1.97163 17.6159 2.05595 17.7221 2.05595ZM20.6063 2.33261C21.019 2.5611 21.3386 2.91531 21.5059 3.32937C21.5359 3.40314 21.6082 3.44832 21.6848 3.44832C21.7086 3.44832 21.7325 3.44417 21.7555 3.43514C21.8544 3.39675 21.9025 3.28758 21.8636 3.19085C21.664 2.69699 21.2848 2.27577 20.7959 2.00513C20.7032 1.95394 20.5863 1.98593 20.5336 2.0759C20.4817 2.16661 20.514 2.28142 20.6063 2.33261ZM2.62439 6.02979C2.73054 6.02979 2.8167 5.94547 2.8167 5.84158V4.35774C2.8167 4.25385 2.73054 4.16953 2.62439 4.16953C2.51824 4.16953 2.43208 4.25385 2.43208 4.35774V5.84158C2.43208 5.94584 2.51824 6.02979 2.62439 6.02979ZM7.13324 14.0554H5.61708C5.51093 14.0554 5.42478 14.1397 5.42478 14.2436C5.42478 14.3475 5.51093 14.4318 5.61708 14.4318H7.13324C7.23939 14.4318 7.32555 14.3475 7.32555 14.2436C7.32555 14.1397 7.23939 14.0554 7.13324 14.0554ZM2.83747 3.09222C2.86901 3.11142 2.90362 3.12046 2.93824 3.12046C3.00247 3.12046 3.06593 3.08884 3.10208 3.03124C3.34247 2.65031 3.71901 2.35143 4.16131 2.1907C4.26093 2.15457 4.3117 2.04616 4.27439 1.94867C4.23708 1.85155 4.1267 1.80149 4.02708 1.838C3.50478 2.02809 3.05978 2.38192 2.77478 2.834C2.71939 2.92171 2.74708 3.03764 2.83747 3.09222ZM21.7629 12.6532C21.6644 12.6163 21.5525 12.6645 21.5144 12.7616C21.3517 13.1772 21.0359 13.5348 20.6255 13.7678C20.5336 13.8201 20.5025 13.9353 20.5555 14.0253C20.5913 14.0855 20.6559 14.119 20.7221 14.119C20.7548 14.119 20.7879 14.1107 20.8182 14.0938C21.3044 13.8175 21.679 13.3921 21.8729 12.8964C21.9117 12.7993 21.8621 12.6905 21.7629 12.6532ZM16.2302 14.0554H14.714C14.6079 14.0554 14.5217 14.1397 14.5217 14.2436C14.5217 14.3475 14.6079 14.4318 14.714 14.4318H16.2302C16.3363 14.4318 16.4225 14.3475 16.4225 14.2436C16.4225 14.1397 16.3367 14.0554 16.2302 14.0554ZM19.2629 14.0554H17.7467C17.6405 14.0554 17.5544 14.1397 17.5544 14.2436C17.5544 14.3475 17.6405 14.4318 17.7467 14.4318H19.2629C19.369 14.4318 19.4552 14.3475 19.4552 14.2436C19.4552 14.1397 19.369 14.0554 19.2629 14.0554ZM14.6898 2.05595H16.2059C16.3121 2.05595 16.3982 1.97163 16.3982 1.86774C16.3982 1.76385 16.3121 1.67953 16.2059 1.67953H14.6898C14.5836 1.67953 14.4975 1.76385 14.4975 1.86774C14.4975 1.97163 14.5836 2.05595 14.6898 2.05595ZM8.62516 2.05595H10.1413C10.2475 2.05595 10.3336 1.97163 10.3336 1.86774C10.3336 1.76385 10.2475 1.67953 10.1413 1.67953H8.62516C8.51901 1.67953 8.43285 1.76385 8.43285 1.86774C8.43285 1.97163 8.51862 2.05595 8.62516 2.05595ZM13.1979 14.0554H11.6817C11.5755 14.0554 11.4894 14.1397 11.4894 14.2436C11.4894 14.3475 11.5755 14.4318 11.6817 14.4318H13.1979C13.304 14.4318 13.3902 14.3475 13.3902 14.2436C13.3902 14.1397 13.3044 14.0554 13.1979 14.0554ZM10.1655 14.0554H8.64939C8.54324 14.0554 8.45708 14.1397 8.45708 14.2436C8.45708 14.3475 8.54324 14.4318 8.64939 14.4318H10.1655C10.2717 14.4318 10.3579 14.3475 10.3579 14.2436C10.3579 14.1397 10.2717 14.0554 10.1655 14.0554ZM11.6575 2.05595H13.1736C13.2798 2.05595 13.3659 1.97163 13.3659 1.86774C13.3659 1.76385 13.2798 1.67953 13.1736 1.67953H11.6575C11.5513 1.67953 11.4652 1.76385 11.4652 1.86774C11.4652 1.97163 11.5509 2.05595 11.6575 2.05595ZM23.8498 10.6755V13.0443C23.8498 14.7047 22.4694 16.0557 20.7729 16.0557H3.7217C2.02516 16.0557 0.644775 14.7047 0.644775 13.0443V3.067C0.644775 1.40663 2.02516 0.0556641 3.7217 0.0556641H20.7729C22.4694 0.0556641 23.8498 1.40663 23.8498 3.067V5.4358C24.9075 5.89277 25.6448 6.89404 25.6448 8.05567C25.6448 9.21729 24.9075 10.2186 23.8498 10.6755ZM23.0805 10.898C22.9132 10.9243 22.7429 10.9413 22.5679 10.9413H22.0229V11.3602C22.0229 11.4641 21.9367 11.5484 21.8305 11.5484C21.7244 11.5484 21.6382 11.4641 21.6382 11.3602V10.9413H19.2344C17.5379 10.9413 16.1575 9.64678 16.1575 8.05529C16.1575 6.4638 17.5379 5.1693 19.2344 5.1693H21.6382V4.74921C21.6382 4.64532 21.7244 4.561 21.8305 4.561C21.9367 4.561 22.0229 4.64532 22.0229 4.74921V5.1693H22.5679C22.7429 5.1693 22.9136 5.18623 23.0805 5.21258V3.06625C23.0805 1.82069 22.0455 0.807746 20.7729 0.807746H3.7217C2.44901 0.807746 1.41401 1.82069 1.41401 3.06625V13.0436C1.41401 14.2891 2.44901 15.3021 3.7217 15.3021H20.7729C22.0455 15.3021 23.0805 14.2891 23.0805 13.0436V10.898ZM24.8755 8.05567C24.8755 6.87936 23.8405 5.92251 22.5679 5.92251H19.2344C17.9617 5.92251 16.9267 6.87936 16.9267 8.05567C16.9267 9.23197 17.9617 10.1888 19.2344 10.1888H22.5679C23.8405 10.1888 24.8755 9.23197 24.8755 8.05567ZM20.6848 8.05567C20.6848 8.78215 20.0809 9.37313 19.3386 9.37313C18.5963 9.37313 17.9925 8.78215 17.9925 8.05567C17.9925 7.32918 18.5963 6.7382 19.3386 6.7382C20.0809 6.7382 20.6848 7.32956 20.6848 8.05567ZM19.9155 8.05567C19.9155 7.74437 19.6567 7.49104 19.3386 7.49104C19.0205 7.49104 18.7617 7.74437 18.7617 8.05567C18.7617 8.36696 19.0205 8.62029 19.3386 8.62029C19.6567 8.62029 19.9155 8.36696 19.9155 8.05567Z"
                            fill="#2D2D3B"
                          />
                        </svg>
                      </bdi>
                    )}
                  </span>
                );
              }
            },
          },
        },
        {
          label: orderLanguage.voucherCode,
          name: "coupon_code",
          options: {
            filter: true,
            sort: false,
            customBodyRender: (value, tableMeta, updateValue) => {
              let data = this.state.order_data[tableMeta.rowIndex];
              return (
                <span>
                  {value &&
                    `(${value}) ${data.discount_value}${
                      data.discount_type === "fixed" ? "SR" : "%"
                    }`}
                </span>
              );
            },
          },
        },
        {
          label: orderLanguage.status,
          name: "status",
          options: {
            filter: true,
            sort: false,
            empty: true,
            customBodyRender: (value, tableMeta, updateValue) => {
              let data = this.state.order_data[tableMeta.rowIndex];
              return (
                <span
                  className={`staus-span-tag-new status-${
                    value == "1" || value == "2" || value == "3"
                      ? "prepared"
                      : value == "4"
                      ? "ready-to-ship"
                      : value == "5"
                      ? "completed"
                      : "cancelled"
                  }`}
                >
                  {data.state}
                </span>
              );
            },
          },
        },
        // {
        //   label: orderLanguage.issue,
        //   name: "issue",
        //   options: {
        //     filter: true,
        //     sort: false,
        //     customBodyRender: (value, tableMeta, updateValue) => {
        //       let id;
        //       this.state.order_data && this.state.order_data.map((item) => id = item.id)
        //       return (
        //         <div className="cust-drop hover-new position-relative">
        //           <span className="order-cust-name">0{/*<i className="bi bi-chevron-down ms-2"></i>*/}</span>
        //           {/* <div className="hover-dropdown p-3">
        //              <div className="issue-comn-part mb-3">
        //                <div className="dark-red-txt mb-2">
        //                  CANCEL REQUEST
        //                </div>
        //                <a href="#" className="data-view">
        //                  <div className="image-box-data me-3">
        //                    <img src={SearchIcon} alt="" />
        //                    <span className="cust-qty-span">1</span>
        //                  </div>
        //                  <div className="issue-data">
        //                    <div className="red-txt text-decoration-underline">Women Dress</div>
        //                    <div className="grey-text">XL</div>
        //                    <div className="grey-text">58885662</div>
        //                  </div>
        //                </a>
        //              </div>
        //              <div className="issue-comn-part">
        //                <div className="orange-txt mb-2">
        //                  OUT OF STOCK
        //                </div>
        //                <a href="#" className="data-view">
        //                  <div className="image-box-data me-3">
        //                    <img src={SearchIcon} alt="" />
        //                    <span className="cust-qty-span">1</span>
        //                  </div>
        //                  <div className="issue-data">
        //                    <div className="red-txt text-decoration-underline">Women Dress</div>
        //                    <div className="grey-text">XL</div>
        //                    <div className="grey-text">58885662</div>
        //                  </div>
        //                </a>
        //              </div>
        //            </div> */}
        //         </div>
        //       );
        //     }
        //   },
        // },
        {
          label: orderLanguage.items,
          name: "items",
          options: {
            filter: true,
            sort: false,
            customBodyRender: (value, tableMeta, updateValue) => {
              // let id;
              // this.state.order_data && this.state.order_data.map((item) => id = item.id)
              let data = this.state.order_data[tableMeta.rowIndex];
              return (
                <>
                  <div className="cust-drop hover-new position-relative">
                    <span
                      className="order-cust-name"
                      onMouseOver={() => this.getOrderItems(data.id)}
                    >
                      {value}
                      <i className="bi bi-chevron-down ms-2"></i>
                    </span>
                    {this.state.orderItemsLoader ? (
                      <div className="hover-dropdown p-3">
                        <div className="order-items-loader">
                          <div
                            class=" spinner-border text-secondary"
                            role="status"
                          >
                            <span class="sr-only">Loading...</span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      value !== 0 && (
                        <div
                          className="hover-dropdown order-items-scroll p-3"
                          onScroll={(e) => this.ScrollItems(e)}
                        >
                          <div className="issue-comn-part">
                            {this.state.orderItemsData &&
                              this.state.orderItemsData.length > 0 &&
                              this.state.orderItemsData.map((item, i) => {
                                let img = item.image.split(",")[0];
                                if (item.quantity !== 0) {
                                  return (
                                    <a href="#" className="data-view mb-3">
                                      <div className="image-box-data me-3">
                                        <img src={img} alt="" />
                                        <span className="cust-qty-span">
                                          {item.quantity}
                                        </span>
                                      </div>
                                      <div className="issue-data">
                                        <div className="red-txt text-decoration-underline">
                                          {item.title_en}
                                        </div>
                                        <div className="grey-text">
                                          {item.size_en}
                                        </div>
                                        <div className="grey-text">
                                          {item.barcode}
                                        </div>
                                      </div>
                                    </a>
                                  );
                                }
                              })}
                            {this.state.orderItemDataLoader && (
                              <div className="m-auto text-center loader-spinr">
                                <div
                                  class=" spinner-border text-secondary"
                                  role="status"
                                >
                                  <span class="sr-only">Loading...</span>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      )
                    )}
                  </div>
                </>
              );
            },
          },
        },
        {
          label: "payment",
          name: "shipping_company",
          options: {
            filter: true,
            sort: false,
            customBodyRender: (value, tableMeta, updateValue) => {
              let data = this.state.order_data[tableMeta.rowIndex];
              return (
                <span
                  className="payment-check-order p-2"
                  onClick={() => this.handlePaymentCheck([data.id])}
                >
                  check
                </span>
              );
            },
          },
        },
        // {
        //   label: orderLanguage.track,
        //   name: "shipping_company",
        //   options: {
        //     filter: true,
        //     sort: false,
        //     customBodyRender: (value, tableMeta, updateValue) => {
        //       let data = this.state.order_data[tableMeta.rowIndex]
        //       return (
        //         <a href={data.track_url && data.track_url} target="_blank">{value}</a>
        //       )
        //     }
        //   },
        // },
        {
          label: orderLanguage.action,
          name: "id",

          options: {
            filter: true,
            sort: false,
            empty: true,
            customBodyRender: (value, tableMeta, updateValue) => {
              return (
                <Dropdown className="cust-drop">
                  <Dropdown.Toggle
                    className="bg-transparent "
                    id="dropdown-basic"
                    align="end"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width={16}
                      height={16}
                      fill="currentColor"
                      className="bi bi-three-dots-vertical"
                      viewBox="0 0 16 16"
                    >
                      <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                    </svg>
                  </Dropdown.Toggle>
                  <Dropdown.Menu>
                    <Dropdown.Item href={"order-details/" + value}>
                      <svg
                        width={19}
                        height={19}
                        viewBox="0 0 19 19"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
                          fill="#2D2D3B"
                        />
                      </svg>
                      <span>{ButtonLanguage.edit}</span>
                    </Dropdown.Item>
                    <Dropdown.Item onClick={this.edit_handleShow}>
                      <svg
                        width={19}
                        height={19}
                        viewBox="0 0 20 18"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M7 0C4.23858 0 2 2.23858 2 5C2 7.76142 4.23858 10 7 10C9.76142 10 12 7.76142 12 5C12 2.23858 9.76142 0 7 0ZM4 5C4 3.34315 5.34315 2 7 2C8.65685 2 10 3.34315 10 5C10 6.65685 8.65685 8 7 8C5.34315 8 4 6.65685 4 5Z"
                          fill="#2D2D3B"
                        ></path>
                        <path
                          d="M14.9084 5.21828C14.6271 5.07484 14.3158 5.00006 14 5.00006V3.00006C14.6316 3.00006 15.2542 3.14956 15.8169 3.43645C15.8789 3.46805 15.9399 3.50121 16 3.5359C16.4854 3.81614 16.9072 4.19569 17.2373 4.65055C17.6083 5.16172 17.8529 5.75347 17.9512 6.37737C18.0496 7.00126 17.9987 7.63958 17.8029 8.24005C17.6071 8.84053 17.2719 9.38611 16.8247 9.83213C16.3775 10.2782 15.8311 10.6119 15.2301 10.8062C14.6953 10.979 14.1308 11.037 13.5735 10.9772C13.5046 10.9698 13.4357 10.9606 13.367 10.9496C12.7438 10.8497 12.1531 10.6038 11.6431 10.2319L11.6421 10.2311L12.821 8.61557C13.0761 8.80172 13.3717 8.92477 13.6835 8.97474C13.9953 9.02471 14.3145 9.00014 14.615 8.90302C14.9155 8.80591 15.1887 8.63903 15.4123 8.41602C15.6359 8.19302 15.8035 7.92024 15.9014 7.62001C15.9993 7.31978 16.0247 7.00063 15.9756 6.68869C15.9264 6.37675 15.8041 6.08089 15.6186 5.82531C15.4331 5.56974 15.1898 5.36172 14.9084 5.21828Z"
                          fill="#2D2D3B"
                        ></path>
                        <path
                          d="M17.9981 18C17.9981 17.475 17.8947 16.9551 17.6938 16.47C17.4928 15.9849 17.1983 15.5442 16.8271 15.1729C16.4558 14.8017 16.0151 14.5072 15.53 14.3062C15.0449 14.1053 14.525 14.0019 14 14.0019V12C14.6821 12 15.3584 12.1163 16 12.3431C16.0996 12.3783 16.1983 12.4162 16.2961 12.4567C17.0241 12.7583 17.6855 13.2002 18.2426 13.7574C18.7998 14.3145 19.2417 14.9759 19.5433 15.7039C19.5838 15.8017 19.6217 15.9004 19.6569 16C19.8837 16.6416 20 17.3179 20 18H17.9981Z"
                          fill="#2D2D3B"
                        ></path>
                        <path
                          d="M14 18H12C12 15.2386 9.76142 13 7 13C4.23858 13 2 15.2386 2 18H0C0 14.134 3.13401 11 7 11C10.866 11 14 14.134 14 18Z"
                          fill="#2D2D3B"
                        ></path>
                      </svg>
                      <span>{ButtonLanguage.assign}</span>
                    </Dropdown.Item>
                    <Dropdown.Item onClick={() => this.delete_record(value)}>
                      <svg
                        width={19}
                        height={19}
                        viewBox="0 0 18 20"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
                          fill="#2D2D3B"
                        />
                      </svg>
                      <span>{orderLanguage.archived}</span>
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              );
            },
          },
        },
      ];
    } else {
      columns = [
        {
          label: orderLanguage.order,
          name: "id",
          options: {
            filter: true,
            customBodyRender: (value) => {
              return (
                <>
                  <Link to={"order-details/" + value}>
                    <a className="fw-bold dark-red-txt">{value}</a>
                  </Link>
                </>
              );
            },
          },
        },
        {
          label: orderLanguage.customerName,
          name: "first_name",
          options: {
            filter: true,
            customBodyRender: (value, tableMeta, updateValue) => {
              let data = this.state.order_data[tableMeta.rowIndex];
              let lastName = data.last_name ? data.last_name : "";
              const address = JSON.parse(data.address ?? "{}");
              // let id;
              // this.state.order_data && this.state.order_data.map((item) => id = item.id)
              return (
                <>
                  <div className="cust-drop hover-new position-relative">
                    <div className="order-cust-name d-flex align-items-center">
                      <div className="tble-name-fix">
                        {value + " " + lastName}
                      </div>
                      <bdi
                        className={`${
                          data.mark?.replace("Customer", " ").includes("New")
                            ? "new-class"
                            : data.mark
                                ?.replace("Customer", " ")
                                .includes("Bad")
                            ? "bad-class"
                            : data.mark
                                ?.replace("Customer", " ")
                                .includes("Premium")
                            ? "vip-class"
                            : ""
                        }`}
                      >
                        {data.mark?.replace("Customer", " ").includes("New")
                          ? "New"
                          : data.mark?.replace("Customer", " ").includes("Bad")
                          ? "Bad"
                          : data.mark
                              ?.replace("Customer", " ")
                              .includes("Premium")
                          ? "Vip"
                          : ""}
                      </bdi>
                      <i className="bi bi-chevron-down ms-2"></i>
                    </div>
                    <div className="hover-dropdown">
                      <div className="p-3 border-bottom">
                        <div className="name-text">{value}</div>
                        <div className="grey-text">
                          {address.area_en},{address.city_en}
                        </div>
                        <div className="grey-text">
                          {data.user_orders} Orders
                        </div>
                        <div className="red-txt text-decoration-underline">
                          {data.email}
                        </div>
                      </div>
                      <div className="p-3">
                        <a href={`user-details/${address.user_id}`}>
                          <button className="red-border-btn w-100">
                            {" "}
                            View Customer
                          </button>
                        </a>
                      </div>
                    </div>
                  </div>
                </>
              );
            },
          },
        },
        {
          label: orderLanguage.date,
          name: "createdat",
          options: {
            filter: true,
            customBodyRender: (value) => {
              return <>{Moment(value).format("DD/MM/YYYY hh:mm A")}</>;
            },
          },
        },
        {
          label: orderLanguage.cityArea,
          name: "CityName",
          options: {
            filter: true,
            customBodyRender: (value, tableMeta, updateValue) => {
              let data = this.state.order_data[tableMeta.rowIndex];
              const address = JSON.parse(data.address ?? "{}");
              // let id;
              // this.state.order_data && this.state.order_data.map((item) => id = item.id)
              if (this.context.language === "english") {
                return (
                  <span>
                    {address.city_en} - {address.area_en}
                  </span>
                );
              } else {
                return (
                  <span>
                    {address.city_ar} - {address.area_ar}
                  </span>
                );
              }
            },
          },
        },
        {
          label: orderLanguage.phoneNumber,
          name: "phone",
          options: {
            filter: true,
            customBodyRender: (value) => {
              if (value) {
                return (
                  <>
                    {value.substring(0, 3) !== "966"
                      ? 0 + value
                      : 0 + value.substring(0, 3)}
                  </>
                );
              }
            },
          },
        },
        {
          label: orderLanguage.value,
          name: "total_paymentable_price",
          options: {
            filter: true,
            sort: false,
            customBodyRender: (value) => {
              return <>{Number(value).toFixed(2) + " "}</>;
            },
          },
        },
        {
          label: orderLanguage.payMethod,
          name: "pay_method",
          options: {
            filter: true,
            sort: false,
            customBodyRender: (value, tableMeta, updateValue) => {
              let data = this.state.order_data[tableMeta.rowIndex];
              if (this.context.language === "english") {
                return (
                  <span>
                    {value === "COD"
                      ? "COD"
                      : value === "cardPayment"
                      ? "Card Payment"
                      : value === "APPLEPAY"
                      ? "Apple Pay"
                      : value}
                    {data.wallet_cost != 0 && (
                      <bdi className="ms-2">
                        <svg
                          width="26"
                          height="17"
                          viewBox="0 0 26 17"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M8.33128 9.52948L9.8615 4.70068H10.9013L12.4315 9.52948L14.1579 4.70068H15.4036L13.0102 11.4111H11.8625L10.4206 6.81268H10.3421L8.90021 11.4111H7.75255L5.35913 4.70068H6.60488L8.33128 9.52948Z"
                            fill="#2D2D3B"
                          />
                          <path
                            d="M2.8167 11.7773C2.8167 11.8812 2.73054 11.9655 2.62439 11.9655C2.51824 11.9655 2.43208 11.8812 2.43208 11.7773V10.2935C2.43208 10.1896 2.51824 10.1053 2.62439 10.1053C2.73054 10.1053 2.8167 10.1896 2.8167 10.2935V11.7773ZM2.62439 8.99784C2.73054 8.99784 2.8167 8.91352 2.8167 8.80963V7.32579C2.8167 7.2219 2.73054 7.13758 2.62439 7.13758C2.51824 7.13758 2.43208 7.2219 2.43208 7.32579V8.80963C2.43208 8.91352 2.51824 8.99784 2.62439 8.99784ZM4.18247 13.9285C3.73862 13.7719 3.35901 13.4772 3.11401 13.0985C3.05747 13.0108 2.93862 12.9845 2.84862 13.0402C2.75901 13.0955 2.73208 13.2122 2.78901 13.2999C3.07939 13.749 3.52785 14.0979 4.05208 14.2824C4.07362 14.2903 4.09554 14.2937 4.11708 14.2937C4.19593 14.2937 4.26978 14.2459 4.29785 14.1691C4.33401 14.0716 4.28247 13.9639 4.18247 13.9285ZM5.59247 2.05595H7.10862C7.21478 2.05595 7.30093 1.97163 7.30093 1.86774C7.30093 1.76385 7.21478 1.67953 7.10862 1.67953H5.59247C5.48631 1.67953 5.40016 1.76385 5.40016 1.86774C5.40016 1.97163 5.48631 2.05595 5.59247 2.05595ZM17.7221 2.05595H19.2382C19.3444 2.05595 19.4305 1.97163 19.4305 1.86774C19.4305 1.76385 19.3444 1.67953 19.2382 1.67953H17.7221C17.6159 1.67953 17.5298 1.76385 17.5298 1.86774C17.5298 1.97163 17.6159 2.05595 17.7221 2.05595ZM20.6063 2.33261C21.019 2.5611 21.3386 2.91531 21.5059 3.32937C21.5359 3.40314 21.6082 3.44832 21.6848 3.44832C21.7086 3.44832 21.7325 3.44417 21.7555 3.43514C21.8544 3.39675 21.9025 3.28758 21.8636 3.19085C21.664 2.69699 21.2848 2.27577 20.7959 2.00513C20.7032 1.95394 20.5863 1.98593 20.5336 2.0759C20.4817 2.16661 20.514 2.28142 20.6063 2.33261ZM2.62439 6.02979C2.73054 6.02979 2.8167 5.94547 2.8167 5.84158V4.35774C2.8167 4.25385 2.73054 4.16953 2.62439 4.16953C2.51824 4.16953 2.43208 4.25385 2.43208 4.35774V5.84158C2.43208 5.94584 2.51824 6.02979 2.62439 6.02979ZM7.13324 14.0554H5.61708C5.51093 14.0554 5.42478 14.1397 5.42478 14.2436C5.42478 14.3475 5.51093 14.4318 5.61708 14.4318H7.13324C7.23939 14.4318 7.32555 14.3475 7.32555 14.2436C7.32555 14.1397 7.23939 14.0554 7.13324 14.0554ZM2.83747 3.09222C2.86901 3.11142 2.90362 3.12046 2.93824 3.12046C3.00247 3.12046 3.06593 3.08884 3.10208 3.03124C3.34247 2.65031 3.71901 2.35143 4.16131 2.1907C4.26093 2.15457 4.3117 2.04616 4.27439 1.94867C4.23708 1.85155 4.1267 1.80149 4.02708 1.838C3.50478 2.02809 3.05978 2.38192 2.77478 2.834C2.71939 2.92171 2.74708 3.03764 2.83747 3.09222ZM21.7629 12.6532C21.6644 12.6163 21.5525 12.6645 21.5144 12.7616C21.3517 13.1772 21.0359 13.5348 20.6255 13.7678C20.5336 13.8201 20.5025 13.9353 20.5555 14.0253C20.5913 14.0855 20.6559 14.119 20.7221 14.119C20.7548 14.119 20.7879 14.1107 20.8182 14.0938C21.3044 13.8175 21.679 13.3921 21.8729 12.8964C21.9117 12.7993 21.8621 12.6905 21.7629 12.6532ZM16.2302 14.0554H14.714C14.6079 14.0554 14.5217 14.1397 14.5217 14.2436C14.5217 14.3475 14.6079 14.4318 14.714 14.4318H16.2302C16.3363 14.4318 16.4225 14.3475 16.4225 14.2436C16.4225 14.1397 16.3367 14.0554 16.2302 14.0554ZM19.2629 14.0554H17.7467C17.6405 14.0554 17.5544 14.1397 17.5544 14.2436C17.5544 14.3475 17.6405 14.4318 17.7467 14.4318H19.2629C19.369 14.4318 19.4552 14.3475 19.4552 14.2436C19.4552 14.1397 19.369 14.0554 19.2629 14.0554ZM14.6898 2.05595H16.2059C16.3121 2.05595 16.3982 1.97163 16.3982 1.86774C16.3982 1.76385 16.3121 1.67953 16.2059 1.67953H14.6898C14.5836 1.67953 14.4975 1.76385 14.4975 1.86774C14.4975 1.97163 14.5836 2.05595 14.6898 2.05595ZM8.62516 2.05595H10.1413C10.2475 2.05595 10.3336 1.97163 10.3336 1.86774C10.3336 1.76385 10.2475 1.67953 10.1413 1.67953H8.62516C8.51901 1.67953 8.43285 1.76385 8.43285 1.86774C8.43285 1.97163 8.51862 2.05595 8.62516 2.05595ZM13.1979 14.0554H11.6817C11.5755 14.0554 11.4894 14.1397 11.4894 14.2436C11.4894 14.3475 11.5755 14.4318 11.6817 14.4318H13.1979C13.304 14.4318 13.3902 14.3475 13.3902 14.2436C13.3902 14.1397 13.3044 14.0554 13.1979 14.0554ZM10.1655 14.0554H8.64939C8.54324 14.0554 8.45708 14.1397 8.45708 14.2436C8.45708 14.3475 8.54324 14.4318 8.64939 14.4318H10.1655C10.2717 14.4318 10.3579 14.3475 10.3579 14.2436C10.3579 14.1397 10.2717 14.0554 10.1655 14.0554ZM11.6575 2.05595H13.1736C13.2798 2.05595 13.3659 1.97163 13.3659 1.86774C13.3659 1.76385 13.2798 1.67953 13.1736 1.67953H11.6575C11.5513 1.67953 11.4652 1.76385 11.4652 1.86774C11.4652 1.97163 11.5509 2.05595 11.6575 2.05595ZM23.8498 10.6755V13.0443C23.8498 14.7047 22.4694 16.0557 20.7729 16.0557H3.7217C2.02516 16.0557 0.644775 14.7047 0.644775 13.0443V3.067C0.644775 1.40663 2.02516 0.0556641 3.7217 0.0556641H20.7729C22.4694 0.0556641 23.8498 1.40663 23.8498 3.067V5.4358C24.9075 5.89277 25.6448 6.89404 25.6448 8.05567C25.6448 9.21729 24.9075 10.2186 23.8498 10.6755ZM23.0805 10.898C22.9132 10.9243 22.7429 10.9413 22.5679 10.9413H22.0229V11.3602C22.0229 11.4641 21.9367 11.5484 21.8305 11.5484C21.7244 11.5484 21.6382 11.4641 21.6382 11.3602V10.9413H19.2344C17.5379 10.9413 16.1575 9.64678 16.1575 8.05529C16.1575 6.4638 17.5379 5.1693 19.2344 5.1693H21.6382V4.74921C21.6382 4.64532 21.7244 4.561 21.8305 4.561C21.9367 4.561 22.0229 4.64532 22.0229 4.74921V5.1693H22.5679C22.7429 5.1693 22.9136 5.18623 23.0805 5.21258V3.06625C23.0805 1.82069 22.0455 0.807746 20.7729 0.807746H3.7217C2.44901 0.807746 1.41401 1.82069 1.41401 3.06625V13.0436C1.41401 14.2891 2.44901 15.3021 3.7217 15.3021H20.7729C22.0455 15.3021 23.0805 14.2891 23.0805 13.0436V10.898ZM24.8755 8.05567C24.8755 6.87936 23.8405 5.92251 22.5679 5.92251H19.2344C17.9617 5.92251 16.9267 6.87936 16.9267 8.05567C16.9267 9.23197 17.9617 10.1888 19.2344 10.1888H22.5679C23.8405 10.1888 24.8755 9.23197 24.8755 8.05567ZM20.6848 8.05567C20.6848 8.78215 20.0809 9.37313 19.3386 9.37313C18.5963 9.37313 17.9925 8.78215 17.9925 8.05567C17.9925 7.32918 18.5963 6.7382 19.3386 6.7382C20.0809 6.7382 20.6848 7.32956 20.6848 8.05567ZM19.9155 8.05567C19.9155 7.74437 19.6567 7.49104 19.3386 7.49104C19.0205 7.49104 18.7617 7.74437 18.7617 8.05567C18.7617 8.36696 19.0205 8.62029 19.3386 8.62029C19.6567 8.62029 19.9155 8.36696 19.9155 8.05567Z"
                            fill="#2D2D3B"
                          />
                        </svg>
                      </bdi>
                    )}
                  </span>
                );
              } else {
                return (
                  <span>
                    {value === "COD"
                      ? "الدفع عند الإستلام"
                      : value === "cardPayment"
                      ? "بطاقة ائتمان"
                      : value === "APPLEPAY"
                      ? "أبل باي"
                      : value == "WALLET"
                      ? "محفظة"
                      : ""}
                    {data.wallet_cost != 0 && (
                      <bdi className="ms-2">
                        <svg
                          width="26"
                          height="17"
                          viewBox="0 0 26 17"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M8.33128 9.52948L9.8615 4.70068H10.9013L12.4315 9.52948L14.1579 4.70068H15.4036L13.0102 11.4111H11.8625L10.4206 6.81268H10.3421L8.90021 11.4111H7.75255L5.35913 4.70068H6.60488L8.33128 9.52948Z"
                            fill="#2D2D3B"
                          />
                          <path
                            d="M2.8167 11.7773C2.8167 11.8812 2.73054 11.9655 2.62439 11.9655C2.51824 11.9655 2.43208 11.8812 2.43208 11.7773V10.2935C2.43208 10.1896 2.51824 10.1053 2.62439 10.1053C2.73054 10.1053 2.8167 10.1896 2.8167 10.2935V11.7773ZM2.62439 8.99784C2.73054 8.99784 2.8167 8.91352 2.8167 8.80963V7.32579C2.8167 7.2219 2.73054 7.13758 2.62439 7.13758C2.51824 7.13758 2.43208 7.2219 2.43208 7.32579V8.80963C2.43208 8.91352 2.51824 8.99784 2.62439 8.99784ZM4.18247 13.9285C3.73862 13.7719 3.35901 13.4772 3.11401 13.0985C3.05747 13.0108 2.93862 12.9845 2.84862 13.0402C2.75901 13.0955 2.73208 13.2122 2.78901 13.2999C3.07939 13.749 3.52785 14.0979 4.05208 14.2824C4.07362 14.2903 4.09554 14.2937 4.11708 14.2937C4.19593 14.2937 4.26978 14.2459 4.29785 14.1691C4.33401 14.0716 4.28247 13.9639 4.18247 13.9285ZM5.59247 2.05595H7.10862C7.21478 2.05595 7.30093 1.97163 7.30093 1.86774C7.30093 1.76385 7.21478 1.67953 7.10862 1.67953H5.59247C5.48631 1.67953 5.40016 1.76385 5.40016 1.86774C5.40016 1.97163 5.48631 2.05595 5.59247 2.05595ZM17.7221 2.05595H19.2382C19.3444 2.05595 19.4305 1.97163 19.4305 1.86774C19.4305 1.76385 19.3444 1.67953 19.2382 1.67953H17.7221C17.6159 1.67953 17.5298 1.76385 17.5298 1.86774C17.5298 1.97163 17.6159 2.05595 17.7221 2.05595ZM20.6063 2.33261C21.019 2.5611 21.3386 2.91531 21.5059 3.32937C21.5359 3.40314 21.6082 3.44832 21.6848 3.44832C21.7086 3.44832 21.7325 3.44417 21.7555 3.43514C21.8544 3.39675 21.9025 3.28758 21.8636 3.19085C21.664 2.69699 21.2848 2.27577 20.7959 2.00513C20.7032 1.95394 20.5863 1.98593 20.5336 2.0759C20.4817 2.16661 20.514 2.28142 20.6063 2.33261ZM2.62439 6.02979C2.73054 6.02979 2.8167 5.94547 2.8167 5.84158V4.35774C2.8167 4.25385 2.73054 4.16953 2.62439 4.16953C2.51824 4.16953 2.43208 4.25385 2.43208 4.35774V5.84158C2.43208 5.94584 2.51824 6.02979 2.62439 6.02979ZM7.13324 14.0554H5.61708C5.51093 14.0554 5.42478 14.1397 5.42478 14.2436C5.42478 14.3475 5.51093 14.4318 5.61708 14.4318H7.13324C7.23939 14.4318 7.32555 14.3475 7.32555 14.2436C7.32555 14.1397 7.23939 14.0554 7.13324 14.0554ZM2.83747 3.09222C2.86901 3.11142 2.90362 3.12046 2.93824 3.12046C3.00247 3.12046 3.06593 3.08884 3.10208 3.03124C3.34247 2.65031 3.71901 2.35143 4.16131 2.1907C4.26093 2.15457 4.3117 2.04616 4.27439 1.94867C4.23708 1.85155 4.1267 1.80149 4.02708 1.838C3.50478 2.02809 3.05978 2.38192 2.77478 2.834C2.71939 2.92171 2.74708 3.03764 2.83747 3.09222ZM21.7629 12.6532C21.6644 12.6163 21.5525 12.6645 21.5144 12.7616C21.3517 13.1772 21.0359 13.5348 20.6255 13.7678C20.5336 13.8201 20.5025 13.9353 20.5555 14.0253C20.5913 14.0855 20.6559 14.119 20.7221 14.119C20.7548 14.119 20.7879 14.1107 20.8182 14.0938C21.3044 13.8175 21.679 13.3921 21.8729 12.8964C21.9117 12.7993 21.8621 12.6905 21.7629 12.6532ZM16.2302 14.0554H14.714C14.6079 14.0554 14.5217 14.1397 14.5217 14.2436C14.5217 14.3475 14.6079 14.4318 14.714 14.4318H16.2302C16.3363 14.4318 16.4225 14.3475 16.4225 14.2436C16.4225 14.1397 16.3367 14.0554 16.2302 14.0554ZM19.2629 14.0554H17.7467C17.6405 14.0554 17.5544 14.1397 17.5544 14.2436C17.5544 14.3475 17.6405 14.4318 17.7467 14.4318H19.2629C19.369 14.4318 19.4552 14.3475 19.4552 14.2436C19.4552 14.1397 19.369 14.0554 19.2629 14.0554ZM14.6898 2.05595H16.2059C16.3121 2.05595 16.3982 1.97163 16.3982 1.86774C16.3982 1.76385 16.3121 1.67953 16.2059 1.67953H14.6898C14.5836 1.67953 14.4975 1.76385 14.4975 1.86774C14.4975 1.97163 14.5836 2.05595 14.6898 2.05595ZM8.62516 2.05595H10.1413C10.2475 2.05595 10.3336 1.97163 10.3336 1.86774C10.3336 1.76385 10.2475 1.67953 10.1413 1.67953H8.62516C8.51901 1.67953 8.43285 1.76385 8.43285 1.86774C8.43285 1.97163 8.51862 2.05595 8.62516 2.05595ZM13.1979 14.0554H11.6817C11.5755 14.0554 11.4894 14.1397 11.4894 14.2436C11.4894 14.3475 11.5755 14.4318 11.6817 14.4318H13.1979C13.304 14.4318 13.3902 14.3475 13.3902 14.2436C13.3902 14.1397 13.3044 14.0554 13.1979 14.0554ZM10.1655 14.0554H8.64939C8.54324 14.0554 8.45708 14.1397 8.45708 14.2436C8.45708 14.3475 8.54324 14.4318 8.64939 14.4318H10.1655C10.2717 14.4318 10.3579 14.3475 10.3579 14.2436C10.3579 14.1397 10.2717 14.0554 10.1655 14.0554ZM11.6575 2.05595H13.1736C13.2798 2.05595 13.3659 1.97163 13.3659 1.86774C13.3659 1.76385 13.2798 1.67953 13.1736 1.67953H11.6575C11.5513 1.67953 11.4652 1.76385 11.4652 1.86774C11.4652 1.97163 11.5509 2.05595 11.6575 2.05595ZM23.8498 10.6755V13.0443C23.8498 14.7047 22.4694 16.0557 20.7729 16.0557H3.7217C2.02516 16.0557 0.644775 14.7047 0.644775 13.0443V3.067C0.644775 1.40663 2.02516 0.0556641 3.7217 0.0556641H20.7729C22.4694 0.0556641 23.8498 1.40663 23.8498 3.067V5.4358C24.9075 5.89277 25.6448 6.89404 25.6448 8.05567C25.6448 9.21729 24.9075 10.2186 23.8498 10.6755ZM23.0805 10.898C22.9132 10.9243 22.7429 10.9413 22.5679 10.9413H22.0229V11.3602C22.0229 11.4641 21.9367 11.5484 21.8305 11.5484C21.7244 11.5484 21.6382 11.4641 21.6382 11.3602V10.9413H19.2344C17.5379 10.9413 16.1575 9.64678 16.1575 8.05529C16.1575 6.4638 17.5379 5.1693 19.2344 5.1693H21.6382V4.74921C21.6382 4.64532 21.7244 4.561 21.8305 4.561C21.9367 4.561 22.0229 4.64532 22.0229 4.74921V5.1693H22.5679C22.7429 5.1693 22.9136 5.18623 23.0805 5.21258V3.06625C23.0805 1.82069 22.0455 0.807746 20.7729 0.807746H3.7217C2.44901 0.807746 1.41401 1.82069 1.41401 3.06625V13.0436C1.41401 14.2891 2.44901 15.3021 3.7217 15.3021H20.7729C22.0455 15.3021 23.0805 14.2891 23.0805 13.0436V10.898ZM24.8755 8.05567C24.8755 6.87936 23.8405 5.92251 22.5679 5.92251H19.2344C17.9617 5.92251 16.9267 6.87936 16.9267 8.05567C16.9267 9.23197 17.9617 10.1888 19.2344 10.1888H22.5679C23.8405 10.1888 24.8755 9.23197 24.8755 8.05567ZM20.6848 8.05567C20.6848 8.78215 20.0809 9.37313 19.3386 9.37313C18.5963 9.37313 17.9925 8.78215 17.9925 8.05567C17.9925 7.32918 18.5963 6.7382 19.3386 6.7382C20.0809 6.7382 20.6848 7.32956 20.6848 8.05567ZM19.9155 8.05567C19.9155 7.74437 19.6567 7.49104 19.3386 7.49104C19.0205 7.49104 18.7617 7.74437 18.7617 8.05567C18.7617 8.36696 19.0205 8.62029 19.3386 8.62029C19.6567 8.62029 19.9155 8.36696 19.9155 8.05567Z"
                            fill="#2D2D3B"
                          />
                        </svg>
                      </bdi>
                    )}
                  </span>
                );
              }
            },
          },
        },
        {
          label: orderLanguage.voucherCode,
          name: "coupon_code",
          options: {
            filter: true,
            sort: false,
            customBodyRender: (value, tableMeta, updateValue) => {
              let data = this.state.order_data[tableMeta.rowIndex];
              return (
                <span className="p-2">
                  {value &&
                    `(${value}) ${data.discount_value}${
                      data.discount_type === "fixed" ? "SR" : "%"
                    }`}
                </span>
              );
            },
          },
        },
        {
          label: orderLanguage.status,
          name: "status",
          options: {
            filter: true,
            sort: false,
            empty: true,
            customBodyRender: (value, tableMeta, updateValue) => {
              let data = this.state.order_data[tableMeta.rowIndex];
              return (
                <span
                  className={`staus-span-tag-new status-${
                    value == "1" || value == "2" || value == "3"
                      ? "prepared"
                      : value == "4"
                      ? "ready-to-ship"
                      : value == "5"
                      ? "completed"
                      : "cancelled"
                  }`}
                >
                  {data.state}
                </span>
              );
            },
          },
        },
        {
          label: orderLanguage.issue,
          name: "issue",
          options: {
            filter: true,
            sort: false,
            customBodyRender: (value, tableMeta, updateValue) => {
              let id;
              this.state.order_data &&
                this.state.order_data.map((item) => (id = item.id));
              let data = this.state.order_data[tableMeta.rowIndex];
              // console.log(data, "data");
              return (
                <div className="cust-drop hover-new position-relative">
                  <span className="order-cust-name p-2">
                    {value}
                    {value !== 0 && <i className="bi bi-chevron-down ms-2"></i>}
                  </span>
                  {value !== 0 && (
                    <div className="hover-dropdown p-3">
                      {data.cancel_items &&
                        data.cancel_items.length > 0 &&
                        data.cancel_items.map((item) => {
                          let img = item.image.split(",")[0];
                          return (
                            <div className="issue-comn-part mb-3">
                              <div
                                className={`${
                                  item.cancel_reason == "Out of stock"
                                    ? "orange-txt"
                                    : "dark-red-txt"
                                } mb-2`}
                              >
                                {item.cancel_reason}
                              </div>
                              <a href="#" className="data-view">
                                <div className="image-box-data me-3">
                                  <img src={img} alt="" />
                                  <span className="cust-qty-span">
                                    {item.cancel_quantity}
                                  </span>
                                </div>
                                <div className="issue-data">
                                  <div className="red-txt text-decoration-underline">
                                    {this.context.language === "english"
                                      ? item.title_en
                                      : item.title_ar}
                                  </div>
                                  <div className="grey-text">
                                    {this.context.language === "english"
                                      ? item.size_en
                                      : item.size_ar}
                                  </div>
                                  <div className="grey-text">
                                    {item.barcode}
                                  </div>
                                </div>
                              </a>
                            </div>
                          );
                        })}
                      {/* <div className="issue-comn-part">
                        <div className="orange-txt mb-2">
                          OUT OF STOCK
                        </div>
                        <a href="#" className="data-view">
                          <div className="image-box-data me-3">
                            <img src={SearchIcon} alt="" />
                            <span className="cust-qty-span">1</span>
                          </div>
                          <div className="issue-data">
                            <div className="red-txt text-decoration-underline">Women Dress</div>
                            <div className="grey-text">XL</div>
                            <div className="grey-text">58885662</div>
                          </div>
                        </a>
                      </div> */}
                    </div>
                  )}
                </div>
              );
            },
          },
        },
        {
          label: orderLanguage.items,
          name: "items",
          options: {
            filter: true,
            sort: false,
            customBodyRender: (value, tableMeta, updateValue) => {
              // let id;
              // this.state.order_data && this.state.order_data.map((item) => id = item.id)
              let data = this.state.order_data[tableMeta.rowIndex];
              return (
                <>
                  <div className="cust-drop hover-new position-relative">
                    <span
                      className="order-cust-name"
                      onMouseOver={() => this.getOrderItems(data.id)}
                    >
                      {value}
                      <i className="bi bi-chevron-down ms-2"></i>
                    </span>
                    {this.state.orderItemsLoader ? (
                      <div className="hover-dropdown p-3">
                        <div className="order-items-loader">
                          <div
                            class=" spinner-border text-secondary"
                            role="status"
                          >
                            <span class="sr-only">Loading...</span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      value !== 0 && (
                        <div
                          className="hover-dropdown order-items-scroll p-3"
                          onScroll={(e) => this.ScrollItems(e)}
                        >
                          <div className="issue-comn-part">
                            {this.state.orderItemsData &&
                              this.state.orderItemsData.length > 0 &&
                              this.state.orderItemsData.map((item, i) => {
                                let img = item.image.split(",")[0];
                                if (item.quantity !== 0) {
                                  return (
                                    <a href="#" className="data-view mb-3">
                                      <div className="image-box-data me-3">
                                        <img src={img} alt="" />
                                        <span className="cust-qty-span">
                                          {item.quantity}
                                        </span>
                                      </div>
                                      <div className="issue-data">
                                        <div className="red-txt text-decoration-underline">
                                          {item.title_en}
                                        </div>
                                        <div className="grey-text">
                                          {item.size_en}
                                        </div>
                                        <div className="grey-text">
                                          {item.barcode}
                                        </div>
                                      </div>
                                    </a>
                                  );
                                }
                              })}
                            {this.state.orderItemDataLoader && (
                              <div className="m-auto text-center loader-spinr">
                                <div
                                  class=" spinner-border text-secondary"
                                  role="status"
                                >
                                  <span class="sr-only">Loading...</span>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      )
                    )}
                  </div>
                </>
              );
            },
          },
        },
        {
          label: orderLanguage.track,
          name: "shipping_company",
          options: {
            filter: true,
            sort: false,
            customBodyRender: (value, tableMeta, updateValue) => {
              let data = this.state.order_data[tableMeta.rowIndex];
              return (
                <a href={data.track_url && data.track_url} target="_blank">
                  {value}
                </a>
              );
            },
          },
        },
        {
          label: orderLanguage.action,
          name: "id",

          options: {
            filter: true,
            sort: false,
            empty: true,
            customBodyRender: (value, tableMeta, updateValue) => {
              return (
                <Dropdown className="cust-drop">
                  <Dropdown.Toggle
                    className="bg-transparent "
                    id="dropdown-basic"
                    align="end"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width={16}
                      height={16}
                      fill="currentColor"
                      className="bi bi-three-dots-vertical"
                      viewBox="0 0 16 16"
                    >
                      <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                    </svg>
                  </Dropdown.Toggle>
                  <Dropdown.Menu>
                    <Dropdown.Item href={"order-details/" + value}>
                      <svg
                        width={19}
                        height={19}
                        viewBox="0 0 19 19"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
                          fill="#2D2D3B"
                        />
                      </svg>
                      <span>{ButtonLanguage.edit}</span>
                    </Dropdown.Item>
                    <Dropdown.Item onClick={this.edit_handleShow}>
                      <svg
                        width={19}
                        height={19}
                        viewBox="0 0 20 18"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M7 0C4.23858 0 2 2.23858 2 5C2 7.76142 4.23858 10 7 10C9.76142 10 12 7.76142 12 5C12 2.23858 9.76142 0 7 0ZM4 5C4 3.34315 5.34315 2 7 2C8.65685 2 10 3.34315 10 5C10 6.65685 8.65685 8 7 8C5.34315 8 4 6.65685 4 5Z"
                          fill="#2D2D3B"
                        ></path>
                        <path
                          d="M14.9084 5.21828C14.6271 5.07484 14.3158 5.00006 14 5.00006V3.00006C14.6316 3.00006 15.2542 3.14956 15.8169 3.43645C15.8789 3.46805 15.9399 3.50121 16 3.5359C16.4854 3.81614 16.9072 4.19569 17.2373 4.65055C17.6083 5.16172 17.8529 5.75347 17.9512 6.37737C18.0496 7.00126 17.9987 7.63958 17.8029 8.24005C17.6071 8.84053 17.2719 9.38611 16.8247 9.83213C16.3775 10.2782 15.8311 10.6119 15.2301 10.8062C14.6953 10.979 14.1308 11.037 13.5735 10.9772C13.5046 10.9698 13.4357 10.9606 13.367 10.9496C12.7438 10.8497 12.1531 10.6038 11.6431 10.2319L11.6421 10.2311L12.821 8.61557C13.0761 8.80172 13.3717 8.92477 13.6835 8.97474C13.9953 9.02471 14.3145 9.00014 14.615 8.90302C14.9155 8.80591 15.1887 8.63903 15.4123 8.41602C15.6359 8.19302 15.8035 7.92024 15.9014 7.62001C15.9993 7.31978 16.0247 7.00063 15.9756 6.68869C15.9264 6.37675 15.8041 6.08089 15.6186 5.82531C15.4331 5.56974 15.1898 5.36172 14.9084 5.21828Z"
                          fill="#2D2D3B"
                        ></path>
                        <path
                          d="M17.9981 18C17.9981 17.475 17.8947 16.9551 17.6938 16.47C17.4928 15.9849 17.1983 15.5442 16.8271 15.1729C16.4558 14.8017 16.0151 14.5072 15.53 14.3062C15.0449 14.1053 14.525 14.0019 14 14.0019V12C14.6821 12 15.3584 12.1163 16 12.3431C16.0996 12.3783 16.1983 12.4162 16.2961 12.4567C17.0241 12.7583 17.6855 13.2002 18.2426 13.7574C18.7998 14.3145 19.2417 14.9759 19.5433 15.7039C19.5838 15.8017 19.6217 15.9004 19.6569 16C19.8837 16.6416 20 17.3179 20 18H17.9981Z"
                          fill="#2D2D3B"
                        ></path>
                        <path
                          d="M14 18H12C12 15.2386 9.76142 13 7 13C4.23858 13 2 15.2386 2 18H0C0 14.134 3.13401 11 7 11C10.866 11 14 14.134 14 18Z"
                          fill="#2D2D3B"
                        ></path>
                      </svg>
                      <span>{ButtonLanguage.assign}</span>
                    </Dropdown.Item>
                    <Dropdown.Item onClick={() => this.delete_record(value)}>
                      <svg
                        width={19}
                        height={19}
                        viewBox="0 0 18 20"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
                          fill="#2D2D3B"
                        />
                      </svg>
                      <span>{orderLanguage.archived}</span>
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              );
            },
          },
        },
      ];
    }

    const option = {
      responsive: "standard",
      searchOpen: false,
      search: false,
      searchAlwaysOpen: false,
      print: false,
      serverSide: true,
      pagination: true,
      count: this.state.totalSize,
      rowsPerPageOptions: [50, 100, 300, 500],
      customToolbarSelect: (selectedRows, displayData, setSelectedRows) => {
        return (
          <div className="btn-list-order productbtn-list">
            <Dropdown>
              <Dropdown.Toggle className="btn dropdown-toggle cust-search-button mb-0 cust-date me-sm-2 me-0">
                <span className="px-3 py-1">{productLanguage.Applyaction}</span>
              </Dropdown.Toggle>
              <Dropdown.Menu className="cust-drop-box">
                <Dropdown.Item onClick={this.changeStatus}>
                  Change Order Status
                </Dropdown.Item>
                <Dropdown.Item onClick={this.AssignTeam}>
                  Assign Team member
                </Dropdown.Item>
                {this.state.OrderStatus == "11" && (
                  <Dropdown.Item
                    onClick={() =>
                      this.handlePaymentCheck(this.state.Order_ids)
                    }
                  >
                    Check payment
                  </Dropdown.Item>
                )}
              </Dropdown.Menu>
            </Dropdown>
          </div>
        );
      },
      onTableChange: (action, state) => {
        if (action === "changePage") {
          this.setState({ page: state.page + 1, Loader: true }, () => {
            this.get_order_data(
              this.state.page,
              this.state.sizePerPage,
              this.state.OrderStatus
            );
          });
        } else if (action === "changeRowsPerPage") {
          this.setState(
            { sizePerPage: state.rowsPerPage, Loader: true },
            () => {
              this.get_order_data(
                this.state.page,
                this.state.sizePerPage,
                this.state.OrderStatus
              );
            }
          );
        } else if (action === "sort") {
          this.setState(
            {
              defaultSorted: [
                {
                  dataField: state.sortOrder.name,
                  order: state.sortOrder.direction,
                  Loader: true,
                },
              ],
            },
            () => {
              this.get_order_data(
                this.state.page,
                this.state.sizePerPage,
                this.state.OrderStatus
              );
            }
          );
        } else if (action === "rowSelectionChange") {
          let selectedRow = state.selectedRows.data;
          let PC_arr = [];
          for (let i = 0; i < this.state.order_data.length; i++) {
            let checked = selectedRow.findIndex((obj) => obj.index === i);
            if (checked != -1) {
              PC_arr.push(this.state.order_data[i].id);
            }
          }
          this.setState({ Order_ids: PC_arr });
        }
      },
      textLabels: {
        body: {
          noMatch:
            this.context.language === "english"
              ? "the order you are searching for is not found"
              : "الطلب الذي تبحث عنه غير موجود",
          toolTip: "Sort",
          columnHeaderTooltip: (column) =>
            `${productLanguage.Sortfor} ${column.label}`,
        },
        pagination: {
          next: "Next Page >",
          previous: "< Previous Page",
          rowsPerPage: "Rows per page:",
          displayRows: "of",
        },
        toolbar: {
          search: "Search",
          downloadCsv: "Download CSV",
          print: "Print",
          viewColumns: productLanguage.Viewcolumns,
          filterTable: "Filter Table",
        },
        filter: {
          all: false,
          title: false,
          reset: false,
        },
        // viewColumns: {
        //   title: "Show Column",
        //   titleAria: "Show/Hide Table Columns",
        // },
        selectedRows: {
          text: "row(s) selected",
          delete: "",
          deleteAria: "Apply action on Selected Rows",
        },
      },
      // onColumnSortChange: this.onChangeColumnSort,
      selectableRows: true,
      rowsPerPage: this.state.sizePerPage,
      onFilterConfirm: (filterList) => {},
      onFilterDialogOpen: () => {},
      onFilterDialogClose: () => {},
      filter: true,
      filterType: "custom",
      display: true,
      customFilterDialogFooter: (
        currentFilterList,
        applyNewFilters,
        filterList
      ) => {
        return (
          <div
            className="p-0 rounded-3"
            style={{
              fontFamily:
                this.context.language === "english"
                  ? "Poppins"
                  : "Noto Kufi Arabic",
            }}
          >
            <div className="row">
              <div className="col-12 form-group mt-3 d-xl-flex align-items-center">
                <label className="cust-radio mb-0">
                  <input
                    type="radio"
                    id="barcode"
                    name="filter-number"
                    onChange={this.filterType}
                    defaultChecked
                  />
                  <span className="checkmark"></span>
                  <p>{DashboardLanguage.OrderNumber}</p>
                </label>
                <label className="cust-radio mb-0 ms-xl-2">
                  <input
                    type="radio"
                    id="awb"
                    name="filter-number"
                    onChange={this.filterType}
                  />
                  <span className="checkmark"></span>
                  <p>{titleLanguage.AWBNumber}</p>
                </label>
                <label className="cust-radio mb-0 ms-xl-2">
                  <input
                    type="radio"
                    id="invoice"
                    name="filter-number"
                    onChange={this.filterType}
                  />
                  <span className="checkmark"></span>
                  <p>{ButtonLanguage.InvoiceNumber}</p>
                </label>
                <label className="cust-radio mb-0 ms-xl-2">
                  <input
                    type="radio"
                    id="phone"
                    name="filter-number"
                    onChange={this.filterType}
                  />
                  <span className="checkmark"></span>
                  <p>{titleLanguage.Phone}</p>
                </label>
              </div>
              <div className="col-12 form-group">
                <textarea
                  placeholder={productLanguage.TypeLineByLine}
                  className="form-control input-custom-class h-auto"
                  rows={5}
                  name="NumberFilter"
                  onChange={this.numberfilterChange}
                  id="barcodeInput"
                />
                {/* <div>
                  <ul className="d-flex align-items-center flex-wrap">
                    <li className="me-2 mb-3">
                      <bdi className="barcode-bg py-1 px-2 mx-2 rounded">jhdvbgdkj</bdi>
                      <mark className="bg-transparent bi bi-x p-0"></mark>
                    </li>
                  </ul>
                </div> */}
              </div>
              <div className="col-md-6 form-group">
                <label className="d-block">
                  {DashboardLanguage.CustomerName}
                </label>
                <input
                  type="text"
                  className="form-control input-custom-class"
                  placeholder={titleLanguage.EnterCustomername}
                  name="CustomerFilterName"
                  onChange={this.filterChange}
                  value={this.state.CustomerFilterName}
                />
              </div>
              <div className="col-md-6 form-group">
                <label className="d-block">{orderLanguage.orderStatus}</label>
                <select
                  className="form-select input-custom-class"
                  name="OrderStatus"
                  onChange={this.filterChange}
                  value={this.state.OrderStatus}
                >
                  <option value="">Select status</option>
                  <option value="1">{DashboardLanguage.Pending}</option>
                  <option value="2">{orderLanguage.prepared}</option>
                  <option value="3">{orderLanguage.readyToShip}</option>
                  <option value="4">{orderLanguage.shipped}</option>
                  <option value="5">{orderLanguage.delivered}</option>
                  <option value="6">{orderLanguage.cancelled}</option>
                  <option value="7">{orderLanguage.archived}</option>
                  <option value="8">{titleLanguage.Returned}</option>
                  <option value="9">{titleLanguage.PartiallyReturned}</option>
                  <option value="10">{titleLanguage.Refund}</option>
                  <option value="11">{titleLanguage.PendingPayment}</option>
                  <option value="12">{titleLanguage.Disputed}</option>
                </select>
              </div>
              <div className="col-md-6 form-group">
                <label className="d-block">{ButtonLanguage.CustomerCity}</label>
                <select
                  className="form-select input-custom-class"
                  name="CustomerFilterCity"
                  onChange={this.filterChange}
                  value={this.state.CustomerFilterCity}
                >
                  <option value="">{ButtonLanguage.Selectcity}</option>
                  {this.state.AllCity.length > 0 &&
                    this.state.AllCity.map((item) => {
                      return <option value={item.id}>{item.english}</option>;
                    })}
                </select>
              </div>
              <div className="col-md-6 form-group">
                <label className="d-block">{userLanguage.Area}</label>
                <select
                  className="form-select input-custom-class"
                  name="CustomerFilterArea"
                  onChange={this.filterChange}
                  value={this.state.CustomerFilterArea}
                >
                  <option defaultValue>{userLanguage.SelectArea}</option>
                  {this.state.AllArea.length > 0 &&
                    this.state.AllArea.map((item) => {
                      return <option value={item.id}>{item.english}</option>;
                    })}
                </select>
              </div>
              <div className="col-md-6 form-group">
                <label className="d-block">{userLanguage.Email}</label>
                <input
                  type="email"
                  className="form-control input-custom-class"
                  placeholder="Enter customer Email Address"
                  name="CustomerFilterEmail"
                  value={this.state.CustomerFilterEmail}
                  onChange={this.filterChange}
                />
              </div>
              {/* <div className="col-md-6 form-group">
                <label className="d-block">Return Status</label>
                <select className="form-select input-custom-class" >
                  <option defaultValue>Select Return Status</option>
                  <option value="">
                  </option>
                </select>
              </div> */}
              <div className="col-md-6 form-group">
                <label className="d-block">
                  {orderLanguage.shippingMethod}
                </label>
                <select
                  className="form-select input-custom-class"
                  name="CustomerFilterShippingCompany"
                  onChange={this.filterChange}
                  value={this.state.CustomerFilterShippingCompany}
                >
                  <option defaultValue>Select Shipping method</option>
                  <option value=""></option>
                </select>
              </div>
              <div className="col-md-6 form-group">
                <label className="d-block">{orderLanguage.paymentMethod}</label>
                <select
                  className="form-select input-custom-class"
                  name="customFilterPaymentMethod"
                  onChange={this.filterChange}
                  value={this.state.customFilterPaymentMethod}
                >
                  <option defaultValue>Select Payment method</option>
                  {paymentMethods.map((item) => {
                    return (
                      <option key={item.id} value={item.id}>
                        {item.name}
                      </option>
                    );
                  })}
                </select>
              </div>
              <div className="col-md-6 form-group">
                <label className="d-block">{productLanguage.taggedWith}</label>
                <input
                  type="text"
                  className="form-control input-custom-class"
                  placeholder="Enter tag"
                />
              </div>
              <div className="col-md-6 form-group">
                <label className="d-block">
                  {userLanguage.PaymentprocessID}
                </label>
                <input
                  type="text"
                  className="form-control input-custom-class"
                  placeholder="Enter payment process id"
                />
              </div>
              <div className="col-md-6 form-group">
                <label className="d-block">{productLanguage.FromDate}</label>
                <DatePicker
                  name="CustomerFilterFromDate"
                  className="form-control input-custom-class"
                  onChange={this.filterStartDateChange}
                  value={this.state.CustomerFilterFromDate}
                  placeholderText="YYYY-MM-DD"
                />
              </div>
              <div className="col-md-6 form-group">
                <label className="d-block">{productLanguage.ToDate}</label>
                <DatePicker
                  name="CustomerFilterToDate"
                  className="form-control input-custom-class"
                  onChange={this.filterEndDateChange}
                  value={this.state.CustomerFilterToDate}
                  placeholderText="YYYY-MM-DD"
                />
              </div>
              <div className="col-12 form-group text-center mt-5">
                <button
                  type="button"
                  className="btn red-btn"
                  onClick={() =>
                    this.get_order_data(
                      this.state.page,
                      this.state.sizePerPage,
                      this.state.OrderStatus
                    )
                  }
                >
                  {productLanguage.filter}
                </button>
                <button
                  type="button"
                  className="btn red-btn mx-3"
                  onClick={this.clearFilter}
                >
                  {productLanguage.clearAll}
                </button>
              </div>
            </div>
          </div>
        );
      },
    };

    return (
      <Adminlayout>
        {this.state.Loader && (
          <div className="loader-main">
            <div className="loader-inr">
              <img src={loader} alt="" />
            </div>
          </div>
        )}
        <div className="container-fluid">
          <div className="row common-space align-items-center">
            <div className="col-6  text-start rtl-txt-start">
              <div className="common-header-txt">
                <h3>{titleLanguage.orders}</h3>
              </div>
            </div>
            {/* <div className="col-6  text-end rtl-txt-end">
              <div className="common-red-btn">
                <a href="#" className="btn red-btn">
                  {ButtonLanguage.exportList}
                </a>
              </div>
            </div> */}
          </div>

          <div className="row common-space">
            <div className="col-md-12">
              <div className="white-box">
                <div className="order-tabs-new">
                  {/* <div className="comn-order-lbl">
                    <input type="radio" id="all-order" name="order-list" onChange={this.selectSatus} defaultChecked />
                    <label className="d-flex align-items-center" htmlFor="all-order">
                      <bdi>All Orders</bdi>
                      <span>95326</span>
                    </label>
                  </div> */}
                  {this.state.Order_Tab.length > 0 &&
                    this.state.Order_Tab.map((item) => {
                      return (
                        <div className="comn-order-lbl">
                          <input
                            type="radio"
                            id={item.id}
                            name="order-list"
                            onChange={this.selectSatus}
                          />
                          <label
                            className="d-flex align-items-center"
                            htmlFor={item.id}
                          >
                            <bdi>
                              {" "}
                              {this.context.language === "english"
                                ? item.labelEng
                                : item.labelArb}
                            </bdi>
                            <span>{item.count}</span>
                          </label>
                        </div>
                      );
                    })}
                  {/* <div className="comn-order-lbl">
                    <input type="radio" id="prepared" name="order-list" onChange={this.selectSatus} />
                    <label className="d-flex align-items-center" htmlFor="prepared">
                      <bdi>prepared</bdi>
                      <span>95326</span>
                    </label>
                  </div>
                  <div className="comn-order-lbl">
                    <input type="radio" id="ready-to-ship" name="order-list" onChange={this.selectSatus} />
                    <label className="d-flex align-items-center" htmlFor="ready-to-ship">
                      <bdi>ready to ship</bdi>
                      <span>95326</span>
                    </label>
                  </div>
                  <div className="comn-order-lbl">
                    <input type="radio" id="shipped" name="order-list" onChange={this.selectSatus} />
                    <label className="d-flex align-items-center" htmlFor="shipped">
                      <bdi>shipped</bdi>
                      <span>95326</span>
                    </label>
                  </div>
                  <div className="comn-order-lbl">
                    <input type="radio" id="delivered" name="order-list" onChange={this.selectSatus} />
                    <label className="d-flex align-items-center" htmlFor="delivered">
                      <bdi>delivered</bdi>
                      <span>95326</span>
                    </label>
                  </div>
                  <div className="comn-order-lbl">
                    <input type="radio" id="cancelled" name="order-list" onChange={this.selectSatus} />
                    <label className="d-flex align-items-center" htmlFor="cancelled">
                      <bdi>cancelled</bdi>
                      <span>95326</span>
                    </label>
                  </div>
                  <div className="comn-order-lbl">
                    <input type="radio" id="archieved" name="order-list" onChange={this.selectSatus} />
                    <label className="d-flex align-items-center" htmlFor="archieved">
                      <bdi>archieved</bdi>
                      <span>95326</span>
                    </label>
                  </div> */}
                  <div className="comn-order-lbl">
                    <Dropdown className="cust-drop">
                      <Dropdown.Toggle
                        className="bg-transparent "
                        id="dropdown-basic"
                        align="end"
                      >
                        {/* <input type="radio" id="more" name="order-list" /> */}
                        {/* <label className="d-flex align-items-center" htmlFor="more"> */}
                        <bdi>{productLanguage.More}</bdi>
                        {/* </label> */}
                      </Dropdown.Toggle>
                      <Dropdown.Menu>
                        <Dropdown.Item
                          id="returned"
                          onClick={(e) => this.selectSatus(e)}
                        >
                          {titleLanguage.Returned}
                        </Dropdown.Item>
                        <Dropdown.Item
                          id="partially-returned"
                          onClick={(e) => this.selectSatus(e)}
                        >
                          {titleLanguage.PartiallyReturned}
                        </Dropdown.Item>
                        <Dropdown.Item
                          id="archieved"
                          onClick={(e) => this.selectSatus(e)}
                        >
                          {titleLanguage.Archieved}
                        </Dropdown.Item>
                        {/* <Dropdown.Item id="refund" onClick={(e) => this.selectSatus(e)}>
                          {titleLanguage.Refund}
                        </Dropdown.Item> */}
                        <Dropdown.Item
                          id="panding-payment"
                          onClick={(e) => this.selectSatus(e)}
                        >
                          {titleLanguage.PendingPayment}
                        </Dropdown.Item>
                        <Dropdown.Item
                          id="disputed"
                          onClick={(e) => this.selectSatus(e)}
                        >
                          {titleLanguage.Disputed}
                        </Dropdown.Item>
                      </Dropdown.Menu>
                    </Dropdown>
                  </div>
                </div>
                <>
                  {/* <div className="btn-list-order">
                  <button
                    className="btn white-btn me-sm-2 me-0"
                    onClick={this.filter_handleShow}
                  >
                    {orderLanguage.filter}{" "}
                    <i className="bi bi-caret-down-fill ms-2" />
                  </button>
                  <Dropdown>
                    <Dropdown.Toggle className="btn dropdown-toggle cust-search-button mb-0 cust-date me-sm-2 me-0">
                      <span>{orderLanguage.selectDate}</span>
                    </Dropdown.Toggle>
                    <Dropdown.Menu className="cust-drop-box fix-box-drop">
                      <div className="row m-0">
                        <div className="col-md-6 form-group pe-0">
                          <label>{orderLanguage.From}</label>
                          <input type="date" className="form-control" />
                        </div>
                        <div className="col-md-6 form-group">
                          <label>{orderLanguage.To}</label>
                          <input type="date" className="form-control" />
                        </div>
                        <div className="col-12">
                          <div
                            className="btn-group pt-3 pb-3 d-block"
                            role="group"
                            aria-label="Basic radio toggle button group"
                          >
                            <ul>
                              <li>
                                <input
                                  type="radio"
                                  className="btn-check date-checked"
                                  name="btnradio"
                                  id="btnradio1"
                                  autoComplete="off"
                                  defaultChecked
                                />
                                <label
                                  className="btn gray-btn-date w-100"
                                  htmlFor="btnradio1"
                                >
                                  {orderLanguage.today}
                                </label>
                              </li>
                              <li>
                                <input
                                  type="radio"
                                  className="btn-check date-checked"
                                  name="btnradio"
                                  id="btnradio2"
                                  autoComplete="off"
                                />
                                <label
                                  className="btn gray-btn-date w-100"
                                  htmlFor="btnradio2"
                                >
                                  {orderLanguage.yesterday}
                                </label>
                              </li>
                              <li>
                                <input
                                  type="radio"
                                  className="btn-check date-checked"
                                  name="btnradio"
                                  id="btnradio3"
                                  autoComplete="off"
                                />
                                <label
                                  className="btn gray-btn-date w-100"
                                  htmlFor="btnradio3"
                                >
                                  {orderLanguage.last_3_Months}
                                </label>
                              </li>

                              <li>
                                <input
                                  type="radio"
                                  className="btn-check date-checked"
                                  name="btnradio"
                                  id="btnradio4"
                                  autoComplete="off"
                                />
                                <label
                                  className="btn gray-btn-date w-100"
                                  htmlFor="btnradio4"
                                >
                                  {orderLanguage.thisYears}
                                </label>
                              </li>
                            </ul>
                          </div>
                          <div className="col-12 text-center">
                            <div className="common-red-btn">
                              <a href="#" className="btn black-btn me-2">
                                {ButtonLanguage.cancel}
                              </a>
                              <a href="add-admin" className="btn red-btn">
                                {ButtonLanguage.update}
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Dropdown.Menu>
                  </Dropdown>
                  <Dropdown>
                    <Dropdown.Toggle className="btn dropdown-toggle cust-search-button mb-0 cust-date me-sm-2 me-0">
                      <span>{orderLanguage.status}</span>
                    </Dropdown.Toggle>
                    <Dropdown.Menu className="cust-drop-box cust-status">
                      <div className="row m-0">
                        <div className="col-md-12">
                          <div className="position-relative">
                            <input
                              className="form-control"
                              type="search"
                              placeholder={orderLanguage.search}
                            />
                          </div>
                          <div className="drop-body-cust">
                            <ul className="mt-3 mb-3">
                              <li>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    {orderLanguage.shipped}
                                  </label>
                                </div>
                              </li>
                              <li>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    {orderLanguage.readyToShip}
                                  </label>
                                </div>
                              </li>
                              <li>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    {orderLanguage.delivered}
                                  </label>
                                </div>
                              </li>
                              <li>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    {orderLanguage.cancelled}
                                  </label>
                                </div>
                              </li>
                              <li>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    {orderLanguage.pendingPayment}
                                  </label>
                                </div>
                              </li>
                              <li>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    {orderLanguage.refunded}
                                  </label>
                                </div>
                              </li>
                              <li>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    {orderLanguage.returning}
                                  </label>
                                </div>
                              </li>
                              <li>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    {orderLanguage.archived}
                                  </label>
                                </div>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </Dropdown.Menu>
                  </Dropdown>
                </div> */}
                </>
                <div className="custom-table">
                  <div className=" dataTables_wrapper no-footer">
                    {this.state.order_data && (
                      <MuiThemeProvider theme={theme}>
                        <div className="right-menu table-over-fix-class ms-auto position-relative">
                          <MUITable
                            data={this.state.order_data}
                            columns={columns}
                            options={option}
                          />
                          <div className="fix-search d-flex align-items-center">
                            <div
                              className="position-relative search-sm-screen"
                              id="search-menu"
                            >
                              <input
                                type="search"
                                name="search"
                                className="form-control top-search ps-5 input-custom-class mb-0"
                                placeholder={productLanguage.search}
                                onChange={this.handleSearch}
                              />
                              <span className="search-icn position-absolute ms-3">
                                <img src={SearchIcon} alt="" />
                              </span>
                            </div>
                            {/* <button className="border-0 bg-transparent dark-red-txt w-100">Clear Filter x</button> */}
                          </div>
                        </div>
                      </MuiThemeProvider>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ------------------------modal-------------------------- */}
        <Modal
          dialogClassName="modal-dialog-centered cust-width-modal"
          className="edit-user-modal cust-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.search_show}
          onHide={this.edit_filterClose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">{orderLanguage.filter}</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.edit_filterClose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <form className="row modal-form">
              <div className="col-md-12 form-group text-end mb-3">
                <a href="#" className="red-underline">
                  {orderLanguage.reset}
                </a>
              </div>
              <div className="col-md-6 form-group">
                <label>{orderLanguage.status}</label>
                <select className="form-control form-select">
                  <option>All</option>
                  <option>{DashboardLanguage.Completed}</option>
                  <option>{DashboardLanguage.Pending}</option>
                  <option>{DashboardLanguage.Cancelled}</option>
                </select>
              </div>
              <div className="col-md-6 form-group">
                <label>{orderLanguage.city}</label>
                <Dropdown>
                  <Dropdown.Toggle className="btn dropdown-toggle cust-search-button w-100">
                    <span>New York</span>
                  </Dropdown.Toggle>
                  <Dropdown.Menu className="w-100 cust-drop-box">
                    <div className="u-search-dw">
                      <div className="sear-u-inp p-2 bg-transparent">
                        <div className="position-relative">
                          <input
                            className="form-control"
                            type="search"
                            placeholder={orderLanguage.search}
                          />
                        </div>
                        <div className="drop-body-cust">
                          <ul>
                            <li>
                              <span>New York</span>
                            </li>
                            <li>
                              <span>Austin</span>
                            </li>
                            <li>
                              <span>Columbus</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </Dropdown.Menu>
                </Dropdown>
              </div>
              <div className="col-md-6 form-group">
                <label>{orderLanguage.shippingMethod}</label>
                <select className="form-control form-select">
                  <option>Aramex</option>
                  <option>Libsi Markah</option>
                  <option>UPs Shipping</option>
                  <option>Shipa</option>
                </select>
              </div>
              <div className="col-md-6 form-group">
                <label>{orderLanguage.paymentMethod}</label>
                <select className="form-control form-select">
                  <option>Paypal</option>
                  <option>Google Pay</option>
                  <option>Credit Card</option>
                  <option>COD</option>
                </select>
              </div>
              <div className="col-md-12 form-group text-center mb-3">
                <button type="button" className="btn red-btn">
                  {ButtonLanguage.save}
                </button>
              </div>
            </form>
          </Modal.Body>
        </Modal>

        {/* status order */}
        <Modal
          dialogClassName="modal-dialog-centered edit-user-modal cust-modal"
          size="md"
          show={this.state.changeStatus}
          onHide={this.changeStatusClose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">Change Order Status </h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.changeStatusClose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <form className="row">
              <div className="col-12 form-group">
                <select className="form-select input-custom-class">
                  <option value="">Select status</option>
                  <option value="0">{orderLanguage.prepared}</option>
                  <option value="1">{orderLanguage.readyToShip}</option>
                  <option value="2">{orderLanguage.shipped}</option>
                  <option value="3">{orderLanguage.delivered}</option>
                  <option value="4">{DashboardLanguage.Pending}</option>
                  <option value="5">{orderLanguage.cancelled}</option>
                  <option value="6">{orderLanguage.archived}</option>
                </select>
              </div>
              <div className="col-12 ">
                <button className="btn red-btn w-100">APPLY</button>
              </div>
            </form>
          </Modal.Body>
        </Modal>

        <Modal
          dialogClassName="modal-dialog-centered edit-user-modal cust-modal"
          size="md"
          show={this.state.AssignTeam}
          onHide={this.AssignTeamClose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">Assign Team Member</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.AssignTeamClose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <form className="row">
              <div className="col-12 form-group">
                <select className="form-select input-custom-class">
                  <option value="">Select team member name</option>
                  <option value="0">team name</option>
                </select>
              </div>
              <div className="col-12 ">
                <button className="btn red-btn w-100">APPLY</button>
              </div>
            </form>
          </Modal.Body>
        </Modal>

        <Modal
          dialogClassName="modal-dialog-centered edit-user-modal cust-modal payment-statu-popup"
          size="md"
          show={this.state.paymentcheckpopup}
          onHide={this.PaymentCheckModalClose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">Payment Status</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.PaymentCheckModalClose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            {this.state.paymentCheckedloader ? (
              <div className="loader-main position-absolute">
                <div className="loader-inr">
                  <img src={loader} alt="" />
                </div>
              </div>
            ) : (
              <div className="row">
                <div className="col-12 position-relative">
                  <div>
                    <div className="form-group pb-3 mt-2">
                      <div className="table-responsive table-custom-info">
                        <table className="table">
                          <thead>
                            <tr>
                              <th>Order ID</th>
                              <th>Message</th>
                            </tr>
                          </thead>
                          <tbody>
                            {this.state.paymentCheckedData.length > 0 &&
                              this.state.paymentCheckedData.map((item, i) => {
                                return (
                                  <tr>
                                    <td>{item.orderid}</td>
                                    <td>{item.message}</td>
                                  </tr>
                                );
                              })}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </Modal.Body>
          <ModalFooter>
            <div class="form-group pb-0 my-0 mx-auto">
              <div class="text-md-end text-center">
                <button
                  type="submit"
                  class="red-btn ms-3"
                  onClick={this.PaymentCheckModalClose}
                >
                  Ok
                </button>
              </div>
            </div>
          </ModalFooter>
        </Modal>
      </Adminlayout>
    );
  }
}

export default Orders;
