import React, { Component } from 'react';
import { Dropdown, Modal, ModalFooter } from 'react-bootstrap';
import Adminlayout from '../../Components/AdminLayout/Adminlayout';
import DataTable from '../../Components/DataTable';
import LanguageContext from "../../contexts/languageContext";
import toastr from "toastr";

import {
    APIBaseUrl,
    API_Path,
    buttonArabic,
    buttonEnglish,
    teamArabic,
    teamEnglish,
    TableFieldArabic,
    TableFieldEnglish,
    titleArabic,
    titleEnglish,
    categoryEnglish,
    categoryArabic,
} from "../../const";
import { PostApi } from '../../helper/APIService';

let mainCategoryArr = [];
let CategoryArr = [];
let subCategoryArr = [];

class Categories extends Component {
    static contextType = LanguageContext;

    constructor(props) {
        super(props);
        this.state = {
            mainCategorySelectBoxData: [],
            CategorySelectBoxData: [],

            maincategoryenglish: '',
            mainCategoryId: '',
            mainCategoryEnglish: '',
            mainCategoryArabic: '',
            mainCategoryDescEnglish: '',
            mainCategoryDescArabic: '',
            mainCatSlugEnglish: '',
            mainCatSlugArabic: '',

            CategoryId: '',
            CategoryEnglish: '',
            CategoryArabic: '',
            CategoryDescEnglish: '',
            CategoryDescArabic: '',
            CatSlugEnglish: '',
            CatSlugArabic: '',

            subCategoryId: '',
            subCategoryEnglish: '',
            subCategoryArabic: '',
            subCategoryDescEnglish: '',
            subCategoryDescArabic: '',
            subCatSlugEnglish: '',
            subCatSlugArabic: '',

            selectMainCategory: '',
            selectCategory: '',
            selectCategoryArabic1: '',

            addmaincat: false,
            addcat: false,
            addsubcat: false,

            page: 1,
            get_order_data: "",
            sizePerPage: 10,
            totalSize: 100,

            mainCatprofilePicture: '',
            CatprofilePicture: '',
            subCatprofilePicture: '',

            mainCat_orderData: [],
            Cat_orderData: [],
            subCat_orderData: [],

            deletemaincategory: false,
            deletecategory: false,
            deletesubcategory: false,

            isMainCategoryEdit: false,
            isCategoryEdit: false,
            isSubCategoryEdit: false,

            editMainFilteredData: '',
            editFilteredData: '',
            editsubFilteredData: '',

            reAssignNewCat: false,
            newSubCatData: "",

            isImg: false,

            defaultSorted: [
                {
                    dataField: "id",
                    order: "asc",
                },
            ]
        }
    }

    componentDidMount() {
        this.getMainCategoryData()
        this.getCategoryData()
        this.getSubCategoryData()
    }

    getMainCategoryData = () => {
        let data = {
            defaultSorted: this.state.defaultSorted
        };

        let path = API_Path.getMainCat;
        const getMainCategoryPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        getMainCategoryPromise.then((res) => {
            if (res) {
                if (res.data.success) {
                    this.setState({ mainCat_orderData: res.data.data });
                    let tempArray = []

                    for (let i = 0; i < res.data.data.length; i++) {
                        if (res.data.data[i].status == 1) {
                            tempArray.push(res.data.data[i])
                        }
                    }
                    this.setState({ mainCategorySelectBoxData: tempArray })
                } else {

                }
            }
        });
    };

    getCategoryData = () => {
        let data = {
            defaultSorted: this.state.defaultSorted
        };

        let path = API_Path.getCat;
        const getCategoryPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        getCategoryPromise.then((res) => {
            if (res) {
                if (res.data.success) {
                    this.setState({ Cat_orderData: res.data.data });
                    let tempArray = []

                    for (let i = 0; i < res.data.data?.length; i++) {
                        if (res.data.data[i].status == 1) {
                            tempArray.push(res.data.data[i])
                        }
                    }
                    this.setState({ CategorySelectBoxData: tempArray })
                }
            }
        });
    };

    getSubCategoryData = () => {
        let data = {
            page: this.state.page,
            sizePerPage: this.state.sizePerPage,
            defaultSorted: this.state.defaultSorted
        };

        let path = API_Path.getSubCat;
        const getSubCategoryPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        getSubCategoryPromise.then((res) => {
            if (res) {
                if (res.data.success) {
                    this.setState({ subCat_orderData: res.data.data[0], totalCount: res.data.data[1][0].cnt });
                }
            }
        });
    };

    getCategoryRelative = () => {
        let data = { main_category_id: this.state.selectMainCategory.split('@').pop() };

        let path = API_Path.getSubCategoryDataRelative;
        const getCategoryRelativePromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        getCategoryRelativePromise.then((res) => {
            if (res) {
                if (res.data.status) {
                    this.setState({ CategorySelectBoxData: res.data.data })
                }
            }
        });
    }

    // getSubCategoryRelative = () => {
    //     let data = { category_id: this.state.selectCategory };

    //     let path = API_Path.getSubCategoryRelative;
    //     const getSubCategoryRelativePromise = new Promise((resolve, reject) => {
    //         resolve(PostApi(path, data));
    //     });

    //     getSubCategoryRelativePromise.then((res) => {
    //         if (res) {
    //             if (res.data.status) {
    //                 console.log("subcat", res.data)
    //             }
    //         }
    //     });
    // }

    imageUpload = (e, name) => {
        console.log(e.target.files[0])
        const form = new FormData();
        for (var i = 0; i < e.target.files.length; i++) {
            form.append("file", e.target.files[i]);
        }
        const addFilePromise = new Promise((resolve, reject) => {
            resolve(PostApi(API_Path.addFileInS3, form));
        });

        addFilePromise.then((res) => {
            if (res) {
                if (res.data.success) {
                    if (name === 'main') {
                        this.setState({ mainCatprofilePicture: res.data.data[0], isImg: true })
                    }
                    if (name === 'category') {
                        this.setState({ CatprofilePicture: res.data.data[0], isImg: true })
                    }
                    if (name === 'sub') {
                        this.setState({ subCatprofilePicture: res.data.data[0], isImg: true })
                    }
                } else {
                    console.log("cancel")
                }
            }
        });
    }

    maincathandleClose = () => {
        this.setState({ addmaincat: false, mainCategoryEnglish: '', mainCategoryArabic: '', mainCategoryDescEnglish: '', mainCategoryDescArabic: '', mainCatprofilePicture: '', mainCatSlugArabic: '', isMainCategoryEdit: false, editMainFilteredData: '', isImg: false })
    }

    addmaincat = () => {
        this.setState({ addmaincat: true })
    }

    addcat = () => {
        this.setState({ addcat: true })
    }

    cathandleClose = () => {
        this.setState({ addcat: false, CategoryEnglish: '', CategoryArabic: '', CategoryDescEnglish: '', CategoryDescArabic: '', CatprofilePicture: '', CatSlugArabic: '', CatSlugEnglish: '', isCategoryEdit: false, editFilteredData: '', selectMainCategory: '', isImg: false })
    }

    addsubcat = () => {
        this.setState({ addsubcat: true })
    }

    subcathandleClose = () => {
        this.setState({ addsubcat: false, subCategoryEnglish: '', subCategoryArabic: '', subCategoryDescEnglish: '', subCategoryDescArabic: '', subCatprofilePicture: '', subCatSlugArabic: '', subCatSlugEnglish: '', isSubCategoryEdit: false, editsubFilteredData: '', selectMainCategory: '', selectCategory: '', isImg: false })
    }

    handleMainCatChange = (e) => {
        this.setState({ [e.target.name]: e.target.value });
    };

    handleCatChange = (e) => {
        this.setState({ [e.target.name]: e.target.value })
    }

    handleSubCatChange = (e) => {
        this.setState({ [e.target.name]: e.target.value });
    }

    handleMainCategoryChange = (e) => {
        let value = e.target.value;

        let result = value.indexOf("@");

        let selectedCat = value.slice(0, result)
        this.setState({ selectMainCategory: value, selectMainCategorySlug: selectedCat }, () => {
            this.getCategoryRelative()
        })
    }

    handleCategoryChange = (e) => {
        let value = e.target.value;

        let result = value.indexOf("@");
        let selectedCat = value.slice(0, result)
        this.setState({ selectCategory: value, selectCategorySlug: selectedCat })
        // this.setState({ selectCategorySlug: selectedCat })
    }

    removethumbnailImages = () => {
        if (document.getElementById('maincatImageSizeInput')) {
            document.getElementById('maincatImageSizeInput').value = ""
        }
        if (document.getElementById('catImageSizeInput')) {
            document.getElementById('catImageSizeInput').value = ""
        }
        if (document.getElementById('subCatImageSizeInput')) {
            document.getElementById('subCatImageSizeInput').value = ""
        }
        this.setState({ mainCatprofilePicture: '', CatprofilePicture: '', subCatprofilePicture: '', isImg: false })
    }

    handleMainCatSubmit = () => {
        if (this.state.mainCategoryEnglish === "") {
            document.getElementById("mainCategoryEnglishErr").style.display = "block";
        }
        if (this.state.mainCategoryArabic === "") {
            document.getElementById("mainCategoryArabicErr").style.display = "block";
        }
        // if (this.state.mainCategoryDescEnglish === "") {
        //     document.getElementById("mainCategoryDescEnglishErr").style.display = "block";
        // }
        // if (this.state.mainCategoryDescArabic === "") {
        //     document.getElementById("mainCategoryDescArabicErr").style.display = "block";
        // }
        if (this.state.mainCatprofilePicture === "") {
            document.getElementById("maincatImageSizeInputErr").style.display = "block";
        }
        // if (this.state.mainCategoryEnglish !== "" && this.state.mainCategoryArabic !== "" && this.state.mainCategoryDescEnglish !== "" && this.state.mainCategoryDescArabic !== "" && this.state.mainCatprofilePicture !== "") {
        if (this.state.mainCategoryEnglish !== "" && this.state.mainCategoryArabic !== "" && this.state.mainCatprofilePicture !== "") {
            let data = {
                english: this.state.mainCategoryEnglish.toLowerCase(),
                arabic: this.state.mainCategoryArabic.toLowerCase(),
                description_english: this.state.mainCategoryDescEnglish,
                description_arabic: this.state.mainCategoryDescArabic,
                slug_english: '/' + this.state.mainCategoryEnglish.toLowerCase(),
                slug_arabic: '/' + this.state.mainCategoryArabic.toLowerCase(),
                thumbnail: this.state.mainCatprofilePicture,
                google_product_category_id: this.state.mainCategoryNumber
            };
            let path = API_Path.addMainCat;
            const addMainCatPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            addMainCatPromise.then((res) => {
                if (res.data.success) {
                    toastr.success(res.data.message)
                    mainCategoryArr.push(res)
                    this.setState({ mainCat_orderData: mainCategoryArr, isImg: false })
                    this.maincathandleClose()
                    this.getMainCategoryData()
                } else {
                    toastr.error(res.data.message)
                }
            });
        }
    };

    handleCatSubmit = () => {
        if (this.state.CategoryEnglish === "") {
            document.getElementById("CategoryEnglishErr").style.display = "block";
        }
        if (this.state.CategoryArabic === "") {
            document.getElementById("CategoryArabicErr").style.display = "block";
        }
        // if (this.state.CategoryDescEnglish === "") {
        //     document.getElementById("CategoryDescEnglishErr").style.display = "block";
        // }
        // if (this.state.CategoryDescArabic === "") {
        //     document.getElementById("CategoryDescArabicErr").style.display = "block";
        // }
        if (this.state.CatprofilePicture === "") {
            document.getElementById("catImageSizeInputErr").style.display = "block";
        }
        if (this.state.selectMainCategory === "") {
            document.getElementById("selectMainCategoryErr").style.display = "block"
        }
        // if (this.state.CategoryEnglish !== "" && this.state.CategoryArabic !== "" && this.state.CategoryDescEnglish !== "" && this.state.CategoryDescArabic !== "" && this.state.CatprofilePicture !== "" && this.state.selectMainCategory !== "") {
        if (this.state.CategoryEnglish !== "" && this.state.CategoryArabic !== "" && this.state.CatprofilePicture !== "" && this.state.selectMainCategory !== "") {
            let data = {
                english: this.state.CategoryEnglish.toLowerCase(),
                arabic: this.state.CategoryArabic.toLowerCase(),
                description_english: this.state.CategoryDescEnglish,
                description_arabic: this.state.CategoryDescArabic,
                slug_english: this.state.selectMainCategorySlug + '/' + this.state.CategoryEnglish.toLowerCase(),
                slug_arabic: this.state.selectMainCategorySlug + '/' + this.state.CategoryArabic.toLowerCase(),
                thumbnail: this.state.CatprofilePicture,
                main_category: this.state.selectMainCategory.substr(this.state.selectMainCategory.lastIndexOf('@') + 1),
                google_product_category_id: this.state.CategoryNumber
            };
            let path = API_Path.addCat;
            const addCatPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            addCatPromise.then((res) => {
                if (res.data.success) {
                    toastr['success'](res.data.message)
                    CategoryArr.push(res)
                    this.setState({ Cat_orderData: CategoryArr, isImg: false })
                    this.cathandleClose()
                    this.getCategoryData()
                } else {
                    toastr['error'](res.data.message)
                }
            });
        }
    }

    handleSubCatSubmit = () => {
        if (this.state.subCategoryEnglish === "") {
            document.getElementById("subCategoryEnglishErr").style.display = "block";
        }
        if (this.state.subCategoryArabic === "") {
            document.getElementById("subCategoryArabicErr").style.display = "block";
        }
        // if (this.state.subCategoryDescEnglish === "") {
        //     document.getElementById("subCategoryDescEnglishErr").style.display = "block";
        // }
        // if (this.state.subCategoryDescArabic === "") {
        //     document.getElementById("subCategoryDescArabicErr").style.display = "block";
        // }
        if (this.state.subCatprofilePicture === "") {
            document.getElementById("subCatImageSizeInputErr").style.display = "block";
        }
        if (this.state.selectMainCategory === "") {
            document.getElementById("selectMainCategoryErr").style.display = "block"
        }
        if (this.state.selectCategory === "") {
            document.getElementById("selectCategoryErr").style.display = "block"
        }
        // if (this.state.subCategoryEnglish !== "" && this.state.subCategoryArabic !== "" && this.state.subCategoryDescEnglish !== "" && this.state.subCategoryDescArabic !== "" && this.state.subCatprofilePicture !== "" && this.state.selectMainCategory !== "" && this.state.selectCategory !== "") {
        if (this.state.subCategoryEnglish !== "" && this.state.subCategoryArabic !== "" && this.state.subCatprofilePicture !== "" && this.state.selectMainCategory !== "" && this.state.selectCategory !== "") {
            let data = {
                english: this.state.subCategoryEnglish.toLowerCase(),
                arabic: this.state.subCategoryArabic.toLowerCase(),
                description_english: this.state.subCategoryDescEnglish,
                description_arabic: this.state.subCategoryDescArabic,
                slug_english: this.state.selectMainCategorySlug + '/' + this.state.selectCategorySlug + '/' + this.state.subCategoryEnglish.toLowerCase(),
                slug_arabic: this.state.selectMainCategorySlug + '/' + this.state.selectCategorySlug + '/' + this.state.subCategoryArabic.toLowerCase(),
                thumbnail: this.state.subCatprofilePicture,
                main_category: this.state.selectMainCategory.substr(this.state.selectMainCategory.lastIndexOf('@') + 1),
                category: this.state.selectCategory.substr(this.state.selectCategory.lastIndexOf('@') + 1),
                google_product_category_id: this.state.subCategoryNumber
            };
            let path = API_Path.addSubCat;
            const addSubCatPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            addSubCatPromise.then((res) => {
                if (res.data.success) {
                    toastr.success(res.data.message)
                    subCategoryArr.push(res)
                    this.setState({ subCat_orderData: subCategoryArr, isImg: false })
                    this.subcathandleClose()
                    this.getSubCategoryData()
                } else {
                    toastr.error(res.data.message)
                }
            });
        }
    }

    mainCatEdit = (id) => {
        this.setState({ isMainCategoryEdit: true })
        this.addmaincat()
        let data = { id: id };

        let path = API_Path.getMainCatById;
        const getMainCategoryByIdPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        getMainCategoryByIdPromise.then((res) => {
            if (res) {
                this.setState({
                    mainCategoryId: res.data.data[0].id,
                    mainCategoryEnglish: res.data.data[0].english,
                    mainCategoryArabic: res.data.data[0].arabic,
                    mainCategoryDescEnglish: res.data.data[0].description_english,
                    mainCategoryDescArabic: res.data.data[0].description_arabic,
                    mainCatSlugEnglish: res.data.data[0].slug_english,
                    mainCatSlugArabic: res.data.data[0].slug_arabic,
                    mainCatprofilePicture: res.data.data[0].thumbnail,
                    isImg: true,
                    mainCategoryNumber: res.data.data[0].google_product_category_id
                })
                // res.data.data[0].responseType = 'blob'
                // let path = new FileReader();
                // path.readAsDataURL(res.data.data[0].thumbnail)
                // console.log(path)
                // if (document.getElementById('maincatImageSizeInput')) {
                //     document.getElementById('maincatImageSizeInput').value = res.data.data[0].thumbnail.split('/').pop()
                // }
            }
        });
    }

    catEdit = (id) => {
        this.setState({ isCategoryEdit: true }, () => {
            this.addcat()
            let data = { id: id };

            let path = API_Path.getCatById;
            const getCategoryByIdPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getCategoryByIdPromise.then((res) => {
                if (res) {
                    console.log(res.data.data)
                    this.setState({
                        CategoryId: res.data.data[0].id,
                        CategoryEnglish: res.data.data[0].english,
                        CategoryArabic: res.data.data[0].arabic,
                        CategoryDescEnglish: res.data.data[0].description_english,
                        CategoryDescArabic: res.data.data[0].description_arabic,
                        CatSlugEnglish: res.data.data[0].slug_english,
                        CatSlugArabic: res.data.data[0].slug_arabic,
                        CatprofilePicture: res.data.data[0].thumbnail,
                        selectMainCategory: res.data.data[0].main_category_english + '@' + res.data.data[0].main_category,
                        selectMainCategorySlug: res.data.data[0].main_category_english,
                        isImg: true,
                        CategoryNumber: res.data.data[0].google_product_category_id
                    }, () => {
                        console.log(this.state.selectMainCategory)
                    })
                }
            });
        })
    }

    subCatEdit = (id) => {
        this.setState({ isSubCategoryEdit: true })
        this.addsubcat()
        let data = { id: id };

        let path = API_Path.getSubCatById;
        const getSubCategoryByIdPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        getSubCategoryByIdPromise.then((res) => {
            if (res) {
                console.log(res.data.data[0])
                this.setState({
                    subCategoryId: res.data.data[0].id,
                    subCategoryEnglish: res.data.data[0].english,
                    subCategoryArabic: res.data.data[0].arabic,
                    subCategoryDescEnglish: res.data.data[0].description_english,
                    subCategoryDescArabic: res.data.data[0].description_arabic,
                    subCatSlugEnglish: res.data.data[0].slug_english,
                    subCatSlugArabic: res.data.data[0].slug_arabic,
                    subCatprofilePicture: res.data.data[0].thumbnail,
                    selectMainCategory: res.data.data[0].main_category_english + '@' + res.data.data[0].main_category,
                    selectMainCategorySlug: res.data.data[0].main_category_english,
                    selectCategory: res.data.data[0].category_english + '@' + res.data.data[0].category,
                    selectCategorySlug: res.data.data[0].category_english,
                    isImg: true,
                    subCategoryNumber: res.data.data[0].google_product_category_id
                }, () => {
                    console.log(this.state.selectMainCategory)
                })
            }
        });
    }

    handleMainCatEdit = () => {
        let data = {
            id: this.state.mainCategoryId,
            english: this.state.mainCategoryEnglish.toLowerCase(),
            arabic: this.state.mainCategoryArabic.toLowerCase(),
            description_english: this.state.mainCategoryDescEnglish,
            description_arabic: this.state.mainCategoryDescArabic,
            slug_english: '/' + this.state.mainCategoryEnglish.toLowerCase(),
            slug_arabic: '/' + this.state.mainCategoryArabic.toLowerCase(),
            thumbnail: this.state.mainCatprofilePicture,
            google_product_category_id: this.state.mainCategoryNumber
        }

        let path = API_Path.editMainCat;
        const editMainCatPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        editMainCatPromise.then((res) => {
            if (res.data.success) {
                toastr.success(res.data.message)
                this.setState({ mainCat_orderData: res.data.data, isImg: false })
                this.getMainCategoryData()
                this.maincathandleClose()
            } else {
                toastr.error(res.data.message)
            }
        });
    }

    handleCatEdit = () => {
        console.log(this.state.maincategoryenglish)
        let data = {
            id: this.state.CategoryId,
            english: this.state.CategoryEnglish.toLowerCase(),
            arabic: this.state.CategoryArabic.toLowerCase(),
            description_english: this.state.CategoryDescEnglish,
            description_arabic: this.state.CategoryDescArabic,
            slug_english: this.state.selectMainCategorySlug + '/' + this.state.CategoryEnglish.toLowerCase(),
            slug_arabic: this.state.selectMainCategorySlug + '/' + this.state.CategoryArabic.toLowerCase(),
            thumbnail: this.state.CatprofilePicture,
            main_category: this.state.selectMainCategory.substr(this.state.selectMainCategory.lastIndexOf('@') + 1),
            google_product_category_id: this.state.CategoryNumber
        }

        let path = API_Path.editCat;
        const editCatPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        editCatPromise.then((res) => {
            if (res.data.success) {
                toastr.success(res.data.message)
                this.setState({ Cat_orderData: res.data.data, isImg: false })
                this.getCategoryData()
                this.cathandleClose()
            } else {
                toastr.error(res.data.message)
            }
        });
    }

    handleSubCatEdit = () => {
        let data = {
            id: this.state.subCategoryId,
            english: this.state.subCategoryEnglish.toLowerCase(),
            arabic: this.state.subCategoryArabic.toLowerCase(),
            description_english: this.state.subCategoryDescEnglish,
            description_arabic: this.state.subCategoryDescArabic,
            slug_english: this.state.selectMainCategorySlug + '/' + this.state.selectCategorySlug + '/' + this.state.subCategoryEnglish.toLowerCase(),
            slug_arabic: this.state.selectMainCategorySlug + '/' + this.state.selectCategorySlug + '/' + this.state.subCategoryArabic.toLowerCase(),
            thumbnail: this.state.subCatprofilePicture,
            main_category: this.state.selectMainCategory.substr(this.state.selectMainCategory.lastIndexOf('@') + 1),
            category: this.state.selectCategory.substr(this.state.selectCategory.lastIndexOf('@') + 1),
            google_product_category_id: this.state.subCategoryNumber
        }

        let path = API_Path.editSubCat;
        const editSubCatPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        editSubCatPromise.then((res) => {
            if (res.data.success) {
                toastr.success(res.data.message)
                this.setState({ subCat_orderData: res.data.data, isImg: false })
                this.getSubCategoryData()
                this.subcathandleClose()
            } else {
                toastr.error(res.data.message)
            }
        });
    }

    handleMainCatStatusChange = (e, id) => {
        const data = {
            id: id,
            mainCategory_status: e.target.checked ? 0 : 1,
        };
        const changeMainCatStatusPromise = new Promise((resolve) => {
            resolve(PostApi(API_Path.changeMainCatStatus, data));
        });
        changeMainCatStatusPromise.then((res) => {
            if (res.data.success) {
                toastr.success(res.data.message);
            } else {
                toastr.error(res.data.message);
            }
        });
    };

    handleCatStatusChange = (e, id) => {
        const data = {
            id: id,
            category_status: e.target.checked ? 0 : 1,
        };
        const changeCatStatusPromise = new Promise((resolve) => {
            resolve(PostApi(API_Path.changeCatStatus, data));
        });
        changeCatStatusPromise.then((res) => {
            if (res.data.success) {
                toastr.success(res.data.message);
            } else {
                toastr.error(res.data.message);
            }
        });
    };

    handleSubCatStatusChange = (e, id) => {
        const data = {
            id: id,
            subCategory_status: e.target.checked ? 0 : 1,
        };
        const changeSubCatStatusPromise = new Promise((resolve) => {
            resolve(PostApi(API_Path.changeSubCatStatus, data));
        });
        changeSubCatStatusPromise.then((res) => {
            if (res.data.success) {
                toastr.success(res.data.message);
            } else {
                toastr.error(res.data.message);
            }
        });
    };

    handleTableChange1 = (type, { page, sizePerPage, filters, sortField, sortOrder }) => {

        switch (type) {
            // case "pagination":
            //     this.setState({ page: page, sizePerPage: sizePerPage }, () => this.getSubCategoryData());
            //     break;

            case "filter":
                let search_val = this.state.search_val;
                let newFilter = {};
                if (Object.keys(filters).length) {
                    for (const dataField in filters) {
                        newFilter[dataField] = filters[dataField].filterVal;
                    }
                    newFilter = {
                        ...search_val,
                        ...newFilter,
                    };
                } else {
                    newFilter = {
                        title: "",
                        indicator: "",
                        definition: "",
                    };
                }
                this.setState(
                    {
                        search_val: newFilter,
                    },
                    // () => this.getSubCategoryData()
                    console.log(this.state.serach_val)
                );
                break;

            case "sort":
                this.setState(
                    {
                        defaultSorted: [
                            {
                                dataField: sortField,
                                order: sortOrder,
                            },
                        ],
                    },
                    () => {
                        this.getMainCategoryData()
                    }
                );
                break;
            default:
                break;
        }
        return true;
    };

    handleTableChange2 = (type, { page, sizePerPage, filters, sortField, sortOrder }) => {

        switch (type) {
            // case "pagination":
            //     this.setState({ page: page, sizePerPage: sizePerPage }, () => this.getSubCategoryData());
            //     break;

            case "filter":
                let search_val = this.state.search_val;
                let newFilter = {};
                if (Object.keys(filters).length) {
                    for (const dataField in filters) {
                        newFilter[dataField] = filters[dataField].filterVal;
                    }
                    newFilter = {
                        ...search_val,
                        ...newFilter,
                    };
                } else {
                    newFilter = {
                        title: "",
                        indicator: "",
                        definition: "",
                    };
                }
                this.setState(
                    {
                        search_val: newFilter,
                    },
                    // () => this.getSubCategoryData()
                    console.log(this.state.serach_val)
                );
                break;

            case "sort":
                this.setState(
                    {
                        defaultSorted: [
                            {
                                dataField: sortField,
                                order: sortOrder,
                            },
                        ],
                    },
                    () => {
                        this.getCategoryData()
                    }
                );
                break;
            default:
                break;
        }
        return true;
    };

    handleTableChange3 = (type, { page, sizePerPage, filters, sortField, sortOrder }) => {

        switch (type) {
            case "pagination":
                this.setState({ page: page, sizePerPage: sizePerPage }, () => {
                    this.getSubCategoryData()
                });
                break;

            case "filter":
                let search_val = this.state.search_val;
                let newFilter = {};
                if (Object.keys(filters).length) {
                    for (const dataField in filters) {
                        newFilter[dataField] = filters[dataField].filterVal;
                    }
                    newFilter = {
                        ...search_val,
                        ...newFilter,
                    };
                } else {
                    newFilter = {
                        title: "",
                        indicator: "",
                        definition: "",
                    };
                }
                this.setState(
                    {
                        search_val: newFilter,
                    },
                    // () => this.getSubCategoryData()
                    console.log(this.state.serach_val)
                );
                break;

            case "sort":
                this.setState(
                    {
                        defaultSorted: [
                            {
                                dataField: sortField,
                                order: sortOrder,
                            },
                        ],
                    },
                    () => {
                        this.getSubCategoryData()
                    }
                );
                break;
            default:
                break;
        }
        return true;
    };

    deletemainCat = (data) => {
        this.deletemaincategory()
        this.setState({ maincatrowdata: data })
    }

    deletemaincategory = () => {
        this.setState({ deletemaincategory: true })
    }

    deletemaincategoryClose = () => {
        this.setState({ deletemaincategory: false })
    }

    handleDeletemaincategory = () => {
        let path = API_Path.deleteMainCat;
        let data = {
            id: this.state.maincatrowdata.id
        };

        const deleteMainCatsAction = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        deleteMainCatsAction.then((res) => {
            if (res) {
                if (res.data.success) {
                    toastr.success(res.data.message);
                    this.deletemaincategoryClose()
                    this.getMainCategoryData()
                } else {
                    this.deletemaincategoryClose()
                    toastr.error(res.data.message);
                }
            }
        });
    }

    deleteCat = (data) => {
        this.deletecategory()
        this.setState({ catrowdata: data })
    }

    deletecategory = () => {
        this.setState({ deletecategory: true })
    }

    deletecategoryClose = () => {
        this.setState({ deletecategory: false })
    }

    handleDeletecategory = () => {
        let path = API_Path.deleteCat;
        let data = {
            id: this.state.catrowdata.id
        };

        const deleteCatAction = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        deleteCatAction.then((res) => {
            if (res) {
                if (res.data.success) {
                    toastr.success(res.data.message);
                    this.deletecategoryClose()
                    this.getCategoryData()
                } else {
                    this.deletecategoryClose()
                    toastr.error(res.data.message);
                }
            }
        });
    }

    deletesubCat = (data) => {
        this.deletesubcategory()
        this.setState({ subcatrowdata: data })
    }

    deletesubcategory = () => {
        this.setState({ deletesubcategory: true })
    }

    deletesubcategoryClose = () => {
        this.setState({ deletesubcategory: false })
    }

    handleDeletesubcategory = () => {
        let obj = {}
        let path = API_Path.deleteSubCat;
        this.state.newSubCatData &&
            this.state.newSubCatData.map((item) => {
                obj.new_main_category_id = item.main_category
                obj.new_category_id = item.category
                obj.new_sub_category_id = item.id
            })
        let data = {
            reassign: this.state.reAssignNewCat,
            id: this.state.subcatrowdata.id,
            new_main_category_id: obj.new_main_category_id,
            new_category_id: obj.new_category_id,
            new_sub_category_id: obj.new_sub_category_id
        };

        const deleteSubCatsAction = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        deleteSubCatsAction.then((res) => {
            if (res) {
                if (res.data.success) {
                    toastr.success(res.data.message);
                    this.getSubCategoryData()
                    this.deletesubcategoryClose()
                } else {
                    this.deletesubcategoryClose()
                    this.getSubCategoryData()
                    toastr.error(res.data.message);
                }
            }
        });
    }

    handleNewcatChange = (e) => {
        let filter = this.state.subCat_orderData.filter((item, i) => item.id === parseInt(e.target.value))
        this.setState({ newSubCatData: filter })
    }

    handleChangeReassigncat = (e) => {
        this.setState({ reAssignNewCat: e.target.checked })
    }

    handleFeatured = (e) => {
        this.setState({ featured: e.target.checked })
    }

    render() {
        let Language =
            this.context.language === "english"
                ? TableFieldEnglish
                : TableFieldArabic;
        let buttonLanguage =
            this.context.language === "english" ? buttonEnglish : buttonArabic;
        let categoryLanguage =
            this.context.language === "english" ? categoryEnglish : categoryArabic;

        const mainCatColumns = [
            // {
            //     dataField: "id",
            //     text: "id",
            //     hidden: true,
            // },
            {
                dataField: "thumbnail",
                text: categoryLanguage.image,
                sort: true,
                hidden: false,
                formatter: (cell, row, rowIndex) => {
                    return (
                        <React.Fragment>
                            <img src={row.thumbnail} width="100px" height="100px" />
                        </React.Fragment>
                    );
                },

            },
            {
                dataField: this.context.language === "english" ? "english" : "arabic",
                text: categoryLanguage.name,
                sort: true,
                hidden: false,

            },
            {
                dataField: this.context.language === "english" ? "slug_english" : "slug_arabic",
                text: categoryLanguage.slug,
                sort: true,
                hidden: false,

            },
            // {
            //     dataField: "status",
            //     text: "Status",
            //     sort: true,
            //     hidden: false,
            //     formatter: (cell, row, rowIndex) => {
            //         return (
            //             <label className="switch ms-2">
            //                 <input
            //                     type="checkbox"
            //                     defaultChecked={row.status == 0 ? false : true}
            //                     onChange={(e) => this.handleMainCatStatusChange(e, row.id)}
            //                 />
            //                 <div className="slider round"></div>
            //             </label>
            //         );
            //     },

            // },
            {
                dataField: "id",
                text: categoryLanguage.action,
                hidden: false,
                csvExport: false,
                headerClasses: "text-center",
                classes: "text-center",
                formatter: (cell, row, rowIndex) => {
                    return (
                        <React.Fragment>
                            {/* <button
                                title='Edit'
                                onClick={() => {
                                    this.mainCatEdit(row.id)
                                }}
                                className="btn"
                            >
                                <svg
                                    width={19}
                                    height={18}
                                    viewBox="0 0 19 19"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                >
                                    <path
                                        d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
                                        fill="#2D2D3B"
                                    />
                                </svg>
                            </button> */}
                            <Dropdown className="cust-drop">
                                <Dropdown.Toggle className="bg-transparent " id="dropdown-basic" align="end">
                                    <svg xmlns="http://www.w3.org/2000/svg" width={16} height={16} fill="currentColor" className="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                        <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                    </svg>
                                </Dropdown.Toggle>
                                <Dropdown.Menu>
                                    <Dropdown.Item title='Edit' onClick={() => { this.mainCatEdit(row.id) }}>
                                        <svg width={19} height={18} viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg" >
                                            <path
                                                d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
                                                fill="#2D2D3B"
                                            />
                                        </svg>
                                        <span>{categoryLanguage.edit}</span>
                                    </Dropdown.Item>
                                    <Dropdown.Item>
                                        <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} fill="currentColor" className="bi bi-arrows-move" viewBox="0 0 16 16">
                                            <path fillRule="evenodd" d="M7.646.146a.5.5 0 0 1 .708 0l2 2a.5.5 0 0 1-.708.708L8.5 1.707V5.5a.5.5 0 0 1-1 0V1.707L6.354 2.854a.5.5 0 1 1-.708-.708l2-2zM8 10a.5.5 0 0 1 .5.5v3.793l1.146-1.147a.5.5 0 0 1 .708.708l-2 2a.5.5 0 0 1-.708 0l-2-2a.5.5 0 0 1 .708-.708L7.5 14.293V10.5A.5.5 0 0 1 8 10zM.146 8.354a.5.5 0 0 1 0-.708l2-2a.5.5 0 1 1 .708.708L1.707 7.5H5.5a.5.5 0 0 1 0 1H1.707l1.147 1.146a.5.5 0 0 1-.708.708l-2-2zM10 8a.5.5 0 0 1 .5-.5h3.793l-1.147-1.146a.5.5 0 0 1 .708-.708l2 2a.5.5 0 0 1 0 .708l-2 2a.5.5 0 0 1-.708-.708L14.293 8.5H10.5A.5.5 0 0 1 10 8z" />
                                        </svg>
                                        <span>{categoryLanguage.move}</span>
                                    </Dropdown.Item>
                                    <Dropdown.Item onClick={() => this.deletemainCat(row)}>
                                        <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} fill="currentColor" className="bi bi-trash" viewBox="0 0 16 16">
                                            <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
                                            <path fillRule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" />
                                        </svg>
                                        <span>{categoryLanguage.delete}</span>
                                    </Dropdown.Item>
                                </Dropdown.Menu>
                            </Dropdown>
                        </React.Fragment>
                    );
                },
            },
        ]

        const catColumns = [
            // {
            //     dataField: "id",
            //     text: "id",
            //     hidden: true,
            // },
            {
                dataField: "thumbnail",
                text: categoryLanguage.image,
                sort: true,
                hidden: false,
                formatter: (cell, row, rowIndex) => {
                    return (
                        <React.Fragment>
                            <img src={row.thumbnail} width="100px" height="100px" />
                        </React.Fragment>
                    );
                },

            },
            {
                dataField: this.context.language === "english" ? "english" : "arabic",
                text: categoryLanguage.name,
                sort: true,
                hidden: false,

            },
            {
                dataField: this.context.language === "english" ? "slug_english" : "slug_arabic",
                text: categoryLanguage.slug,
                sort: true,
                hidden: false,

            },
            // {
            //     dataField: "status",
            //     text: "Status",
            //     sort: true,
            //     hidden: false,
            //     formatter: (cell, row, rowIndex) => {
            //         return (
            //             <label className="switch ms-2">
            //                 <input
            //                     type="checkbox"
            //                     defaultChecked={row.status == 0 ? false : true}
            //                     onChange={(e) => this.handleCatStatusChange(e, row.id)}
            //                 />
            //                 <div className="slider round"></div>
            //             </label>
            //         );
            //     },

            // },
            {
                dataField: "id",
                text: categoryLanguage.action,
                hidden: false,
                csvExport: false,
                headerClasses: "text-center",
                classes: "text-center",
                formatter: (cell, row, rowIndex) => {
                    return (
                        <React.Fragment>
                            {/* <button
                                title='Edit'
                                onClick={() => {
                                    this.mainCatEdit(row.id)
                                }}
                                className="btn"
                            >
                                <svg
                                    width={19}
                                    height={18}
                                    viewBox="0 0 19 19"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                >
                                    <path
                                        d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
                                        fill="#2D2D3B"
                                    />
                                </svg>
                            </button> */}
                            <Dropdown className="cust-drop">
                                <Dropdown.Toggle className="bg-transparent " id="dropdown-basic" align="end">
                                    <svg xmlns="http://www.w3.org/2000/svg" width={16} height={16} fill="currentColor" className="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                        <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                    </svg>
                                </Dropdown.Toggle>
                                <Dropdown.Menu>
                                    <Dropdown.Item title='Edit' onClick={() => { this.catEdit(row.id) }}>
                                        <svg width={19} height={18} viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg" >
                                            <path
                                                d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
                                                fill="#2D2D3B"
                                            />
                                        </svg>
                                        <span>{categoryLanguage.edit}</span>
                                    </Dropdown.Item>
                                    <Dropdown.Item>
                                        <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} fill="currentColor" className="bi bi-arrows-move" viewBox="0 0 16 16">
                                            <path fillRule="evenodd" d="M7.646.146a.5.5 0 0 1 .708 0l2 2a.5.5 0 0 1-.708.708L8.5 1.707V5.5a.5.5 0 0 1-1 0V1.707L6.354 2.854a.5.5 0 1 1-.708-.708l2-2zM8 10a.5.5 0 0 1 .5.5v3.793l1.146-1.147a.5.5 0 0 1 .708.708l-2 2a.5.5 0 0 1-.708 0l-2-2a.5.5 0 0 1 .708-.708L7.5 14.293V10.5A.5.5 0 0 1 8 10zM.146 8.354a.5.5 0 0 1 0-.708l2-2a.5.5 0 1 1 .708.708L1.707 7.5H5.5a.5.5 0 0 1 0 1H1.707l1.147 1.146a.5.5 0 0 1-.708.708l-2-2zM10 8a.5.5 0 0 1 .5-.5h3.793l-1.147-1.146a.5.5 0 0 1 .708-.708l2 2a.5.5 0 0 1 0 .708l-2 2a.5.5 0 0 1-.708-.708L14.293 8.5H10.5A.5.5 0 0 1 10 8z" />
                                        </svg>
                                        <span>{categoryLanguage.move}</span>
                                    </Dropdown.Item>
                                    <Dropdown.Item onClick={() => this.deleteCat(row)}>
                                        <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} fill="currentColor" className="bi bi-trash" viewBox="0 0 16 16">
                                            <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
                                            <path fillRule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" />
                                        </svg>
                                        <span>{categoryLanguage.delete}</span>
                                    </Dropdown.Item>
                                </Dropdown.Menu>
                            </Dropdown>
                        </React.Fragment>
                    );
                },
            },
        ]

        const subCatColumns = [
            // {
            //     dataField: "id",
            //     text: "id",
            //     hidden: true,
            // },
            {
                dataField: "thumbnail",
                text: categoryLanguage.image,
                sort: true,
                hidden: false,
                formatter: (cell, row, rowIndex) => {
                    return (
                        <React.Fragment>
                            <img src={row.thumbnail} width="100px" height="100px" />
                        </React.Fragment>
                    );
                },

            },
            {
                dataField: this.context.language === "english" ? "english" : "arabic",
                text: categoryLanguage.name,
                sort: true,
                hidden: false,

            },
            {
                dataField: this.context.language === "english" ? "slug_english" : "slug_arabic",
                text: categoryLanguage.slug,
                sort: true,
                hidden: false,

            },
            {
                dataField: "products",
                text: categoryLanguage.products,
                sort: true,
                hidden: false,

            },
            {
                dataField: "id",
                text: "Featured",
                sort: false,
                formatter: (cell, row, rowIndex) => {
                    return (
                        <React.Fragment>
                            <div className="cust-star-table-rating">
                                {/* <input type="checkbox" checked={value == 0 ? false : true} className="btn-check" id={"btncheck1_" + tableMeta.rowData[0]} autoComplete="off" onChange={(e) => this.featured(e, tableMeta.rowData[0])} /> */}
                                {/* {value == 1 ? <label className="bi bi-star-fill" htmlFor={"btncheck1_" + tableMeta.rowData[0]} /> : <label className="bi bi-star" htmlFor={"btncheck1_" + tableMeta.rowData[0]} />} */}
                                <input
                                    type="checkbox"
                                    checked={this.state.featured}
                                    className="btn-check"
                                    autoComplete="off"
                                    id={`btncheck1_${rowIndex}`}
                                    onChange={this.handleFeatured}
                                />
                                {
                                    this.state.featured ?
                                        <label className="bi bi-star-fill" htmlFor={`btncheck1_${rowIndex}`} /> :
                                        <label className="bi bi-star" htmlFor={`btncheck1_${rowIndex}`} />
                                }
                            </div>
                        </React.Fragment>
                    );
                },
            },
            // {
            //     dataField: "status",
            //     text: "Status",
            //     sort: true,
            //     hidden: false,
            //     formatter: (cell, row, rowIndex) => {
            //         return (
            //             <label className="switch ms-2">
            //                 <input
            //                     type="checkbox"
            //                     defaultChecked={row.status == 0 ? false : true}
            //                     onChange={(e) => this.handleSubCatStatusChange(e, row.id)}
            //                 />
            //                 <div className="slider round"></div>
            //             </label>
            //         );
            //     },

            // },
            {
                dataField: "id",
                text: categoryLanguage.action,
                hidden: false,
                csvExport: false,
                headerClasses: "text-center",
                classes: "text-center",
                formatter: (cell, row, rowIndex) => {
                    return (
                        <React.Fragment>
                            {/* <button
                                title='Edit'
                                onClick={() => {
                                    this.mainCatEdit(row.id)
                                }}
                                className="btn"
                            >
                                <svg
                                    width={19}
                                    height={18}
                                    viewBox="0 0 19 19"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                >
                                    <path
                                        d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
                                        fill="#2D2D3B"
                                    />
                                </svg>
                            </button> */}
                            <Dropdown className="cust-drop">
                                <Dropdown.Toggle className="bg-transparent " id="dropdown-basic" align="end">
                                    <svg xmlns="http://www.w3.org/2000/svg" width={16} height={16} fill="currentColor" className="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                        <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                    </svg>
                                </Dropdown.Toggle>
                                <Dropdown.Menu>
                                    <Dropdown.Item title='Edit' onClick={() => { this.subCatEdit(row.id) }}>
                                        <svg width={19} height={18} viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg" >
                                            <path
                                                d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
                                                fill="#2D2D3B"
                                            />
                                        </svg>
                                        <span>{categoryLanguage.edit}</span>
                                    </Dropdown.Item>
                                    <Dropdown.Item>
                                        <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} fill="currentColor" className="bi bi-arrows-move" viewBox="0 0 16 16">
                                            <path fillRule="evenodd" d="M7.646.146a.5.5 0 0 1 .708 0l2 2a.5.5 0 0 1-.708.708L8.5 1.707V5.5a.5.5 0 0 1-1 0V1.707L6.354 2.854a.5.5 0 1 1-.708-.708l2-2zM8 10a.5.5 0 0 1 .5.5v3.793l1.146-1.147a.5.5 0 0 1 .708.708l-2 2a.5.5 0 0 1-.708 0l-2-2a.5.5 0 0 1 .708-.708L7.5 14.293V10.5A.5.5 0 0 1 8 10zM.146 8.354a.5.5 0 0 1 0-.708l2-2a.5.5 0 1 1 .708.708L1.707 7.5H5.5a.5.5 0 0 1 0 1H1.707l1.147 1.146a.5.5 0 0 1-.708.708l-2-2zM10 8a.5.5 0 0 1 .5-.5h3.793l-1.147-1.146a.5.5 0 0 1 .708-.708l2 2a.5.5 0 0 1 0 .708l-2 2a.5.5 0 0 1-.708-.708L14.293 8.5H10.5A.5.5 0 0 1 10 8z" />
                                        </svg>
                                        <span>{categoryLanguage.move}</span>
                                    </Dropdown.Item>
                                    <Dropdown.Item onClick={() => this.deletesubCat(row)}>
                                        <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} fill="currentColor" className="bi bi-trash" viewBox="0 0 16 16">
                                            <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
                                            <path fillRule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" />
                                        </svg>
                                        <span>{categoryLanguage.delete}</span>
                                    </Dropdown.Item>
                                </Dropdown.Menu>
                            </Dropdown>
                        </React.Fragment>
                    );
                },
            },
        ]

        return (
            <Adminlayout>
                <div className='container-fluid'>
                    <div className='row common-space'>
                        <div className='col-md-12'>

                            <div className='row'>
                                <div className='col-md-6'>
                                    <div className='white-box'>
                                        <div className='common-header-txt d-flex align-items-center'>
                                            <h5>{categoryLanguage.MainCategories}</h5>
                                            <button className='ms-auto red-border-btn' onClick={this.addmaincat}>{categoryLanguage.AddMainCategory}</button>
                                        </div>
                                        <div className='main-cat-table my-3'>
                                            <div className="custom-table">
                                                <div className="table-responsive dataTables_wrapper no-footer">
                                                    {this.state.mainCat_orderData && (
                                                        <DataTable
                                                            keyField="id"
                                                            loading={this.state.loading}
                                                            columns={mainCatColumns}
                                                            data={this.state.mainCat_orderData}
                                                            page={this.state.page}
                                                            sizePerPage={this.state.sizePerPage}
                                                            totalSize={this.state.totalSize}
                                                            defaultSorted={this.state.defaultSorted}
                                                            onTableChange={this.handleTableChange1}
                                                            language={this.context.language}
                                                            selectableRows
                                                        />
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className='col-md-6'>
                                    <div className='white-box'>
                                        <div className='common-header-txt d-flex align-items-center'>
                                            <h5>{categoryLanguage.Categories}</h5>
                                            <button className='ms-auto red-border-btn' onClick={this.addcat}>{categoryLanguage.AddCategory}</button>
                                        </div>
                                        <div className='main-cat-table my-3'>
                                            <div className="custom-table">
                                                <div className="table-responsive dataTables_wrapper no-footer">
                                                    {this.state.Cat_orderData && (
                                                        <DataTable
                                                            keyField="id"
                                                            loading={this.state.loading}
                                                            columns={catColumns}
                                                            data={this.state.Cat_orderData}
                                                            page={this.state.page}
                                                            sizePerPage={this.state.sizePerPage}
                                                            totalSize={this.state.totalSize}
                                                            defaultSorted={this.state.defaultSorted}
                                                            language={this.context.language}
                                                            onTableChange={this.handleTableChange2}
                                                            selectableRows
                                                        />
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className='col-md-12 mt-3'>
                                    <div className='white-box'>
                                        <div className='common-header-txt d-flex align-items-center'>
                                            <h5>{categoryLanguage.SubCategories}</h5>
                                            <button className='ms-auto red-border-btn' onClick={this.addsubcat}>{categoryLanguage.AddSubCategory}</button>
                                        </div>
                                        <div className=' my-3'>
                                            <div className="custom-table">
                                                <div className="table-responsive dataTables_wrapper no-footer">
                                                    {this.state.subCat_orderData && (
                                                        <DataTable
                                                            keyField="id"
                                                            loading={this.state.loading}
                                                            columns={subCatColumns}
                                                            data={this.state.subCat_orderData}
                                                            page={this.state.page}
                                                            sizePerPage={this.state.sizePerPage}
                                                            totalSize={this.state.totalCount}
                                                            defaultSorted={this.state.defaultSorted}
                                                            language={this.context.language}
                                                            onTableChange={this.handleTableChange3}
                                                            selectableRows
                                                        />
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <Modal show={this.state.addmaincat} className="cust-modal" onHide={this.maincathandleClose} size="lg" centered>
                    <Modal.Header closeButton>
                        <Modal.Title>
                            <h1>{this.state.isMainCategoryEdit ? categoryLanguage.Editmaincategory : categoryLanguage.AddMainCategory}</h1>
                        </Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <form className='row'>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.MainCategoryNameinEnglish}</label>
                                <input type="text" value={this.state.mainCategoryEnglish} onChange={this.handleMainCatChange} name='mainCategoryEnglish' className='form-control input-custom-class' placeholder='Enter Main Category Name in English ' />
                                <span id="mainCategoryEnglishErr" style={{ display: "none" }} className="input-feedback text-danger">
                                    Required
                                </span>
                            </div>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.MainCategoryNameinArabic}</label>
                                <input value={this.state.mainCategoryArabic} onChange={this.handleMainCatChange} name='mainCategoryArabic' type="text" className='form-control input-custom-class ' placeholder='Enter Main Category Name in Arabic ' />
                                <span id="mainCategoryArabicErr" style={{ display: "none" }} className="input-feedback text-danger">
                                    Required
                                </span>
                            </div>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.MainCategoryDescriptioninEnglish}</label>
                                <textarea value={this.state.mainCategoryDescEnglish} onChange={this.handleMainCatChange} name='mainCategoryDescEnglish' className='form-control input-custom-class h-auto' rows={5} placeholder="Enter Main Category Description in English"></textarea>
                                {/* <span id="mainCategoryDescEnglishErr" style={{ display: "none" }} className="input-feedback text-danger">
                                    Required
                                </span> */}
                            </div>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.MainCategoryDescriptioninArabic}</label>
                                <textarea value={this.state.mainCategoryDescArabic} onChange={this.handleMainCatChange} name='mainCategoryDescArabic' className='form-control input-custom-class h-auto' rows={5} placeholder="Enter Main Category Description in Arabic"></textarea>
                                {/* <span id="mainCategoryDescArabicErr" style={{ display: "none" }} className="input-feedback text-danger">
                                    Required
                                </span> */}
                            </div>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.SlugEnglish}</label>
                                <input name='mainCatSlugEnglish' value={this.state.mainCategoryEnglish.length > 0 ? '/' + this.state.mainCategoryEnglish : ''} type="text" className='form-control input-custom-class' readOnly disabled />
                            </div>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.SlugArabic}</label>
                                <input name='mainCatSlugArabic' value={this.state.mainCategoryArabic.length ? '/' + this.state.mainCategoryArabic : ''} type="text" className='form-control input-custom-class' readOnly disabled />
                            </div>
                            <div className='col-md-6 form-group d-flex'>
                                <div>
                                    <label>{categoryLanguage.Addthumbnail}</label>
                                    <div className="input-group mb-3">
                                        <input type="file" name='maincatImageSizeInput' id="maincatImageSizeInput" accept="image/*" className="form-control input-custom-class cust-line-height" onChange={(e) => this.imageUpload(e, 'main')} />
                                    </div>
                                    {
                                        this.state.isImg && (
                                            <div className="img-preview ps-3 wdth-click-main">
                                                <ul className="justify-content-center">
                                                    <div className="img-bdr-main">
                                                        <div className="img-bdr-main-inr">
                                                            <li>
                                                                <div className="img-preview-main position-relative">
                                                                    <img
                                                                        src={this.state.mainCatprofilePicture && this.state.mainCatprofilePicture}
                                                                        alt=""
                                                                    />
                                                                    <div
                                                                        onClick={this.removethumbnailImages}
                                                                        className="remove-img-btn"
                                                                    >
                                                                        <i className="bi bi-x-circle-fill"></i>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                        </div>
                                                    </div>
                                                </ul>
                                            </div>
                                        )
                                    }
                                    <span id="maincatImageSizeInputErr" style={{ display: "none" }} className="input-feedback text-danger">
                                        Required
                                    </span>
                                </div>
                            </div>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.Googleproductcategoryid}</label>
                                <input type="number" value={this.state.mainCategoryNumber} onChange={this.handleMainCatChange} name='mainCategoryNumber' className='form-control input-custom-class' placeholder={categoryLanguage.EnterNumber} />
                            </div>
                        </form>
                    </Modal.Body>
                    <ModalFooter>
                        <div className=" col-md-12 mb-3 mt-5 text-center">
                            <div className="common-red-btn">
                                <button onClick={this.state.isMainCategoryEdit ? this.handleMainCatEdit : this.handleMainCatSubmit} type="submit" className="btn red-btn me-2">{this.state.isMainCategoryEdit ? categoryLanguage.update : categoryLanguage.save}</button>
                                {/* <div onClick={this.handleReset} className="btn black-btn">CANCEL</div> */}
                            </div>
                        </div>
                    </ModalFooter>
                </Modal>

                <Modal show={this.state.addcat} className="cust-modal" onHide={this.cathandleClose} size="lg" centered>
                    <Modal.Header closeButton>
                        <Modal.Title>
                            <h1>{this.state.isCategoryEdit ? categoryLanguage.EditCategory : categoryLanguage.AddCategory}</h1>
                        </Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <form className='row'>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.CategoryNameinEnglish}</label>
                                <input id="CategoryEnglish" type="text" value={this.state.CategoryEnglish} onChange={this.handleCatChange} name='CategoryEnglish' className='form-control input-custom-class ' placeholder='Enter Category Name in English ' />
                                <span id="CategoryEnglishErr" style={{ display: "none" }} className="input-feedback text-danger">
                                    Required
                                </span>
                            </div>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.CategoryNameinArabic}</label>
                                <input id="CategoryArabic" value={this.state.CategoryArabic} onChange={this.handleCatChange} name='CategoryArabic' type="text" className='form-control input-custom-class ' placeholder='Enter Category Name in Arabic ' />
                                <span id="CategoryArabicErr" style={{ display: "none" }} className="input-feedback text-danger">
                                    Required
                                </span>
                            </div>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.CategoryDescriptioninEnglish}</label>
                                <textarea id="CategoryDescEnglish" value={this.state.CategoryDescEnglish} onChange={this.handleCatChange} name='CategoryDescEnglish' className='form-control input-custom-class h-auto' rows={5} placeholder="Enter Category Description in English"></textarea>
                                {/* <span id="CategoryDescEnglishErr" style={{ display: "none" }} className="input-feedback text-danger">
                                    Required
                                </span> */}
                            </div>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.CategoryDescriptioninArabic}</label>
                                <textarea id="CategoryDescArabic" value={this.state.CategoryDescArabic} onChange={this.handleCatChange} name='CategoryDescArabic' className='form-control input-custom-class h-auto' rows={5} placeholder="Enter Category Description in Arabic"></textarea>
                                {/* <span id="CategoryDescArabicErr" style={{ display: "none" }} className="input-feedback text-danger">
                                    Required
                                </span> */}
                            </div>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.SlugEnglish}</label>
                                <input id="CatSlugEnglish" name='CatSlugEnglish' value={(this.state.selectMainCategory && this.state.selectMainCategorySlug) + (this.state.CategoryEnglish && '/' + this.state.CategoryEnglish)} type="text" className='form-control input-custom-class' readOnly disabled />
                            </div>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.SlugArabic}</label>
                                <input id="CatSlugArabic" name='CatSlugArabic' value={(this.state.selectMainCategory && this.state.selectMainCategorySlug) + (this.state.CategoryArabic && '/' + this.state.CategoryArabic)} type="text" className='form-control input-custom-class' readOnly disabled />
                            </div>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.SelectMainCategory}</label>
                                <select className='form-select input-custom-class' value={this.state.selectMainCategory} name="selectMainCat" onChange={this.handleMainCategoryChange}>
                                    <option value="">{categoryLanguage.SelectMainCategory}</option>
                                    {
                                        this.state.mainCategorySelectBoxData &&
                                        this.state.mainCategorySelectBoxData.length > 0 &&
                                        this.state.mainCategorySelectBoxData.map((item, i) => {
                                            return (
                                                <option key={i} value={item.english + '@' + item.id}>
                                                    {item.english} | {item.arabic}
                                                </option>
                                            );
                                        })}
                                </select>
                                <span id="selectMainCategoryErr" style={{ display: "none" }} className="input-feedback text-danger">
                                    Required
                                </span>
                            </div>
                            <div className='col-md-6 form-group d-flex'>
                                <div>
                                    <label>{categoryLanguage.Addthumbnail}</label>
                                    <div className="input-group mb-3">
                                        <input type="file" id="catImageSizeInput" accept="image/*" className="form-control input-custom-class cust-line-height" onChange={(e) => this.imageUpload(e, 'category')} />
                                    </div>
                                    {
                                        this.state.isImg && (
                                            <div className="img-preview ps-3 wdth-click-main">
                                                <ul className="justify-content-center">
                                                    <div className="img-bdr-main">
                                                        <div className="img-bdr-main-inr">
                                                            <li>
                                                                <div className="img-preview-main position-relative">
                                                                    <img
                                                                        src={this.state.CatprofilePicture && this.state.CatprofilePicture}
                                                                        alt=""
                                                                    />
                                                                    <div
                                                                        onClick={this.removethumbnailImages}
                                                                        className="remove-img-btn"
                                                                    >
                                                                        <i className="bi bi-x-circle-fill"></i>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                        </div>
                                                    </div>
                                                </ul>
                                            </div>
                                        )
                                    }
                                    <span id="catImageSizeInputErr" style={{ display: "none" }} className="input-feedback text-danger">
                                        Required
                                    </span>
                                </div>
                            </div>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.Googleproductcategoryid}</label>
                                <input type="number" value={this.state.CategoryNumber} onChange={this.handleCatChange} name='CategoryNumber' className='form-control input-custom-class' placeholder={categoryLanguage.EnterNumber} />
                            </div>
                        </form>
                    </Modal.Body>
                    <ModalFooter className=' justify-content-between'>
                        <div className=" col-md-12 mb-3 mt-5 text-center">
                            <div className="common-red-btn">
                                <button onClick={this.state.isCategoryEdit ? this.handleCatEdit : this.handleCatSubmit} type="submit" className="btn red-btn me-2">{this.state.isCategoryEdit ? categoryLanguage.update : categoryLanguage.save}</button>
                                {/* <div onClick={this.handleReset} className="btn black-btn">CANCEL</div> */}
                            </div>
                        </div>
                    </ModalFooter>

                </Modal>

                <Modal show={this.state.addsubcat} className="cust-modal" onHide={this.subcathandleClose} size="lg" centered>
                    <Modal.Header closeButton>
                        <Modal.Title>
                            <h1>{this.state.isSubCategoryEdit ? categoryLanguage.Editsubcategory : categoryLanguage.AddSubCategory}</h1>
                        </Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <form className='row'>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.SubCategoryNameinEnglish}</label>
                                <input id="subCategoryEnglish" type="text" value={this.state.subCategoryEnglish} onChange={this.handleSubCatChange} name='subCategoryEnglish' className='form-control input-custom-class ' placeholder={categoryLanguage.SubCategoryNameinEnglish} />
                                <span id="subCategoryEnglishErr" style={{ display: "none" }} className="input-feedback text-danger">
                                    Required
                                </span>
                            </div>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.SubCategoryNameinArabic}</label>
                                <input id="subCategoryArabic" value={this.state.subCategoryArabic} onChange={this.handleSubCatChange} name='subCategoryArabic' type="text" className='form-control input-custom-class ' placeholder={categoryLanguage.SubCategoryNameinArabic} />
                                <span id="subCategoryArabicErr" style={{ display: "none" }} className="input-feedback text-danger">
                                    Required
                                </span>
                            </div>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.SubCategoryDescriptioninEnglish}</label>
                                <textarea id="subCategoryDescEnglish" value={this.state.subCategoryDescEnglish} onChange={this.handleSubCatChange} name='subCategoryDescEnglish' className='form-control input-custom-class h-auto' rows={5} placeholder={categoryLanguage.SubCategoryDescriptioninEnglish}></textarea>
                                {/* <span id="subCategoryDescEnglishErr" style={{ display: "none" }} className="input-feedback text-danger">
                                    Required
                                </span> */}
                            </div>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.SubCategoryDescriptioninArabic}</label>
                                <textarea id="subCategoryDescArabic" value={this.state.subCategoryDescArabic} onChange={this.handleSubCatChange} name='subCategoryDescArabic' className='form-control input-custom-class h-auto' rows={5} placeholder={categoryLanguage.SubCategoryDescriptioninArabic}></textarea>
                                {/* <span id="subCategoryDescArabicErr" style={{ display: "none" }} className="input-feedback text-danger">
                                    Required
                                </span> */}
                            </div>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.SelectMainCategory}</label>
                                <select className='form-select input-custom-class' value={this.state.selectMainCategory} name="selectMainCat" onChange={this.handleMainCategoryChange}>
                                    <option value="">{categoryLanguage.SelectMainCategory}</option>
                                    {
                                        this.state.mainCategorySelectBoxData &&
                                        this.state.mainCategorySelectBoxData.length > 0 &&
                                        this.state.mainCategorySelectBoxData.map((item, i) => {
                                            return (
                                                <option key={i} value={item.english + "@" + item.id}>
                                                    {item.english} | {item.arabic}
                                                </option>
                                            );
                                        })}
                                </select>
                                <span id="selectMainCategoryErr" style={{ display: "none" }} className="input-feedback text-danger">
                                    Required
                                </span>
                            </div>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.SelectCategory}</label>
                                <select className='form-select input-custom-class' value={this.state.selectCategory} name="selectCat" onChange={this.handleCategoryChange}>
                                    <option value="">{categoryLanguage.SelectCategory}</option>
                                    {
                                        this.state.CategorySelectBoxData &&
                                        this.state.CategorySelectBoxData.length > 0 &&
                                        this.state.CategorySelectBoxData.map((item, i) => {
                                            return (
                                                <option key={i} value={item.english + "@" + item.id}>
                                                    {item.english} | {item.arabic}
                                                </option>
                                            );
                                        })}
                                </select>
                                <span id="selectCategoryErr" style={{ display: "none" }} className="input-feedback text-danger">
                                    Required
                                </span>
                            </div>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.SlugEnglish}</label>
                                <input id="subCatSlugEnglish" name='subCatSlugEnglish' value={(this.state.selectMainCategory && this.state.selectMainCategorySlug) + (this.state.selectCategory && '/' + this.state.selectCategorySlug) + (this.state.subCategoryEnglish && '/' + this.state.subCategoryEnglish)} type="text" className='form-control input-custom-class' readOnly disabled />
                            </div>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.SlugArabic}</label>
                                <input id="subCatSlugArabic" name='subCatSlugArabic' value={(this.state.selectMainCategory && this.state.selectMainCategorySlug) + (this.state.selectCategory && '/' + this.state.selectCategorySlug) + (this.state.subCategoryArabic && '/' + this.state.subCategoryArabic)} type="text" className='form-control input-custom-class' readOnly disabled />
                            </div>
                            <div className='col-md-12 form-group d-flex'>
                                <div>
                                    <label>{categoryLanguage.Addthumbnail}</label>
                                    <div className="input-group mb-3">
                                        <input type="file" id="subCatImageSizeInput" accept="image/*" className="form-control input-custom-class cust-line-height" onChange={(e) => this.imageUpload(e, 'sub')} />
                                    </div>
                                    {
                                        this.state.isImg && (
                                            <div className="img-preview ps-3 wdth-click-main">
                                                <ul className="justify-content-center">
                                                    <div className="img-bdr-main">
                                                        <div className="img-bdr-main-inr">
                                                            <li>
                                                                <div className="img-preview-main position-relative">
                                                                    <img
                                                                        src={this.state.subCatprofilePicture && this.state.subCatprofilePicture}
                                                                        alt=""
                                                                    />
                                                                    <div
                                                                        onClick={this.removethumbnailImages}
                                                                        className="remove-img-btn"
                                                                    >
                                                                        <i className="bi bi-x-circle-fill"></i>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                        </div>
                                                    </div>
                                                </ul>
                                            </div>
                                        )
                                    }
                                    <span id="subCatImageSizeInputErr" style={{ display: "none" }} className="input-feedback text-danger">
                                        Required
                                    </span>
                                </div>
                            </div>
                            <div className='col-md-6 form-group'>
                                <label>{categoryLanguage.Googleproductcategoryid}</label>
                                <input type="number" value={this.state.subCategoryNumber} onChange={this.handleSubCatChange} name='subCategoryNumber' className='form-control input-custom-class' placeholder={categoryLanguage.EnterNumber} />
                            </div>
                        </form>
                    </Modal.Body>
                    <ModalFooter className='justify-content-center'>
                        {/* <button className='btn dark-red-txt  p-0'>Delete</button> */}
                        <button onClick={this.state.isSubCategoryEdit ? this.handleSubCatEdit : this.handleSubCatSubmit} type="submit" className="btn red-btn me-2">{this.state.isSubCategoryEdit ? categoryLanguage.update : categoryLanguage.save}</button>
                    </ModalFooter>

                </Modal>

                <Modal show={this.state.deletemaincategory} className="cust-modal" onHide={this.deletemaincategoryClose} size="md" centered>
                    <Modal.Header closeButton>
                        <Modal.Title>
                            <h1>Delete Main Category</h1>
                        </Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <div className='row'>
                            <div className='col-md-12'>
                                <p>NB: Are you sure want to delete {this.state.maincatrowdata !== undefined ? this.state.maincatrowdata.english : ""} category? You cannot revert back it.</p>
                            </div>
                            <div className='col-md-12 text-center'>
                                <button className='red-btn' onClick={this.handleDeletemaincategory}>{categoryLanguage.delete}</button>
                            </div>
                        </div>
                    </Modal.Body>
                </Modal>

                <Modal show={this.state.deletecategory} className="cust-modal" onHide={this.deletecategoryClose} size="md" centered>
                    <Modal.Header closeButton>
                        <Modal.Title>
                            <h1>Delete Category</h1>
                        </Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <div className='row'>
                            <div className='col-md-12'>
                                <p>NB: Are you sure want to delete {this.state.catrowdata !== undefined ? this.state.catrowdata.english : ""} category? You cannot revert back it.</p>
                            </div>
                            <div className='col-md-12 text-center'>
                                <button className='red-btn' onClick={this.handleDeletecategory}>{categoryLanguage.delete}</button>
                            </div>
                        </div>
                    </Modal.Body>
                </Modal>

                <Modal show={this.state.deletesubcategory} className="cust-modal" onHide={this.deletesubcategoryClose} size="md" centered>
                    <Modal.Header closeButton>
                        <Modal.Title>
                            <h1>{categoryLanguage.DeleteSubCategory}</h1>
                        </Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <div className='row'>
                            <div className='col-md-12'>
                                <p>NB: Are you sure want to delete {this.state.subcatrowdata !== undefined ? this.state.subcatrowdata.english : ""} category? You cannot revert back it.</p>
                                <div class="cust-checkbox-new">
                                    <label class="cust-chk-bx">
                                        <input name="reassign" id="reassign" type="checkbox" onChange={this.handleChangeReassigncat} />
                                        <span class="cust-chkmark" >
                                        </span>
                                        <b>
                                            <bdi>Reassign Category</bdi>
                                        </b>
                                    </label>
                                </div>
                                <div className='form-group mt-3'>
                                    {
                                        this.state.reAssignNewCat ? (
                                            <label>{categoryLanguage.SelectCategory}</label>
                                        ) : ""
                                    }
                                    {
                                        this.state.reAssignNewCat ? (
                                            <select className='form-select input-custom-class' onChange={this.handleNewcatChange}>
                                                <option value="">{categoryLanguage.SelectCategory}</option>
                                                {this.state.subCat_orderData &&
                                                    this.state.subCat_orderData.map((item) => {
                                                        return (
                                                            <option key={item.id} value={item.id}>
                                                                {item.main_english + " > " + item.category_english + " > " + item.english}
                                                            </option>
                                                        );
                                                    })}
                                            </select>
                                        ) : ""
                                    }
                                </div>
                            </div>
                            <div className='col-md-12 text-center'>
                                <button className='red-btn' onClick={this.handleDeletesubcategory}>{categoryLanguage.delete}</button>
                            </div>
                        </div>
                    </Modal.Body>
                </Modal>

            </Adminlayout>
        );
    }
}

export default Categories;