import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import { Breadcrumb } from "react-bootstrap";

import { API_Path, APIBaseUrl, buttonArabic, buttonEnglish, TableFieldArabic, TableFieldEnglish, titleArabic, titleEnglish, productArabic, productEnglish, LIVE_FILE_URL } from "../../const";

import { PostApi } from "../../helper/APIService";
import toastr from "toastr";
import "toastr/build/toastr.min.css";
import LanguageContext from "../../contexts/languageContext";
import "slick-carousel/slick/slick-theme.css";

import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
// import "~slick-carousel/slick/slick-theme.css";
import Image from "../../images/slide-img-p-1.png";
import Image2 from "../../images/slide-img-p-2.png";
import Image3 from "../../images/slide-img-p-3.png";
import Image4 from "../../images/slide-img-p-1.png";
import Image5 from "../../images/img-slide-5.png";
import { Tabs, Tab } from "react-bootstrap";
import cart from "../../images/cart-icn.svg";

class Productdetails extends Component {
  static contextType = LanguageContext;
  constructor(props) {
    super(props);
    this.myRef = React.createRef();

    this.state = {
      language: "",
      product_id: "",
      product_details: [],
      product_variation: [],
      product_variant: [],
      nav1: null,
      nav2: null,
      slides: [Image, Image2, Image3, Image4, Image5],
      images: [],
      cid: "",
      cvid: "",
      currentVariation: "",
      currentVariant: "",
      selected: false,
    };
  }

  componentDidMount() {
    this.setState(
      {
        product_id: window.location.href.split("/").pop(),
        nav1: this.slider1,
        nav2: this.slider2,
        language: localStorage.getItem("currentLanguage"),
        // slides: this.props.slides
      },
      () => {
        this.get_product_details(this.state.product_id);
        this.get_product_variation(this.state.product_id);
        this.get_product_variant(this.state.product_id);
      }
    );
  }
  componentDidUpdate(prevProps) {
    if (this.props !== prevProps) {
      this.setState({ language: localStorage.getItem("currentLanguage") });
    }
  }

  handleChange = (e) => {
    console.log("e :: ", e.target.value);
  };

  get_product_details = (id) => {
    const formData = { product_id: id };
    const getProductDetailDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(API_Path.getProductDetailById, formData));
    });
    getProductDetailDataPromise.then((response) => {
      if (response.status === 200) {
        this.setState({ product_details: response.data.data[0] }, () => {
          // console.log('size :: ', response.data.data[0].size_guide);
        });
      } else {
        toastr.error(response.message);
      }
    });
  };

  //     var elements = document.querySelectorAll('.tab');
  // for (var i = 0; i < elements.length; i++) {
  //     elements[i].classList.remove('active');
  //     elements[i].onclick = function (event) {
  //         console.log("ONCLICK");
  //         //remove all active class
  //         removeClass();
  //         if (event.target.innerHTML === this.innerHTML) {
  //             this.classList.add("active");
  //         }
  //     }
  // }

  // function removeClass(){
  //   for (var i = 0; i < elements.length; i++) {
  //     elements[i].classList.remove('active');
  //   }
  // }

  get_product_variation = (id) => {
    const narr = [];
    const formData = { product_id: id };

    const getProductVariationDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(API_Path.getProductVariationById, formData));
    });
    getProductVariationDataPromise.then((response) => {
      if (response.status === 200) {
        this.setState(
          {
            product_variation: response.data.data,
            currentVariation: response.data.data[0],
          },
          () => {
            console.log("variation data", this.state.currentVariation.variant);
          }
          // () => {
          //   // console.log(this.state.currentVariation, "??????");
          //   document.getElementById("color-0").setAttribute("checked", true);
          //   // }
          // }
        );
      } else {
        toastr.error(response.message);
      }
    });
  };

  get_product_variant = (id) => {
    const formData = { product_id: id };
    const getProductVariantDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(API_Path.getProductVariantById, formData));
    });
    getProductVariantDataPromise.then((response) => {
      console.log(response);
      if (response.status === 200) {
        this.setState({ product_variant: response.data.data });
      } else {
        toastr.error(response.message);
      }
    });
  };

  setColor = (item, id) => {
    console.log("item", item);
    console.log("id", id);

    this.setState({
      cid: item.id,
      currentVariation: item,
      currentVariant: item,
    });

    console.log("element", document.getElementById("color_parant"));
    // document.getElementById("color_parant").classList.remove("active");
    // document.getElementById(id).classList.add("active");
  };

  render() {
    let Language = this.context.language === "english" ? TableFieldEnglish : TableFieldArabic;
    let ButtonLanguage = this.context.language === "english" ? buttonEnglish : buttonArabic;
    let titleLanguage = this.context.language === "english" ? titleEnglish : titleArabic;
    let productLanguage = this.context.language === "english" ? productEnglish : productArabic;
    // console.log(Language, 'Language');
    const { slides } = this.state;
    let variant = "";
    const slickSettingsVerticalNav = {
      arrows: false,
      vertical: true,
      slidesToShow: 3,
      swipeToSlide: true,
      focusOnSelect: true,
      verticalSwiping: true,
      asNavFor: this.state.nav2,
      ref: (slider) => (this.slider1 = slider),
    };

    const slickSettingsVerticalMain = {
      arrows: false,
      slidesToShow: 1,
      asNavFor: this.state.nav1,
      focusOnSelect: true,
      adaptiveHeight: true,
      ref: (slider) => (this.slider2 = slider),
    };
    console.log(this.state.currentVariation);
    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space">
            <div className="col-sm-6 text-sm-start text-center">
              <div className="common-header-txt">
                <h3>{productLanguage.ProductsPreview}</h3>
              </div>
            </div>
          </div>
          <div className="row common-space">
            <div className="col-md-12">
              <div className="white-box">
                <div className="row">
                  <div className="col-lg-6">
                    <div className="row align-items-center">
                      <div className="col-sm-3 d-sm-block d-none  product-details-slider">
                        <Slider {...slickSettingsVerticalNav}>
                          {this.state.currentVariation &&
                            this.state.currentVariation.images.split(",").map((item, i) => {
                              return (
                                <div key={i}>
                                  <img src={item} className="slide-nav" alt="" />
                                </div>
                              );
                            })}
                        </Slider>
                      </div>
                      <div className="col-sm-6">
                        <Slider {...slickSettingsVerticalMain}>
                          {this.state.currentVariation &&
                            this.state.currentVariation.images.split(",").map((item, i) => {
                              return (
                                <div key={i}>
                                  <img src={item} className="slide-main" alt="" />
                                </div>
                              );
                            })}
                        </Slider>
                      </div>
                    </div>
                  </div>

                  {Language == "english" ? (
                    <div className="col-lg-6 ps-lg-5">
                      <div className="pro-slider-head custom-border-title">
                        <div>
                          <h1>{this.state.product_details["title_en"]}</h1>
                          {/* <p>{this.state.product_details['description_en']}</p> */}
                          <div className="mt-3 mb-3">
                            <ul className="rating-slide">
                              <li>
                                <i className="bi bi-star-fill" />
                              </li>
                              <li>
                                <i className="bi bi-star-fill" />
                              </li>
                              <li>
                                <i className="bi bi-star-fill" />
                              </li>
                              <li>
                                <i className="bi bi-star-fill" />
                              </li>
                              <li>
                                <i className="bi bi-star" />
                              </li>
                              <li>
                                <span>(16)</span>
                              </li>
                            </ul>
                          </div>
                        </div>
                        <div className="ms-auto slider-right-sec margin-right-auto">
                          <svg xmlns="http://www.w3.org/2000/svg" width={20} height={20} fill="currentColor" className="bi bi-heart-fill" viewBox="0 0 16 16">
                            <path fillRule="evenodd" d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314z" fill="#A81A1C" />
                          </svg>
                          <span className="ms-2">10</span>
                        </div>
                      </div>
                      <div ref={this.myRef} id="color_parant" className="">
                        {this.state.product_variation.length > 0
                          ? this.state.product_variation.map((item, i) => {
                            return (
                              <button key={i} type="button" className="btn mt-1" onClick={() => this.setColor(item, "color-" + i)}>
                                {item.color_en}
                              </button>
                            );
                          })
                          : ""}
                        <div>
                          <ul className="size-btn color-btn-ad">
                            {this.state.product_variation.length > 0
                              ? this.state.product_variation.map((item, i) => {
                                return (
                                  <li key={i}>
                                    <input type="radio" className="btn-check" value={item.color_en} name="btnradio" id="btnradio3" onChange={this.handleChange} checked={this.state.selected === item.color_en} autoComplete="off" />
                                    <button className="btn" htmlFor="btnradio3" key={i}>
                                      {item.color_en}
                                    </button>
                                  </li>
                                );
                              })
                              : ""}
                          </ul>
                        </div>
                      </div>
                      <div className="price-div-pro-s my-3">
                        {this.state.currentVariation ? (
                          <ul>
                            <li>
                              <span>{this.state.currentVariation.discount_price.toFixed(2)}</span>
                            </li>
                            <li>
                              <bdi>{this.state.currentVariation.price.toFixed(2)}</bdi>
                            </li>
                            {this.state.currentVariation.discount !== 0 && (
                              <li>
                                <dl>{this.state.currentVariation.discount.toFixed(2)}%</dl>
                              </li>
                            )}
                          </ul>
                        ) : (
                          ""
                        )}

                        <span className="dark-red-txt">Inclusive of all taxes</span>
                      </div>
                      <div className="mt-3">
                        <div className="iner-pro-title">
                          <h3>Select Size</h3>
                        </div>

                        <div className="btn-group mt-3" role="group" aria-label="Basic radio toggle button group">
                          <ul className="size-btn">
                            {this.state.currentVariation
                              ? this.state.product_variant?.map((item, i) => {
                                if (this.state.currentVariation.id == item.variation_id) {
                                  return (
                                    // <input type="radio" disabled className="btn-check" />
                                    <li key={i}>
                                      <label className="btn" key={i}>
                                        {item.size}
                                      </label>
                                    </li>
                                  );
                                }
                              })
                              : ""}
                          </ul>
                        </div>
                      </div>
                      <div className="mt-4 mb-4">
                        <button disabled className="red-btn d-flex">
                          <img className="me-2" src={cart} alt="" />
                          ADD TO Cart
                        </button>
                      </div>
                      {/* <div className="product-dtl">
                                                    <span>
                                                        {this.state.product_details['description_en']}
                                                    </span>
                                                </div> */}
                    </div>
                  ) : (
                    <div className="col-lg-6 ps-lg-5">
                      <div className="pro-slider-head custom-border-title">
                        <div>
                          <h1>{this.state.product_details["title_ar"]}</h1>
                          {/* <p>{this.state.product_details['description_en']}</p> */}
                          <div className="mt-3 mb-3">
                            <ul className="rating-slide">
                              <li>
                                <i className="bi bi-star-fill" />
                              </li>
                              <li>
                                <i className="bi bi-star-fill" />
                              </li>
                              <li>
                                <i className="bi bi-star-fill" />
                              </li>
                              <li>
                                <i className="bi bi-star-fill" />
                              </li>
                              <li>
                                <i className="bi bi-star" />
                              </li>
                              <li>
                                <span>(16)</span>
                              </li>
                            </ul>
                          </div>
                        </div>
                        <div className="ms-auto slider-right-sec margin-right-auto">
                          <svg xmlns="http://www.w3.org/2000/svg" width={20} height={20} fill="currentColor" className="bi bi-heart-fill" viewBox="0 0 16 16">
                            <path fillRule="evenodd" d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314z" fill="#A81A1C" />
                          </svg>
                          <span className="ms-2">10</span>
                        </div>
                      </div>
                      <div>
                        {this.state.product_variation.length > 0
                          ? this.state.product_variation.map((item, i) => {
                            return (

                              <>
                                {
                                  item.color_en !== null &&
                                  (<button key={i} type="button" className="red-btn mt-1" onClick={() => this.setColor(item)}>
                                    {this.context.language === "english" ? item.color_en : item.color_ar}
                                  </button>)
                                }
                              </>
                            );
                          })
                          : ""}
                      </div>
                      <div className="price-div-pro-s my-3">
                        {this.state.currentVariation ? (
                          <ul>
                            <li>
                              <span>{this.state.currentVariation.discount_price.toFixed(2) + " SR"}</span>
                            </li>
                            {this.state.currentVariation.discount !== 0 && (
                              <li>
                                <bdi>{this.state.currentVariation.price.toFixed(2)}</bdi>
                              </li>
                            )}
                            {this.state.currentVariation.discount !== 0 && (
                              <li>
                                <dl>{this.state.currentVariation.discount.toFixed(2)}%</dl>
                              </li>
                            )}
                          </ul>
                        ) : (
                          ""
                        )}

                        <span className="dark-red-txt">{productLanguage.InclusiveofAllTaxes}</span>
                      </div>
                      <div className="my-3">
                        <div className="iner-pro-title">
                          <h3>{productLanguage.SelectSize}</h3>
                        </div>

                        <div className="btn-group mt-3" role="group" aria-label="Basic radio toggle button group">
                          <ul className="size-btn">
                            {this.state.currentVariation
                              ? this.state.product_variant?.map((item, i) => {
                                if (this.state.currentVariation.id === item.variation_id) {
                                  return (
                                    // <input type="radio" disabled className="btn-check" />
                                    <li className="btn" key={i}>
                                      {item.size}
                                    </li>
                                  );
                                }
                              })
                              : ""}
                          </ul>
                        </div>
                      </div>
                      <div className="mt-5 mb-4">
                        <button disabled className="red-btn d-flex">
                          <img className="me-2" src={cart} alt="" />
                          {productLanguage.ADDTOCart}
                        </button>
                      </div>

                      {/* <div className="product-dtl mt-2">
                                                    <span>
                                                        {this.state.product_details['description_ar']}
                                                    </span>
                                                </div> */}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="row common-space">
            <div className="col-md-12">
              <div className="white-box">
                <div className="cust-tab">
                  <Tabs defaultActiveKey="spec" id="uncontrolled-tab-example" className="mb-3">
                    <Tab eventKey="description" title={productLanguage.Description}>
                      {Language == "english" ? this.state.product_details["description_en"] : this.state.product_details["description_ar"]}
                    </Tab>
                    <Tab eventKey="review" title={productLanguage.Reviews}>
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap.
                    </Tab>
                    <Tab eventKey="spec" title={productLanguage.Specification}>
                      <div className="row">
                        <div className="col">
                          <ul className="spec-tab">
                            <li>
                              {productLanguage.Occasion}: <bdi>Party</bdi>
                            </li>
                            <li>
                              {productLanguage.Design}: <bdi>Printed</bdi>
                            </li>
                            <li>
                              {productLanguage.Length}: <bdi>Full Length</bdi>
                            </li>
                          </ul>
                        </div>
                        <div className="col">
                          <ul className="spec-tab">
                            <li>
                              {productLanguage.SleeveLength}: <bdi>Cap Sleeve</bdi>
                            </li>
                            <li>
                              {productLanguage.Material}: <bdi>Cotton & Polyster</bdi>
                            </li>
                            <li>
                              {productLanguage.NoOfPieces}: <bdi>2</bdi>
                            </li>
                          </ul>
                        </div>
                        <div className="col">
                          <ul className="spec-tab">
                            <li>
                              {productLanguage.Neckline}: <bdi>Round Neck</bdi>
                            </li>
                            <li>
                              {productLanguage.Closure}: <bdi>Buckle </bdi>
                            </li>
                            <li>
                              {productLanguage.AgeGroup}: <bdi>Toddlers(2-8Years)</bdi>
                            </li>
                          </ul>
                        </div>
                        <div className="col">
                          <ul className="spec-tab">
                            <li>
                              {productLanguage.Fit}: <bdi>Slim</bdi>
                            </li>
                            <li>
                              {productLanguage.Type}: <bdi>Pyjamas</bdi>
                            </li>
                            <li>
                              {productLanguage.CareInstruction}: <bdi>Only Hand wash</bdi>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </Tab>
                  </Tabs>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Adminlayout>
    );
  }
}

export default Productdetails;

