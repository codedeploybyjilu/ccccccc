import React, { Component, createRef } from "react";
import Select from "react-select";
import dragimg from "../../images/file-upload.svg";
import imgprev from "../../images/img-prev.png";
import videoicn from "../../images//video-icn.svg";
import { Formik } from "formik";
import * as EmailValidator from "email-validator";
import * as Yup from "yup";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";

import { PostApi } from "../../helper/APIService";
import { Modal } from "react-bootstrap";
import plusImg from "../../images/plus-icn.svg";
import loader from "../../images/loader.gif";
import { API_Path, APIBaseUrl, buttonArabic, buttonEnglish, TableFieldArabic, TableFieldEnglish, titleArabic, titleEnglish, productArabic, productEnglish, LIVE_FILE_URL } from "../../const";
import LanguageContext from "../../contexts/languageContext";
import { Prompt } from 'react-router-dom';

let ImageFileArray = [];
let images = [];
let videos = [];
let TagArray = [];
let TagValue = [];
let RowArray = [];
let columnArray = [];
let modelwearArray = [];

const reorder = (list, startIndex, endIndex) => {
  const result = Array.from(list);
  const [removed] = result.splice(startIndex, 1);
  result.splice(endIndex, 0, removed);

  return result;
};

const grid = 8;

const getItemStyle = (isDragging, draggableStyle) => ({
  // some basic styles to make the items look a bit nicer
  userSelect: "none",
  padding: grid,

  // change background colour if dragging
  background: isDragging ? "#A81A1C" : "#F7F7F7",

  // styles we need to apply on draggables
  ...draggableStyle,
});

const getListStyle = (isDraggingOver, itemsLength) => ({
  background: isDraggingOver ? "#f7f7f7" : "#fff",
  display: "flex",
  flexWrap: "wrap",
  padding: grid,
  width: itemsLength * 150 + 10,
});

export default class BasicDetails extends Component {
  static contextType = LanguageContext;

  constructor(props) {
    super(props);

    this.state = {
      selectedOption: "",
      selectedOptiontags: "",
      count: 0,
      status: 1,
      returnable: 1,
      items: "",
      videoFiles: "",
      englishTitle: "",
      arabicTitle: "",
      englishDescription: "",
      arabicDescription: "",
      mainCategory: "",
      category: "",
      subCategory: "",
      barcode: "",
      productCode: "",
      tags: "",
      tagsForDisplay: [],
      tagsValue: [],
      maincategoryData: "",
      categoryData: "",
      subCategoryData: "",
      designData: "",
      materialData: "",
      careInstructionData: "",
      productActivateStatus: false,
      previewTable: false,
      // selectRow: '',
      // selectColumn: '',
      rowOption: [
        { value: "XS", label: "XS" },
        { value: "S", label: "S" },
        { value: "M", label: "M" },
        { value: "L", label: "L" },
        { value: "XL", label: "XL" },
        { value: "XXL", label: "XXL" },
        { value: "XXXL", label: "XXXL" },
      ],
      columnOption: [],
      selectedRow: "",
      selectedColumn: "",
      sizeGuideData: [],
      sizeGuideline: "",
      sizeImage: "",
      thumbnailImg: "",
      sizeImageUrl: "",
      thumbnailImgUrl: "",
      isLoading: false,
      showSizeGuide: true,
      shouldBlockNavigation: "",
      sizeGuideLineType: ''
    };
    this.runforms = createRef();
    this.onDragEnd = this.onDragEnd.bind(this);
  }

  componentDidMount() {
    this.getMainCategoryData();
    this.getdesignData();
    this.getMaterialData();
    this.getcareInstructionData();
    // this.setState({ shouldBlockNavigation: true }, () => {
    //   if (this.state.shouldBlockNavigation) {
    //     window.onbeforeunload = () => true;
    //   } else {
    //     window.onbeforeunload = undefined;
    //   }
    // })
  }

  // componentDidUpdate = () => {
  //   if (this.state.shouldBlockNavigation) {
  //     window.onbeforeunload = () => true;
  //   } else {
  //     window.onbeforeunload = undefined;
  //   }
  // };

  size_show = () => {
    this.setState({ sizeguide_show: true });
  };

  edit_Close = () => {
    this.setState({
      sizeguide_show: false,
      previewTable: false,
      selectedColumn: [],
      selectedRow: [],
    });
  };

  onDragEnd(result) {
    // dropped outside the list
    if (!result.destination) {
      return;
    }

    const items = reorder(this.state.items, result.source.index, result.destination.index);

    this.setState({
      items,
    });
  }

  errorContainer = (form, field) => {
    return form.touched[field] && form.errors[field] ? <span className="error text-danger">{form.errors[field]}</span> : null;
  };

  formAttr = (form, field) => ({
    onBlur: form.handleBlur,
    onChange: form.handleChange,
    value: form.values[field],
  });

  options = [
    { value: "XS", label: "XS" },
    { value: "S", label: "S" },
    { value: "M", label: "M" },
    { value: "L", label: "L" },
    { value: "XL", label: "XL" },
    { value: "XXL", label: "XXL" },
    { value: "XXXL", label: "XXXL" },
  ];

  handleSelect = (selectedOption) => {
    this.setState({ selectedOption }, () => {
      if (this.state.selectedOption.length > 0) {
        document.getElementById("selectedOptionError").style.display = "none";
      } else {
        document.getElementById("selectedOptionError").style.display = "block";
      }
    });
  };

  handleRowSelect = (selectedRow) => {
    this.setState({ selectedRow }, () => {
      if (this.state.selectedRow.length < 1) {
        document.getElementById("selectedRowError").style.display = "block";
      } else {
        document.getElementById("selectedRowError").style.display = "none";
      }
    });
  };

  handleColumnSelect = (selectedColumn) => {
    this.setState({ selectedColumn }, () => {
      if (this.state.selectedColumn.length < 1) {
        document.getElementById("selectedColumnError").style.display = "block";
      } else {
        document.getElementById("selectedColumnError").style.display = "none";
      }
    });
  };

  handleSelectTag = (selectedOptiontags) => {
    this.setState({ selectedOptiontags }, () => {
      console.log("taghs :: ", this.state.selectedOptiontags);
      if (this.state.selectedOptiontags.length > 0) {
        document.getElementById("selectedOptiontagsError").style.display = "none";
      } else {
        document.getElementById("selectedOptiontagsError").style.display = "block";
      }
    });
  };

  optionstags = [
    { value: "winter", label: "winter" },
    { value: "Summer", label: "Summer" },
    { value: "Monsson", label: "Monsson" },
  ];

  decresebtn = () => {
    this.state.count = this.state.count + 1;
  };

  handleTableSubmit = () => {
    if (this.state.selectedColumn.length > 0 && this.state.selectedRow.length > 0) {
      this.setState({ previewTable: true });
    } else {
      if (this.state.selectedColumn.length < 1) {
        document.getElementById("selectedColumnError").style.display = "block";
      } else {
        document.getElementById("selectedColumnError").style.display = "none";
      }
      if (this.state.selectedRow.length < 1) {
        document.getElementById("selectedRowError").style.display = "block";
      } else {
        document.getElementById("selectedRowError").style.display = "none";
      }
    }
  };

  // handleImageFile = (e) => {
  //     let array = Object.values(e.target.files)

  //     for (let i = 0; i < array.length; i++) {

  //         let imageObject = {
  //             src: array[i],
  //             id: (Math.floor(Math.random() * 1000000) + 1).toString()
  //         }

  //         ImageFileArray.push(imageObject)
  //         // images.push(URL.createObjectURL(array[i]))
  //     }
  //     this.setState({ items: ImageFileArray }, () => {
  //         if (this.state.items.length > 0) {
  //             document.getElementById('imageArrayError').style.display = 'none'
  //         }
  //     })

  // }

  // removeImage = (id) => {
  //     const filteredimage = this.state.items.filter((item) => item.id !== id);
  //     // console.log('filter :: ', filteredimage);
  //     this.setState({ items: filteredimage }, () => {
  //         if (this.state.items.length == 0) {
  //             document.getElementById('imageArrayError').style.display = 'block'
  //         }
  //     })
  // }

  getMainCategoryData = () => {

    let data = {};

    let path = API_Path.getMainCategory;
    const getMainCategoryPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getMainCategoryPromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data);
        this.setState({ maincategoryData: res.data.data });
      }
    });
  };

  getCategoryData = (val) => {
    if (val) {

      let data = { main_category_id: val };
      let path = API_Path.getCategoryRelative;
      const getCategoryPromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      getCategoryPromise.then((res) => {
        if (res) {
          // console.log('res is :: ', res.data.data);
          this.setState({ categoryData: res.data.data });
        }
      });
    } else {

      let data = {};

      let path = API_Path.getCategory;
      const getCategoryPromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      getCategoryPromise.then((res) => {
        if (res) {
          // console.log('res is :: ', res.data.data);
          this.setState({ categoryData: res.data.data });
        }
      });
    }
  };

  getSubCategoryData = (val) => {
    // console.log(val);
    if (val) {

      let data = { category_id: val };

      let path = API_Path.getSubCategoryRelative;
      const getSubCategoryPromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      getSubCategoryPromise.then((res) => {
        if (res) {
          // console.log('res is :: ', res.data.data);
          this.setState({ subCategoryData: res.data.data });
        }
      });
    } else {

      let data = {};
      let path = API_Path.getSubCategory;
      const getSubCategoryPromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      getSubCategoryPromise.then((res) => {
        if (res) {
          // console.log('res is :: ', res.data.data);
          this.setState({ subCategoryData: res.data.data });
        }
      });
    }
  };

  getdesignData = () => {

    let data = {};

    let path = API_Path.getDesign;
    const getDesignPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getDesignPromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data);
        this.setState({ designData: res.data.data });
      }
    });
  };

  getMaterialData = () => {

    let data = {};

    let path = API_Path.getMaterial;
    const getMaterialPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getMaterialPromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data);
        this.setState({ materialData: res.data.data });
      }
    });
  };

  getcareInstructionData = () => {

    let data = {};

    let path = API_Path.getCareInstruction;
    const getcareInstructionDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getcareInstructionDataPromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res);
        this.setState({ careInstructionData: res.data.data });
      }
    });
  };

  addImageToStorage = (files) => {


    // console.log('files is :: ', files);

    var formData = new FormData();
    for (var i = 0; i < files.length; i++) {
      formData.append("file", files[i]);
    }

    let path = API_Path.addFileInS3;
    const addFileInS3Promise = new Promise((resolve, reject) => {
      resolve(PostApi(path, formData));
    });

    addFileInS3Promise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data[0]);
        this.setState({ sizeImageUrl: res.data.data[0] }, () => {
          this.setState({ isLoading: false });
          document.getElementById("imagesizeError").style.display = "none";
        });
      }
    });
  };

  addThumbnailToStorage = (files) => {


    // console.log('files is :: ', files);

    var formData = new FormData();
    for (var i = 0; i < files.length; i++) {
      formData.append("file", files[i]);
    }

    let path = API_Path.addFileInS3;
    const addFileInS3Promise = new Promise((resolve, reject) => {
      resolve(PostApi(path, formData));
    });

    addFileInS3Promise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data[0]);
        this.setState({ thumbnailImgUrl: res.data.data[0] }, () => {
          this.setState({ isLoading: false });
          // document.getElementById('thumbnailError').style.display = 'none'
        });
      }
    });
  };

  handleVideoFile = (e) => {
    this.setState({ videoFiles: e.target.files[0] }, () => {
      console.log("object", this.state.videoFiles);
    });
  };

  RemoveSizeGuideline = () => {
    this.setState({ sizeImageUrl: "", sizeGuideData: "", sizeGuideline: "" });

    // this.setState({ showSizeGuide: false });
  };

  removeVideo = () => {
    this.setState({ videoFiles: "" });
  };

  // RemoveSizeGuideline = () => {
  //     this.setState({ sizeGuideData: '' })
  // }

  customStyles = {
    control: () => ({
      height: "50px",
      backgroundColor: "#F7F7F7",
      border: "1px solid #F7F7F7",
      borderRadius: "10px",
      fontSize: "14px",
      color: "#5E5E6C",
      marginBottom: "15px",
      display: "flex",
      zIndex: 2,
    }),

    indicatorSeparator: () => ({
      backgroundColor: "transparent",
    }),

    indicatorContainer: () => ({
      backgroundColor: "#000",
    }),
  };

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value, shouldBlockNavigation: true }, () => {
      // window.onbeforeunload = () => true;
    });
  };

  handleChange1 = (e) => {
    if (e.target.name == "mainCategory") {
      this.getCategoryData(e.target.value);
      this.setState({ mainCategory: e.target.value });
    }
    if (e.target.name == "category") {
      this.getSubCategoryData(e.target.value);
      this.setState({ category: e.target.value });
    }
    if (e.target.name == "subCategory") {
      this.setState({ subCategory: e.target.value }, () => {
        this.getSizeGuideLine();
      });
    }
  };

  handleAddTag = () => {
    if (this.state.tags !== "") {
      let data = {
        value: this.state.tags,
        id: Date.now(),
      };
      TagArray.push(data);
      TagValue.push(data.value);
      this.setState({ tags: "", tagsForDisplay: TagArray, tagsValue: TagValue }, () => {
        if (this.state.tagsForDisplay.length > 0) {
          document.getElementById("selectedOptiontagsError").style.display = "none";
        }
      });
      // console.log('tag :: ', TagArray);
    }
  };

  removeTag = (idToRemove) => {
    const filteredTag = TagArray.filter((item) => item.id !== idToRemove);
    TagArray = filteredTag;
    if (filteredTag?.length > 0) {
      filteredTag?.map((item) => {
        TagValue.push(item.value)
      })
    } else {
      TagValue = []
    }
    this.setState({ tagsForDisplay: filteredTag, tagsValue: TagValue });
  };

  // saveTable = (item) => {
  //     let data;
  //     if (item === 'row') {
  //         data = {
  //             row: this.state.selectRow,
  //             id: Date.now()
  //         }
  //         RowArray.push(data)
  //         this.setState({ totalRow: RowArray })
  //     }
  //     if (item === 'column') {
  //         data = {
  //             column: this.state.selectColumn,
  //             id: Date.now()
  //         }
  //         columnArray.push(data)
  //     }
  // }

  // addThumbnail = (e) => {
  //   this.setState({ thumbnailImg: Object.values(e.target.files) }, () => {
  //     this.setState({ isLoading: true });
  //     this.addThumbnailToStorage(this.state.thumbnailImg);
  //   });
  // };

  addThumbnail = (e) => {


    var form = new FormData();
    for (var i = 0; i < e.target.files.length; i++) {
      form.append("file", e.target.files[i]);
    }

    let path = API_Path.addFileInS3;
    const addFileInS3Promise = new Promise((resolve, reject) => {
      resolve(PostApi(path, form));
    });

    addFileInS3Promise.then((res) => {
      if (res) {
        console.log("res is :: ", res.data.data[0]);
        this.setState({ thumbnailImgUrl: res.data.data[0] }, () => {
          this.setState({ isLoading: false });
          // document.getElementById('thumbnailError').style.display = 'none'
        });
      }
    });
  };

  removeThumbnail = () => {
    this.setState({ thumbnailImg: "", thumbnailImgUrl: "" });
    document.getElementById("thumbnailInput").value = "";
  };

  // handleStatusChange = (e) => {
  //   console.log("e Is :: ", e.target.checked);
  //   this.setState({ productActivateStatus: e.target.checked });
  // };

  handleSizeImage = (e) => {
    // console.log('e', Object.values(e.target.files));
    this.setState({ sizeImage: Object.values(e.target.files) }, () => {
      this.setState({ isLoading: true });
      this.addImageToStorage(this.state.sizeImage);
    });
  };

  removeSizeImage = () => {
    this.setState({ sizeImage: "", sizeImageUrl: "" }, () => {
      document.getElementById("imagesizeError").style.display = "block";
    });
    document.getElementById("imageSizeInput").value = "";
  };

  table_to_array = (table_id) => {
    let myData = document.getElementById(table_id).rows;
    //console.log(myData)
    let my_liste = [];
    for (var i = 0; i < myData.length; i++) {
      let el = myData[i].children;
      let my_el = [];
      for (var j = 0; j < el.length; j++) {
        my_el.push(el[j].innerText);
      }
      my_liste.push(my_el);
    }
    return my_liste;
  };

  getSizeGuideLine = () => {
    let data = {
      main_category: this.state.mainCategory,
      category: this.state.category,
      sub_category: this.state.subCategory,
    };

    let path = API_Path.getSizeGuideLineByCategories;
    const getSizeGuideLineDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getSizeGuideLineDataPromise.then((res) => {
      if (res) {
        console.log("res is :: ", res.data.data);
        this.setState({ sizeGuideData: res.data.data }, () => {
          if (this.state.sizeGuideData.length > 0) {
            this.setState({
              sizeImageUrl: this.state.sizeGuideData[0].size_guide_img,
              sizeGuideline: this.state.sizeGuideData[0].id,
            });
          }
        });
      }
    });
  };

  handleSizeguidelineChange = (e) => {
    let url = e.target.value;
    let id = url.substr(url.lastIndexOf("-") + 1);
    let image = url.substr(0, url.lastIndexOf("-"));
    console.log("image :: ", image);
    this.setState({ sizeGuideline: id, sizeImageUrl: image });
  };

  handleSizeguidelineTypeChange = (e) => {
    this.setState({ sizeGuideLineType: e.target.value })
    if (e.target.value == 0) {
      this.props.selectSpecificSizeGuid(false)
    } else {
      this.setState({ sizeGuideline: '', sizeImageUrl: '' })
      this.props.selectSpecificSizeGuid(true)
    }
  }

  handleModelWearSize = (e) => {
    this.setState({ modelwear: e.target.value }, () => {
      if (e.keyCode === 13) {
        if (this.state.modelwear !== "") {
          this.state.modelwear
            .trim()
            .split(/\s+/)
            .map((item, i) => {
              let data = {
                value: item,
                id: this.makeId(7),
              };
              modelwearArray.push(data);
            });
          let modelValueArray = [];
          modelwearArray.map((l) => {
            let value = l.value;
            modelValueArray.push(value);
          });
          this.setState(
            {
              modelwear: "",
              modelForDisplay: modelwearArray,
              modelValueForDisplay: modelValueArray,
            },
            () => {
              document.getElementById("modelwear").value = "";
            }
          );
        }
      }
    });
  };

  makeId = (length) => {
    var result = "";
    var characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    var charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  };

  removeModel = (idToRemove) => {
    const modelSize = modelwearArray.filter((item) => item.id !== idToRemove);
    modelwearArray = modelSize;
    this.setState({ modelForDisplay: modelSize });
  };

  render() {
    let Language = this.context.language === "english" ? TableFieldEnglish : TableFieldArabic;
    let ButtonLanguage = this.context.language === "english" ? buttonEnglish : buttonArabic;
    let titleLanguage = this.context.language === "english" ? titleEnglish : titleArabic;
    let productLanguage = this.context.language === "english" ? productEnglish : productArabic;
    return (
      <React.Fragment>
        <Prompt when={this.state.shouldBlockNavigation === true} message="You have unsaved changes, are you sure you want to leave?" />

        {this.state.isLoading && (
          <div className="loader-main">
            <div className="loader-inr">
              <img src={loader} alt="" />
            </div>
          </div>
        )}
        <Formik
          innerRef={this.runforms}
          enableReinitialize={true}
          initialValues={{
            englishTitle: this.state.englishTitle,
            arabicTitle: this.state.arabicTitle,
            englishDescription: this.state.englishDescription,
            arabicDescription: this.state.arabicDescription,
            mainCategory: this.state.mainCategory,
            category: this.state.category,
            subCategory: this.state.subCategory,
            barcode: this.state.barcode,
            productCode: this.state.productCode,
            status: this.state.status,
            returnable: this.state.returnable
          }}
          validationSchema={Yup.object().shape({
            englishTitle: Yup.string().required("Required"),
            arabicTitle: Yup.string().required("Required"),
            // englishDescription: Yup.string().required("Required"),
            // arabicDescription: Yup.string().required("Required"),
            mainCategory: Yup.string().required("Required"),
            category: Yup.string().required("Required"),
            subCategory: Yup.string().required("Required"),
            barcode: Yup.string().required("Required"),
          })}
          onSubmit={(values, { setSubmitting }) => {
            this.setState({ shouldBlockNavigation: false })
            setSubmitting(false);
          }}
        >
          {(props) => {
            const { values, touched, errors, isSubmitting, handleChange, handleBlur, handleSubmit } = props;
            return (
              <form className="row mt-3" onSubmit={handleSubmit}>
                <div className="form-group col-md-6">
                  <div className="d-flex align-items-center justify-content-end">
                    <label className="mb-0">{productLanguage.productTitleara}</label>
                  </div>
                  <input type="text" dir="rtl" name="arabicTitle" value={this.state.arabicTitle} onChange={this.handleChange} onBlur={handleBlur} className="form-control input-custom-class" placeholder={productLanguage.EnterProductTitleNameinArabic} />
                  {errors.arabicTitle && touched.arabicTitle && <div className="input-feedback text-danger">{errors.arabicTitle}</div>}
                </div>

                <div className="form-group col-md-6">
                  <div className="d-flex align-items-center ">
                    <label className="mb-0">{productLanguage.productTitle}</label>
                  </div>
                  <input type="text" name="englishTitle" value={this.state.englishTitle} onChange={this.handleChange} onBlur={handleBlur} className="form-control input-custom-class eng-start" placeholder={productLanguage.EnterProductTitleNameinEnglish} />

                  {errors.englishTitle && touched.englishTitle && <div className="input-feedback text-danger">{errors.englishTitle}</div>}
                </div>

                <div className="form-group col-md-6">
                  <div className="d-flex align-items-center  justify-content-end">
                    <label className="mb-0">{productLanguage.ProductDescriptionInArabic}</label>
                  </div>
                  <textarea rows="4" dir="rtl" name="arabicDescription" value={this.state.arabicDescription} onChange={this.handleChange} onBlur={handleBlur} className="form-control  input-custom-class h-auto" placeholder={productLanguage.EnterProductDescriptioninArabic}></textarea>
                  {errors.arabicDescription && touched.arabicDescription && <div className="input-feedback text-danger">{errors.arabicDescription}</div>}
                </div>

                <div className="form-group col-md-6">
                  <div className="d-flex align-items-center">
                    <label className="mb-0">{productLanguage.ProductDescriptionInEng}</label>
                  </div>
                  <textarea rows="4" name="englishDescription" value={this.state.englishDescription} onChange={this.handleChange} onBlur={handleBlur} className="form-control eng-start input-custom-class h-auto" placeholder={productLanguage.EnterProductDescriptioninEnglish}></textarea>
                  {errors.englishDescription && touched.englishDescription && <div className="input-feedback text-danger">{errors.englishDescription}</div>}
                </div>

                <div className="form-group col-xl-3 col-md-4">
                  <label>{productLanguage.mainCategory}</label>
                  <select name="mainCategory" value={this.state.mainCategory} onChange={this.handleChange} onChangeCapture={this.handleChange1} onBlur={handleBlur} className="form-select input-custom-class">
                    <option>{productLanguage.chooseMainCategory} </option>
                    {this.state.maincategoryData &&
                      this.state.maincategoryData.length > 0 &&
                      this.state.maincategoryData.map((item, i) => {
                        return (
                          <option value={item.id} key={i}>
                            {item.english} | {item.arabic}
                          </option>
                        );
                      })}
                  </select>
                  {errors.mainCategory && touched.mainCategory && <div className="input-feedback text-danger">{errors.mainCategory}</div>}
                </div>

                <div className="form-group col-xl-3 col-md-4">
                  <label>{productLanguage.category}</label>
                  <select name="category" value={this.state.category} onChange={this.handleChange} onChangeCapture={this.handleChange1} onBlur={handleBlur} className="form-select input-custom-class">
                    <option>{productLanguage.SelectCategory} </option>
                    {this.state.categoryData &&
                      this.state.categoryData.length > 0 &&
                      this.state.categoryData.map((item, i) => {
                        return (
                          <option value={item.id} key={i}>
                            {item.english} | {item.arabic}
                          </option>
                        );
                      })}
                  </select>
                  {errors.category && touched.category && <div className="input-feedback text-danger">{errors.category}</div>}
                </div>

                <div className="form-group col-xl-3 col-md-4">
                  <label>{productLanguage.subCategory}</label>
                  <select name="subCategory" value={this.state.subCategory} onChange={this.handleChange} onChangeCapture={this.handleChange1} onBlur={handleBlur} className="form-select input-custom-class">
                    <option>{productLanguage.SelectSubCategory}</option>
                    {this.state.subCategoryData &&
                      this.state.subCategoryData.length > 0 &&
                      this.state.subCategoryData.map((item, i) => {
                        return (
                          <option value={item.id} key={i}>
                            {item.english} | {item.arabic}
                          </option>
                        );
                      })}
                  </select>
                  {errors.subCategory && touched.subCategory && <div className="input-feedback text-danger">{errors.subCategory}</div>}
                </div>

                <div className="form-group col-xl-3 col-md-4">
                  <label>{productLanguage.BarcodeNo} </label>
                  <input type="text" name="barcode" value={this.state.barcode} onBlur={handleBlur} onChange={this.handleChange} className="form-control input-custom-class" placeholder={productLanguage.EnterBarcodeNo} />
                  {/* <div id="barcodeNoId" style={{ display: "none" }} className="input-feedback text-danger">
                    Required !!
                  </div> */}
                  {errors.barcode && touched.barcode && <div className="input-feedback text-danger">{errors.barcode}</div>}
                </div>

                <div className="form-group col-xl-3 col-md-4">
                  <label>{productLanguage.ProductCode}</label>
                  <input type="text" name="productCode" value={this.props.productCode} readOnly className="form-control input-custom-class" placeholder={productLanguage.EnterProductCode} />
                </div>

                <div className="form-group col-xl-3 col-md-4">
                  <label>{productLanguage.Tag}</label>
                  <div className="d-flex align-items-center">
                    <input type="text" className="form-control input-custom-class me-2" onChange={this.handleChange} value={this.state.tags} name="tags" placeholder={productLanguage.EnterTagsName} />

                    <div onClick={this.handleAddTag} className="btn light-red-btn">
                      <img src={plusImg} />
                    </div>
                  </div>
                  {this.state.tagsForDisplay && this.state.tagsForDisplay.length > 0 && (
                    <div className="cust-select-cate-drop cust-tag-div">
                      <ul>
                        {this.state.tagsForDisplay.map((item, i) => {
                          return (
                            <li key={i}>
                              <span>{item.value}</span>
                              <mark onClick={() => this.removeTag(item.id)} className=" bg-transparent bi bi-x p-0"></mark>
                            </li>
                          );
                        })}
                      </ul>
                    </div>
                  )}

                  <div id="selectedOptiontagsError" style={{ display: "none" }} className="input-feedback text-danger">
                    Required
                  </div>
                </div>

                <div className="form-group col-md-3">
                  <label> {productLanguage.Productstatus}</label>

                  <select name="status" className="form-select input-custom-class" onChange={this.handleChange} onBlur={handleBlur} value={this.state.status}>
                    <option value="1" selected>
                      {productLanguage.Active}
                    </option>
                    <option value="0">{productLanguage.dective}</option>
                    <option value="3">{productLanguage.postpone}</option>
                    <option value="2">{productLanguage.saveToDraft}</option>
                  </select>
                  {/* {errors.status && touched.status && <div className="input-feedback text-danger">{errors.status}</div>} */}
                </div>

                <div className="form-group col-md-3">
                  <label> {productLanguage.Returnable}</label>

                  <select name="returnable" className="form-select input-custom-class" onChange={this.handleChange} onBlur={handleBlur} value={this.state.returnable}>
                    <option value="1" selected>
                      {productLanguage.Yes}
                    </option>
                    <option value="0"> {productLanguage.No}</option>
                  </select>
                  {/* {errors.status && touched.status && <div className="input-feedback text-danger">{errors.status}</div>} */}
                </div>
                <div className="form-group col-xl-3 col-md-4">
                  <div className=" d-flex">
                    <div className="w-100">
                      <label>{productLanguage.SelectSizeGuideline}</label>
                      <select name="sizeGuideLineType" value={this.state.sizeGuideLineType} onChange={this.handleSizeguidelineTypeChange} className="form-select input-custom-class">
                        <option>{productLanguage.SelectSizeGuideline}</option>
                        <option value={0} selected>Stander SizeGuideline</option>
                        <option value={1}>Specific SizeGuideline</option>
                      </select>
                      {/* <bdi className="red-underline d-block cursor-pointer" onClick={this.size_show}>Add</bdi> */}
                    </div>
                  </div>
                  <div id="sizeGuidelineError" style={{ display: "none" }} className="input-feedback text-danger">
                    Required
                  </div>
                </div>
                {this.state.sizeGuideLineType == 0 &&
                  <div className="form-group col-xl-3 col-md-4">
                    <div className=" d-flex">
                      <div className="w-100">
                        <label>{productLanguage.AddSizeGuideline}</label>
                        <select name="sizeGuideLine" value={this.state.sizeGuideLine} onChange={this.handleSizeguidelineChange} className="form-select input-custom-class">
                          <option>{productLanguage.SelectSizeguideline}</option>
                          {this.state.sizeGuideData.length > 0 &&
                            this.state.sizeGuideData.map((item, i) => {
                              return (
                                <>
                                  {i == 0 ? (
                                    <option key={i} selected value={item.size_guide_img + "-" + item.id}>
                                      {item.size_guide_name_english + " | " + item.size_guide_name_arabic}
                                    </option>
                                  ) : (
                                    <option key={i} value={item.size_guide_img + "-" + item.id}>
                                      {item.size_guide_name_english + " | " + item.size_guide_name_arabic}
                                    </option>
                                  )}
                                </>
                              );
                            })}
                        </select>
                        {/* <bdi className="red-underline d-block cursor-pointer" onClick={this.size_show}>Add</bdi> */}
                      </div>
                      {this.state.sizeGuideline && this.state.sizeGuideline !== "" && (
                        <div className=" flex-wrap align-items-center ms-2">
                          <div className=" text-center my-3">
                            <div className="img-with-close-varia position-relative">
                              <img src={this.state.sizeImageUrl} alt="" />

                              <div onClick={this.RemoveSizeGuideline} className="remove-img-btn">
                                <i className="bi bi-x-circle-fill"></i>
                              </div>
                              {/* <div onClick={this.RemoveSizeGuideline} className="close_variant"><i className="bi bi-x-lg"></i></div> */}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                    <div id="sizeGuidelineError" style={{ display: "none" }} className="input-feedback text-danger">
                      Required
                    </div>
                  </div>
                }
                <div style={{ display: "none" }} className="col-12">
                  <div className="btn-comn-div pt-5 text-center">
                    <button id="basicDetailSubmit" disabled={isSubmitting} type="submit" className="btn-comn">
                      <span>{productLanguage.submit}</span>
                    </button>
                  </div>
                </div>
              </form>
            );
          }}
        </Formik>
      </React.Fragment>
    );
  }
}
