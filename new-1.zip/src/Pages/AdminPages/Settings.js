import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import { Modal } from "react-bootstrap";
import { CKEditor } from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { Accordion } from "react-bootstrap";
import * as Yup from 'yup';
import { Formik } from 'formik';
import { API_Path, settingEnglish, settingArabic, buttonEnglish, buttonArabic } from "../../const";
import { GetApi, PostApi } from "../../helper/APIService";
import toastr from "toastr";
import LanguageContext from "../../contexts/languageContext";
import PhoneInput from "react-phone-input-2";
import moment from "moment";

export class Settings extends Component {
    static contextType = LanguageContext
    constructor(props) {
        super(props);
        this.state = {
            offersettingmodal: false,
            cityData: [],
            areaData: [],
            termsSettingModal: false,
            salePrice: true,
            codRate: 10,
            tabbyMinValue: 100,
            tabbyMaxValue: 300,
            tamaraMinValue: 100,
            tamaraMaxValue: 300,
            codRateLimit: 0,
            ONLINE: true,
            APPLE: true,
            COD: true,
            TABBY: true,
            TAMARA: true,
            taxType: 'Inclusive',
            taxRate: "",
            maintance_mode: true,
            maintance_note: "",
            meta_name_en: "",
            meta_name_ar: "",
            meta_description_en: "",
            meta_description_ar: "",
            meta_keyword_en: "",
            meta_keyword_ar: "",
            tc_en: "",
            tc_ar: "",
            inputList: [{ que_en: "", que_ar: "", ans_en: "", ans_ar: "" }],
            inputListUpdate: [],
            GetSettings: [],
            GetImportantPages: [],
            GetIntegrations: [],
            title_en: "",
            title_ar: "",
            syntax_en: "",
            syntax_ar: "",
            search_val: '',
            sizePerPage: 10000,
            page: 1,
            defaultSorted: [
                {
                    dataField: "id",
                    order: "desc",
                },
            ],
            SnapChatModal: false,
            MetaModal: false,
            GoogleModal: false,
            SanpchatId: '',
            metaId: '',
            gooleID: '',
            TiktokId: '',
            TiktokModal: false,
            Inclusive: false,
            Exclusive: false,
            statusSettingmodal: false,
            BannerModelShow: false,
            banerActive: '',
            BannerImg: '',
            CoponCode: '',
            codeValidation: false,
            adminModelShow: false,
            AdminPhone: '',
            AdminName: '',
            AdminDetails: '',
            adminId: '',
            chatModelShow: false,
            chatType: '1',
            chatWPNumber: '',
            warehouseRegistrationModal: false,
        };
        this.runforms = React.createRef()
    }

    componentDidMount() {
        this.getShippingData();
        this.getSettings()
        this.getCity()
        // this.getIntegrations()
    }

    getCity = () => {
        let path = API_Path.getShippingCity;
        let data = {
            sizePerPage: this.state.sizePerPage,
            page: this.state.page,
            defaultSorted: this.state.defaultSorted,
            search_val: this.state.search_val
        };
        const getCityPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        getCityPromise.then((res) => {
            if (res) {
                if (res.data.success) {
                    this.setState({ cityData: res.data.data }, () => {
                    });
                }
            }
        });
    }

    getArea = () => {
        let data = {
            isocode: this.state.isoCode,
            city_id: this.state.city
        };

        let path = API_Path.getArea;
        const getAreaDataPromise = new Promise((resolve) => {
            resolve(PostApi(path, data));
        });

        getAreaDataPromise.then((res) => {
            if (res) {
                if (res.data.success) {
                    this.setState({ areaData: res.data.data });
                }
            }
        });
    };

    getShippingData = () => {
        let data = {};
        let path = API_Path.getShippingCompany;
        const getShippingDataPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });
        getShippingDataPromise.then((res) => {
            if (res) {
                if (res.data.success) {
                    this.setState({ shippingCompanyData: res.data.data });
                }
            }
        });
    };

    getSettings = () => {
        let path = API_Path.GetSetting;
        const getShippingDataPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, {}));
        });

        getShippingDataPromise.then((res) => {
            if (res) {
                if (res.data.success) {
                    this.setState({ GetSettings: res.data.data[0] }, () => {
                        this.setState({
                            ONLINE: this.state.GetSettings.payment.online_payment === 1 ? true : false,
                            COD: this.state.GetSettings.payment.cod_payment === 1 ? true : false,
                            APPLE: this.state.GetSettings.payment.apple_pay === 1 ? true : false,
                            TABBY: this.state.GetSettings.payment.tabby === 1 ? true : false,
                            TAMARA: this.state.GetSettings.payment.tamara === 1 ? true : false,
                            tabbyMinValue: this.state.GetSettings.payment.tabby_min_value,
                            tabbyMaxValue: this.state.GetSettings.payment.tabby_max_value,
                            tamaraMinValue: this.state.GetSettings.payment.tamara_min_value,
                            tamaraMaxValue: this.state.GetSettings.payment.tamara_max_value,
                            codRate: this.state.GetSettings.payment.cod_amount,
                            codRateLimit: this.state.GetSettings.payment.cod_amount_limit,
                            salePrice: this.state.GetSettings.offer.sale === 1 ? true : false,
                            city: this.state.GetSettings.shipping?.city,
                            Exclusive: this.state.GetSettings.tax.tax === "Exclusive" ? true : false,
                            Inclusive: this.state.GetSettings.tax.tax === "Inclusive" ? true : false,
                            taxRate: this.state.GetSettings.tax.tax_rate,
                            maintance_mode: this.state.GetSettings.store.maintenance === 1 ? true : false,
                            maintance_note: this.state.GetSettings.store.maintenance_note,
                            banerActive: this.state.GetSettings.popup.status === 1 ? true : false,
                            BannerImg: this.state.GetSettings.popup.image,
                            CoponCode: this.state.GetSettings.popup.coupon_code,
                            chatType: this.state.GetSettings.chat.chatType,
                            chatWPNumber: this.state.GetSettings.chat.number,
                            meta_name_en: this.state.GetSettings.seo.meta_title_en,
                            meta_name_ar: this.state.GetSettings.seo.meta_title_ar,
                            meta_description_en: this.state.GetSettings.seo.meta_description_en,
                            meta_description_ar: this.state.GetSettings.seo.meta_description_ar,
                            meta_keyword_en: this.state.GetSettings.seo.meta_keyword_en,
                            meta_keyword_ar: this.state.GetSettings.seo.meta_keyword_ar,

                        }, () => {
                            let cityArr = []
                            this.state.cityData.filter((item) => {
                                if (item.id === parseInt(this.state.city)) {
                                    cityArr.push(item);
                                }
                            });
                            this.setState({ isoCode: cityArr[0]?.isocode }, () => {
                                this.getArea()
                            })
                        })
                        if (this.runforms.current) {
                            this.runforms.current.setFieldValue("company_name", this.state.GetSettings.shipping?.company_name)
                            this.runforms.current.setFieldValue("contact_name", this.state.GetSettings.shipping?.contact_name)
                            this.runforms.current.setFieldValue("address", this.state.GetSettings.shipping?.address)
                            // this.runforms.current.setFieldValue("city", this.state.GetSettings.shipping?.city)
                            this.runforms.current.setFieldValue("area", this.state.GetSettings.shipping?.area)
                            this.runforms.current.setFieldValue("contact_number", this.state.GetSettings.shipping?.contact_number)
                            this.runforms.current.setFieldValue("email", this.state.GetSettings.shipping?.email)
                            this.runforms.current.setFieldValue("shipping_company", this.state.GetSettings.shipping?.default_shipping)
                            this.runforms.current.setFieldValue("collection_point_delivery", this.state.GetSettings.shipping?.collection_point_delivery)
                            this.runforms.current.setFieldValue("collection_point_delivery_charge", this.state.GetSettings.shipping?.collection_point_delivery_charge)
                            this.runforms.current.setFieldValue("delivery_time", this.state.GetSettings.shipping?.default_delivery_time)
                            this.runforms.current.setFieldValue("freeShipping_limit", this.state.GetSettings.shipping?.shipping_free_amount)
                            this.runforms.current.setFieldValue("shipping_charge", this.state.GetSettings.shipping?.default_shipping_charge)
                        }
                    });
                }
            }
        });
    }

    getWareHouses = () => {
        // let path = API_Path.getPickupLocations;
        // const getWarehouseDataPromise = new Promise((resolve, reject) => {
        //     resolve(PostApi(path, {}));
        // });

        // getWarehouseDataPromise.then((res) => {
        //     if (res) {
        //         if (res.data.success) {
        //         }
        //     }
        // });
    }

    getImportantPages = (page) => {
        let data = {
            page: page
        }
        let path = API_Path.GetImportantPage;
        const getImportantPagesDataPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        getImportantPagesDataPromise.then((res) => {
            if (res) {
                if (res.data.success) {
                    this.setState({ GetImportantPages: res.data.data }, () => {
                        if (page === 'Terms And Conditions') {
                            this.setState({ tc_en: this.state.GetImportantPages?.title_en, tc_ar: this.state.GetImportantPages?.title_ar, tc_content_en: this.state.GetImportantPages?.syntax_en, tc_content_ar: this.state.GetImportantPages?.syntax_ar }, () => {
                                this.setState({ termsSettingModal: true })
                            })
                        }
                        if (page === 'Privacy Policy') {
                            this.setState({ privacy_en: this.state.GetImportantPages?.title_en, privacy_ar: this.state.GetImportantPages?.title_ar, privacy_content_en: this.state.GetImportantPages?.syntax_en, privacy_content_ar: this.state.GetImportantPages?.syntax_ar }, () => {
                                this.setState({ privacyPolicySettingModal: true })
                            })
                        }
                        if (page === 'Return Policy') {
                            this.setState({ return_en: this.state.GetImportantPages?.title_en, return_ar: this.state.GetImportantPages?.title_ar, return_content_en: this.state.GetImportantPages?.syntax_en, return_content_ar: this.state.GetImportantPages?.syntax_ar }, () => {
                                this.setState({ returnSettingModal: true })
                            })
                        }
                        if (page === 'Frequently Asked Questions') {
                            this.setState({ inputList: [{ que_en: this.state.GetImportantPages?.title_en, que_ar: this.state.GetImportantPages?.title_ar, ans_en: this.state.GetImportantPages?.syntax_en, ans_ar: this.state.GetImportantPages?.syntax_ar }] }, () => {
                                this.setState({ faqsettingmodal: true })
                            })
                        }
                    });
                }
            }
        });
    }

    // getIntegrations = () => {
    //     let path = API_Path.GetAnalytics;
    //     const getIntegrationsDataPromise = new Promise((resolve, reject) => {
    //         resolve(PostApi(path, {}));
    //     });

    //     getIntegrationsDataPromise.then((res) => {
    //         if (res) {
    //             this.setState({ GetIntegrations: res.data.data });
    //         }
    //     });
    // }

    // ============================= * ==============================

    formAttr = (form, field) => ({
        onBlur: form.handleBlur,
        onChange: form.handleChange,
        value: form.values[field],
    });

    handleChange = (e) => {
        this.setState({ [e.target.name]: e.target.value }, () => {
            if (e.target.name === 'city') {
                let cityArr = []
                this.state.cityData.filter((item) => {
                    if (item.id === parseInt(this.state.city)) {
                        cityArr.push(item);
                    }
                });
                this.setState({ isoCode: cityArr[0]?.isocode }, () => {
                    this.getArea()
                })
            }
        })
    }
    handleChangePhone = (value) => {
        this.setState({ AdminPhone: value })
    }
    handleChatPhone = (phone) => {
        this.setState({ chatWPNumber: phone })
    }

    // ------------------------------- modal open ------------------------------ //

    offersettingmodal = () => {
        this.setState({ offersettingmodal: true });
    };
    offersettingmodalclose = () => {
        this.setState({ offersettingmodal: false });
    };

    taxsettingmodal = () => {
        this.setState({ taxsettingmodal: true }, () => {
            this.getSettings()
        });
    };
    chatModelopen = () => {
        this.setState({ chatModelShow: true }, () => {
            this.getSettings()
        })
    }
    taxsettingmodalclose = () => {
        this.setState({ taxsettingmodal: false });
    };
    chatModelClose = () => {
        this.setState({ chatModelShow: false })
    }

    paymentsettingmodal = () => {
        this.setState({ paymentsettingmodal: true }, () => {
            this.getSettings()
        });
    };
    paymentsettingmodalclose = () => {
        this.setState({ paymentsettingmodal: false });
    };

    shippingsettingmodal = () => {
        this.setState({ shippingsettingmodal: true }, () => {
            this.getSettings()
        });
    };
    shippingsettingmodalclose = () => {
        this.setState({ shippingsettingmodal: false });
    };
    warehouseRegistrationModal = () => {
        this.setState({ warehouseRegistrationModal: true }, () => {
            this.getWareHouses()
        });
    };
    warehouseRegistrationModalClose = () => {
        this.setState({ warehouseRegistrationModal: false });
    };

    seosettingmodal = () => {
        this.setState({ seosettingmodal: true }, () => {
            this.getSettings();
        });
    };
    seosettingmodalclose = () => {
        this.setState({ seosettingmodal: false });
    };

    statussettingmodal = () => {
        this.setState({ statusSettingmodal: true }, () => {
            this.getSettings()
        });
    };
    statussettingmodalclose = () => {
        this.setState({ statusSettingmodal: false });
    };

    termsSettingModal = () => {
        // this.setState({ termsSettingModal: true },()=>{
        this.getImportantPages('Terms And Conditions')
        // })
    }
    termsSettingModalClose = () => {
        this.setState({ termsSettingModal: false });
    }

    privacyPolicySettingModal = () => {
        // this.setState({ privacyPolicySettingModal: true }, () => {
        this.getImportantPages('Privacy Policy')
        // });
    }
    privacyPolicySettingModalClose = () => {
        this.setState({ privacyPolicySettingModal: false });
    }

    returnSettingModal = () => {
        // this.setState({ returnSettingModal: true }, () => {
        this.getImportantPages('Return Policy')
        // });
    }
    returnSettingModalClose = () => {
        this.setState({ returnSettingModal: false });
    }

    faqsettingmodal = () => {
        // this.setState({ faqsettingmodal: true }, () => {
        this.getImportantPages('Frequently Asked Questions')
        // });
    }
    faqsettingmodalClose = () => {
        this.setState({ faqsettingmodal: false });
    }
    bannerModel = () => {
        this.setState({ BannerModelShow: true }, () => {
            this.getSettings()
        })
    }
    bannerModelClose = () => {
        this.setState({ BannerModelShow: false })
    }

    AdminModel = () => {
        this.getAdminDetails()
        this.setState({ adminModelShow: true })
    }
    adminModelClose = () => {
        this.setState({ adminModelShow: false })
    }
    // -------------------------- submit --------------------------- //

    handleSubmitSettings = (value) => {
        let data = {
            settings: value,
            contact_name: this.state.shippingDetails?.contact_name,
            company_name: this.state.shippingDetails?.company_name,
            address: this.state.shippingDetails?.address,
            city: this.state?.city,
            area: this.state?.shippingDetails?.area,
            contact_number: this.state.shippingDetails?.contact_number,
            email: this.state.shippingDetails?.email,
            default_shipping: this.state.shippingDetails?.shipping_company,
            collection_point_delivery: this.state.shippingDetails?.collection_point_delivery,
            collection_point_delivery_charge: this.state.shippingDetails?.collection_point_delivery_charge,
            default_delivery_time: this.state.shippingDetails?.delivery_time,
            default_shipping_charge: this.state.shippingDetails?.shipping_charge,
            shipping_free_amount: this.state.shippingDetails?.freeShipping_limit,
            sale: this.state.salePrice === true ? 1 : 0,
            tax: this.state.taxType,
            tax_rate: parseInt(this.state.taxRate),
            online_payment: this.state.ONLINE === true ? 1 : 0,
            cod_payment: this.state.COD === true ? 1 : 0,
            apple_pay: this.state.APPLE === true ? 1 : 0,
            tabby: this.state.TABBY === true ? 1 : 0,
            tamara: this.state.TAMARA === true ? 1 : 0,
            tabby_min_value: parseInt(this.state.tabbyMinValue ?? 0),
            tabby_max_value: parseInt(this.state.tabbyMaxValue ?? 0),
            tamara_min_value: parseInt(this.state.tamaraMinValue ?? 0),
            tamara_max_value: parseInt(this.state.tamaraMaxValue ?? 0),
            cod_amount: parseInt(this.state.codRate),
            cod_amount_limit: parseInt(this.state.codRateLimit),
            meta_title_en: this.state.meta_name_en,
            meta_title_ar: this.state.meta_name_ar,
            meta_description_en: this.state.meta_description_en,
            meta_description_ar: this.state.meta_description_ar,
            meta_keyword_en: this.state.meta_keyword_en,
            meta_keyword_ar: this.state.meta_keyword_ar,
            maintenance: this.state.maintance_mode === true ? 1 : 0,
            maintenance_note: this.state.maintance_note,
            status: this.state.banerActive ? 1 : 0,
            image: this.state.BannerImg,
            coupon_code: this.state.CoponCode,
            chatType: this.state.chatType,
            number: this.state.chatWPNumber
        };
        // console.log(this.state.CoponCode, "this.state.CoponCode");
        if (value == 'popup' && this.state.CoponCode === '') {
            this.setState({ codeValidation: true })
        } else {
            const UpdateSettingDataPromise = new Promise((resolve, reject) => {
                resolve(PostApi(API_Path.UpdateSetting, data));
            });

            UpdateSettingDataPromise.then((res) => {
                if (res) {
                    if (res.data.success) {
                        toastr.success(res.data.message)
                        this.statussettingmodalclose()
                        this.seosettingmodalclose()
                        this.shippingsettingmodalclose()
                        this.warehouseRegistrationModalClose()
                        this.paymentsettingmodalclose()
                        this.taxsettingmodalclose()
                        this.offersettingmodalclose()
                        this.bannerModelClose()
                        this.chatModelClose()
                    } else {
                    }
                }
            });
        }

    }

    handleSubmitImportantPages = (page) => {
        let data = {
            page: page,
            slug: page.replaceAll(' ', '-')?.toLowerCase(),
            title_en: this.state.title_en,
            title_ar: this.state.title_ar,
            syntax_en: this.state.syntax_en,
            syntax_ar: this.state.syntax_ar
        };

        const UpdateSettingDataPromise = new Promise((resolve, reject) => {
            resolve(PostApi(API_Path.UpdateImportantPage, data));
        });

        UpdateSettingDataPromise.then((res) => {
            if (res) {
                if (res.data.success) {
                    toastr.success(res.data.message)
                    this.termsSettingModalClose()
                    this.privacyPolicySettingModalClose()
                    this.returnSettingModalClose()
                    this.faqsettingmodalClose()
                } else {
                }
            }
        });
    }

    // =========================== * ==========================

    //  ================ shipping setting ==============

    handleSubmitOffer = () => {
        this.offersettingmodalclose()
    }

    handleSubmitTaxSetting = () => {
        // let data = {
        //     taxType: this.state.taxType,
        //     taxRate: this.state.taxRate
        // }

        // console.log(data)
        this.taxsettingmodalclose()
    }

    handlePaymentSettingSubmit = () => {
        // let data = {
        //     online: this.state.ONLINE,
        //     cod: this.state.COD,
        //     applePay: this.state.APPLE,
        //     codRate: this.state.codRate
        // }
        // console.log(data)

        this.paymentsettingmodalclose()
    }

    submitShippingDetails = (formData) => {
        this.setState({ shippingDetails: formData }, () => {
            this.handleSubmitSettings('shipping')
        })
        this.shippingsettingmodalclose()
    }

    submitWarehouseDetails = (formData) => {
        const payload = {
            ...formData,
            pickup_time: moment(formData.pickup_time, "HH:mm").format("hh:mm A")
        }
        const UpdateSettingDataPromise = new Promise((resolve, reject) => {
            resolve(PostApi(API_Path.createPickupLocation, payload));
        });

        UpdateSettingDataPromise.then((res) => {
            if (res) {
                if (res.data.success) {
                    toastr.success(res.data.message ?? "Warehouse registered successfully");
                }
                else {
                    toastr.error(res.data.message ?? "Warehouse registration unsuccessful");
                }
            }
        });

        this.warehouseRegistrationModalClose()
    }

    handleSEOSubmit = () => {
        let data = {
            title_en: this.state.meta_name_en,
            title_ar: this.state.meta_name_ar,
            description_en: this.state.meta_description_en,
            description_ar: this.state.meta_description_ar,
            keyword_en: this.state.meta_keyword_en,
            keyword_ar: this.state.meta_keyword_ar,
        }

        this.seosettingmodalclose()
    }

    handleSubmitStoreStatus = () => {
        let data = {
            maintance_mode: this.state.maintance_mode,
            maintance_note: this.state.maintance_note
        }

        this.statussettingmodalclose()
    }

    // ============================== * ===============================

    // ===================== important pages setting ====================

    handleSubmitTermsCondition = () => {
        this.setState({
            title_en: this.state.tc_en,
            title_ar: this.state.tc_ar,
            syntax_en: this.state.tc_content_en,
            syntax_ar: this.state.tc_content_ar
        }, () => {
            this.handleSubmitImportantPages('Terms And Conditions')
        })
    }

    handleSubmitPrivacyPolicy = () => {
        this.setState({
            title_en: this.state.privacy_en,
            title_ar: this.state.privacy_ar,
            syntax_en: this.state.privacy_content_en,
            syntax_ar: this.state.privacy_content_ar
        }, () => {
            this.handleSubmitImportantPages('Privacy Policy')
        })
    }

    handleSubmitReturnPolicy = () => {
        this.setState({
            title_en: this.state.return_en,
            title_ar: this.state.return_ar,
            syntax_en: this.state.return_content_en,
            syntax_ar: this.state.return_content_ar
        }, () => {
            this.handleSubmitImportantPages('Return Policy')
        })
    }

    handleSubmitFAQ = () => {
        this.setState({
            title_en: this.state.inputList[0]?.que_en,
            title_ar: this.state.inputList[0]?.que_ar,
            syntax_en: this.state.inputList[0]?.ans_en,
            syntax_ar: this.state.inputList[0]?.ans_ar

        }, () => {
            this.handleSubmitImportantPages('Frequently Asked Questions')
        })
    }

    handleRemoveClick = (index) => {
        const list = [...this.state.inputList];
        list.splice(index, 1);
        this.setState({ inputList: list })
    };

    handleAddClick = () => {
        this.setState({ inputList: [...this.state.inputList, { que_en: "", que_ar: "", ans_en: "", ans_ar: "" }] });
    };

    handleInputChange = (e, index) => {
        const list = [...this.state.inputList];
        list[index][e.target.name] = e.target.value;

        this.setState({ inputList: list }, () => {
            let result = this.state.inputList.map((item) => item)
            this.setState({ inputListUpdate: result })
        })
    };

    googleShow = () => {
        let path = API_Path.GetAnalytics;
        const getIntegrationsDataPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, { analytic: 'google' }));
        });

        getIntegrationsDataPromise.then((res) => {
            if (res) {
                this.setState({ gooleID: res.data.data.key }, () => {
                    this.setState({ GoogleModal: true })
                });
            }
        });
    }
    OnMetaShow = () => {
        let path = API_Path.GetAnalytics;
        const getIntegrationsDataPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, { analytic: 'meta' }));
        });

        getIntegrationsDataPromise.then((res) => {
            if (res) {
                this.setState({ metaId: res.data.data.key }, () => {
                    this.setState({ MetaModal: true })
                });
            }
        });
    }
    OnSnapChatShow = () => {
        let path = API_Path.GetAnalytics;
        const getIntegrationsDataPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, { analytic: 'snapchat' }));
        });

        getIntegrationsDataPromise.then((res) => {
            if (res) {
                this.setState({ SanpchatId: res.data.data.key }, () => {
                    this.setState({ SnapChatModal: true })
                });
            }
        });
    }
    OnTikTokShow = () => {
        let path = API_Path.GetAnalytics;
        const getIntegrationsDataPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, { analytic: 'tiktok' }));
        });

        getIntegrationsDataPromise.then((res) => {
            if (res) {
                this.setState({ TiktokId: res.data.data.key }, () => {
                    this.setState({ TiktokModal: true })
                });
            }
        });
    }
    googleHide = () => {
        this.setState({ GoogleModal: false })
    }
    OnMetaHide = () => {
        this.setState({ MetaModal: false })
    }
    OnSnapChatHide = () => {
        this.setState({ SnapChatModal: false })
    }
    OnTiktokHide = () => {
        this.setState({ TiktokModal: false })
    }
    handleItegrationSubmit = (value) => {
        let Data
        switch (value) {
            case 'google':
                Data = {
                    analytic: value,
                    key: this.state.gooleID
                }
                break;
            case 'meta':
                Data = {
                    analytic: value,
                    key: this.state.metaId
                }
                break;
            case 'snapchat':
                Data = {
                    analytic: value,
                    key: this.state.SanpchatId
                }
                break;
            case 'tiktok':
                Data = {
                    analytic: value,
                    key: this.state.TiktokId
                }
                break;
            default:
                break;
        }
        new Promise((resolve) => {
            resolve(PostApi(API_Path.UpdateAnalytics, Data))
        }).then((res) => {
            if (res) {
                this.googleHide()
                this.OnMetaHide()
                this.OnSnapChatHide()
                this.OnTiktokHide()
            }
        })

    }
    // ========================= * ==========================
    handleImageChange = (e) => {
        var formData = new FormData;
        formData.append('file', e.target.files[0]);
        new Promise((resolve) => {
            resolve(PostApi(API_Path.addFileInS3, formData))
        }).then((res) => {
            if (res.data.success) {
                this.setState({ BannerImg: res.data.data[0] })
            }
        })
    }
    getAdminDetails = () => {
        new Promise((resolve) => {
            resolve(GetApi(API_Path.GetAdminDetail))
        }).then((res) => {
            if (res.data.success) {
                this.setState({ AdminDetails: res.data.data })
            }
        })
    }
    editAdminDetail = (id) => {
        for (let i = 0; i < this.state.AdminDetails.length; i++) {
            if (this.state.AdminDetails[i].id == id) {
                this.setState({ AdminName: this.state.AdminDetails[i].name, AdminPhone: '966' + this.state.AdminDetails[i].phone, adminId: id })
            }

        }
    }
    addAdminDetail = () => {
        let data = {
            phone: this.state.AdminPhone.replaceAll('966', ''),
            name: this.state.AdminName,
            id: this.state.adminId
        }
        new Promise((resolve) => {
            resolve(PostApi(API_Path.UpdateAdminDetail, data))
        }).then((res) => {
            if (res.data.success) {
                toastr.success(res.data.message)
                this.setState({ AdminName: '', AdminPhone: '966', adminId: '' })

                this.getAdminDetails()
            }
        })

    }
    deletAdmin = (id) => {
        let data = { id: id }
        new Promise((resolve) => {
            resolve(PostApi(API_Path.DeleteAdminDetail, data))
        }).then((res) => {
            if (res.data.success) {
                toastr.success(res.data.message)
                this.getAdminDetails()
            }
        })
    }
    render() {

        let settingLanguage = this.context.language === "english" ? settingEnglish : settingArabic;
        let ButtonLanguage = this.context.language === "english" ? buttonEnglish : buttonArabic;

        return (
            <Adminlayout>
                <div className="container-fluid">
                    <div className="row common-space align-items-center">
                        <div className="col-12 mb-3">
                            <div className="common-header-txt">
                                <h3>{settingLanguage.settings}</h3>
                            </div>
                        </div>
                        <div className="col-12 ">
                            <div className="row justify-content-center">
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0" onClick={this.offersettingmodal}>
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.offersettings}</div>
                                            <div className="ms-auto">
                                                <svg width="89" height="47" viewBox="0 0 89 47" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M22.9893 19.3207C22.9957 19.8274 23.1954 20.3134 23.5491 20.6832C23.9028 21.053 24.3849 21.2797 24.9006 21.3188C25.4164 21.358 25.9284 21.2067 26.336 20.8947C26.7436 20.5827 27.0173 20.1326 27.1032 19.6329C27.1104 19.529 27.1104 19.4247 27.1032 19.3207V15.2692C27.0968 14.7625 26.8972 14.2765 26.5435 13.9068C26.1898 13.537 25.7077 13.3103 25.1919 13.2711C24.6762 13.232 24.1642 13.3833 23.7566 13.6953C23.349 14.0073 23.0753 14.4574 22.9893 14.9571C22.9821 15.061 22.9821 15.1653 22.9893 15.2692V19.3207ZM4.17261 0H84.8282C85.934 0.00187593 86.994 0.433065 87.776 1.19911C88.5579 1.96515 88.9981 3.00359 89 4.08694V8.51445C89 8.95733 88.8209 9.38218 88.5019 9.69601C88.1829 10.0098 87.75 10.1871 87.2979 10.189H87.0517C86.4504 10.1896 85.8552 10.3072 85.3007 10.535C84.7462 10.7628 84.2434 11.0961 83.8214 11.5158C82.9516 12.367 82.4575 13.5186 82.4453 14.7229V14.8364C82.4461 15.4381 82.5694 16.0336 82.8082 16.588C83.047 17.1424 83.3964 17.6445 83.8359 18.0648L83.9156 18.1429C84.817 18.9441 85.9939 19.3825 87.211 19.3704H87.2907C87.5133 19.3694 87.7338 19.4115 87.9398 19.494C88.1458 19.5766 88.3332 19.6981 88.4912 19.8517C88.6493 20.0052 88.7749 20.1877 88.861 20.3888C88.947 20.5898 88.9918 20.8056 88.9928 21.0236V26.6289C88.9928 26.8479 88.9487 27.0647 88.8632 27.267C88.7777 27.4693 88.6523 27.6532 88.4942 27.808C88.3362 27.9628 88.1486 28.0856 87.942 28.1694C87.7355 28.2532 87.5142 28.2964 87.2907 28.2964H87.2038C85.953 28.2875 84.7478 28.7557 83.8431 29.6019C83.4044 30.0202 83.0549 30.5198 82.8149 31.0716C82.575 31.6234 82.4493 32.2164 82.4453 32.8161V32.9296C82.4595 34.1357 82.9531 35.2887 83.8214 36.1438C84.2439 36.5629 84.7468 36.8958 85.3012 37.1236C85.8556 37.3513 86.4505 37.4693 87.0517 37.4707H87.2762C87.4988 37.4679 87.7197 37.508 87.9265 37.5889C88.1332 37.6697 88.3216 37.7897 88.481 37.9419C88.6404 38.0941 88.7677 38.2756 88.8555 38.4759C88.9433 38.6763 88.9899 38.8917 88.9928 39.1097V42.9057C88.993 43.4424 88.885 43.9737 88.6749 44.4693C88.4649 44.9649 88.1569 45.4149 87.7687 45.7936L87.6456 45.9C86.8807 46.6045 85.8708 46.9977 84.8209 46.9998H4.17261C3.0775 47.0112 2.02158 46.601 1.23205 45.8574C0.446333 45.0904 0.00349206 44.0492 0.000774712 42.9625V39.1665C0.000774712 38.7242 0.180098 38.3001 0.499294 37.9874C0.818491 37.6747 1.25141 37.4991 1.70283 37.4991H1.94184C2.54309 37.4996 3.13855 37.384 3.69411 37.1588C4.24966 36.9335 4.75438 36.6031 5.17936 36.1864C6.04654 35.3335 6.54019 34.183 6.55549 32.9793V32.9225H6.51927C6.52118 32.3198 6.40152 31.7225 6.16715 31.1652C5.93278 30.6078 5.58833 30.1013 5.15357 29.6748C4.71882 29.2482 4.20232 28.91 3.63376 28.6795C3.06519 28.4491 2.45575 28.3309 1.84044 28.3318C1.39281 28.3244 0.966206 28.1444 0.653046 27.831C0.339885 27.5176 0.165389 27.0959 0.167359 26.6573L0.000774712 21.1016C-0.00597559 20.883 0.0314421 20.6652 0.110878 20.4608C0.190314 20.2564 0.310201 20.0693 0.463653 19.9104C0.617104 19.7515 0.801095 19.6239 1.00505 19.5349C1.20901 19.4458 1.42891 19.3972 1.65213 19.3917H1.7825C3.03724 19.4061 4.2482 18.9402 5.15763 18.0932L5.2373 18.0223C6.07883 17.1781 6.54942 16.0447 6.54824 14.8648V14.7442C6.54774 14.1435 6.42443 13.549 6.18559 12.9957C5.94675 12.4425 5.59723 11.9417 5.15763 11.5229L5.07072 11.4377C4.17227 10.6418 3.00102 10.2061 1.78974 10.2173H1.60867C1.17254 10.1972 0.761357 10.0122 0.461524 9.70125C0.16169 9.39032 -0.00345898 8.97764 0.000774712 8.54993V4.08694C0.00460813 3.00605 0.444613 1.97051 1.2248 1.20621C2.00557 0.437567 3.06572 0.00376284 4.17261 0ZM50.8233 33.4547C50.5663 33.8981 50.1874 34.2619 49.7297 34.5048C48.9997 34.8038 48.2087 34.9326 47.4192 34.8809C46.3401 34.8809 45.7968 34.5971 45.7968 34.0365C45.8075 33.949 45.8294 33.8632 45.862 33.7811L57.5664 13.4812C57.725 13.2022 57.9066 12.9364 58.1096 12.6865C58.3739 12.4471 58.6841 12.2614 59.0222 12.1402C59.5482 11.9408 60.1097 11.8467 60.6735 11.8635C62.0424 11.8635 62.7232 12.1544 62.7232 12.7362C62.7258 12.8369 62.7034 12.9367 62.658 13.0271L50.8233 33.4547ZM45.4709 24.2307C44.6186 24.2433 43.7678 24.1575 42.9359 23.9753C42.2169 23.7993 41.5386 23.4911 40.9369 23.0671C39.6815 22.1825 39.0538 20.4654 39.0538 17.9158C39.0538 15.3662 39.7153 13.7106 41.0383 12.9491C42.3805 12.1838 43.9196 11.8142 45.4709 11.8848C47.0304 11.8245 48.5759 12.1932 49.9325 12.9491C51.2507 13.7934 51.917 15.4537 51.917 17.9158C51.917 20.3779 51.2869 22.173 50.0266 23.0671C48.6644 23.9002 47.075 24.3062 45.4709 24.2307ZM45.4709 21.0875C45.5523 21.0894 45.6331 21.0732 45.7072 21.04C45.7812 21.0068 45.8465 20.9575 45.8982 20.8959C46.1807 20.5908 46.3256 19.8245 46.3256 18.597C46.3487 17.7482 46.3051 16.899 46.1952 16.0568C46.1689 15.7513 46.067 15.4566 45.8982 15.1983C45.8429 15.143 45.7762 15.0998 45.7025 15.0717C45.6288 15.0435 45.5499 15.0311 45.4709 15.0351C44.8915 15.0351 44.609 16.0426 44.609 18.0648C44.609 20.087 44.8915 21.0875 45.4709 21.0875ZM62.8536 35.2073C62.0037 35.2193 61.1553 35.1335 60.3259 34.9518C59.6068 34.7833 58.9279 34.4797 58.3268 34.0578C57.0763 33.1732 56.4486 31.4562 56.4437 28.9066C56.4437 26.4232 57.1028 24.7771 58.4282 23.9398C59.7601 23.153 61.3 22.7704 62.8536 22.84C64.4315 22.7704 65.9962 23.1499 67.3586 23.9327C68.6768 24.7558 69.3359 26.4019 69.3359 28.8995C69.3359 31.397 68.713 33.1567 67.4527 34.0507C66.0896 34.8878 64.4966 35.2941 62.8898 35.2144L62.8536 35.2073ZM62.8536 32.0711C62.9334 32.0736 63.013 32.0604 63.0876 32.0324C63.1623 32.0043 63.2304 31.962 63.2881 31.9079C63.5706 31.5815 63.7155 30.8081 63.7155 29.5735C63.7384 28.7248 63.6948 27.8756 63.5851 27.0334C63.5574 26.7281 63.4556 26.4337 63.2881 26.1748C63.2304 26.1207 63.1623 26.0784 63.0876 26.0504C63.013 26.0224 62.9334 26.0092 62.8536 26.0116C62.2814 26.0116 61.9989 27.0192 61.9989 29.0414C61.9989 31.0636 62.2814 32.0711 62.8536 32.0711ZM84.8282 3.34192H27.125V7.15923C27.1324 7.2608 27.1324 7.36277 27.125 7.46434C27.0392 7.96354 26.7661 8.41332 26.3592 8.72539C25.9524 9.03746 25.4411 9.18929 24.9259 9.15108C24.4106 9.11287 23.9285 8.88737 23.5743 8.51885C23.22 8.15032 23.0191 7.66539 23.0111 7.15923V3.34192H4.17986C4.07732 3.3355 3.97456 3.35053 3.87841 3.38601C3.78225 3.42149 3.6949 3.4766 3.62216 3.54769C3.55107 3.61589 3.49509 3.69771 3.4577 3.78805C3.42032 3.87839 3.40234 3.9753 3.40488 4.07275V7.02442C4.90395 7.31346 6.291 8.00639 7.41013 9.02532L7.51878 9.11756C8.28421 9.84328 8.89331 10.712 9.31006 11.6724C9.72682 12.6327 9.94275 13.6652 9.94511 14.7087V14.9003C9.93625 16.9548 9.10087 18.923 7.62018 20.3779L7.51878 20.4844C6.39434 21.5465 4.98103 22.2683 3.44834 22.5633L3.52801 25.1531C5.06453 25.4614 6.4763 26.201 7.5912 27.2817C8.34366 28.017 8.94028 28.8907 9.34674 29.8527C9.7532 30.8147 9.96148 31.8459 9.95959 32.8871C9.95959 32.8871 9.95959 32.9509 9.95959 32.9722C9.93963 35.046 9.09217 37.0299 7.59845 38.4995C6.46123 39.6215 5.00458 40.3807 3.41936 40.6778V42.9341C3.41581 43.0327 3.4333 43.131 3.47072 43.2226C3.50813 43.3143 3.56464 43.3973 3.63665 43.4663H3.62216C3.76566 43.603 3.95798 43.6793 4.15813 43.6791H22.9893V39.5638C22.9819 39.4622 22.9819 39.3603 22.9893 39.2587C23.0751 38.7595 23.3482 38.3097 23.7551 37.9977C24.1619 37.6856 24.6732 37.5338 25.1884 37.572C25.7037 37.6102 26.1858 37.8357 26.54 38.2042C26.8943 38.5727 27.0952 39.0577 27.1032 39.5638V43.6791H84.8064C84.984 43.6826 85.1567 43.622 85.2917 43.5088L85.3424 43.4592C85.4857 43.3176 85.5663 43.1264 85.5669 42.927V40.6991C83.9816 40.4065 82.5244 39.6494 81.3878 38.5279C79.8939 37.0613 79.0462 35.0795 79.0267 33.0077V32.8161C79.0319 31.7728 79.2506 30.741 79.6698 29.7819C80.0891 28.8228 80.7003 27.9557 81.4675 27.2321C82.5958 26.15 84.0195 25.4107 85.5669 25.1034V22.5633C84.0675 22.2837 82.6792 21.5951 81.5617 20.5766L81.453 20.4844C80.6924 19.7577 80.0878 18.8893 79.6749 17.9303C79.2619 16.9713 79.0489 15.9411 79.0484 14.9003V14.7016C79.0808 12.6449 79.9274 10.6809 81.4096 9.22399C82.5442 8.09728 84.0017 7.33512 85.5887 7.03861V4.08694C85.5782 3.90207 85.4986 3.72746 85.365 3.59654C85.2313 3.46563 85.0531 3.3876 84.8644 3.3774L84.8282 3.34192ZM22.9893 31.4893C22.9957 31.996 23.1954 32.482 23.5491 32.8518C23.9028 33.2215 24.3849 33.4483 24.9006 33.4874C25.4164 33.5265 25.9284 33.3752 26.336 33.0632C26.7436 32.7513 27.0173 32.3012 27.1032 31.8015C27.1104 31.6975 27.1104 31.5932 27.1032 31.4893V27.4378C27.0968 26.9311 26.8972 26.4451 26.5435 26.0753C26.1898 25.7056 25.7077 25.4788 25.1919 25.4397C24.6762 25.4006 24.1642 25.5519 23.7566 25.8638C23.349 26.1758 23.0753 26.6259 22.9893 27.1256C22.9819 27.2296 22.9819 27.3339 22.9893 27.4378V31.4893Z"
                                                        fill="#F4F4F4"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0" onClick={this.taxsettingmodal}>
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.taxsettings}</div>
                                            <div className="ms-auto">
                                                <svg width="80" height="73" viewBox="0 0 80 73" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        fill-rule="evenodd"
                                                        clip-rule="evenodd"
                                                        d="M79.9675 38.3528L57.1903 73L39.0466 61.2807L40.2505 58.7208L53.5459 67.232L53.7086 67.3433C54.0097 67.5336 54.3451 67.6622 54.6957 67.7217C55.0462 67.7812 55.405 67.7705 55.7515 67.6902C56.0979 67.61 56.4252 67.4616 56.7146 67.2538C57.0039 67.046 57.2496 66.7827 57.4376 66.4791L58.1729 65.3006H58.212L61.6416 59.6898L77.2602 36.5786L80 38.3397L79.9675 38.3528ZM21.5733 25.7039H15.7488L11.4862 10.0301H16.3735L16.8096 12.649L18.6122 21.3697H18.9051L21.1177 12.9109L21.5733 10.0301H26.2979L21.5733 25.7039ZM39.8601 25.7039H34.9728L34.5367 23.1178V23.0392L32.1744 22.9934L30.2221 23.0916L29.8121 25.7104H25.0484L29.773 10.0367H35.63L39.8926 25.7104L39.8601 25.7039ZM33.7948 19.5038L32.7341 14.4036H32.4412L31.0941 19.5365H32.4412H33.7948V19.5038ZM51.2096 10.3706L50.9493 13.906L47.767 13.7489H47.5067L47.3831 20.6037L47.5783 25.6908H42.7625L43.0033 21.1078L42.8537 13.7489H42.5413L39.3395 13.8929L39.0466 13.5656L39.3134 10.0301H50.9493L51.2096 10.3706ZM31.6212 54.5241L31.2373 54.1575L25.8358 59.7421C25.8074 59.7808 25.777 59.818 25.7447 59.8535C25.5931 60.0061 25.413 60.1272 25.2148 60.2098C25.0166 60.2924 24.8041 60.3349 24.5896 60.3349C24.3751 60.3349 24.1626 60.2924 23.9644 60.2098C23.7662 60.1272 23.5862 60.0061 23.4345 59.8535L17.7727 54.1575L11.9157 59.7487C11.6066 60.0427 11.1956 60.2038 10.7703 60.1977C10.3449 60.1916 9.93867 60.0187 9.63801 59.716L4.09989 54.0724L2.94151 55.3818C2.73824 55.6555 2.45521 55.8587 2.13181 55.963C1.8084 56.0674 1.46071 56.0677 1.13711 55.964C0.813508 55.8603 0.530087 55.6577 0.326284 55.3843C0.12248 55.111 0.00842918 54.7806 0 54.439L0 1.64332C0 1.20748 0.172095 0.789499 0.478426 0.481317C0.784758 0.173135 1.20023 0 1.63345 0L61.0884 0C61.3026 -1.72392e-06 61.5147 0.0425506 61.7125 0.125215C61.9104 0.20788 62.09 0.329029 62.2412 0.481712C62.3923 0.634394 62.512 0.815604 62.5934 1.01494C62.6748 1.21428 62.7162 1.42782 62.7154 1.64332V14.2006L61.9149 13.6834C61.5549 13.4487 61.15 13.2926 60.7263 13.2249C60.3026 13.1572 59.8695 13.1796 59.455 13.2906V3.27354H3.25388V50.2161C3.54333 50.0627 3.87205 50.0006 4.19711 50.038C4.52218 50.0753 4.82849 50.2104 5.07606 50.4256C5.10742 50.4507 5.13581 50.4792 5.16066 50.5108H5.20621L10.8419 56.3049L16.6989 50.7203C17.002 50.4208 17.4098 50.253 17.8345 50.253C18.2593 50.253 18.6671 50.4208 18.9701 50.7203L24.5863 56.3704L30.0203 50.7399C30.3147 50.4315 30.7178 50.2519 31.1426 50.2396C31.5675 50.2274 31.9801 50.3835 32.2915 50.6744L33.3198 51.6303L32.0182 53.5552C31.827 53.8543 31.6883 54.1843 31.6082 54.5307L31.6212 54.5241ZM39.1442 42.7394H12.4624C12.1431 42.7394 11.8368 42.6118 11.6111 42.3846C11.3853 42.1575 11.2584 41.8494 11.2584 41.5282C11.2584 41.2069 11.3853 40.8989 11.6111 40.6717C11.8368 40.4446 12.1431 40.317 12.4624 40.317H40.7321L39.1442 42.7394ZM44.4416 34.6996H12.0979C11.7786 34.6996 11.4724 34.5719 11.2466 34.3448C11.0208 34.1176 10.894 33.8096 10.894 33.4883C10.894 33.1671 11.0208 32.859 11.2466 32.6319C11.4724 32.4047 11.7786 32.2771 12.0979 32.2771H46.0294L44.4416 34.6996ZM77.8329 30.8761L55.0557 65.4708L36.886 53.7778L59.6632 19.1306L77.8264 30.8499L77.8329 30.8761ZM61.2251 40.3104C61.7093 41.1564 61.9333 42.1279 61.8687 43.102C61.8042 44.076 61.454 45.009 60.8625 45.7829C60.2709 46.5567 59.4646 47.1368 58.5454 47.4497C57.6262 47.7626 56.6355 47.7943 55.6984 47.5407C54.7613 47.2872 53.92 46.7598 53.2808 46.0253C52.6416 45.2908 52.2333 44.3821 52.1074 43.4141C51.9815 42.4461 52.1437 41.4623 52.5735 40.5871C53.0033 39.7118 53.6814 38.9844 54.5221 38.4969C55.0803 38.1721 55.6968 37.9614 56.3361 37.8768C56.9754 37.7922 57.6251 37.8354 58.2478 38.0039C58.8705 38.1723 59.454 38.4628 59.9649 38.8586C60.4758 39.2544 60.9041 39.7478 61.2251 40.3104ZM71.3251 34.9418L56.0514 57.8042C55.3382 57.3473 54.474 57.1933 53.6482 57.3762C52.8224 57.559 52.1023 58.0637 51.6457 58.7797L44.4871 54.1509C44.7129 53.7959 44.8669 53.3996 44.9403 52.9846C45.0138 52.5697 45.0052 52.1442 44.9152 51.7326C44.8251 51.321 44.6553 50.9313 44.4155 50.5857C44.1757 50.2401 43.8705 49.9454 43.5175 49.7186L58.7717 26.843C59.1237 27.0703 59.5168 27.2255 59.9285 27.2998C60.3402 27.3741 60.7624 27.366 61.1709 27.276C61.5795 27.1861 61.9665 27.0159 62.3096 26.7753C62.6528 26.5348 62.9455 26.2285 63.1709 25.8741L70.362 30.5029C70.1359 30.8575 69.9815 31.2535 69.9076 31.6682C69.8336 32.0829 69.8416 32.5082 69.9311 32.9197C70.0205 33.3313 70.1897 33.7212 70.4288 34.067C70.668 34.4128 70.9726 34.7078 71.3251 34.9352V34.9418Z"
                                                        fill="#F4F4F4"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0" onClick={this.paymentsettingmodal}>
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.paymentsettings}</div>
                                            <div className="ms-auto">
                                                <svg width="86" height="58" viewBox="0 0 86 58" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M76.8462 55.3077H9.15385C5.76923 55.3077 3 52.5385 3 49.1538V9.15385C3 5.76923 5.76923 3 9.15385 3H76.8462C80.2308 3 83 5.76923 83 9.15385V49.1538C83 52.5385 80.2308 55.3077 76.8462 55.3077Z"
                                                        stroke="#F4F4F4"
                                                        stroke-width="5"
                                                        stroke-miterlimit="10"
                                                        stroke-linecap="round"
                                                        strokeLinejoin="round"
                                                    />
                                                    <path d="M3 15.3076H83" stroke="#F4F4F4" stroke-width="5" stroke-miterlimit="10" stroke-linecap="round" strokeLinejoin="round" />
                                                    <path
                                                        d="M52.2308 43.0001C55.6294 43.0001 58.3846 40.2449 58.3846 36.8462C58.3846 33.4476 55.6294 30.6924 52.2308 30.6924C48.8321 30.6924 46.0769 33.4476 46.0769 36.8462C46.0769 40.2449 48.8321 43.0001 52.2308 43.0001Z"
                                                        stroke="#F4F4F4"
                                                        stroke-width="5"
                                                        stroke-miterlimit="10"
                                                        stroke-linecap="round"
                                                        strokeLinejoin="round"
                                                    />
                                                    <path
                                                        d="M64.5385 43.0001C67.9372 43.0001 70.6923 40.2449 70.6923 36.8462C70.6923 33.4476 67.9372 30.6924 64.5385 30.6924C61.1398 30.6924 58.3846 33.4476 58.3846 36.8462C58.3846 40.2449 61.1398 43.0001 64.5385 43.0001Z"
                                                        stroke="#F4F4F4"
                                                        stroke-width="5"
                                                        stroke-miterlimit="10"
                                                        stroke-linecap="round"
                                                        strokeLinejoin="round"
                                                    />
                                                    <path d="M15.3077 43H21.4616" stroke="#F4F4F4" stroke-width="5" stroke-miterlimit="10" stroke-linecap="round" strokeLinejoin="round" />
                                                    <path d="M15.3077 33.769H30.6924" stroke="#F4F4F4" stroke-width="5" stroke-miterlimit="10" stroke-linecap="round" strokeLinejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0" onClick={this.shippingsettingmodal}>
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.shippingsettings}</div>
                                            <div className="ms-auto">
                                                <svg width="80" height="86" viewBox="0 0 80 86" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M36.0722 4.03662C38.5602 2.65447 41.5858 2.65447 44.0742 4.03658L75.0274 21.2302C76.3353 21.9566 77.1463 23.3348 77.1463 24.8305V58.7461C77.1463 61.7374 75.5242 64.494 72.9089 65.9466L44.0742 81.9634C41.5858 83.3456 38.5602 83.3456 36.0722 81.9634L7.2375 65.9466C4.62207 64.494 3 61.7374 3 58.7461V24.8305C3 23.3348 3.81104 21.9566 5.11877 21.2302L36.0722 4.03662Z"
                                                        stroke="#F4F4F4"
                                                        stroke-width="5"
                                                        stroke-linecap="round"
                                                        strokeLinejoin="round"
                                                    />
                                                    <path d="M40.0732 43V80.0732M4.95123 23.4878L40.0732 43L4.95123 23.4878ZM40.0732 43L75.1951 23.4878L40.0732 43Z" stroke="#F4F4F4" stroke-width="5" strokeLinejoin="round" />
                                                    <path d="M22.5122 32.2681L57.6342 11.7803" stroke="#F4F4F4" stroke-width="5" stroke-linecap="round" strokeLinejoin="round" />
                                                    <path d="M14.7073 43.9756L28.3659 51.7805" stroke="#F4F4F4" stroke-width="5" stroke-linecap="round" strokeLinejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/* --- Warehouse registration card --- */}
                                {/* <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0" onClick={this.warehouseRegistrationModal}>
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.warehouseRegistration}</div>
                                            <div className="ms-auto">
                                                <svg width="80" height="86" viewBox="0 0 80 86" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M36.0722 4.03662C38.5602 2.65447 41.5858 2.65447 44.0742 4.03658L75.0274 21.2302C76.3353 21.9566 77.1463 23.3348 77.1463 24.8305V58.7461C77.1463 61.7374 75.5242 64.494 72.9089 65.9466L44.0742 81.9634C41.5858 83.3456 38.5602 83.3456 36.0722 81.9634L7.2375 65.9466C4.62207 64.494 3 61.7374 3 58.7461V24.8305C3 23.3348 3.81104 21.9566 5.11877 21.2302L36.0722 4.03662Z"
                                                        stroke="#F4F4F4"
                                                        stroke-width="5"
                                                        stroke-linecap="round"
                                                        strokeLinejoin="round"
                                                    />
                                                    <path d="M40.0732 43V80.0732M4.95123 23.4878L40.0732 43L4.95123 23.4878ZM40.0732 43L75.1951 23.4878L40.0732 43Z" stroke="#F4F4F4" stroke-width="5" strokeLinejoin="round" />
                                                    <path d="M22.5122 32.2681L57.6342 11.7803" stroke="#F4F4F4" stroke-width="5" stroke-linecap="round" strokeLinejoin="round" />
                                                    <path d="M14.7073 43.9756L28.3659 51.7805" stroke="#F4F4F4" stroke-width="5" stroke-linecap="round" strokeLinejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div> */}
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0">
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.notificationsettings}</div>
                                            <div className="ms-auto">
                                                <svg width="81" height="80" viewBox="0 0 81 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M30.272 69.2959C29.664 68.8853 28.8346 69.0427 28.4213 69.6519C27.4253 71.1226 25.7732 71.9999 24.0011 71.9999C21.0596 71.9999 18.6677 69.6078 18.6677 66.6665C18.6677 64.8944 19.545 63.2423 21.0157 62.2476C21.6251 61.8329 21.7851 61.0049 21.3717 60.3942C20.9596 59.7862 20.1302 59.6275 19.521 60.0383C17.3156 61.5316 16.0009 64.009 16.0009 66.6665C16.0009 71.0787 19.5889 74.6668 24.0011 74.6668C26.6586 74.6668 29.1373 73.3508 30.6293 71.1466C31.0414 70.5372 30.8814 69.708 30.272 69.2959Z"
                                                        fill="#F4F4F4"
                                                    />
                                                    <path
                                                        d="M53.3356 2.66406C46.9248 2.66406 40.8978 5.16009 36.3644 9.69368L23.1653 22.8927C22.6441 23.4142 22.6441 24.2581 23.1653 24.7781C23.6868 25.2995 24.5307 25.2995 25.0507 24.7781L38.2498 11.5791C42.2793 7.54955 47.6381 5.33087 53.3356 5.33087C59.0344 5.33087 64.3933 7.54955 68.4229 11.5791C72.451 15.6086 74.6698 20.9661 74.6698 26.6649C74.6698 32.3624 72.4511 37.7212 68.4229 41.7507L51.4501 58.7221C51.0434 59.1274 50.9433 59.7475 51.1994 60.2608C52.8262 63.5142 52.0274 70.0891 49.7261 72.3906L45.3353 76.7814L3.21918 34.6652L7.60995 30.2744C9.86878 28.0157 16.2409 27.2037 19.5557 28.7117L47.6793 56.8353C48.1993 57.3568 49.0434 57.3568 49.5647 56.8353C50.0847 56.3141 50.0847 55.47 49.5647 54.95L21.2798 26.6649C21.1784 26.5637 21.0612 26.4796 20.9331 26.4155C16.6503 24.2701 8.82859 25.2834 5.72458 28.3889L0.390951 33.7225C-0.130317 34.2439 -0.130317 35.0866 0.390951 35.6079L44.3925 79.6094C44.6525 79.8694 44.9939 80.0001 45.3352 80.0001C45.6764 80.0001 46.0179 79.8694 46.2779 79.6094L51.6113 74.276C54.5074 71.3799 55.5835 64.3769 53.9728 59.9701L70.3067 43.6363C74.8401 39.1028 77.3363 33.0759 77.3363 26.6651C77.3363 20.2542 74.8403 14.226 70.3067 9.69384C65.7746 5.16024 59.7477 2.66406 53.3356 2.66406Z"
                                                        fill="#F4F4F4"
                                                    />
                                                    <path
                                                        d="M78.4404 1.56005C76.3617 -0.520018 72.9761 -0.520018 70.8987 1.56005L69.1387 3.32012C68.6174 3.84013 68.6174 4.68423 69.1387 5.2055C69.6587 5.72551 70.5028 5.72551 71.024 5.2055L72.7841 3.44543C73.8227 2.4068 75.5162 2.4068 76.5549 3.44543C77.0589 3.94951 77.3363 4.61876 77.3363 5.33222C77.3363 6.04287 77.0589 6.71227 76.5549 7.21635L74.7964 8.97625C74.2749 9.49768 74.2749 10.3416 74.7964 10.863C75.0564 11.123 75.3978 11.2524 75.7391 11.2524C76.0805 11.2524 76.4205 11.123 76.6817 10.8618L78.4404 9.10313C79.4484 8.09513 80.0031 6.75633 80.0031 5.33237C80.0031 3.9067 79.4484 2.56665 78.4404 1.56005Z"
                                                        fill="#F4F4F4"
                                                    />
                                                    <path
                                                        d="M47.1833 14.6824C47.37 14.6824 47.5606 14.6424 47.7433 14.5583C51.2328 12.9409 55.3595 12.9289 58.8596 14.5251C59.5317 14.8304 60.3197 14.533 60.6264 13.8636C60.9305 13.1942 60.6358 12.4022 59.9664 12.0968C55.7583 10.1808 50.8114 10.1941 46.6206 12.1382C45.9526 12.4489 45.662 13.2424 45.9726 13.9103C46.1979 14.3957 46.6792 14.6824 47.1833 14.6824Z"
                                                        fill="#F4F4F4"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0" onClick={this.seosettingmodal}>
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.searchengineoptimization}</div>
                                            <div className="ms-auto">
                                                <svg width="80" height="59" viewBox="0 0 80 59" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M77.8669 50.6667H77.3336V5.33329C77.3336 2.40001 74.9336 0 72.0003 0H8.00002C5.06673 0 2.66672 2.40001 2.66672 5.33329V50.6667H2.13344C0.933283 50.6667 0 51.6001 0 52.8001V56.5334C0 57.7334 0.933283 58.6667 2.13329 58.6667H77.8667C79.0667 58.6667 80 57.7334 80 56.5334V52.8001C80.0002 51.6001 79.0669 50.6667 77.8669 50.6667ZM5.33329 5.33329C5.33329 3.86657 6.53329 2.66657 8.00002 2.66657H72.0001C73.4669 2.66657 74.6669 3.86657 74.6669 5.33329V50.6667H46.9334L46.6667 51.5999C46.6499 51.6167 46.6312 51.6354 46.6107 51.6554C46.4667 51.7957 46.2334 52 46.0001 52H35.3334C35.1334 52 35.0001 51.9667 34.9001 51.8999C34.8001 51.8332 34.7334 51.7332 34.6668 51.5999L34.4001 50.6667H5.33329V5.33329ZM77.3334 56.0001H2.66672V53.3334H32.6668C33.3335 54.1334 34.2668 54.6667 35.3335 54.6667H46.0001C47.0668 54.6667 48.0001 54.1334 48.6668 53.3334H77.3336V56.0001H77.3334Z"
                                                        fill="#F7F7F7"
                                                    />
                                                    <path
                                                        d="M72.0001 46.6669V6.66678C72.0001 5.86678 71.4668 5.3335 70.6668 5.3335H9.33328C8.53328 5.3335 8 5.86678 8 6.66678V46.6669C8 47.4669 8.53328 48.0001 9.33328 48.0001H70.6667C71.4668 48.0003 72.0001 47.4669 72.0001 46.6669ZM69.3334 45.3336H10.6667V8.00022H69.3336V45.3336H69.3334Z"
                                                        fill="#F7F7F7"
                                                    />
                                                    <path
                                                        d="M28 30.6666H25.8667C25.0667 30.6666 24.1334 30.2666 23.6 29.7333C23.0666 29.2 22.2667 29.2 21.7333 29.7333C21.1998 30.2666 21.2 31.0666 21.7333 31.6C22.8 32.6667 24.2666 33.3333 25.8666 33.3333H28C30.2667 33.3333 32 31.6 32 29.3333C32 27.0666 30.2667 25.3333 28 25.3333H26.6667H25.3334C24.5334 25.3333 24.0002 24.8 24.0002 24C24.0002 23.2 24.5334 22.6667 25.3334 22.6667H27.4667C28.2667 22.6667 29.2 23.0667 29.7334 23.6C30.2669 24.1333 31.0667 24.1333 31.6002 23.6C32.1334 23.0667 32.1334 22.2667 31.6002 21.7333C30.5334 20.6666 29.0669 20 27.4669 20H25.3336C23.0669 20 21.3336 21.7333 21.3336 24C21.3336 26.2667 23.0669 28 25.3336 28H26.6669H28.0002C28.8002 28 29.3334 28.5333 29.3334 29.3333C29.3334 30.1333 28.8 30.6666 28 30.6666Z"
                                                        fill="#F7F7F7"
                                                    />
                                                    <path
                                                        d="M36 33.3332H44C44.8 33.3332 45.3333 32.7999 45.3333 31.9999C45.3333 31.1999 44.8 30.6666 44 30.6666H37.3333V27.9999H41.3333C42.1333 27.9999 42.6666 27.4666 42.6666 26.6666C42.6666 25.8666 42.1333 25.3333 41.3333 25.3333H37.3333V22.6666H44C44.8 22.6666 45.3333 22.1333 45.3333 21.3333C45.3333 20.5333 44.8 20 44 20H36C35.2 20 34.6667 20.5333 34.6667 21.3333V32C34.6667 32.7999 35.2 33.3332 36 33.3332Z"
                                                        fill="#F7F7F7"
                                                    />
                                                    <path
                                                        d="M53.3334 33.3333C56.2667 33.3333 58.6667 30.9333 58.6667 28V25.3333C58.6667 22.4 56.2667 20 53.3334 20C50.4001 20 48.0001 22.4 48.0001 25.3333V28C48.0001 30.9333 50.4001 33.3333 53.3334 33.3333ZM50.6668 25.3333C50.6668 23.8666 51.8668 22.6666 53.3336 22.6666C54.8003 22.6666 56.0003 23.8666 56.0003 25.3333V28C56.0003 29.4667 54.8003 30.6667 53.3336 30.6667C51.8668 30.6667 50.6668 29.4667 50.6668 28V25.3333Z"
                                                        fill="#F7F7F7"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0">
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.brandsettings}</div>
                                            <div className="ms-auto">
                                                <svg width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M79.6756 68.1042C79.5747 61.6902 73.7715 56.0969 67.1623 56.0969H63.0032L72.2258 50.7758C72.5299 50.5992 72.753 50.3111 72.8446 49.9711C72.9363 49.6311 72.8885 49.2686 72.7118 48.9645L63.4162 32.8645L54.1206 16.7644L44.8249 0.664368C44.6483 0.360268 44.3575 0.137172 44.0188 0.0455438C43.6789 -0.0460846 43.3164 0.00172153 43.0109 0.178339L24.6109 10.8019C23.9748 11.1684 23.7583 11.9811 24.1248 12.6159L33.4205 28.7173L36.172 33.4833L31.7366 30.923L15.6353 21.6274C14.9979 21.2595 14.1878 21.4786 13.8213 22.1134L3.1977 40.5134C3.02241 40.8175 2.97461 41.1801 3.06491 41.5214C3.15521 41.8613 3.3783 42.1521 3.68373 42.3274L19.7851 51.6204L27.547 56.0969H19.9192H1.32795C0.594921 56.0969 0 56.6972 0 57.4302V78.6774C0 79.4117 0.594921 80 1.32795 80H19.9192H38.5105H57.1018H67.1623C73.8871 80 79.6769 74.6776 79.6769 68.334C79.6769 68.314 79.6769 68.2941 79.6769 68.2742C79.6769 68.2556 79.6769 68.2384 79.6769 68.2198C79.6769 68.2012 79.6769 68.1826 79.6769 68.164C79.6769 68.1441 79.6769 68.1242 79.6756 68.1042ZM18.5913 77.3441H2.6559V58.7528H18.5913V77.3441ZM69.7465 49.1425L63.6486 52.6628L64.4214 51.3256C64.788 50.6895 64.5702 49.8781 63.9354 49.5116L50.5856 41.8055L61.7788 35.3437L69.7465 49.1425ZM60.4509 33.0398L58.7431 34.0277L47.915 40.2704L47.8062 40.1894V40.1615C47.8062 40.1615 47.8354 40.1615 47.834 40.1615L40.7707 36.11L36.3831 28.5234L44.4332 23.8822L52.4832 19.2384L60.4509 33.0398ZM35.0552 26.2367L27.0875 12.4366L43.1875 3.14099L51.1552 16.941L43.1052 21.5889L35.0552 26.2367ZM6.16168 40.6874L15.4573 24.5874L29.2574 32.555L24.6095 40.6051L19.9617 48.6551L6.16168 40.6874ZM37.1826 77.3441H21.2472V58.7528H37.1826V77.3441ZM37.4043 55.6228C37.3167 55.7742 37.2676 56.0969 37.2436 56.0969H31.823C31.7659 56.0969 31.56 55.3493 31.1935 55.1381L22.2617 49.9817L26.9096 41.9317L31.5574 33.8817L39.136 38.2573L45.3574 41.8507L37.4043 55.6228ZM55.7738 77.3441H39.8385V58.7528H55.7738V77.3441ZM40.197 56.0969L47.6587 43.1773L61.4588 51.1463L58.8733 55.6228C58.7856 55.7729 58.7392 56.0969 58.7166 56.0969H57.1018H40.197ZM67.1623 77.3441H58.4297V58.7528H67.1623C72.3944 58.7528 76.9865 63.1669 77.021 68.2131C76.9878 73.1677 72.4874 77.3441 67.1623 77.3441Z"
                                                        fill="#F5F5F5"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0" onClick={this.statussettingmodal}>
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.storestatus}</div>
                                            <div className="ms-auto">
                                                <svg width="78" height="68" viewBox="0 0 78 68" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M17.2757 55.4347C8.60136 49.7555 3 41.1979 3 33.6905C3 20.932 19.1039 5.29492 38.9809 5.29492C47.1107 5.29492 54.657 7.90111 60.7251 11.9465"
                                                        stroke="#F4F4F4"
                                                        stroke-width="5.5"
                                                        stroke-linecap="round"
                                                        strokeLinejoin="round"
                                                    />
                                                    <path
                                                        d="M69.5154 19.9619C72.9812 24.3574 75 29.2199 75 33.6932C75 46.4519 58.8572 62.089 38.9802 62.089C35.4405 62.089 31.9824 61.5833 28.7498 60.6887"
                                                        stroke="#F4F4F4"
                                                        stroke-width="5.5"
                                                        stroke-linecap="round"
                                                        strokeLinejoin="round"
                                                    />
                                                    <path
                                                        d="M30.2899 42.3568C27.9755 40.0657 26.6802 36.9422 26.6919 33.6864C26.6763 26.8987 32.1687 21.3828 38.9603 21.3711C42.2278 21.3633 45.363 22.6587 47.6735 24.9692"
                                                        stroke="#F4F4F4"
                                                        stroke-width="5.5"
                                                        stroke-linecap="round"
                                                        strokeLinejoin="round"
                                                    />
                                                    <path d="M51.0764 35.8657C50.1662 40.8914 46.2335 44.8318 41.2079 45.7537" stroke="#F4F4F4" stroke-width="5.5" stroke-linecap="round" strokeLinejoin="round" />
                                                    <path d="M69.6784 3L8.32007 64.3582" stroke="#F4F4F4" stroke-width="5.5" stroke-linecap="round" strokeLinejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0">
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.refundreturns}</div>
                                            <div className="ms-auto">
                                                <svg width="68" height="80" viewBox="0 0 68 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M52.6479 67.1581H14.5878C10.7292 67.1581 7.02858 65.6253 4.30012 62.8968C1.57165 60.1683 0.0388184 56.4677 0.0388184 52.6091V14.549C0.0388184 10.6904 1.57165 6.98976 4.30012 4.2613C7.02858 1.53283 10.7292 0 14.5878 0H52.6479C56.5066 0 60.2071 1.53283 62.9356 4.2613C65.6641 6.98976 67.1969 10.6904 67.1969 14.549V52.6091C67.1969 56.4677 65.6641 60.1683 62.9356 62.8968C60.2071 65.6253 56.5066 67.1581 52.6479 67.1581ZM14.5878 5.81959C12.2726 5.81959 10.0523 6.73929 8.41519 8.37637C6.77811 10.0134 5.85841 12.2338 5.85841 14.549V52.6091C5.85841 54.9243 6.77811 57.1446 8.41519 58.7817C10.0523 60.4188 12.2726 61.3385 14.5878 61.3385H52.6479C54.9631 61.3385 57.1835 60.4188 58.8205 58.7817C60.4576 57.1446 61.3773 54.9243 61.3773 52.6091V14.549C61.3773 12.2338 60.4576 10.0134 58.8205 8.37637C57.1835 6.73929 54.9631 5.81959 52.6479 5.81959H14.5878Z"
                                                        fill="#F4F4F4"
                                                    />
                                                    <path
                                                        d="M52.6091 79.9999H14.549C10.6935 79.9896 6.99886 78.4535 4.27261 75.7273C1.54636 73.001 0.0102404 69.3064 0 65.4509V27.3908C0 26.619 0.306567 25.8789 0.85226 25.3332C1.39795 24.7875 2.13807 24.481 2.9098 24.481C3.68152 24.481 4.42164 24.7875 4.96733 25.3332C5.51302 25.8789 5.81959 26.619 5.81959 27.3908V65.4509C5.81959 67.7661 6.73929 69.9864 8.37637 71.6235C10.0134 73.2606 12.2338 74.1803 14.549 74.1803H52.6091C54.9243 74.1803 57.1446 73.2606 58.7817 71.6235C60.4188 69.9864 61.3385 67.7661 61.3385 65.4509V27.3908C61.3385 26.619 61.6451 25.8789 62.1908 25.3332C62.7364 24.7875 63.4766 24.481 64.2483 24.481C65.02 24.481 65.7601 24.7875 66.3058 25.3332C66.8515 25.8789 67.1581 26.619 67.1581 27.3908V65.4509C67.1581 69.3095 65.6253 73.0101 62.8968 75.7386C60.1683 78.467 56.4677 79.9999 52.6091 79.9999Z"
                                                        fill="#F4F4F4"
                                                    />
                                                    <path
                                                        d="M44.0737 45.5481H20.7953C20.2625 45.5278 19.7454 45.3614 19.3007 45.0672C18.856 44.773 18.5006 44.3623 18.2735 43.8798C18.0421 43.3556 17.9776 42.7729 18.0887 42.2107C18.1997 41.6485 18.4809 41.1341 18.8942 40.7372L27.5072 32.1242C27.7747 31.8497 28.0945 31.6315 28.4476 31.4826C28.8008 31.3336 29.1802 31.2568 29.5635 31.2568C29.9468 31.2568 30.3262 31.3336 30.6794 31.4826C31.0325 31.6315 31.3523 31.8497 31.6198 32.1242C32.1647 32.6698 32.4707 33.4094 32.4707 34.1805C32.4707 34.9516 32.1647 35.6911 31.6198 36.2367L27.9728 39.8837H41.3579V18.778C41.3579 18.0062 41.6644 17.2661 42.2101 16.7204C42.7558 16.1747 43.4959 15.8682 44.2677 15.8682C45.0394 15.8682 45.7795 16.1747 46.3252 16.7204C46.8709 17.2661 47.1775 18.0062 47.1775 18.778V42.6383C47.1728 43.0356 47.0878 43.4279 46.9277 43.7916C46.7676 44.1553 46.5356 44.4829 46.2457 44.7547C45.9558 45.0265 45.614 45.2369 45.2407 45.3732C44.8675 45.5095 44.4705 45.569 44.0737 45.5481Z"
                                                        fill="#F4F4F4"
                                                    />
                                                    <path
                                                        d="M29.7188 54.1608C28.949 54.1519 28.2123 53.8461 27.6625 53.3073L18.8943 44.6943C18.3494 44.1487 18.0433 43.4091 18.0433 42.638C18.0433 41.8669 18.3494 41.1273 18.8943 40.5817C19.1618 40.3072 19.4816 40.089 19.8347 39.9401C20.1879 39.7911 20.5673 39.7144 20.9506 39.7144C21.3339 39.7144 21.7133 39.7911 22.0664 39.9401C22.4196 40.089 22.7393 40.3072 23.0068 40.5817L31.6198 49.1947C32.1647 49.7403 32.4708 50.4799 32.4708 51.251C32.4708 52.0221 32.1647 52.7617 31.6198 53.3073C31.1053 53.8051 30.4327 54.107 29.7188 54.1608Z"
                                                        fill="#F4F4F4"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0" onClick={this.AdminModel}>
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.adminSetting}</div>
                                            <div className="ms-auto">
                                                <svg width="67" height="69" viewBox="0 0 67 69" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <mask id="path-1-inside-1_1_12" fill="white">
                                                        <path d="M37.6986 14.874C37.6064 13.228 35.8465 13.508 34.1293 13.508C35.3978 13.831 36.5978 14.2802 37.6986 14.874Z" />
                                                    </mask>
                                                    <path d="M37.6986 14.874L36.2744 17.5144L40.9938 20.06L40.6939 14.7063L37.6986 14.874ZM34.1293 13.508V10.508L33.3891 16.4153L34.1293 13.508ZM40.6939 14.7063C40.6392 13.7281 40.3003 12.682 39.4671 11.8471C38.6884 11.0668 37.7673 10.7656 37.1223 10.6342C36.4806 10.5034 35.8479 10.4894 35.3945 10.49C35.1555 10.4903 34.9145 10.4956 34.7092 10.4999C34.4931 10.5044 34.308 10.508 34.1293 10.508V16.508C34.3799 16.508 34.6254 16.5029 34.8345 16.4986C35.0546 16.494 35.2335 16.4902 35.4024 16.49C35.5691 16.4898 35.6937 16.4932 35.7902 16.4996C35.8878 16.5061 35.9266 16.5138 35.9243 16.5134C35.9228 16.5131 35.8427 16.4973 35.7185 16.4396C35.5879 16.379 35.404 16.2697 35.22 16.0853C35.0306 15.8955 34.8925 15.6774 34.806 15.4625C34.7236 15.2575 34.7067 15.1027 34.7033 15.0418L40.6939 14.7063ZM33.3891 16.4153C34.453 16.6861 35.4182 17.0526 36.2744 17.5144L39.1228 12.2337C37.7773 11.5079 36.3425 10.9758 34.8694 10.6008L33.3891 16.4153Z" fill="#F4F4F4" mask="url(#path-1-inside-1_1_12)" />
                                                    <path d="M22.2549 13.0289C18.9317 14.5221 16.2633 17.0233 14.5036 20.2516C13.6006 18.8574 13.5191 17.2353 14.0471 15.8094C14.7758 13.8413 16.6707 12.2489 19.3416 12.2489C20.4121 12.2489 21.4074 12.5357 22.2549 13.0289Z" stroke="#F4F4F4" stroke-width="3" />
                                                    <path d="M6.99569 21.1434L6.65823 20.1084H5.56958H2.47983C2.4772 20.1084 2.47477 20.1083 2.47253 20.1081V15.0083C2.47477 15.0081 2.4772 15.008 2.47983 15.008H5.57444H6.66911L7.00297 13.9655C7.23784 13.2322 7.54966 12.523 7.92497 11.8423L8.48223 10.8316L7.64811 10.0339L5.52645 8.00499L9.31984 4.38256L9.32057 4.38186C9.32102 4.38165 9.32166 4.38137 9.32251 4.38104C9.32787 4.37897 9.33738 4.37667 9.34915 4.37667C9.36063 4.37667 9.36902 4.37884 9.37348 4.38056C9.37551 4.38135 9.37659 4.38198 9.37699 4.38224L9.37855 4.3835L11.5676 6.47614L12.3338 7.20865L13.2801 6.7309C14.0004 6.36725 14.7489 6.06595 15.5254 5.83964L16.6058 5.52481V4.39955V1.50031C16.608 1.50011 16.6104 1.5 16.6131 1.5H22.0721C22.0739 1.5 22.0755 1.50004 22.077 1.50011V4.39969V5.52578L23.1583 5.84008C23.9366 6.0663 24.684 6.3673 25.4007 6.73022L26.3465 7.20917L27.1136 6.47747L29.3105 4.38216L29.3105 4.38217L29.3145 4.37832C29.3147 4.37824 29.3149 4.37816 29.3151 4.37808C29.3186 4.37671 29.3267 4.37449 29.3383 4.37449C29.3497 4.37449 29.3581 4.37665 29.3625 4.37836C29.3645 4.37914 29.3655 4.37974 29.3658 4.37993L29.3668 4.38078L29.367 4.38093L33.1559 8.00337L31.0345 10.0332L30.198 10.8336L30.5537 11.4737C29.8131 11.4457 29.0954 11.4644 28.3758 11.5202C26.3814 8.7589 23.0891 6.93677 19.3414 6.93677C13.3164 6.93677 8.30033 11.638 8.30033 17.5588C8.30033 20.9652 9.97748 23.9607 12.5249 25.8904C12.3929 26.5797 12.292 27.2866 12.2255 28.0107L11.5648 28.6432L9.38642 30.7289C9.38398 30.7309 9.37969 30.7338 9.37325 30.7363C9.36564 30.7393 9.35731 30.7409 9.34915 30.7409C9.33632 30.7409 9.32582 30.7384 9.31897 30.7357C9.31719 30.735 9.31592 30.7344 9.3151 30.734L5.52648 27.1115L7.64815 25.0824L8.4827 24.2843L7.92455 23.2734C7.55003 22.595 7.23666 21.8825 6.99569 21.1434ZM5.45802 27.177L5.45832 27.1767C5.45811 27.1769 5.458 27.177 5.45802 27.177Z" stroke="#F4F4F4" stroke-width="3" />
                                                    <path d="M55.4319 43.0302C55.4319 44.9052 54.4869 46.5977 52.9759 47.6968C50.3638 45.6825 47.3375 44.1829 44.069 43.3115C45.0075 41.5664 45.7637 39.6872 46.32 37.7482C47.1771 37.3307 48.1328 37.0905 49.1461 37.0905C52.6751 37.0905 55.4319 39.8197 55.4319 43.0302Z" stroke="#F4F4F4" stroke-width="3" />
                                                    <path d="M67.4568 40.1999C67.4649 40.2077 67.4686 40.2136 67.4699 40.2161L67.4725 45.8404C67.4716 45.8426 67.4686 45.8482 67.4609 45.8555L67.4555 45.8607L67.4501 45.8659C67.4476 45.8684 67.4376 45.8768 67.4173 45.8848C67.3968 45.8929 67.3716 45.8982 67.3447 45.8982H64.0048H62.91L62.5762 46.9408C62.3204 47.7397 61.9787 48.5122 61.5687 49.251L61.0064 50.2641L61.8446 51.0641L64.2109 53.3224C64.2111 53.3226 64.2113 53.3228 64.2115 53.323C64.2186 53.3299 64.2207 53.3345 64.2212 53.3357C64.2214 53.3362 64.2216 53.3367 64.2217 53.3372C64.2219 53.3379 64.222 53.3387 64.222 53.3398C64.222 53.3417 64.2217 53.3426 64.2214 53.3434C64.2211 53.3441 64.2194 53.3479 64.2131 53.3539L60.3257 57.0686C59.4357 55.0226 58.2669 53.1408 56.8731 51.4559C59.2922 49.4089 60.8508 46.4091 60.8508 43.0302C60.8508 36.7614 55.5363 31.7784 49.1461 31.7784C48.5387 31.7784 47.949 31.829 47.3779 31.92C47.4222 31.3007 47.4452 30.6816 47.4452 30.0653C47.4452 28.5032 47.2901 27.0066 46.9975 25.5852H52.0917C52.1481 25.5852 52.1837 25.6058 52.2022 25.6235C52.2101 25.6311 52.2135 25.6369 52.2146 25.6389V28.8314V29.9576L53.2961 30.2718C54.1452 30.5185 54.9584 30.8463 55.7365 31.2407L56.6828 31.7204L57.4503 30.9879L59.8197 28.7267L59.8197 28.7267L59.8231 28.7234C59.8426 28.7047 59.8785 28.6853 59.9321 28.6853C59.9875 28.6853 60.0251 28.7061 60.0432 28.7234L60.0456 28.7258L64.2079 32.7054L64.2105 32.7079C64.2169 32.714 64.2199 32.7185 64.2211 32.7207C64.2199 32.7226 64.2174 32.7261 64.2124 32.7309L64.2081 32.735L61.8436 34.995L61.0072 35.7945L61.5681 36.8065C61.9786 37.5472 62.3204 38.3198 62.5762 39.118L62.9102 40.1601H64.0046H67.3446C67.3995 40.1601 67.4365 40.1805 67.4568 40.1999Z" fill="#F5F5F5" fill-opacity="0.12" stroke="#F4F4F4" stroke-width="3" />
                                                    <path d="M3.81666 66.5542L3.81644 66.5539C3.38812 65.9832 3.28058 65.2633 3.51104 64.6099C3.51117 64.6096 3.51129 64.6092 3.51142 64.6089L4.90639 60.684C4.9064 60.684 4.90642 60.684 4.90643 60.6839C7.14797 54.379 12.9801 49.928 19.8556 49.0926C22.5609 51.6325 25.9342 53.2958 29.7872 53.2958C33.6432 53.2958 37.0144 51.6321 39.7211 49.0926C46.5923 49.928 52.4243 54.3789 54.6659 60.6829L56.0617 64.6114L56.0618 64.6116C56.2928 65.2614 56.1859 65.9817 55.7571 66.5555C55.3221 67.1343 54.6019 67.5 53.8089 67.5H5.7632C4.97244 67.5 4.25166 67.1341 3.81666 66.5542Z" stroke="#F4F4F4" stroke-width="3" />
                                                    <path d="M29.7872 46.8276C27.0477 46.8276 24.3164 44.9354 22.1851 41.6786C20.0775 38.458 18.7603 34.1778 18.7603 30.0653C18.7603 25.8528 20.1921 22.8267 22.2211 20.8537C24.2673 18.8639 27.0136 17.8541 29.7873 17.8561C32.5611 17.8581 35.3084 18.8719 37.3555 20.8636C39.3853 22.8384 40.8165 25.8627 40.8165 30.0653C40.8165 34.1778 39.4993 38.458 37.3915 41.6785C35.26 44.9351 32.5281 46.8276 29.7872 46.8276Z" stroke="#F4F4F4" stroke-width="3" />
                                                </svg>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0" onClick={this.chatModelopen}>
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.chatSetting}</div>
                                            <div className="ms-auto">
                                                <svg width="67" height="67" viewBox="0 0 67 67" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g clip-path="url(#clip0_3768_38393)">
                                                        <path d="M61.4166 19.4858V44.6667C61.4166 47.7375 58.9041 50.25 55.8333 50.25H16.75L5.58331 61.4167V11.1667C5.58331 8.09583 8.09581 5.58333 11.1666 5.58333H39.3625C39.195 6.47667 39.0833 7.42583 39.0833 8.375C39.0833 9.32417 39.195 10.2733 39.3625 11.1667H11.1666V44.6667H55.8333V22.0542C57.8991 21.6354 59.7975 20.7142 61.4166 19.4858ZM44.6666 8.375C44.6666 13.0092 48.4075 16.75 53.0416 16.75C57.6758 16.75 61.4166 13.0092 61.4166 8.375C61.4166 3.74083 57.6758 0 53.0416 0C48.4075 0 44.6666 3.74083 44.6666 8.375Z" fill="#F4F4F4" />
                                                    </g>
                                                    <path d="M18.7415 32.8182L18.9375 29.3665L16.0398 31.267L15 29.4602L18.0938 27.9091L15 26.358L16.0398 24.5511L18.9375 26.4517L18.7415 23H20.8125L20.625 26.4517L23.5227 24.5511L24.5625 26.358L21.4602 27.9091L24.5625 29.4602L23.5227 31.267L20.625 29.3665L20.8125 32.8182H18.7415Z" fill="#F4F4F4" />
                                                    <path d="M31.7727 32.8182L31.9688 29.3665L29.071 31.267L28.0312 29.4602L31.125 27.9091L28.0312 26.358L29.071 24.5511L31.9688 26.4517L31.7727 23H33.8438L33.6562 26.4517L36.554 24.5511L37.5938 26.358L34.4915 27.9091L37.5938 29.4602L36.554 31.267L33.6562 29.3665L33.8438 32.8182H31.7727Z" fill="#F4F4F4" />
                                                    <path d="M44.804 32.8182L45 29.3665L42.1023 31.267L41.0625 29.4602L44.1562 27.9091L41.0625 26.358L42.1023 24.5511L45 26.4517L44.804 23H46.875L46.6875 26.4517L49.5852 24.5511L50.625 26.358L47.5227 27.9091L50.625 29.4602L49.5852 31.267L46.6875 29.3665L46.875 32.8182H44.804Z" fill="#F4F4F4" />
                                                    <defs>
                                                        <clipPath id="clip0_3768_38393">
                                                            <rect width="67" height="67" fill="white" />
                                                        </clipPath>
                                                    </defs>
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0" onClick={this.bannerModel}>
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.othersettings}</div>
                                            <div className="ms-auto">
                                                <svg width="80" height="74" viewBox="0 0 80 74" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M44.2715 18.4083L35.2505 9.38429L36.8684 7.76292C37.6528 6.9768 37.6528 5.71573 36.8684 4.92962C36.084 4.1435 34.8256 4.1435 34.0412 4.92962L27.4225 11.5625L16.4731 0.589589C15.6887 -0.19653 14.4303 -0.19653 13.6459 0.589589C12.8614 1.37571 12.8614 2.63677 13.6459 3.42289L24.5953 14.3958L14.3649 24.6481L3.41556 13.6752C2.63112 12.8891 1.37276 12.8891 0.588325 13.6752C-0.196108 14.4613 -0.196108 15.7224 0.588325 16.5085L11.5377 27.4814L4.91905 34.1143C4.13462 34.9004 4.13462 36.1614 4.91905 36.9476C5.31127 37.3406 5.81788 37.5371 6.34084 37.5371C6.8638 37.5371 7.37041 37.3406 7.76263 36.9476L9.38052 35.3262L18.3852 44.3502C21.9478 47.9205 26.6381 49.7056 31.3283 49.7056C33.2567 49.7056 35.2015 49.378 37.0482 48.7721L42.196 53.931C43.1439 54.8645 44.3695 55.3394 45.6116 55.3394C46.8536 55.3394 48.0793 54.8645 49.0271 53.931L50.024 52.932L50.6287 53.5379C54.0115 56.9281 59.5026 56.9281 62.8855 53.5379L68.017 48.3954C69.831 46.5775 72.7889 46.5775 74.6193 48.3954C76.4333 50.2133 76.4333 53.1776 74.6193 55.0119L69.4878 60.1708C67.8535 61.8085 66.9547 63.9867 66.9547 66.3123C66.9547 68.6379 67.8535 70.8161 69.4878 72.4539C69.88 72.847 70.3866 73.0435 70.9096 73.0435C71.4325 73.0435 71.9391 72.847 72.3313 72.4539C73.1158 71.6678 73.1158 70.4067 72.3313 69.6206C71.4489 68.7362 70.9586 67.557 70.9586 66.3123C70.9586 65.0677 71.4489 63.8885 72.3313 63.0041L77.4629 57.8452C80.8457 54.4551 80.8457 48.9522 77.4629 45.5621C74.08 42.172 68.5889 42.172 65.2061 45.5621L60.0746 50.7046C58.2606 52.5225 55.3026 52.5225 53.4722 50.7046L52.8676 50.0987L53.8645 49.0996C54.7796 48.1825 55.2699 46.9706 55.2699 45.6767C55.2699 44.3829 54.7633 43.171 53.8645 42.2539L48.7166 37.095C50.7758 30.7405 49.3049 23.4689 44.2715 18.4083ZM21.2287 41.5169L12.2078 32.4765L32.4233 12.2176L41.4279 21.2416C47.0007 26.8263 47.0007 35.9158 41.4279 41.5005C35.8715 47.1016 26.8015 47.1016 21.2287 41.5169ZM51.0045 45.1035C51.217 45.3164 51.2497 45.5621 51.2497 45.6767C51.2497 45.8078 51.217 46.0534 51.0045 46.25L46.1835 51.0813C45.8567 51.4089 45.3501 51.4089 45.0232 51.0813L40.9213 46.9869C42.1143 46.25 43.2419 45.3819 44.2715 44.3502C45.3011 43.3184 46.1672 42.1883 46.9026 40.9928L51.0045 45.1035Z"
                                                        fill="#F4F4F4"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-12 mb-3">
                            <div className="common-header-txt">
                                <h3>{settingLanguage.importantpages}</h3>
                            </div>
                        </div>
                        <div className="col-12">
                            <div className="row justify-content-center">
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0" onClick={this.termsSettingModal}>
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.termsconditions}</div>
                                            <div className="ms-auto">
                                                <svg width="80" height="73" viewBox="0 0 80 73" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M72.9794 7.02773C68.4445 2.49558 62.4168 -0.000333066 56.007 3.33368e-08C50.0442 0.000333133 44.4134 2.16315 40.0056 6.11337C35.5997 2.16581 29.9716 0.00466341 24.0095 0.00466341C24.0088 0.00466341 24.0078 0.00466341 24.0068 0.00466341C17.5947 0.0053296 11.5666 2.50224 7.03408 7.03473C2.49824 11.5655 0 17.5896 0 23.9968C0 30.4047 2.49791 36.4294 7.03341 40.9616L7.60573 41.5338C7.60473 41.5888 7.60173 41.6438 7.60173 41.6991C7.60173 43.8022 8.42236 45.7782 9.90898 47.2588C11.2446 48.5942 12.9749 49.3897 14.8358 49.5399C14.8351 49.5832 14.8328 49.6262 14.8328 49.6698C14.8338 51.7716 15.6541 53.7466 17.1417 55.2302C18.6283 56.7152 20.6046 57.5329 22.7062 57.5329C22.7065 57.5329 22.7065 57.5329 22.7065 57.5329C22.7512 57.5329 22.7952 57.5303 22.8398 57.5296C22.9842 59.326 23.7371 61.0811 25.1071 62.4508C26.4444 63.7902 28.1763 64.5873 30.0389 64.7369C30.0383 64.7772 30.0359 64.8172 30.0359 64.8575C30.0359 66.9593 30.8559 68.9353 32.3422 70.4192C33.8271 71.9075 35.805 72.7273 37.911 72.7273C37.9113 72.7273 37.911 72.7273 37.9113 72.7273C40.0139 72.7273 41.9908 71.9098 43.4791 70.4242L48.6616 65.2392C49.4509 64.4514 50.0499 63.5244 50.4405 62.5141C51.4548 62.122 52.3805 61.5258 53.1668 60.7397C54.5914 59.317 55.4037 57.444 55.4713 55.4411C57.4753 55.3751 59.3492 54.5634 60.7712 53.1407C62.1258 51.788 62.9271 50.0295 63.0611 48.1392C63.0767 48.1392 63.0921 48.1395 63.1077 48.1395C65.1227 48.1392 67.1399 47.3751 68.6789 45.8455C69.2948 45.2292 69.7945 44.5284 70.1705 43.7703L72.9794 40.9639C82.34 31.6128 82.3404 16.3888 72.9794 7.02773ZM13.4419 43.7236C12.9002 43.1837 12.6015 42.4645 12.6015 41.6987C12.6015 40.9306 12.9012 40.2074 13.4439 39.6645L18.6237 34.4908C19.168 33.9468 19.891 33.6474 20.6596 33.6474C21.4262 33.6474 22.1462 33.9458 22.6902 34.4901C23.8105 35.6083 23.8111 37.4327 22.6969 38.5519L22.4065 38.8417C22.3785 38.869 22.3492 38.8947 22.3215 38.9227L17.5057 43.736C16.9651 44.2749 16.2474 44.5717 15.4834 44.5717H15.4831C14.7141 44.5717 13.9902 44.2716 13.4419 43.7236ZM22.7065 52.5364C21.9399 52.5364 21.2189 52.238 20.6749 51.695C20.1319 51.1534 19.833 50.4336 19.8326 49.6675C19.8323 48.8997 20.1319 48.1775 20.6766 47.6332L21.0309 47.2791C21.0359 47.2741 21.0412 47.2695 21.0462 47.2645L25.9001 42.4162C26.4387 41.8992 27.1417 41.6135 27.889 41.6135C28.6583 41.6135 29.3829 41.9136 29.9263 42.4545C31.0462 43.5747 31.0462 45.3991 29.9296 46.517L24.7384 51.6934C24.1955 52.2373 23.4738 52.5364 22.7065 52.5364ZM28.645 58.9203C27.5263 57.8021 27.5277 55.98 28.6466 54.8605L33.8298 49.6864C34.3754 49.1408 35.0991 48.8404 35.8664 48.8404C36.6307 48.8404 37.3503 49.1388 37.895 49.6838C38.438 50.2251 38.7369 50.9456 38.7373 51.7124C38.7376 52.4802 38.4386 53.2023 37.898 53.7433L32.7072 58.9246C32.1652 59.4692 31.4452 59.7687 30.6799 59.7687C29.9136 59.7684 29.1916 59.4679 28.645 58.9203ZM39.9439 66.8914C39.4013 67.433 38.6796 67.7311 37.9113 67.7311C37.1433 67.7311 36.4227 67.433 35.8794 66.8884C35.3354 66.3454 35.0361 65.6243 35.0361 64.8578C35.0361 64.091 35.3357 63.3698 35.8804 62.8256L41.0609 57.6482C41.6045 57.1049 42.3261 56.8058 43.0928 56.8058C43.8608 56.8058 44.5837 57.1056 45.127 57.6472C45.6697 58.1898 45.9687 58.911 45.9687 59.6781C45.9687 60.4439 45.6704 61.1634 45.1267 61.706L39.9439 66.8914ZM61.0718 42.3056L60.7771 42.0115C60.7765 42.0108 60.7761 42.0102 60.7758 42.0098L49.9795 31.2237C49.0029 30.2478 47.4206 30.2481 46.444 31.2241C45.468 32.2001 45.468 33.7816 46.4443 34.7573L57.2366 45.5397C57.2376 45.5407 57.2386 45.542 57.2396 45.543C57.7826 46.086 58.0812 46.8075 58.0806 47.5749C58.0799 48.3424 57.7803 49.0639 57.2349 49.6082C56.693 50.1508 55.9717 50.4492 55.2044 50.4492C54.4364 50.4492 53.7144 50.1501 53.1708 49.6068L42.3788 38.8221C41.4025 37.8468 39.8196 37.8468 38.8436 38.8221C37.8673 39.7981 37.8673 41.3796 38.8436 42.3553L49.6356 53.14C50.1779 53.682 50.4765 54.4038 50.4759 55.1719C50.4755 55.5806 50.3882 55.975 50.2269 56.3378C49.8435 55.522 49.3176 54.7699 48.6606 54.113C47.324 52.7793 45.5937 51.9858 43.7334 51.8369C43.7341 51.7946 43.7364 51.7523 43.7364 51.71C43.7358 49.6072 42.9151 47.6312 41.4285 46.1489C39.9419 44.662 37.9663 43.8432 35.866 43.8432C35.821 43.8432 35.7764 43.8459 35.7314 43.8465C35.5857 42.0495 34.8314 40.292 33.4591 38.919C32.1188 37.5846 30.3846 36.7908 28.5216 36.6439C28.5536 34.5861 27.7917 32.5198 26.2264 30.9573C24.7404 29.4696 22.7635 28.6502 20.6596 28.6502C18.5557 28.6502 16.5771 29.4693 15.0888 30.9566L9.90764 36.1316C9.81398 36.2252 9.72332 36.3208 9.63499 36.4181C6.63909 32.9675 4.99982 28.6089 4.99982 23.9972C4.99982 18.9244 6.97742 14.1554 10.5696 10.5679C14.1588 6.97843 18.931 5.00149 24.0075 5.00116C24.0085 5.00116 24.0085 5.00116 24.0095 5.00116C28.6206 5.00116 32.9788 6.63734 36.4324 9.62957L26.8327 19.2245C23.7635 22.2943 23.7625 27.2872 26.832 30.3554C29.9029 33.4205 34.8981 33.4202 37.9686 30.3537L47.6073 20.7168L65.1463 38.2468C65.687 38.7851 65.9856 39.5036 65.9866 40.2707C65.987 40.6428 65.916 41.0039 65.7833 41.3393C65.7713 41.367 65.7593 41.3943 65.7483 41.4223C65.6066 41.7497 65.4053 42.0508 65.1473 42.3086C64.021 43.4278 62.1931 43.4268 61.0718 42.3056ZM70.1325 36.7056C69.7605 35.9767 69.2738 35.3029 68.6782 34.7103L49.3759 15.4182C49.3756 15.4178 49.3749 15.4172 49.3746 15.4165C48.4609 14.5042 47.0176 14.4459 46.0363 15.2403C46.034 15.2423 46.0317 15.2436 46.0297 15.2456C45.987 15.2803 45.947 15.3192 45.9063 15.3569C45.8847 15.3772 45.8614 15.3959 45.84 15.4172L45.8397 15.4175L45.8394 15.4178L34.4338 26.8208C33.3125 27.9397 31.4875 27.9397 30.3669 26.8215C29.2469 25.702 29.2483 23.8782 30.3699 22.756L41.7495 11.3823C41.7592 11.373 41.7698 11.3647 41.7792 11.3554C41.7882 11.3464 41.7958 11.336 41.8048 11.327L42.5678 10.5642C46.16 6.97444 50.9332 4.99716 56.008 4.99682C61.0821 4.99649 65.854 6.97277 69.4438 10.5603C76.6182 17.7352 76.8476 29.2595 70.1325 36.7056Z"
                                                        fill="#F4F4F4"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0" onClick={this.privacyPolicySettingModal}>
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.privacypolicy}</div>
                                            <div className="ms-auto">
                                                <svg width="72" height="80" viewBox="0 0 72 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M59.2526 9.88C58.9326 9.88 58.6126 9.8 58.3326 9.64C50.6526 5.68 44.0126 4 36.0526 4C28.1326 4 20.6126 5.88 13.7726 9.64C12.8126 10.16 11.6126 9.8 11.0526 8.84C10.5326 7.88 10.8926 6.64 11.8526 6.12C19.2926 2.08 27.4526 0 36.0526 0C44.5726 0 52.0126 1.88 60.1726 6.08C61.1726 6.6 61.5326 7.8 61.0126 8.76C60.6526 9.48 59.9726 9.88 59.2526 9.88ZM2.01264 30.88C1.61264 30.88 1.21264 30.76 0.852636 30.52C-0.0673646 29.88 -0.267365 28.64 0.372635 27.72C4.33264 22.12 9.37264 17.72 15.3726 14.64C27.9326 8.16 44.0126 8.12 56.6126 14.6C62.6126 17.68 67.6526 22.04 71.6126 27.6C72.2526 28.48 72.0526 29.76 71.1326 30.4C70.2126 31.04 68.9726 30.84 68.3326 29.92C64.7326 24.88 60.1726 20.92 54.7726 18.16C43.2926 12.28 28.6126 12.28 17.1726 18.2C11.7326 21 7.17264 25 3.57264 30.04C3.25264 30.6 2.65264 30.88 2.01264 30.88ZM27.0126 79.16C26.4926 79.16 25.9726 78.96 25.6126 78.56C22.1326 75.08 20.2526 72.84 17.5726 68C14.8126 63.08 13.3726 57.08 13.3726 50.64C13.3726 38.76 23.5326 29.08 36.0126 29.08C48.4926 29.08 58.6526 38.76 58.6526 50.64C58.6526 51.76 57.7726 52.64 56.6526 52.64C55.5326 52.64 54.6526 51.76 54.6526 50.64C54.6526 40.96 46.2926 33.08 36.0126 33.08C25.7326 33.08 17.3726 40.96 17.3726 50.64C17.3726 56.4 18.6526 61.72 21.0926 66.04C23.6526 70.64 25.4126 72.6 28.4926 75.72C29.2526 76.52 29.2526 77.76 28.4926 78.56C28.0526 78.96 27.5326 79.16 27.0126 79.16ZM55.6926 71.76C50.9326 71.76 46.7326 70.56 43.2926 68.2C37.3326 64.16 33.7726 57.6 33.7726 50.64C33.7726 49.52 34.6526 48.64 35.7726 48.64C36.8926 48.64 37.7726 49.52 37.7726 50.64C37.7726 56.28 40.6526 61.6 45.5326 64.88C48.3726 66.8 51.6926 67.72 55.6926 67.72C56.6526 67.72 58.2526 67.6 59.8526 67.32C60.9326 67.12 61.9726 67.84 62.1726 68.96C62.3726 70.04 61.6526 71.08 60.5326 71.28C58.2526 71.72 56.2526 71.76 55.6926 71.76ZM47.6526 80C47.4926 80 47.2926 79.96 47.1326 79.92C40.7726 78.16 36.6126 75.8 32.2526 71.52C26.6526 65.96 23.5726 58.56 23.5726 50.64C23.5726 44.16 29.0926 38.88 35.8926 38.88C42.6926 38.88 48.2126 44.16 48.2126 50.64C48.2126 54.92 51.9326 58.4 56.5326 58.4C61.1326 58.4 64.8526 54.92 64.8526 50.64C64.8526 35.56 51.8526 23.32 35.8526 23.32C24.4926 23.32 14.0926 29.64 9.41264 39.44C7.85264 42.68 7.05264 46.48 7.05264 50.64C7.05264 53.76 7.33264 58.68 9.73264 65.08C10.1326 66.12 9.61264 67.28 8.57264 67.64C7.53264 68.04 6.37264 67.48 6.01264 66.48C4.05264 61.24 3.09264 56.04 3.09264 50.64C3.09264 45.84 4.01264 41.48 5.81263 37.68C11.1326 26.52 22.9326 19.28 35.8526 19.28C54.0526 19.28 68.8526 33.32 68.8526 50.6C68.8526 57.08 63.3326 62.36 56.5326 62.36C49.7326 62.36 44.2126 57.08 44.2126 50.6C44.2126 46.32 40.4926 42.84 35.8926 42.84C31.2926 42.84 27.5726 46.32 27.5726 50.6C27.5726 57.44 30.2126 63.84 35.0526 68.64C38.8526 72.4 42.4926 74.48 48.1326 76.04C49.2126 76.32 49.8126 77.44 49.5326 78.48C49.3326 79.4 48.4926 80 47.6526 80Z"
                                                        fill="#F4F4F4"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0" onClick={this.returnSettingModal}>
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.ReturnRefundpolicy}</div>
                                            <div className="ms-auto">
                                                <svg width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M53.5579 22.7334H24.8415C24.8415 22.7334 24.8415 22.7334 24.8178 22.7334H20.4675C17.4485 22.7334 15 25.1819 15 28.2009V48.0504C15 51.0694 17.4485 53.5179 20.4675 53.5179H24.8178H53.5579H57.9081C60.9271 53.5179 63.3756 51.0694 63.3756 48.0504V28.2009C63.3756 25.1819 60.9271 22.7334 57.9081 22.7334H53.5579ZM59.8099 33.6447V42.5829C55.6973 42.773 52.3455 45.9109 51.8225 49.9283H26.5531C26.0301 45.9109 22.6783 42.773 18.5658 42.5829V33.6447C22.6783 33.4545 26.0301 30.3166 26.5531 26.2992H51.8225C52.3455 30.3166 55.6973 33.4545 59.8099 33.6447ZM20.4675 26.2992H22.9398C22.4643 28.3435 20.7052 29.8887 18.5658 30.0789V28.2009C18.5658 27.155 19.4216 26.2992 20.4675 26.2992ZM18.5658 48.0266V46.1486C20.7052 46.315 22.4643 47.884 22.9398 49.9283H20.4675C19.4216 49.9283 18.5658 49.0726 18.5658 48.0266ZM57.9319 49.9283H55.4596C55.9351 47.884 57.6942 46.3388 59.8336 46.1486V48.0266C59.8099 49.0726 58.9778 49.9283 57.9319 49.9283ZM59.8099 28.1771V30.0551C57.6704 29.8887 55.9113 28.3198 55.4358 26.2754H57.9081C58.9778 26.2992 59.8099 27.155 59.8099 28.1771Z"
                                                        fill="#F4F4F4"
                                                    />
                                                    <path
                                                        d="M39.1998 45.8871C43.4787 45.8871 46.9732 42.3926 46.9732 38.1137C46.9732 33.8348 43.4787 30.3403 39.1998 30.3403C34.9208 30.3403 31.4264 33.8348 31.4264 38.1137C31.4264 42.3926 34.8971 45.8871 39.1998 45.8871ZM39.1998 33.9061C41.5294 33.9061 43.4074 35.7841 43.4074 38.1137C43.4074 40.4433 41.5294 42.3213 39.1998 42.3213C36.8701 42.3213 34.9922 40.4433 34.9922 38.1137C34.9922 35.7841 36.8701 33.9061 39.1998 33.9061Z"
                                                        fill="#F4F4F4"
                                                    />
                                                    <path
                                                        d="M39.9842 80C50.6577 80 60.6894 75.8399 68.2489 68.2805C75.2615 61.2678 79.3978 51.9493 79.897 42.0364C79.9446 41.0618 79.1839 40.206 78.2092 40.1585C77.2346 40.1109 76.3788 40.8716 76.3313 41.8463C75.8796 50.8558 72.0999 59.3423 65.7053 65.7369C58.8352 72.607 49.6831 76.4105 39.9604 76.4105C30.2377 76.4105 21.0856 72.6307 14.2155 65.7369C0.0237687 51.5451 0.0237687 28.439 14.2155 14.2472C26.3154 2.14733 45.1427 0.126729 59.4533 9.23133L55.4359 14.1521L66.9652 12.9873L65.8004 1.45795L61.7354 6.45003C45.9747 -3.81939 25.0793 -1.65616 11.6957 11.7274C-3.89858 27.3217 -3.89858 52.6624 11.6957 68.2567C19.2789 75.8399 29.3106 80 39.9842 80Z"
                                                        fill="#F4F4F4"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0" onClick={this.faqsettingmodal}>
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.Faqsettings}</div>
                                            <div className="ms-auto">
                                                <svg width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M43.6843 59.2096C43.0255 59.2096 42.3814 59.0142 41.8332 58.6482C41.2855 58.2821 40.8586 57.7619 40.6063 57.1529C40.354 56.5443 40.2882 55.8745 40.4166 55.2281C40.5454 54.5818 40.8626 53.9883 41.3286 53.5223C41.7946 53.0563 42.3881 52.7387 43.0344 52.6103C43.6807 52.482 44.3506 52.5477 44.9592 52.8C45.5682 53.0523 46.0884 53.4792 46.4544 54.027C46.8205 54.5751 47.0159 55.2192 47.0159 55.878C47.0044 56.758 46.6499 57.5989 46.0275 58.2213C45.4052 58.8436 44.5643 59.1981 43.6843 59.2096Z"
                                                        fill="#F4F4F4"
                                                    />
                                                    <path
                                                        d="M42.7516 48.1484C41.8681 48.1484 41.0205 47.7974 40.396 47.1724C39.7709 46.5478 39.42 45.7003 39.42 44.8167C39.42 43.9332 39.7709 43.0856 40.396 42.461C41.0205 41.836 41.8681 41.4851 42.7516 41.4851C44.7982 41.3336 46.7114 40.4136 48.108 38.9099C49.5042 37.4063 50.2803 35.4299 50.2803 33.3781C50.2803 31.3262 49.5042 29.3499 48.108 27.8463C46.7114 26.3426 44.7982 25.4227 42.7516 25.2711C39.7079 24.8932 36.633 25.6698 34.1338 27.4478C33.1801 28.4369 32.4493 29.6184 31.9896 30.9132C31.5298 32.208 31.3521 33.586 31.4685 34.9551C31.4685 35.8386 31.1176 36.6862 30.4925 37.3108C29.868 37.9358 29.0204 38.2867 28.1369 38.2867C27.2533 38.2867 26.4059 37.9358 25.7811 37.3108C25.1563 36.6862 24.8053 35.8386 24.8053 34.9551C24.6344 32.6043 24.9881 30.245 25.8409 28.0478C26.6936 25.8506 28.024 23.8703 29.736 22.2504C33.5208 19.3084 38.2944 17.94 43.0626 18.4301C44.9741 18.4533 46.862 18.8535 48.6184 19.6078C50.3749 20.362 51.9652 21.4556 53.2983 22.8257C54.6314 24.1958 55.6806 25.8155 56.3865 27.5921C57.0924 29.3685 57.4402 31.2667 57.4109 33.1782C57.4344 35.1243 57.0737 37.0562 56.3487 38.8629C55.6242 40.6695 54.5505 42.3153 53.1886 43.7062C51.8266 45.0966 50.2039 46.2049 48.4128 46.9672C46.6221 47.7295 44.6982 48.131 42.7516 48.1484Z"
                                                        fill="#F4F4F4"
                                                    />
                                                    <path
                                                        d="M40.886 77.7313C34.6941 77.6873 28.6021 76.1641 23.1173 73.2891C22.7079 73.1008 22.341 72.8311 22.0387 72.4966C21.7365 72.1621 21.5053 71.7699 21.359 71.3435C21.2128 70.9174 21.1546 70.4657 21.188 70.0161C21.2213 69.5666 21.3456 69.1286 21.5531 68.7283C21.7607 68.3285 22.0473 67.9745 22.3956 67.6884C22.7439 67.4024 23.1466 67.19 23.5794 67.0639C24.0122 66.9377 24.466 66.9013 24.9134 66.9555C25.3609 67.0101 25.7925 67.1549 26.1824 67.381C32.584 70.6691 39.8936 71.7468 46.9718 70.4461C52.6316 69.3227 57.8854 66.6996 62.1841 62.8504C66.4828 59.0017 69.6687 54.0687 71.4083 48.567C73.1483 43.0658 73.378 37.1977 72.0737 31.577C70.7695 25.9564 67.9794 20.7894 63.9947 16.6161C60.0101 12.4429 54.9775 9.4168 49.423 7.85422C43.8685 6.29163 37.9964 6.24997 32.4206 7.73361C26.8444 9.21721 21.7693 12.1716 17.7259 16.2879C13.6825 20.4042 10.8192 25.5312 9.43539 31.1328C7.45986 39.4432 8.81513 48.1966 13.2113 55.5204C13.6289 56.2627 13.7466 57.1365 13.54 57.9627C13.3335 58.7885 12.8185 59.5041 12.1007 59.9626C11.3586 60.3801 10.4847 60.4979 9.65861 60.2913C8.83245 60.0847 8.11677 59.5699 7.65852 58.852C4.41425 53.4876 2.51877 47.417 2.13452 41.1601C1.75023 34.9029 2.88859 28.6457 5.45204 22.9249C8.01554 17.204 11.9277 12.1899 16.8534 8.31207C21.779 4.43427 27.5715 1.80836 33.7341 0.659385C43.8721 -1.23152 54.3459 0.982288 62.8518 6.81377C71.3572 12.6452 77.1978 21.6168 79.0888 31.7547C80.9799 41.8927 78.7659 52.3664 72.9346 60.8719C67.1029 69.3778 58.1315 75.2184 47.9935 77.1094C45.6458 77.5145 43.2684 77.7229 40.886 77.7313Z"
                                                        fill="#F4F4F4"
                                                    />
                                                    <path
                                                        d="M6.45909 79.998C5.39412 80.0233 4.34003 79.779 3.39509 79.2868C2.45019 78.7951 1.64527 78.0719 1.05539 77.1848C0.46547 76.2977 0.109873 75.276 0.021651 74.2143C-0.0665264 73.1526 0.115559 72.086 0.550982 71.1136L7.34753 55.9214C7.71872 55.1329 8.38402 54.5212 9.20085 54.2178C10.0176 53.9139 10.921 53.9424 11.717 54.2968C12.5131 54.6513 13.1386 55.3034 13.4595 56.1137C13.7803 56.924 13.7709 57.8275 13.4333 58.6311L7.12542 73.1126L23.4282 67.2933C23.8476 67.1094 24.3003 67.0135 24.7583 67.0126C25.2162 67.0113 25.6695 67.1046 26.0898 67.2862C26.5101 67.4679 26.8884 67.7345 27.2011 68.069C27.5137 68.4035 27.754 68.7988 27.9073 69.2306C28.0601 69.6624 28.1227 70.1208 28.0907 70.5775C28.0587 71.0346 27.9326 71.4797 27.7207 71.8857C27.5088 72.2917 27.2156 72.6493 26.8592 72.9371C26.5028 73.2246 26.0909 73.4356 25.6493 73.5568L8.54692 79.6426C7.87859 79.8878 7.17091 80.0082 6.45909 79.998Z"
                                                        fill="#F4F4F4"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0">
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.CompanyDetails}</div>
                                            <div className="ms-auto">
                                                <svg width="80" height="69" viewBox="0 0 80 69" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M8.42269 0H49.3445C50.4498 0 51.3463 0.897068 51.3463 2.003V6.77036H58.0117C66.578 6.77036 73.5792 13.7756 73.5792 22.3478V64.482H78.0253C80.6582 64.482 80.6582 68.4871 78.0253 68.4871C52.6758 68.4871 27.3252 68.4871 1.97466 68.4871C-0.658222 68.4871 -0.658222 64.482 1.97466 64.482H6.42085V2.003C6.42085 0.897068 7.31739 0 8.42269 0ZM56.4755 27.1344C53.8436 27.1344 53.8436 23.1293 56.4755 23.1293H64.4463C67.0782 23.1293 67.0782 27.1344 64.4463 27.1344H56.4755ZM56.4755 47.1567C53.8436 47.1567 53.8436 43.1517 56.4755 43.1517H64.4463C67.0782 43.1517 67.0782 47.1567 64.4463 47.1567H56.4755ZM56.4755 33.8085C53.8436 33.8085 53.8436 29.8034 56.4755 29.8034H64.4463C67.0782 29.8034 67.0782 33.8085 64.4463 33.8085H56.4755ZM56.4755 40.4826C53.8436 40.4826 53.8436 36.4776 56.4755 36.4776H64.4463C67.0782 36.4776 67.0782 40.4826 64.4463 40.4826H56.4755ZM18.8811 24.8263H38.886C41.7565 24.8263 44.096 27.1671 44.096 30.0383C44.096 32.9105 41.7565 35.2513 38.886 35.2513H18.8811C16.0145 35.2513 13.6711 32.9047 13.6711 30.0393C13.6711 27.1777 16.0212 24.8263 18.8811 24.8263ZM38.886 28.8313H18.8811C18.2126 28.8313 17.6739 29.3703 17.6739 30.0383C17.6739 30.7015 18.2164 31.2463 18.8811 31.2463H38.886C39.546 31.2463 40.0933 30.6986 40.0933 30.0393C40.0933 29.379 39.546 28.8313 38.886 28.8313ZM32.5208 64.482V54.4613H25.2464V64.482H32.5208ZM21.2437 64.482V52.4583C21.2437 51.3523 22.1393 50.4562 23.2446 50.4562H34.5226C35.6279 50.4562 36.5235 51.3523 36.5235 52.4583V64.482H47.3436V4.00504H10.4236V64.482H21.2437ZM18.8811 10.7427H38.886C41.7565 10.7427 44.096 13.0835 44.096 15.9557C44.096 18.8269 41.7565 21.1677 38.886 21.1677H18.8811C16.0145 21.1677 13.6711 18.8211 13.6711 15.9557C13.6711 13.0941 16.0212 10.7427 18.8811 10.7427ZM38.886 14.7477H18.8811C18.2126 14.7477 17.6739 15.2867 17.6739 15.9557C17.6739 16.6189 18.2164 17.1627 18.8811 17.1627H38.886C39.546 17.1627 40.0933 16.616 40.0933 15.9557C40.0933 15.2954 39.546 14.7477 38.886 14.7477ZM51.3463 10.7754V64.482H69.5764V22.3478C69.5764 15.9874 64.3674 10.7754 58.0117 10.7754H51.3463Z"
                                                        fill="#F4F4F4"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-12 mb-3">
                            <div className="common-header-txt">
                                <h3>{settingLanguage.Integrations}</h3>
                            </div>
                        </div>
                        <div className="col-12">
                            <div className="row justify-content-center">
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0" onClick={this.googleShow}>
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.Googlesettings}</div>
                                            <div className="ms-auto">
                                                <svg width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M79.8463 36.517C79.4995 33.907 77.1653 31.8625 74.5325 31.8625H44.8086C42.1078 31.8625 39.9106 34.0597 39.9106 36.7605V43.7905C39.9106 46.4912 42.1078 48.6884 44.8086 48.6884H59.4853C59.9936 48.6884 60.2439 48.8703 60.272 48.9309C60.2744 48.9414 60.2739 48.9861 60.248 49.0634C58.5452 52.8531 55.808 56.0887 52.3297 58.4227C52.3295 58.4227 52.3294 58.4228 52.3292 58.423C48.663 60.8823 44.3997 62.1822 40.0003 62.1822C30.8897 62.1822 22.5727 56.4536 19.3042 47.9269C19.3041 47.9266 19.3041 47.9263 19.3039 47.9258C18.3183 45.3533 17.8184 42.6866 17.8184 40C17.8184 37.2789 18.3278 34.5858 19.3325 31.9955C19.333 31.9942 19.3333 31.9928 19.3337 31.9916C22.6741 23.3816 30.7853 17.8184 39.9994 17.8184C44.4383 17.8184 48.7281 19.1392 52.4055 21.6383C52.4119 21.6425 52.4181 21.6469 52.4245 21.6512L52.5372 21.7255C52.5469 21.7317 52.5564 21.738 52.5662 21.7441C53.5159 22.3417 54.5928 22.6577 55.6802 22.6577C57.1173 22.6577 58.4303 22.0992 59.3753 21.0877L65.1786 14.8964C66.0959 13.9144 66.5297 12.6311 66.3684 11.3759C66.2134 10.1698 65.5208 9.0775 64.4594 8.35656C64.4317 8.33203 64.4033 8.30859 64.3739 8.28609C57.3328 2.86531 48.9041 0 39.9997 0C25.1687 0 11.6275 8.14688 4.65969 21.2617C4.65875 21.2636 4.65812 21.2653 4.65703 21.267C1.61047 27.0041 0 33.4817 0 40.0003C0 46.5531 1.62484 53.0589 4.69859 58.8152C4.69875 58.8155 4.69891 58.8159 4.69922 58.8164C11.6789 71.883 25.205 80 39.9994 80C49.5231 80 58.7539 76.5875 65.9925 70.3906C65.9945 70.3891 65.9964 70.3877 65.9984 70.3861C74.8966 62.7656 79.9997 51.6903 79.9997 40C79.9997 37.6986 79.8525 36.5642 79.8463 36.517ZM39.9997 3.26531C48.1547 3.26531 55.8739 5.88125 62.3288 10.8322C62.3288 10.8322 62.5064 10.9716 62.5827 11.0297C62.9181 11.2856 63.0927 11.5 63.1303 11.7919C63.1677 12.0836 63.0478 12.3947 62.7948 12.6656L56.9916 18.8569C56.578 19.2997 56.0505 19.3925 55.6808 19.3925C55.2212 19.3925 54.7381 19.2492 54.3187 18.9888L54.2314 18.9311C50.013 16.067 45.0919 14.5533 39.9998 14.5533C34.768 14.5533 29.7436 16.1325 25.4697 19.1205C21.9037 21.6136 19.0658 24.9313 17.1702 28.8006L8.19734 21.6145C14.7661 10.2612 26.8292 3.26531 39.9997 3.26531ZM3.26531 40.0003C3.26531 34.6756 4.43766 29.3823 6.66484 24.5705L15.8783 31.9492C14.9986 34.5672 14.5534 37.2697 14.5534 40C14.5534 42.6986 14.9908 45.3758 15.8548 47.975L6.68891 55.4861C4.44594 50.6606 3.26531 45.3484 3.26531 40.0003ZM39.9994 76.7347C26.8587 76.7347 14.8069 69.7603 8.22984 58.4448L17.1427 51.1411C19.0305 55.0206 21.8639 58.3487 25.4305 60.8523C29.7128 63.8586 34.7509 65.4477 40.0005 65.4477C44.6481 65.4477 49.1625 64.1845 53.1311 61.7833L62.3344 69.1542C55.9416 74.0555 48.085 76.7347 39.9994 76.7347ZM64.8795 67.0089L55.9172 59.8311C59.0828 57.292 61.5987 54.0495 63.2527 50.3436C63.2647 50.3167 63.2759 50.2894 63.2864 50.2619C63.7102 49.1553 63.5911 47.9944 62.9598 47.077C62.2473 46.0412 60.9484 45.423 59.4853 45.423H44.8086C43.9083 45.423 43.1759 44.6906 43.1759 43.7903V36.7603C43.1759 35.86 43.9083 35.1277 44.8086 35.1277H74.5323C75.51 35.1277 76.4806 35.978 76.6089 36.943C76.61 36.9528 76.7342 37.9483 76.7342 39.9998C76.7344 50.2862 72.4287 60.0525 64.8795 67.0089Z"
                                                        fill="#F4F4F4"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0" onClick={this.OnMetaShow}>
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.Metasettings}</div>
                                            <div className="ms-auto">
                                                <svg width="80" height="54" viewBox="0 0 80 54" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        fill-rule="evenodd"
                                                        clip-rule="evenodd"
                                                        d="M8.64098 35.0424C8.64098 38.0971 9.31145 40.4423 10.1878 41.8612C11.3368 43.7196 13.0505 44.5069 14.7976 44.5069C17.0511 44.5069 19.1125 43.9477 23.0853 38.4532C25.3287 35.3489 27.8541 31.3612 30.0331 27.9207L30.0331 27.9207C30.9453 26.4803 31.7968 25.1358 32.5414 23.9922L35.9429 18.7659C34.2822 16.4008 32.8535 14.6009 31.8264 13.5095C29.7705 11.3256 27.1276 8.68827 22.91 8.68827C22.4833 8.68827 22.0647 8.7257 21.654 8.79835C18.7791 9.30693 16.2943 11.5416 14.1717 14.7475C10.7414 19.9249 8.64098 27.6367 8.64098 35.0424ZM0 34.7336C0 39.438 0.929197 43.5666 2.82098 46.713C5.13841 50.5745 8.88023 53.1367 14.7976 53.1367C19.7858 53.1367 23.5749 50.8972 28.0122 44.9882C30.5439 41.6136 31.8264 39.5688 36.8897 30.5912L39.4102 26.126C39.6186 25.7566 39.8249 25.391 40.0293 25.0294C40.2317 25.3612 40.4353 25.698 40.6399 26.0398L47.8147 38.0248C50.2267 42.0587 53.3621 46.5461 56.044 49.0722C59.5326 52.3633 62.6874 53.1367 66.2484 53.1367C71.9766 53.1367 75.3818 50.1127 77.1289 47.0858C78.9373 43.956 80 39.9944 80 34.6029C80 25.5335 77.7299 16.745 73.0533 9.7677C68.7801 3.39686 63.1965 0 57.3348 0C53.8434 0 50.3742 1.55794 47.1582 4.36222C44.9845 6.25803 42.9642 8.65103 41.0911 11.1814C38.7857 8.26296 36.6419 6.03863 34.5639 4.34275C30.6218 1.12394 26.8466 0 23.0491 0C16.4919 0 10.7748 4.27041 6.81319 10.377C2.34803 17.2625 0 26.1789 0 34.7336ZM49.2057 23.2077C47.7398 20.7659 46.3483 18.5697 45.0169 16.5941C45.254 16.2266 45.4901 15.8679 45.7254 15.5182C49.4617 9.96244 52.7862 6.84657 56.9175 6.84657C60.7372 6.84657 64.2092 9.37265 66.8883 13.5067C70.6635 19.3351 72.3772 27.492 72.3772 34.8421C72.3772 40 71.1532 44.5069 66.2484 44.5069C64.3149 44.5069 62.8265 43.739 60.7011 41.1629C59.0485 39.157 56.2248 34.9033 51.2617 26.6351L49.2057 23.2077Z"
                                                        fill="#F4F4F4"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0" onClick={this.OnSnapChatShow}>
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.Snapchatsettings}</div>
                                            <div className="ms-auto">
                                                <svg width="80" height="78" viewBox="0 0 80 78" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M39.9646 4.28094C50.7016 4.28453 59.6453 13.2454 59.6583 24.0349C59.6614 26.562 59.7391 28.8891 59.8814 31.0329C59.9692 32.3555 61.0665 33.3357 62.3249 33.3357C62.5103 33.3357 62.699 33.3144 62.8886 33.2699L66.2522 32.4795C66.3953 32.4458 66.539 32.4297 66.6809 32.4297C67.5352 32.4297 68.3218 33.0148 68.5136 33.8814C68.7847 35.1061 68.1002 36.3435 66.9165 36.7596L61.8108 38.8257C60.5218 39.3473 59.8295 40.7537 60.1925 42.0989C64.2887 57.2798 75.7298 55.701 75.7298 57.6788C75.7298 60.1624 67.1061 60.5131 66.327 61.2943C65.5479 62.0755 66.2932 65.8665 64.5524 66.6004C64.2242 66.7388 63.7581 66.7869 63.1894 66.7869C61.8783 66.7869 60.0239 66.5304 58.0694 66.5304C56.374 66.5304 54.6034 66.7234 53.0467 67.4443C48.917 69.3567 44.9357 72.9287 40.0001 72.9287C35.0645 72.9287 31.0831 69.3567 26.9535 67.4443C25.3965 66.7232 23.6263 66.5304 21.9308 66.5304C19.9765 66.5304 18.1217 66.7869 16.8107 66.7869C16.2424 66.7869 15.7758 66.7386 15.4478 66.6004C13.707 65.8665 14.4523 62.0755 13.6732 61.2943C12.8941 60.5131 4.27041 60.1623 4.27041 57.6786C4.27041 55.7007 15.7115 57.2795 19.8077 42.0988C20.1707 40.7537 19.4784 39.3473 18.1892 38.8255L13.0835 36.7594C11.8996 36.3433 11.2151 35.1059 11.4864 33.8812C11.6782 33.0144 12.4648 32.4293 13.3191 32.4295C13.4608 32.4295 13.6047 32.4456 13.7478 32.4793L17.1114 33.2697C17.301 33.3143 17.4897 33.3355 17.6751 33.3355C18.9333 33.3355 20.0308 32.3552 20.1186 31.0327C20.2609 28.889 20.3388 26.5619 20.3418 24.0347C20.3548 13.2454 29.2274 4.28471 39.9646 4.28094ZM39.9659 0H39.9644H39.9628C36.758 0.00102743 33.636 0.646593 30.6839 1.91889C27.8503 3.13998 25.3 4.88113 23.1039 7.09403C20.9108 9.30402 19.1849 11.8697 17.9742 14.7198C16.7152 17.6834 16.075 20.8156 16.0711 24.0296C16.0692 25.6075 16.0366 27.1389 15.9737 28.6054L14.7223 28.3112C14.2632 28.2033 13.791 28.1485 13.3194 28.1484C11.9575 28.1482 10.614 28.6097 9.53651 29.4477C8.41237 30.3221 7.62405 31.5671 7.31709 32.9536C6.58651 36.2539 8.40434 39.5857 11.5545 40.7573L15.3017 42.2736C12.8205 49.9084 8.24514 51.3714 5.16412 52.3569C4.3466 52.6184 3.64044 52.8443 2.96811 53.1787C0.289192 54.5116 0 56.7697 0 57.6786C0 59.4196 0.821969 61.0083 2.31473 62.152C3.05796 62.7216 3.97866 63.1915 5.12928 63.5886C6.69754 64.1298 8.51554 64.4733 9.9931 64.7487C10.0645 65.2975 10.1692 65.8871 10.3457 66.4813C11.0783 68.949 12.6244 70.054 13.7924 70.5463C14.9007 71.0136 16.0458 71.0675 16.8107 71.0675C17.5589 71.0675 18.3498 71.0088 19.1871 70.9466C20.0854 70.8798 21.0144 70.811 21.9308 70.811C23.3509 70.811 24.4081 70.9809 25.1626 71.3302C26.1986 71.81 27.2973 72.4569 28.4606 73.1417C31.6989 75.0483 35.3693 77.2093 40.0001 77.2093C44.6309 77.2093 48.3011 75.0483 51.5394 73.1417C52.7027 72.4568 53.8014 71.81 54.8375 71.3302C55.592 70.9807 56.6492 70.811 58.0694 70.811C58.9858 70.811 59.9147 70.88 60.8129 70.9466C61.6502 71.0088 62.4411 71.0675 63.1893 71.0675C63.9542 71.0675 65.0992 71.0136 66.2076 70.5463C67.3756 70.054 68.9217 68.949 69.6543 66.4813C69.8308 65.8871 69.9357 65.2975 70.0069 64.7487C71.4845 64.4732 73.3026 64.1298 74.8707 63.5886C76.0215 63.1915 76.942 62.7216 77.6853 62.152C79.1779 61.0083 80 59.4196 80 57.6786C80 56.7697 79.7108 54.5116 77.0315 53.1789C76.3592 52.8444 75.6531 52.6186 74.8355 52.3571C71.7545 51.3718 67.1792 49.9086 64.6979 42.2738L68.4449 40.7575C71.5951 39.5858 73.4131 36.2539 72.6826 32.9536C72.3756 31.5671 71.5873 30.3221 70.4631 29.4477C69.3856 28.6099 68.0425 28.1484 66.6809 28.1484C66.2093 28.1484 65.7372 28.2032 65.2777 28.311L64.0261 28.6052C63.9632 27.1389 63.9306 25.6075 63.9287 24.0294C63.9248 20.8129 63.2795 17.6775 62.0105 14.71C60.7924 11.8613 59.057 9.29632 56.8528 7.08615C54.6488 4.87616 52.0913 3.1369 49.2518 1.91683C46.2942 0.646079 43.1699 0.00119866 39.9659 0Z"
                                                        fill="#F4F4F4"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0" onClick={this.OnTikTokShow}>
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.tiktoksettings}</div>
                                            <div className="ms-auto">
                                                <svg width="80" height="78" viewBox="0 0 80 78" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M29.0913 77.21C22.5562 77.21 16.3941 75.4316 11.2679 72.0669C10.3116 71.439 9.39153 70.7526 8.52976 70.0269C2.54978 64.9842 -0.459816 58.2696 0.0570345 51.1182C0.448192 45.7135 3.00128 40.5044 7.24569 36.4483C12.8707 31.0726 20.6285 28.1123 29.0902 28.1123C30.5433 28.1123 32.0123 28.2049 33.4573 28.3876C34.4426 28.5128 35.1727 29.2343 35.1727 30.0853V42.3163C35.1727 42.867 34.863 43.3842 34.3401 43.7068C33.8163 44.0285 33.1434 44.1178 32.5313 43.9453C31.4322 43.6358 30.2899 43.4787 29.1325 43.4787C26.2113 43.4787 23.4752 44.4549 21.4269 46.2274C19.3907 47.9921 18.2916 50.3255 18.3359 52.8005C18.3912 55.9927 20.361 58.8863 23.6039 60.5405C25.0982 61.3038 26.8006 61.7492 28.5271 61.8298C29.8907 61.8932 31.2371 61.7404 32.5302 61.3777C36.9544 60.1302 39.9281 56.6284 39.9281 52.6624L39.949 1.71578C39.949 0.768669 40.8502 0 41.9601 0H56.08C57.1841 0 58.0811 0.758373 58.0911 1.70034C58.1031 2.77184 58.2308 3.83734 58.4714 4.8668C59.4194 8.93405 62.0923 12.5552 65.9939 15.0654C69.4386 17.2822 73.5454 18.4601 77.8743 18.4738C78.0293 18.4652 78.189 18.4738 78.3479 18.4987C79.3043 18.6462 80 19.3565 80 20.1861V32.1795C80 33.1264 79.0991 33.8952 77.99 33.8952C77.9858 33.8952 77.9808 33.8952 77.978 33.8952C72.8767 33.8952 67.9203 33.0416 63.2457 31.3584C61.4679 30.7175 59.7522 29.9644 58.1162 29.1048L58.1795 52.7525C58.1475 59.2871 55.1178 65.4175 49.6527 70.0269C45.2162 73.7681 39.6162 76.1573 33.4573 76.9363C32.0223 77.1183 30.5533 77.21 29.0913 77.21ZM29.0913 31.5437C21.7909 31.5437 15.098 34.0976 10.2472 38.7338C6.60114 42.2175 4.40803 46.6897 4.0722 51.3292C3.62874 57.4768 6.216 63.2504 11.3584 67.5854C12.1025 68.2125 12.8979 68.8053 13.7234 69.3484C18.1368 72.2462 23.4521 73.7785 29.0913 73.7785C30.3562 73.7785 31.6262 73.6987 32.8669 73.5417C38.1742 72.8717 43.001 70.8118 46.824 67.587C51.525 63.6236 54.1293 58.3544 54.1575 52.7499L54.085 25.8361C54.0831 25.1816 54.5185 24.5827 55.2061 24.2936C55.8949 24.0054 56.7175 24.0731 57.324 24.4739C59.6125 25.9803 62.1305 27.2328 64.8081 28.198C68.3718 29.4804 72.1196 30.2243 75.9757 30.4148V21.8376C71.4659 21.527 67.2114 20.1484 63.5705 17.8055C58.8786 14.7883 55.6669 10.4311 54.5246 5.53767C54.3657 4.84622 54.2459 4.14276 54.1695 3.43154H43.9713L43.9532 52.6651C43.9532 58.1125 39.8707 62.9245 33.7932 64.6376C32.0203 65.136 30.1751 65.342 28.3089 65.2579C25.9318 65.1472 23.5909 64.5347 21.5395 63.4873C17.092 61.2173 14.3911 57.2425 14.3137 52.8527C14.2544 49.4522 15.7627 46.2445 18.5621 43.8211C21.3706 41.3879 25.1253 40.0487 29.1325 40.0487C29.8091 40.0487 30.4828 40.0884 31.1507 40.1663V31.6167C30.4647 31.5677 29.7759 31.5437 29.0913 31.5437Z" fill="#F4F4F4" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0">
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.partyIntegrations}</div>
                                            <div className="ms-auto">
                                                <svg width="78" height="80" viewBox="0 0 78 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M69.7246 31.7985C65.7848 31.7985 62.4859 34.5912 61.7011 38.3008H53.1529C52.8255 35.3477 51.6552 32.6465 49.8889 30.4407L57.0445 23.2852C58.0554 23.8774 59.2088 24.1941 60.4111 24.1943C60.4113 24.1943 60.4113 24.1943 60.4113 24.1943C62.1952 24.1943 63.8724 23.4997 65.1345 22.238C67.7379 19.634 67.7379 15.397 65.1343 12.7929C63.8726 11.5315 62.1952 10.8366 60.4113 10.8366C58.6274 10.8366 56.9502 11.5312 55.6888 12.7929C54.4273 14.0544 53.7324 15.7316 53.7324 17.5157C53.7324 18.7183 54.0492 19.8714 54.6414 20.8823L47.4856 28.0381C45.2799 26.2719 42.5787 25.1017 39.6255 24.7741V16.225C43.3351 15.4402 46.1279 12.1413 46.1279 8.20132C46.1279 3.67927 42.4488 0 37.9268 0C33.4043 0 29.7252 3.67926 29.7252 8.20154C29.7252 12.1413 32.5178 15.4402 36.2272 16.225V24.7736C33.2738 25.101 30.5726 26.2714 28.3668 28.0379L22.3171 21.9881C23.1796 20.6687 23.6434 19.1276 23.6434 17.5148C23.6434 15.3242 22.7899 13.2646 21.241 11.7154C19.692 10.1665 17.6324 9.31348 15.4416 9.31348C13.251 9.31348 11.1914 10.1665 9.64244 11.7154C6.44506 14.9133 6.44483 20.1166 9.64221 23.3142C11.1912 24.8631 13.251 25.7166 15.4418 25.7166H15.442C17.0542 25.7166 18.5948 25.253 19.9138 24.3912L25.9637 30.4412C24.1975 32.6471 23.0273 35.3484 22.7002 38.3015L12.0149 38.3013C11.2766 35.7462 8.91791 33.8714 6.12788 33.8714C2.74971 33.8717 0.000679667 36.6207 0 39.9998C0.000679667 43.3786 2.74971 46.1277 6.12811 46.1277C8.91723 46.1277 11.2755 44.2538 12.0142 41.6998L22.7002 41.7001C23.0278 44.6532 24.198 47.3542 25.9644 49.56L19.9149 55.6095C18.5955 54.7472 17.0542 54.2832 15.4414 54.2832C13.2506 54.2832 11.1909 55.1364 9.64198 56.6856C6.4446 59.8834 6.44483 65.0863 9.64221 68.2839C11.1912 69.8329 13.251 70.6863 15.4418 70.6863C15.4418 70.6863 15.442 70.6863 15.4423 70.6863C17.6324 70.6863 19.692 69.8331 21.2405 68.2841C24.0262 65.4986 24.3844 61.1918 22.3169 58.0137L28.3677 51.963C30.5735 53.729 33.2745 54.8994 36.2276 55.2268V63.775C32.5178 64.5595 29.7248 67.8587 29.7248 71.7987C29.7248 76.3205 33.4036 79.9995 37.9257 80C37.9257 80 37.9259 80 37.9261 80C42.4484 79.9995 46.1274 76.3203 46.1274 71.7987C46.1274 67.8591 43.3351 64.5602 39.626 63.7752V55.2266C42.5789 54.899 45.2801 53.7288 47.4859 51.9626L53.5363 58.013C51.468 61.1911 51.8258 65.4988 54.6117 68.2846C56.1604 69.8331 58.2201 70.6863 60.4109 70.6865H60.4115C62.6017 70.6865 64.6613 69.8335 66.2109 68.2843C69.4081 65.0861 69.4078 59.883 66.2107 56.6858C64.6615 55.1366 62.6019 54.2834 60.4111 54.2834C58.7987 54.2834 57.2579 54.7472 55.9384 55.609L49.8889 49.5593C51.6552 47.3535 52.8255 44.6523 53.1529 41.6992H61.7011C62.4859 45.4088 65.7848 48.2015 69.7246 48.2015C74.2468 48.2015 77.9261 44.5223 77.9261 40C77.9261 35.4777 74.2468 31.7985 69.7246 31.7985ZM58.0916 15.1955C58.711 14.5759 59.535 14.2347 60.4111 14.2347C61.2874 14.2347 62.1114 14.5759 62.731 15.1955C64.0099 16.4747 64.0099 18.556 62.7312 19.8347C62.1114 20.4546 61.2876 20.7958 60.4113 20.7958H60.4111C59.5348 20.7958 58.711 20.4546 58.0916 19.835C57.472 19.2153 57.1308 18.3913 57.1308 17.5152C57.1308 16.6389 57.472 15.8152 58.0916 15.1955ZM18.8381 20.9113C17.9308 21.8184 16.7246 22.318 15.4418 22.318C14.1588 22.318 12.9524 21.8182 12.0453 20.9111C10.1726 19.0384 10.1728 15.9912 12.0457 14.1183C12.9526 13.2111 14.1588 12.7118 15.4416 12.7118C16.7246 12.7118 17.9308 13.2114 18.8381 14.1185C19.7452 15.0256 20.245 16.232 20.245 17.5148C20.245 18.7978 19.745 20.004 18.8381 20.9113ZM6.12788 42.7293C4.62287 42.7293 3.39834 41.5046 3.39811 39.9998C3.39834 38.4945 4.62287 37.27 6.12788 37.2698C7.63312 37.2698 8.85765 38.4943 8.85765 39.9995C8.85765 41.5048 7.63312 42.7291 6.12788 42.7293ZM18.8374 65.881C17.9305 66.7879 16.7248 67.2875 15.4423 67.2875C15.442 67.2875 15.442 67.2875 15.442 67.2875C14.1588 67.2875 12.9524 66.7877 12.0453 65.8806C10.1726 64.0079 10.1726 60.9609 12.0453 59.088C12.9524 58.1809 14.1584 57.6813 15.4414 57.6813C16.7243 57.6813 17.9305 58.1811 18.8379 59.088C20.7104 60.9609 20.7101 64.0081 18.8374 65.881ZM57.0143 59.0885C57.9217 58.1813 59.1279 57.6818 60.4109 57.6818C61.6938 57.6818 62.9 58.1815 63.8074 59.0887C65.6799 60.9609 65.6799 64.0083 63.8074 65.881C62.9 66.7882 61.6941 67.2877 60.4113 67.2877H60.4109C59.1276 67.2877 57.9215 66.7879 57.0146 65.8813C55.1418 64.0086 55.1421 60.9614 57.0143 59.0885ZM33.1234 8.20154C33.1234 5.55311 35.2781 3.39856 37.9266 3.39834C40.5748 3.39834 42.7293 5.55311 42.7293 8.20132C42.7293 10.8498 40.5745 13.0048 37.9261 13.0048C35.2779 13.0048 33.1234 10.85 33.1234 8.20154ZM42.7291 71.7982C42.7291 74.4462 40.5743 76.601 37.9261 76.6012C35.2777 76.601 33.1231 74.4464 33.1231 71.7982C33.1231 69.1498 35.2779 66.995 37.9263 66.9948C40.5745 66.995 42.7291 69.1498 42.7291 71.7982ZM37.9261 51.9243C31.3512 51.9243 26.0018 46.5751 26.0018 40C26.0018 33.4249 31.351 28.0755 37.9261 28.0755C44.5012 28.0755 49.8509 33.4247 49.8509 40C49.8509 46.5751 44.5014 51.9243 37.9261 51.9243ZM69.7246 44.8032C67.0761 44.8032 64.9214 42.6484 64.9214 40C64.9214 37.3516 67.0761 35.1968 69.7246 35.1968C72.373 35.1968 74.5278 37.3516 74.5278 40C74.5278 42.6484 72.373 44.8032 69.7246 44.8032Z"
                                                        fill="#F4F4F4"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-sm-set mb-3">
                                    <div className="comn-set-box">
                                        <div className="text-end">
                                            <button className="bg-transparent border-0">
                                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.68788 14.9465C1.46529 14.9461 1.2531 14.8522 1.10308 14.6878C0.950289 14.5247 0.874368 14.3042 0.894392 14.0816L1.0888 11.9439L10.0695 2.96644L12.876 5.7722L3.89773 14.7489L1.76008 14.9433C1.73549 14.9457 1.71089 14.9465 1.68788 14.9465ZM13.4362 5.21121L10.6305 2.40545L12.3134 0.722465C12.4623 0.573466 12.6642 0.489746 12.8748 0.489746C13.0854 0.489746 13.2874 0.573466 13.4362 0.722465L15.1192 2.40545C15.2682 2.55428 15.3519 2.75624 15.3519 2.96684C15.3519 3.17743 15.2682 3.37939 15.1192 3.52823L13.437 5.21041L13.4362 5.21121Z"
                                                        fill="#696969"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                        <div className="d-flex pt-3">
                                            <div className="comn-text-set">{settingLanguage.OtherIntegrations}</div>
                                            <div className="ms-auto">
                                                <svg width="78" height="80" viewBox="0 0 78 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M75.9447 48.4664L73.1852 46.8731C73.6486 44.5681 73.8831 42.26 73.8831 40C73.8831 37.7071 73.6524 35.3968 73.1968 33.12L75.9447 31.5335C76.7957 31.0422 77.4046 30.2488 77.6588 29.2996C77.913 28.3504 77.7826 27.3589 77.2912 26.5079L69.7765 13.492C69.2851 12.6409 68.4918 12.0321 67.5426 11.7778C66.5933 11.5236 65.602 11.654 64.7508 12.1454L62.0007 13.7332C58.5269 10.6771 54.4386 8.31186 50.0867 6.84023V3.67906C50.0867 1.65041 48.4363 0 46.4076 0H31.3783C29.3496 0 27.6992 1.65041 27.6992 3.67906V6.84039C23.3704 8.30607 19.2878 10.6744 15.8011 13.7426L13.0349 12.1454C12.1837 11.654 11.1923 11.5234 10.2431 11.7778C9.29387 12.0323 8.5006 12.6409 8.00917 13.492L0.494496 26.5079C0.00306766 27.3589 -0.127343 28.3504 0.126903 29.2996C0.38115 30.2488 0.989995 31.0422 1.84103 31.5335L4.60048 33.1267C4.13739 35.4317 3.90272 37.7398 3.90272 40C3.90272 42.2926 4.13348 44.6029 4.58906 46.8798L1.84119 48.4664C0.0843203 49.4807 -0.519672 51.7351 0.494496 53.4921L8.00917 66.508C9.0235 68.2647 11.2779 68.8689 13.0349 67.8546L15.7848 66.2668C19.2588 69.3229 23.3469 71.6881 27.6992 73.1599V76.3209C27.6992 78.3496 29.3496 80 31.3783 80H46.4076C48.4363 80 50.0867 78.3496 50.0867 76.3209V73.1596C54.4156 71.6939 58.4983 69.3256 61.9849 66.2575L64.7509 67.8546C66.5076 68.8689 68.7624 68.2647 69.7767 66.508L77.2914 53.4921C78.3055 51.7351 77.7015 49.4807 75.9447 48.4664ZM75.2575 52.318L67.7429 65.3337C67.3761 65.9693 66.5606 66.1877 65.9251 65.8207L62.4195 63.7968C61.9741 63.5396 61.4128 63.6023 61.0352 63.9516C57.4512 67.2664 53.139 69.7674 48.5651 71.1843C48.0735 71.3367 47.7383 71.7913 47.7383 72.3059V76.3209C47.7383 77.0547 47.1414 77.6517 46.4076 77.6517H31.3783C30.6445 77.6517 30.0475 77.0547 30.0475 76.3209V72.3061C30.0475 71.7915 29.7123 71.3368 29.2209 71.1845C24.6188 69.7588 20.3013 67.2609 16.7348 63.9612C16.5123 63.7553 16.226 63.6488 15.9372 63.6488C15.7358 63.6488 15.5334 63.7005 15.3504 63.8062L11.8608 65.8207C11.2251 66.1876 10.4098 65.9692 10.043 65.3337L2.52831 52.318C2.1615 51.6825 2.38005 50.867 3.01536 50.5L6.50217 48.4869C6.94741 48.2298 7.17364 47.7132 7.06045 47.2116C6.5233 44.8308 6.25105 42.4044 6.25105 40C6.25105 37.636 6.52737 35.2119 7.0725 32.795C7.18553 32.2935 6.95931 31.7768 6.51422 31.5198L3.01536 29.4998C2.70757 29.3221 2.48745 29.0351 2.3954 28.6918C2.3035 28.3485 2.35062 27.9898 2.52831 27.682L10.043 14.6661C10.2207 14.3584 10.5076 14.1381 10.8511 14.0462C11.1943 13.9541 11.5531 14.0014 11.8609 14.1791L15.3665 16.2031C15.8121 16.4604 16.3732 16.3975 16.7508 16.0482C20.335 12.7335 24.647 10.2325 29.2209 8.8155C29.7125 8.66317 30.0477 8.20853 30.0477 7.69393V3.67906C30.0477 2.94528 30.6446 2.34834 31.3784 2.34834H46.4078C47.1415 2.34834 47.7385 2.94528 47.7385 3.67906V7.69393C47.7385 8.20853 48.0737 8.66317 48.5651 8.8155C53.1671 10.2411 57.4846 12.7389 61.0512 16.0388C61.4288 16.3883 61.9901 16.451 62.4356 16.1938L65.9253 14.1791C66.2332 14.0014 66.5919 13.9541 66.935 14.0462C67.2784 14.1382 67.5653 14.3584 67.7432 14.6661L75.2579 27.682C75.4356 27.9898 75.4828 28.3485 75.3908 28.6918C75.2987 29.0351 75.0786 29.3221 74.7708 29.4998L71.284 31.513C70.8388 31.77 70.6125 32.2868 70.7257 32.7883C71.2629 35.1688 71.5351 37.5951 71.5351 40C71.5351 42.364 71.2588 44.7881 70.7137 47.2049C70.6006 47.7063 70.8269 48.2229 71.2719 48.48L74.7708 50.5C75.406 50.867 75.6245 51.6825 75.2575 52.318Z"
                                                        fill="#F4F4F4"
                                                    />
                                                    <path
                                                        d="M38.8929 16.2817C25.8146 16.2817 15.1747 26.9217 15.1747 39.9999C15.1747 53.0781 25.8146 63.7181 38.8929 63.7181C51.9713 63.7181 62.6111 53.0781 62.6111 39.9999C62.6111 26.9217 51.9713 16.2817 38.8929 16.2817ZM38.8929 61.3698C27.1096 61.3698 17.523 51.7833 17.523 39.9999C17.523 28.2166 27.1096 18.6301 38.8929 18.6301C50.6762 18.6301 60.2628 28.2166 60.2628 39.9999C60.2628 51.7833 50.6762 61.3698 38.8929 61.3698Z"
                                                        fill="#F4F4F4"
                                                    />
                                                    <path
                                                        d="M43.2765 33.8164H38.8929C38.2445 33.8164 37.7188 34.3421 37.7188 34.9906V45.0101C37.7188 45.6586 38.2445 46.1843 38.8929 46.1843C39.5414 46.1843 40.0671 45.6586 40.0671 45.0101V42.427H43.2765C45.6505 42.427 47.5818 40.4957 47.5818 38.1217C47.5818 35.7477 45.6505 33.8164 43.2765 33.8164ZM43.2765 40.0786H40.0671V36.1647H43.2765C44.3556 36.1647 45.2335 37.0426 45.2335 38.1217C45.2335 39.2008 44.3556 40.0786 43.2765 40.0786Z"
                                                        fill="#F4F4F4"
                                                    />
                                                    <path
                                                        d="M32.4776 34.5784C32.3057 34.1201 31.8677 33.8164 31.3783 33.8164H30.1258C29.6364 33.8164 29.1982 34.12 29.0265 34.5784L25.2691 44.5979C25.0414 45.2051 25.3491 45.8818 25.9563 46.1096C26.5634 46.3374 27.2402 46.0296 27.468 45.4225L28.1214 43.6794H33.3825L34.0361 45.4224C34.2129 45.8937 34.6603 46.1846 35.1356 46.1846C35.2726 46.1846 35.4119 46.1605 35.5477 46.1096C36.1548 45.882 36.4626 45.2051 36.2348 44.5979L32.4776 34.5784ZM29.0021 41.3311L30.752 36.6646L32.502 41.3311H29.0021Z"
                                                        fill="#F4F4F4"
                                                    />
                                                    <path
                                                        d="M50.165 33.8164C49.5165 33.8164 48.9908 34.3421 48.9908 34.9906V45.0101C48.9908 45.6586 49.5165 46.1843 50.165 46.1843C50.8134 46.1843 51.3391 45.6586 51.3391 45.0101V34.9906C51.3391 34.3421 50.8134 33.8164 50.165 33.8164Z"
                                                        fill="#F4F4F4"
                                                    />
                                                    <path
                                                        d="M47.2925 13.6671C48.1074 13.9269 48.9197 14.2285 49.7067 14.5636C49.8567 14.6274 50.0126 14.6577 50.1661 14.6577C50.6226 14.6577 51.0569 14.3896 51.2469 13.9431C51.5009 13.3465 51.2231 12.6569 50.6265 12.4029C49.772 12.0393 48.8903 11.7117 48.0054 11.4298C47.3878 11.2328 46.7272 11.5741 46.5302 12.1919C46.3334 12.8097 46.6747 13.4702 47.2925 13.6671Z"
                                                        fill="#F4F4F4"
                                                    />
                                                    <path
                                                        d="M14.619 53.2136C14.3084 52.6444 13.595 52.4346 13.0259 52.7452C12.4566 53.0558 12.2469 53.7691 12.5575 54.3383C13.0447 55.2313 13.584 56.1098 14.1604 56.9492C14.3881 57.2806 14.7555 57.4588 15.1294 57.4588C15.3584 57.4588 15.5898 57.3919 15.793 57.2525C16.3276 56.8853 16.4634 56.1544 16.0963 55.6199C15.5651 54.8462 15.068 54.0366 14.619 53.2136Z"
                                                        fill="#F4F4F4"
                                                    />
                                                    <path
                                                        d="M36.4882 67.5293C30.1964 66.9872 24.2241 64.2606 19.6716 59.8517C19.2057 59.4005 18.4624 59.4126 18.0114 59.8783C17.5603 60.3442 17.5721 61.0876 18.038 61.5386C22.9773 66.3221 29.4583 69.2806 36.2866 69.8689C36.3209 69.8719 36.3548 69.8733 36.3887 69.8733C36.9916 69.8733 37.5044 69.4116 37.5572 68.8C37.6128 68.154 37.1342 67.5851 36.4882 67.5293Z"
                                                        fill="#F4F4F4"
                                                    />
                                                    <path
                                                        d="M55.7892 15.2307C55.2538 14.8649 54.5232 15.0023 54.1573 15.5376C53.7914 16.073 53.9289 16.8036 54.4641 17.1695C59.9192 20.8976 63.8652 26.4451 65.5752 32.79C65.7164 33.3139 66.1905 33.6589 66.7082 33.6589C66.8094 33.6589 66.9122 33.6458 67.0144 33.6182C67.6407 33.4494 68.0114 32.805 67.8426 32.179C65.9871 25.2937 61.7064 19.2747 55.7892 15.2307Z"
                                                        fill="#F4F4F4"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* ---------------offer setting-------------------------------- */}
                <Modal
                    dialogClassName="modal-dialog-centered cust-modal-white-content"
                    className="cust-white-modal"
                    ref={(el) => {
                        this.dialog = el;
                    }}
                    show={this.state.offersettingmodal}
                    onHide={this.offersettingmodalclose}
                    size="md"
                >
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">{settingLanguage.offersettings}</h1>
                        </Modal.Title>
                        <button type="button" onClick={this.offersettingmodalclose} className="close btn-close"></button>
                    </Modal.Header>
                    <Modal.Body>
                        <form className="comn-set-modal">
                            <div className="row modal-form cust-white-modal setting-cart-modal align-items-center">
                                <div className="col-6 mb-3 form-group">
                                    <label>{settingLanguage.SalePrices}</label>
                                </div>
                                <div className="col-6 mb-3 text-end">
                                    <label className="switch me-4 ">
                                        <input type="checkbox" checked={this.state.salePrice} onChange={(e) => { this.setState({ salePrice: e.target.checked }) }} />
                                        <div className="slider round" />
                                        <div className="on-off-text" />
                                    </label>
                                </div>
                                <div className="col-12 text-lg-end text-center">
                                    <div className="common-red-btn">
                                        <button className="btn red-border-btn  me-2" onClick={this.offersettingmodalclose}>
                                            {settingLanguage.Cancel}
                                        </button>
                                        <button className="btn red-btn" type="button" onClick={() => this.handleSubmitSettings('offer')}>
                                            {/* <button className="btn red-btn" type="button" onClick={this.handleSubmitOffer}> */}
                                            {settingLanguage.Save}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>

                {/* -----------------Tax Setting-------------------------------- */}
                <Modal
                    dialogClassName="modal-dialog-centered cust-modal-white-content"
                    className="cust-white-modal"
                    ref={(el) => {
                        this.dialog = el;
                    }}
                    show={this.state.taxsettingmodal}
                    onHide={this.taxsettingmodalclose}
                    size="md"
                >
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">{settingLanguage.taxsettings}</h1>
                        </Modal.Title>
                        <button type="button" onClick={this.taxsettingmodalclose} className="close btn-close"></button>
                    </Modal.Header>
                    <Modal.Body>
                        <form>
                            <div className="row modal-form cust-white-modal setting-cart-modal align-items-center">
                                <div className="col-12 mb-3 form-group">
                                    <ul>
                                        <li className="d-inline-block li-mr">
                                            <label className="cust-radio mb-3">
                                                <input type="radio" id="1" value="Inclusive" name="taxType" defaultChecked={this.state.Inclusive} onChange={this.handleChange} />
                                                <span className="checkmark"></span>
                                                <span>{settingLanguage.Inclusive}</span>
                                            </label>
                                        </li>
                                        {/* <li className="d-inline-block">
                                            <label className="cust-radio mb-3">
                                                <input type="radio" id="2" value="Exclusive" name="taxType" defaultChecked={this.state.Exclusive} onChange={this.handleChange} />
                                                <span className="checkmark"></span>
                                                <span>{settingLanguage.Exclusive}</span>
                                            </label>
                                        </li> */}
                                    </ul>
                                </div>
                                <div className="col-12 mb-3 form-group">
                                    <div className="d-flex align-items-center">

                                        <label>{settingLanguage.VATRate} (%)</label>
                                        <input type="number" name="taxRate" onChange={this.handleChange} value={this.state.taxRate} className="ms-2 form-control input-custom-class w-auto" />
                                    </div>
                                </div>
                                <div className="col-12 text-lg-end text-center">
                                    <div className="common-red-btn">
                                        <button className="btn red-border-btn  me-2" onClick={this.taxsettingmodalclose}>
                                            {settingLanguage.Cancel}
                                        </button>
                                        <button className="btn red-btn" type="button" onClick={() => this.handleSubmitSettings('tax')}>
                                            {/* <button className="btn red-btn" type="button" onClick={this.handleSubmitTaxSetting}> */}
                                            {settingLanguage.Save}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>

                {/* -----------------payment setting--------------------------- */}
                <Modal
                    dialogClassName="modal-dialog-centered cust-modal-white-content"
                    className="cust-white-modal"
                    ref={(el) => {
                        this.dialog = el;
                    }}
                    show={this.state.paymentsettingmodal}
                    onHide={this.paymentsettingmodalclose}
                    size="md"
                >
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">{settingLanguage.paymentsettings}</h1>
                        </Modal.Title>
                        <button type="button" onClick={this.paymentsettingmodalclose} className="close btn-close"></button>
                    </Modal.Header>
                    <Modal.Body className="px-4">
                        <form className="comn-set-modal">
                            <div className="row modal-form cust-white-modal setting-cart-modal align-items-center">
                                <div className="col-6 mb-3 form-group">
                                    <label>{settingLanguage.OnlinePayments}</label>
                                </div>
                                <div className="col-6 mb-3 text-end pe-3">
                                    <label className="switch me-4 ">
                                        <input type="checkbox" name="ONLINE" checked={this.state.ONLINE} onChange={(e) => { this.setState({ ONLINE: e.target.checked }) }} />
                                        <div className="slider round" />
                                        <div className="on-off-text" />
                                    </label>
                                </div>
                                <div className="col-6 mb-3 form-group">
                                    <label>{settingLanguage.CODPayments}</label>
                                </div>
                                <div className="col-6 mb-3 text-end pe-3">
                                    <label className="switch me-4 ">
                                        <input type="checkbox" name="COD" checked={this.state.COD} onChange={(e) => { this.setState({ COD: e.target.checked }) }} />
                                        <div className="slider round" />
                                        <div className="on-off-text" />
                                    </label>
                                </div>
                                <div className="col-6 mb-3 form-group">
                                    <label>{settingLanguage.ApplePay}</label>
                                </div>
                                <div className="col-6 mb-3 text-end pe-3">
                                    <label className="switch me-4 ">
                                        <input type="checkbox" name="APPLE" checked={this.state.APPLE} onChange={(e) => { this.setState({ APPLE: e.target.checked }) }} />
                                        <div className="slider round" />
                                        <div className="on-off-text" />
                                    </label>
                                </div>
                                <div className="col-6 mb-3 form-group">
                                    <label>{settingLanguage.TabbyPayment}</label>
                                </div>
                                <div className="col-6 mb-3 text-end pe-3">
                                    <label className="switch me-4 ">
                                        <input type="checkbox" name="TABBY" checked={this.state.TABBY} onChange={(e) => { this.setState({ TABBY: e.target.checked }) }} />
                                        <div className="slider round" />
                                        <div className="on-off-text" />
                                    </label>
                                </div>
                                <div className="col-6 mb-3 form-group">
                                    <label>{settingLanguage.TamaraPayment}</label>
                                </div>
                                <div className="col-6 mb-3 text-end pe-3">
                                    <label className="switch me-4 ">
                                        <input type="checkbox" name="TAMARA" checked={this.state.TAMARA} onChange={(e) => { this.setState({ TAMARA: e.target.checked }) }} />
                                        <div className="slider round" />
                                        <div className="on-off-text" />
                                    </label>
                                </div>
                                <div className="col-12 mb-3 form-group">
                                    <div className="d-flex align-items-center">

                                        <label className="me-2">{settingLanguage.TabbyMinPurchaseValue}</label>
                                        <input type="number" name="tabbyMinValue" value={this.state.tabbyMinValue} onChange={this.handleChange} className="ms-auto form-control input-custom-class w-auto" />
                                    </div>
                                </div>
                                <div className="col-12 mb-3 form-group">
                                    <div className="d-flex align-items-center">

                                        <label className="me-2">{settingLanguage.TabbyMaxPurchaseValue}</label>
                                        <input type="number" name="tabbyMaxValue" value={this.state.tabbyMaxValue} onChange={this.handleChange} className="ms-auto form-control input-custom-class w-auto" />
                                    </div>
                                </div>
                                <div className="col-12 mb-3 form-group">
                                    <div className="d-flex align-items-center">

                                        <label className="me-2">{settingLanguage.TamaraMinPurchaseValue}</label>
                                        <input type="number" name="tamaraMinValue" value={this.state.tamaraMinValue} onChange={this.handleChange} className="ms-auto form-control input-custom-class w-auto" />
                                    </div>
                                </div>
                                <div className="col-12 mb-3 form-group">
                                    <div className="d-flex align-items-center">

                                        <label className="me-2">{settingLanguage.TamaraMaxPurchaseValue}</label>
                                        <input type="number" name="tamaraMaxValue" value={this.state.tamaraMaxValue} onChange={this.handleChange} className="ms-auto form-control input-custom-class w-auto" />
                                    </div>
                                </div>
                                <div className="col-12 mb-3 form-group">
                                    <div className="d-flex align-items-center">

                                        <label className="me-2">{settingLanguage.CashonDeliveryrate}</label>
                                        <input type="number" name="codRate" value={this.state.codRate} onChange={this.handleChange} className="ms-auto form-control input-custom-class w-auto" />
                                    </div>
                                </div>
                                <div className="col-12 mb-3 form-group">
                                    <div className="d-flex align-items-center">

                                        <label className="me-2">{settingLanguage.CashonDeliveryrateLimit}</label>
                                        <input type="number" name="codRateLimit" value={this.state.codRateLimit} onChange={this.handleChange} className="ms-auto form-control input-custom-class w-auto" />
                                    </div>
                                </div>
                                <div className="col-12 text-lg-end text-center">
                                    <div className="common-red-btn">
                                        <button className="btn red-border-btn  me-2" onClick={this.paymentmodalclose}>
                                            {settingLanguage.Cancel}
                                        </button>
                                        <button className="btn red-btn" type="button" onClick={() => this.handleSubmitSettings('payment')}>
                                            {/* <button className="btn red-btn" type="button" onClick={this.handlePaymentSettingSubmit}> */}
                                            {settingLanguage.Save}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>

                {/* -----------------shipping setting-------------------------- */}
                <Modal
                    dialogClassName="modal-dialog-centered cust-modal-white-content"
                    className="cust-white-modal"
                    ref={(el) => {
                        this.dialog = el;
                    }}
                    show={this.state.shippingsettingmodal}
                    onHide={this.shippingsettingmodalclose}
                    size="xl"
                >
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">{settingLanguage.shippingsettings}</h1>
                        </Modal.Title>
                        <button type="button" onClick={this.shippingsettingmodalclose} className="close btn-close"></button>
                    </Modal.Header>
                    <Modal.Body>
                        <Formik
                            innerRef={this.runforms}
                            enableReinitialize
                            initialValues={{
                                contact_name: "",
                                company_name: "",
                                address: "",
                                // city: "",
                                area: "",
                                contact_number: "",
                                email: "",
                                shipping_company: "",
                                collection_point_delivery: "",
                                collection_point_delivery_charge: "",
                                delivery_time: "",
                                freeShipping_limit: "",
                                shipping_charge: "",
                            }}
                            validationSchema={Yup.object({
                                contact_name: Yup.string().required("Required."),
                                company_name: Yup.string().required("Required."),
                                address: Yup.string().required("Required."),
                                // city: Yup.string().required("Required."),
                                area: Yup.string().required("Required."),
                                contact_number: Yup.number().required("Required."),
                                email: Yup.string().required("Required.").email('Invalid Email.'),
                                shipping_company: Yup.string().required("Required."),
                                collection_point_delivery: Yup.string().required("Required."),
                                collection_point_delivery_charge: Yup.string().required("Required."),
                                delivery_time: Yup.string().required("Required."),
                                freeShipping_limit: Yup.string().required("Required."),
                                shipping_charge: Yup.string().required("Required."),
                            })}
                            onSubmit={(formData, { resetForm }) => {
                                this.submitShippingDetails(formData, resetForm);
                            }}
                        >
                            {(runform) => (
                                <form onSubmit={runform.handleSubmit} >
                                    <div className="row modal-form cust-white-modal setting-cart-modal ">
                                        <div className="col-lg-6 mb-2 form-group">
                                            <div className="d-flex align-items-center">
                                                <label>{settingLanguage.ContactName}</label>
                                                <input type="text" name="contact_name" {...this.formAttr(runform, "contact_name")} className="ms-auto form-control input-custom-class w-auto mb-0" />
                                            </div>
                                            <div className="d-flex mt-2 align-items-center">
                                                <label>{settingLanguage.CompanyName}</label>
                                                <input type="text" name="company_name" {...this.formAttr(runform, "company_name")} className="ms-auto form-control input-custom-class w-auto mb-0" />
                                            </div>
                                            <div className="d-flex mt-2 align-items-center">
                                                <label>{settingLanguage.Address}</label>
                                                <input type="text" name="address" {...this.formAttr(runform, "address")} className="ms-auto form-control input-custom-class w-auto mb-0" />
                                            </div>
                                            <div className="d-flex mt-2 align-items-center">
                                                <label>{settingLanguage.City}</label>
                                                <select name="city" onChange={this.handleChange} value={this.state.city} className="form-select form-control fix-wselect input-custom-class mb-0 ms-auto">
                                                    {
                                                        this.state.cityData?.map((item) => {
                                                            return (
                                                                <option value={item.id} key={item.id}>{this.context.language === 'english' ? item.english : item.arabic}</option>
                                                            )
                                                        })
                                                    }
                                                </select>
                                            </div>
                                            <div className="d-flex mt-2 align-items-center">
                                                <label >{settingLanguage.Area}</label>
                                                <select name="area" {...this.formAttr(runform, "area")} className="form-select form-control fix-wselect input-custom-class mb-0 ms-auto">
                                                    {
                                                        this.state.areaData?.map((item) => {
                                                            return (
                                                                <option value={item.id} key={item.id}>{this.context.language === 'english' ? item.english : item.arabic}</option>
                                                            )
                                                        })
                                                    }
                                                </select>
                                            </div>
                                            <div className="d-flex mt-2 align-items-center">
                                                <label>{settingLanguage.ContactNumber}</label>
                                                <input type="tel" name="contact_number" {...this.formAttr(runform, "contact_number")} className="ms-auto form-control input-custom-class w-auto mb-0" />
                                            </div>
                                            <div className="d-flex mt-2 align-items-center">
                                                <label>{settingLanguage.EmailAddress}</label>
                                                <input type="email" name="email" {...this.formAttr(runform, "email")} className="ms-auto form-control input-custom-class w-auto mb-0" />
                                            </div>
                                        </div>
                                        <div className="col-lg-6 mb-2">
                                            <div className="d-flex align-items-center">
                                                <label>{settingLanguage.DefaultShippingCompany}</label>
                                                <select className="form-select form-control input-custom-class mb-0 ms-auto" name="shipping_company" {...this.formAttr(runform, "shipping_company")}>
                                                    {
                                                        this.state.shippingCompanyData?.map((item) => {
                                                            return (
                                                                <option value={item.id} key={item.id}>{this.context.language === 'english' ? item.english : item.arabic}</option>
                                                            )
                                                        })
                                                    }
                                                </select>
                                            </div>
                                            <div className="d-flex mt-2 align-items-center">
                                                <label>{settingLanguage.collectionPointDelivery}</label>
                                                <select className="form-select form-control input-custom-class mb-0 ms-auto" name="collection_point_delivery" {...this.formAttr(runform, "collection_point_delivery")}>
                                                    <option value={"1"}>{ButtonLanguage.Yes}</option>
                                                    <option value={"0"}>{ButtonLanguage.No}</option>
                                                </select>
                                                {/* <select className="form-select form-control input-custom-class mb-0 ms-auto" name="delivery_time" {...this.formAttr(runform, "delivery_time")}>
                                                    <option value="3-5 days">3-5 Days</option>
                                                    <option value="7-8 days">7-8 Days</option>
                                                </select> */}
                                            </div>
                                            <div className="d-flex mt-2 align-items-center">
                                                <label>{settingLanguage.collectionPointDeliveryCharge}</label>
                                                <input type="number" name="collection_point_delivery_charge" {...this.formAttr(runform, "collection_point_delivery_charge")} className="ms-auto form-control input-custom-class w-auto mb-0" />
                                                {/* <select className="form-select form-control input-custom-class mb-0 ms-auto" name="delivery_time" {...this.formAttr(runform, "delivery_time")}>
                                                    <option value="3-5 days">3-5 Days</option>
                                                    <option value="7-8 days">7-8 Days</option>
                                                </select> */}
                                            </div>
                                            <div className="d-flex mt-2 align-items-center">
                                                <label>{settingLanguage.DefaultAverageDeliveryTime}</label>
                                                <input type="text" name="delivery_time" {...this.formAttr(runform, "delivery_time")} className="ms-auto form-control input-custom-class w-auto mb-0" />
                                                {/* <select className="form-select form-control input-custom-class mb-0 ms-auto" name="delivery_time" {...this.formAttr(runform, "delivery_time")}>
                                                    <option value="3-5 days">3-5 Days</option>
                                                    <option value="7-8 days">7-8 Days</option>
                                                </select> */}
                                            </div>
                                            <div className="d-flex mt-2 align-items-center">
                                                <label>{settingLanguage.DefaultShippingCharge}</label>
                                                <input type="number" name="shipping_charge" {...this.formAttr(runform, "shipping_charge")} className="ms-auto form-control input-custom-class w-auto mb-0" />
                                            </div>
                                            <div className="d-flex mt-2 align-items-center">
                                                <label>{settingLanguage.FreeShippinglimit}</label>
                                                <input type="number" name="freeShipping_limit" {...this.formAttr(runform, "freeShipping_limit")} className="ms-auto form-control input-custom-class w-auto mb-0" />
                                            </div>
                                        </div>
                                        <div className="col-12 text-lg-end text-center">
                                            <div className="common-red-btn">
                                                <button className="btn red-border-btn  me-2" type="button" onClick={this.shippingsettingmodalclose}>
                                                    {settingLanguage.Cancel}
                                                </button>
                                                <button className="btn red-btn" type="submit">
                                                    {settingLanguage.Save}
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            )}
                        </Formik>
                    </Modal.Body>
                </Modal>
                {/* -----------------warehouse registration-------------------------- */}
                <Modal
                    dialogClassName="modal-dialog-centered cust-modal-white-content"
                    className="cust-white-modal"
                    ref={(el) => {
                        this.dialog = el;
                    }}
                    show={this.state.warehouseRegistrationModal}
                    onHide={this.warehouseRegistrationModalClose}
                    size="md"
                >
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">{settingLanguage.warehouseRegistration}</h1>
                        </Modal.Title>
                        <button type="button" onClick={this.warehouseRegistrationModalClose} className="close btn-close"></button>
                    </Modal.Header>
                    <Modal.Body>
                        <Formik
                            innerRef={this.runforms}
                            enableReinitialize
                            initialValues={{
                                reference: "",
                                address: "",
                                city: this.state.city,
                                latitude: "",
                                longitude: "",
                                manager_phone: "",
                                pickup_time: "",
                            }}
                            validationSchema={Yup.object({
                                reference: Yup.string().required("Required."),
                                address: Yup.string().required("Required."),
                                city: Yup.string().required("Required."),
                                latitude: Yup.number().required("Required."),
                                longitude: Yup.number().required("Required."),
                                manager_phone: Yup.string().required("Required."),
                                pickup_time: Yup.string().required("Required."),
                            })}
                            onSubmit={(formData, { resetForm }) => {
                                this.submitWarehouseDetails(formData, resetForm);
                            }}
                        >
                            {(runform) => (
                                <form onSubmit={runform.handleSubmit} >
                                    <div className="row modal-form cust-white-modal setting-cart-modal">
                                        <div className="col-lg-12 mb-4 form-group">
                                            <div className="d-flex align-items-center">
                                                <label>{settingLanguage.reference}</label>
                                                <input type="text" name="reference" {...this.formAttr(runform, "reference")} className="ms-auto form-control input-custom-class w-auto mb-0" />
                                            </div>
                                            <div className="d-flex mt-2 align-items-center">
                                                <label>{settingLanguage.Address}</label>
                                                <input type="text" name="address" {...this.formAttr(runform, "address")} className="ms-auto form-control input-custom-class w-auto mb-0" />
                                            </div>
                                            <div className="d-flex mt-2 align-items-center">
                                                <label>{settingLanguage.City}</label>
                                                <select name="city" onChange={this.handleChange} value={this.state.city} className="form-select form-control fix-wselect input-custom-class mb-0 ms-auto">
                                                    {
                                                        this.state.cityData?.map((item) => {
                                                            return (
                                                                <option value={item.id} key={item.id}>{this.context.language === 'english' ? item.english : item.arabic}</option>
                                                            )
                                                        })
                                                    }
                                                </select>
                                            </div>
                                            <div className="d-flex mt-2 align-items-center">
                                                <label>{settingLanguage.warehouseLatitude}</label>
                                                <input type="number" name="latitude" {...this.formAttr(runform, "latitude")} className="ms-auto form-control input-custom-class w-auto mb-0" />
                                            </div>
                                            <div className="d-flex mt-2 align-items-center">
                                                <label>{settingLanguage.warehouseLongitude}</label>
                                                <input type="number" name="longitude" {...this.formAttr(runform, "longitude")} className="ms-auto form-control input-custom-class w-auto mb-0" />
                                            </div>
                                            <div className="d-flex mt-2 align-items-center">
                                                <label>{settingLanguage.managerPhone}</label>
                                                <input type="tel" name="manager_phone" {...this.formAttr(runform, "manager_phone")} className="ms-auto form-control input-custom-class w-auto mb-0" />
                                            </div>
                                            <div className="d-flex mt-2 align-items-center">
                                                <label>{settingLanguage.pickupTime}</label>
                                                <input type="time" name="pickup_time" {...this.formAttr(runform, "pickup_time")} className="ms-auto form-control input-custom-class mb-0" style={{ width: 204 }} />
                                            </div>
                                        </div>
                                        <div className="col-12 text-lg-end text-center">
                                            <div className="common-red-btn">
                                                <button className="btn red-border-btn  me-2" type="button" onClick={this.warehouseRegistrationModalClose}>
                                                    {settingLanguage.Cancel}
                                                </button>
                                                <button className="btn red-btn" type="submit">
                                                    {settingLanguage.Save}
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            )}
                        </Formik>
                    </Modal.Body>
                </Modal>

                {/* -----------------seo setting------------------------------ */}
                <Modal
                    dialogClassName="modal-dialog-centered cust-modal-white-content"
                    className="cust-white-modal"
                    ref={(el) => {
                        this.dialog = el;
                    }}
                    show={this.state.seosettingmodal}
                    onHide={this.seosettingmodalclose}
                    size="xl"
                >
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">Home page SEO </h1>
                        </Modal.Title>
                        <button type="button" onClick={this.seosettingmodalclose} className="close btn-close"></button>
                    </Modal.Header>
                    <Modal.Body>
                        <form>
                            <div className="row modal-form cust-white-modal setting-cart-modal ">
                                <div className="col-md-6 mb-3 form-group">
                                    <label>Meta Title in English</label>
                                    <input type="text" value={this.state.meta_name_en} name="meta_name_en" onChange={this.handleChange} className="form-control input-custom-class mb-0" />
                                </div>
                                <div className="col-md-6 mb-3 text-end form-group">
                                    <label>Meta Title Name in Arabic</label>
                                    <input type="text" value={this.state.meta_name_ar} name="meta_name_ar" onChange={this.handleChange} className="form-control text-end input-custom-class mb-0" />
                                </div>
                                <div className="col-md-6 mb-3 form-group">
                                    <label>Meta Description in English</label>
                                    <textarea rows={4} value={this.state.meta_description_en} name="meta_description_en" onChange={this.handleChange} className="form-control h-auto input-custom-class mb-0" />
                                </div>
                                <div className="col-md-6 mb-3 text-end form-group">
                                    <label>Meta Description  in Arabic</label>
                                    <textarea rows={4} value={this.state.meta_description_ar} name="meta_description_ar" onChange={this.handleChange} className="form-control h-auto text-end input-custom-class mb-0" />
                                </div>
                                <div className="col-md-6 mb-3 form-group">
                                    <label>Meta Keywords in English</label>
                                    <textarea rows={4} value={this.state.meta_keyword_en} name="meta_keyword_en" onChange={this.handleChange} className="form-control h-auto input-custom-class mb-0" />
                                </div>
                                <div className="col-md-6 mb-3 text-end form-group">
                                    <label>Meta Keywords in Arabic</label>
                                    <textarea rows={4} value={this.state.meta_keyword_ar} name="meta_keyword_ar" onChange={this.handleChange} className="form-control h-auto text-end input-custom-class mb-0" />
                                </div>
                                <div className="col-12 text-lg-end text-center">
                                    <div className="common-red-btn">
                                        <button className="btn red-border-btn  me-2" type="button" onClick={this.seosettingmodalclose}>
                                            Cancel
                                        </button>
                                        <button className="btn red-btn" type="button" onClick={() => this.handleSubmitSettings('seo')}>
                                            {/* <button className="btn red-btn" type="button" onClick={this.handleSEOSubmit}> */}
                                            Save
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>

                {/* -----------------store status setting--------------------------- */}
                <Modal
                    dialogClassName="modal-dialog-centered cust-modal-white-content"
                    className="cust-white-modal"
                    ref={(el) => {
                        this.dialog = el;
                    }}
                    show={this.state.statusSettingmodal}
                    onHide={this.statussettingmodalclose}
                    size="md"
                >
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">{settingLanguage.storestatus}</h1>
                        </Modal.Title>
                        <button type="button" onClick={this.statussettingmodalclose} className="close btn-close"></button>
                    </Modal.Header>
                    <Modal.Body>
                        <form className="comn-set-modal">
                            <div className="row modal-form cust-white-modal setting-cart-modal align-items-center">
                                <div className="col-6 mb-3 form-group">
                                    <label>{settingLanguage.Maintenancemode}</label>
                                </div>
                                <div className="col-6 mb-3 text-end">
                                    <label className="switch me-4 ">
                                        <input type="checkbox" onChange={(e) => { this.setState({ maintance_mode: e.target.checked }) }} checked={this.state.maintance_mode} />
                                        <div className="slider round" />
                                        <div className="on-off-text" />
                                    </label>
                                </div>
                                <div className="col-12 mb-3 form-group">
                                    <label className="">{settingLanguage.Maintenancenote}</label>
                                    <textarea name="maintance_note" onChange={this.handleChange} value={this.state.maintance_note} className="form-control input-custom-class mb-0 h-auto" rows={4} />
                                </div>
                                <div className="col-12 text-lg-end text-center">
                                    <div className="common-red-btn">
                                        <button className="btn red-border-btn  me-2" type="button" onClick={this.statussettingmodalclose}>
                                            {settingLanguage.Cancel}
                                        </button>
                                        <button className="btn red-btn" type="button" onClick={() => this.handleSubmitSettings('store')}>
                                            {/* <button className="btn red-btn" type="button" onClick={this.handleSubmitStoreStatus}> */}
                                            {settingLanguage.Save}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>

                {/* -----------------------terms and condition setting------------ */}
                <Modal
                    dialogClassName="modal-dialog-centered cust-modal-white-content"
                    className="cust-white-modal"
                    ref={(el) => {
                        this.dialog = el;
                    }}
                    show={this.state.termsSettingModal}
                    onHide={this.termsSettingModalClose}
                    size="lg"
                >
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">Terms & Conditions</h1>
                        </Modal.Title>
                        <button type="button" onClick={this.termsSettingModalClose} className="close btn-close"></button>
                    </Modal.Header>
                    <Modal.Body>
                        <form className="comn-set-modal">
                            <div className="row modal-form cust-white-modal setting-cart-modal">
                                <div className="col-md-6 mb-3 form-group">
                                    <label>Term and Conditions Title in English</label>
                                    <input type="text" name="tc_en" value={this.state.tc_en} onChange={this.handleChange} className="form-control input-custom-class mb-0" placeholder="Terms & Conditions" />
                                </div>
                                <div className="col-md-6 mb-3 form-group">
                                    <label>Term and Conditions in Arabic</label>
                                    <input type="text" name="tc_ar" value={this.state.tc_ar} onChange={this.handleChange} className="form-control input-custom-class mb-0" placeholder="مﺎﻜﺣﺄﻟو طوﺮﺸﻟا" />
                                </div>
                                <div className="col-md-6 mb-3 form-group">
                                    <label>Term and Conditions in English</label>
                                    <CKEditor
                                        editor={ClassicEditor}
                                        data={this.state.tc_content_en}
                                        onChange={(event, editor) => {
                                            this.setState({ tc_content_en: editor.getData() })
                                        }}
                                    />
                                </div>
                                <div className="col-md-6 mb-3 form-group arabic-editor">
                                    <label>Term and Conditions in Arabic</label>
                                    <CKEditor
                                        editor={ClassicEditor}
                                        data={this.state.tc_content_ar}
                                        onChange={(event, editor) => {
                                            this.setState({ tc_content_ar: editor.getData() })
                                        }}
                                    />
                                </div>
                                <div className="col-12 text-lg-end text-center">
                                    <div className="common-red-btn">
                                        <button className="btn red-border-btn  me-2" type="button" onClick={this.termsSettingModalClose}>
                                            Cancel
                                        </button>
                                        <button className="btn red-btn" type="button" onClick={this.handleSubmitTermsCondition}>
                                            Save
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>

                {/* -----------------------privacy policy setting------------ */}

                <Modal
                    dialogClassName="modal-dialog-centered cust-modal-white-content"
                    className="cust-white-modal"
                    ref={(el) => {
                        this.dialog = el;
                    }}
                    show={this.state.privacyPolicySettingModal}
                    onHide={this.privacyPolicySettingModalClose}
                    size="lg"
                >
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">Privacy policy</h1>
                        </Modal.Title>
                        <button type="button" onClick={this.privacyPolicySettingModalClose} className="close btn-close"></button>
                    </Modal.Header>
                    <Modal.Body>
                        <form className="comn-set-modal">
                            <div className="row modal-form cust-white-modal setting-cart-modal">
                                <div className="col-md-6 mb-3 form-group">
                                    <label>Privacy Policy Title in English</label>
                                    <input type="text" onChange={this.handleChange} name="privacy_en" value={this.state.privacy_en} className="form-control input-custom-class mb-0" placeholder="Privacy policy" />
                                </div>
                                <div className="col-md-6 mb-3 form-group text-end">
                                    <label>Privacy Policy Title in Arabic</label>
                                    <input dir="rtl" type="text" onChange={this.handleChange} name="privacy_ar" value={this.state.privacy_ar} className="form-control input-custom-class mb-0" placeholder="مﺎﻜﺣﺄﻟو طوﺮﺸﻟا" />
                                </div>
                                <div className="col-md-6 mb-3 form-group h-100">
                                    <label>Privacy Policy in English</label>
                                    <CKEditor
                                        editor={ClassicEditor}
                                        data={this.state.privacy_content_en}
                                        onChange={(event, editor) => {
                                            this.setState({ privacy_content_en: editor.getData() })
                                        }}
                                    />
                                </div>
                                <div className="col-md-6 mb-3 form-group h-100  arabic-editor">
                                    <label>Privacy Policy in Arabic</label>
                                    <CKEditor
                                        editor={ClassicEditor}
                                        data={this.state.privacy_content_ar}
                                        onChange={(event, editor) => {
                                            this.setState({ privacy_content_ar: editor.getData() })
                                        }}
                                    />
                                </div>
                                <div className="col-12 text-lg-end text-center">
                                    <div className="common-red-btn">
                                        <button className="btn red-border-btn  me-2" type="button" onClick={this.privacyPolicySettingModalClose}>
                                            Cancel
                                        </button>
                                        <button className="btn red-btn" type="button" onClick={this.handleSubmitPrivacyPolicy}>
                                            Save
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>

                {/* ----------------return & refund policy----------------------- */}
                <Modal
                    dialogClassName="modal-dialog-centered cust-modal-white-content"
                    className="cust-white-modal"
                    ref={(el) => {
                        this.dialog = el;
                    }}
                    show={this.state.returnSettingModal}
                    onHide={this.returnSettingModalClose}
                    size="lg"
                >
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">Return & Refund policy</h1>
                        </Modal.Title>
                        <button type="button" onClick={this.returnSettingModalClose} className="close btn-close"></button>
                    </Modal.Header>
                    <Modal.Body>
                        <form className="comn-set-modal">
                            <div className="row modal-form cust-white-modal setting-cart-modal">
                                <div className="col-md-6 mb-3 form-group">
                                    <label>Return Policy  Title in English</label>
                                    <input type="text" onChange={this.handleChange} name="return_en" value={this.state.return_en} className="form-control input-custom-class mb-0" placeholder="Privacy policy" />
                                </div>
                                <div className="col-md-6 mb-3 form-group text-end">
                                    <label>Return Policy  Title in Arabic</label>
                                    <input dir="rtl" type="text" onChange={this.handleChange} name="return_ar" value={this.state.return_ar} className="form-control input-custom-class mb-0" placeholder="مﺎﻜﺣﺄﻟو طوﺮﺸﻟا" />
                                </div>
                                <div className="col-md-6 mb-3 form-group h-100">
                                    <label>Return Policy in English</label>
                                    <CKEditor
                                        editor={ClassicEditor}
                                        data={this.state.return_content_en}
                                        onChange={(event, editor) => {
                                            this.setState({ return_content_en: editor.getData() })
                                        }}
                                    />
                                </div>
                                <div className="col-md-6 mb-3 form-group h-100  arabic-editor">
                                    <label>Return Policy in Arabic</label>
                                    <CKEditor
                                        editor={ClassicEditor}
                                        data={this.state.return_content_ar}
                                        onChange={(event, editor) => {
                                            this.setState({ return_content_ar: editor.getData() })
                                        }}
                                    />
                                </div>
                                <div className="col-12 text-lg-end text-center">
                                    <div className="common-red-btn">
                                        <button className="btn red-border-btn  me-2" type="button" onClick={this.privacyPolicySettingModalClose}>
                                            Cancel
                                        </button>
                                        <button className="btn red-btn" type="button" onClick={this.handleSubmitReturnPolicy}>
                                            Save
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>

                {/* --------------faq settings----------------------- */}
                <Modal
                    dialogClassName="modal-dialog-centered cust-modal-white-content"
                    className="cust-white-modal"
                    ref={(el) => {
                        this.dialog = el;
                    }}
                    show={this.state.faqsettingmodal}
                    onHide={this.faqsettingmodalClose}
                    size="xl"
                >
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">FAQs</h1>
                        </Modal.Title>
                        <button type="button" onClick={this.faqsettingmodalClose} className="close btn-close"></button>
                    </Modal.Header>
                    <Modal.Body>
                        <form>
                            <div className="row modal-form cust-white-modal setting-cart-modal ">
                                <div className="col-12 mb-3">
                                    <Accordion className="faq-set-box">
                                        {this.state.inputList.map((item, i) => {
                                            return (
                                                <Accordion.Item eventKey={i} key={item.que_en} flush>
                                                    <Accordion.Header>
                                                        <div className="row w-100">
                                                            <div className="col-md-6 mb-3">
                                                                <input className="form-control red-text-class fw-normal input-custom-class mb-0" type="text" placeholder="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do ?" value={item.que_en} name="que_en" onChange={(e) => this.handleInputChange(e, i)} />
                                                            </div>
                                                            <div className="col-md-6 mb-3">
                                                                <input dir="rtl" className="form-control red-text-class fw-normal input-custom-class mb-0" type="text" placeholder="؟ تﺎﺒﻏر ﻲﻓ نﻮﻤﺋﺎﻬﻟا ﺔﻈﺤﻠﻟا ةﻮﺸﻨﺑ نﻮﻧﻮﺘﻔﻤﻟا لﺎﺟﺮﻟا ءﺎﻟﺆﻫ ﺮﻜﻨﺘﺴﻧو ﺐﺠﺸﻧ ﺮﺧﺂﻟ" value={item.que_ar} name="que_ar" onChange={(e) => this.handleInputChange(e, i)} />
                                                            </div>
                                                            {
                                                                this.state.inputList.length !== 1 &&
                                                                <button className="bg-transparent border-0 red-close" type="button" onClick={() => this.handleRemoveClick(i)}>
                                                                    <i className="bi bi-x-circle"></i>
                                                                </button>
                                                            }
                                                            {
                                                                this.state.inputList.length - 1 === i &&
                                                                <button type="button" className="bg-transparent border-0 add-btn-faq" onClick={this.handleAddClick}>
                                                                    <i className="bi bi-plus-circle"></i>
                                                                </button>
                                                            }
                                                        </div>
                                                    </Accordion.Header>
                                                    <Accordion.Body className="pt-0">
                                                        <div className="d-flex align-items-baseline">
                                                            <div className="row w-100">
                                                                <div className="col-md-6 mb-3">
                                                                    <textarea className="form-control input-custom-class h-auto mb-0" rows={5} placeholder="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do ?" value={item.ans_en} name="ans_en" onChange={(e) => this.handleInputChange(e, i)} />
                                                                </div>
                                                                <div className="col-md-6 mb-3">
                                                                    <textarea dir="rtl" className="form-control input-custom-class h-auto mb-0" rows={5} placeholder="؟ تﺎﺒﻏر ﻲﻓ نﻮﻤﺋﺎﻬﻟا ﺔﻈﺤﻠﻟا ةﻮﺸﻨﺑ نﻮﻧﻮﺘﻔﻤﻟا لﺎﺟﺮﻟا ءﺎﻟﺆﻫ ﺮﻜﻨﺘﺴﻧو ﺐﺠﺸﻧ ﺮﺧﺂﻟ" value={item.ans_ar} name="ans_ar" onChange={(e) => this.handleInputChange(e, i)} />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </Accordion.Body>
                                                </Accordion.Item>
                                            )
                                        })}
                                    </Accordion>
                                </div>
                                <div className="col-8 text-end">
                                    <div className="common-red-btn">
                                        <button className=" red-border-btn  me-2" type="button" onClick={this.faqsettingmodalClose}>
                                            Cancel
                                        </button>
                                        <button className=" red-btn" type="button" onClick={this.handleSubmitFAQ}>
                                            Save
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>

                {/* -----------------------------------------google-------------------------------------- */}
                <Modal
                    dialogClassName="modal-dialog-centered cust-modal-white-content"
                    className="cust-white-modal"
                    ref={(el) => {
                        this.dialog = el;
                    }}
                    show={this.state.GoogleModal}
                    onHide={this.googleHide}
                    size="lg"
                >
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">Google Integrations</h1>
                        </Modal.Title>
                        <button type="button" onClick={this.googleHide} className="close btn-close"></button>
                    </Modal.Header>
                    <Modal.Body>
                        <form className="comn-set-modal">
                            <div className="row modal-form cust-white-modal setting-cart-modal">
                                <div className="col-lg-6 mb-3 form-group">
                                    <label>G-Tag</label>
                                    <input type="text" name="gooleID" value={this.state.gooleID} onChange={this.handleChange} className="form-control input-custom-class mb-0" placeholder="G-XXXXXXXXXX" />
                                </div>

                                <div className="col-12 text-lg-end text-center">
                                    <div className="common-red-btn">
                                        <button className="btn red-border-btn  me-2" type="button" onClick={this.googleHide}>
                                            Cancel
                                        </button>
                                        <button className="btn red-btn" type="button" onClick={() => this.handleItegrationSubmit('google')}>
                                            Save
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>

                {/* -----------------------------------------meta-------------------------------------- */}
                <Modal
                    dialogClassName="modal-dialog-centered cust-modal-white-content"
                    className="cust-white-modal"
                    ref={(el) => {
                        this.dialog = el;
                    }}
                    show={this.state.MetaModal}
                    onHide={this.OnMetaHide}
                    size="lg"
                >
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">Meta Integrations</h1>
                        </Modal.Title>
                        <button type="button" onClick={this.OnMetaHide} className="close btn-close"></button>
                    </Modal.Header>
                    <Modal.Body>
                        <form className="comn-set-modal">
                            <div className="row modal-form cust-white-modal setting-cart-modal">
                                <div className="col-lg-6 mb-3 form-group">
                                    <label>Enter PixelId</label>
                                    <input type="text" name="metaId" value={this.state.metaId} onChange={this.handleChange} className="form-control input-custom-class mb-0" placeholder="XXXXXXXXXXXXXXXX" />
                                </div>

                                <div className="col-12 text-lg-end text-center">
                                    <div className="common-red-btn">
                                        <button className="btn red-border-btn  me-2" type="button" onClick={this.OnMetaHide}>
                                            Cancel
                                        </button>
                                        <button className="btn red-btn" type="button" onClick={() => this.handleItegrationSubmit('meta')}>
                                            Save
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>

                {/* -----------------------------------------snapchat-------------------------------------- */}
                <Modal
                    dialogClassName="modal-dialog-centered cust-modal-white-content"
                    className="cust-white-modal"
                    ref={(el) => {
                        this.dialog = el;
                    }}
                    show={this.state.SnapChatModal}
                    onHide={this.OnSnapChatHide}
                    size="lg"
                >
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">SnapChat Integrations</h1>
                        </Modal.Title>
                        <button type="button" onClick={this.OnSnapChatHide} className="close btn-close"></button>
                    </Modal.Header>
                    <Modal.Body>
                        <form className="comn-set-modal">
                            <div className="row modal-form cust-white-modal setting-cart-modal">
                                <div className="col-lg-6 mb-3 form-group">
                                    <label>Enter PixelId</label>
                                    <input type="text" name="SanpchatId" value={this.state.SanpchatId} onChange={this.handleChange} className="form-control input-custom-class mb-0" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" />
                                </div>

                                <div className="col-12 text-lg-end text-center">
                                    <div className="common-red-btn">
                                        <button className="btn red-border-btn  me-2" type="button" onClick={this.OnSnapChatHide}>
                                            Cancel
                                        </button>
                                        <button className="btn red-btn" type="button" onClick={() => this.handleItegrationSubmit('snapchat')}>
                                            Save
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>

                {/* -------------------------------------------tik-tok------------------------------------------ */}
                <Modal
                    dialogClassName="modal-dialog-centered cust-modal-white-content"
                    className="cust-white-modal"
                    ref={(el) => {
                        this.dialog = el;
                    }}
                    show={this.state.TiktokModal}
                    onHide={this.OnTiktokHide}
                    size="lg"
                >
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">Tiktok Integrations</h1>
                        </Modal.Title>
                        <button type="button" onClick={this.OnTiktokHide} className="close btn-close"></button>
                    </Modal.Header>
                    <Modal.Body>
                        <form className="comn-set-modal">
                            <div className="row modal-form cust-white-modal setting-cart-modal">
                                <div className="col-lg-6 mb-3 form-group">
                                    <label>Enter PixelId</label>
                                    <input type="text" name="SanpchatId" value={this.state.TiktokId} onChange={this.handleChange} className="form-control input-custom-class mb-0" placeholder="xxxxxxxxxxxxxxxxxxxx" />
                                </div>

                                <div className="col-12 text-lg-end text-center">
                                    <div className="common-red-btn">
                                        <button className="btn red-border-btn  me-2" type="button" onClick={this.OnTiktokHide}>
                                            Cancel
                                        </button>
                                        <button className="btn red-btn" type="button" onClick={() => this.handleItegrationSubmit('tiktok')}>
                                            Save
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>

                {/* ------------------------------------------------Banner-model---------------------------------------- */}
                <Modal
                    dialogClassName="modal-dialog-centered cust-modal-white-content"
                    className="cust-white-modal"
                    ref={(el) => {
                        this.dialog = el;
                    }}
                    show={this.state.BannerModelShow}
                    onHide={this.bannerModelClose}
                    size="lg"
                >
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">{settingLanguage.bannerSetting}</h1>
                        </Modal.Title>
                        <button type="button" onClick={this.bannerModelClose} className="close btn-close"></button>
                    </Modal.Header>
                    <Modal.Body>
                        <form className="comn-set-modal">
                            <div className="row modal-form cust-white-modal setting-cart-modal align-items-center">
                                <div className="col-6 mb-3 form-group">
                                    <label>{settingLanguage.bannerPopup}</label>
                                </div>
                                <div className="col-6 mb-3 text-end">
                                    <label className="switch me-4 ">
                                        <input type="checkbox" checked={this.state.banerActive} onChange={(e) => { this.setState({ banerActive: e.target.checked }) }} />
                                        <div className="slider round" />
                                        <div className="on-off-text" />
                                    </label>
                                </div>
                                {this.state.BannerImg !== "" &&
                                    <div className="avatar-preview avatar-preview-cust">
                                        <div id="imagePreview" className="overflow-hidden mx-auto">
                                            <div className="banner-main-box-ad w-100 h-100">
                                                <div className="w-100 h-100">
                                                    <img id='pcEnglishPreview' src={this.state.BannerImg} className="w-100 h-100" alt="Image" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                }
                                <div className="avatar-edit text-center">
                                    <input className="d-none" type="file" id="imageUpload1" name='pcEnglish' onChange={this.handleImageChange} accept=".png, .jpg, .jpeg" />
                                    <label className="btn red-btn mt-3" htmlFor="imageUpload1">
                                        <i className="bi bi-upload me-2" />
                                        {/* {ButtonLanguage.Uploadimage} */}upload
                                    </label>
                                </div>
                                <div className="col-lg-6 mb-3 form-group">
                                    <label>Enter CouponCode</label>
                                    <input type="text" name="CoponCode" value={this.state.CoponCode} onChange={this.handleChange} className="form-control input-custom-class mb-0" placeholder="copone code" />
                                    {this.state.codeValidation && <span className="text-danger">Please Add CouponCode*</span>}
                                </div>
                                <div className="col-12 text-lg-end text-center">
                                    <div className="common-red-btn">
                                        <button className="btn red-border-btn  me-2" onClick={this.bannerModelClose}>
                                            {settingLanguage.Cancel}
                                        </button>
                                        <button className="btn red-btn" type="button" onClick={() => this.handleSubmitSettings('popup')}>
                                            {/* <button className="btn red-btn" type="button" onClick={this.handleSubmitOffer}> */}
                                            {settingLanguage.Save}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>
                {/* -----------------------------------------------admin-setting-model------------------------------------------------- */}
                <Modal
                    dialogClassName="modal-dialog-centered cust-width-modal modal-dialog-scrollable"
                    className="edit-user-modal cust-modal"
                    ref={(el) => {
                        this.dialog = el;
                    }}
                    show={this.state.adminModelShow}
                    onHide={this.adminModelClose}
                >
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">{settingLanguage.adminsContact}</h1>
                        </Modal.Title>
                        <button type="button" onClick={this.adminModelClose} className="close btn-close"></button>
                    </Modal.Header>
                    <Modal.Body>
                        <div className="white-box cuts-popup-tbl p-3">
                            <div className="form-group pb-3">
                                <div className="d-md-flex align-items-end">
                                    <div className="w-100 mb-3 mb-md-0 src-with-btn-class position-relative">
                                        <label>{settingLanguage.phone}</label>
                                        <PhoneInput name='AdminPhone' disableCountryGuess={true} country={'sa'} disableDropdown countryCodeEditable={false} placeholder={settingLanguage.phone} value={"+" + this.state.AdminPhone} className="form-select-phone" onChange={this.handleChangePhone} />
                                    </div>
                                    <div className="w-100 ms-md-3 mb-3 mb-md-0 src-with-btn-class position-relative">
                                        <label>{settingLanguage.name}</label>
                                        <input type="text" name="AdminName" className="form-control input-custom-class mb-0" placeholder={settingLanguage.name} value={this.state.AdminName} onChange={this.handleChange} />
                                    </div>
                                    <div className="src-with-btn-class position-relative">
                                        <button type="button" className="red-btn ms-md-3 red-add-btn" onClick={() => this.addAdminDetail(false)}>{settingLanguage.add}</button>
                                    </div>
                                </div>
                            </div>
                            <div className="form-group text-center pb-3 mt-2">
                                <div className="table-responsive">
                                    <table className="table">
                                        <thead>
                                            <tr>
                                                <th>{settingLanguage.name}</th>
                                                {/* <th>{settingLanguage.eMail}</th> */}
                                                <th>{settingLanguage.phone}</th>
                                                <th>{settingLanguage.Actions}</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {this.state.AdminDetails.length > 0 &&
                                                this.state.AdminDetails.map((data, i) => (
                                                    <tr key={i}>
                                                        {/* <td>
                                                            <label className="cust-chk-bx">
                                                                <input name="" type="checkbox" onChange={(e) => this.handleCustomersCheckboxChange(e, data)} />
                                                                <span className="cust-chkmark"></span>
                                                            </label>
                                                        </td> */}
                                                        <td>{data.name}</td>
                                                        {/* <td>{data.email}</td> */}
                                                        <td>{data.phone}</td>
                                                        <td><span className="bi bi-pencil-square me-2" onClick={() => this.editAdminDetail(data.id)}></span>
                                                            <span onClick={() => this.deletAdmin(data.id)}>
                                                                <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} fill="currentColor" className="bi bi-trash" viewBox="0 0 16 16">
                                                                    <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
                                                                    <path fillRule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" />
                                                                </svg>
                                                            </span>
                                                        </td>
                                                    </tr>
                                                ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <div className="form-group pb-0 my-0 mx-auto">
                            <button className="btn red-btn" type="button" onClick={this.adminModelClose}>
                                {/* <button className="btn red-btn" type="button" onClick={this.handleSubmitOffer}> */}
                                {settingLanguage.Ok}
                            </button>
                        </div>
                    </Modal.Footer>
                </Modal>
                {/* ----------------------------------------------------chat-setting---------------------------------------------------- */}
                <Modal
                    dialogClassName="modal-dialog-centered cust-modal-white-content"
                    className="cust-white-modal"
                    ref={(el) => {
                        this.dialog = el;
                    }}
                    show={this.state.chatModelShow}
                    onHide={this.chatModelClose}
                    size="md"
                >
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">{settingLanguage.chatSetting}</h1>
                        </Modal.Title>
                        <button type="button" onClick={this.chatModelClose} className="close btn-close"></button>
                    </Modal.Header>
                    <Modal.Body>
                        <form>
                            <div className="row modal-form cust-white-modal setting-cart-modal align-items-center">
                                <div className="col-12 mb-3 form-group">
                                    <ul className="d-flex align-items-center justify-content-around">
                                        <li className="d-inline-block li-mr">
                                            <label className="cust-radio">
                                                <input type="radio" id="watsapp" value={1} name="chatType" defaultChecked={this.state.chatType == 1} onChange={this.handleChange} />
                                                <span className="checkmark"></span>
                                                <span>{settingLanguage.wpChat}</span>
                                            </label>
                                        </li>
                                        <li className="d-inline-block">
                                            <label className="cust-radio">
                                                <input type="radio" id="widget" value={0} name="chatType" defaultChecked={this.state.chatType == 0} onChange={this.handleChange} />
                                                <span className="checkmark"></span>
                                                <span>{settingLanguage.widgetChat}</span>
                                            </label>
                                        </li>
                                    </ul>
                                </div>
                                <div className="col-12 mb-3 form-group">
                                    <div className="chat-phone-input">
                                        <label>{settingLanguage.phone}</label>
                                        <PhoneInput name='chatWPNumber' disableCountryGuess={true} country={'sa'} disableDropdown countryCodeEditable={false} placeholder={settingLanguage.phone} value={"+" + this.state.chatWPNumber} className="form-select-phone" onChange={this.handleChatPhone} />
                                    </div>
                                </div>
                                <div className="col-12">
                                    <div className="common-red-btn text-center">
                                        {/* <button className="btn red-border-btn  me-2" onClick={this.chatModelClose}>
                                            {settingLanguage.Cancel}
                                        </button> */}
                                        <button className="btn red-btn" type="button" onClick={() => this.handleSubmitSettings('chat')}>
                                            {/* <button className="btn red-btn" type="button" onClick={this.handleSubmitTaxSetting}> */}
                                            {settingLanguage.Save}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>

            </Adminlayout >
        );
    }
}

export default Settings;
