import React, { Component } from 'react';
import Adminlayout from '../../Components/AdminLayout/Adminlayout';
import IncludeVariationList from './IncludeVariationList';
import ExcludeVariationList from './ExcludeVariationList';
import { Dropdown } from 'react-bootstrap';
import Select from "react-select";

class CreateUserSegment extends Component {

    render() {

        // const options = [
        //     { value: 'chocolate', label: 'Chocolate' },
        //     { value: 'strawberry', label: 'Strawberry' },
        //     { value: 'vanilla', label: 'Vanilla' }
        // ]

        // const customStyles = {
        //     option: (provided, state) => ({
        //         ...provided,
        //         backgroundColor: "#fff",
        //         color: "#2d2d3b",
        //         ":hover": {
        //             color: "#a81a1c",
        //             backgroundColor: "#f4f1fc",
        //         },
        //     }),
        // };

        return (
            <Adminlayout>
                <div className="container-fluid">
                    <div className="row common-space">
                        <div className="col-12 text-sm-start text-center rtl-txt-start">
                            <div className="common-header-txt">
                                <h3>Create Audience Segment</h3>
                            </div>
                        </div>
                    </div>
                    <div className='row common-space'>
                        <div className="col-xxl-7 col-lg-10 mx-auto usr-select-info">
                            <div className="white-box mb-3 h-auto">
                                <div className="row">
                                    <IncludeVariationList />
                                    <div className="col-12 mt-2">
                                        <div className="d-flex flex-wrap">
                                            <button className="btn-comn-all-4 mt-2 me-2" >
                                                <span>Include More People</span>
                                            </button>
                                            <button id="exclude-btn-1" className="btn-comn-all-4 mt-2" >
                                                <span>Exclude People</span>
                                            </button>
                                        </div>
                                    </div>
                                    <ExcludeVariationList />
                                    <div className="col-12 my-3">
                                        <button id="exclude-btn-2" className="btn-comn-all-4 mt-2">
                                            <span>Exclude People</span>
                                        </button>
                                    </div>
                                    <div className="col-12">
                                        <div className="row">
                                            <div className="col-12 mt-3">
                                                <label className="lbl-frnt-side">Audience Name</label>
                                                <input name="audience_name" placeholder="" className="form-control input-custom-class" />
                                                <span id="create-aud" className="text-danger" style={{ display: 'none' }}>
                                                    Required !!
                                                </span>
                                            </div>
                                            <div className="col-12 mt-3 mb-3">
                                                <label className="lbl-frnt-side">Description (Optional)</label>
                                                <input name="description_name" placeholder="" className="form-control input-custom-class" />
                                            </div>
                                            <div className="col-12 cust-loction-menus">
                                                <div className="position-relative mx-auto custom-dropdown-select">
                                                    <label className="lbl-frnt-side">Location</label>
                                                    <div className="position-relative src-icons-box-new">
                                                        <select className="form-select input-custom-class" id="">
                                                            <option selected>Choose...</option>
                                                            <option value="1">One</option>
                                                            <option value="2">Two</option>
                                                            <option value="3">Three</option>
                                                        </select>
                                                        {/* <svg width="18" height="18" viewBox="0 0 18 18" fill="none" >
                                                            <path d="M7.66667 13.3333C10.7963 13.3333 13.3333 10.7963 13.3333 7.66667C13.3333 4.53705 10.7963 2 7.66667 2C4.53705 2 2 4.53705 2 7.66667C2 10.7963 4.53705 13.3333 7.66667 13.3333Z" stroke="#9CA3AF" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                            <path d="M16.6663 16.6666L13.333 13.3333" stroke="#9CA3AF" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg> */}
                                                        <div className="browse-btn-fix drop-locs-main">
                                                            <Dropdown drop="up">
                                                                <Dropdown.Toggle variant="success" id="" className="bg-transparent border-0 p-0" >
                                                                    Browse
                                                                </Dropdown.Toggle>
                                                                <Dropdown.Menu>
                                                                    <div>
                                                                        <div className="frst-top-box list-group-main">
                                                                            <div className="list-group-click cursor-pointer submenu-on-transform">
                                                                                <svg width="7" height="14" viewBox="0 0 7 14" fill="none">
                                                                                    <path d="M1.64319 12.9653L4.51019 10.0983L6.2697 8.34771C7.01101 7.6064 7.01101 6.40064 6.2697 5.65933L1.64319 1.03282C1.03584 0.425477 -0.000208383 0.86312 -0.00020842 1.71161L-0.000208639 6.72218L-0.000208882 12.2865C-0.00020892 13.1439 1.03584 13.5726 1.64319 12.9653Z" fill="#9CA3AF" />
                                                                                </svg>
                                                                            </div>
                                                                            <bdi>Countries</bdi>
                                                                            <div className="ms-auto">
                                                                                <button type="button" className="btn-select-box">
                                                                                    Select All
                                                                                </button>
                                                                                <label class="cust-chk-bx">
                                                                                    <input type="checkbox" />
                                                                                    <span class="cust-chkmark"></span>
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                        <div className="main-submenu-first">
                                                                            <ul>
                                                                                <li>
                                                                                    <div className="list-group-main">
                                                                                        <div className="list-group-click cursor-pointer submenu-on-transform">
                                                                                            <svg width="7" height="14" viewBox="0 0 7 14" fill="none">
                                                                                                <path d="M1.64319 12.9653L4.51019 10.0983L6.2697 8.34771C7.01101 7.6064 7.01101 6.40064 6.2697 5.65933L1.64319 1.03282C1.03584 0.425477 -0.000208383 0.86312 -0.00020842 1.71161L-0.000208639 6.72218L-0.000208882 12.2865C-0.00020892 13.1439 1.03584 13.5726 1.64319 12.9653Z" fill="#9CA3AF" />
                                                                                            </svg>
                                                                                        </div>
                                                                                        <bdi>1</bdi>
                                                                                        <div className="ms-auto">
                                                                                            <button type="button" className="btn-select-box">
                                                                                                Select All
                                                                                            </button>
                                                                                            <label class="cust-chk-bx">
                                                                                                <input type="checkbox" />
                                                                                                <span class="cust-chkmark"></span>
                                                                                            </label>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div className="">
                                                                                        <div className="main-submenu-inrs">
                                                                                            <strong>1</strong>
                                                                                            <div className="ms-auto">
                                                                                                <label class="cust-chk-bx">
                                                                                                    <input type="checkbox" />
                                                                                                    <span class="cust-chkmark"></span>
                                                                                                </label>
                                                                                            </div>
                                                                                        </div>

                                                                                    </div>
                                                                                </li>

                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </Dropdown.Menu>
                                                            </Dropdown>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-12 text-end py-3">
                                        <button type="submit" className="btn red-btn px-4 mx-2">
                                            <span>Create</span>
                                        </button>
                                        <button type="reset" className="white-btn mx-2">
                                            Cancel
                                        </button>
                                    </div>
                                </div>
                            </div>
                            {/* <div className="white-box h-auto mb-3" style={{ borderLeft: "5px solid #a81a1c" }}>
                                <div className="d-flex mb-3">
                                    <div className="cmn-title-class  w-100 p-0 me-3">
                                        <h2 className="pt-1 pt-sm-0">Create audience segment based on location</h2>
                                        <p className="sub-text-p">Segment your customers based on their geographic location. Send location-based promotional offers to customers to increase engagement and drive profits for your online business.</p>
                                    </div>
                                    <svg width="40" height="40" viewBox="0 0 40 40" fill="none" >
                                        <path d="M20 40C31.0457 40 40 31.0457 40 20C40 8.9543 31.0457 0 20 0C8.9543 0 0 8.9543 0 20C0 31.0457 8.9543 40 20 40Z" fill="#7343DD" />
                                        <path d="M39.9999 20C39.9999 19.8961 39.9976 19.7928 39.996 19.6893L25.9417 5.63506C25.9417 5.63506 15.6249 1.87499 14.453 11.1719C13.2812 20.4687 11 36.5 11 36.5L16.9417 39.7674C17.9537 39.9225 18.9761 40.0003 19.9999 40C31.0456 40 39.9999 31.0457 39.9999 20Z" fill="#552CB7" />
                                        <path d="M25.8462 18.1538H23.6452V13.9321C23.6452 11.9611 22.148 10.3575 20.3077 10.3575C18.4675 10.3575 16.9703 11.9611 16.9703 13.9321V18.1538H14.7693V13.9321C14.7693 10.6612 17.2539 8 20.3077 8C23.3616 8 25.8462 10.6611 25.8462 13.9321V18.1538Z" fill="#F4F2EF" />
                                        <path d="M25.8461 13.9317V18.1538H23.6449V13.9317C23.6449 11.9609 22.1478 10.3575 20.3076 10.3575V8C23.3614 8 25.8461 10.6611 25.8461 13.9317Z" fill="#E5E1DC" />
                                        <path d="M24.6571 32H15.9583C13.7722 32 12 30.2308 12 28.0485V18.1539H28.6154V28.0485C28.6154 30.2308 26.8432 32 24.6571 32Z" fill="#FFC136" />
                                        <path d="M28.6153 18.1539V28.0485C28.6153 30.2308 26.8431 32 24.657 32H20.3076V18.1539H28.6153Z" fill="#F4A300" />
                                        <path d="M22.1537 23.2801C22.1537 21.9784 21.3272 20.9231 20.3076 20.9231C19.288 20.9231 18.4614 21.9784 18.4614 23.2801C18.4614 24.1607 18.8399 24.928 19.4002 25.3326V29.2308H21.2149V25.3326C21.7752 24.928 22.1537 24.1607 22.1537 23.2801Z" fill="#655665" />
                                        <path d="M22.1538 23.2798C22.1538 24.1604 21.7752 24.9278 21.2147 25.3325V29.2308H20.3076V20.9231C21.3271 20.9231 22.1538 21.9781 22.1538 23.2798Z" fill="#493E49" />
                                    </svg>
                                </div>
                                <button type="button" className="btn red-btn px-4 mx-2" >
                                    <span>Create</span>
                                </button>
                            </div> */}
                        </div>
                    </div>
                </div>
            </Adminlayout>
        );
    }
}

export default CreateUserSegment;
