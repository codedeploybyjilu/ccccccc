import React, { Component } from 'react';
import Adminlayout from '../../Components/AdminLayout/Adminlayout';
import DataTable from '../../Components/DataTable';
import { textFilter } from 'react-bootstrap-table2-filter';
import { confirmAlert } from 'react-confirm-alert';
import Profile from '../../images/data-profile.png'
import LanguageContext from '../../contexts/languageContext'
import { titleEnglish, titleArabic, AdminArabic, AdminEnglish, API_Path } from '../../const';
import { Dropdown } from 'react-bootstrap';
import { PostApi } from '../../helper/APIService';
import toastr from 'toastr';


class Admin extends Component {
    static contextType = LanguageContext;
    constructor(props) {
        super(props);
        this.state = {
            page: 1,
            sizePerPage: 10,
            totalSize: 100,
            defaultSorted: [{
                dataField: 'id',
                order: 'asc'
            }],
            order_data: [

            ],
        }

    }

    componentDidMount = () => {
        let data = {}
        let path = API_Path.getAdmin


        const GetAdminPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        GetAdminPromise.then((res) => {
            if (res) {
                if (res.data.success) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ order_data: res.data.data })

                } else {
                    // toastr.error(res.data.message)
                }

            }
        });
    }

    handleStatusChange = (e, id) => {
        if (e.target.checked) {

            let path = API_Path.statusAdmin

            let data = {
                id: id
            }

            const ChangeStatusPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            ChangeStatusPromise.then((res) => {
                if (res) {
                    if (res.data.success) {
                        document.getElementById(id).checked = true
                    } else {
                        toastr.error(res.data.message)
                    }
                }
            });


        } else {
            let path = API_Path.statusAdmin

            let data = {
                id: id
            }

            const ChangeStatusPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            ChangeStatusPromise.then((res) => {
                if (res) {
                    if (res.data.success) {
                        document.getElementById(id).checked = false
                    } else {
                        toastr.error(res.data.message)
                    }
                }
            });
        }
    }

    edit_userClose = () => {
        this.setState({ search_show: false });
    }

    edit_userShow = (e) => {
        e.preventDefault()
        this.setState({ search_show: true });
    }
    edit_handleShow = (e) => {
        e.preventDefault()
        this.setState({ search_show: true });
    }
    get_order_data = () => {
        // console.log('come');
    }
    delete_record = (id) => {
        confirmAlert({
            customUI: ({ onClose }) => {
                return (
                    <div className='custom-ui'>
                        <h1>Are you sure?</h1>
                        <p>You want to delete this file?</p>
                        <button className="btn red-btn me-2" onClick={onClose}>No</button>
                        <button className="btn red-btn"
                            onClick={() => {
                                this.finaly_delete_record(id);
                                onClose();
                            }}
                        >
                            Yes, Delete it!
                        </button>
                    </div>
                );
            }
        });
    }

    finaly_delete_record = (id) => {
        alert(id)
    }
    handleTableChange = (type, { page, sizePerPage, filters, sortField, sortOrder }) => {
        switch (type) {
            case "pagination":
                this.setState({
                    page,
                    sizePerPage
                }, () => this.get_order_data());
                break;
            case "filter":
                let search_val = this.state.search_val;
                let newFilter = {};
                if (Object.keys(filters).length) {
                    for (const dataField in filters) {
                        newFilter[dataField] = filters[dataField].filterVal;
                    }
                    newFilter = {
                        ...search_val,
                        ...newFilter
                    };
                } else {
                    newFilter = {
                        title: '',
                        indicator: '',
                        definition: ''
                    };
                }
                this.setState({
                    search_val: newFilter
                }, () => this.get_order_data())
                break;
            case "sort":
                this.setState({
                    defaultSorted: [{
                        dataField: sortField,
                        order: sortOrder
                    }]
                }, () => this.get_order_data());
                break;
            default:
                break;
        }
        return true;
    }







    render() {
        let Language = this.context.language === 'english' ? AdminEnglish : AdminArabic;
        let titleLanguage = this.context.language === "english" ? titleEnglish : titleArabic;

        const columns = [
            {
                dataField: 'id',
                text: 'Id',
                hidden: true,
            },
            {
                dataField: 'image',
                text: Language.image,
                sort: true,
                hidden: false,
                classes: '',
                formatter: (cell, row, rowIndex) => {
                    return (
                        <React.Fragment>
                            <img src={Profile} alt="" />

                        </React.Fragment>
                    );
                }
            },
            {
                dataField: 'first_name',
                text: Language.firstName,
                sort: true,
                hidden: false,
                filter: textFilter({
                    placeholder: titleLanguage.search
                }),
            },
            {
                dataField: 'last_name',
                text: Language.lastName,
                sort: true,
                hidden: false,
                filter: textFilter({
                    placeholder: titleLanguage.search
                }),
            },
            {
                dataField: 'email',
                text: Language.emailAddress,
                sort: true,
                hidden: false,
                filter: textFilter({
                    placeholder: titleLanguage.search
                }),
            },
            {
                dataField: 'phone',
                text: Language.phoneNumber,
                sort: true,
                hidden: false,
                filter: textFilter({
                    placeholder: titleLanguage.search
                }),
            },
            {
                dataField: 'role',
                text: Language.role,
                sort: true,
                hidden: false,
                filter: textFilter({
                    placeholder: titleLanguage.search
                }),
            },
            {
                dataField: 'status',
                text: Language.status,
                sort: true,
                hidden: false,
                classes: '',
                formatter: (cell, row, rowIndex) => {
                    return (
                        <React.Fragment>
                            <label className="switch ">

                                {cell == 1 ? <input type="checkbox" id={row.id} onChange={(e) => this.handleStatusChange(e, row.id)} defaultChecked /> : <input id={row.id} onChange={(e) => this.handleStatusChange(e, row.id)} type="checkbox" />}
                                <div className="slider round" />
                                {/* <div className="text"></div> */}
                            </label>

                        </React.Fragment>
                    );
                }
            },
            {
                dataField: 'action',
                text: Language.action,
                hidden: false,
                csvExport: false,
                headerClasses: 'text-center',
                classes: 'text-end',
                formatter: (cell, row, rowIndex) => {
                    return (
                        <React.Fragment>
                            <Dropdown className="cust-drop">
                                <Dropdown.Toggle className="bg-transparent " id="dropdown-basic" align="end">
                                    <svg xmlns="http://www.w3.org/2000/svg" width={16} height={16} fill="currentColor" className="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                        <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                    </svg>
                                </Dropdown.Toggle>
                                <Dropdown.Menu>
                                    <Dropdown.Item href={"/admin-details/" + row.id}>
                                        <svg width={20} height={15} viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M10 14C8.35987 14.0204 6.7367 13.6665 5.254 12.965C4.10469 12.4042 3.07265 11.6298 2.213 10.683C1.30243 9.70413 0.585467 8.56167 0.1 7.31601L0 7.00001L0.105 6.68401C0.590815 5.43944 1.30624 4.29728 2.214 3.31701C3.07334 2.37032 4.10504 1.59587 5.254 1.03501C6.73671 0.333598 8.35988 -0.0203796 10 9.39617e-06C11.6401 -0.0203444 13.2633 0.333631 14.746 1.03501C15.8953 1.59574 16.9274 2.3702 17.787 3.31701C18.6993 4.29456 19.4165 5.43737 19.9 6.68401L20 7.00001L19.895 7.31601C18.3262 11.3998 14.3742 14.0694 10 14ZM10 2.00001C6.59587 1.89334 3.47142 3.8751 2.117 7.00001C3.4712 10.1251 6.59579 12.107 10 12C13.4041 12.1064 16.5284 10.1247 17.883 7.00001C16.5304 3.87359 13.4047 1.89109 10 2.00001ZM10 10C8.55733 10.0096 7.30937 8.99737 7.02097 7.58378C6.73256 6.1702 7.48427 4.75003 8.81538 4.19367C10.1465 3.63731 11.6852 4.10014 12.4885 5.29852C13.2919 6.49689 13.1354 8.09609 12.115 9.11601C11.5563 9.68127 10.7948 9.99957 10 10Z" fill="#2D2D3B" />
                                        </svg>
                                        <span>View</span>
                                    </Dropdown.Item>
                                    <Dropdown.Item href="#" onClick={() => this.delete_record(row.id)}>
                                        <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} fill="currentColor" className="bi bi-trash" viewBox="0 0 16 16">
                                            <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
                                            <path fillRule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" />
                                        </svg>
                                        <span>Delete</span>
                                    </Dropdown.Item>
                                </Dropdown.Menu>
                            </Dropdown>
                        </React.Fragment>
                    );
                }
            }
        ]
        return (
            <Adminlayout>
                <div className={"container-fluid " + Language.rtlEnabled}>
                    <div className="row common-space align-items-center">
                        <div className="col-sm-4 text-sm-start text-center rtl-txt-start">
                            <div className="common-header-txt">
                                <h3>{Language.admin}</h3>
                            </div>
                        </div>
                        <div className="col-sm-8 text-sm-end text-center rtl-txt-end">
                            <div className="common-red-btn">
                                <a href="#" className="btn black-btn me-2">{Language.exportList}</a>
                                <a href="/add-admin" className="btn red-btn">{Language.createAdmin}</a>
                            </div>
                        </div>
                    </div>
                    <div className="row common-space">
                        <div className="col-md-12">
                            <div className="white-box">
                                <div className="custom-table">
                                    <div className="table-responsive dataTables_wrapper no-footer">
                                        {
                                            this.state.order_data &&
                                            <DataTable
                                                keyField='id'
                                                loading={this.state.loading}
                                                columns={columns}
                                                data={this.state.order_data}
                                                page={this.state.page}
                                                sizePerPage={this.state.sizePerPage}
                                                totalSize={this.state.totalSize}
                                                defaultSorted={this.state.defaultSorted}
                                                onTableChange={this.handleTableChange}
                                                language={this.context.language}
                                                selectableRows
                                            />
                                        }
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </Adminlayout>
        );
    }
}

export default Admin;