import React, { Component } from 'react'
import { Modal } from 'react-bootstrap'
import { buttonEnglish, buttonArabic, APIBaseUrl, API_Path } from '../../const'
import LanguageContext from "../../contexts/languageContext";

export default class EditBanner extends Component {
    static contextType = LanguageContext;
    state = {
        name: ''
    }
    componentDidMount() {
        this.setState({ name: this.props.name })
    }

    handleChange = (e) => {
        this.setState({ name: e.target.value })
    }

    render() {
        let ButtonLanguage = this.context.language === "english" ? buttonEnglish : buttonArabic;
        return (
            <Modal
                dialogClassName="modal-dialog-centered"
                className="edit-user-modal cust-modal"
                size="xl"
                ref={(el) => {
                    this.dialog = el
                }}
                show={this.props.show}
                onHide={this.props.closeEditBanner}
            >
                <Modal.Header>
                    <Modal.Title>
                        <h1 className="modal-title">Add Banner </h1>
                    </Modal.Title>
                    <button
                        type="button"
                        onClick={this.props.closeEditBanner}
                        className="close btn-close"
                    ></button>
                </Modal.Header>
                <Modal.Body>
                    <div className="row">
                        <div className="col-md-12 form-group">
                            <label>Banner Name</label>

                            <input type='text' value={this.state.name} onChange={this.handleChange} className="form-control input-custom-class" />
                        </div>
                        <div className="col-md-12 form-group">
                            <button onClick={this.handleSubmit} className="red-btn">{ButtonLanguage.submit}</button>
                        </div>
                    </div>
                </Modal.Body>
            </Modal>

        )
    }
}
