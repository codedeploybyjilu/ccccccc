import React, { Component } from 'react'
import logo from '../../images/logo.svg'
import logoAR from '../../images/arabic-logo.svg'
import Barcode from "react-barcode";
import QRCode from "react-qr-code";
import html2pdf from 'html2pdf.js';
import { PostApi } from '../../helper/APIService';
import { API_Path } from '../../const';
import moment from 'moment';
import ReactToPrint from 'react-to-print';

export class Invoice extends Component {
    constructor(props) {
        super(props)
        this.state = {
            barcode: "",
            qeneratecode: "",
            barcodeWidth: 4,
            orderDetails: '',
            totalQTY: ''
        }
        // this.componentRef = React.createRef(null)
    }

    componentDidMount() {
        let url = window.location.href;
        let idString = url?.split("/")[url?.split("/")?.length - 1];
        let id = parseInt(idString);
        this.getOrderDetails(id)
    }

    handleDownload = () => {
        let content = document.getElementsByClassName('white-pdf-box-en-ar')[0].innerHTML
        var opt = {
            margin: 0,
            filename: 'INVOICE-' + this.state.barcode + '.pdf',
            displayHeaderFooter: true,
            pagebreak: { mode: 'legacy' },
            image: { type: 'jpeg', quality: 1 },
            enableLinks: true,
            html2canvas: { dpi: 72, scale: 3 },
            jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
        };
        html2pdf().set(opt).from(content).toContainer().toCanvas().toImg().toPdf().save();
    }

    getOrderDetails = (id) => {
        let data = {
            id: id,
        };
        const getDetailDataPromise = new Promise((resolve) => {
            resolve(PostApi(API_Path.getOrderById, data));
        });
        getDetailDataPromise.then((res) => {
            if (res) {
                let data = res.data.data
                let sum = data[0].order_item.reduce((a, b) => a = a + b.quantity, 0)
                this.setState({ orderDetails: data, barcode: res.data.data[0].id, totalQTY: sum })
            }

        })
    }

    render() {
        let option = {
            width: 5,
            font: "Poppins",
            rodchanges: null,
            format: "CODE128"
        }
        return (
            <div className='content-wrapper-section m-0 p-0'>
                <div className='container'>
                    <div className='row'>
                        <div className='col-6'>
                            <div className='m-1 p-2 text-end D-hide'>
                                <ReactToPrint trigger={() => {
                                    return (
                                        <button className="btn red-btn px-5">PRINT</button>
                                    )
                                }}
                                    content={() => this.componentRef}
                                // onBeforePrint={() => {
                                //     const tfoot = document.querySelector('.print-tfoot');
                                //     if (tfoot) {
                                //         tfoot.classList.add('print-on-last-page');
                                //     }
                                // }}
                                // onAfterPrint={() => {
                                //     const tfoot = document.querySelector('.print-tfoot');
                                //     if (tfoot) {
                                //         tfoot.classList.remove('print-on-last-page');
                                //     }
                                // }}
                                />
                            </div>
                            {/* english */}
                            <div className='white-pdf-box-invoice' ref={el => (this.componentRef = el)} dir='ltr'>
                                <div className='row'>
                                    <div className='col-12 mb-1 border-bottom pb-1'>
                                        <div className='row align-items-center'>
                                            <div className='col-3'>
                                                <div className=''>
                                                    <div style={{ width: '79px', height: '46px' }}>
                                                        <img src={logo} alt="" style={{ width: '100%', height: '100%' }} />
                                                    </div>
                                                    <p style={{ fontWeight: '500', fontSize: '6px', color: '#000', marginTop: '4px', marginBottom: '0' }}>Stylish Fashion, Competitive Prices</p>
                                                </div>
                                            </div>
                                            <div className='col-6'>
                                                <div style={{ textAlign: 'center' }}>
                                                    <span style={{ fontWeight: '600', fontSize: '14px', color: '#000', display: 'block' }}>Libsi Markah Trading Company</span>
                                                    <bdi style={{ fontWeight: '500', fontSize: '10px', color: '#000' }}>VAT No. <bdi style={{ fontWeight: '400', fontSize: '10px', color: '#000' }}> 310888882700003  CR No. 4031043575 </bdi> </bdi>
                                                    <p style={{ fontWeight: '400', fontSize: '9px', color: '#000', maxWidth: '400px', margin: 'auto' }}><bdi style={{ fontWeight: '500', fontSize: '9px', color: '#000' }}>Reg. Address:</bdi> Hay Al-Shara'i' -  'Umar Qadi Street
                                                        Makkah Al Mukarramah 24432, KSA</p>
                                                </div>
                                            </div>
                                            {
                                                this.state.barcode !== null && (
                                                    <div className='col-3 mt-sm-0 mt-3 text-center'>
                                                        <div>
                                                            <Barcode value={this.state.barcode} width={1.5} height={50} fontSize={14} />
                                                        </div>
                                                    </div>
                                                )
                                            }
                                        </div>
                                    </div>
                                    <div className='col-12 mb-2'>
                                        <div className='row'>
                                            {this.state.orderDetails.length > 0 &&
                                                <div className='col-6'>
                                                    <div style={{ lineHeight: '90%' }}>
                                                        <span style={{ fontWeight: '600', fontSize: '10px', color: '#000', display: 'block' }}>Customer Details:</span>
                                                    </div>
                                                    <div style={{ lineHeight: '90%' }}>
                                                        <span style={{ fontWeight: '400', fontSize: '9px', color: '#000', display: 'block' }}>{this.state.orderDetails[0].address.name}</span>
                                                    </div>
                                                    <div style={{ lineHeight: '90%' }}>
                                                        <bdi style={{ fontWeight: '400', fontSize: '9px', color: '#000', display: 'block', textAlign: 'left' }}>{`${this.state.orderDetails[0].address.line_1},${this.state.orderDetails[0].address.line_2},${this.state.orderDetails[0].address.area_en},${this.state.orderDetails[0].address.city_en}`}</bdi>
                                                    </div>
                                                    <div style={{ lineHeight: '90%' }}>
                                                        <span style={{ fontWeight: '400', fontSize: '9px', color: '#000', display: 'block' }}>{this.state.orderDetails[0].address.email}, <b style={{ lineHeight: '133%' }}>{this.state.orderDetails[0].address.phone.replace('966', '')}</b></span>
                                                    </div>
                                                </div>
                                            }
                                            <div className='col-6'>
                                                <div style={{ lineHeight: '90%', display: 'flex', alignItems: 'center' }}><div style={{ fontWeight: '400', fontSize: '9px', color: '#000', lineHeight: '133%', width: '65px' }}>Invoice No: </div> {this.state.orderDetails.length > 0 && <div style={{ fontWeight: '600', fontSize: '9px', color: '#000', lineHeight: '133%' }}> {this.state.orderDetails[0].invoice_no}</div>}</div>
                                                <div style={{ lineHeight: '90%', display: 'flex', alignItems: 'center' }}><div style={{ fontWeight: '400', fontSize: '9px', color: '#000', lineHeight: '133%', width: '65px' }}>Order Date: </div>{this.state.orderDetails.length > 0 && <div style={{ fontWeight: '600', fontSize: '9px', color: '#000', lineHeight: '133%' }}> {moment(this.state.orderDetails[0].createdat).format('DD/MM/YYYY hh:mm A')}</div>}</div>
                                                <div style={{ lineHeight: '90%', display: 'flex', alignItems: 'center' }}><div style={{ fontWeight: '400', fontSize: '9px', color: '#000', lineHeight: '133%', width: '65px' }}>Order No: </div>{this.state.orderDetails.length > 0 && <div style={{ fontWeight: '600', fontSize: '9px', color: '#000', lineHeight: '133%' }}> {this.state.orderDetails[0].id}</div>}</div>
                                                <div style={{ lineHeight: '90%', display: 'flex', alignItems: 'center' }}><div style={{ fontWeight: '400', fontSize: '9px', color: '#000', lineHeight: '133%', width: '65px' }}>Pay Method: </div>{this.state.orderDetails.length > 0 && <div style={{ fontWeight: '600', fontSize: '9px', color: '#000', lineHeight: '133%' }}> {this.state.orderDetails[0].pay_method}</div>}</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className='col-12'>
                                        <div>
                                            <div className="table-responsive">
                                                <table className="table mb-0">
                                                    <thead className='mb-2 mt-2'>
                                                        <tr>
                                                            <th style={{ fontWeight: '700', fontSize: '10px', padding: "8px 10px", color: '#000', backgroundColor: "#0000000d", verticalAlign: 'middle', border: '0px' }}>Item Code</th>
                                                            <th style={{ fontWeight: '700', fontSize: '10px', padding: "8px 10px", color: '#000', backgroundColor: "#0000000d", verticalAlign: 'middle', border: '0px' }}>Item Description</th>
                                                            <th style={{ fontWeight: '700', fontSize: '10px', padding: "8px 10px", color: '#000', backgroundColor: "#0000000d", verticalAlign: 'middle', border: '0px' }}>Price (SAR)</th>
                                                            <th style={{ fontWeight: '700', fontSize: '10px', padding: "8px 10px", color: '#000', backgroundColor: "#0000000d", verticalAlign: 'middle', textAlign: 'center', border: '0px' }}>Quantity</th>
                                                            <th style={{ fontWeight: '700', fontSize: '10px', padding: "8px 10px", color: '#000', backgroundColor: "#0000000d", verticalAlign: 'middle', textAlign: 'end', border: '0px' }}>Total</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {this.state.orderDetails.length > 0 && this.state.orderDetails[0].order_item.length > 0 &&
                                                            this.state.orderDetails[0].order_item.map((item) => {
                                                                return (
                                                                    <>
                                                                        {
                                                                            item.quantity !== 0 && (
                                                                                <tr>
                                                                                    <td style={{ fontWeight: '600', fontSize: '10px', padding: "8px 10px", color: '#000', verticalAlign: 'middle', borderBottom: '1px solid #C4C4C4' }}>{item.barcode}</td>
                                                                                    <td style={{ fontWeight: '400', fontSize: '10px', padding: "8px 10px", color: '#000', verticalAlign: 'middle', borderBottom: '1px solid #C4C4C4' }}>
                                                                                        <div className='d-flex align-items-center'>
                                                                                            <span style={{ paddingRight: '5px', }}>{item.title_en}</span>
                                                                                            <span style={{ padding: '0px 5px', borderLeft: '1px solid #000' }}>{item.size_en}</span>
                                                                                            <span style={{ paddingLeft: '5px', borderLeft: '1px solid #000' }}>{item.color_en}</span>
                                                                                        </div>
                                                                                    </td>
                                                                                    <td style={{ fontWeight: '400', fontSize: '10px', padding: "8px 10px", color: '#000', verticalAlign: 'middle', borderBottom: '1px solid #C4C4C4' }}>
                                                                                        <div className='text-start'>
                                                                                            {item.discounted_price?.toFixed(2)}
                                                                                            {item.discount !== 0 && <span className="text-secondary text-decoration-line-through ms-2">{item.product_price?.toFixed(2)}</span>}
                                                                                        </div>
                                                                                    </td>
                                                                                    <td style={{ fontWeight: '400', fontSize: '10px', padding: "8px 10px", color: '#000', verticalAlign: 'middle', textAlign: 'center', borderBottom: '1px solid #C4C4C4' }}>{item.quantity}</td>
                                                                                    <td style={{ fontWeight: '400', fontSize: '10px', padding: "8px 10px", color: '#000', verticalAlign: 'middle', textAlign: 'end', borderBottom: '1px solid #C4C4C4' }}>{item.total_discounted_price?.toFixed(2)}</td>
                                                                                </tr>
                                                                            )
                                                                        }
                                                                    </>
                                                                )
                                                            })}
                                                        <tr>
                                                            <td style={{ fontWeight: '600', fontSize: '10px', padding: "8px 10px", color: '#000', backgroundColor: "#0000000d", verticalAlign: 'middle', border: '0px' }}>Subtotal</td>
                                                            <td style={{ fontWeight: '600', fontSize: '10px', padding: "8px 10px", color: '#000', backgroundColor: "#0000000d", verticalAlign: 'middle', border: '0px' }}></td>
                                                            <td style={{ fontWeight: '600', fontSize: '10px', padding: "8px 10px", color: '#000', backgroundColor: "#0000000d", verticalAlign: 'middle', border: '0px' }}></td>
                                                            <td style={{ fontWeight: '600', fontSize: '10px', padding: "8px 10px", color: '#000', backgroundColor: "#0000000d", verticalAlign: 'middle', border: '0px', textAlign: 'center', }}>{this.state.totalQTY !== "" && this.state.totalQTY}</td>
                                                            <td style={{ fontWeight: '600', fontSize: '10px', padding: "8px 10px", color: '#000', backgroundColor: "#0000000d", verticalAlign: 'middle', textAlign: 'end', border: '0px' }}>{this.state.orderDetails.length > 0 && this.state.orderDetails[0].final_ordered_price?.toFixed(2)}</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div className='col-12'>
                                        <div className='row'>
                                            <div className='col-6 ms-auto'>
                                                <div style={{ marginTop: '5px' }}>
                                                    {this.state.orderDetails.length > 0 && this.state.orderDetails[0].shipping_cost !== 0 &&
                                                        <div style={{ display: 'flex', alignItems: 'center' }}>
                                                            <span style={{ fontWeight: '400', fontSize: '10px', padding: "4px 10px", color: '#000', verticalAlign: 'middle' }}>Shipping Charges</span>
                                                            <bdi style={{ fontWeight: '400', fontSize: '10px', padding: "4px 10px", color: '#000', verticalAlign: 'middle', marginLeft: 'auto' }}>{this.state.orderDetails[0].shipping_cost?.toFixed(2)}</bdi>
                                                        </div>
                                                    }
                                                    {this.state.orderDetails.length > 0 && this.state.orderDetails[0].COD_cost !== 0 &&
                                                        <div style={{ display: 'flex', alignItems: 'center' }}>
                                                            <span style={{ fontWeight: '400', fontSize: '10px', padding: "4px 10px", color: '#000', verticalAlign: 'middle' }}>COD Charges</span>
                                                            <bdi style={{ fontWeight: '400', fontSize: '10px', padding: "4px 10px", color: '#000', verticalAlign: 'middle', marginLeft: 'auto' }}>{this.state.orderDetails[0].COD_cost?.toFixed(2)}</bdi>
                                                        </div>
                                                    }
                                                    {this.state.orderDetails.length > 0 && this.state.orderDetails[0].coupon_discount !== 0 &&
                                                        <div style={{ display: 'flex', alignItems: 'center' }}>
                                                            <span style={{ fontWeight: '400', fontSize: '10px', padding: "4px 10px", color: '#000', verticalAlign: 'middle' }}>Discount (Coupon: {this.state.orderDetails[0].coupon_code} {this.state.orderDetails[0].discount_value}{this.state.orderDetails[0].discount_type === 'fixed' ? ' SR' : '%'})</span>
                                                            <bdi style={{ fontWeight: '400', fontSize: '10px', padding: "4px 10px", color: '#000', verticalAlign: 'middle', marginLeft: 'auto' }}>-{this.state.orderDetails[0].coupon_discount?.toFixed(2)}</bdi>
                                                        </div>
                                                    }
                                                    {this.state.orderDetails.length > 0 && this.state.orderDetails[0].wallet_cost !== 0 &&
                                                        <div style={{ display: 'flex', alignItems: 'center' }}>
                                                            <span style={{ fontWeight: '400', fontSize: '10px', padding: "4px 10px", color: '#000', verticalAlign: 'middle' }}>My Credit</span>
                                                            <bdi style={{ fontWeight: '400', fontSize: '10px', padding: "4px 10px", color: '#000', verticalAlign: 'middle', marginLeft: 'auto' }}>-{this.state.orderDetails[0].wallet_cost?.toFixed(2)}</bdi>
                                                        </div>
                                                    }
                                                    <div style={{ display: 'flex', alignItems: 'center' }}>
                                                        <bdi style={{ fontWeight: '600', fontSize: '12px', padding: "4px 10px", color: '#000', verticalAlign: 'middle' }}>Grand Total</bdi>
                                                        <bdi style={{ fontWeight: '600', fontSize: '12px', padding: "4px 10px", color: '#000', verticalAlign: 'middle', marginLeft: 'auto' }}>{this.state.orderDetails.length > 0 && this.state.orderDetails[0].total_paymentable_price?.toFixed(2)}</bdi>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className='col-6'>
                            <div className='m-1 p-2 text-end D-hide'>
                                <ReactToPrint trigger={() => {
                                    return (
                                        <button className="btn red-btn px-5" style={{ fontFamily: "Noto Sans Arabic,sans-serif" }}>العربية</button>
                                    )
                                }}
                                    content={() => this.componentRefAr}
                                // onBeforePrint={() => {
                                //     const tfoot = document.querySelector('.print-tfoot');
                                //     if (tfoot) {
                                //         tfoot.classList.add('print-on-last-page');
                                //     }
                                // }}
                                // onAfterPrint={() => {
                                //     const tfoot = document.querySelector('.print-tfoot');
                                //     if (tfoot) {
                                //         tfoot.classList.remove('print-on-last-page');
                                //     }
                                // }}
                                />
                            </div>
                            {/* Arabic */}
                            <div className='white-pdf-box-invoice' style={{ fontFamily: "Noto Sans Arabic,sans-serif" }} dir='rtl' ref={el => (this.componentRefAr = el)}>
                                <div className='row'>
                                    <div className='col-12 mb-1 border-bottom pb-1'>
                                        <div className='row align-items-center'>
                                            <div className='col-3'>
                                                <div className=''>
                                                    <div style={{ width: '79px', height: '46px' }}>
                                                        <img src={logoAR} alt="" style={{ width: '100%', height: '100%' }} />
                                                    </div>
                                                    <p style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '500', fontSize: '6px', color: '#000', marginTop: '4px', marginBottom: '0' }}>أزياء عصرية بأسعار منافسة</p>
                                                </div>
                                            </div>
                                            <div className='col-6'>
                                                <div style={{ textAlign: 'center' }}>
                                                    <span style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '600', fontSize: '14px', color: '#000', display: 'block' }}>شركة لبسي ماركة التجارية</span>
                                                    <bdi style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '500', fontSize: '10px', color: '#000' }}>رقم الضريبة: <bdi style={{ fontWeight: '400', fontSize: '10px', color: '#000' }}> 310888882700003  س.ت. 4031043575 </bdi></bdi>
                                                    <p style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '400', fontSize: '9px', color: '#000', maxWidth: '400px', margin: 'auto' }}><bdi style={{ fontWeight: '500', fontSize: '9px', color: '#000' }}>العنوان: </bdi>  الشرائع, مكة المكرمة 24432, المملكة العربية السعودية</p>
                                                </div>
                                            </div>
                                            {
                                                this.state.barcode !== null && (
                                                    <div className='col-3 mt-sm-0 mt-3 text-center'>
                                                        <div>
                                                            <Barcode value={this.state.barcode} width={1.5} height={50} fontSize={14} />
                                                        </div>
                                                    </div>
                                                )
                                            }
                                        </div>
                                    </div>
                                    <div className='col-12 mb-2'>
                                        <div className='row'>
                                            {this.state.orderDetails.length > 0 &&
                                                <div className='col-6'>
                                                    <div style={{ lineHeight: '90%' }}>
                                                        <span style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '600', fontSize: '10px', color: '#000', display: 'block' }}>تفاصيل العميل:</span>
                                                    </div>
                                                    <div style={{ lineHeight: '90%' }}>
                                                        <span style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '400', fontSize: '9px', color: '#000', display: 'block' }}> {this.state.orderDetails[0].address.name}</span>
                                                    </div>
                                                    <div style={{ lineHeight: '90%' }}>
                                                        <bdi style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '400', fontSize: '9px', color: '#000', display: 'block', textAlign: 'right' }}>{`${this.state.orderDetails[0].address.line_1},${this.state.orderDetails[0].address.line_2},${this.state.orderDetails[0].address.area_ar},${this.state.orderDetails[0].address.city_ar}`}</bdi>
                                                    </div>
                                                    <div style={{ lineHeight: '90%' }}>
                                                        <span style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '400', fontSize: '9px', color: '#000', display: 'block' }}>{this.state.orderDetails[0].address.email} <b style={{ lineHeight: '133%' }}>{this.state.orderDetails[0].address.phone.replace('966', '')}</b></span>
                                                    </div>
                                                </div>
                                            }
                                            <div className='col-6'>
                                                <div style={{ lineHeight: '90%', display: 'flex', alignItems: 'center' }}><div style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '400', fontSize: '9px', color: '#000', lineHeight: '133%', width: '55px' }}>رقم الفاتورة: </div> {this.state.orderDetails.length > 0 && <div style={{ fontWeight: '600', fontSize: '9px', color: '#000', lineHeight: '133%', fontFamily: "Noto Sans Arabic,sans-serif", }}> {this.state.orderDetails[0].invoice_no}</div>}</div>
                                                <div style={{ lineHeight: '90%', display: 'flex', alignItems: 'center' }}><div style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '400', fontSize: '9px', color: '#000', lineHeight: '133%', width: '55px' }}>تاريخ الطلب: </div>{this.state.orderDetails.length > 0 && <div style={{ fontWeight: '600', fontSize: '9px', color: '#000', lineHeight: '133%', fontFamily: "Noto Sans Arabic,sans-serif", }}> {moment(this.state.orderDetails[0].createdat).format('DD/MM/YYYY hh:mm A')}</div>}</div>
                                                <div style={{ lineHeight: '90%', display: 'flex', alignItems: 'center' }}><div style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '400', fontSize: '9px', color: '#000', lineHeight: '133%', width: '55px' }}>رقم الطلب: </div>{this.state.orderDetails.length > 0 && <div style={{ fontWeight: '600', fontSize: '9px', color: '#000', lineHeight: '133%', fontFamily: "Noto Sans Arabic,sans-serif", }}> {this.state.orderDetails[0].id}</div>}</div>
                                                <div style={{ lineHeight: '90%', display: 'flex', alignItems: 'center' }}><div style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '400', fontSize: '9px', color: '#000', lineHeight: '133%', width: '55px' }}>طريقة الدفع: </div>{this.state.orderDetails.length > 0 && <div style={{ fontWeight: '600', fontSize: '9px', color: '#000', lineHeight: '133%', fontFamily: "Noto Sans Arabic,sans-serif", }}> {this.state.orderDetails[0].pay_method}</div>}</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className='col-12'>
                                        <div>
                                            <div className="table-responsive">
                                                <table className="table mb-0">
                                                    <thead className='mb-2 mt-2'>
                                                        <tr>
                                                            <th style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '700', fontSize: '10px', padding: "8px 10px", color: '#000', backgroundColor: "#0000000d", verticalAlign: 'middle', border: '0px' }}>باركود</th>
                                                            <th style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '700', fontSize: '10px', padding: "8px 10px", color: '#000', backgroundColor: "#0000000d", verticalAlign: 'middle', border: '0px' }}>وصف المنتج</th>
                                                            <th style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '700', fontSize: '10px', padding: "8px 10px", color: '#000', backgroundColor: "#0000000d", verticalAlign: 'middle', border: '0px' }}>السعر (ر.س.)</th>
                                                            <th style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '700', fontSize: '10px', padding: "8px 10px", color: '#000', backgroundColor: "#0000000d", verticalAlign: 'middle', textAlign: 'center', border: '0px' }}>الكمية</th>
                                                            <th style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '700', fontSize: '10px', padding: "8px 10px", color: '#000', backgroundColor: "#0000000d", verticalAlign: 'middle', textAlign: 'end', border: '0px' }}>الإجمالي</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {this.state.orderDetails.length > 0 && this.state.orderDetails[0].order_item.length > 0 &&
                                                            this.state.orderDetails[0].order_item.map((item) => {
                                                                return (
                                                                    <>
                                                                        {
                                                                            item.quantity !== 0 && (
                                                                                <tr>
                                                                                    <td style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '600', fontSize: '10px', padding: "8px 10px", color: '#000', verticalAlign: 'middle', borderBottom: '1px solid #C4C4C4' }}>{item.barcode}</td>
                                                                                    <td style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '400', fontSize: '10px', padding: "8px 10px", color: '#000', verticalAlign: 'middle', borderBottom: '1px solid #C4C4C4' }}>
                                                                                        <div className='d-flex align-items-center'>
                                                                                            <span style={{ fontFamily: "Noto Sans Arabic,sans-serif", paddingLeft: '5px', }}>{item.title_ar}</span>
                                                                                            <span style={{ fontFamily: "Noto Sans Arabic,sans-serif", padding: '0px 5px', borderRight: '1px solid #000' }}>{item.size_ar}</span>
                                                                                            <span style={{ fontFamily: "Noto Sans Arabic,sans-serif", paddingRight: '5px', borderRight: '1px solid #000' }}>{item.color_ar}</span>
                                                                                        </div>
                                                                                    </td>
                                                                                    <td style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '400', fontSize: '10px', padding: "8px 10px", color: '#000', verticalAlign: 'middle', borderBottom: '1px solid #C4C4C4' }}>
                                                                                        <div className='text-right' style={{ fontFamily: "Noto Sans Arabic,sans-serif", }}>
                                                                                            {item.discount !== 0 && <span className="text-secondary text-decoration-line-through me-2">{item.product_price?.toFixed(2)}</span>}
                                                                                            {item.discounted_price?.toFixed(2)}
                                                                                        </div>
                                                                                    </td>
                                                                                    <td style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '400', fontSize: '10px', padding: "8px 10px", color: '#000', verticalAlign: 'middle', textAlign: 'center', borderBottom: '1px solid #C4C4C4' }}>{item.quantity}</td>
                                                                                    <td style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '400', fontSize: '10px', padding: "8px 10px", color: '#000', verticalAlign: 'middle', textAlign: 'end', borderBottom: '1px solid #C4C4C4' }}>{item.total_discounted_price?.toFixed(2)}</td>
                                                                                </tr>
                                                                            )
                                                                        }
                                                                    </>
                                                                )
                                                            })}
                                                        <tr>
                                                            <td style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '600', fontSize: '10px', padding: "8px 10px", color: '#000', backgroundColor: "#0000000d", verticalAlign: 'middle', border: '0px' }}>المجموع الفرعي</td>
                                                            <td style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '600', fontSize: '10px', padding: "8px 10px", color: '#000', backgroundColor: "#0000000d", verticalAlign: 'middle', border: '0px' }}></td>
                                                            <td style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '600', fontSize: '10px', padding: "8px 10px", color: '#000', backgroundColor: "#0000000d", verticalAlign: 'middle', border: '0px' }}></td>
                                                            <td style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '600', fontSize: '10px', padding: "8px 10px", color: '#000', backgroundColor: "#0000000d", verticalAlign: 'middle', border: '0px', textAlign: 'center', }}>{this.state.totalQTY !== "" && this.state.totalQTY}</td>
                                                            <td style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '600', fontSize: '10px', padding: "8px 10px", color: '#000', backgroundColor: "#0000000d", verticalAlign: 'middle', textAlign: 'end', border: '0px' }}>{this.state.orderDetails.length > 0 && this.state.orderDetails[0].final_ordered_price?.toFixed(2)}</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div className='col-12'>
                                        <div className='row'>
                                            <div className='col-6 me-auto'>
                                                <div style={{ marginTop: '5px' }}>
                                                    {this.state.orderDetails.length > 0 && this.state.orderDetails[0].shipping_cost !== 0 &&
                                                        <div style={{ display: 'flex', alignItems: 'center' }}>
                                                            <span style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '400', fontSize: '10px', padding: "4px 10px", color: '#000', verticalAlign: 'middle' }}>رسوم الشحن</span>
                                                            <bdi style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '400', fontSize: '10px', padding: "4px 10px", color: '#000', verticalAlign: 'middle', marginRight: 'auto' }}>{this.state.orderDetails[0].shipping_cost?.toFixed(2)}</bdi>
                                                        </div>
                                                    }
                                                    {this.state.orderDetails.length > 0 && this.state.orderDetails[0].COD_cost !== 0 &&
                                                        <div style={{ display: 'flex', alignItems: 'center' }}>
                                                            <span style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '400', fontSize: '10px', padding: "4px 10px", color: '#000', verticalAlign: 'middle' }}>رسوم الدفع عند الإستلام</span>
                                                            <bdi style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '400', fontSize: '10px', padding: "4px 10px", color: '#000', verticalAlign: 'middle', marginRight: 'auto' }}>{this.state.orderDetails[0].COD_cost?.toFixed(2)}</bdi>
                                                        </div>
                                                    }
                                                    {this.state.orderDetails.length > 0 && this.state.orderDetails[0].coupon_discount !== 0 &&
                                                        <div style={{ display: 'flex', alignItems: 'center' }}>
                                                            <span style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '400', fontSize: '10px', padding: "4px 10px", color: '#000', verticalAlign: 'middle' }}>(كوبون : {this.state.orderDetails[0].coupon_code} {this.state.orderDetails[0].discount_value}{this.state.orderDetails[0].discount_type === 'fixed' ? ' SR' : '%'})</span>
                                                            <bdi style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '400', fontSize: '10px', padding: "4px 10px", color: '#000', verticalAlign: 'middle', marginRight: 'auto' }}>-{this.state.orderDetails[0].coupon_discount?.toFixed(2)}</bdi>
                                                        </div>
                                                    }
                                                    {this.state.orderDetails.length > 0 && this.state.orderDetails[0].wallet_cost !== 0 &&
                                                        <div style={{ display: 'flex', alignItems: 'center' }}>
                                                            <span style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '400', fontSize: '10px', padding: "4px 10px", color: '#000', verticalAlign: 'middle' }}>المحفظة</span>
                                                            <bdi style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '400', fontSize: '10px', padding: "4px 10px", color: '#000', verticalAlign: 'middle', marginRight: 'auto' }}>-{this.state.orderDetails[0].wallet_cost?.toFixed(2)}</bdi>
                                                        </div>
                                                    }
                                                    <div style={{ display: 'flex', alignItems: 'center' }}>
                                                        <bdi style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '600', fontSize: '12px', padding: "4px 10px", color: '#000', verticalAlign: 'middle' }}>المجموع الإجمالي</bdi>
                                                        <bdi style={{ fontFamily: "Noto Sans Arabic,sans-serif", fontWeight: '600', fontSize: '12px', padding: "4px 10px", color: '#000', verticalAlign: 'middle', marginRight: 'auto' }}>{this.state.orderDetails.length > 0 && this.state.orderDetails[0].total_paymentable_price?.toFixed(2)}</bdi>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/* <div className='pdf-data-box mt-5 mb-5'>





                </div> */}
            </div>
        )
    }
}

export default Invoice