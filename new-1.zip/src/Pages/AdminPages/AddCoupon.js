import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import { Formik } from "formik";
import Moment from "moment";
import {
  API_Path,
  marketingArabic,
  marketingEnglish,
  buttonArabic,
  buttonEnglish,
} from "../../const";
import LanguageContext from "../../contexts/languageContext";

import { PostApi } from "../../helper/APIService";
import { Modal } from "react-bootstrap";
import toastr from "toastr";
import * as Yup from "yup";
import moment from "moment";
import { withRouter } from "react-router-dom";
import Select from "react-select";

let dataToAdd = [];
let CategorydataToAdd = [];
let customersdataToAdd = [];

export class AddCoupon extends Component {
  static contextType = LanguageContext;

  constructor() {
    super();

    this.state = {
      slider: true,
      couponCode: "",
      exclude_sale: 0,
      product: "Include",
      product_apply: "All Product",
      exclude_customer: 0,
      customer: "Include",
      customer_apply: "All Customers",
      payment_apply: "All Payment methods",
      discountValue: "",
      percentage: "",
      spanValue: "",
      payment: "Include",
      paymentmethods: "",
      specificPayment: "",
      Browse1: "",
      Browse2: "",

      specificCategoryShow: false,
      specificProductsShow: false,
      CustomersShow: false,

      subCategoryData: [],
      SpecificProductsData: [],
      CustomersData: [],

      selectedData: [],
      selectedDataArray: [],

      selectedCategoryData: [],
      selectedCategoryDataArray: [],

      selectedCustomersData: [],
      selectedCustomersDataArray: [],

      firstFormData: {},
      thirdFormData: {},
      specificProductsPage: 1,
      loadmoreLoader: false,
      searchSpecificProducts: "",
      customerloadmoreLoader: false,
      showLoadmoreCustomerButton: true,
      customerSearch: "",
      customerLoadPage: 1,

      disablePaymentMethodSelect: true,
    };

    this.innerInput = React.createRef();
  }

  customStyles = {
    control: () => ({
      height: "50px",
      backgroundColor: "#F7F7F7",
      border: "1px solid #F7F7F7",
      borderRadius: "10px",
      fontSize: "16px",
      color: "#5E5E6C",
      marginBottom: "15px",
      display: "flex",
    }),

    indicatorSeparator: () => ({
      backgroundColor: "transparent",
    }),

    indicatorContainer: () => ({
      backgroundColor: "#000",
    }),
  };

  componentDidMount() {
    this.getSubCategoryData();
    document.getElementById("enddate").style.display = "none";
    document.getElementById("endtime").style.display = "none";
  }

  handleSlider = (e) => {
    this.setState({ slider: e.target.checked.toString() });
  };

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  handlecouponcode = (e) => {
    this.setState({ couponCode: e.target.value.toUpperCase() });
    this.innerInput.current.setFieldValue(
      "couponCode",
      e.target.value.toUpperCase()
    );
  };

  handlediscountType = (e) => {
    this.setState({ discountType: e.target.value }, () => {
      if (this.state.discountType === "percentage") {
        this.setState({ spanValue: "%" });
      } else if (this.state.discountType === "fixed") {
        this.setState({ spanValue: "SR" });
        if (document.getElementById("include")) {
          document.getElementById("include").checked = true;
        }
        if (document.getElementById("allproduct")) {
          document.getElementById("allproduct").checked = true;
        }
      }
      this.innerInput.current.setFieldValue("discountType", e.target.value);
    });
  };

  handleValue = (e) => {
    if (this.state.discountType === "percentage") {
      if (e.target.value < 100) {
        this.setState({ discountValue: e.target.value }, () => {
          this.innerInput.current.setFieldValue(
            "discountValue",
            e.target.value
          );
        });
      }
    } else {
      this.setState({ discountValue: e.target.value }, () => {
        this.innerInput.current.setFieldValue("discountValue", e.target.value);
      });
    }
  };

  handleSubmit2 = (e) => {
    this.setState(e.target.value);
  };

  handleexclude_sale = (e) => {
    this.setState({ exclude_sale: e.target.checked ? 1 : 0 });
  };

  handleProductChange = (e) => {
    this.setState({ product: e.target.value }, () => {
      document.getElementById("product-validate").style.display = "none";
    });
  };

  handleproduct_applyChange = (e) => {
    this.setState({ product_apply: e.target.value }, () => {
      document.getElementById("product_apply-validate").style.display = "none";
      console.log("Product_apply :: ", e.target.value);
    });
  };

  handlePayment = (e) => {
    this.setState({ product_apply: e.target.value });
  };

  handleBrowse1Submit = () => {
    if (this.state.product_apply === "") {
      toastr.error("Please Select category or product");
    } else {
      if (this.state.product_apply === "All Product") {
        console.log(
          "All Product :: ",
          document.getElementById("allproduct").value
        );
      } else if (this.state.product_apply === "Specific Category") {
        this.getSubCategoryData();
        this.setState({ specificCategoryShow: true });
      } else if (this.state.product_apply === "Specific Products") {
        this.getSpecificProducts();
        this.setState({ specificProductsShow: true });
      }
    }
  };

  handleBrowse2Submit = () => {
    if (this.state.customer_apply === "") {
      toastr.error("Please Select Specific Customers");
    } else {
      if (this.state.customer_apply === "Specific Customer Groups") {
        this.getCustomers();
        this.setState({ CustomersShow: true });
      } else if (this.state.customer_apply === "All Customers") {
        console.log(
          "All Customers :: ",
          document.getElementById("allcustomers").value
        );
      }
    }
  };

  getSubCategoryData = () => {
    let data = {
      // page: 1,
      // sizePerPage: 10
    };

    let path = API_Path.getSubCategory;
    const getSubCategoryPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getSubCategoryPromise.then((res) => {
      if (res) {
        this.setState({ subCategoryData: res.data.data[0] }, () => {});
      }
    });
  };

  getSpecificProducts = () => {
    this.setState({ searchSpecificProducts: "" });
    let data = {
      page: this.state.specificProductsPage,
      sizePerPage: 10,
    };

    let path = API_Path.getSpecificProducts;
    const getSpecificProductsPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getSpecificProductsPromise.then((res) => {
      if (res) {
        this.setState({ SpecificProductsData: res.data.data });
      }
    });
  };

  loadMoreSpecificProducts = () => {
    this.setState(
      {
        specificProductsPage: this.state.specificProductsPage + 1,
        loadmoreLoader: true,
      },
      () => {
        let data;
        if (this.state.searchSpecificProducts !== "") {
          data = {
            page: this.state.specificProductsPage,
            sizePerPage: 10,
            search_val: this.state.searchSpecificProducts,
          };
        } else {
          data = {
            page: this.state.specificProductsPage,
            sizePerPage: 10,
          };
        }
        let path = API_Path.getSpecificProducts;
        const getSpecificProductsPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        getSpecificProductsPromise.then((res) => {
          if (res.data.data.length > 0) {
            this.setState({
              SpecificProductsData: [
                ...this.state.SpecificProductsData,
                ...res.data.data,
              ],
              loadmoreLoader: false,
            });
          } else {
            this.setState({ loadmoreLoader: false });
          }
        });
      }
    );
  };

  getCustomers = () => {
    let data = {
      page: 1,
      sizePerPage: 10,
    };

    let path = API_Path.getCustomers;
    const getCustomersPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getCustomersPromise.then((res) => {
      if (res) {
        this.setState({ CustomersData: res.data.data });
      }
    });
  };
  loadMoreCustomersData = () => {
    this.setState(
      {
        customerLoadPage: this.state.customerLoadPage + 1,
        customerloadmoreLoader: true,
      },
      () => {
        let data = {
          page: this.state.customerLoadPage,
          sizePerPage: 10,
          search_val: this.state.customerSearch,
        };

        let path = API_Path.getCustomers;
        const getCustomersPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        getCustomersPromise.then((res) => {
          if (res) {
            this.setState({
              CustomersData: [...this.state.CustomersData, ...res.data.data],
              customerloadmoreLoader: false,
            });
          }
        });
      }
    );
  };

  addCoupon = (data) => {
    let path = API_Path.addCoupon;
    const addCouponPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    addCouponPromise.then((res) => {
      if (res) {
        if (res.data.success) {
          toastr.success(res.data.message);
          this.setState({ CouponData: res.data.data }, () => {
            this.props.history.push("/marketing");
            // window.location.href = "/marketing";
          });
        } else {
          toastr.error(res.data.message);
        }
      }
    });
  };

  specificCategoryClose = () => {
    this.setState({ specificCategoryShow: false });
  };

  specificProductsClose = () => {
    this.setState({ specificProductsShow: false });
  };

  CustomersClose = () => {
    this.setState({ CustomersShow: false });
  };

  handlepaymentmethods = (values) => {
    const payment_apply =
      values.length > 0
        ? values.map(({ value }) => value).join(",")
        : "All Payment methods";

    this.setState({ paymentmethods: values, payment_apply });
  };

  handleexclude_customer = (e) => {
    this.setState({ exclude_customer: e.target.checked ? 1 : 0 });
  };

  handleCustomerChange = (e) => {
    this.setState({ customer: e.target.value }, () => {
      document.getElementById("customer-validate").style.display = "none";
    });
  };

  handlecustomer_applyChange = (e) => {
    this.setState({ customer_apply: e.target.value }, () => {
      document.getElementById("customer_apply-validate").style.display = "none";
    });
  };

  handlePaymentChange = (e) => {
    this.setState({ payment: e.target.value }, () => {
      document.getElementById("payment-validate").style.display = "none";
    });
  };

  handlepayment_applyChange = (e) => {
    this.setState({ payment_apply: e.target.value }, () => {
      document.getElementById("payment_apply-validate").style.display = "none";
    });
  };

  handleSetEndDate = (e) => {
    if (e.target.checked) {
      document.getElementById("enddate").style.display = "block";
      document.getElementById("endtime").style.display = "block";
    } else {
      document.getElementById("enddate").style.display = "none";
      document.getElementById("endtime").style.display = "none";
    }
  };

  // =================================== Category ===================================

  handleCategoryCheckboxChange = (e, data) => {
    if (e.target.checked) {
      CategorydataToAdd.push(data);
    } else {
      const idToRemove = data.id;
      const filteredData = CategorydataToAdd.filter(
        (item) => item.id !== idToRemove
      );
      CategorydataToAdd = filteredData;
    }
  };

  handleCategoryAdd = () => {
    if (CategorydataToAdd.length > 0) {
      this.specificCategoryClose();
      this.setState(
        {
          selectedCategoryData: CategorydataToAdd,
          selectedData: [],
          // selectedDataArray: [],
        },
        () => {
          document.getElementById("Browse1-validate").style.display = "none";
        }
      );
    } else {
      toastr.error("Please Select items");
    }
  };

  handleCategoryCancel = (data) => {
    const idToRemove = data.id;

    const filteredCategoryData = this.state.selectedCategoryData.filter(
      (item) => item.id !== idToRemove
    );
    CategorydataToAdd = filteredCategoryData;
    this.setState(
      {
        selectedCategoryData: filteredCategoryData,
      },
      () => {
        if (filteredCategoryData.length == 0) {
          document.getElementById("Browse1-validate").style.display = "block";
        }
      }
    );
  };

  // =================================== Products ===================================

  handleCheckboxChange = (e, data) => {
    if (e.target.checked) {
      dataToAdd.push(data);
    } else {
      const idToRemove = data.id;
      const filteredData = dataToAdd.filter((item) => item.id !== idToRemove);
      dataToAdd = filteredData;
    }
  };

  handleAdd = () => {
    if (dataToAdd.length > 0) {
      this.specificProductsClose();
      this.setState(
        {
          selectedData: dataToAdd,
          selectedCategoryData: [],
          // selectedCategoryDataArray: [],
        },
        () => {
          document.getElementById("Browse1-validate").style.display = "none";
        }
      );
    } else {
      toastr.error("Please Select items");
    }
  };

  handleCancel = (data) => {
    const idToRemove = data.id;

    const filteredData = this.state.selectedData.filter(
      (item) => item.id !== idToRemove
    );
    dataToAdd = filteredData;
    this.setState({ selectedData: filteredData }, () => {
      if (filteredData.length == 0) {
        document.getElementById("Browse1-validate").style.display = "block";
      }
    });
  };

  // =================================== Customers ===================================

  handleCustomersCheckboxChange = (e, data) => {
    if (e.target.checked) {
      customersdataToAdd.push(data);
    } else {
      const idToRemove = data.id;

      const filteredCustomersData = customersdataToAdd.filter(
        (item) => item.id !== idToRemove
      );
      customersdataToAdd = filteredCustomersData;
    }
  };

  handleCustomersAdd = () => {
    if (customersdataToAdd.length > 0) {
      this.CustomersClose();
      this.setState(
        {
          selectedCustomersData: customersdataToAdd,
        },
        () => {
          document.getElementById("Browse2-validate").style.display = "none";
        }
      );
    } else {
      toastr.error("Please Select items");
    }
  };

  handleCustomersCancel = (data) => {
    const idToRemove = data.id;

    const filteredCustomersData = this.state.selectedCustomersData.filter(
      (item) => item.id !== idToRemove
    );
    customersdataToAdd = filteredCustomersData;
    this.setState(
      {
        selectedCustomersData: filteredCustomersData,
      },
      () => {
        if (filteredCustomersData.length == 0) {
          document.getElementById("Browse2-validate").style.display = "block";
        }
      }
    );
  };

  // =================================== X ===================================

  handleCategorySearch = (e) => {
    let data = {
      search_val: e.target.value,
      // page: 1,
      // sizePerPage: 10
    };

    let path = API_Path.getSubCategory;
    const getSubCategoryPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getSubCategoryPromise.then((res) => {
      if (res) {
        this.setState({ subCategoryData: res.data.data });
      }
    });
  };

  handleProductsSearch = (e) => {
    this.setState({ searchSpecificProducts: e.target.value });

    let data = {
      search_val: e.target.value,
      page: 1,
      sizePerPage: 10,
    };

    let path = API_Path.getSpecificProducts;
    const getSpecificProductsPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getSpecificProductsPromise.then((res) => {
      if (res) {
        this.setState({ SpecificProductsData: res.data.data });
      }
    });
  };

  handleCustomersSearch = (e) => {
    this.setState({ customerSearch: e.target.value });
    let data = {
      search_val: e.target.value,
      page: 1,
      sizePerPage: 10,
    };

    let path = API_Path.getCustomers;
    const getCustomersPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getCustomersPromise.then((res) => {
      if (res) {
        this.setState({ CustomersData: res.data.data });
      }
    });
  };

  getFirstFormData = (data) => {
    this.setState({ firstFormData: data });
  };

  getThirdFormData = (data) => {
    this.setState({ thirdFormData: data });
  };

  handlecouponSubmit = () => {
    this.getAllData();
  };

  getAllData = () => {
    document.getElementById("first-btn").click();
    document.getElementById("third-btn").click();

    if (this.state.product === "") {
      document.getElementById("product-validate").style.display = "block";
    }
    if (this.state.product_apply === "") {
      document.getElementById("product_apply-validate").style.display = "block";
    }
    if (this.state.customer === "") {
      document.getElementById("customer-validate").style.display = "block";
    }
    if (this.state.customer_apply === "") {
      document.getElementById("customer_apply-validate").style.display =
        "block";
    }
    if (this.state.payment === "") {
      document.getElementById("payment-validate").style.display = "block";
    }
    if (this.state.payment_apply === "") {
      document.getElementById("payment_apply-validate").style.display = "block";
    }
    // if (this.state.selectedData.length == 0 && this.state.selectedCategoryData.length == 0) {
    //   document.getElementById("Browse1-validate").style.display = "block";
    // }
    if (this.state.product_apply === "All Product") {
      document.getElementById("Browse1-validate").style.display = "none";
    } else if (
      this.state.selectedData.length == 0 &&
      this.state.selectedCategoryData.length == 0
    ) {
      document.getElementById("Browse1-validate").style.display = "block";
    }
    if (this.state.customer_apply === "All Customers") {
      document.getElementById("Browse2-validate").style.display = "none";
    } else if (this.state.selectedCustomersData.length == 0) {
      document.getElementById("Browse2-validate").style.display = "block";
    }

    let selectedProductData =
      this.state.product_apply === "Specific Products"
        ? this.state.selectedData
        : this.state.product_apply === "Specific Category"
        ? this.state.selectedCategoryData
        : [];
    let selectedCustomersData = this.state.selectedCustomersData;

    if (selectedProductData.length > 0) {
      let selectedDataProduct = [];
      for (let i = 0; i < selectedProductData.length; i++) {
        selectedDataProduct.push(selectedProductData[i].id);
      }
      selectedProductData = selectedDataProduct;
    }

    if (selectedCustomersData.length > 0) {
      let selectedDataCustomer = [];
      for (let i = 0; i < selectedCustomersData.length; i++) {
        selectedDataCustomer.push(selectedCustomersData[i].id);
      }
      selectedCustomersData = selectedDataCustomer;
    }

    let interval = setInterval(() => {
      if (
        Object.keys(this.state.firstFormData).length !== 0 &&
        this.state.thirdFormData &&
        (this.state.product_apply !== "All Product"
          ? selectedProductData.length > 0
          : selectedProductData.length == 0) &&
        (this.state.customer_apply !== "All Customers"
          ? selectedCustomersData.length > 0
          : selectedCustomersData.length == 0 &&
            this.state.payment_apply !== "")
        // this.state.product !== "" &&
        // this.state.product_apply !== "" &&
        // this.state.customer !== "" &&
        // this.state.customer_apply !== "" &&
      ) {
        clearInterval(interval);
        if (this.state.firstFormData.discountType === "fixed") {
          // if (this.state.firstFormData.discountValue < this.state.firstFormData.minimumPurchaseAmount) {
          let finalData = {
            couponCode: this.state.firstFormData.couponCode?.toUpperCase(),
            discountType: this.state.firstFormData.discountType,
            discountValue: this.state.firstFormData.discountValue,
            freeCod: this.state.firstFormData.freeCod,
            freeShipping: this.state.firstFormData.freeShipping,
            limitDiscountUse: this.state.firstFormData.limitDiscountUse,
            maximumPurchaseAmount:
              this.state.firstFormData.maximumPurchaseAmount,
            minimumPurchaseAmount:
              this.state.firstFormData.minimumPurchaseAmount,
            oneCustomer: this.state.firstFormData.oneCustomer,

            exclude_sale: this.state.exclude_sale,
            product: this.state.product,
            product_apply: this.state.product_apply,
            exclude_customer: this.state.exclude_customer,
            customer: this.state.customer,
            customer_apply: this.state.customer_apply,
            payment: this.state.payment,
            payment_apply: this.state.payment_apply,

            selectedDataArray: this.state.selectedProductData,
            selectedCustomersDataArray: this.state.selectedCustomersData,

            enddate: this.state.thirdFormData.enddate
              ? this.state.thirdFormData.enddate
              : "",
            endtime: this.state.thirdFormData.endtime
              ? this.state.thirdFormData.endtime
              : "",
            startdate: this.state.thirdFormData.startdate,
            starttime: this.state.thirdFormData.starttime,
          };
          this.addCoupon(finalData);
          // } else {
          //   toastr.error("Discount value should be less than minimum purchase amount");
          // }
        } else {
          let finalData = {
            couponCode: this.state.firstFormData.couponCode?.toUpperCase(),
            discountType: this.state.firstFormData.discountType,
            discountValue: this.state.firstFormData.discountValue,
            freeCod: this.state.firstFormData.freeCod,
            freeShipping: this.state.firstFormData.freeShipping,
            limitDiscountUse: this.state.firstFormData.limitDiscountUse,
            maximumPurchaseAmount:
              this.state.firstFormData.maximumPurchaseAmount,
            minimumPurchaseAmount:
              this.state.firstFormData.minimumPurchaseAmount,
            oneCustomer: this.state.firstFormData.oneCustomer,

            exclude_sale: this.state.exclude_sale,
            product: this.state.product,
            product_apply: this.state.product_apply,
            exclude_customer: this.state.exclude_customer,
            customer: this.state.customer,
            customer_apply: this.state.customer_apply,
            payment: this.state.payment,
            payment_apply: this.state.payment_apply,

            selectedDataArray: this.state.selectedProductData,

            selectedDataArray: this.state.selectedData,
            selectedCategoryDataArray: this.state.selectedCategoryData,
            selectedCustomersDataArray: this.state.selectedCustomersData,

            enddate: this.state.thirdFormData.enddate
              ? this.state.thirdFormData.enddate
              : "",
            endtime: this.state.thirdFormData.endtime
              ? this.state.thirdFormData.endtime
              : "",
            startdate: this.state.thirdFormData.startdate,
            starttime: this.state.thirdFormData.starttime,

            productData: this.state.selectedDataArray,
            categoryData: this.state.selectedCategoryDataArray,
            customerData: this.state.selectedCustomersDataArray,
          };
          this.addCoupon(finalData);
        }
      }
    }, 200);
  };

  render() {
    let marketingLanguage =
      this.context.language === "english" ? marketingEnglish : marketingArabic;
    let buttonLanguage =
      this.context.language === "english" ? buttonEnglish : buttonArabic;

    const paymentMethodOptions = [
      { value: "Card Payment", label: marketingLanguage.cardPay },
      { value: "Cash on delivery", label: marketingLanguage.CashonDelivery },
      { value: "Apple Pay", label: marketingLanguage.ApplePay },
      { value: "Tabby", label: marketingLanguage.Tabby },
      { value: "Tamara", label: marketingLanguage.Tamara },
    ];

    const { disablePaymentMethodSelect } = this.state;

    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space">
            <div className="col-8">
              <div className="common-header-txt">
                <h3>{marketingLanguage.AddCouponCode}</h3>
              </div>
            </div>
            <div className="col-4 text-end">
              <div className="d-inline-flex align-items-center cust-switch-drop border-0 p-0">
                <label className="switch ms-auto">
                  <input
                    type="checkbox"
                    name="slider"
                    defaultChecked
                    value="slider"
                    onChange={this.handleSlider}
                  />
                  <div className="slider round" />
                </label>
              </div>
            </div>
          </div>
          <div className="row common-space">
            <div className="col-md-12">
              {/* //=================================== 111 =================================== */}

              <div className="pb-4">
                <div className="white-box">
                  <div className="row custom-border-title">
                    <div className="col-md-12">
                      <div className="product-header">
                        <span>{marketingLanguage.CouponDetails}</span>
                      </div>
                    </div>
                  </div>

                  <Formik
                    innerRef={this.innerInput}
                    initialValues={{
                      couponCode: "",
                      discountType: "",
                      discountValue: "",
                      minimumPurchaseAmount: null,
                      maximumPurchaseAmount: null,
                      freeShipping: "No",
                      oneCustomer: null,
                      limitDiscountUse: null,
                      freeCod: "No",
                      limitedOfferAmount: null,
                    }}
                    onSubmit={async (values) => {
                      this.getFirstFormData(values);
                    }}
                    validationSchema={Yup.object().shape({
                      couponCode: Yup.string().required(
                        "Coupon Code is required"
                      ),
                      discountType: Yup.string().required(
                        "Discount Type is required"
                      ),
                      discountValue: Yup.string().required(
                        "Discount value is required"
                      ),
                      // minimumPurchaseAmount: Yup.string().nullable().required("Minimum Purchase amount is required"),
                      // maximumPurchaseAmount: Yup.string().nullable().required("Maximum Purchase Amount is required"),
                      freeShipping: Yup.string().required(
                        "Free Shipping is required"
                      ),
                      // oneCustomer: Yup.string().nullable().required("Limit times of use to one customer is required"),
                      // limitDiscountUse: Yup.string().nullable().required("Limit Discount Use is required"),
                      freeCod: Yup.string().required(
                        "Free Cash on delivery is required"
                      ),
                      // limitedOfferAmount: Yup.string().nullable().required("Limited offer Amount is required"),
                    })}
                  >
                    {(props) => {
                      const {
                        touched,
                        errors,
                        values,
                        handleChange,
                        handleBlur,
                        handleSubmit,
                      } = props;
                      return (
                        <form className="row mt-3" onSubmit={handleSubmit}>
                          <div className="form-group col-lg-4 col-md-6">
                            <label className="mb-2 lbl-bdi-inr-class">
                              {marketingLanguage.CouponCode}{" "}
                              <bdi>
                                {
                                  marketingLanguage.CustomersWillEnterThisDiscountCodeatCheckout
                                }
                              </bdi>
                            </label>
                            <input
                              type="text"
                              name="couponCode"
                              className="form-control input-custom-class text-uppercase"
                              placeholder={marketingLanguage.enterCouponCode}
                              style={{ color: "#A81A1C" }}
                              value={this.state.couponCode.toUpperCase()}
                              onChange={this.handlecouponcode}
                              onBlur={handleBlur}
                            />
                            {touched.couponCode && errors.couponCode && (
                              <div className="input-feedback text-danger">
                                {errors.couponCode}
                              </div>
                            )}
                          </div>
                          <div className="form-group col-lg-4 col-md-6">
                            <label className="mb-2 lbl-bdi-inr-class">
                              {marketingLanguage.DiscountType}
                            </label>
                            <select
                              name="discountType"
                              className="form-select input-custom-class"
                              value={this.state.discountType}
                              onChange={this.handlediscountType}
                              onBlur={handleBlur}
                            >
                              <option value="select">
                                {marketingLanguage.select}
                              </option>
                              <option value="percentage">
                                {marketingLanguage.percentage}
                              </option>
                              <option value="fixed">
                                {marketingLanguage.Fixed}
                              </option>
                            </select>
                            {touched.discountType && errors.discountType && (
                              <div className="input-feedback text-danger">
                                {errors.discountType}
                              </div>
                            )}
                          </div>
                          <div className="form-group col-lg-4 col-md-6">
                            <label className="mb-2 lbl-bdi-inr-class">
                              {marketingLanguage.DiscountValue}
                            </label>
                            <div className="d-flex align-items-cecmter cust-input-edon">
                              <input
                                type="number"
                                name="discountValue"
                                className="form-control input-custom-class"
                                placeholder={marketingLanguage.enterValue}
                                value={this.state.discountValue}
                                onChange={this.handleValue}
                                onBlur={handleBlur}
                              />
                              {this.state.spanValue !== "" && (
                                <span className="input-group-text">
                                  {this.state.spanValue}
                                </span>
                              )}
                            </div>
                            {touched.discountValue && errors.discountValue && (
                              <div className="input-feedback text-danger">
                                {errors.discountValue}
                              </div>
                            )}
                          </div>
                          <div className="form-group col-lg-4 col-md-6">
                            <label className="mb-2 lbl-bdi-inr-class">
                              {marketingLanguage.MinimumPurchaseamountinSAR}
                            </label>
                            <input
                              type="number"
                              name="minimumPurchaseAmount"
                              className="form-control input-custom-class"
                              placeholder={
                                marketingLanguage.enterMinPurchaseAmount
                              }
                              value={values.minimumPurchaseAmount}
                              onChange={handleChange}
                              onBlur={handleBlur}
                            />
                            {touched.minimumPurchaseAmount &&
                              errors.minimumPurchaseAmount && (
                                <div className="input-feedback text-danger">
                                  {errors.minimumPurchaseAmount}
                                </div>
                              )}
                          </div>
                          <div className="form-group col-lg-4 col-md-6">
                            <label className="mb-2 lbl-bdi-inr-class">
                              {marketingLanguage.MaximumPurchaseAmountinSAR}
                            </label>
                            <input
                              type="number"
                              name="maximumPurchaseAmount"
                              className="form-control input-custom-class"
                              placeholder={
                                marketingLanguage.enterMaxPurchaseAmount
                              }
                              value={values.maximumPurchaseAmount}
                              onChange={handleChange}
                              onBlur={handleBlur}
                            />
                            {touched.maximumPurchaseAmount &&
                              errors.maximumPurchaseAmount && (
                                <div className="input-feedback text-danger">
                                  {errors.maximumPurchaseAmount}
                                </div>
                              )}
                          </div>
                          <div className="form-group col-lg-4 col-md-6">
                            <label className="mb-2 lbl-bdi-inr-class">
                              {marketingLanguage.FreeShipping}
                            </label>
                            <select
                              name="freeShipping"
                              className="form-select input-custom-class"
                              value={values.freeShipping}
                              onChange={handleChange}
                              onBlur={handleBlur}
                            >
                              <option>{marketingLanguage.yes}</option>
                              <option selected>{marketingLanguage.no}</option>
                            </select>
                          </div>
                          <div className="form-group col-lg-4 col-md-6">
                            <label className="mb-2 lbl-bdi-inr-class">
                              {marketingLanguage.LimitTimesOfUseToOneCustomer}
                            </label>
                            <input
                              type="number"
                              name="oneCustomer"
                              className="form-control input-custom-class"
                              placeholder={marketingLanguage.enterCustomer}
                              value={values.oneCustomer}
                              onChange={handleChange}
                              onBlur={handleBlur}
                            />
                            {touched.oneCustomer && errors.oneCustomer && (
                              <div className="input-feedback text-danger">
                                {errors.oneCustomer}
                              </div>
                            )}
                          </div>
                          <div className="form-group col-lg-4 col-md-6">
                            <label className="mb-2 lbl-bdi-inr-class">
                              {
                                marketingLanguage.LimitNumberOfTimesThisDiscountCanBeUsedInTotal
                              }
                            </label>
                            <input
                              type="number"
                              name="limitDiscountUse"
                              className="form-control input-custom-class"
                              placeholder={marketingLanguage.enterLimitNoOftime}
                              value={values.limitDiscountUse}
                              onChange={handleChange}
                              onBlur={handleBlur}
                            />
                            {touched.limitDiscountUse &&
                              errors.limitDiscountUse && (
                                <div className="input-feedback text-danger">
                                  {errors.limitDiscountUse}
                                </div>
                              )}
                          </div>
                          <div className="form-group col-lg-4 col-md-6">
                            <label className="mb-2 lbl-bdi-inr-class">
                              {marketingLanguage.FreeCashonDelivery}
                            </label>
                            <select
                              name="freeCod"
                              className="form-select input-custom-class"
                              value={values.freeCod}
                              onChange={handleChange}
                              onBlur={handleBlur}
                            >
                              <option>{marketingLanguage.yes}</option>
                              <option selected>{marketingLanguage.no}</option>
                            </select>
                          </div>
                          <div className="form-group col-lg-4 col-md-6">
                            <label className="mb-2 lbl-bdi-inr-class">
                              {marketingLanguage.LimitedOfferAmount}
                            </label>
                            <input
                              name="limitedOfferAmount"
                              value={values.limitedOfferAmount}
                              type="number"
                              className="form-control input-custom-class"
                              placeholder={
                                marketingLanguage.enterLimitedOfferAmount
                              }
                            />
                          </div>
                          <div className="text-md-end text-center pb-3 d-none">
                            <button
                              type="submit"
                              id="first-btn"
                              className="red-btn ms-3"
                            >
                              {buttonLanguage.save}
                            </button>
                          </div>
                        </form>
                      );
                    }}
                  </Formik>
                </div>
              </div>

              {/* //=================================== 2222 =================================== */}

              <div className="pb-4">
                <div className="white-box">
                  <div className="row custom-border-title">
                    <div className="col-md-12">
                      <div className="product-header">
                        <span>{marketingLanguage.Filter}</span>
                      </div>
                    </div>
                  </div>

                  <form className="row mt-3" onSubmit={this.handleSubmit2}>
                    <div className="col-lg-4">
                      <div className="row">
                        <div className="col-12 pb-2">
                          <label className="cust-chk-bx">
                            <input
                              name="exclude_sale"
                              type="checkbox"
                              onChange={this.handleexclude_sale}
                              value={marketingLanguage.excludeSaleItem}
                              required
                            />
                            <span className="cust-chkmark"></span>
                            <bdi>{marketingLanguage.excludeSaleItem}</bdi>
                          </label>
                        </div>
                        <div
                          className="col-12 form-group pb-3"
                          name="product"
                          onChange={this.handleProductChange}
                          value={this.state.product}
                          required
                        >
                          <label className="mb-1 lbl-bdi-inr-class">
                            {" "}
                            {marketingLanguage.product}
                          </label>
                          <div className="row">
                            <div className="col-4">
                              <label className="cust-radio mb-0">
                                <input
                                  type="radio"
                                  id="include"
                                  value="Include"
                                  name="Products"
                                  defaultChecked
                                />
                                <span className="checkmark"></span>
                                <span>{marketingLanguage.include} </span>
                              </label>
                            </div>
                            {this.state.discountType === "fixed" ? (
                              <div className="col-4">
                                <label className="cust-radio mb-0">
                                  <input
                                    type="radio"
                                    id="2"
                                    value="Exclude"
                                    name="Products"
                                    disabled
                                  />
                                  <span className="checkmark"></span>
                                  <span>{marketingLanguage.exclude}</span>
                                </label>
                              </div>
                            ) : (
                              <div className="col-4">
                                <label className="cust-radio mb-0">
                                  <input
                                    type="radio"
                                    id="2"
                                    value="Exclude"
                                    name="Products"
                                  />
                                  <span className="checkmark"></span>
                                  <span>{marketingLanguage.exclude}</span>
                                </label>
                              </div>
                            )}
                            <div
                              id="product-validate"
                              style={{ display: "none" }}
                              className="input-feedback text-danger"
                            >
                              required
                            </div>
                          </div>
                        </div>
                        <div
                          className="col-12 form-group pb-3"
                          name="product_apply"
                          onChange={this.handleproduct_applyChange}
                          value={this.state.product_apply}
                          required
                        >
                          <label className="mb-1 lbl-bdi-inr-class">
                            {" "}
                            {marketingLanguage.AppliesTO}
                          </label>
                          <div className="row">
                            <div className="col-12 mb-2">
                              <label className="cust-radio mb-0">
                                <input
                                  type="radio"
                                  id="allproduct"
                                  value="All Product"
                                  name="Applies1"
                                  defaultChecked
                                />
                                <span className="checkmark"></span>
                                <span>{marketingLanguage.allProduct}</span>
                              </label>
                            </div>
                            {this.state.discountType === "fixed" ? (
                              <>
                                <div className="col-12 mb-2">
                                  <label className="cust-radio mb-0">
                                    <input
                                      type="radio"
                                      id="2"
                                      value="Specific Category"
                                      name="Applies1"
                                      disabled
                                    />
                                    <span className="checkmark"></span>
                                    <span>
                                      {marketingLanguage.specificCategory}
                                    </span>
                                  </label>
                                </div>
                                <div className="col-12 mb-2">
                                  <label className="cust-radio mb-0">
                                    <input
                                      type="radio"
                                      id="3"
                                      value="Specific Products"
                                      name="Applies1"
                                      disabled
                                    />
                                    <span className="checkmark"></span>
                                    <span>
                                      {marketingLanguage.specificProduct}
                                    </span>
                                  </label>
                                </div>
                              </>
                            ) : (
                              <>
                                <div className="col-12 mb-2">
                                  <label className="cust-radio mb-0">
                                    <input
                                      type="radio"
                                      id="2"
                                      value="Specific Category"
                                      name="Applies1"
                                    />
                                    <span className="checkmark"></span>
                                    <span>
                                      {marketingLanguage.specificCategory}
                                    </span>
                                  </label>
                                </div>
                                <div className="col-12 mb-2">
                                  <label className="cust-radio mb-0">
                                    <input
                                      type="radio"
                                      id="3"
                                      value="Specific Products"
                                      name="Applies1"
                                    />
                                    <span className="checkmark"></span>
                                    <span>
                                      {marketingLanguage.specificProduct}
                                    </span>
                                  </label>
                                </div>
                              </>
                            )}
                            <div
                              id="product_apply-validate"
                              style={{ display: "none" }}
                              className="input-feedback text-danger"
                            >
                              required Category or Product
                            </div>
                          </div>
                        </div>
                        <div className="col-12 form-group pb-3">
                          <div className="d-flex align-items-center">
                            <div className="w-100 src-with-btn-class position-relative">
                              {/* <input type="text" name="" className="form-control input-custom-class mb-0" placeholder={marketingLanguage.searchCategories} />
                              <span className="position-absolute">
                                <i className="bi bi-search"></i>
                              </span> */}
                              <label className="mb-1 lbl-bdi-inr-class">
                                {marketingLanguage.SelectSpecificProduct}/
                                {marketingLanguage.SelectSpecificCategory}
                              </label>
                            </div>
                            <div className="ps-3 src-with-btn-class-inr">
                              <button
                                type="button"
                                name="Browse1"
                                onClick={this.handleBrowse1Submit}
                              >
                                {marketingLanguage.Browse}
                              </button>
                            </div>
                          </div>
                        </div>
                        <div
                          id="Browse1-validate"
                          style={{ display: "none" }}
                          className="input-feedback text-danger"
                        >
                          Select Specific Category or Product
                        </div>
                        <div className="col-12 form-group pb-3 mt-2">
                          <div className="table-responsive">
                            {this.state.selectedCategoryData.length > 0 && (
                              <table className="table">
                                <thead>
                                  <tr>
                                    <th>Name</th>
                                    <th></th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {this.state.selectedCategoryData.map(
                                    (data, i) => (
                                      <tr key={i}>
                                        <td>{data.category_english}</td>
                                        <td className="text-end">
                                          <button
                                            type="button"
                                            className="p-0 bg-transparent border-0"
                                            onClick={() =>
                                              this.handleCategoryCancel(data)
                                            }
                                          >
                                            <i className="bi bi-x-lg"></i>
                                          </button>
                                        </td>
                                      </tr>
                                    )
                                  )}
                                </tbody>
                              </table>
                            )}
                            {this.state.selectedData.length > 0 && (
                              <table className="table">
                                <thead>
                                  <tr>
                                    <th>Items</th>
                                    <th>Barcode</th>
                                    <th>Name</th>
                                    <th></th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {this.state.selectedData.map((data, i) => (
                                    <tr key={i}>
                                      <td>
                                        {" "}
                                        <img
                                          src={data.thumbnail}
                                          alt="image"
                                          className="imgfix-smpl-tbl"
                                        />
                                      </td>
                                      <td>{data.barcode}</td>
                                      <td>{data.title_en}</td>
                                      <td className="text-end">
                                        <button
                                          type="button"
                                          className="p-0 bg-transparent border-0"
                                          onClick={() =>
                                            this.handleCancel(data)
                                          }
                                        >
                                          <i className="bi bi-x-lg"></i>
                                        </button>
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-lg-4">
                      <div className="row">
                        <div className="col-12 pb-2">
                          <label className="cust-chk-bx">
                            <input
                              name="exclude_customer"
                              type="checkbox"
                              onChange={this.handleexclude_customer}
                              value={this.state.exclude_customer}
                              required
                            />
                            <span className="cust-chkmark"></span>
                            <bdi>
                              {marketingLanguage.excludeCustomerDoingReturnMore}
                            </bdi>
                          </label>
                        </div>
                        <div
                          className="col-12 form-group pb-3"
                          name="customer"
                          onChange={this.handleCustomerChange}
                          value={this.state.customer}
                          required
                        >
                          <label className="mb-1 lbl-bdi-inr-class">
                            {" "}
                            {marketingLanguage.customers}
                          </label>
                          <div className="row">
                            <div className="col-4">
                              <label className="cust-radio mb-0">
                                <input
                                  type="radio"
                                  id="1"
                                  value="Include"
                                  name="customers"
                                  defaultChecked
                                />
                                <span className="checkmark"></span>
                                <span>{marketingLanguage.include} </span>
                              </label>
                            </div>
                            <div className="col-4">
                              <label className="cust-radio mb-0">
                                <input
                                  type="radio"
                                  id="2"
                                  value="Exclude"
                                  name="customers"
                                />
                                <span className="checkmark"></span>
                                <span>{marketingLanguage.exclude}</span>
                              </label>
                            </div>
                            <div
                              id="customer-validate"
                              style={{ display: "none" }}
                              className="input-feedback text-danger"
                            >
                              required
                            </div>
                          </div>
                        </div>
                        <div
                          className="col-12 form-group pb-3"
                          name="customer_apply"
                          onChange={this.handlecustomer_applyChange}
                          value={this.state.customer_apply}
                          required
                        >
                          <label className="mb-1 lbl-bdi-inr-class">
                            {" "}
                            {marketingLanguage.AppliesTO}
                          </label>
                          <div className="row">
                            <div className="col-12 mb-2">
                              <label className="cust-radio mb-0">
                                <input
                                  type="radio"
                                  id="allcustomers"
                                  value="All Customers"
                                  name="Applies2"
                                  defaultChecked
                                />
                                <span className="checkmark"></span>
                                <span>{marketingLanguage.allCustomer}</span>
                              </label>
                            </div>
                            <div className="col-12 mb-2">
                              <label className="cust-radio mb-0">
                                <input
                                  type="radio"
                                  id="2"
                                  value="Specific Customer Groups"
                                  name="Applies2"
                                />
                                <span className="checkmark"></span>
                                <span>
                                  {marketingLanguage.specificCustomer}
                                </span>
                              </label>
                            </div>
                            {/* <div className="col-12 mb-2">
                              <label className="cust-radio mb-0">
                                <input type="radio" id="3" name="Applies2" />
                                <span className="checkmark"></span>
                                <span>
                                  {marketingLanguage.specificCustomers}
                                </span>
                              </label>
                            </div> */}
                            <div
                              id="customer_apply-validate"
                              style={{ display: "none" }}
                              className="input-feedback text-danger"
                            >
                              required Specific Customer
                            </div>
                          </div>
                        </div>
                        <div className="col-12 form-group pb-3">
                          <div className="d-flex align-items-center">
                            <div className="w-100 src-with-btn-class position-relative">
                              {/* <input type="text" name="" className="form-control input-custom-class mb-0" placeholder={marketingLanguage.searchCustomerGroup} />
                              <span className="position-absolute">
                                <i className="bi bi-search"></i>
                              </span> */}

                              <label className="mb-1 lbl-bdi-inr-class">
                                {marketingLanguage.SelectSpecificcustomers}:
                              </label>
                            </div>
                            <div className="ps-3 src-with-btn-class-inr">
                              <button
                                type="button"
                                name="Browse2"
                                onClick={this.handleBrowse2Submit}
                              >
                                {marketingLanguage.Browse}
                              </button>
                            </div>
                          </div>
                        </div>
                        <div
                          id="Browse2-validate"
                          style={{ display: "none" }}
                          className="input-feedback text-danger"
                        >
                          Select Specific Customer
                        </div>
                        <div className="col-12 form-group pb-3 mt-2">
                          <div className="table-responsive">
                            {this.state.selectedCustomersData.length > 0 && (
                              <table className="table">
                                <thead>
                                  <tr>
                                    <th>Username</th>
                                    <th>{marketingLanguage.eMail}</th>
                                    <th>{marketingLanguage.phoneNumber}</th>
                                    <th></th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {this.state.selectedCustomersData.map(
                                    (data, i) => (
                                      <tr key={i}>
                                        <td>{data.fullname}</td>
                                        <td>{data.email}</td>
                                        <td>{data.phone}</td>
                                        <td className="text-end">
                                          <button
                                            type="button"
                                            className="p-0 bg-transparent border-0"
                                            onClick={() =>
                                              this.handleCustomersCancel(data)
                                            }
                                          >
                                            <i className="bi bi-x-lg"></i>
                                          </button>
                                        </td>
                                      </tr>
                                    )
                                  )}
                                </tbody>
                              </table>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-lg-4">
                      <div className="row">
                        <div className="col-12 pb-2 invisible">
                          <label className="cust-chk-bx">
                            <input name="" type="checkbox" />
                            <span className="cust-chkmark"></span>
                            <bdi>{marketingLanguage.excludeSaleItem}</bdi>
                          </label>
                        </div>
                        <div
                          className="col-12 form-group pb-3"
                          name="payment"
                          onChange={this.handlePaymentChange}
                          value={this.state.payment}
                          required
                        >
                          <label className="mb-1 lbl-bdi-inr-class">
                            {" "}
                            {marketingLanguage.PaymentMethods}
                          </label>
                          <div className="row">
                            <div className="col-4">
                              <label className="cust-radio mb-0">
                                <input
                                  type="radio"
                                  id="1"
                                  value="Include"
                                  name="payments"
                                  defaultChecked
                                />
                                <span className="checkmark"></span>
                                <span>{marketingLanguage.include} </span>
                              </label>
                            </div>
                            <div className="col-4">
                              <label className="cust-radio mb-0">
                                <input
                                  type="radio"
                                  id="2"
                                  value="Exclude"
                                  name="payments"
                                />
                                <span className="checkmark"></span>
                                <span>{marketingLanguage.exclude}</span>
                              </label>
                            </div>
                            <div
                              id="payment-validate"
                              style={{ display: "none" }}
                              className="input-feedback text-danger"
                            >
                              required
                            </div>
                          </div>
                        </div>
                        <div
                          className="col-12 form-group pb-3"
                          name="payment_apply"
                          onChange={this.handlepayment_applyChange}
                          value={this.state.payment_apply}
                          required
                        >
                          <label className="mb-1 lbl-bdi-inr-class">
                            {marketingLanguage.AppliesTO}
                          </label>
                          <div className="row">
                            <div className="col-12 pb-2">
                              <label className="cust-chk-bx">
                                <input
                                  name="Applies3"
                                  type="checkbox"
                                  defaultChecked
                                  onChange={(e) => {
                                    const isChecked = e.target.checked;
                                    if (isChecked) {
                                      this.setState({
                                        payment_apply: "All Payment methods",
                                        paymentmethods: [],
                                        disablePaymentMethodSelect:
                                          e.target.checked,
                                      });
                                    } else {
                                      this.setState({
                                        payment_apply: "",
                                        disablePaymentMethodSelect:
                                          e.target.checked,
                                      });
                                    }
                                  }}
                                  value="All Payment methods"
                                />
                                <span className="cust-chkmark"></span>
                                <bdi>{marketingLanguage.allPayMethods}</bdi>
                              </label>
                            </div>
                            <div className="col-12 mb-2">
                              <label className="cust-radio mb-0 ps-0 pt-2">
                                <ul>
                                  <li>
                                    {marketingLanguage.specificPayMethods}
                                  </li>
                                </ul>
                                <div className="form-group col-12">
                                  <Select
                                    isMulti
                                    id="specificPayment"
                                    name="paymentmethods"
                                    closeMenuOnSelect={false}
                                    styles={this.customStyles}
                                    options={paymentMethodOptions}
                                    value={this.state.paymentmethods}
                                    onChange={this.handlepaymentmethods}
                                    isDisabled={disablePaymentMethodSelect}
                                  />
                                </div>
                              </label>
                            </div>
                            <div
                              id="payment_apply-validate"
                              style={{ display: "none" }}
                              className="input-feedback text-danger"
                            >
                              required Payment Methods
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>

              {/* //=================================== 333 =================================== */}

              <div className="pb-4">
                <div className="white-box">
                  <div className="row custom-border-title">
                    <div className="col-md-12">
                      <div className="product-header">
                        <span>{marketingLanguage.Activedates}</span>
                      </div>
                    </div>
                  </div>

                  <Formik
                    initialValues={{
                      startdate: moment(Date.now()).format("YYYY-MM-DD"),
                      starttime: moment(Date.now()).format("hh:mm"),
                    }}
                    onSubmit={async (values) => {
                      this.getThirdFormData(values);
                    }}
                    validationSchema={Yup.object().shape({
                      startdate: Yup.string().required(
                        "Start date is required"
                      ),
                      starttime: Yup.string().required(
                        "Start time is required"
                      ),
                    })}
                  >
                    {(props) => {
                      const {
                        touched,
                        errors,
                        // isSubmitting,
                        values,
                        handleChange,
                        handleBlur,
                        handleSubmit,
                      } = props;
                      return (
                        <div className="row">
                          <div className="col-md-6">
                            <form className="row mt-3" onSubmit={handleSubmit}>
                              <div className="form-group col-lg-6 col-6">
                                <label className="mb-2 lbl-bdi-inr-class">
                                  {marketingLanguage.Startdate}
                                </label>
                                <input
                                  type="date"
                                  name="startdate"
                                  className="form-control input-custom-class"
                                  value={values.startdate}
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  placeholder="01/02/2022"
                                />
                                {touched.startdate && errors.startdate && (
                                  <div className="input-feedback text-danger">
                                    {errors.startdate}
                                  </div>
                                )}
                              </div>
                              <div className="form-group col-lg-6 col-6">
                                <label className="mb-2 lbl-bdi-inr-class">
                                  {marketingLanguage.Starttime}
                                </label>
                                <input
                                  type="time"
                                  name="starttime"
                                  className="form-control input-custom-class"
                                  value={values.starttime}
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  placeholder="4:57 PM"
                                />
                                {touched.starttime && errors.starttime && (
                                  <div className="input-feedback text-danger">
                                    {errors.starttime}
                                  </div>
                                )}
                              </div>
                              <div className="col-12">
                                <label className="cust-chk-bx">
                                  <input
                                    name="sizeArabic4"
                                    value={values.sizeArabic4}
                                    onChange={this.handleSetEndDate}
                                    onBlur={handleBlur}
                                    type="checkbox"
                                  />
                                  <span className="cust-chkmark"></span>
                                  <bdi>{marketingLanguage.setEndDate}</bdi>
                                </label>
                              </div>
                              <div
                                className="form-group col-lg-6 col-6 mt-4"
                                id="enddate"
                              >
                                <label className="mb-2 lbl-bdi-inr-class">
                                  {marketingLanguage.EndDate}
                                </label>
                                <input
                                  type="date"
                                  name="enddate"
                                  className="form-control input-custom-class"
                                  value={values.enddate}
                                  min={Moment(values.startdate).format(
                                    "YYYY-MM-DD"
                                  )}
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  placeholder="01/03/2022"
                                />
                              </div>
                              <div
                                className="form-group col-lg-6 col-6 mt-4"
                                id="endtime"
                              >
                                <label className="mb-2 lbl-bdi-inr-class">
                                  {marketingLanguage.EndTime}
                                </label>
                                <input
                                  type="time"
                                  name="endtime"
                                  className="form-control input-custom-class"
                                  value={values.endtime}
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  placeholder="2:25 AM"
                                />
                              </div>
                              <div className="text-md-end text-center pb-3 d-none">
                                <button
                                  type="submit"
                                  id="third-btn"
                                  className="red-btn ms-3"
                                >
                                  {buttonLanguage.save}
                                </button>
                              </div>
                            </form>
                          </div>
                          <div className="col-md-6 mt-3">
                            <div>
                              <label className="cust-chk-bx">
                                <input name="sizeArabic4" type="checkbox" />
                                <span className="cust-chkmark"></span>
                                <bdi className="text-dark">
                                  {marketingLanguage.Influencercoupon}
                                </bdi>
                              </label>
                            </div>
                            <div className="form-group pb-3">
                              <div className="d-flex align-items-center">
                                <div className="w-100 src-with-btn-class position-relative">
                                  <input
                                    type="text"
                                    name=""
                                    className="form-control input-custom-class mb-0"
                                    placeholder="select influencer"
                                  />
                                  <span className="position-absolute">
                                    <i className="bi bi-search"></i>
                                  </span>
                                </div>
                                <div className="ps-3 src-with-btn-class-inr">
                                  <button type="button" name="Browse1">
                                    {marketingLanguage.Browse}
                                  </button>
                                </div>
                              </div>
                            </div>
                            <div
                              className="form-group col-sm-6 mt-4"
                              id="enddate"
                            >
                              <label className="mb-2 lbl-bdi-inr-class">
                                {marketingLanguage.Influencercommission}
                              </label>
                              <p className="ps-4 text-secondary">7%</p>
                            </div>
                          </div>
                        </div>
                      );
                    }}
                  </Formik>
                </div>
              </div>

              {/* //=================================== BUTTON =================================== */}

              <div className="text-md-end text-center pb-3">
                <button type="button" id="CouponCancel" className="black-btn">
                  {buttonLanguage.cancel}
                </button>
                <button
                  type="submit"
                  id="CouponSubmit"
                  onClick={this.handlecouponSubmit}
                  className="red-btn ms-3"
                >
                  {buttonLanguage.save}
                </button>
              </div>
            </div>
          </div>
        </div>

        <Modal
          dialogClassName="modal-dialog-centered cust-width-modal modal-dialog-scrollable"
          className="edit-user-modal cust-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.specificCategoryShow}
          onHide={this.specificCategoryClose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">Select Specific category</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.specificCategoryClose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <div className="white-box cuts-popup-tbl p-0">
              <div className="form-group pb-3">
                <div className="d-flex align-items-center">
                  <div className="w-100 src-with-btn-class position-relative">
                    <input
                      type="text"
                      name=""
                      className="form-control input-custom-class mb-0"
                      placeholder={marketingLanguage.searchCategories}
                      onChange={this.handleCategorySearch}
                    />
                    <span className="position-absolute">
                      <i className="bi bi-search"></i>
                    </span>
                  </div>
                </div>
              </div>
              <div className="form-group pb-3 mt-2">
                <div className="table-responsive">
                  <table className="table">
                    <thead>
                      <tr>
                        <th></th>
                        <th>Image</th>
                        <th>Main Categories</th>
                        <th>Categories</th>
                        <th>Sub Categories</th>
                      </tr>
                    </thead>
                    <tbody>
                      {this.state.subCategoryData &&
                        this.state.subCategoryData.map((data, i) => (
                          <tr key={i}>
                            <td>
                              <label className="cust-chk-bx">
                                <input
                                  name=""
                                  type="checkbox"
                                  onChange={(e) =>
                                    this.handleCategoryCheckboxChange(e, data)
                                  }
                                  required
                                />
                                <span className="cust-chkmark"></span>
                              </label>
                            </td>
                            <td>
                              {" "}
                              <img
                                src={data.thumbnail}
                                alt="image"
                                className="imgfix-smpl-tbl"
                              />
                            </td>
                            <td>{data.main_english}</td>
                            <td>{data.category_english}</td>
                            <td>{data.english}</td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <div className="form-group pb-0 my-0 mx-auto">
              <div className="text-md-end text-center">
                <button
                  type="submit"
                  className="red-btn ms-3"
                  onClick={this.handleCategoryAdd}
                >
                  {marketingLanguage.add}
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>

        <Modal
          dialogClassName="modal-dialog-centered cust-width-modal modal-dialog-scrollable"
          className="edit-user-modal cust-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.specificProductsShow}
          onHide={this.specificProductsClose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">
                {marketingLanguage.SelectSpecificProducts}
              </h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.specificProductsClose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <div className="white-box cuts-popup-tbl p-0">
              <div className="form-group pb-3">
                <div className="d-flex align-items-center">
                  <div className="w-100 src-with-btn-class position-relative">
                    <input
                      type="text"
                      name=""
                      className="form-control input-custom-class mb-0"
                      placeholder={marketingLanguage.searchCategories}
                      onChange={this.handleProductsSearch}
                    />
                    <span className="position-absolute">
                      <i className="bi bi-search"></i>
                    </span>
                  </div>
                </div>
              </div>
              <div className="form-group text-center pb-3 mt-2">
                <div className="table-responsive">
                  <table className="table">
                    <thead>
                      <tr>
                        <th></th>
                        <th>item</th>
                        <th>Barcode</th>
                        <th>Name</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      {this.state.SpecificProductsData &&
                        this.state.SpecificProductsData.map((data, i) => (
                          <tr key={i}>
                            <td>
                              <label className="cust-chk-bx">
                                <input
                                  name=""
                                  type="checkbox"
                                  onChange={(e) =>
                                    this.handleCheckboxChange(e, data)
                                  }
                                />
                                <span className="cust-chkmark"></span>
                              </label>
                            </td>
                            <td>
                              {" "}
                              <img
                                src={data.thumbnail}
                                alt="image"
                                className="imgfix-smpl-tbl"
                              />
                            </td>
                            <td>{data.barcode}</td>
                            <td>{data.title_en}</td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
                <button
                  type="button"
                  className="red-btn align-item-center mt-3"
                  onClick={this.loadMoreSpecificProducts}
                >
                  {this.state.loadmoreLoader
                    ? "Loading...."
                    : "LoadMoreProduct"}
                </button>
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <div className="form-group mx-auto">
              <div className="text-center">
                <button
                  type="submit"
                  className="red-btn "
                  name="add"
                  onClick={this.handleAdd}
                >
                  {marketingLanguage.add}
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>

        <Modal
          dialogClassName="modal-dialog-centered cust-width-modal modal-dialog-scrollable"
          className="edit-user-modal cust-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.CustomersShow}
          onHide={this.CustomersClose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">{marketingLanguage.customers}</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.CustomersClose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <div className="white-box cuts-popup-tbl p-0">
              <div className="form-group pb-3">
                <div className="d-flex align-items-center">
                  <div className="w-100 src-with-btn-class position-relative">
                    <input
                      type="text"
                      name=""
                      className="form-control input-custom-class mb-0"
                      placeholder={marketingLanguage.searchCategories}
                      onChange={this.handleCustomersSearch}
                    />
                    <span className="position-absolute">
                      <i className="bi bi-search"></i>
                    </span>
                  </div>
                </div>
              </div>
              <div className="form-group text-center pb-3 mt-2">
                <div className="table-responsive">
                  <table className="table">
                    <thead>
                      <tr>
                        <th></th>
                        <th>Name</th>
                        <th>{marketingLanguage.eMail}</th>
                        <th>{marketingLanguage.phoneNumber}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {this.state.CustomersData.length > 0 &&
                        this.state.CustomersData.map((data, i) => (
                          <tr key={i}>
                            <td>
                              <label className="cust-chk-bx">
                                <input
                                  name=""
                                  type="checkbox"
                                  onChange={(e) =>
                                    this.handleCustomersCheckboxChange(e, data)
                                  }
                                />
                                <span className="cust-chkmark"></span>
                              </label>
                            </td>
                            <td>{data.fullname}</td>
                            <td>{data.email}</td>
                            <td>{data.phone}</td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
                {this.state.showLoadmoreCustomerButton && (
                  <button
                    type="button"
                    className="red-btn align-item-center mt-3"
                    onClick={this.loadMoreCustomersData}
                  >
                    {this.state.customerloadmoreLoader
                      ? "Loading...."
                      : "LoadMoreProduct"}
                  </button>
                )}
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <div className="form-group pb-0 my-0 mx-auto">
              <div className="text-md-end text-center">
                <button
                  type="submit"
                  className="red-btn ms-3"
                  onClick={this.handleCustomersAdd}
                >
                  {marketingLanguage.add}
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
      </Adminlayout>
    );
  }
}

export default withRouter(AddCoupon);
