import { Tabs, Tab, Accordion } from "react-bootstrap";
import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import LanguageContext from "../../contexts/languageContext";
import {
  API_Path,
  buttonArabic,
  buttonEnglish,
  TableFieldArabic,
  TableFieldEnglish,
  titleArabic,
  titleEnglish,
  HelpEnglish,
  HelpArabic,
} from "../../const";

class HelpandSupport extends Component {
  static contextType = LanguageContext;

  constructor(props) {
    super(props);
    this.state = {
      enableSwitch: true,
    };
  }
  handleSwitch = () => {
    this.setState({ enableSwitch: !this.state.enableSwitch });
  };

  render() {
    let Language =
      this.context.language === "english"
        ? TableFieldEnglish
        : TableFieldArabic;
    let ButtonLanguage =
      this.context.language === "english" ? buttonEnglish : buttonArabic;
    let titleLanguage =
      this.context.language === "english" ? titleEnglish : titleArabic;
    let HelpLanguage =
      this.context.language === "english" ? HelpEnglish : HelpArabic;
    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space">
            <div className="col-sm-12 text-sm-start text-center rtl-txt-start">
              <div className="common-header-txt">
                <h3>{HelpLanguage.HelpAndSupport}</h3>
              </div>
            </div>
          </div>
          <div className="row common-space">
            <div className="col-sm-12">
              <div className="white-box">
                <div className="cust-tab">
                  <Tabs
                    defaultActiveKey="FAQs"
                    id="uncontrolled-tab-example"
                    className="mb-3"
                  >
                    <Tab
                      eventKey="privacy_policy"
                      title={HelpLanguage.PrivacyPolicy}
                    >
                      1
                    </Tab>
                    <Tab
                      eventKey="terms_and_conditions"
                      title={HelpLanguage.TermsAndConditions}
                    >
                      2
                    </Tab>
                    <Tab
                      eventKey="disclaimers"
                      title={HelpLanguage.Disclaimers}
                    >
                      3
                    </Tab>
                    <Tab eventKey="FAQs" title={HelpLanguage.FAQs}>
                      <Accordion
                        className="cust-accordian"
                        defaultActiveKey="0"
                        flush
                      >
                        <Accordion.Item eventKey="0">
                          <Accordion.Header>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do ?
                          </Accordion.Header>
                          <Accordion.Body>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do eiusmod tempor incididunt ut labore et
                            dolore magna aliqua. Ut enim ad minim veniam, quis
                            nostrud exercitation ullamco laboris nisi ut aliquip
                            ex ea commodo consequat. Duis aute irure dolor in
                            reprehenderit in voluptate velit esse cillum dolore
                            eu fugiat nulla pariatur. Excepteur sint occaecat
                            cupidatat non proident, sunt in culpa qui officia
                            deserunt mollit anim id est laborum.
                          </Accordion.Body>
                        </Accordion.Item>
                        <Accordion.Item eventKey="1">
                          <Accordion.Header>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do ?
                          </Accordion.Header>
                          <Accordion.Body>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do eiusmod tempor incididunt ut labore et
                            dolore magna aliqua. Ut enim ad minim veniam, quis
                            nostrud exercitation ullamco laboris nisi ut aliquip
                            ex ea commodo consequat. Duis aute irure dolor in
                            reprehenderit in voluptate velit esse cillum dolore
                            eu fugiat nulla pariatur. Excepteur sint occaecat
                            cupidatat non proident, sunt in culpa qui officia
                            deserunt mollit anim id est laborum.
                          </Accordion.Body>
                        </Accordion.Item>
                        <Accordion.Item eventKey="2">
                          <Accordion.Header>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do ?
                          </Accordion.Header>
                          <Accordion.Body>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do eiusmod tempor incididunt ut labore et
                            dolore magna aliqua. Ut enim ad minim veniam, quis
                            nostrud exercitation ullamco laboris nisi ut aliquip
                            ex ea commodo consequat. Duis aute irure dolor in
                            reprehenderit in voluptate velit esse cillum dolore
                            eu fugiat nulla pariatur. Excepteur sint occaecat
                            cupidatat non proident, sunt in culpa qui officia
                            deserunt mollit anim id est laborum.
                          </Accordion.Body>
                        </Accordion.Item>
                        <Accordion.Item eventKey="3">
                          <Accordion.Header>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do ?
                          </Accordion.Header>
                          <Accordion.Body>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do eiusmod tempor incididunt ut labore et
                            dolore magna aliqua. Ut enim ad minim veniam, quis
                            nostrud exercitation ullamco laboris nisi ut aliquip
                            ex ea commodo consequat. Duis aute irure dolor in
                            reprehenderit in voluptate velit esse cillum dolore
                            eu fugiat nulla pariatur. Excepteur sint occaecat
                            cupidatat non proident, sunt in culpa qui officia
                            deserunt mollit anim id est laborum.
                          </Accordion.Body>
                        </Accordion.Item>
                        <Accordion.Item eventKey="4">
                          <Accordion.Header>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do ?
                          </Accordion.Header>
                          <Accordion.Body>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do eiusmod tempor incididunt ut labore et
                            dolore magna aliqua. Ut enim ad minim veniam, quis
                            nostrud exercitation ullamco laboris nisi ut aliquip
                            ex ea commodo consequat. Duis aute irure dolor in
                            reprehenderit in voluptate velit esse cillum dolore
                            eu fugiat nulla pariatur. Excepteur sint occaecat
                            cupidatat non proident, sunt in culpa qui officia
                            deserunt mollit anim id est laborum.
                          </Accordion.Body>
                        </Accordion.Item>
                      </Accordion>
                    </Tab>
                  </Tabs>
                </div>
              </div>
            </div>
          </div>
          <div className="row common-space">
            <div className="col-md-12">
              <div className="row m-0 white-box">
                <div className="col-md-6 p-0">
                  <div className="help-support-txt ">
                    <label className="cust-radio">
                      <input type="radio" name="radio" />
                      <span className="checkmark" />
                    </label>
                    <span>WhatsApp (Off platform Chat & Support service)</span>
                  </div>
                </div>
                <div className="col-md-6 p-0">
                  <div className="help-support-txt ">
                    <label className="cust-radio">
                      <input
                        type="radio"
                        checked={this.state.enableSwitch}
                        onChange={this.handleSwitch}
                        name="radio"
                      />
                      <span className="checkmark" />
                    </label>

                    <span>Tawk.to (On platform Chat & Support service)</span>

                    {/* <label className="switch">
                                            <input type="checkbox" checked={this.state.enableSwitch} onChange={this.handleSwitch} />
                                            <div className="slider round" />
                                        </label> */}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Adminlayout>
    );
  }
}

export default HelpandSupport;
