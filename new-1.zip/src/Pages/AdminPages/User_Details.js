// City not coming [order: 764910]
// there are two addresses
// maybe default address not set

// Building Name/House No, Floor, Apartment No
// to be mandatory in website

// ---------------------------------------------

import React, { Component } from "react";
import { Link, withRouter } from "react-router-dom";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import DataTable from "../../Components/DataTable";
import { textFilter } from "react-bootstrap-table2-filter";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";
import LanguageContext from "../../contexts/languageContext";
import {
  API_Path,
  TableFieldArabic,
  TableFieldEnglish,
  titleArabic,
  titleEnglish,
  UserEnglish,
  buttonArabic,
  buttonEnglish,
  UserArabic,
} from "../../const";
import { GetApi, PostApi } from "../../helper/APIService";
import { Dropdown, Accordion, Modal } from "react-bootstrap";
import PhoneInput from "react-phone-input-2";
import Cust_1 from "../../images/cust-top-1.svg";
import Cust_2 from "../../images/cust-top-2.svg";
import Cust_3 from "../../images/cust-top-3.svg";
import Cust_4 from "../../images/cust-top-4.svg";
import moment from "moment";
import { Formik } from "formik";
import toastr from "toastr";

import * as Yup from "yup";
import OtpInput from "react-otp-input";

class UserDetails extends Component {
  static contextType = LanguageContext;
  constructor(props) {
    super(props);
    this.state = {
      page: 1,
      sizePerPage: 10,
      totalSize: 0,
      defaultSorted: [
        {
          dataField: "createdat",
          order: "desc",
        },
      ],
      default: 0,
      phone: "",
      city: "",
      area: "",
      CityData: "",
      areaData: "",
      isocode: "",
      search: "",
      userDetail: {},
      addressData: "",
      editForm: false,
      formShow: false,
      user_id: "",
      add_type: "",
      area_id: "",
      city_id: "",
      UserLadger: "",
      UserRecentOrder: [],
      WalletMoneyStatus: "",
      walletOtp: "",
      addmoneymodal: false,
      intervalId: null,
      countdown: 0,
      WithdrawMoneyReason: "",
      WithdrawWalletMoney: "",
      AddMoneyReason: "",
      AddMoneyWallet: "",
      AdminDetails: "",
      selectOTPNumber: "",
      userArea: "",
      userCity: "",
      banCustomer: false,
      codCustomerStatus: false,
      subWhatsapp: false,
      subEmail: false,
      subSms: false,
      editCustomerMark: "",
      editCustomerName: "",
      editCustomerNumber: "",
      editCustomerEmail: "",
      editCustomerGender: "",
      editCustomerLaguage: "",
      editCustomerDOB: "",
      NoteModalShow: false,
      customerNote: "",
      userNote: "",
      noteUpdatedDate: "",
    };
    this.runforms = React.createRef();
    this.customerRunforms = React.createRef();
    this.focusInput = React.createRef();
  }

  componentDidMount() {
    let userId = window.location.href.substr(
      window.location.href.lastIndexOf("/") + 1
    );
    this.setState({ user_id: userId });
    this.get_user_detail(userId);
    // this.getAreaData();
    this.getUserLedger(userId);
    this.getRecentOrder(userId, 1, 10, this.state.defaultSorted);
    this.getCityData();
    this.getAllAddress(userId);
  }

  get_user_detail = (userId) => {
    const GetUserDetailsPromise = new Promise((resolve) => {
      resolve(PostApi(API_Path.getUserDetails, { user_id: userId }));
    });

    GetUserDetailsPromise.then((res) => {
      if (res) {
        this.setState({ userDetail: res.data.data[0] }, () => {
          this.setState({
            banCustomer: res.data.data[0].status == 0 ? true : false,
            codCustomerStatus:
              res.data.data[0].cod_deactivate == 1 ? true : false,
            subWhatsapp: res.data.data[0].sub_whatsapp == 1 ? true : false,
            subEmail: res.data.data[0].sub_email == 1 ? true : false,
            subSms: res.data.data[0].sub_sms == 1 ? true : false,
            editCustomerMark: res.data.data[0].mark,
            editCustomerName: res.data.data[0].first_name,
            editCustomerNumber:
              res.data.data[0].phone.substring(0, 3) !== "966"
                ? "966" + res.data.data[0].phone
                : res.data.data[0].phone,
            editCustomerEmail: res.data.data[0].email,
            editCustomerGender: res.data.data[0].gender,
            editCustomerLaguage: res.data.data[0].language,
            editCustomerDOB: res.data.data[0].date_of_birth
              ? moment(res.data.data[0].date_of_birth).format("YYYY-MM-DD")
              : "",
            userNote: res.data.data[0].note,
            noteUpdatedDate: res.data.data[0].note_time
              ? moment.utc(res.data.data[0].note_time)
              : "",
          });
        });
      }
    });
  };
  getUserLedger = (id) => {
    let UserData = {
      user_id: id,
    };
    new Promise((resolve) => {
      resolve(PostApi(API_Path.getUserLedger, UserData));
    }).then((res) => {
      if (res) {
        if (res.data.success) {
          this.setState({ UserLadger: res.data.data });
        }
      }
    });
  };
  getRecentOrder = (id, page, row, defaultSorted) => {
    let User_orde_Data = {
      user_id: id,
      page: page,
      sizePerPage: row,
      defaultSorted: defaultSorted,
    };
    new Promise((resolve) => {
      resolve(PostApi(API_Path.getUserRecentOrders, User_orde_Data));
    }).then((res) => {
      if (res) {
        if (res.data.success) {
          this.setState({
            UserRecentOrder: res.data.data,
            totalSize: res.data.totalRecord,
          });
        }
      }
    });
  };

  getCityData = (value) => {
    let data = { search_val: value };

    let path = API_Path.getCityData;
    const getCityDataPromise = new Promise((resolve) => {
      resolve(PostApi(path, data));
    });

    getCityDataPromise.then((res) => {
      if (res.data.success) {
        this.setState({ CityData: res.data.data }, () => {
          // this.state.CityData.map((item, i) => {
          //     if (i === 0) {
          //         this.setState({ city: item.id });
          //     }
          // });
        });
      }
    });
  };

  getAreaData = (value) => {
    let data = { isocode: value };

    let path = API_Path.getArea;
    const getAreaDataPromise = new Promise((resolve) => {
      resolve(PostApi(path, data));
    });

    getAreaDataPromise.then((res) => {
      if (res.data.success) {
        this.setState({ areaData: res.data.data }, () => {
          // this.state.areaData.map((item, i) => {
          //     if (i === 0) {
          //         this.setState({ area: item.id });
          //     }
          // });
        });
      }
    });
  };

  getAllAddress = (id) => {
    let path = API_Path.getCoustomerAddress;
    let data = {
      user_id: id,
    };
    const getAddressPromise = new Promise((resolve) => {
      resolve(PostApi(path, data));
    });
    getAddressPromise.then((res) => {
      if (res.data.success) {
        if (res.data.data.length > 0) {
          this.setState({ addressData: res.data.data }, () => {
            for (let i = 0; i < this.state.addressData.length; i++) {
              if (this.state.addressData[i].defaults == 1) {
                this.setState({
                  userCity:
                    this.context.language === "english"
                      ? this.state.addressData[i].city_en
                      : this.state.addressData[i].city_ar,
                  userArea:
                    this.context.language === "english"
                      ? this.state.addressData[i].area_en
                      : this.state.addressData[i].area_ar,
                });
              }
            }
            // if (document.getElementById("address-" + this.state.addressData[0].id)) {
            //   document.getElementById("address-" + this.state.addressData[0].id).click();
            // }
          });
        } else {
          this.setState({ addressData: "" });
        }
      }
    });
  };

  getAddressById = (id) => {
    let path = API_Path.getAddressById2;
    let data = { id: id, user_id: parseInt(this.state.user_id) };
    const getAddressbyIdPromise = new Promise((resolve) => {
      resolve(PostApi(path, data));
    });
    getAddressbyIdPromise.then((res) => {
      if (res) {
        let data = res.data.data[0];
        this.setState({
          edit_data: res.data.data[0],
          email: data.email,
          city: data.city_en,
          idToEdit: data.id,
          add_type: data.type,
          fullName: data.name,
          line_1: data.line_1,
          line_2: data.line_2,
          area: data.area_en,
          default: data.defaults === 1 ? true : false,
          phone: data.phone,
          formShow: true,
          editForm: true,
          city_id: data.city_id,
          area_id: data.area_id,
        });
      } else {
        toastr.error(res.data.message);
      }
    });
  };

  edit_userClose = () => {
    this.setState({ search_show: false });
  };
  handleEditCustomerChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };
  SaveEditCustomerData = () => {
    let data = {
      first_name: this.state.editCustomerName,
      // last_name: this.state.editCustomerLName,
      phone:
        this.state.userDetail.phone.substring(0, 3) !== "966"
          ? this.state.editCustomerNumber.substring(3)
          : this.state.editCustomerNumber,
      email: this.state.editCustomerEmail,
      gender: this.state.editCustomerGender,
      language: this.state.editCustomerLaguage,
      date_of_birth: this.state.editCustomerDOB,
      mark: this.state.editCustomerMark,
      user_id: this.state.user_id,
      note: this.state.userNote,
    };
    new Promise((resolve) => {
      resolve(PostApi(API_Path.editCostmerData, data));
    }).then((res) => {
      console.log(res, "edit Data");
      if (res.data.success === true) {
        toastr.success(res.data.message);
        this.get_user_detail(this.state.user_id);
        this.edit_userClose();
        this.notemodalClose();
      }
    });
  };

  edit_handleShow = (e) => {
    e.preventDefault();
    this.setState({ search_show: true });
  };

  delete_record = (id) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>Are you sure?</h1>
            <p>You want to delete this file?</p>
            <button className="btn red-btn me-2" onClick={onClose}>
              No
            </button>
            <button
              className="btn red-btn"
              onClick={() => {
                this.finaly_delete_record(id);
                onClose();
              }}
            >
              Yes, Delete it!
            </button>
          </div>
        );
      },
    });
  };

  sendmsgmodal = () => {
    this.setState({ sendmsgmodal: true });
  };

  sendmsgmodalclose = () => {
    this.setState({ sendmsgmodal: false });
  };

  addressmodal = () => {
    this.setState({ addressmodal: true });
  };

  addressmodalclose = () => {
    this.setState({
      addressmodal: false,
      edit_data: "",
      phone: "",
      city: "",
      area: "",
    });
  };

  finaly_delete_record = (id) => {
    alert(id);
  };

  handleTableChange = (
    type,
    { page, sizePerPage, filters, sortField, sortOrder }
  ) => {
    switch (type) {
      case "pagination":
        this.setState(
          {
            page,
            sizePerPage,
          },
          () => {
            this.getRecentOrder(
              this.state.user_id,
              page,
              sizePerPage,
              this.state.defaultSorted
            );
          }
        );
        break;
      case "filter":
        let search_val = this.state.search_val;
        let newFilter = {};
        if (Object.keys(filters).length) {
          for (const dataField in filters) {
            newFilter[dataField] = filters[dataField].filterVal;
          }
          newFilter = {
            ...search_val,
            ...newFilter,
          };
        } else {
          newFilter = {
            title: "",
            indicator: "",
            definition: "",
          };
        }
        this.setState(
          {
            search_val: newFilter,
          },
          () => {}
        );
        break;
      case "sort":
        this.setState(
          {
            defaultSorted: [
              {
                dataField: sortField,
                order: sortOrder,
              },
            ],
          },
          () => {
            this.getRecentOrder(
              this.state.user_id,
              page,
              sizePerPage,
              this.state.defaultSorted
            );
          }
        );
        break;
      default:
        break;
    }
    return true;
  };

  deleteNoteModalShow = () => {
    this.setState({ userNote: "" }, () => {
      this.SaveEditCustomerData();
    });
  };

  addNote = () => {
    this.setState({ NoteModalShow: true });
  };
  notemodalClose = () => {
    this.setState({ NoteModalShow: false });
  };

  handleChageNote = (e) => {
    this.setState({ userNote: e.target.value });
  };
  AddUserNote = () => {};

  handleSelectCity = (data) => {
    let cityArr = [];
    this.setState({ city: data.english, city_id: data.id }, () => {
      this.runforms.current.setFieldValue("city", this.state.city);
      this.state.CityData.filter((item) => {
        if (item.id === parseInt(data.id)) {
          cityArr.push(item);
        }
      });
      this.setState({ isocode: cityArr[0].isocode }, () => {
        this.getAreaData(this.state.isocode);
      });
    });
  };

  handleSelectArea = (data) => {
    this.setState({ area: data.english, area_id: data.id }, () => {
      this.runforms.current.setFieldValue("area", this.state.area);
    });
  };

  onSearchCityChange = (e) => {
    this.setState({ [e.target.name]: e.target.value }, () => {
      this.getCityData(e.target.value);
    });
  };

  onSearchAreaChange = (e) => {
    this.setState({ [e.target.name]: e.target.value }, () => {
      this.getAreaData(e.target.value);
    });
  };

  handleAddressChange = (e) => {
    this.setState({ default: e.target.checked }, () => {
      // this.runforms.current.setFieldValue("default", this.state.default);
    });
  };

  handlePhoneChange = (value) => {
    this.setState({ phone: value }, () => {
      this.runforms.current.setFieldValue("phone", this.state.phone);
    });
  };
  handleEditPhoneChange = (value) => {
    this.setState({ editCustomerNumber: value }, () => {
      this.customerRunforms.current.setFieldValue(
        "phone",
        this.state.editCustomerNumber
      );
    });
  };

  handleEditAddress = (id) => {
    this.setState({ addressmodal: true });
    this.getAddressById(id);
  };

  handleDeleteAddress = (id) => {
    let path = API_Path.deleteAddressById;
    let data = { id: id };
    const deleteAddressPromise = new Promise((resolve) => {
      resolve(PostApi(path, data));
    });
    deleteAddressPromise.then((res) => {
      if (res.data.success) {
        this.getAllAddress(this.state.user_id);

        toastr.success(res.data.message);
      }
    });
  };

  handleCustomerSettingChange = (e) => {
    this.setState({ [e.target.name]: e.target.checked });
    console.log(e.target.name, "e.target.name");
    if (e.target.name == "banCustomer") {
      this.changeCustomerPermmision("ban");
    } else if (e.target.name == "codCustomerStatus") {
      this.changeCustomerPermmision("cod");
    } else if (e.target.name == "subWhatsapp") {
      // this.changeCustomerPermmision('whatsapp')
    } else if (e.target.name == "subEmail") {
      // this.changeCustomerPermmision('email')
    } else if (e.target.name == "subSms") {
      // this.changeCustomerPermmision('sms')
    }
  };

  changeCustomerPermmision = (state) => {
    let reqData = {
      type: state,
      user_id: this.state.user_id,
    };
    new Promise((resolve) => {
      resolve(PostApi(API_Path.customerPermmision, reqData));
    }).then((res) => {
      if (res.data.success) {
        toastr.success(res.data.message);
      }
    });
  };

  // handleAddAddressData = (formData) => {
  //   let data = {
  //     name: formData.name,
  //     phone: formData.phone,
  //     city_id: formData.city,
  //     area_id: formData.area,
  //     line_1: formData.line_1,
  //     default: formData.default,
  //     email: "s@gmail.com",
  //   };

  //   let path = API_Path.addAddress;
  //   const addAddressDataPromise = new Promise((resolve) => {
  //     resolve(PostApi(path, data));
  //   });

  //   addAddressDataPromise.then((res) => {
  //     if (res.data.success) {
  //       toastr.success(res.data.message);
  //       this.addressmodalclose();

  //       // this.setState({ areaData: res.data.data }, () => {
  //       //   //   this.state.areaData.map((item, i) => {
  //       //   //     if (i === 0) {
  //       //   //       this.setState({ area: item.id });
  //       //   //     }
  //       //   //   });
  //       // });
  //     } else {
  //       toastr.error(res.data.message);
  //     }
  //   });
  // };
  changeAddType = (type) => {
    this.setState({ add_type: type });
  };

  handleEditAddressData = (formData) => {
    let data = {
      id: this.state.idToEdit,
      type: this.state.add_type,
      name: formData.name,
      line_1: formData.line_1,
      line_2: formData.line_2,
      city_id: parseInt(this.state.city_id),
      area_id: parseInt(this.state.area_id),
      phone: this.state.phone,
      email: this.state.email,
      defaults: this.state.default ? 1 : 0,
      user_id: parseInt(this.state.user_id),
    };
    let path = API_Path.editAddressById;

    const editAddressPromise = new Promise((resolve) => {
      resolve(PostApi(path, data));
    });
    editAddressPromise.then((res) => {
      if (res.data.success) {
        toastr.success(res.data.message);
        this.getAllAddress(this.state.user_id);
        this.addressmodalclose();
      } else {
        toastr.error(res.data.error);
      }
    });
  };

  handleEditMarkChange = (e) => {
    this.setState({ editCustomerMark: e.target.id });
  };

  errorContainer = (form, field) => {
    return form.touched[field] && form.errors[field] ? (
      <span className="error text-danger">{form.errors[field]}</span>
    ) : null;
  };

  formAttr = (form, field) => ({
    onBlur: form.handleBlur,
    onChange: form.handleChange,
    value: form.values[field],
  });
  getAdminDetails = () => {
    new Promise((resolve) => {
      resolve(GetApi(API_Path.GetAdminDetail));
    }).then((res) => {
      if (res.data.success) {
        this.setState({ AdminDetails: res.data.data });
      }
    });
  };
  addmoneyModalShow = (e) => {
    this.getAdminDetails();
    e.preventDefault();
    this.setState(
      {
        WalletMoneyStatus: "add-money",
        selectOTPNumber: "",
        AddMoneyWallet: "",
        AddMoneyReason: "",
        walletOtp: "",
        countdown: 0,
      },
      () => {
        this.setState({ addmoneymodal: true });
      }
    );
  };
  addmoneyModalClose = () => {
    clearInterval(this.state.intervalId);
    this.setState({ addmoneymodal: false });
  };

  withdrawmoneyModal = () => {
    this.getAdminDetails();
    this.setState(
      {
        WalletMoneyStatus: "withdraw-money",
        selectOTPNumber: "",
        AddMoneyWallet: "",
        AddMoneyReason: "",
        walletOtp: "",
        countdown: 0,
      },
      () => {
        this.setState({ addmoneymodal: true });
      }
    );
  };
  SendOtpAddMoney = () => {
    if (
      this.state.selectOTPNumber !== "" &&
      this.state.AddMoneyWallet !== "" &&
      this.state.AddMoneyReason !== ""
    ) {
      new Promise((resolve) => {
        resolve(
          PostApi(API_Path.sendOtp, { phone: this.state.selectOTPNumber })
        );
      }).then((res) => {
        if (res.data.success) {
          this.setState({ WalletMoneyStatus: "otp-money" });
        }
      });
    } else {
      toastr.error("please fill all details");
    }
  };
  SendOtpWithdrawMoney = () => {
    if (
      this.state.selectOTPNumber !== "" &&
      this.state.WithdrawWalletMoney !== "" &&
      this.state.WithdrawMoneyReason !== ""
    ) {
      new Promise((resolve) => {
        resolve(
          PostApi(API_Path.sendOtp, { phone: this.state.selectOTPNumber })
        );
      }).then((res) => {
        if (res.data.success) {
          this.setState({ WalletMoneyStatus: "otp-withdraw-money" });
        }
      });
    } else {
      toastr.error("please fill all details");
    }
  };
  otpChange = (otp) => {
    this.setState({ walletOtp: otp });
  };
  handleVerifyOtp = (status) => {
    let BodyReq;
    if (status == "add") {
      BodyReq = {
        phone: this.state.selectOTPNumber,
        otp: this.state.walletOtp,
        amount: this.state.AddMoneyWallet,
        reason: this.state.AddMoneyReason,
        user_id: this.state.user_id,
      };
    } else {
      BodyReq = {
        phone: this.state.selectOTPNumber,
        otp: this.state.walletOtp,
        amount: "-" + this.state.WithdrawWalletMoney,
        reason: this.state.WithdrawMoneyReason,
        user_id: this.state.user_id,
      };
    }

    new Promise((resolve) => {
      resolve(PostApi(API_Path.verifyOtp, BodyReq));
    }).then((res) => {
      if (res.data.success) {
        if (status == "add") {
          this.setState({ WalletMoneyStatus: "success-added-money" });
        } else {
          this.setState({ WalletMoneyStatus: "success-withdraw-money" });
        }
        this.getUserLedger(this.state.user_id);
      }
    });
  };
  ResendOtp = (sec, type) => {
    this.setState({ countdown: sec }, () => {
      if (type == "add") {
        this.SendOtpAddMoney();
      } else {
        this.SendOtpWithdrawMoney();
      }
      const intervalId = setInterval(() => {
        this.setState((prevState) => ({ countdown: prevState.countdown - 1 }));
      }, 1000);

      this.setState({ intervalId });
    });
  };
  walletChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  render() {
    let Language =
      this.context.language === "english"
        ? TableFieldEnglish
        : TableFieldArabic;
    let buttonLanguage =
      this.context.language === "english" ? buttonEnglish : buttonArabic;
    let UserLanguage =
      this.context.language === "english" ? UserEnglish : UserArabic;
    let titleLanguage =
      this.context.language === "english" ? titleEnglish : titleArabic;
    const Style = {
      width: "50px",
      height: "50px",
      borderRadius: "15px",
      border: "0",
      backgroundColor: "#f7f7f7",
    };
    const focusStyle = {
      borderColor: " #a81a1c63",
      boxShadow: "0 0 3px #a81a1c63",
    };
    const ContainerStyle = {
      display: "flex",
      justifyContent: "center",
    };
    const columns = [
      {
        dataField: "id",
        text: Language.orderNumber,
        hidden: false,
        formatter: (cell, row, rowIndex) => {
          return (
            <Link to={"/order-details/" + row.id}>
              <a className="fw-bold dark-red-txt">{row.id}</a>
            </Link>
          );
        },
      },
      {
        dataField: "createdat",
        text: Language.orderDate,
        sort: true,
        hidden: false,
        formatter: (cell, row, rowIndex) => {
          return (
            <span>{moment(row.createdat).format("DD/MM/YYYY hh:mm A")}</span>
          );
        },
        // filter: textFilter({
        //     placeholder: "Search",
        // }),
      },
      {
        dataField: "status",
        text: Language.status,
        sort: true,
        hidden: false,
        formatter: (cell, row, rowIndex) => {
          let status;
          switch (row.status) {
            case 1:
              status = "pending";
              break;
            case 2:
              status = "prepared";
              break;
            case 3:
              status = "ready-to-ship";
              break;
            case 4:
              status = "shipped";
              break;
            case 5:
              status = "delivered";
              break;
            case 6:
              status = "cancelled";
              break;
            case 7:
              status = "archieved";
              break;
            case 8:
              status = "returned";
              break;
            case 9:
              status = "partially-returned";
              break;
            case 10:
              status = "refund";
              break;
            case 11:
              status = "panding-payment";
              break;
            case 12:
              status = "disputed";
              break;

            default:
              break;
          }
          return (
            <span
              className={`staus-span-tag-new status-${
                row.status == 1 || row.status == 2 || row.status == 3
                  ? "prepared"
                  : row.status == 4
                  ? "ready-to-ship"
                  : row.status == 5
                  ? "completed"
                  : "cancelled"
              }`}
            >
              {status}
            </span>
          );
        },
      },
      {
        dataField: "shipping_company",
        text: Language.track,
        sort: true,
        hidden: false,
        formatter: (cell, row, rowIndex) => {
          return (
            <a href={row.track_url} target="_blank">
              {row.shipping_company}
            </a>
          );
        },
      },
      {
        dataField: "pay_method",
        text: Language.Payment,
        sort: true,
        hidden: false,
      },
      {
        dataField: "items",
        text: Language.totalItem,
        sort: true,
        hidden: false,
      },
      {
        dataField: "final_ordered_price",
        text: Language.Ordervalue,
        sort: true,
        hidden: false,
      },
      // {
      //     dataField: "totalitems",
      //     text: Language.totalItem,
      //     sort: true,
      //     hidden: false,
      //     filter: textFilter({
      //         placeholder: "Search",
      //     }),
      // },
      // {
      //     dataField: "action",
      //     text: Language.action,
      //     hidden: false,
      //     csvExport: false,
      //     headerClasses: "text-center",
      //     classes: "text-center",
      //     formatter: (cell, row, rowIndex) => {
      //         return (
      //             <React.Fragment>
      //                 <button className="border-0 mx-1 bg-transparent" onClick={() => this.delete_record(row.id)}>
      //                     <svg width={18} height={20} viewBox="0 0 18 20" fill="none" xmlns="http://www.w3.org/2000/svg">
      //                         <path
      //                             d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
      //                             fill="#2D2D3B"
      //                         />
      //                     </svg>
      //                 </button>
      //             </React.Fragment>
      //         );
      //     },
      // },
    ];
    const {
      id,
      username,
      first_name,
      last_name,
      email,
      password,
      phone,
      img,
      token,
      role,
      status,
      createdat,
      updatedat,
      customer_id,
      mark,
      otp,
      is_verified,
      date_of_birth,
      gender,
      language,
      my_wallet,
    } = this.state.userDetail;
    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space">
            <div className="col-sm-12 text-sm-start text-center">
              <div className="common-header-txt">
                <h3>{Language.Customerdetail}</h3>
              </div>
            </div>
          </div>

          <div className="row common-space">
            <div className="col-xl-8 col-lg-6">
              <div className="row align-items-center">
                <div className="col-12 mb-3">
                  <div className="white-box">
                    <div className="row">
                      <div className="col-xxl-3 col-sm-6 mb-xxl-0 mb-3">
                        <div className="grey-box-comn h-100 ">
                          <div className="customer-info-top text-center">
                            <img src={Cust_1} alt="" />
                            <span className="d-block my-2">
                              {Language.Amountspent}
                            </span>
                            {this.state.UserLadger !== "" &&
                              this.state.UserLadger && (
                                <p>
                                  {" "}
                                  {this.state.UserLadger.amount_spent?.toFixed(
                                    2
                                  )}
                                </p>
                              )}
                          </div>
                        </div>
                      </div>
                      <div className="col-xxl-3 col-sm-6 mb-xxl-0 mb-3">
                        <div className="grey-box-comn h-100">
                          <div className="customer-info-top text-center">
                            <img src={Cust_2} alt="" />
                            <span className="d-block my-2">
                              {Language.ItemsPurchased}
                            </span>
                            {this.state.UserLadger !== "" &&
                              this.state.UserLadger && (
                                <p>{this.state.UserLadger.purchased_item}</p>
                              )}
                          </div>
                        </div>
                      </div>
                      <div className="col-xxl-3 col-sm-6 mb-xxl-0 mb-3">
                        <div className="grey-box-comn h-100">
                          <div className="customer-info-top text-center">
                            <img src={Cust_3} alt="" />
                            <span className="d-block my-2">
                              {Language.AverageOrdervalue}
                            </span>
                            {this.state.UserLadger !== "" &&
                              this.state.UserLadger && (
                                <p>
                                  {this.state.UserLadger.average_spent?.toFixed(
                                    2
                                  )}
                                </p>
                              )}
                          </div>
                        </div>
                      </div>
                      <div className="col-xxl-3 col-sm-6 mb-xxl-0 mb-3">
                        <div className="grey-box-comn h-100">
                          <div className="customer-info-top text-center position-relative">
                            <img src={Cust_4} alt="" />
                            <span className="d-block my-2">
                              {Language.WalletBalance}
                            </span>
                            {this.state.UserLadger !== "" &&
                              this.state.UserLadger && (
                                <p>
                                  {this.state.UserLadger.my_wallet.toFixed(2)}
                                </p>
                              )}

                            <Dropdown className="cust-drop position-absolute top-0 end-0">
                              <Dropdown.Toggle
                                className="bg-transparent p-0"
                                id="dropdown-basic"
                                align="end"
                              >
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  width={16}
                                  height={16}
                                  fill="currentColor"
                                  className="bi bi-three-dots-vertical"
                                  viewBox="0 0 16 16"
                                >
                                  <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                </svg>
                              </Dropdown.Toggle>
                              <Dropdown.Menu>
                                <Dropdown.Item onClick={this.addmoneyModalShow}>
                                  <svg
                                    width="20"
                                    height="20"
                                    viewBox="0 0 20 20"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                  >
                                    <path
                                      d="M10 20C4.47715 20 0 15.5228 0 10C0 4.47715 4.47715 0 10 0C15.5228 0 20 4.47715 20 10C19.9939 15.5203 15.5203 19.9939 10 20ZM2 10.172C2.04732 14.5732 5.64111 18.1095 10.0425 18.086C14.444 18.0622 17.9995 14.4875 17.9995 10.086C17.9995 5.68451 14.444 2.10977 10.0425 2.086C5.64111 2.06246 2.04732 5.59876 2 10V10.172ZM11 15H9V11H5V9H9V5H11V9H15V11H11V15Z"
                                      fill="#323232"
                                    />
                                  </svg>
                                  <span>{Language.AddMoney}</span>
                                </Dropdown.Item>
                                <Dropdown.Item
                                  onClick={this.withdrawmoneyModal}
                                >
                                  <svg
                                    width="20"
                                    height="20"
                                    viewBox="0 0 20 20"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                  >
                                    <path
                                      d="M10 20C4.47715 20 0 15.5228 0 10C0 4.47715 4.47715 0 10 0C15.5228 0 20 4.47715 20 10C19.9939 15.5203 15.5203 19.9939 10 20ZM2 10.172C2.04732 14.5732 5.64111 18.1095 10.0425 18.086C14.444 18.0622 17.9995 14.4875 17.9995 10.086C17.9995 5.68451 14.444 2.10977 10.0425 2.086C5.64111 2.06246 2.04732 5.59876 2 10V10.172ZM15 11H5V9H15V11Z"
                                      fill="#323232"
                                    />
                                  </svg>
                                  <span>{Language.WithdrawMoney}</span>
                                </Dropdown.Item>
                                <Dropdown.Item href="#">
                                  <svg
                                    width="18"
                                    height="18"
                                    viewBox="0 0 18 18"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                  >
                                    <path
                                      d="M16 0H2C0.9 0 0 0.9 0 2V16C0 17.1 0.9 18 2 18H16C17.1 18 18 17.1 18 16V2C18 0.9 17.1 0 16 0ZM16 16H2V2H16V16Z"
                                      fill="#1F2937"
                                    />
                                    <path
                                      d="M8.25 4.71973H3.25V6.21973H8.25V4.71973Z"
                                      fill="#1F2937"
                                    />
                                    <path
                                      d="M15 12.75H10V14.25H15V12.75Z"
                                      fill="#1F2937"
                                    />
                                    <path
                                      d="M15 10.25H10V11.75H15V10.25Z"
                                      fill="#1F2937"
                                    />
                                    <path
                                      d="M5 15H6.5V13H8.5V11.5H6.5V9.5H5V11.5H3V13H5V15Z"
                                      fill="#1F2937"
                                    />
                                    <path
                                      d="M11.0898 7.95L12.4998 6.54L13.9098 7.95L14.9698 6.89L13.5598 5.47L14.9698 4.06L13.9098 3L12.4998 4.41L11.0898 3L10.0298 4.06L11.4398 5.47L10.0298 6.89L11.0898 7.95Z"
                                      fill="#1F2937"
                                    />
                                  </svg>
                                  <span>{Language.Statements}</span>
                                </Dropdown.Item>
                              </Dropdown.Menu>
                            </Dropdown>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-xl-4 col-sm-5  text-sm-start text-center rtl-txt-start mb-3">
                  <div className="common-header-txt">
                    <h3>{Language.RecentOrders}</h3>
                  </div>
                </div>
                <div className="col-xl-8 col-sm-7  text-sm-end text-center rtl-txt-end mb-3">
                  {this.state.UserLadger !== "" && this.state.UserLadger && (
                    <span className="mx-3">
                      {Language.ReturnRequests} (
                      {this.state.UserLadger.return_requests})
                    </span>
                  )}
                  {this.state.UserLadger !== "" && this.state.UserLadger && (
                    <Link to={"/orders?" + phone}>
                      <a>
                        <span className="dark-red-txt">
                          Show all Orders ({this.state.UserLadger.total_orders})
                        </span>
                      </a>
                    </Link>
                  )}
                </div>
                <div className="col-12 mb-3">
                  <div className="white-box">
                    {/* <form className="row cust-form-user">
                                    <div className="form-group col-md-6">
                                        <label>{Language.firstName}</label>
                                        <input type="text" className="form-control" value={first_name} readOnly />
                                    </div>

                                    <div className="form-group col-md-6">
                                        <label>{Language.lastName}</label>
                                        <input type="text" className="form-control" value={last_name} readOnly />
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>{Language.emailAddress}</label>
                                        <input type="email" className="form-control" value={email} readOnly />
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>{Language.numberOfOrders}</label>
                                        <input type="number" className="form-control" value="10" readOnly />
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>{Language.billingAdd}</label>
                                        <input type="text" className="form-control" value="123, Main street CA-95101, United States" readOnly />
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>{Language.shipmentAdd}</label>
                                        <input type="text" className="form-control" value="123, Main street CA-95101, United States" readOnly />
                                    </div>
                                </form> */}
                    {/* <div className="row common-space">
                                    <div className="col-sm-12 text-sm-start text-center">
                                        <div className="common-header-txt">
                                            <h3>{titleLanguage.orderHistory}</h3>
                                        </div>
                                    </div>
                                </div> */}

                    <div className="row common-space">
                      <div className="col-md-12">
                        <div className="custom-table">
                          <div className="table-responsive dataTables_wrapper no-footer">
                            {this.state.UserRecentOrder &&
                              this.state.totalSize !== 0 && (
                                <DataTable
                                  keyField="id"
                                  loading={this.state.loading}
                                  columns={columns}
                                  data={this.state.UserRecentOrder}
                                  page={this.state.page}
                                  sizePerPage={this.state.sizePerPage}
                                  totalSize={this.state.totalSize}
                                  defaultSorted={this.state.defaultSorted}
                                  language={this.context.language}
                                  onTableChange={this.handleTableChange}
                                />
                              )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {this.state.userNote && this.state.userNote != "" ? (
                  <div className="col-12 mb-3">
                    <div className="white-box">
                      <div className="common-header-txt pb-2 mb-2 border-bottom">
                        <h3>{Language.Note}</h3>
                      </div>
                      <div className="grey-box-info">
                        <div className="d-flex">
                          <div className="w-100 note-part">
                            {/* <bdi className="d-block mb-2">{Apr 18, 3:30 PM}</bdi> */}
                            {this.state.noteUpdatedDate != "" && (
                              <bdi className="d-block mb-2">
                                {this.state.noteUpdatedDate
                                  .local()
                                  .format("MMM DD, hh:mm A")}
                              </bdi>
                            )}
                            <p>{this.state.userNote}</p>
                          </div>
                          <div className="btn-last-part text-end">
                            <button
                              className="border-0 bg-transparent"
                              onClick={this.addNote}
                            >
                              <svg
                                width="16"
                                height="16"
                                viewBox="0 0 16 16"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                              >
                                <path
                                  d="M15.4142 0.585786C14.6332 -0.195262 13.3668 -0.195262 12.5858 0.585786L5 8.17157V11H7.82842L15.4142 3.41421C16.1953 2.63316 16.1953 1.36683 15.4142 0.585786Z"
                                  fill="#111827"
                                />
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M0 4C0 2.89543 0.89543 2 2 2H6C6.55228 2 7 2.44772 7 3C7 3.55228 6.55228 4 6 4H2V14H12V10C12 9.44772 12.4477 9 13 9C13.5523 9 14 9.44772 14 10V14C14 15.1046 13.1046 16 12 16H2C0.89543 16 0 15.1046 0 14V4Z"
                                  fill="#111827"
                                />
                              </svg>
                            </button>
                            <button
                              className="border-0 bg-transparent"
                              onClick={this.deleteNoteModalShow}
                            >
                              <svg
                                width="14"
                                height="16"
                                viewBox="0 0 14 16"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                              >
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M6 0C5.62123 0 5.27497 0.214002 5.10557 0.552786L4.38197 2H1C0.447715 2 0 2.44772 0 3C0 3.55228 0.447716 4 1 4L1 14C1 15.1046 1.89543 16 3 16H11C12.1046 16 13 15.1046 13 14V4C13.5523 4 14 3.55228 14 3C14 2.44772 13.5523 2 13 2H9.61804L8.89443 0.552786C8.72504 0.214002 8.37877 0 8 0H6ZM4 6C4 5.44772 4.44772 5 5 5C5.55228 5 6 5.44772 6 6V12C6 12.5523 5.55228 13 5 13C4.44772 13 4 12.5523 4 12V6ZM9 5C8.44771 5 8 5.44772 8 6V12C8 12.5523 8.44771 13 9 13C9.55229 13 10 12.5523 10 12V6C10 5.44772 9.55229 5 9 5Z"
                                  fill="#111827"
                                />
                              </svg>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="col-12 mb-3">
                    <div
                      className="white-box text-center cursor-pointer"
                      onClick={this.addNote}
                    >
                      <i class="bi bi-plus-circle me-2"></i>
                      {buttonLanguage.AddNote}
                    </div>
                  </div>
                )}
              </div>
            </div>
            <div className="col-xl-4 col-lg-6 mt-md-0 mt-3">
              <div className="order-detail-rgt-main">
                <Accordion flush>
                  <Accordion.Item>
                    <Accordion.Header>
                      <div className="order-head-txt d-flex align-items-center">
                        <span>{Language.Customerdetail}</span>
                        <button
                          className="border-0 bg-transparent ms-2"
                          onClick={this.edit_handleShow}
                        >
                          <i class="bi bi-pencil-square" />
                        </button>
                      </div>
                    </Accordion.Header>
                    <Accordion.Body>
                      <div className="table-responsive">
                        <table className="order-table w-100">
                          <tbody>
                            <tr>
                              <td>{UserLanguage.Name}</td>
                              <td>
                                <a href="#" className="dark-red-txt">
                                  {first_name} {last_name}
                                </a>
                              </td>
                            </tr>
                            <tr>
                              <td>{Language.Registeredon}</td>
                              <td>
                                {moment(createdat).format("DD-MM-YYYY hh:mm A")}
                              </td>
                            </tr>
                            <tr>
                              <td>{Language.emailAddress}</td>
                              <td>{email}</td>
                            </tr>
                            <tr>
                              <td>
                                <div className="d-flex align-items-center">
                                  {Language.phoneNumber}
                                  <svg
                                    className="ms-2"
                                    width="20"
                                    height="18"
                                    viewBox="0 0 20 18"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                  >
                                    <path
                                      d="M19.1668 8.99167L17.1335 6.66667L17.4168 3.59167L14.4085 2.90833L12.8335 0.25L10.0002 1.46667L7.16683 0.25L5.59183 2.90833L2.5835 3.58333L2.86683 6.66667L0.833496 8.99167L2.86683 11.3167L2.5835 14.4L5.59183 15.0833L7.16683 17.75L10.0002 16.525L12.8335 17.7417L14.4085 15.0833L17.4168 14.4L17.1335 11.325L19.1668 8.99167ZM15.8752 10.225L15.4085 10.7667L15.4752 11.475L15.6252 13.1L14.0418 13.4583L13.3418 13.6167L12.9752 14.2333L12.1502 15.6333L10.6668 14.9917L10.0002 14.7083L9.34183 14.9917L7.8585 15.6333L7.03349 14.2417L6.66683 13.625L5.96683 13.4667L4.3835 13.1083L4.5335 11.475L4.60016 10.7667L4.1335 10.225L3.0585 9L4.1335 7.76667L4.60016 7.225L4.52516 6.50833L4.37516 4.89167L5.9585 4.53333L6.6585 4.375L7.02516 3.75833L7.85016 2.35833L9.3335 3L10.0002 3.28333L10.6585 3L12.1418 2.35833L12.9668 3.75833L13.3335 4.375L14.0335 4.53333L15.6168 4.89167L15.4668 6.51667L15.4002 7.225L15.8668 7.76667L16.9418 8.99167L15.8752 10.225Z"
                                      fill="#66A81A"
                                    />
                                    <path
                                      d="M8.40837 10.4586L6.47503 8.51693L5.2417 9.75859L8.40837 12.9336L14.525 6.80026L13.2917 5.55859L8.40837 10.4586Z"
                                      fill="#66A81A"
                                    />
                                  </svg>
                                </div>
                              </td>
                              <td>{phone}</td>
                            </tr>
                            <tr>
                              <td>{Language.city}</td>
                              <td>
                                {this.state.userCity !== "" &&
                                  this.state.userCity}
                              </td>
                            </tr>
                            <tr>
                              <td>{Language.area}</td>
                              <td>
                                {this.state.userArea !== "" &&
                                  this.state.userArea}
                              </td>
                            </tr>
                            <tr>
                              <td>{Language.Gender}</td>
                              <td>{gender}</td>
                            </tr>
                            <tr>
                              <td>{Language.DOB}</td>
                              <td>
                                {moment(date_of_birth).format("DD-MM-YYYY")}
                              </td>
                            </tr>
                            <tr>
                              <td>{Language.PreferredLanguage}</td>
                              <td>{language}</td>
                            </tr>
                            <tr>
                              <td>{Language.Mark}</td>
                              <td>{mark}</td>
                            </tr>
                            <tr>
                              <td className="text-start">
                                <button
                                  className="btn gray-red-txt-btn"
                                  onClick={this.sendmsgmodal}
                                >
                                  {Language.SendMessage}
                                </button>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </Accordion.Body>
                  </Accordion.Item>
                </Accordion>
                {/* =========================================================user-permmission-accordion============================================= */}
                <Accordion flush>
                  <Accordion.Item>
                    <Accordion.Header>
                      <div className="order-head-txt">
                        <span>{Language.Customersettings}</span>
                      </div>
                    </Accordion.Header>
                    <Accordion.Body>
                      <div className="table-responsive">
                        <table className="order-table w-100">
                          <tbody>
                            <tr>
                              <td>{Language.BanCustomer}</td>
                              <td>
                                <label className="switch ms-auto me-0 pop-switch">
                                  <input
                                    name="banCustomer"
                                    type="checkbox"
                                    onChange={this.handleCustomerSettingChange}
                                    checked={this.state.banCustomer}
                                  />
                                  <div className="slider round" />
                                </label>
                              </td>
                            </tr>
                            <tr>
                              <td>{Language.DeactivateCOD}</td>
                              <td>
                                <label className="switch ms-auto me-0 pop-switch">
                                  <input
                                    name="codCustomerStatus"
                                    type="checkbox"
                                    onChange={this.handleCustomerSettingChange}
                                    checked={this.state.codCustomerStatus}
                                  />
                                  <div className="slider round" />
                                </label>
                              </td>
                            </tr>
                            <tr>
                              <td>{Language.Subscribewhatsapp}</td>
                              <td>
                                <label className="switch ms-auto me-0 pop-switch">
                                  <input
                                    name="subWhatsapp"
                                    type="checkbox"
                                    onChange={this.handleCustomerSettingChange}
                                    defaultChecked={this.state.subWhatsapp}
                                  />
                                  <div className="slider round" />
                                </label>
                              </td>
                            </tr>
                            <tr>
                              <td>{Language.SubscribeEmail}</td>
                              <td>
                                <label className="switch ms-auto me-0 pop-switch">
                                  <input
                                    name="subEmail"
                                    type="checkbox"
                                    onChange={this.handleCustomerSettingChange}
                                    defaultChecked={this.state.subEmail}
                                  />
                                  <div className="slider round" />
                                </label>
                              </td>
                            </tr>
                            <tr>
                              <td>{Language.SubscribeSMS}</td>
                              <td>
                                <label className="switch ms-auto me-0 pop-switch">
                                  <input
                                    name="subSms"
                                    type="checkbox"
                                    onChange={this.handleCustomerSettingChange}
                                    defaultChecked={this.state.subSms}
                                  />
                                  <div className="slider round" />
                                </label>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </Accordion.Body>
                  </Accordion.Item>
                </Accordion>
                {/* ==========================================address-accordion============================================================== */}
                <Accordion flush>
                  <Accordion.Item>
                    <Accordion.Header>
                      <div className="order-head-txt">
                        <span>{Language.CustomerAddresses}</span>
                      </div>
                    </Accordion.Header>
                    <Accordion.Body>
                      <div className="table-responsive">
                        {this.state.addressData.length > 0 &&
                          this.state.addressData.map((item, i) => {
                            return (
                              <>
                                <div className="grey-box-comn  mb-3" key={i}>
                                  <div className="grey-box-info">
                                    <div className="d-flex mb-3">
                                      <div className="w-100">
                                        {this.context.language === "english" ? (
                                          <p>
                                            {item.area_en +
                                              " - " +
                                              item.city_en}
                                          </p>
                                        ) : (
                                          <p>
                                            {item.area_ar +
                                              " - " +
                                              item.city_ar}
                                          </p>
                                        )}
                                        <p> {item.line_1}</p>
                                        <p>{item.line_2}</p>
                                      </div>

                                      <div className="btn-last-part text-end">
                                        <button
                                          className="border-0 bg-transparent"
                                          onClick={() =>
                                            this.handleEditAddress(item.id)
                                          }
                                        >
                                          <svg
                                            width="16"
                                            height="16"
                                            viewBox="0 0 16 16"
                                            fill="none"
                                            xmlns="http://www.w3.org/2000/svg"
                                          >
                                            <path
                                              d="M15.4142 0.585786C14.6332 -0.195262 13.3668 -0.195262 12.5858 0.585786L5 8.17157V11H7.82842L15.4142 3.41421C16.1953 2.63316 16.1953 1.36683 15.4142 0.585786Z"
                                              fill="#111827"
                                            />
                                            <path
                                              fill-rule="evenodd"
                                              clip-rule="evenodd"
                                              d="M0 4C0 2.89543 0.89543 2 2 2H6C6.55228 2 7 2.44772 7 3C7 3.55228 6.55228 4 6 4H2V14H12V10C12 9.44772 12.4477 9 13 9C13.5523 9 14 9.44772 14 10V14C14 15.1046 13.1046 16 12 16H2C0.89543 16 0 15.1046 0 14V4Z"
                                              fill="#111827"
                                            />
                                          </svg>
                                        </button>
                                        <button
                                          className="border-0 bg-transparent"
                                          onClick={() =>
                                            this.handleDeleteAddress(item.id)
                                          }
                                        >
                                          <svg
                                            width="14"
                                            height="16"
                                            viewBox="0 0 14 16"
                                            fill="none"
                                            xmlns="http://www.w3.org/2000/svg"
                                          >
                                            <path
                                              fill-rule="evenodd"
                                              clip-rule="evenodd"
                                              d="M6 0C5.62123 0 5.27497 0.214002 5.10557 0.552786L4.38197 2H1C0.447715 2 0 2.44772 0 3C0 3.55228 0.447716 4 1 4L1 14C1 15.1046 1.89543 16 3 16H11C12.1046 16 13 15.1046 13 14V4C13.5523 4 14 3.55228 14 3C14 2.44772 13.5523 2 13 2H9.61804L8.89443 0.552786C8.72504 0.214002 8.37877 0 8 0H6ZM4 6C4 5.44772 4.44772 5 5 5C5.55228 5 6 5.44772 6 6V12C6 12.5523 5.55228 13 5 13C4.44772 13 4 12.5523 4 12V6ZM9 5C8.44771 5 8 5.44772 8 6V12C8 12.5523 8.44771 13 9 13C9.55229 13 10 12.5523 10 12V6C10 5.44772 9.55229 5 9 5Z"
                                              fill="#111827"
                                            />
                                          </svg>
                                        </button>
                                      </div>
                                    </div>
                                    <div className="d-flex align-items-center">
                                      <div className="d-flex align-items-center">
                                        <span>
                                          {item.phone.replaceAll("966", "")}
                                        </span>
                                        <svg
                                          className="ms-2"
                                          width="20"
                                          height="18"
                                          viewBox="0 0 20 18"
                                          fill="none"
                                          xmlns="http://www.w3.org/2000/svg"
                                        >
                                          <path
                                            d="M19.1668 8.99167L17.1335 6.66667L17.4168 3.59167L14.4085 2.90833L12.8335 0.25L10.0002 1.46667L7.16683 0.25L5.59183 2.90833L2.5835 3.58333L2.86683 6.66667L0.833496 8.99167L2.86683 11.3167L2.5835 14.4L5.59183 15.0833L7.16683 17.75L10.0002 16.525L12.8335 17.7417L14.4085 15.0833L17.4168 14.4L17.1335 11.325L19.1668 8.99167ZM15.8752 10.225L15.4085 10.7667L15.4752 11.475L15.6252 13.1L14.0418 13.4583L13.3418 13.6167L12.9752 14.2333L12.1502 15.6333L10.6668 14.9917L10.0002 14.7083L9.34183 14.9917L7.8585 15.6333L7.03349 14.2417L6.66683 13.625L5.96683 13.4667L4.3835 13.1083L4.5335 11.475L4.60016 10.7667L4.1335 10.225L3.0585 9L4.1335 7.76667L4.60016 7.225L4.52516 6.50833L4.37516 4.89167L5.9585 4.53333L6.6585 4.375L7.02516 3.75833L7.85016 2.35833L9.3335 3L10.0002 3.28333L10.6585 3L12.1418 2.35833L12.9668 3.75833L13.3335 4.375L14.0335 4.53333L15.6168 4.89167L15.4668 6.51667L15.4002 7.225L15.8668 7.76667L16.9418 8.99167L15.8752 10.225Z"
                                            fill="#66A81A"
                                          />
                                          <path
                                            d="M8.40837 10.4586L6.47503 8.51693L5.2417 9.75859L8.40837 12.9336L14.525 6.80026L13.2917 5.55859L8.40837 10.4586Z"
                                            fill="#66A81A"
                                          />
                                        </svg>
                                      </div>
                                      {item.defaults == 1 && (
                                        <bdi className="green-text-brd ms-auto">
                                          Default Address
                                        </bdi>
                                      )}
                                    </div>
                                  </div>
                                </div>

                                {/* <div className="white-box-new mb-3">
                                  <div className="grey-box-info">
                                    <div className="d-flex mb-3">
                                      <div className="w-100">
                                        <p>{item.line_1 + ", " + item.line_2 + ", " + item.area_en + ", " + item.city_en}</p>
                                        <p> {"Phone number :- " + item.phone}</p>
                                        <p>{"Email Address :- " + item.email}</p>
                                      </div>
                                      <div className="btn-last-part text-end">
                                        <button className="border-0 bg-transparent" onClick={() => this.handleEditAddress(item.id)}>
                                          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M15.4142 0.585786C14.6332 -0.195262 13.3668 -0.195262 12.5858 0.585786L5 8.17157V11H7.82842L15.4142 3.41421C16.1953 2.63316 16.1953 1.36683 15.4142 0.585786Z" fill="#111827" />
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M0 4C0 2.89543 0.89543 2 2 2H6C6.55228 2 7 2.44772 7 3C7 3.55228 6.55228 4 6 4H2V14H12V10C12 9.44772 12.4477 9 13 9C13.5523 9 14 9.44772 14 10V14C14 15.1046 13.1046 16 12 16H2C0.89543 16 0 15.1046 0 14V4Z" fill="#111827" />
                                          </svg>
                                        </button>
                                        <button className="border-0 bg-transparent">
                                          <svg width="14" height="16" viewBox="0 0 14 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M6 0C5.62123 0 5.27497 0.214002 5.10557 0.552786L4.38197 2H1C0.447715 2 0 2.44772 0 3C0 3.55228 0.447716 4 1 4L1 14C1 15.1046 1.89543 16 3 16H11C12.1046 16 13 15.1046 13 14V4C13.5523 4 14 3.55228 14 3C14 2.44772 13.5523 2 13 2H9.61804L8.89443 0.552786C8.72504 0.214002 8.37877 0 8 0H6ZM4 6C4 5.44772 4.44772 5 5 5C5.55228 5 6 5.44772 6 6V12C6 12.5523 5.55228 13 5 13C4.44772 13 4 12.5523 4 12V6ZM9 5C8.44771 5 8 5.44772 8 6V12C8 12.5523 8.44771 13 9 13C9.55229 13 10 12.5523 10 12V6C10 5.44772 9.55229 5 9 5Z" fill="#111827" />
                                          </svg>
                                        </button>
                                      </div>
                                    </div>
                                    <div className="d-flex align-items-center">
                                      <div className="d-flex align-items-center">
                                        <span>0512345678</span>
                                        <svg className="ms-2" width="20" height="18" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M19.1668 8.99167L17.1335 6.66667L17.4168 3.59167L14.4085 2.90833L12.8335 0.25L10.0002 1.46667L7.16683 0.25L5.59183 2.90833L2.5835 3.58333L2.86683 6.66667L0.833496 8.99167L2.86683 11.3167L2.5835 14.4L5.59183 15.0833L7.16683 17.75L10.0002 16.525L12.8335 17.7417L14.4085 15.0833L17.4168 14.4L17.1335 11.325L19.1668 8.99167ZM15.8752 10.225L15.4085 10.7667L15.4752 11.475L15.6252 13.1L14.0418 13.4583L13.3418 13.6167L12.9752 14.2333L12.1502 15.6333L10.6668 14.9917L10.0002 14.7083L9.34183 14.9917L7.8585 15.6333L7.03349 14.2417L6.66683 13.625L5.96683 13.4667L4.3835 13.1083L4.5335 11.475L4.60016 10.7667L4.1335 10.225L3.0585 9L4.1335 7.76667L4.60016 7.225L4.52516 6.50833L4.37516 4.89167L5.9585 4.53333L6.6585 4.375L7.02516 3.75833L7.85016 2.35833L9.3335 3L10.0002 3.28333L10.6585 3L12.1418 2.35833L12.9668 3.75833L13.3335 4.375L14.0335 4.53333L15.6168 4.89167L15.4668 6.51667L15.4002 7.225L15.8668 7.76667L16.9418 8.99167L15.8752 10.225Z" fill="#66A81A" />
                                          <path d="M8.40837 10.4586L6.47503 8.51693L5.2417 9.75859L8.40837 12.9336L14.525 6.80026L13.2917 5.55859L8.40837 10.4586Z" fill="#66A81A" />
                                        </svg>
                                      </div>
                                    </div>
                                  </div>
                                </div> */}
                              </>
                            );
                          })}

                        {/* <button className="btn gray-red-txt-btn" onClick={this.addressmodal}>
                          Add Address
                        </button> */}
                      </div>
                    </Accordion.Body>
                  </Accordion.Item>
                </Accordion>
              </div>
            </div>
          </div>
        </div>

        {/* ----------------sms modal------------------------ */}
        <Modal
          dialogClassName="modal-dialog-centered cust-modal-white-content"
          className="cust-white-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.sendmsgmodal}
          onHide={this.sendmsgmodalclose}
          size="xl"
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">
                {buttonLanguage.Sendmessagecustomer}
              </h1>
              <p>{buttonLanguage.Forwriteshortmessage}</p>
            </Modal.Title>
            <button
              type="button"
              onClick={this.sendmsgmodalclose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <>
              <form onSubmit={this.sendMsgViaEmail}>
                <div className="row modal-form cust-white-modal align-items-center">
                  <div className="col-md-12">
                    <textarea
                      className="form-control h-auto"
                      rows="9"
                      name="message"
                    ></textarea>
                  </div>
                  <div className="col-lg-6 mb-lg-0 mb-3">
                    <ul className="d-sm-flex align-items-center">
                      <li className="me-3 mb-sm-0 mb-1">
                        <div className="cust-checkbox-new">
                          <label className="cust-chk-bx">
                            <input type="checkbox" />
                            <span className="cust-chkmark" />
                            <svg
                              className="me-2"
                              width={24}
                              height={24}
                              viewBox="0 0 24 24"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <path
                                fillRule="evenodd"
                                clipRule="evenodd"
                                d="M12 24C18.6274 24 24 18.6274 24 12C24 5.37258 18.6274 0 12 0C5.37258 0 0 5.37258 0 12C0 14.1522 0.566569 16.172 1.55869 17.9185L0 24L6.26988 22.5461C7.97261 23.4732 9.92479 24 12 24ZM12 22.1538C17.6078 22.1538 22.1538 17.6078 22.1538 12C22.1538 6.39219 17.6078 1.84615 12 1.84615C6.39219 1.84615 1.84615 6.39219 1.84615 12C1.84615 14.1652 2.52386 16.1721 3.67872 17.8202L2.76923 21.2308L6.23994 20.3631C7.8766 21.4925 9.86106 22.1538 12 22.1538Z"
                                fill="#A81A1C"
                              />
                              <path
                                d="M9.00002 6.42827C8.71471 5.8552 8.27702 5.90593 7.83486 5.90593C7.04465 5.90593 5.8125 6.85246 5.8125 8.61404C5.8125 10.0577 6.44867 11.6381 8.59236 14.0022C10.6612 16.2837 13.3795 17.4639 15.6362 17.4237C17.8929 17.3836 18.3572 15.4416 18.3572 14.7858C18.3572 14.4951 18.1768 14.3501 18.0525 14.3107C17.2835 13.9416 15.8651 13.2539 15.5424 13.1247C15.2197 12.9955 15.0512 13.1703 14.9464 13.2653C14.6538 13.5442 14.0736 14.3662 13.875 14.551C13.6764 14.7359 13.3802 14.6424 13.257 14.5725C12.8035 14.3905 11.5739 13.8436 10.5938 12.8935C9.38171 11.7185 9.31057 11.3142 9.0822 10.9543C8.89951 10.6665 9.03357 10.4898 9.10047 10.4126C9.36163 10.1113 9.72223 9.64607 9.88395 9.41487C10.0457 9.18368 9.91728 8.83266 9.84025 8.61404C9.50895 7.6738 9.22827 6.88672 9.00002 6.42827Z"
                                fill="#A81A1C"
                              />
                            </svg>
                            {buttonLanguage.Whatsapp}
                          </label>
                        </div>
                      </li>
                      <li className="me-3 mb-sm-0 mb-1">
                        <div className="cust-checkbox-new">
                          <label className="cust-chk-bx">
                            <input type="checkbox" />
                            <span className="cust-chkmark" />
                            <svg
                              className="me-2"
                              width={20}
                              height={20}
                              viewBox="0 0 20 20"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <path
                                d="M2 2H18V14H3.17L2 15.17V2ZM2 0C0.9 0 0.00999999 0.9 0.00999999 2L0 20L4 16H18C19.1 16 20 15.1 20 14V2C20 0.9 19.1 0 18 0H2ZM4 10H12V12H4V10ZM4 7H16V9H4V7ZM4 4H16V6H4V4Z"
                                fill="#A81A1C"
                              />
                            </svg>
                            SMS
                          </label>
                        </div>
                      </li>
                      <li className=" mb-sm-0 mb-1">
                        <div className="cust-checkbox-new">
                          <label className="cust-chk-bx">
                            <input type="checkbox" />
                            <span className="cust-chkmark" />
                            <svg
                              className="me-2"
                              width={21}
                              height={19}
                              viewBox="0 0 21 19"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <path
                                d="M18 0H2C0.9 0 0 0.9 0 2V14C0 15.1 0.9 16 2 16H11V14H2V4L10 9L18 4V9H20V2C20 0.9 19.1 0 18 0ZM10 7L2 2H18L10 7ZM17 11L21 15L17 19V16H13V14H17V11Z"
                                fill="#A81A1C"
                              />
                            </svg>
                            {buttonLanguage.Email}
                          </label>
                        </div>
                      </li>
                    </ul>
                  </div>
                  <div className="col-lg-6 text-lg-end text-center">
                    <div className="common-red-btn">
                      <button
                        className="btn red-border-btn  me-2"
                        type="reset"
                        onClick={this.sendmsgmodalclose}
                      >
                        {buttonLanguage.cancel}
                      </button>
                      <button className="btn red-btn" type="submit">
                        {buttonLanguage.Send}
                      </button>
                    </div>
                  </div>
                </div>
              </form>
            </>
          </Modal.Body>
        </Modal>

        {/* ------------------address modal ---------------------------- */}
        <Modal
          dialogClassName="modal-dialog-centered cust-modal-white-content"
          className="cust-white-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.addressmodal}
          onHide={this.addressmodalclose}
          size="xl"
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">Add/Edit Address</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.addressmodalclose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <>
              <Formik
                innerRef={this.runforms}
                enableReinitialize={this.state.editForm ? true : false}
                initialValues={{
                  name: this.state.edit_data ? this.state.edit_data.name : "",
                  phone: this.state.edit_data
                    ? this.state.edit_data.phone
                    : this.state.phone,
                  city: this.state.edit_data
                    ? this.state.edit_data.city_id
                    : "",
                  area: this.state.edit_data
                    ? this.state.edit_data.area_id
                    : "",
                  line_1: this.state.edit_data
                    ? this.state.edit_data.line_1
                    : "",
                  line_2: this.state.edit_data
                    ? this.state.edit_data.line_2
                    : "",
                  // default: this.state.edit_data ? this.state.default : false,
                }}
                validationSchema={Yup.object({
                  name: Yup.string().required("required."),
                  phone: Yup.string().required("required."),
                  //   city: Yup.string().required("required."),
                  //   area: Yup.string().required("required"),
                  line_1: Yup.string().required("required"),
                })}
                onSubmit={(formData, { resetForm }) => {
                  this.handleEditAddressData(formData, resetForm);
                }}
              >
                {(runform) => (
                  <form onSubmit={runform.handleSubmit} autoComplete="off">
                    <div className="row modal-form cust-white-modal align-items-center">
                      <div className="col-md-6 form-group">
                        <label>
                          Full Name <bdi>*</bdi>
                        </label>
                        <input
                          type="text"
                          name="name"
                          className="form-control"
                          placeholder="Mohammed Salim"
                          {...this.formAttr(runform, "name")}
                        />
                        {this.errorContainer(runform, "name")}
                      </div>
                      <div className="col-md-6 form-group">
                        <label>
                          Phone Number <bdi>*</bdi>
                        </label>
                        <PhoneInput
                          name="phone"
                          disableCountryGuess={true}
                          country="sa"
                          disableDropdown
                          countryCodeEditable={false}
                          placeholder="Enter phone number"
                          value={"+" + this.state.phone}
                          className="form-select-phone"
                          onChange={this.handlePhoneChange}
                        />
                        {this.errorContainer(runform, "phone")}
                      </div>
                      <div className="col-md-6 form-group">
                        <label>
                          City <bdi>*</bdi>
                        </label>
                        <Dropdown>
                          <Dropdown.Toggle className="btn form-control dropdown-toggle cust-search-button w-100">
                            <span>
                              {this.state.city
                                ? this.state.city
                                : "Select city"}
                            </span>
                          </Dropdown.Toggle>
                          <Dropdown.Menu className="w-100 cust-drop-box">
                            <div className="u-search-dw">
                              <div className="sear-u-inp p-2 bg-transparent">
                                <div className="position-relative">
                                  <input
                                    className="form-control"
                                    type="search"
                                    placeholder={titleLanguage.search}
                                    onChange={this.onSearchCityChange}
                                  />
                                </div>
                                <div className="drop-body-cust">
                                  <ul>
                                    {this.state.CityData.length > 0 &&
                                      this.state.CityData.map((item, i) => {
                                        return (
                                          <li
                                            onClick={() =>
                                              this.handleSelectCity(item)
                                            }
                                            key={i}
                                          >
                                            <span>{item.english}</span>
                                          </li>
                                        );
                                      })}
                                  </ul>
                                </div>
                              </div>
                            </div>
                          </Dropdown.Menu>
                        </Dropdown>
                        {/* {this.errorContainer(runform, "city")} */}
                      </div>
                      <div className="col-md-6 form-group">
                        <label>
                          Area <bdi>*</bdi>
                        </label>
                        <Dropdown>
                          <Dropdown.Toggle className="btn form-control dropdown-toggle cust-search-button w-100">
                            <span>
                              {this.state.area
                                ? this.state.area
                                : "Select Area"}
                            </span>
                          </Dropdown.Toggle>
                          <Dropdown.Menu className="w-100 cust-drop-box">
                            <div className="u-search-dw">
                              <div className="sear-u-inp p-2 bg-transparent">
                                <div className="position-relative">
                                  <input
                                    className="form-control"
                                    type="search"
                                    placeholder={titleLanguage.search}
                                    onChange={this.onSearchAreaChange}
                                  />
                                </div>
                                <div className="drop-body-cust">
                                  <ul>
                                    {this.state.areaData &&
                                      this.state.areaData.map((item, i) => {
                                        return (
                                          <li
                                            onClick={() =>
                                              this.handleSelectArea(item)
                                            }
                                            key={i}
                                          >
                                            <span>{item.english}</span>
                                          </li>
                                        );
                                      })}
                                  </ul>
                                </div>
                              </div>
                            </div>
                          </Dropdown.Menu>
                        </Dropdown>
                      </div>
                      <div className="col-12 form-group">
                        <label>
                          Building Name/House No, Floor, Apartment No.{" "}
                          <bdi>*</bdi>
                        </label>
                        <input
                          className="form-control"
                          name="line_1"
                          type="text"
                          placeholder="Eg: Deluxe Tower, 4th floor, apt 203"
                          {...this.formAttr(runform, "line_1")}
                        />
                        {this.errorContainer(runform, "line_1")}
                      </div>
                      <div className="col-12 form-group">
                        <label>Street Name/No. (optional)</label>
                        <input
                          className="form-control"
                          type="text"
                          placeholder="Eg: Deluxe Tower, 4th floor, apt 203"
                          name="line_2"
                          {...this.formAttr(runform, "line_2")}
                        />
                      </div>
                      {/* <div className="col-md-6 form-group">
                        <label>Postal Code (optional)</label>
                        <input className="form-control" type="text" placeholder="Eg: Deluxe Tower, 4th floor, apt 203" name="postal_code" {...this.formAttr(runform, "postal_code")} />
                      </div> */}
                      <div className="col-md-6 form-group">
                        <label>Address Type</label>
                        <Dropdown>
                          <Dropdown.Toggle className="btn form-control dropdown-toggle cust-search-button w-100">
                            <span>
                              {this.state.add_type ? this.state.add_type : ""}
                            </span>
                          </Dropdown.Toggle>
                          <Dropdown.Menu className="w-100 cust-drop-box">
                            <div className="u-search-dw">
                              <div className="sear-u-inp p-2 bg-transparent">
                                <div className="drop-body-cust">
                                  <ul>
                                    <li
                                      onClick={() => this.changeAddType("Home")}
                                    >
                                      Home
                                    </li>
                                    <li
                                      onClick={() =>
                                        this.changeAddType("Office")
                                      }
                                    >
                                      Office
                                    </li>
                                  </ul>
                                </div>
                              </div>
                            </div>
                          </Dropdown.Menu>
                        </Dropdown>
                      </div>
                      <div className="col-md-6">
                        <div class="cust-checkbox-new">
                          <label class="cust-chk-bx">
                            <input
                              name="default"
                              id="default"
                              type="checkbox"
                              checked={this.state.default}
                              onChange={this.handleAddressChange}
                            />
                            <span class="cust-chkmark"></span>
                            Default Address
                          </label>
                        </div>
                      </div>
                      <div className="col-12 text-lg-end text-center">
                        <div className="common-red-btn">
                          <button
                            className="btn red-border-btn me-2"
                            type="reset"
                            onClick={this.addressmodalclose}
                          >
                            Cancel
                          </button>
                          <button className="btn red-btn" type="submit">
                            save
                          </button>
                        </div>
                      </div>
                    </div>
                  </form>
                )}
              </Formik>
            </>
          </Modal.Body>
        </Modal>

        {/* ------------------edit customer modal--------------------------------------- */}
        <Modal
          dialogClassName="modal-dialog-centered cust-width-modal"
          className="edit-user-modal cust-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.search_show}
          onHide={this.edit_userClose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">Edit Customer</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.edit_userClose}
              className="close btn-close"
            />
          </Modal.Header>
          <Modal.Body>
            <Formik
              innerRef={this.customerRunforms}
              enableReinitialize={this.state.search_show ? true : false}
              initialValues={{
                first_name: this.state.editCustomerName,
                // last_name: this.state.editCustomerLName,
                phone:
                  this.state.userDetail.phone?.substring(0, 3) !== "966"
                    ? this.state.userDetail.phone?.substring(3)
                    : this.state.userDetail.phone,
                email: this.state.editCustomerEmail,
                gender: this.state.editCustomerGender,
                language: this.state.editCustomerLaguage,
                date_of_birth: this.state.editCustomerDOB,
                mark: this.state.editCustomerMark,
              }}
              validationSchema={Yup.object({
                first_name: Yup.string().required("required."),
                phone: Yup.string().required("required."),
              })}
              onSubmit={(formData, { resetForm }) => {
                console.log(formData);
                // this.SaveEditCustomerData(formData);
              }}
            >
              {(runform) => (
                <form onSubmit={runform.handleSubmit} autoComplete="off">
                  <div className="row modal-form">
                    <div className="col-md-6 form-group">
                      <label>
                        Full Name <bdi>*</bdi>
                      </label>
                      <input
                        className="form-control"
                        type="text"
                        name="first_name"
                        placeholder="John Doe"
                        {...this.formAttr(runform, "first_name")}
                      />
                      {this.errorContainer(runform, "first_name")}
                    </div>
                    {/* <div className="col-md-6 form-group">
								<label>Last Name</label>
								<input
									className="form-control"
									type="text"
									name="editCustomerLName"
									placeholder="John Doe"
									value={this.state.editCustomerLName}
									onChange={this.handleEditCustomerChange}
								/>
							</div> */}
                    <div className="col-md-6 form-group">
                      <label>
                        Phone Number <bdi>*</bdi>
                      </label>
                      <PhoneInput
                        country={"sa"}
                        name="phone"
                        className="form-control"
                        value={this.state.editCustomerNumber}
                        onChange={this.handleEditPhoneChange}
                      />
                      {this.errorContainer(runform, "phone")}
                      {/* <input
									className="form-control"
									type="tel"
									name="editCustomerNumber"
									placeholder="+956 508946664"
									value={this.state.editCustomerNumber}
									onChange={this.handleEditCustomerChange}
								/> */}
                    </div>
                    <div className="col-md-6 form-group">
                      <label>Email Address</label>
                      <input
                        className="form-control"
                        type="email"
                        placeholder="salimthottupoyil@gmail.com"
                        name="email"
                        // value={this.state.editCustomerEmail}
                        // onChange={this.handleEditCustomerChange}
                      />
                    </div>
                    <div className="col-md-6 form-group">
                      <label>Gender </label>
                      <select
                        className="form-control form-select"
                        name="gender"
                        value={this.state.editCustomerGender}
                        onChange={this.handleEditCustomerChange}
                      >
                        <option>select</option>
                        <option value={"male"}>Male</option>
                        <option value={"female"}>Female</option>
                        <option value={"other"}>Other</option>
                      </select>
                    </div>
                    <div className="col-md-6 form-group">
                      <label>Prefered language</label>
                      <select
                        className="form-control form-select"
                        name="language"
                        // value={this.state.editCustomerLaguage}
                        // onChange={this.handleEditCustomerChange}
                      >
                        <option>Select</option>
                        <option value={"arabic"}>Arabic</option>
                        <option value={"english"}>English</option>
                      </select>
                    </div>
                    <div className="col-md-6 form-group">
                      <label>Date of Birth</label>
                      <input
                        className="form-control"
                        type="date"
                        placeholder=""
                        name="date_of_birth"
                        // value={this.state.editCustomerDOB}
                        // onChange={this.handleEditCustomerChange}
                      />
                    </div>
                    <div className="col-md-12 form-group">
                      <label>{UserLanguage.Mark}</label>
                      <ul className="user-pop-radio">
                        <li>
                          <div className="help-support-txt">
                            <label className="cust-radio">
                              <input
                                type="radio"
                                name="mark"
                                id="Premium"
                                // onChange={this.handleEditMarkChange}
                                defaultChecked={
                                  this.state.editCustomerMark == "Premium"
                                }
                              />
                              <span className="checkmark" />
                            </label>
                            <span className> {UserLanguage.Premium}</span>
                          </div>
                        </li>
                        <li>
                          <div className="help-support-txt">
                            <label className="cust-radio">
                              <input
                                type="radio"
                                name="mark"
                                id="Standard"
                                // onChange={this.handleEditMarkChange}
                                defaultChecked={
                                  this.state.editCustomerMark == "Standard"
                                }
                              />
                              <span className="checkmark" />
                            </label>
                            <span className> {UserLanguage.Standard}</span>
                          </div>
                        </li>
                        <li>
                          <div className="help-support-txt">
                            <label className="cust-radio">
                              <input
                                type="radio"
                                name="mark"
                                id="Bad Customer"
                                // onChange={this.handleEditMarkChange}
                                defaultChecked={
                                  this.state.editCustomerMark == "Bad Customer"
                                }
                              />
                              <span className="checkmark" />
                            </label>
                            <span className> {UserLanguage.BadCustomers}</span>
                          </div>
                        </li>
                        <li>
                          <div className="help-support-txt">
                            <label className="cust-radio">
                              <input
                                type="radio"
                                name="mark"
                                id="Good Customer"
                                // onChange={this.handleEditMarkChange}
                                defaultChecked={
                                  this.state.editCustomerMark == "Good Customer"
                                }
                              />
                              <span className="checkmark" />
                            </label>
                            <span className> {UserLanguage.GoodCustomers}</span>
                          </div>
                        </li>
                      </ul>
                    </div>
                    <div className="col-md-12 form-group text-center mb-3">
                      <button type="submit" className="btn red-btn">
                        {buttonLanguage.save}
                      </button>
                    </div>
                  </div>
                </form>
              )}
            </Formik>
          </Modal.Body>
        </Modal>

        {/* ------------------ Add Money Modal --------------------------------------- */}

        <Modal
          dialogClassName="modal-dialog-centered cust-width-modal"
          className="edit-user-modal add-money-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.addmoneymodal}
          onHide={this.addmoneyModalClose}
        >
          <Modal.Body>
            {this.state.WalletMoneyStatus == "add-money" && (
              <div className="row modal-form">
                <div className="col-12 mb-3">
                  <h1 className="modal-title">{Language.AddMoney}</h1>
                </div>
                <div className="col-12 form-group">
                  <label>{Language.amount}</label>
                  <input
                    className="form-control"
                    type="tel"
                    placeholder={Language.EnterAmount}
                    name="AddMoneyWallet"
                    onChange={this.walletChange}
                  />
                </div>
                <div className="col-12 form-group">
                  <label>{Language.MentionReason}</label>
                  <input
                    className="form-control"
                    type="text"
                    placeholder={Language.ContestReward}
                    name="AddMoneyReason"
                    onChange={this.walletChange}
                  />
                </div>
                <div className="col-12 form-group">
                  <label>{Language.OTPPhoneNumber}</label>
                  <select
                    className="form-control form-select"
                    name="selectOTPNumber"
                    value={this.state.selectOTPNumber}
                    onChange={this.walletChange}
                  >
                    <option>{Language.SelectNumberOTP}</option>
                    {this.state.AdminDetails.length > 0 &&
                      this.state.AdminDetails.map((item, i) => {
                        return <option>{item.phone}</option>;
                      })}
                  </select>
                </div>
                <div className="col-sm-8 d-flex align-items-center form-group text-center m-auto mt-3">
                  <button
                    className="btn red-border-btn mx-3 w-100"
                    onClick={this.addmoneyModalClose}
                  >
                    {buttonLanguage.cancel}
                  </button>
                  <button
                    type="button"
                    className="btn red-btn w-100"
                    onClick={this.SendOtpAddMoney}
                  >
                    {Language.SendOTP}
                  </button>
                </div>
              </div>
            )}

            {/*  ------------- Withdraw Money ----------- */}
            {this.state.WalletMoneyStatus == "withdraw-money" && (
              <div className="row modal-form">
                <div className="col-12 mb-3">
                  <h1 className="modal-title withdraw-red-txt">
                    {Language.WithdrawMoney}
                  </h1>
                </div>
                <div className="col-12 form-group">
                  <label>{Language.amount}</label>
                  <input
                    className="form-control"
                    type="tel"
                    placeholder={Language.EnterAmount}
                    name="WithdrawWalletMoney"
                    onChange={this.walletChange}
                  />
                </div>
                <div className="col-12 form-group">
                  <label>{Language.MentionReason}</label>
                  <input
                    className="form-control"
                    type="text"
                    placeholder={Language.ContestReward}
                    name="WithdrawMoneyReason"
                    onChange={this.walletChange}
                  />
                </div>
                <div className="col-12 form-group">
                  <label>{Language.OTPPhoneNumber}</label>
                  <select
                    className="form-control form-select"
                    name="selectOTPNumber"
                    value={this.state.selectOTPNumber}
                    onChange={this.walletChange}
                  >
                    <option>{Language.SelectNumberOTP}</option>
                    {this.state.AdminDetails.length > 0 &&
                      this.state.AdminDetails.map((item, i) => {
                        return <option>{item.phone}</option>;
                      })}
                  </select>
                </div>
                <div className="col-sm-8 d-flex align-items-center form-group text-center m-auto mt-3">
                  <button
                    className="btn red-border-btn mx-3 w-100"
                    onClick={this.addmoneyModalClose}
                  >
                    {buttonLanguage.cancel}
                  </button>
                  <button
                    type="button"
                    className="btn red-btn w-100"
                    onClick={this.SendOtpWithdrawMoney}
                  >
                    {Language.SendOTP}
                  </button>
                </div>
              </div>
            )}

            {/*  ------------- OTP-ADD-Verification ----------- */}

            {this.state.WalletMoneyStatus == "otp-money" && (
              <div className="row modal-form otp-verify-modal">
                <div className="col-12 mb-3">
                  <h1 className="modal-title">{Language.OTPVerification}</h1>
                </div>
                <div className="col-12 form-group pt-3">
                  <div className="text-center">
                    <p className="red-clr-txt mb-4">
                      {Language.Areyousuretoadd}{" "}
                      <b>{parseFloat(this.state.AddMoneyWallet).toFixed(2)}</b>
                      {Language.SARtothewalletofthecustomer}
                      <b>
                        {" "}
                        {first_name}, ({phone}).
                      </b>
                    </p>
                    <p className="verify-num-txt">
                      {Language.Enterverificationcodephonenumber}{" "}
                      <b>{this.state.selectOTPNumber}</b>
                    </p>
                  </div>
                </div>
                <div className="col-12">
                  <div className="">
                    <OtpInput
                      value={this.state.walletOtp}
                      onChange={this.otpChange}
                      numInputs={4}
                      separator={<span>&nbsp;&nbsp;&nbsp;</span>}
                      inputStyle={Style}
                      focusStyle={focusStyle}
                      containerStyle={ContainerStyle}
                      shouldAutoFocus={true}
                      isInputNum={true}
                    />
                    {/* <OTPInput OTPLength={4} onChange={this.otpChange} autoFocus value={this.state.walletOtp} className="otp-cust-box" inputStyles={Style} secure /> */}
                    {/* <ul id="otp">
                      <li>
                        <input type="tel" maxLength={1} className="otp-comn-class-cust form-control" />
                      </li>
                      <li>
                        <input type="tel" maxLength={1} className="otp-comn-class-cust form-control" />
                      </li>
                      <li>
                        <input type="tel" maxLength={1} className="otp-comn-class-cust form-control" />
                      </li>
                      <li>
                        <input type="tel" maxLength={1} className="otp-comn-class-cust form-control" />
                      </li>
                    </ul> */}
                  </div>
                </div>
                <div className="col-sm-6 form-group text-center m-auto mt-3">
                  <button
                    type="button"
                    className="btn red-btn w-100"
                    onClick={() => this.handleVerifyOtp("add")}
                  >
                    {Language.Verify}
                  </button>
                  <div className="mt-3">
                    {this.state.countdown > 0 ? (
                      <span className="d-inlineblock cursor-pointer resend-otp-class">
                        {Language.ResendOTP} in {this.state.countdown}
                      </span>
                    ) : (
                      <span
                        className="d-inlineblock cursor-pointer resend-otp-class"
                        onClick={() => this.ResendOtp(60, "add")}
                      >
                        {Language.ResendOTP}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            )}
            {/*  ------------- OTP-withdraw-Verification ----------- */}
            {this.state.WalletMoneyStatus == "otp-withdraw-money" && (
              <div className="row modal-form otp-verify-modal">
                <div className="col-12 mb-3">
                  <h1 className="modal-title"> {Language.OTPVerification}</h1>
                </div>
                <div className="col-12 form-group pt-3">
                  <div className="text-center">
                    <p className="red-clr-txt mb-4">
                      {Language.Areyousuretowithdraw}{" "}
                      <b>
                        {parseFloat(this.state.WithdrawWalletMoney).toFixed(2)}{" "}
                      </b>{" "}
                      {Language.SARtothewalletofthecustomer}
                      <b>
                        {" "}
                        {first_name}, ({phone}).
                      </b>
                    </p>
                    <p className="verify-num-txt">
                      {Language.Enterverificationcodephonenumber}{" "}
                      <b>{this.state.selectOTPNumber}</b>
                    </p>
                  </div>
                </div>
                <div className="col-12">
                  <div className="">
                    <OtpInput
                      value={this.state.walletOtp}
                      onChange={this.otpChange}
                      numInputs={4}
                      separator={<span>&nbsp;&nbsp;&nbsp;</span>}
                      inputStyle={Style}
                      focusStyle={focusStyle}
                      containerStyle={ContainerStyle}
                      shouldAutoFocus={true}
                      isInputNum={true}
                    />
                    {/* <OTPInput OTPLength={4} onChange={this.otpChange} autoFocus value={this.state.walletOtp} className="otp-cust-box" inputStyles={Style} secure /> */}
                    {/* <ul id="otp">
                      <li>
                        <input type="tel" maxLength={1} className="otp-comn-class-cust form-control" />
                      </li>
                      <li>
                        <input type="tel" maxLength={1} className="otp-comn-class-cust form-control" />
                      </li>
                      <li>
                        <input type="tel" maxLength={1} className="otp-comn-class-cust form-control" />
                      </li>
                      <li>
                        <input type="tel" maxLength={1} className="otp-comn-class-cust form-control" />
                      </li>
                    </ul> */}
                  </div>
                </div>
                <div className="col-sm-6 form-group text-center m-auto mt-3">
                  <button
                    type="button"
                    className="btn red-btn w-100"
                    onClick={() => this.handleVerifyOtp("withdraw")}
                  >
                    {Language.Verify}
                  </button>
                  <div className="mt-3">
                    {this.state.countdown > 0 ? (
                      <span className="d-inlineblock cursor-pointer resend-otp-class">
                        {Language.ResendOTP} in {this.state.countdown}
                      </span>
                    ) : (
                      <span
                        className="d-inlineblock cursor-pointer resend-otp-class"
                        onClick={() => this.ResendOtp(60)}
                      >
                        {Language.ResendOTP}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/*  ------------- added success ----------- */}
            {this.state.WalletMoneyStatus == "success-added-money" && (
              <div className="row modal-form otp-success-modal py-5">
                <div className="col-12 mb-3">
                  <h1 className="modal-title text-center">
                    {Language.Successful}
                  </h1>
                </div>
                <div className="col-12 form-group mt-3">
                  <div className="text-center">
                    <p className="verify-num-txt">
                      <b>
                        {parseFloat(this.state.AddMoneyWallet).toFixed(2)} SAR
                      </b>{" "}
                      {Language.successfullyaddedtowalletcustomer},{" "}
                      <b>
                        {first_name}, ({phone}).
                      </b>
                    </p>
                  </div>
                </div>
                <div className="col-sm-6 form-group text-center m-auto mt-3">
                  <div className="form-group pb-0 my-0 mx-auto">
                    <button
                      className="btn red-btn"
                      type="button"
                      onClick={this.addmoneyModalClose}
                    >
                      {UserLanguage.Ok}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* ---------------- withdraw success------------ */}
            {this.state.WalletMoneyStatus == "success-withdraw-money" && (
              <div className="row modal-form otp-success-modal py-5">
                <div className="col-12 mb-3">
                  <h1 className="modal-title text-center">
                    {Language.Successful}
                  </h1>
                </div>
                <div className="col-12 form-group mt-3">
                  <div className="text-center">
                    <p className="verify-num-txt">
                      <b>
                        {parseFloat(this.state.WithdrawWalletMoney).toFixed(2)}{" "}
                        SAR
                      </b>
                      {Language.successfullywithdrawnwalletcustomer},
                      <b>
                        {first_name}, ({phone}).
                      </b>
                    </p>
                  </div>
                </div>
                <div className="col-sm-6 form-group text-center m-auto mt-3">
                  <div className="form-group pb-0 my-0 mx-auto">
                    <button
                      className="btn red-btn"
                      type="button"
                      onClick={this.addmoneyModalClose}
                    >
                      {UserLanguage.Ok}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </Modal.Body>
        </Modal>

        {/* ---------------------------------customer-note-modal-------------------------------------- */}
        <Modal
          dialogClassName="modal-dialog-centered cust-modal-white-content"
          className="cust-white-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.NoteModalShow}
          onHide={this.notemodalClose}
          size="xl"
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">{buttonLanguage.AddNote}</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.notemodalClose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <>
              <div className="row modal-form cust-white-modal align-items-center">
                <div className="col-md-12">
                  <textarea
                    className="form-control h-auto"
                    rows="9"
                    name="message"
                    value={this.state.userNote}
                    onChange={this.handleChageNote}
                  ></textarea>
                </div>
                <div className="col-lg-12  text-center">
                  <div className="common-red-btn">
                    <button
                      className="btn red-border-btn  me-2"
                      type="reset"
                      onClick={this.notemodalClose}
                    >
                      {buttonLanguage.cancel}
                    </button>
                    <button
                      className="btn red-btn"
                      type="submit"
                      onClick={this.SaveEditCustomerData}
                    >
                      {buttonLanguage.save}
                    </button>
                  </div>
                </div>
              </div>
            </>
          </Modal.Body>
        </Modal>
      </Adminlayout>
    );
  }
}

export default withRouter(UserDetails);
