import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import DataTable from "../../Components/DataTable";
import { textFilter } from "react-bootstrap-table2-filter";
import "react-confirm-alert/src/react-confirm-alert.css";
import {
  buttonArabic,
  buttonEnglish,
  productEnglish,
  productArabic,
  SidebarArabic,
  SidebarEnglish,
  TableFieldArabic,
  TableFieldEnglish,
  titleArabic,
  titleEnglish,
} from "../../const";
import LanguageContext from "../../contexts/languageContext";
import productimg from "../../images/product-img.png";
import { Dropdown } from "react-bootstrap";

export class Inventory extends Component {
  static contextType = LanguageContext;

  constructor(props) {
    super(props);
    this.state = {
      page: 1,
      sizePerPage: 10,
      totalSize: 100,
      defaultSorted: [
        {
          dataField: "id",
          order: "asc",
        },
      ],

      order_data: [
        {
          id: 1,
          productname: "Black Top",
          sku: "32367710",
          soldout: "Stop Selling",
          available: "10",
          price: "$500",
          reason: "Lorem Ipsum",
          date: "30 Apr 12:30 pm",
          cod: "yes",
        },
        {
          id: 2,
          productname: "Black Top",
          sku: "32367710",
          soldout: "Stop Selling",
          available: "10",
          price: "$500",
          reason: "Lorem Ipsum",
          date: "30 Apr 12:30 pm",
          cod: "yes",
        },
        {
          id: 3,
          productname: "Black Top",
          sku: "32367710",
          soldout: "Stop Selling",
          available: "10",
          price: "$500",
          reason: "Lorem Ipsum",
          date: "30 Apr 12:30 pm",
          cod: "yes",
        },
        {
          id: 4,
          productname: "Black Top",
          sku: "32367710",
          soldout: "Stop Selling",
          available: "10",
          price: "$500",
          reason: "Lorem Ipsum",
          date: "30 Apr 12:30 pm",
          cod: "yes",
        },
        {
          id: 5,
          productname: "Black Top",
          sku: "32367710",
          soldout: "Stop Selling",
          available: "10",
          price: "$500",
          reason: "Lorem Ipsum",
          date: "30 Apr 12:30 pm",
          cod: "No",
        },
        {
          id: 6,
          productname: "Black Top",
          sku: "32367710",
          soldout: "Stop Selling",
          available: "10",
          price: "$500",
          reason: "Lorem Ipsum",
          date: "30 Apr 12:30 pm",
          cod: "yes",
        },
        {
          id: 7,
          productname: "Black Top",
          sku: "32367710",
          soldout: "Stop Selling",
          available: "10",
          price: "$500",
          reason: "Lorem Ipsum",
          date: "30 Apr 12:30 pm",
          cod: "yes",
        },
        {
          id: 8,
          productname: "Black Top",
          sku: "32367710",
          soldout: "Stop Selling",
          available: "10",
          price: "$500",
          reason: "Lorem Ipsum",
          date: "30 Apr 12:30 pm",
          cod: "NO",
        },
        {
          id: 9,
          productname: "Black Top",
          sku: "32367710",
          soldout: "Stop Selling",
          available: "10",
          price: "$500",
          reason: "Lorem Ipsum",
          date: "30 Apr 12:30 pm",
          cod: "yes",
        },
        {
          id: 10,
          productname: "Black Top",
          sku: "32367710",
          soldout: "Stop Selling",
          available: "10",
          price: "$500",
          reason: "Lorem Ipsum",
          date: "30 Apr 12:30 pm",
          cod: "No",
        },
      ],
    };
  }
  get_order_data = () => { };

  handleTableChange = (
    type,
    { page, sizePerPage, filters, sortField, sortOrder }
  ) => {
    switch (type) {
      case "pagination":
        this.setState(
          {
            page,
            sizePerPage,
          },
          () => this.get_order_data()
        );
        break;
      case "filter":
        let search_val = this.state.search_val;
        let newFilter = {};
        if (Object.keys(filters).length) {
          for (const dataField in filters) {
            newFilter[dataField] = filters[dataField].filterVal;
          }
          newFilter = {
            ...search_val,
            ...newFilter,
          };
        } else {
          newFilter = {
            title: "",
            indicator: "",
            definition: "",
          };
        }
        this.setState(
          {
            search_val: newFilter,
          },
          () => this.get_order_data()
        );
        break;
      case "sort":
        this.setState(
          {
            defaultSorted: [
              {
                dataField: sortField,
                order: sortOrder,
              },
            ],
          },
          () => this.get_order_data()
        );
        break;
      default:
        break;
    }
    return true;
  };
  render() {
    let Language =
      this.context.language === "english"
        ? TableFieldEnglish
        : TableFieldArabic;
    let titleLanguage =
      this.context.language === "english" ? titleEnglish : titleArabic;
    let productLanguage =
      this.context.language === "english" ? productEnglish : productArabic;
    let buttonLanguage =
      this.context.language === "english" ? buttonEnglish : buttonArabic;
    const columns = [
      {
        dataField: "id",
        text: "Id",
        hidden: true,
      },
      {
        dataField: "photo",
        text: productLanguage.photo,
        sort: true,
        hidden: false,
        formatter: (cell, row, rowIndex) => {
          return (
            <React.Fragment>
              <img src={productimg} alt="" />
            </React.Fragment>
          );
        },
      },
      {
        dataField: "productname",
        text: productLanguage.productName,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: productLanguage.search,
        }),
      },
      {
        dataField: "sku",
        text: "SKU",
        sort: true,
        hidden: false,
      },
      {
        dataField: "soldout",
        text: productLanguage.whenSoldOut,
        sort: true,
        hidden: false,
      },

      {
        dataField: "available",
        text: productLanguage.available,
        sort: true,
        hidden: false,
        class: "text-center",
      },
      {
        dataField: "available",
        text: productLanguage.editQuantityAvailable,
        sort: true,
        hidden: false,
        classes: "text-center",
        headerClasses: "text-center",
        formatter: (cell, row, rowIndex) => {
          return (
            <React.Fragment>
              <div className="d-flex align-items-center justify-content-center">
                <div
                  className="btn-group me-2"
                  role="group"
                  aria-label="Basic radio toggle button group"
                >
                  <input
                    type="radio"
                    className="btn-check"
                    name="btnradio"
                    id="btnradio1"
                    autoComplete="off"
                  />
                  <label
                    className="btn black-btn-group-table"
                    htmlFor="btnradio1"
                  >
                    {productLanguage.Add}
                  </label>
                  <input
                    type="radio"
                    className="btn-check"
                    name="btnradio"
                    id="btnradio2"
                    autoComplete="off"
                  />
                  <label
                    className="btn black-btn-group-table"
                    htmlFor="btnradio2"
                  >
                    Set
                  </label>
                </div>
                <div className="me-2">
                  <input
                    type="number"
                    className="form-control input-custom-table-num"
                  />
                </div>
                <div className="common-red-btn">
                  <a href="#" className="btn red-btn">
                    {buttonLanguage.save}
                  </a>
                </div>
              </div>
            </React.Fragment>
          );
        },
      },
    ];
    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space align-items-center">
            <div className="col-sm-6 text-sm-start text-center rtl-txt-start">
              <div className="common-header-txt">
                <h3>{productLanguage.inventory}</h3>
              </div>
            </div>
            <div className="col-sm-6 text-sm-end text-center rtl-txt-end">
              <div className="common-red-btn">
                <a href="#" className="btn black-btn me-2">
                  {productLanguage.exportList}
                </a>

                <a href="#" className="btn red-btn">
                  {productLanguage.viewProduct}
                </a>
              </div>
            </div>
          </div>

          <div className="row common-space">
            <div className="col-md-12">
              <div className="white-box">
                <div className="btn-list-order productbtn-list">
                  <Dropdown>
                    <Dropdown.Toggle className="btn dropdown-toggle cust-search-button mb-0 cust-date me-sm-2 me-0">
                      <span>{productLanguage.taggedWith}</span>
                    </Dropdown.Toggle>
                    <Dropdown.Menu className="cust-drop-box">
                      <Dropdown.Item href="#/action-1">
                        {productLanguage.action}
                      </Dropdown.Item>
                      <Dropdown.Item href="#/action-2">
                        {productLanguage.anotherAction}
                      </Dropdown.Item>
                      <Dropdown.Item href="#/action-3">
                        {productLanguage.somethingElse}
                      </Dropdown.Item>
                    </Dropdown.Menu>
                  </Dropdown>
                  <Dropdown>
                    <Dropdown.Toggle className="btn dropdown-toggle cust-search-button mb-0 cust-date">
                      <span>{productLanguage.filter}</span>
                    </Dropdown.Toggle>
                    <Dropdown.Menu className="cust-drop-box">
                      <Dropdown.Item href="#/action-1">
                        {productLanguage.action}
                      </Dropdown.Item>
                      <Dropdown.Item href="#/action-2">
                        {productLanguage.anotherAction}
                      </Dropdown.Item>
                      <Dropdown.Item href="#/action-3">
                        {productLanguage.somethingElse}
                      </Dropdown.Item>
                    </Dropdown.Menu>
                  </Dropdown>
                </div>
                <div className="custom-table">
                  <div className="table-responsive dataTables_wrapper no-footer">
                    {this.state.order_data &&
                      console.log(this.state.order_data)}
                    {this.state.order_data && (
                      <DataTable
                        keyField="id"
                        loading={this.state.loading}
                        columns={columns}
                        data={this.state.order_data}
                        page={this.state.page}
                        sizePerPage={this.state.sizePerPage}
                        totalSize={this.state.totalSize}
                        defaultSorted={this.state.defaultSorted}
                        onTableChange={this.handleTableChange}
                        language={this.context.language}
                        selectableRows
                      />
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Adminlayout>
    );
  }
}

export default Inventory;
