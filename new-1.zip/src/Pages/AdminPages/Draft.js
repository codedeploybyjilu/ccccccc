import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import DataTable from "../../Components/DataTable";
import { textFilter } from "react-bootstrap-table2-filter";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";
import { Dropdown, Modal } from "react-bootstrap";
import {
  APIBaseUrl,
  API_Path,
  buttonArabic,
  buttonEnglish,
  SidebarArabic,
  SidebarEnglish,
  TableFieldArabic,
  TableFieldEnglish,
  titleArabic,
  titleEnglish,
  productArabic,
  productEnglish,
  LIVE_FILE_URL,
} from "../../const";
import LanguageContext from "../../contexts/languageContext";
import productimg from "../../images/product-img.png";
import dummyThumb from "../../images/store.png";
import Select from "react-select";
import moment from "moment";
import toastr from "toastr";
import "toastr/build/toastr.min.css";
import { PostApi } from "../../helper/APIService";
import ProductDetailModal from "./ProductDetailModal";
import { withRouter } from "react-router-dom";

export class Draft extends Component {
  static contextType = LanguageContext;

  constructor(props) {
    super(props);
    this.state = {
      View_Product_id: "",
      Product_details_model_show: false,
      search_val: "",
      loading: true,
      selectedOption: "",
      page: 1,
      sizePerPage: 10,
      totalSize: 0,
      defaultSorted: [
        {
          dataField: "id",
          order: "desc",
        },
      ],
      product_data: [],
    };
  }

  options = [
    { value: "Summer", label: "Summer" },
    { value: "winter", label: "winter" },
    { value: "monsoon", label: "monsoon" },
  ];

  get_product_data = () => {
    const data = {
      sizePerPage: this.state.sizePerPage,
      page: this.state.page,
      defaultSorted: this.state.defaultSorted,
      search_val: this.state.search_val,
    };
    // console.log('data is :: ', data)
    const getAllDraftDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(API_Path.getAllDraft, data));
    });
    getAllDraftDataPromise.then((res) => {
      // console.log(res, "&&&&&&&");
      if (res) {
        if (res.data.success) {
          this.setState({
            product_data: res.data.data,
            totalSize: res.data.totalRecord,
          });
        } else {
          toastr.error(res.data.message);
        }
      }
    });
  };

  handleChanges = (selectedOption) => {
    this.setState({ selectedOption });
  };

  edit_userClose = () => {
    this.setState({ search_show: false });
  };

  edit_userShow = (e) => {
    e.preventDefault();
    this.setState({ search_show: true });
  };

  edit_handleShow = (e) => {
    e.preventDefault();
    this.setState({ search_show: true });
  };

  delete_draft_record = (id) => {
    const data = {
      id: id,
    };
    // console.log('data is :: ', data)
    const deletDraftDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(API_Path.deletedraft, data));
    });
    deletDraftDataPromise.then((response) => {
      // console.log(response, "&&&&&&&");
      if (response.data.status === 200) {
        const deleteDraft = this.state.product_data.filter(
          (row) => row.id !== id
        );
        this.setState({ product_data: deleteDraft });
        toastr.success(response.data.message);
      } else {
        toastr.error(response.data.message);
      }
    });
  };

  delete_record = (id) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>Are you sure?</h1>
            <p>You want to delete this Draft Product?</p>
            <button className="btn red-btn me-2" onClick={onClose}>
              No
            </button>
            <button
              className="btn red-btn"
              onClick={() => {
                this.delete_draft_record(id);
                onClose();
              }}
            >
              Yes, Delete it!
            </button>
          </div>
        );
      },
    });
  };

  handleReturn = () => {
    this.props.history.push("/return-product");
  };

  customStyles = {
    control: () => ({
      height: "50px",
      backgroundColor: "#F7F7F7",
      border: "1px solid #F7F7F7",
      borderRadius: "10px",
      fontSize: "16px",
      color: "#5E5E6C",
      marginBottom: "15px",
      display: "flex",
    }),

    indicatorSeparator: () => ({
      backgroundColor: "transparent",
    }),

    indicatorContainer: () => ({
      backgroundColor: "#000",
    }),
  };

  handleTableChange = (
    type,
    { page, sizePerPage, filters, sortField, sortOrder }
  ) => {
    switch (type) {
      case "pagination":
        this.setState(
          {
            page,
            sizePerPage,
          },
          () => this.get_product_data()
        );
        break;
      case "filter":
        // console.log('filters :: ', filters);

        let search_val = filters;
        let newFilter = {};
        if (Object.keys(filters).length) {
          for (const dataField in filters) {
            newFilter[dataField] = filters[dataField].filterVal;
          }
          newFilter = {
            ...search_val,
            ...newFilter,
          };
        } else {
          newFilter = {
            title: "",
            indicator: "",
            definition: "",
          };
        }
        this.setState(
          {
            search_val: newFilter,
          },
          () => this.get_product_data()
        );
        break;
      case "sort":
        this.setState(
          {
            defaultSorted: [
              {
                dataField: sortField,
                order: sortOrder,
              },
            ],
          },
          () => this.get_product_data()
        );
        break;
      default:
        break;
    }
    return true;
  };

  View_product_detail_handleShow = (id) => {
    this.setState({ Product_details_model_show: true, View_Product_id: id });
  };

  View_product_detail_handleClose = () => {
    this.setState({ Product_details_model_show: false });
  };

  render() {
    let Language =
      this.context.language === "english"
        ? TableFieldEnglish
        : TableFieldArabic;
    let ButtonLanguage =
      this.context.language === "english" ? buttonEnglish : buttonArabic;
    let titleLanguage =
      this.context.language === "english" ? titleEnglish : titleArabic;
    let productLanguage =
      this.context.language === "english" ? productEnglish : productArabic;
    const columns = [
      {
        dataField: "id",
        text: "Id",
        hidden: true,
      },
      {
        dataField: "thumbnail",
        text: productLanguage.photo,
        sort: true,
        hidden: false,
        formatter: (cell, row, rowIndex) => {
          return (
            <React.Fragment>
              <img
                className="imgWidth"
                src={row.thumbnail ? row.thumbnail : dummyThumb}
                alt=""
              />
            </React.Fragment>
          );
        },
      },
      {
        dataField: "code",
        text: productLanguage.itemCode,
        sort: true,
        hidden: false,
      },
      {
        dataField:
          this.context.language === "english" ? "title_en" : "title_ar",
        text: productLanguage.productName,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: productLanguage.search,
        }),
      },
      {
        dataField:
          this.context.language === "english" ? "mc_english" : "mc_arabic",
        text: productLanguage.mainCategory,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: productLanguage.search,
        }),
      },
      {
        dataField:
          this.context.language === "english" ? "c_english" : "c_arabic",
        text: productLanguage.category,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: productLanguage.search,
        }),
      },
      {
        dataField:
          this.context.language === "english" ? "sc_english" : "sc_arabic",
        text: productLanguage.subCategory,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: productLanguage.search,
        }),
      },
      {
        dataField: "sales",
        text: productLanguage.sales,
        sort: true,
        hidden: false,
      },
      {
        dataField: "qty",
        text: productLanguage.quantity,
        sort: true,
        hidden: false,
      },
      {
        dataField: "createdat",
        text: productLanguage.date,
        sort: true,
        hidden: false,
        formatter: (cell, row, rowIndex) => {
          return moment(row.createdat).calendar(null, {
            sameDay: "[Today at] h:mm A",
            lastDay: "[Yesterday at] h:mm A",
            sameElse: "MM/DD/yy hh:mm A",
          });
        },
      },
      {
        dataField: "prefered",
        text: productLanguage.prefered,
        sort: true,
        hidden: false,
        headerClasses: "text-center",
        formatter: (cell, row, rowIndex) => {
          return (
            <React.Fragment>
              <div className="cust-star-table-rating">
                <input
                  type="checkbox"
                  className="btn-check"
                  id={"btncheck1_" + row.id}
                  autoComplete="off"
                />
                <label
                  className="bi bi-star"
                  htmlFor={"btncheck1_" + row.id}
                ></label>
              </div>
            </React.Fragment>
          );
        },
      },
      {
        dataField: "Action",
        text: productLanguage.action,
        hidden: false,
        csvExport: false,
        headerClasses: "text-right",
        classes: "text-right",
        formatter: (cell, row, rowIndex) => {
          return (
            <React.Fragment>
              <Dropdown className="cust-drop">
                <Dropdown.Toggle
                  className="bg-transparent "
                  id="dropdown-basic"
                  align="end"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width={16}
                    height={16}
                    fill="currentColor"
                    className="bi bi-three-dots-vertical"
                    viewBox="0 0 16 16"
                  >
                    <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                  </svg>
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  {/* <Dropdown.Item href="#" onClick={() => this.View_product_detail_handleShow(row.id)}>
                                        <svg width={20} height={15} viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M10 14C8.35987 14.0204 6.7367 13.6665 5.254 12.965C4.10469 12.4042 3.07265 11.6298 2.213 10.683C1.30243 9.70413 0.585467 8.56167 0.1 7.31601L0 7.00001L0.105 6.68401C0.590815 5.43944 1.30624 4.29728 2.214 3.31701C3.07334 2.37032 4.10504 1.59587 5.254 1.03501C6.73671 0.333598 8.35988 -0.0203796 10 9.39617e-06C11.6401 -0.0203444 13.2633 0.333631 14.746 1.03501C15.8953 1.59574 16.9274 2.3702 17.787 3.31701C18.6993 4.29456 19.4165 5.43737 19.9 6.68401L20 7.00001L19.895 7.31601C18.3262 11.3998 14.3742 14.0694 10 14ZM10 2.00001C6.59587 1.89334 3.47142 3.8751 2.117 7.00001C3.4712 10.1251 6.59579 12.107 10 12C13.4041 12.1064 16.5284 10.1247 17.883 7.00001C16.5304 3.87359 13.4047 1.89109 10 2.00001ZM10 10C8.55733 10.0096 7.30937 8.99737 7.02097 7.58378C6.73256 6.1702 7.48427 4.75003 8.81538 4.19367C10.1465 3.63731 11.6852 4.10014 12.4885 5.29852C13.2919 6.49689 13.1354 8.09609 12.115 9.11601C11.5563 9.68127 10.7948 9.99957 10 10Z" fill="#2D2D3B" />
                                        </svg>
                                        <span>View</span>
                                    </Dropdown.Item> */}
                  <Dropdown.Item href={" /product-details/" + row.id}>
                    <svg
                      width={20}
                      height={15}
                      viewBox="0 0 20 15"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M10 14C8.35987 14.0204 6.7367 13.6665 5.254 12.965C4.10469 12.4042 3.07265 11.6298 2.213 10.683C1.30243 9.70413 0.585467 8.56167 0.1 7.31601L0 7.00001L0.105 6.68401C0.590815 5.43944 1.30624 4.29728 2.214 3.31701C3.07334 2.37032 4.10504 1.59587 5.254 1.03501C6.73671 0.333598 8.35988 -0.0203796 10 9.39617e-06C11.6401 -0.0203444 13.2633 0.333631 14.746 1.03501C15.8953 1.59574 16.9274 2.3702 17.787 3.31701C18.6993 4.29456 19.4165 5.43737 19.9 6.68401L20 7.00001L19.895 7.31601C18.3262 11.3998 14.3742 14.0694 10 14ZM10 2.00001C6.59587 1.89334 3.47142 3.8751 2.117 7.00001C3.4712 10.1251 6.59579 12.107 10 12C13.4041 12.1064 16.5284 10.1247 17.883 7.00001C16.5304 3.87359 13.4047 1.89109 10 2.00001ZM10 10C8.55733 10.0096 7.30937 8.99737 7.02097 7.58378C6.73256 6.1702 7.48427 4.75003 8.81538 4.19367C10.1465 3.63731 11.6852 4.10014 12.4885 5.29852C13.2919 6.49689 13.1354 8.09609 12.115 9.11601C11.5563 9.68127 10.7948 9.99957 10 10Z"
                        fill="#2D2D3B"
                      />
                    </svg>
                    <span>{productLanguage.preview}</span>
                  </Dropdown.Item>
                  <Dropdown.Item href={"edit-product/" + row.id}>
                    <svg
                      width="19"
                      height="18"
                      viewBox="0 0 19 19"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
                        fill="#2D2D3B"
                      ></path>
                    </svg>
                    <span>{ButtonLanguage.edit}</span>
                  </Dropdown.Item>
                  <Dropdown.Item
                    href="#"
                    onClick={() => this.delete_record(row.id)}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width={18}
                      height={18}
                      fill="currentColor"
                      className="bi bi-trash"
                      viewBox="0 0 16 16"
                    >
                      <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
                      <path
                        fillRule="evenodd"
                        d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"
                      />
                    </svg>
                    <span>{ButtonLanguage.delete}</span>
                  </Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </React.Fragment>
          );
        },
      },
    ];

    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space">
            <div className="col-md-4 text-md-start text-center rtl-txt-start">
              <div className="common-header-txt">
                <h3>{productLanguage.product}</h3>
              </div>
            </div>
            <div className="col-md-8 text-md-end text-center rtl-txt-end">
              <div className="common-red-btn">
                <a
                  href="#"
                  className="btn red-btn me-2 mt-sm-0 mt-2"
                  onClick={this.edit_handleShow}
                >
                  {productLanguage.applyFeature}
                </a>
                <a href="#" className="btn black-btn me-2 mt-sm-0 mt-2">
                  {productLanguage.exportList}
                </a>
                <a href="add-product" className="btn red-btn mt-sm-0 mt-2">
                  {productLanguage.addProduct}
                </a>
              </div>
            </div>
          </div>
          <div className="row common-space">
            <div className="col-md-12">
              <div className="white-box">
                <div className="btn-list-order productbtn-list">
                  {/* <button className="btn white-btn me-sm-2 me-0" onClick={this.handleReturn}>Return Products</button> */}
                  {/* <Dropdown>
                                        <Dropdown.Toggle className="btn dropdown-toggle cust-search-button mb-0 cust-date me-sm-2 me-0">
                                            <span>Top Selling</span>
                                        </Dropdown.Toggle>
                                        <Dropdown.Menu className="cust-drop-box">
                                            <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
                                            <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
                                            <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
                                        </Dropdown.Menu>
                                    </Dropdown>
                                    <button className="btn white-btn me-sm-2 me-0">Not Moving</button> */}
                  <Dropdown>
                    <Dropdown.Toggle className="btn dropdown-toggle cust-search-button mb-0 cust-date me-sm-2 me-0">
                      <span>{productLanguage.taggedWith}</span>
                    </Dropdown.Toggle>
                    <Dropdown.Menu className="cust-drop-box">
                      <Dropdown.Item href="#/action-1">
                        {productLanguage.action}
                      </Dropdown.Item>
                      <Dropdown.Item href="#/action-2">
                        {productLanguage.anotherAction}
                      </Dropdown.Item>
                      <Dropdown.Item href="#/action-3">
                        {productLanguage.somethingElse}
                      </Dropdown.Item>
                    </Dropdown.Menu>
                  </Dropdown>
                  <Dropdown>
                    <Dropdown.Toggle className="btn dropdown-toggle cust-search-button mb-0 cust-date me-sm-2 me-0">
                      <span>{productLanguage.stock}</span>
                    </Dropdown.Toggle>
                    <Dropdown.Menu className="cust-drop-box">
                      <ul className="stock-list-product">
                        <li>
                          <div className="help-support-txt ">
                            <label className="cust-radio">
                              <input type="radio" name="radio" />
                              <span className="checkmark" />
                            </label>
                            <span className>{productLanguage.InStock}</span>
                          </div>
                        </li>
                        <li>
                          <div className="help-support-txt ">
                            <label className="cust-radio">
                              <input type="radio" name="radio" />
                              <span className="checkmark" />
                            </label>
                            <span className>{productLanguage.OutOfStock}</span>
                          </div>
                        </li>
                        <li>
                          <div className="help-support-txt ">
                            <label className="cust-radio">
                              <input type="radio" name="radio" />
                              <span className="checkmark" />
                            </label>
                            <span className>{productLanguage.LowStock}</span>
                          </div>
                        </li>
                      </ul>
                    </Dropdown.Menu>
                  </Dropdown>
                  {/* <Dropdown>
                                        <Dropdown.Toggle className="btn dropdown-toggle cust-search-button mb-0 cust-date me-sm-2 me-0">
                                            <span>Category</span>
                                        </Dropdown.Toggle>
                                        <Dropdown.Menu className="cust-drop-box">
                                            <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
                                            <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
                                            <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
                                        </Dropdown.Menu>
                                    </Dropdown>
                                    <Dropdown>
                                        <Dropdown.Toggle className="btn dropdown-toggle cust-search-button mb-0 cust-date me-sm-2 me-0">
                                            <span>Sub Category</span>
                                        </Dropdown.Toggle>
                                        <Dropdown.Menu className="cust-drop-box">
                                            <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
                                            <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
                                            <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
                                        </Dropdown.Menu>
                                    </Dropdown> */}
                  <Dropdown>
                    <Dropdown.Toggle className="btn dropdown-toggle cust-search-button mb-0 cust-date me-sm-2 me-0">
                      <span>{productLanguage.Price}</span>
                    </Dropdown.Toggle>
                    <Dropdown.Menu className="cust-drop-box">
                      <Dropdown.Item href="#/action-1">
                        {productLanguage.action}
                      </Dropdown.Item>
                      <Dropdown.Item href="#/action-2">
                        {productLanguage.anotherAction}
                      </Dropdown.Item>
                      <Dropdown.Item href="#/action-3">
                        {productLanguage.somethingElse}
                      </Dropdown.Item>
                    </Dropdown.Menu>
                  </Dropdown>
                  <Dropdown>
                    <Dropdown.Toggle className="btn dropdown-toggle cust-search-button mb-0 cust-date">
                      <span>{productLanguage.selectDate}</span>
                    </Dropdown.Toggle>
                    <Dropdown.Menu className="cust-drop-box fix-box-drop">
                      <div className="row m-0">
                        <div className="col-md-6 form-group pe-0">
                          <label>{productLanguage.From}</label>
                          <input type="date" className="form-control" />
                        </div>
                        <div className="col-md-6 form-group">
                          <label>{productLanguage.To}</label>
                          <input type="date" className="form-control" />
                        </div>
                        <div className="col-12">
                          <div
                            className="btn-group pt-3 pb-3 d-block"
                            role="group"
                            aria-label="Basic radio toggle button group"
                          >
                            <ul>
                              <li>
                                <input
                                  type="radio"
                                  className="btn-check date-checked"
                                  name="btnradio"
                                  id="btnradio1"
                                  autoComplete="off"
                                  defaultChecked
                                />
                                <label
                                  className="btn gray-btn-date w-100"
                                  htmlFor="btnradio1"
                                >
                                  {productLanguage.today}
                                </label>
                              </li>
                              <li>
                                <input
                                  type="radio"
                                  className="btn-check date-checked"
                                  name="btnradio"
                                  id="btnradio2"
                                  autoComplete="off"
                                />
                                <label
                                  className="btn gray-btn-date w-100"
                                  htmlFor="btnradio2"
                                >
                                  {productLanguage.yesterday}
                                </label>
                              </li>
                              <li>
                                <input
                                  type="radio"
                                  className="btn-check date-checked"
                                  name="btnradio"
                                  id="btnradio3"
                                  autoComplete="off"
                                />
                                <label
                                  className="btn gray-btn-date w-100"
                                  htmlFor="btnradio3"
                                >
                                  {productLanguage.last_3_Months}
                                </label>
                              </li>
                              <li>
                                <input
                                  type="radio"
                                  className="btn-check date-checked"
                                  name="btnradio"
                                  id="btnradio4"
                                  autoComplete="off"
                                />
                                <label
                                  className="btn gray-btn-date w-100"
                                  htmlFor="btnradio4"
                                >
                                  {productLanguage.thisYears}
                                </label>
                              </li>
                            </ul>
                          </div>
                          <div className="col-12 text-center">
                            <div className="common-red-btn">
                              <a href="#" className="btn black-btn me-2">
                                {ButtonLanguage.cancel}
                              </a>
                              <a href="add-admin" className="btn red-btn">
                                {ButtonLanguage.update}
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Dropdown.Menu>
                  </Dropdown>
                </div>
                <div className="table-responsive dataTables_wrapper no-footer">
                  {this.state.product_data && (
                    <DataTable
                      keyField="id"
                      loading={this.state.loading}
                      columns={columns}
                      data={this.state.product_data}
                      page={this.state.page}
                      sizePerPage={this.state.sizePerPage}
                      totalSize={this.state.totalSize}
                      defaultSorted={this.state.defaultSorted}
                      onTableChange={this.handleTableChange}
                      language={this.context.language}
                      selectableRows
                    />
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ------------------------modal-------------------------- */}

        <Modal
          dialogClassName="modal-dialog-centered cust-width-modal"
          className="edit-user-modal cust-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.search_show}
          onHide={this.edit_userClose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">{productLanguage.Feature}</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.edit_userClose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <div className="row modal-form">
              <div className="col-md-12 form-group">
                <label>{productLanguage.offer}</label>
                <ul className="product-list-check-offer">
                  <li>
                    <div className="cust-checkbox-new">
                      <label className="cust-chk-bx">
                        <input type="checkbox" />
                        <span className="cust-chkmark" />
                        50% off
                      </label>
                    </div>
                  </li>
                  <li>
                    <div className="cust-checkbox-new">
                      <label className="cust-chk-bx">
                        <input type="checkbox" />
                        <span className="cust-chkmark" />
                        10% off
                      </label>
                    </div>
                  </li>
                  <li>
                    <div className="cust-checkbox-new">
                      <label className="cust-chk-bx">
                        <input type="checkbox" />
                        <span className="cust-chkmark" />
                        50% off
                      </label>
                    </div>
                  </li>
                  <li>
                    <div className="cust-checkbox-new">
                      <label className="cust-chk-bx">
                        <input type="checkbox" />
                        <span className="cust-chkmark" />
                        20% off
                      </label>
                    </div>
                  </li>
                  <li>
                    <div className="cust-checkbox-new">
                      <label className="cust-chk-bx">
                        <input type="checkbox" />
                        <span className="cust-chkmark" />
                        10% off
                      </label>
                    </div>
                  </li>
                  <li>
                    <div className="cust-checkbox-new">
                      <label className="cust-chk-bx">
                        <input type="checkbox" />
                        <span className="cust-chkmark" />
                        60% off
                      </label>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="col-md-12 form-group">
                <label>{productLanguage.Tag}</label>
                <Select
                  isMulti
                  value={this.state.selectedOption}
                  onChange={this.handleChanges}
                  options={this.options}
                  styles={this.customStyles}
                />
              </div>
              <div className="col-md-12 form-group">
                <label>{productLanguage.status}</label>
                <label className="switch d-block">
                  <input type="checkbox" />
                  <div className="slider round" />
                  <div className="text" />
                </label>
              </div>

              <div className="col-md-12 form-group text-center mb-3">
                <button type="button" className="btn red-btn">
                  {ButtonLanguage.apply}
                </button>
              </div>
            </div>
          </Modal.Body>
        </Modal>

        {/* ------------------------Product Details modal Start-------------------------- */}

        <Modal
          dialogClassName="modal-xl modal-dialog-centered"
          className="edit-user-modal cust-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.Product_details_model_show}
          onHide={this.View_product_detail_handleClose}
        >
          <ProductDetailModal
            View_product_detail_handleClose={
              this.View_product_detail_handleClose
            }
            View_Product_id={this.state.View_Product_id}
          />
        </Modal>

        {/* ------------------------Product Details modal Close-------------------------- */}
      </Adminlayout>
    );
  }
}

export default withRouter(Draft);
