import React, { Component } from "react";
import {
  API_Path,
  APIBaseUrl,
  buttonArabic,
  buttonEnglish,
  TableFieldArabic,
  TableFieldEnglish,
  titleArabic,
  titleEnglish,
  productArabic,
  productEnglish,
} from "../../const";
import { PostApi } from "../../helper/APIService";
import { Modal } from "react-bootstrap";
import productimg from "../../images/product-img.png";
import moment from "moment";
import toastr from "toastr";
import "toastr/build/toastr.min.css";
import LanguageContext from "../../contexts/languageContext";

class ProductDetailModal extends Component {
  static contextType = LanguageContext;

  constructor(props) {
    super(props);
    this.state = {
      product_id: "",
      product_details: [],
    };
  }

  componentDidMount() {
    this.setState({ product_id: this.props.View_Product_id }, () => {
      this.get_Product_by_id(this.state.product_id);
    });
  }

  close_model = () => {
    this.props.View_product_detail_handleClose();
  };

  get_Product_by_id = (id) => {
    const formData = { product_id: id };
    const getProductDetailDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(API_Path.getProductDetailById, formData));
    });
    getProductDetailDataPromise.then((response) => {
      if (response.status === 200) {
        this.setState({ product_details: response.data.data[0] });
      } else {
        toastr.error(response.data.message);
      }
    });
  };

  render() {
    let Language =
      this.context.language === "english"
        ? TableFieldEnglish
        : TableFieldArabic;
    let ButtonLanguage =
      this.context.language === "english" ? buttonEnglish : buttonArabic;
    let titleLanguage =
      this.context.language === "english" ? titleEnglish : titleArabic;
    let productLanguage =
      this.context.language === "english" ? productEnglish : productArabic;
    return (
      <React.Fragment>
        <Modal.Header>
          <Modal.Title>
            <h1 className="modal-title">Products details</h1>
          </Modal.Title>
          <button
            type="button"
            onClick={this.close_model}
            className="close btn-close"
          ></button>
        </Modal.Header>
        <Modal.Body>
          <div className="row">
            <div className="col-md-12 my-3">
              <div className="white-box">
                <div className="row cust-form-user">
                  <div className="form-group col-md-9">
                    <ul className="d-flex flex-wrap new-product-list">
                      <li>
                        <img src={productimg} />
                      </li>
                      <li>
                        <img src={productimg} />
                      </li>
                      <li>
                        <img src={productimg} />
                      </li>
                    </ul>
                  </div>
                  <div className="form-group col-md-3">
                    <label>{productLanguage.itemCode}</label>
                    <input
                      type="text"
                      className="form-control"
                      readOnly
                      defaultValue={this.state.product_details["code"]}
                    />
                  </div>
                  <form className="row cust-form-user">
                    <div className="form-group col-md-6">
                      <label>Product Name in English</label>
                      <input
                        type="text"
                        className="form-control"
                        readOnly
                        defaultValue={this.state.product_details["title_en"]}
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <label>Product Name in Arabic</label>
                      <input
                        type="text"
                        className="form-control"
                        readOnly
                        defaultValue={this.state.product_details["title_ar"]}
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <label>{productLanguage.mainCategory}</label>
                      <input
                        type="text"
                        className="form-control"
                        readOnly
                        defaultValue={this.state.product_details["mc_english"]}
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <label>{productLanguage.mainCategory}</label>
                      <input
                        type="text"
                        className="form-control"
                        readOnly
                        defaultValue={this.state.product_details["mc_arabic"]}
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <label>{productLanguage.category}</label>
                      <input
                        type="text"
                        className="form-control"
                        readOnly
                        defaultValue={this.state.product_details["c_english"]}
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <label>{productLanguage.category}</label>
                      <input
                        type="text"
                        className="form-control"
                        readOnly
                        defaultValue={this.state.product_details["c_arabic"]}
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <label>{productLanguage.subCategory}</label>
                      <input
                        type="text"
                        className="form-control"
                        readOnly
                        defaultValue={this.state.product_details["sc_english"]}
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <label>{productLanguage.subCategory}</label>
                      <input
                        type="text"
                        className="form-control"
                        readOnly
                        defaultValue={this.state.product_details["sc_arabic"]}
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <label>{productLanguage.Description}</label>
                      <textarea
                        className="form-control"
                        defaultValue={
                          this.state.product_details["description_en"]
                        }
                        readOnly
                      ></textarea>
                    </div>
                    <div className="form-group col-md-6">
                      <label>{productLanguage.Description}</label>
                      <textarea
                        className="form-control"
                        defaultValue={
                          this.state.product_details["description_ar"]
                        }
                        readOnly
                      ></textarea>
                    </div>
                    <div className="form-group col-md-6">
                      <label>Price</label>
                      <input
                        type="text"
                        className="form-control"
                        readOnly
                        defaultValue=""
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <label>{productLanguage.quantity}</label>
                      <input
                        type="number"
                        className="form-control"
                        readOnly
                        defaultValue=""
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <label>{productLanguage.date}</label>
                      <input
                        type=""
                        className="form-control"
                        readOnly
                        defaultValue={moment(
                          this.state.product_details["createdat"]
                        ).format("DD-MM-YYYY")}
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <label>{productLanguage.color}</label>
                      <input
                        type="text"
                        className="form-control"
                        readOnly
                        defaultValue={this.state.product_details["color"]}
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <label>{productLanguage.size}</label>
                      <input
                        type="text"
                        className="form-control"
                        readOnly
                        defaultValue={this.state.product_details["size"]}
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <label>{productLanguage.BarcodeNo}</label>
                      <input
                        type="text"
                        className="form-control"
                        readOnly
                        defaultValue={this.state.product_details["barcode"]}
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <label>{productLanguage.ProductCode}</label>
                      <input
                        type="text"
                        className="form-control"
                        readOnly
                        defaultValue={
                          this.state.product_details["product_code"]
                        }
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <label>{productLanguage.Length}</label>
                      <input
                        type="text"
                        className="form-control"
                        readOnly
                        defaultValue={this.state.product_details["length"]}
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <label>Neck Length</label>
                      <input
                        type="text"
                        className="form-control"
                        readOnly
                        defaultValue={this.state.product_details["neck"]}
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <label>Neck Line</label>
                      <input
                        type="text"
                        className="form-control"
                        readOnly
                        defaultValue={this.state.product_details["neck"]}
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <label>Waist Type</label>
                      <input
                        type="text"
                        className="form-control"
                        readOnly
                        defaultValue={this.state.product_details["west"]}
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <label>{productLanguage.sales}</label>
                      <input
                        type="number"
                        className="form-control"
                        readOnly
                        defaultValue={this.state.product_details["sales"]}
                      />
                    </div>
                    <div className="form-group col-md-12">
                      <label>{productLanguage.Material}</label>
                      <input
                        type="text"
                        className="form-control"
                        readOnly
                        defaultValue={this.state.product_details["material"]}
                      />
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <button type="reset" onClick={this.close_model} className="btn">
            Close
          </button>
        </Modal.Footer>
      </React.Fragment>
    );
  }
}

export default ProductDetailModal;
