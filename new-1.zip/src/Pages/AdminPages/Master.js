import React, { Component } from "react";
import saleimg from "../../images/sale-img.png";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import DataTable from "../../Components/DataTable";
import { textFilter } from "react-bootstrap-table2-filter";
import { confirmAlert } from "react-confirm-alert";
import {
	APIBaseUrl,
	API_Path,
	buttonArabic,
	buttonEnglish,
	TableFieldArabic,
	TableFieldEnglish,
	titleArabic,
	titleEnglish,
	masterEnglish,
	masterArabic,
	LIVE_FILE_URL,
} from "../../const";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import LanguageContext from "../../contexts/languageContext";
import { Accordion, Dropdown, Modal } from "react-bootstrap";
import { PostApi } from "../../helper/APIService";
import moment from "moment";
import Position1 from "../../Models/Position1";
import Position2 from "../../Models/Position2";
import Position3 from "../../Models/Position3";
import Position4 from "../../Models/Position4";
import Position5 from "../../Models/Position5";
import Position6 from "../../Models/Position6";
import Position7 from "../../Models/Position7";
import Position8 from "../../Models/Position8";
import Position9 from "../../Models/Position9";
import Position10 from "../../Models/Position10";
import Position11 from "../../Models/Position11";
import bannermain from "../../images/banner-main-ad.png";
import bannerpos3 from "../../images/banner-pos-3.png";
import pos4_1 from "../../images/pos4-1.png";
import pos4_2 from "../../images/pos4-2.png";
import pos4_3 from "../../images/pos4-3.png";
import pos5_1 from "../../images/pos5_1.png";
import pos5_2 from "../../images/pos5_2.png";
import pos5_3 from "../../images/pos5_3.png";
import pos6_1 from "../../images/pos6-1.png";
import pos7_1 from "../../images/pos7-1.png";
import pos8_1 from "../../images/pos8-1.png";
import pos9_1 from "../../images/pos9-1.png";
import pos10_1 from "../../images/pos10-1.png";
import pos10_2 from "../../images/pos10-2.png";
import pos10_3 from "../../images/pos10-3.png";
import pos10_4 from "../../images/pos10-4.png";
import pos11_1 from "../../images/pos11-1.png";
import pos11_2 from "../../images/pos11-2.png";
import plus from "../../images/plus-bg.svg";
import loader from "../../images/loader.gif";
import toastr from "toastr";
import EditPosition1 from "../../Models/EditPosition1";
import EditPosition2 from "../../Models/EditPosition2";
import EditPosition3 from "../../Models/EditPosition3";
import EditPosition4 from "../../Models/EditPosition4";
import EditPosition6 from "../../Models/EditPosition6";
import EditPosition7 from "../../Models/EditPosition7";
import EditPosition8 from "../../Models/EditPosition8";
import EditPosition9 from "../../Models/EditPosition9";
import EditPosition10 from "../../Models/EditPosition10";
import EditPosition11 from "../../Models/EditPosition11";
import EditPosition5 from "../../Models/EditPosition5";
import EditBanner from "./EditBanner";

const reorder = (list, startIndex, endIndex) => {
	// console.log(list, 'list')
	const result = Array.from(list);
	const [removed] = result.splice(startIndex, 1);
	result.splice(endIndex, 0, removed);

	return result;
};

const getItemStyle = (isDragging, draggableStyle) => ({
	userSelect: "none",
	// background: isDragging ? '#A81A1C' : '#F7F7F7',
	...draggableStyle,
});

const getListStyle = (isDraggingOver, itemsLength) => ({
	// background: isDraggingOver ? '#f7f7f7' : '#fff',
	display: "flex",
	flexWrap: "no-wrap",
	// width: itemsLength * 150 + 10,
});

class Master extends Component {
	static contextType = LanguageContext;
	constructor(props) {
		super(props);
		this.state = {
			masterCategory: "women",
			position1: "Position 1",
			position2: "Position 2",
			position3: "Position 3",
			position4: "Position 4",
			position5: "Position 5",
			position6: "Position 6",
			Newposition6: "Staff Piked Item",
			position7: "Position 7",
			position8: "Position 8",
			position9: "Position 9",
			position10: "Position 10",
			position11: "Position 11",
			Position1: false,
			Position2: false,
			Position3: false,
			Position4: false,
			Position5: false,
			Position6: false,
			NewPosition6: false,
			Position7: false,
			Position8: false,
			Position9: false,
			Position10: false,
			Position11: false,
			editPosition1: false,
			editPosition2: false,
			editPosition3: false,
			editPosition4: false,
			editPosition5: false,
			editPosition6: false,
			NeweditPosition6: false,
			editPosition7: false,
			editPosition8: false,
			editPosition9: false,
			editPosition10: false,
			editPosition11: false,
			position1Banners: [],
			position2Banners: [],
			position3Banners: [],
			position4Banners: [],
			position5Banners: [],
			position6Banners: [],
			Newposition6Banners: [],
			position7Banners: [],
			position8Banners: [],
			position9Banners: [],
			position10Banners: [],
			position11Banners: [],
			isLoading: true,
			editBannerNameEnglish: "",
			editBannerNameArabic: "",
			getArray: [
				{
					name: "one",
					stateName: "position1Banners",
					activeStatus: "position1ActiveStatus",
					bannerName: "position1",
				},
				{
					name: "two",
					stateName: "position2Banners",
					activeStatus: "position2ActiveStatus",
					bannerName: "position2",
				},
				{
					name: "three",
					stateName: "position3Banners",
					activeStatus: "position3ActiveStatus",
					bannerName: "position3",
				},
				{
					name: "four",
					stateName: "position4Banners",
					activeStatus: "position4ActiveStatus",
					bannerName: "position4",
				},
				{
					name: "five",
					stateName: "position5Banners",
					activeStatus: "position5ActiveStatus",
					bannerName: "position5",
				},
				{
					name: "six",
					stateName: "position6Banners",
					activeStatus: "position6ActiveStatus",
					bannerName: "position6",
				},
				{
					name: "seven",
					stateName: "position7Banners",
					activeStatus: "position7ActiveStatus",
					bannerName: "position7",
				},
				{
					name: "eight",
					stateName: "position8Banners",
					activeStatus: "position8ActiveStatus",
					bannerName: "position8",
				},
				{
					name: "nine",
					stateName: "position9Banners",
					activeStatus: "position9ActiveStatus",
					bannerName: "position9",
				},
				{
					name: "ten",
					stateName: "position10Banners",
					activeStatus: "position10ActiveStatus",
					bannerName: "position10",
				},
				{
					name: "eleven",
					stateName: "position11Banners",
					activeStatus: "position11ActiveStatus",
					bannerName: "position11",
				},
			],
			editBannerData: "",
			bannerNameEdit: false,
			EditStateName: "",
			position1ActiveStatus: false,
			position2ActiveStatus: false,
			position3ActiveStatus: false,
			position4ActiveStatus: false,
			position5ActiveStatus: false,
			position6ActiveStatus: false,
			Newposition6ActiveStatus: false,
			position7ActiveStatus: false,
			position8ActiveStatus: false,
			position9ActiveStatus: false,
			position10ActiveStatus: false,
			position11ActiveStatus: false,
			maincategoryData: '',
			selectedMainCatagory: '',
			ActionTagArr: [],
			selectedTags: [],
			TagCatagoryType: '0'
		};
	}

	componentDidMount = () => {
		this.getBanner();
		this.getMainCategoryData('women')
		this.selectAccordian()
	};
	getMainCategoryData = (id) => {

		let data = {};

		let path = API_Path.getMainCategory;
		const getMainCategoryPromise = new Promise((resolve, reject) => {
			resolve(PostApi(path, data));
		});

		getMainCategoryPromise.then((res) => {
			if (res) {
				this.setState({ maincategoryData: res.data.data }, () => {
					let select = res.data.data.filter(obj => obj.english == id)
					this.setState({ selectedMainCatagory: select[0] })
				});
			}
		});
	};
	getBannerName = (name) => {
		let data = {
			table_name: name,
			master_category: this.state.masterCategory
		}
		let path = API_Path.getBannerName;
		const getBannerNamePromise = new Promise((resolve, reject) => {
			resolve(PostApi(path, data));
		});

		getBannerNamePromise.then((res) => {
			if (res.data.success) {
				this.setState({
					editBannerNameEnglish: res.data.data[0].banner_name_en,
					editBannerNameArabic: res.data.data[0].banner_name_ar
				})
			}
		});
	}

	handleChangeForRadio = (e) => {
		// console.log('e :: ', e);
		if (e.target.checked) {
			this.setState({ masterCategory: e.target.id, isLoading: true, selectedTags: [] }, () => {
				this.getMainCategoryData(this.state.masterCategory)
				this.getBanner();
				this.selectAccordian()
			});
		}
	};

	onPosition1DragEnd = (result) => {
		// dropped outside the list
		if (!result.destination) {
			return;
		}
		// console.log('edit :: ', this.state.editVariationImages);
		const position1Banners = reorder(
			this.state.position1Banners,
			result.source.index,
			result.destination.index
		);

		this.setState(
			{
				position1Banners,
			},
			() => {
				let tempArray = [];
				for (let i = 0; i < this.state.position1Banners.length; i++) {
					let data = {
						id: this.state.position1Banners[i].id,
					};
					tempArray.push(data);
				}
				let data = {
					table_name: "one",
					fields: tempArray,
				};
				this.SortArray(data);
				// console.log(tempArray);
			}
		);
	};

	onPosition2DragEnd = (result) => {
		// dropped outside the list
		if (!result.destination) {
			return;
		}
		// console.log('edit :: ', this.state.editVariationImages);
		const position2Banners = reorder(
			this.state.position2Banners,
			result.source.index,
			result.destination.index
		);

		this.setState(
			{
				position2Banners,
			},
			() => {
				let tempArray = [];
				for (let i = 0; i < this.state.position2Banners.length; i++) {
					let data = {
						id: this.state.position2Banners[i].id,
					};
					tempArray.push(data);
				}
				let data = {
					table_name: "two",
					fields: tempArray,
				};
				this.SortArray(data);
				// console.log(tempArray);
			}
		);
	};

	onPosition4DragEnd = (result) => {
		// dropped outside the list
		if (!result.destination) {
			return;
		}
		// console.log('edit :: ', this.state.editVariationImages);
		const position4Banners = reorder(
			this.state.position4Banners,
			result.source.index,
			result.destination.index
		);

		this.setState(
			{
				position4Banners,
			},
			() => {
				let tempArray = [];
				for (let i = 0; i < this.state.position4Banners.length; i++) {
					let data = {
						id: this.state.position4Banners[i].id,
					};
					tempArray.push(data);
				}
				let data = {
					table_name: "four",
					fields: tempArray,
				};
				this.SortArray(data);
				// console.log(tempArray);
			}
		);
	};

	onPosition7DragEnd = (result) => {
		// dropped outside the list
		if (!result.destination) {
			return;
		}
		// console.log('edit :: ', this.state.editVariationImages);
		const position7Banners = reorder(
			this.state.position7Banners,
			result.source.index,
			result.destination.index
		);

		this.setState(
			{
				position7Banners,
			},
			() => {
				let tempArray = [];
				for (let i = 0; i < this.state.position7Banners.length; i++) {
					let data = {
						id: this.state.position7Banners[i].id,
					};
					tempArray.push(data);
				}
				let data = {
					table_name: "seven",
					fields: tempArray,
				};
				this.SortArray(data);
				// console.log(tempArray);
			}
		);
	};

	onPosition8DragEnd = (result) => {
		// dropped outside the list
		if (!result.destination) {
			return;
		}
		// console.log('edit :: ', this.state.editVariationImages);
		const position8Banners = reorder(
			this.state.position8Banners,
			result.source.index,
			result.destination.index
		);

		this.setState(
			{
				position8Banners,
			},
			() => {
				let tempArray = [];
				for (let i = 0; i < this.state.position8Banners.length; i++) {
					let data = {
						id: this.state.position8Banners[i].id,
					};
					tempArray.push(data);
				}
				let data = {
					table_name: "eight",
					fields: tempArray,
				};
				this.SortArray(data);
				// console.log(tempArray);
			}
		);
	};

	onPosition10DragEnd = (result) => {
		// dropped outside the list
		if (!result.destination) {
			return;
		}
		// console.log('edit :: ', this.state.editVariationImages);
		const position10Banners = reorder(
			this.state.position10Banners,
			result.source.index,
			result.destination.index
		);

		this.setState(
			{
				position10Banners,
			},
			() => {
				let tempArray = [];
				for (let i = 0; i < this.state.position10Banners.length; i++) {
					let data = {
						id: this.state.position10Banners[i].id,
					};
					tempArray.push(data);
				}
				let data = {
					table_name: "ten",
					fields: tempArray,
				};
				this.SortArray(data);
				// console.log(tempArray);
			}
		);
	};

	onPosition11DragEnd = (result) => {
		// dropped outside the list
		if (!result.destination) {
			return;
		}
		// console.log('edit :: ', this.state.editVariationImages);
		const position11Banners = reorder(
			this.state.position11Banners,
			result.source.index,
			result.destination.index
		);

		this.setState(
			{
				position11Banners,
			},
			() => {
				let tempArray = [];
				for (let i = 0; i < this.state.position11Banners.length; i++) {
					let data = {
						id: this.state.position11Banners[i].id,
					};
					tempArray.push(data);
				}
				let data = {
					table_name: "eleven",
					fields: tempArray,
				};
				this.SortArray(data);
				// console.log(tempArray);
			}
		);
	};

	SortArray = (data) => {
		let path = API_Path.sortArray;
		const sortingPromise = new Promise((resolve, reject) => {
			resolve(PostApi(path, data));
		});
		sortingPromise.then((res) => {
			if (res) {
				// console.log('res :: ', res);
			}
		});
	};

	getBanner = () => {
		let testArray = [];
		for (let i = 0; i < this.state.getArray.length; i++) {
			let path = API_Path.GetBanner;
			let data = {
				table_name: this.state.getArray[i].name,
				master_category: this.state.masterCategory,
			};
			const addBannerPromise = new Promise((resolve, reject) => {
				resolve(PostApi(path, data));
			});

			addBannerPromise.then((res) => {
				if (res) {
					testArray.push("1");
					if (res.data.data) {
						let status =
							res.data.data[0].active_banner_status == 1 ? true : false;
						this.setState(
							{
								[this.state.getArray[i].stateName]: res.data.data,
								[this.state.getArray[i].activeStatus]: status,
							},
							() => {
								if (res.data.data[0].banner_name_en) {
									this.setState({
										[this.state.getArray[i].bannerName]:
											res.data.data[0].banner_name_en,
									});
								} else {
									this.setState({
										[this.state.getArray[i].bannerName]:
											this.state.getArray[i].bannerName,
									});
								}
								if (testArray.length == 11) {
									this.setState({ isLoading: false });
								}
							}
						);
					} else {
						this.setState(
							{
								[this.state.getArray[i].stateName]: [],
								[this.state.getArray[i].bannerName]:
									this.state.getArray[i].bannerName,
							},
							() => {
								if (testArray.length == 11) {
									this.setState({ isLoading: false });
								}
							}
						);
					}
				}
			});
		}
	};

	getSingleBanner = (name) => {
		let path = API_Path.GetBanner;
		let data = {
			table_name: name,
			master_category: this.state.masterCategory,
		};
		let stateName = "";
		let bannerStateName = "";
		if (name === "one") {
			stateName = "position1Banners";
			bannerStateName = "position1";
		}
		if (name === "two") {
			stateName = "position2Banners";
			bannerStateName = "position2";
		}
		if (name === "three") {
			stateName = "position3Banners";
			bannerStateName = "position3";
		}
		if (name === "four") {
			stateName = "position4Banners";
			bannerStateName = "position4";
		}
		if (name === "five") {
			stateName = "position5Banners";
			bannerStateName = "position5";
		}
		if (name === "six") {
			stateName = "position6Banners";
			bannerStateName = "position6";
		}
		if (name === "seven") {
			stateName = "position7Banners";
			bannerStateName = "position7";
		}
		if (name === "eight") {
			stateName = "position8Banners";
			bannerStateName = "position8";
		}
		if (name === "nine") {
			stateName = "position9Banners";
			bannerStateName = "position9";
		}
		if (name === "ten") {
			stateName = "position10Banners";
			bannerStateName = "position10";
		}
		if (name === "eleven") {
			stateName = "position11Banners";
			bannerStateName = "position11";
		}
		const addBannerPromise = new Promise((resolve, reject) => {
			resolve(PostApi(path, data));
		});

		addBannerPromise.then((res) => {
			if (res) {
				if (res.data.data) {
					this.setState({
						[stateName]: res.data.data,
						isLoading: false,
						[bannerStateName]: res.data.data[0].banner_name_en,
					});
				} else {
					this.setState({
						[stateName]: [],
						isLoading: false,
						[bannerStateName]: bannerStateName,
					});
				}
			}
		});
	};

	addBannerToDatabase = (data) => {
		this.setState({ isLoading: true });
		let path = API_Path.AddBanner;
		const addBannerPromise = new Promise((resolve, reject) => {
			resolve(PostApi(path, data));
		});

		addBannerPromise.then((res) => {
			if (res) {
				// console.log('res is :: ', res.data.data);
				this.getSingleBanner(data.table_name);
			}
		});
	};

	editBannerInDatabase = (data) => {
		this.setState({ isLoading: true });
		let path = API_Path.editBanner;
		const editBannerPromise = new Promise((resolve, reject) => {
			resolve(PostApi(path, data));
		});

		editBannerPromise.then((res) => {
			if (res) {
				this.getSingleBanner(data.table_name);
			}
		});
	};

	showPosition1 = () => {
		this.setState({ Position1: true });
	};

	closePosition1 = () => {
		this.setState({ Position1: false });
	};

	submitPosition1 = (value) => {
		value.master_category = this.state.masterCategory
		// console.log(value, "valueee");
		this.closePosition1();
		// let data = {
		//   banner_id: value.bannerId,
		//   banner_url: value.bannerUrl,
		//   banner_image: null,
		//   pc_english: value.pcEnglish,
		//   mobile_english: value.mobileEnglish,
		//   pc_arabic: value.pcArabic,
		//   mobile_arabic: value.mobileArabic,
		//   status: value.status == true ? "1" : "0",
		//   table_name: "one",
		//   master_category: this.state.masterCategory,
		// };
		this.addBannerToDatabase(value);
	};

	showPosition2 = () => {
		this.setState({ Position2: true });
	};

	closePosition2 = () => {
		this.setState({ Position2: false });
	};

	submitPosition2 = (value) => {
		value.master_category = this.state.masterCategory
		// console.log(value, "valueee");
		this.closePosition2();
		// let data = {
		//   banner_id: value.bannerId,
		//   banner_url: value.bannerUrl,
		//   offer_text_english: value.offerTextEnglish,
		//   offer_text_arabic: value.offerTextArabic,
		//   bg_color: value.bgColor,
		//   status: value.status == true ? "1" : "0",
		//   table_name: "two",
		//   master_category: this.state.masterCategory,
		// };
		this.addBannerToDatabase(value);
	};

	showPosition3 = () => {
		this.setState({ Position3: true });
	};

	closePosition3 = () => {
		this.setState({ Position3: false });
	};

	submitPosition3 = (value) => {
		value.master_category = this.state.masterCategory
		// console.log(value, "valueee");
		this.closePosition3();

		// let data = {
		//   banner_id: value.bannerId,
		//   banner_url: value.bannerUrl,
		//   pc_english: value.pcEnglish,
		//   mobile_english: value.mobileEnglish,
		//   pc_arabic: value.pcArabic,
		//   mobile_arabic: value.mobileArabic,
		//   status: value.status == true ? "1" : "0",
		//   table_name: "three",
		//   master_category: this.state.masterCategory,
		// };
		this.addBannerToDatabase(value);
	};

	showPosition4 = () => {
		this.setState({ Position4: true });
	};

	closePosition4 = () => {
		this.setState({ Position4: false });
	};

	submitPosition4 = (value) => {
		value.master_category = this.state.masterCategory
		// console.log(value, "valueee");
		this.closePosition4();
		// let data = {
		//   banner_id: value.bannerId,
		//   banner_url: value.bannerUrl,
		//   banner_image: value.bannerImage,
		//   banner_title_english: value.bannerNameEnglish,
		//   banner_title_arabic: value.bannerNameArabic,
		//   status: value.status == true ? "1" : "0",
		//   table_name: "four",
		//   master_category: this.state.masterCategory,
		// };
		this.addBannerToDatabase(value);
	};

	showPosition5 = () => {
		this.setState({ Position5: true });
	};

	closePosition5 = () => {
		this.setState({ Position5: false });
	};

	submitPosition5 = (value) => {
		value.master_category = this.state.masterCategory
		// console.log(value, "valueee");
		this.closePosition5();
		// let data = {
		//   banner_1_english: value.banner1English,
		//   banner_1_arabic: value.banner1Arabic,
		//   banner_url_1: value.bannerUrl1,
		//   banner_2_english: value.banner2English,
		//   banner_2_arabic: value.banner2Arabic,
		//   banner_url_2: value.bannerUrl2,
		//   banner_3_english: value.banner3English,
		//   banner_3_arabic: value.banner3Arabic,
		//   banner_url_3: value.bannerUrl3,
		//   banner_id: value.bannerId,
		//   status: value.status == true ? "1" : "0",
		//   table_name: "five",
		//   master_category: this.state.masterCategory,
		// };
		this.addBannerToDatabase(value);
	};

	showPosition6 = () => {
		this.setState({ Position6: true });
	};

	closePosition6 = () => {
		this.setState({ Position6: false });
	};

	submitPosition6 = (value) => {
		value.master_category = this.state.masterCategory
		// console.log(value, "valueee");
		this.closePosition6();
		// let data = {
		//   banner_id: value.bannerId,
		//   banner_url: value.bannerUrl,
		//   pc_english: value.pcEnglish,
		//   mobile_english: value.mobileEnglish,
		//   pc_arabic: value.pcArabic,
		//   mobile_arabic: value.mobileArabic,
		//   status: value.status == true ? "1" : "0",
		//   table_name: "six",
		//   master_category: this.state.masterCategory,
		// };
		this.addBannerToDatabase(value);
	};

	showPosition7 = () => {
		this.setState({ Position7: true });
	};

	closePosition7 = () => {
		this.setState({ Position7: false });
	};

	submitPosition7 = (value) => {
		value.master_category = this.state.masterCategory
		// console.log(value, "valueee");
		this.closePosition7();
		// let data = {
		//   banner_id: value.bannerId,
		//   banner_url: value.bannerUrl,
		//   pc_english: value.pcEnglish,
		//   mobile_english: value.mobileEnglish,
		//   pc_arabic: value.pcArabic,
		//   mobile_arabic: value.mobileArabic,
		//   status: value.status == true ? "1" : "0",
		//   table_name: "seven",
		//   master_category: this.state.masterCategory,
		// };
		this.addBannerToDatabase(value);
	};

	showPosition8 = () => {
		this.setState({ Position8: true });
	};

	closePosition8 = () => {
		this.setState({ Position8: false });
	};

	submitPosition8 = (value) => {
		value.master_category = this.state.masterCategory
		// console.log(value, "valueee");
		this.closePosition8();
		// let data = {
		//   banner_id: value.bannerId,
		//   banner_url: value.bannerUrl,
		//   pc_english: value.pcEnglish,
		//   pc_arabic: value.pcArabic,
		//   status: value.status == true ? "1" : "0",
		//   table_name: "eight",
		//   master_category: this.state.masterCategory,
		// };
		this.addBannerToDatabase(value);
	};

	showPosition9 = () => {
		this.setState({ Position9: true });
	};

	closePosition9 = () => {
		this.setState({ Position9: false });
	};

	submitPosition9 = (value) => {
		value.master_category = this.state.masterCategory
		// console.log(value, "valueee");
		this.closePosition9();
		// let data = {
		//   banner_id: value.bannerId,
		//   banner_url: value.bannerUrl,
		//   pc_english: value.pcEnglish,
		//   mobile_english: value.mobileEnglish,
		//   pc_arabic: value.pcArabic,
		//   mobile_arabic: value.mobileArabic,
		//   status: value.status == true ? "1" : "0",
		//   table_name: "nine",
		//   master_category: this.state.masterCategory,
		// };
		this.addBannerToDatabase(value);
	};

	showPosition10 = () => {
		this.setState({ Position10: true });
	};

	closePosition10 = () => {
		this.setState({ Position10: false });
	};

	submitPosition10 = (value) => {
		value.master_category = this.state.masterCategory
		// console.log(value, "valueee");
		this.closePosition10();
		// let data = {
		//   banner_id: value.bannerId,
		//   banner_url: value.bannerUrl,
		//   pc_english: value.pcEnglish,
		//   pc_arabic: value.pcArabic,
		//   status: value.status == true ? "1" : "0",
		//   table_name: "ten",
		//   master_category: this.state.masterCategory,
		// };
		this.addBannerToDatabase(value);
	};

	showPosition11 = () => {
		this.setState({ Position11: true });
	};

	closePosition11 = () => {
		this.setState({ Position11: false });
	};

	submitPosition11 = (value) => {
		value.master_category = this.state.masterCategory
		// console.log(value, "valueee");
		this.closePosition11();
		// let data = {
		//   banner_id: value.bannerId,
		//   banner_url: value.bannerUrl,
		//   pc_english: value.pcEnglish,
		//   pc_arabic: value.pcArabic,
		//   status: value.status == true ? "1" : "0",
		//   table_name: "eleven",
		//   master_category: this.state.masterCategory,
		// };
		this.addBannerToDatabase(value);
	};

	delete_Banner = (tableName, id) => {
		confirmAlert({
			customUI: ({ onClose }) => {
				return (
					<div className="custom-ui">
						<h1>Are you sure?</h1>
						<p> Do you want to delet this Banner?</p>
						<button className="btn red-btn me-2" onClick={onClose}>
							No
						</button>
						<button
							className="btn red-btn"
							onClick={() => {
								// this.finaly_delete_record(id);
								onClose();
								this.removeBanner(tableName, id);
							}}
						>
							Delete
						</button>
					</div>
				);
			},
		});
	};

	removeBanner = (tableName, id) => {
		this.setState({ isLoading: true });
		// console.log(tableName, id);
		let data = {
			table_name: tableName,
			id: id,
		};
		let path = API_Path.DeleteBanner;
		const deleteBannerPromise = new Promise((resolve, reject) => {
			resolve(PostApi(path, data));
		});
		deleteBannerPromise.then((res) => {
			if (res) {
				// console.log('res is :: ', res.data.message);
				toastr.success(res.data.message);
				this.getSingleBanner(tableName);
			}
		});
	};

	handleCheckbox = (e, name) => {
		let data = {
			table_name: name,
			active_banner_status: e.target.checked,
			master_category: this.state.masterCategory,
		};
		let path = API_Path.toggleBanner;
		const editBannerPromise = new Promise((resolve, reject) => {
			resolve(PostApi(path, data));
		});

		editBannerPromise.then((res) => {
			if (res) {
				this.getBanner();
			}
		});
	};

	getBannerById = (id, tableName) => {
		let data = {
			table_name: tableName,
			id: id,
		};
		let path = API_Path.getBannerById;
		const getBannerPromise = new Promise((resolve, reject) => {
			resolve(PostApi(path, data));
		});
		getBannerPromise.then((res) => {
			if (res) {
				// console.log('res is :: ', res.data.data[0]);
				this.setState({ editBannerData: res.data.data[0] }, () => {
					let PositionName = "";
					if (tableName === "one") {
						PositionName = "editPosition1";
					}
					if (tableName === "two") {
						PositionName = "editPosition2";
					}
					if (tableName === "three") {
						PositionName = "editPosition3";
					}
					if (tableName === "four") {
						PositionName = "editPosition4";
					}
					if (tableName === "five") {
						PositionName = "editPosition5";
					}
					if (tableName === "six") {
						PositionName = "editPosition6";
					}
					if (tableName === "seven") {
						PositionName = "editPosition7";
					}
					if (tableName === "eight") {
						PositionName = "editPosition8";
					}
					if (tableName === "nine") {
						PositionName = "editPosition9";
					}
					if (tableName === "ten") {
						PositionName = "editPosition10";
					}
					if (tableName === "eleven") {
						PositionName = "editPosition11";
					}
					// console.log('tablename');
					this.setState({ editPopupShow: true, [PositionName]: true });
				});
			}
		});
	};

	showEditPosition1 = (id, tableName) => {
		this.getBannerById(id, tableName);
	};

	closeEditPosition1 = () => {
		this.setState({ editPosition1: false, editBannerData: "", editPopupShow: false });
	};

	submitEditPosition1 = (value) => {
		let data = {
			id: this.state.editBannerData.id,
			table_name: "one",
			fields: value,
		};
		this.editBannerInDatabase(data);
		this.closeEditPosition1();
	};

	showEditPosition2 = (id, tableName) => {
		this.getBannerById(id, tableName);
	};

	closeEditPosition2 = () => {
		this.setState({ editPosition2: false, editBannerData: "" });
	};

	submitEditPosition2 = (value) => {
		let data = {
			id: this.state.editBannerData.id,
			table_name: "two",
			fields: value,
		};
		this.editBannerInDatabase(data);
		this.closeEditPosition2();
	};

	showEditPosition3 = (id, tableName) => {
		this.getBannerById(id, tableName);
	};

	closeEditPosition3 = () => {
		this.setState({ editPosition3: false, editBannerData: "" });
	};

	submitEditPosition3 = (value) => {
		let data = {
			id: this.state.editBannerData.id,
			table_name: "three",
			fields: value,
		};
		this.editBannerInDatabase(data);
		this.closeEditPosition3();
	};

	showEditPosition4 = (id, tableName) => {
		this.getBannerById(id, tableName);
	};

	closeEditPosition4 = () => {
		this.setState({ editPosition4: false, editBannerData: "" });
	};

	submitEditPosition4 = (value) => {
		let data = {
			id: this.state.editBannerData.id,
			table_name: "four",
			fields: value
		};
		this.editBannerInDatabase(data);
		this.closeEditPosition4();
	};

	showEditPosition5 = (id, tableName) => {
		this.getBannerById(id, tableName);
	};

	closeEditPosition5 = () => {
		this.setState({ editPosition5: false, editBannerData: "" });
	};

	submitEditPosition5 = (value) => {
		let data = {
			id: this.state.editBannerData.id,
			table_name: "five",
			fields: value,
		};
		this.editBannerInDatabase(data);
		this.closeEditPosition5();
	};

	showEditPosition6 = (id, tableName) => {
		this.getBannerById(id, tableName);
	};

	closeEditPosition6 = () => {
		this.setState({ editPosition6: false, editBannerData: "" });
	};

	submitEditPosition6 = (value) => {
		let data = {
			id: this.state.editBannerData.id,
			table_name: "six",
			fields: value,
		};
		this.editBannerInDatabase(data);
		this.closeEditPosition6();
	};

	showEditPosition7 = (id, tableName) => {
		this.getBannerById(id, tableName);
	};

	closeEditPosition7 = () => {
		this.setState({ editPosition7: false, editBannerData: "" });
	};

	submitEditPosition7 = (value) => {
		let data = {
			id: this.state.editBannerData.id,
			table_name: "seven",
			fields: value,
		};
		this.editBannerInDatabase(data);
		this.closeEditPosition7();
	};

	showEditPosition8 = (id, tableName) => {
		this.getBannerById(id, tableName);
	};

	closeEditPosition8 = () => {
		this.setState({ editPosition8: false, editBannerData: "" });
	};

	submitEditPosition8 = (value) => {
		let data = {
			id: this.state.editBannerData.id,
			table_name: "eight",
			fields: value,
		};
		this.editBannerInDatabase(data);
		this.closeEditPosition8();
	};

	showEditPosition9 = (id, tableName) => {
		this.getBannerById(id, tableName);
	};

	closeEditPosition9 = () => {
		this.setState({ editPosition9: false, editBannerData: "" });
	};

	submitEditPosition9 = (value) => {
		let data = {
			id: this.state.editBannerData.id,
			table_name: "nine",
			fields: value,
		};
		this.editBannerInDatabase(data);
		this.closeEditPosition9();
	};

	showEditPosition10 = (id, tableName) => {
		this.getBannerById(id, tableName);
	};

	closeEditPosition10 = () => {
		this.setState({ editPosition10: false, editBannerData: "" });
	};

	submitEditPosition10 = (value) => {
		let data = {
			id: this.state.editBannerData.id,
			table_name: "ten",
			fields: value,
		};
		this.editBannerInDatabase(data);
		this.closeEditPosition10();
	};

	showEditPosition11 = (id, tableName) => {
		this.getBannerById(id, tableName);
	};

	closeEditPosition11 = () => {
		this.setState({ editPosition11: false, editBannerData: "" });
	};

	submitEditPosition11 = (value) => {
		let data = {
			id: this.state.editBannerData.id,
			table_name: "eleven",
			fields: value,
		};
		this.editBannerInDatabase(data);
		this.closeEditPosition11();
	};

	editBannerShow = (name, tableName) => {
		this.setState({ bannerNameEdit: true, EditStateName: name }, () => {
			this.getBannerName(tableName)
		});
	};

	editBannerClose = () => {
		this.setState({ bannerNameEdit: false });
	};

	submitEditBannerName = () => {
		// this.setState({ [this.state.EditStateName]: this.state.EditBannerName })
		this.editBannerClose();
		let tableName = "";
		if (this.state.EditStateName === "position1") {
			tableName = "one";
		} else if (this.state.EditStateName === "position2") {
			tableName = "two";
		} else if (this.state.EditStateName === "position3") {
			tableName = "three";
		} else if (this.state.EditStateName === "position4") {
			tableName = "four";
		} else if (this.state.EditStateName === "position5") {
			tableName = "five";
		} else if (this.state.EditStateName === "position6") {
			tableName = "six";
		} else if (this.state.EditStateName === "position7") {
			tableName = "seven";
		} else if (this.state.EditStateName === "position8") {
			tableName = "eight";
		} else if (this.state.EditStateName === "position9") {
			tableName = "nine";
		} else if (this.state.EditStateName === "position10") {
			tableName = "ten";
		} else if (this.state.EditStateName === "position11") {
			tableName = "eleven";
		}
		let data = {
			table_name: tableName,
			banner_name_english: this.state.editBannerNameEnglish,
			banner_name_arabic: this.state.editBannerNameArabic,
			master_category: this.state.masterCategory,
		};
		let path = API_Path.addBannerName;
		const addBannerNamePromise = new Promise((resolve, reject) => {
			resolve(PostApi(path, data));
		});
		addBannerNamePromise.then((res) => {
			if (res) {
				// console.log('res is :: ', res.data.message);
				this.setState({ editBannerNameArabic: "", editBannerNameEnglish: "" });
				toastr.success(res.data.message);
				this.getSingleBanner(tableName);
			}
		});
	};

	handleChange = (e) => {
		this.setState({ [e.target.name]: e.target.value });
	};

	singleBannderStatusChange = (e, id, name) => {
		// console.log('e :: ', e.target.checked);
		this.setState({ isLoading: true });
		let data = {
			id: id,
			table_name: name,
			fields: {
				status: e.target.checked == true ? "1" : "0",
			},
		};
		let path = API_Path.editBanner;
		const editBannerPromise = new Promise((resolve, reject) => {
			resolve(PostApi(path, data));
		});

		editBannerPromise.then((res) => {
			if (res) {
				this.getSingleBanner(data.table_name);
			}
		});
	};
	getAllProductTag = () => {
		const data = {};
		const getAllTagsPromise = new Promise((resolve, reject) => {
			resolve(PostApi(API_Path.getAllTags, data));
		});
		getAllTagsPromise.then((response) => {
			if (response) {
				if (response.data.success) {
					let res = []
					for (let i = 0; i < response.data.data.length; i++) {
						let obj = {
							id: i,
							tag: response.data.data[i]
						}
						res.push(obj)
					}

					console.log(res, "res==");
					this.setState({ ActionTagArr: response.data.data });
				} else {
					toastr.error(response.data.message);
				}
			}
		});
	}
	selectAccordian = () => {
		let path = API_Path.GetBanner;
		let reqData = {
			table_name: 'six_new',
			master_category: this.state.masterCategory,
		}
		new Promise((resolve) => {
			resolve(PostApi(path, reqData))
		}).then((res) => {
			let resArr = JSON.parse(res.data.data[0].tags)
			if (resArr && resArr.length > 0) {
				const newArray = resArr.map((tag, index) => {
					return {
						tag: tag,
						id: index
					};
				});
				console.log(res.data.data[0].specificData)
				this.setState({ selectedTags: newArray, TagCatagoryType: res.data.data[0].specificData, Newposition6ActiveStatus: true })
			} else {
				this.setState({ selectedTags: [], Newposition6ActiveStatus: false })
			}
			this.getAllProductTag()
		})
	}
	handleTagChange = (e) => {
		let filteredArr = this.state.selectedTags.find(obj => obj.tag == e.target.value)
		if (!filteredArr) {
			let obj = {
				tag: e.target.value,
				id: this.state.selectedTags.length
			}
			let dataArr = [...this.state.selectedTags, obj]
			this.setState({ selectedTags: dataArr, Newposition6ActiveStatus: true }, () => {
				let reqArr = this.state.selectedTags.map(item => item.tag)
				this.submitTag(reqArr)
			})
		} else {
			toastr.error('the Tag is Already added')
		}
	}
	removeTag = (id) => {
		let updateArr = this.state.selectedTags.filter(obj => obj.id != id)
		console.log(updateArr, "updateArr--");
		this.setState({ selectedTags: updateArr }, () => {
			let reqArr = this.state.selectedTags.map(item => item.tag)
			this.submitTag(reqArr)
			console.log(reqArr, "reqArr");
		})
	}
	submitTag = (arr) => {
		let reqData = {
			id: this.state.selectedMainCatagory.id,
			fields: {
				tags: JSON.stringify(arr),
				specificData: this.state.TagCatagoryType
			},
			table_name: 'six_new'
		}
		let Path = API_Path.editBanner
		new Promise((resolve) => {
			resolve(PostApi(Path, reqData))
		}).then((res) => {
			toastr.success(res.data.message)
		})
	}
	Tagsatus = (e) => {
		let reqArr = this.state.selectedTags.map(item => item.tag)
		if (e.target.checked) {
			this.submitTag(reqArr)
		} else {
			this.submitTag([])
		}
	}

	onCatagoryTypeChange = (e) => {
		this.setState({ TagCatagoryType: e.target.value }, () => {
			let reqArr = this.state.selectedTags.map(item => item.tag)
			this.submitTag(reqArr)
		})
	}

	render() {
		let Language =
			this.context.language === "english"
				? TableFieldEnglish
				: TableFieldArabic;
		let buttonLanguage =
			this.context.language === "english" ? buttonEnglish : buttonArabic;
		let titleLanguage =
			this.context.language === "english" ? titleEnglish : titleArabic;
		let masterLanguage =
			this.context.language === "english" ? masterEnglish : masterArabic;
		return (
			<>
				{this.state.isLoading ? (
					<div className="loader-main">
						<div className="loader-inr">
							<svg
								xmlns="http://www.w3.org/2000/svg"
								xlink="http://www.w3.org/1999/xlink"
								style={{ margin: "auto", display: "block" }}
								width="200px"
								height="200px"
								viewBox="0 0 100 100"
								preserveAspectRatio="xMidYMid"
							>
								<defs>
									<clipPath
										id="ldio-jq5jcmra7v9-cp"
										x="0"
										y="0"
										width="100"
										height="100"
									>
										<rect x="0" y="5" width="100" height="46"></rect>
									</clipPath>
								</defs>
								<path
									d="M70 75.2H34.1l-4.1-18.4l-0.7-3l-1-4.7c0 0 0 0 0-0.1c0-0.1 0-0.1-0.1-0.2c0 0 0-0.1-0.1-0.1c0 0 0-0.1-0.1-0.1 c0 0-0.1-0.1-0.1-0.1c0 0-0.1-0.1-0.1-0.1c0 0-0.1-0.1-0.1-0.1c0 0 0 0-0.1-0.1L22.3 44c0-0.1 0-0.2 0-0.3c0-1.9-1.6-3.5-3.5-3.5 s-3.5 1.6-3.5 3.5c0 1.9 1.6 3.5 3.5 3.5c0.7 0 1.4-0.2 2-0.6l4.8 3.7L31.5 77c0 0 0 0 0 0l-5.6 7.7c-0.3 0.5-0.4 1.1-0.1 1.6 c0.3 0.5 0.8 0.8 1.3 0.8h4c-0.8 0.8-1.3 1.9-1.3 3.2c0 2.6 2.1 4.7 4.7 4.7c2.6 0 4.7-2.1 4.7-4.7c0-1.2-0.5-2.3-1.3-3.2h29 c-0.8 0.8-1.3 1.9-1.3 3.2c0 2.6 2.1 4.7 4.7 4.7c2.6 0 4.7-2.1 4.7-4.7c0-1.2-0.5-2.3-1.3-3.2H77c0.8 0 1.5-0.7 1.5-1.5 s-0.7-1.5-1.5-1.5H30l4.3-6h36.8c0.7 0 1.3-0.5 1.4-1.1l7.5-27.3c0.2-0.8-0.2-1.6-1-1.8c-0.8-0.2-1.6 0.2-1.8 1l-1.3 4.7l-0.8 3"
									fill="#dddddd"
								></path>
								<polygon
									points="31.3 53.1 35.7 73.2 68.5 73.2 74 53.1"
									fill="#dddddd"
								></polygon>
								<g clip-path="url(#ldio-jq5jcmra7v9-cp)">
									<g>
										<g transform="translate(50 41)">
											<path
												d="M6.5-6.7C6.1-6.9 5.7-7.2 5.3-7.4C5-7.5 4.6-7.7 4.3-7.8C3.1-2.2-4-3.7-2.9-9.3c-0.4 0-0.7 0-1.1 0 c-0.5 0-1 0.1-1.4 0.2c-1.8 0.3-3.6 0.9-5.3 1.8l1.1 4.2l3.1-0.8L-8.7 6.9L3.2 9.3L5.4-1.5l2.5 2l2.7-3.4C9.5-4.4 8.1-5.7 6.5-6.7z"
												fill="#e15b64"
											>
												<animateTransform
													attributeName="transform"
													type="rotate"
													keyTimes="0;1"
													values="0;360"
													dur="0.7462686567164178s"
													repeatCount="indefinite"
												></animateTransform>
											</path>
										</g>
										<animateTransform
											attributeName="transform"
											type="translate"
											keyTimes="0;1"
											values="0 0;0 75"
											dur="1.4925373134328357s"
											repeatCount="indefinite"
										></animateTransform>
									</g>
									<g>
										<g transform="translate(35 17)">
											<path
												d="M3.4-5.3L2.5-5l0.8-2.3L1.1-6.3l-1.2-2.2l-1.6 4.6l-4.6-1.6l0.9 2.3l-2.2 1.2l2.3 0.8L-6-0.9 c-0.6 0.3-0.8 0.9-0.5 1.5l1 2.1C-5.2 3.4-4.6 3.6-4 3.3l0.1-0.1l2.1 4.5C-1.4 8.4-0.7 8.7 0 8.3l1.7-0.8l1.7-0.8L5 5.9l1.7-0.8 C7.4 4.8 7.7 4 7.4 3.3L5.2-1.1l0.1-0.1c0.6-0.3 0.8-0.9 0.5-1.5l-1-2.1C4.6-5.4 3.9-5.6 3.4-5.3z"
												fill="#f47e60"
											>
												<animateTransform
													attributeName="transform"
													type="rotate"
													keyTimes="0;1"
													values="0;360"
													dur="0.7462686567164178s"
													repeatCount="indefinite"
												></animateTransform>
											</path>
										</g>
										<animateTransform
											attributeName="transform"
											type="translate"
											keyTimes="0;1"
											values="0 0;0 75"
											dur="1.4925373134328357s"
											repeatCount="indefinite"
										></animateTransform>
									</g>
									<g>
										<g transform="translate(66 26)">
											<path
												d="M-4.5-3.7L1.9-6l0.5-0.2L2-7.2l-6.9 2.5C-5.7-4.4-6.1-3.5-6-2.7c0 0.1 0 0.2 0.1 0.3l3 8.2 C-2.5 6.9-1.3 7.4-0.2 7l5.6-2C5.9 4.8 6.2 4.2 6 3.7L3.2-3.9l-0.4-1L2.4-4.7L1.9-4.5l-3.2 1.2l-2.7 1c-0.3 0.1-0.6 0-0.8-0.2 c-0.1-0.1-0.1-0.1-0.1-0.2C-5.1-3.1-4.9-3.6-4.5-3.7z"
												fill="#f8b26a"
											>
												<animateTransform
													attributeName="transform"
													type="rotate"
													keyTimes="0;1"
													values="0;360"
													dur="0.7462686567164178s"
													repeatCount="indefinite"
												></animateTransform>
											</path>
										</g>
										<animateTransform
											attributeName="transform"
											type="translate"
											keyTimes="0;1"
											values="0 0;0 75"
											dur="1.4925373134328357s"
											repeatCount="indefinite"
										></animateTransform>
									</g>
									<g>
										<g transform="translate(55 6)">
											<polygon
												points="0 -4.9 1.6 -1.7 5.1 -1.1 2.6 1.3 3.2 4.9 0 3.2 -3.2 4.9 -2.6 1.3 -5.1 -1.1 -1.6 -1.7"
												fill="#abbd81"
											>
												<animateTransform
													attributeName="transform"
													type="rotate"
													keyTimes="0;1"
													values="0;360"
													dur="0.7462686567164178s"
													repeatCount="indefinite"
												></animateTransform>
											</polygon>
										</g>
										<animateTransform
											attributeName="transform"
											type="translate"
											keyTimes="0;1"
											values="0 0;0 75"
											dur="1.4925373134328357s"
											repeatCount="indefinite"
										></animateTransform>
									</g>
								</g>
								<g clip-path="url(#ldio-jq5jcmra7v9-cp)">
									<g transform="translate(0 -75)">
										<g>
											<g transform="translate(50 41)">
												<path
													d="M6.5-6.7C6.1-6.9 5.7-7.2 5.3-7.4C5-7.5 4.6-7.7 4.3-7.8C3.1-2.2-4-3.7-2.9-9.3c-0.4 0-0.7 0-1.1 0 c-0.5 0-1 0.1-1.4 0.2c-1.8 0.3-3.6 0.9-5.3 1.8l1.1 4.2l3.1-0.8L-8.7 6.9L3.2 9.3L5.4-1.5l2.5 2l2.7-3.4C9.5-4.4 8.1-5.7 6.5-6.7z"
													fill="#e15b64"
												>
													<animateTransform
														attributeName="transform"
														type="rotate"
														keyTimes="0;1"
														values="0;360"
														dur="0.7462686567164178s"
														repeatCount="indefinite"
													></animateTransform>
												</path>
											</g>
											<animateTransform
												attributeName="transform"
												type="translate"
												keyTimes="0;1"
												values="0 0;0 75"
												dur="1.4925373134328357s"
												repeatCount="indefinite"
											></animateTransform>
										</g>
										<g>
											<g transform="translate(35 17)">
												<path
													d="M3.4-5.3L2.5-5l0.8-2.3L1.1-6.3l-1.2-2.2l-1.6 4.6l-4.6-1.6l0.9 2.3l-2.2 1.2l2.3 0.8L-6-0.9 c-0.6 0.3-0.8 0.9-0.5 1.5l1 2.1C-5.2 3.4-4.6 3.6-4 3.3l0.1-0.1l2.1 4.5C-1.4 8.4-0.7 8.7 0 8.3l1.7-0.8l1.7-0.8L5 5.9l1.7-0.8 C7.4 4.8 7.7 4 7.4 3.3L5.2-1.1l0.1-0.1c0.6-0.3 0.8-0.9 0.5-1.5l-1-2.1C4.6-5.4 3.9-5.6 3.4-5.3z"
													fill="#f47e60"
												>
													<animateTransform
														attributeName="transform"
														type="rotate"
														keyTimes="0;1"
														values="0;360"
														dur="0.7462686567164178s"
														repeatCount="indefinite"
													></animateTransform>
												</path>
											</g>
											<animateTransform
												attributeName="transform"
												type="translate"
												keyTimes="0;1"
												values="0 0;0 75"
												dur="1.4925373134328357s"
												repeatCount="indefinite"
											></animateTransform>
										</g>
										<g>
											<g transform="translate(66 26)">
												<path
													d="M-4.5-3.7L1.9-6l0.5-0.2L2-7.2l-6.9 2.5C-5.7-4.4-6.1-3.5-6-2.7c0 0.1 0 0.2 0.1 0.3l3 8.2 C-2.5 6.9-1.3 7.4-0.2 7l5.6-2C5.9 4.8 6.2 4.2 6 3.7L3.2-3.9l-0.4-1L2.4-4.7L1.9-4.5l-3.2 1.2l-2.7 1c-0.3 0.1-0.6 0-0.8-0.2 c-0.1-0.1-0.1-0.1-0.1-0.2C-5.1-3.1-4.9-3.6-4.5-3.7z"
													fill="#f8b26a"
												>
													<animateTransform
														attributeName="transform"
														type="rotate"
														keyTimes="0;1"
														values="0;360"
														dur="0.7462686567164178s"
														repeatCount="indefinite"
													></animateTransform>
												</path>
											</g>
											<animateTransform
												attributeName="transform"
												type="translate"
												keyTimes="0;1"
												values="0 0;0 75"
												dur="1.4925373134328357s"
												repeatCount="indefinite"
											></animateTransform>
										</g>
										<g>
											<g transform="translate(55 6)">
												<polygon
													points="0 -4.9 1.6 -1.7 5.1 -1.1 2.6 1.3 3.2 4.9 0 3.2 -3.2 4.9 -2.6 1.3 -5.1 -1.1 -1.6 -1.7"
													fill="#abbd81"
												>
													<animateTransform
														attributeName="transform"
														type="rotate"
														keyTimes="0;1"
														values="0;360"
														dur="0.7462686567164178s"
														repeatCount="indefinite"
													></animateTransform>
												</polygon>
											</g>
											<animateTransform
												attributeName="transform"
												type="translate"
												keyTimes="0;1"
												values="0 0;0 75"
												dur="1.4925373134328357s"
												repeatCount="indefinite"
											></animateTransform>
										</g>
									</g>
								</g>
							</svg>
						</div>
					</div>
				) :
					<Adminlayout>
						<div className="container-fluid">
							<div className="row common-space align-items-center">
								<div className="col-6  text-start rtl-txt-start">
									<div className="common-header-txt">
										<h3>{titleLanguage.master}</h3>
									</div>
								</div>
							</div>
							<div className="row common-space align-items-center">
								<div className="col-12  text-start rtl-txt-start">
									<div className="common-header-txt">
										<div className="master-btn-group text-center">
											<div
												className="btn-group justify-content-center"
												role="group"
												aria-label="Basic radio toggle button group"
												onChange={this.handleChangeForRadio}
											>
												<input
													type="radio"
													className="btn-check"
													name="btnradio"
													id="women"
													autoComplete="off"
													defaultChecked={this.state.masterCategory == 'women'}
												/>
												<label className="btn" htmlFor="women">
													{masterLanguage.womens}
												</label>
												<input
													type="radio"
													className="btn-check"
													name="btnradio"
													id="men"
													autoComplete="off"
													defaultChecked={this.state.masterCategory == 'men'}
												/>
												<label className="btn" htmlFor="men">
													{masterLanguage.men}
												</label>

												<input
													type="radio"
													className="btn-check"
													name="btnradio"
													id="kids"
													autoComplete="off"
													defaultChecked={this.state.masterCategory == 'kids'}
												/>
												<label className="btn" htmlFor="kids">
													{masterLanguage.kids}
												</label>
												<input
													type="radio"
													className="btn-check"
													name="btnradio"
													id="home"
													autoComplete="off"
													defaultChecked={this.state.masterCategory == 'home'}
												/>
												<label className="btn" htmlFor="home">
													{masterLanguage.home}
												</label>
											</div>
										</div>
									</div>
								</div>
							</div>

							<div className="row common-space">
								<div className="col-md-12">
									<div className="white-box">
										<div className="cust-master accordian">
											<Accordion defaultActiveKey="0">
												<Accordion.Item eventKey="0">
													<Accordion.Header>
														{this.state.position1}
														<span>{masterLanguage.maximumBannerActive}</span>
														<Dropdown className="cust-drop text-end ms-auto">
															<Dropdown.Toggle
																className="bg-transparent "
																id="dropdown-basic"
																align="end"
															>
																<svg
																	xmlns="http://www.w3.org/2000/svg"
																	width={16}
																	height={16}
																	fill="currentColor"
																	className="bi bi-three-dots-vertical"
																	viewBox="0 0 16 16"
																>
																	<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																</svg>
															</Dropdown.Toggle>
															<Dropdown.Menu>
																<div className="d-flex align-items-center cust-switch-drop">
																	<span className="m-0">
																		{masterLanguage.active}
																	</span>
																	<label className="switch ms-auto">
																		<input
																			type="checkbox"
																			defaultChecked={
																				this.state.position1ActiveStatus
																			}
																			onChange={(e) =>
																				this.handleCheckbox(e, "one")
																			}
																		/>
																		<div className="slider round" />
																	</label>
																</div>
																<Dropdown.Item
																	onClick={() => this.editBannerShow("position1", 'one')}
																	className="d-flex align-items-center"
																>
																	<span className="m-0">
																		{buttonLanguage.edit}
																	</span>
																	<svg
																		className="ms-auto"
																		width={19}
																		height={18}
																		viewBox="0 0 19 19"
																		fill="none"
																		xmlns="http://www.w3.org/2000/svg"
																	>
																		<path
																			d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																			fill="#2D2D3B"
																		/>
																	</svg>
																</Dropdown.Item>
															</Dropdown.Menu>
														</Dropdown>
													</Accordion.Header>
													<Accordion.Body>
														<div className="row">
															{this.state.position1Banners &&
																this.state.position1Banners.length > 0 && (
																	<DragDropContext
																		onDragEnd={this.onPosition1DragEnd}
																	>
																		<Droppable
																			droppableId="droppable"
																			direction="horizontal"
																		>
																			{(provided, snapshot) => (
																				<div
																					className="drag-main-div col-md-9 d-flex mb-3"
																					ref={provided.innerRef}
																					style={getListStyle(
																						snapshot.isDraggingOver,
																						this.state.position1Banners.length
																					)}
																					{...provided.droppableProps}
																				>
																					{this.state.position1Banners.map(
																						(item, index) => (
																							<Draggable
																								key={item.banner_id}
																								draggableId={item.banner_id}
																								index={index}
																							>
																								{(provided, snapshot) => (
																									<div
																										className="drag-item-width"
																										ref={provided.innerRef}
																										{...provided.draggableProps}
																										{...provided.dragHandleProps}
																										style={getItemStyle(
																											snapshot.isDragging,
																											provided.draggableProps
																												.style
																										)}
																									>
																										<div
																											className="iner-width-banner-drag pos-1-img"
																											key={index}
																										>
																											<div className="banner-main-box-ad position-relative">
																												<div className="drop-btn-banner">
																													<Dropdown className="cust-drop text-end">
																														<Dropdown.Toggle
																															className="bg-transparent "
																															id="dropdown-basic"
																															align="end"
																														>
																															<svg
																																xmlns="http://www.w3.org/2000/svg"
																																width={16}
																																height={16}
																																fill="currentColor"
																																className="bi bi-three-dots-vertical"
																																viewBox="0 0 16 16"
																															>
																																<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																															</svg>
																														</Dropdown.Toggle>
																														<Dropdown.Menu>
																															<div className="d-flex align-items-center cust-switch-drop">
																																<span className="m-0">
																																	{
																																		masterLanguage.active
																																	}
																																</span>
																																<label className="switch ms-auto">
																																	<input
																																		type="checkbox"
																																		defaultChecked={
																																			item.status
																																		}
																																		onChange={(
																																			e
																																		) =>
																																			this.singleBannderStatusChange(
																																				e,
																																				item.id,
																																				"one"
																																			)
																																		}
																																	/>
																																	<div className="slider round" />
																																</label>
																															</div>
																															<Dropdown.Item
																																onClick={() => {
																																	this.showEditPosition1(
																																		item.id,
																																		"one"
																																	);
																																}}
																																className="d-flex align-items-center"
																															>
																																<span className="m-0">
																																	{
																																		buttonLanguage.edit
																																	}
																																</span>
																																<svg
																																	className="ms-auto"
																																	width={19}
																																	height={18}
																																	viewBox="0 0 19 19"
																																	fill="none"
																																	xmlns="http://www.w3.org/2000/svg"
																																>
																																	<path
																																		d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																																		fill="#2D2D3B"
																																	/>
																																</svg>
																															</Dropdown.Item>
																															<Dropdown.Item
																																onClick={() => {
																																	this.delete_Banner(
																																		"one",
																																		item.id
																																	);
																																}}
																																className="d-flex align-items-center"
																															>
																																<span className="m-0">
																																	{buttonLanguage.delete}
																																</span>
																																<svg
																																	className="ms-auto"
																																	width={18}
																																	height={20}
																																	viewBox="0 0 18 20"
																																	fill="none"
																																	xmlns="http://www.w3.org/2000/svg"
																																>
																																	<path
																																		d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
																																		fill="#2D2D3B"
																																	/>
																																</svg>
																															</Dropdown.Item>
																														</Dropdown.Menu>
																													</Dropdown>
																												</div>
																												<div className="banner-imag-main-div">
																													<img
																														src={
																															item.pc_english
																														}
																														alt=""
																														className="img-fluid w-100"
																													/>
																												</div>
																											</div>
																										</div>
																									</div>
																								)}
																							</Draggable>
																						)
																					)}
																					{provided.placeholder}
																				</div>
																			)}
																		</Droppable>
																	</DragDropContext>
																)}

															{this.state.position1Banners &&
																this.state.position1Banners.length < 10 && (
																	<div className="col-md-3 mb-3">
																		<div className="banner-main-box-ad">
																			<button
																				className="btn"
																				onClick={this.showPosition1}
																			>
																				<img src={plus} className="mb-3" />
																				<span>{masterLanguage.AddNewBanner}</span>
																			</button>
																		</div>
																	</div>
																)}
														</div>
													</Accordion.Body>
												</Accordion.Item>
												<Accordion.Item eventKey="1">
													<Accordion.Header>
														{this.state.position2}
														<span>(Unlimitated banners Active)</span>
														<Dropdown className="cust-drop text-end ms-auto">
															<Dropdown.Toggle
																className="bg-transparent "
																id="dropdown-basic"
																align="end"
															>
																<svg
																	xmlns="http://www.w3.org/2000/svg"
																	width={16}
																	height={16}
																	fill="currentColor"
																	className="bi bi-three-dots-vertical"
																	viewBox="0 0 16 16"
																>
																	<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																</svg>
															</Dropdown.Toggle>
															<Dropdown.Menu>
																<div className="d-flex align-items-center cust-switch-drop">
																	<span className="m-0">
																		{masterLanguage.active}
																	</span>
																	<label className="switch ms-auto">
																		<input
																			type="checkbox"
																			defaultChecked={
																				this.state.position2ActiveStatus
																			}
																			onChange={(e) =>
																				this.handleCheckbox(e, "two")
																			}
																		/>
																		<div className="slider round" />
																	</label>
																</div>
																<Dropdown.Item
																	onClick={() => this.editBannerShow("position2", 'two')}
																	className="d-flex align-items-center"
																>
																	<span className="m-0">
																		{buttonLanguage.edit}
																	</span>
																	<svg
																		className="ms-auto"
																		width={19}
																		height={18}
																		viewBox="0 0 19 19"
																		fill="none"
																		xmlns="http://www.w3.org/2000/svg"
																	>
																		<path
																			d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																			fill="#2D2D3B"
																		/>
																	</svg>
																</Dropdown.Item>
															</Dropdown.Menu>
														</Dropdown>
													</Accordion.Header>
													<Accordion.Body>
														<div className="row">
															<div className="col-md-12">
																<ul>
																	{this.state.position2Banners &&
																		this.state.position2Banners.length > 0 && (
																			<DragDropContext
																				onDragEnd={this.onPosition2DragEnd}
																			>
																				<Droppable
																					droppableId="droppable"
																					direction="vertical"
																				>
																					{(provided, snapshot) => (
																						<div
																							className="d-block fix-height-scroll-pos-2"
																							ref={provided.innerRef}
																							style={getListStyle(
																								snapshot.isDraggingOver,
																								this.state.position2Banners.length
																							)}
																							{...provided.droppableProps}
																						>
																							{this.state.position2Banners.map(
																								(item, index) => (
																									<Draggable
																										key={item.id.toString()}
																										draggableId={item.id.toString()}
																										index={index}
																									>
																										{(provided, snapshot) => (
																											<div
																												ref={provided.innerRef}
																												{...provided.draggableProps}
																												{...provided.dragHandleProps}
																												style={getItemStyle(
																													snapshot.isDragging,
																													provided.draggableProps
																														.style
																												)}
																											>
																												<li
																													style={{
																														backgroundColor:
																															item.bg_color,
																														padding: "5px 0",
																														marginBottom: "5px",
																													}}
																												>
																													<div
																														className="d-flex align-items-center"
																														style={{
																															color: "#fff",
																														}}
																													>
																														<span className="ms-auto">
																															{
																																item.offer_text_english
																															}
																														</span>
																														<div className="ms-auto d-flex align-items-center">
																															<i className="me-2 bi bi-chevron-expand" />

																															<Dropdown className="cust-drop text-end">
																																<Dropdown.Toggle
																																	className="bg-transparent p-0 "
																																	id="dropdown-basic"
																																	align="end"
																																>
																																	<svg
																																		xmlns="http://www.w3.org/2000/svg"
																																		width={16}
																																		height={16}
																																		fill="currentColor"
																																		className="bi bi-three-dots-vertical"
																																		viewBox="0 0 16 16"
																																	>
																																		<path
																																			d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"
																																			fill="#fff"
																																		/>
																																	</svg>
																																</Dropdown.Toggle>
																																<Dropdown.Menu>
																																	<div className="d-flex align-items-center cust-switch-drop">
																																		<span className="m-0">
																																			{
																																				masterLanguage.active
																																			}
																																		</span>
																																		<label className="switch ms-auto">
																																			<input
																																				type="checkbox"
																																				defaultChecked={
																																					item.status
																																				}
																																				onChange={(
																																					e
																																				) =>
																																					this.singleBannderStatusChange(
																																						e,
																																						item.id,
																																						"two"
																																					)
																																				}
																																			/>
																																			<div className="slider round" />
																																		</label>
																																	</div>
																																	<Dropdown.Item
																																		onClick={() => {
																																			this.showEditPosition1(
																																				item.id,
																																				"two"
																																			);
																																		}}
																																		className="d-flex align-items-center"
																																	>
																																		<span className="m-0">
																																			edit
																																		</span>
																																		<svg
																																			className="ms-auto"
																																			width={19}
																																			height={18}
																																			viewBox="0 0 19 19"
																																			fill="none"
																																			xmlns="http://www.w3.org/2000/svg"
																																		>
																																			<path
																																				d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																																				fill="#2D2D3B"
																																			/>
																																		</svg>
																																	</Dropdown.Item>
																																	<Dropdown.Item
																																		onClick={() => {
																																			this.delete_Banner(
																																				"two",
																																				item.id
																																			);
																																		}}
																																		className="d-flex align-items-center"
																																	>
																																		<span className="m-0">
																																			{buttonLanguage.delete}
																																		</span>
																																		<svg
																																			className="ms-auto"
																																			width={18}
																																			height={20}
																																			viewBox="0 0 18 20"
																																			fill="none"
																																			xmlns="http://www.w3.org/2000/svg"
																																		>
																																			<path
																																				d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
																																				fill="#2D2D3B"
																																			/>
																																		</svg>
																																	</Dropdown.Item>
																																</Dropdown.Menu>
																															</Dropdown>
																														</div>
																													</div>
																												</li>
																											</div>
																										)}
																									</Draggable>
																								)
																							)}
																							{provided.placeholder}
																						</div>
																					)}
																				</Droppable>
																			</DragDropContext>
																		)}

																	<li style={{ marginBottom: "5px" }}>
																		<button
																			className="btn w-100 rounded-0"
																			onClick={this.showPosition2}
																		>
																			<i className="bi bi-plus-circle fw-bold me-2 text-black" />
																			Add New Offer
																		</button>
																	</li>
																</ul>
															</div>
														</div>
													</Accordion.Body>
												</Accordion.Item>
												<Accordion.Item eventKey="2">
													<Accordion.Header>
														{this.state.position3}
														<span>(Maximum 1 banner Active)</span>
														<Dropdown className="cust-drop text-end ms-auto">
															<Dropdown.Toggle
																className="bg-transparent "
																id="dropdown-basic"
																align="end"
															>
																<svg
																	xmlns="http://www.w3.org/2000/svg"
																	width={16}
																	height={16}
																	fill="currentColor"
																	className="bi bi-three-dots-vertical"
																	viewBox="0 0 16 16"
																>
																	<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																</svg>
															</Dropdown.Toggle>
															<Dropdown.Menu>
																<div className="d-flex align-items-center cust-switch-drop">
																	<span className="m-0">
																		{masterLanguage.active}
																	</span>
																	<label className="switch ms-auto">
																		<input
																			type="checkbox"
																			defaultChecked={
																				this.state.position3ActiveStatus
																			}
																			onChange={(e) =>
																				this.handleCheckbox(e, "three")
																			}
																		/>
																		<div className="slider round" />
																	</label>
																</div>
																<Dropdown.Item
																	onClick={() => this.editBannerShow("position3", 'three')}
																	className="d-flex align-items-center"
																>
																	<span className="m-0">
																		{buttonLanguage.edit}
																	</span>
																	<svg
																		className="ms-auto"
																		width={19}
																		height={18}
																		viewBox="0 0 19 19"
																		fill="none"
																		xmlns="http://www.w3.org/2000/svg"
																	>
																		<path
																			d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																			fill="#2D2D3B"
																		/>
																	</svg>
																</Dropdown.Item>
															</Dropdown.Menu>
														</Dropdown>
													</Accordion.Header>
													<Accordion.Body>
														<div className="row">
															{this.state.position3Banners &&
																this.state.position3Banners.length > 0 ? (
																<div className="col-md-5 mb-3">
																	<div className="banner-main-box-ad position-relative">
																		<div className="drop-btn-banner">
																			<Dropdown className="cust-drop text-end">
																				<Dropdown.Toggle
																					className="bg-transparent "
																					id="dropdown-basic"
																					align="end"
																				>
																					<svg
																						xmlns="http://www.w3.org/2000/svg"
																						width={16}
																						height={16}
																						fill="currentColor"
																						className="bi bi-three-dots-vertical"
																						viewBox="0 0 16 16"
																					>
																						<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																					</svg>
																				</Dropdown.Toggle>
																				<Dropdown.Menu>
																					<div className="d-flex align-items-center cust-switch-drop">
																						<span className="m-0">
																							{masterLanguage.active}
																						</span>
																						<label className="switch ms-auto">
																							<input
																								type="checkbox"
																								defaultChecked={
																									this.state.position3Banners[0]
																										.status
																								}
																								onChange={(e) =>
																									this.singleBannderStatusChange(
																										e,
																										this.state.position3Banners[0]
																											.id,
																										"three"
																									)
																								}
																							/>
																							<div className="slider round" />
																						</label>
																					</div>
																					<Dropdown.Item
																						onClick={() => {
																							this.showEditPosition3(
																								this.state.position3Banners[0].id,
																								"three"
																							);
																						}}
																						className="d-flex align-items-center"
																					>
																						<span className="m-0">
																							{buttonLanguage.edit}
																						</span>
																						<svg
																							className="ms-auto"
																							width={19}
																							height={18}
																							viewBox="0 0 19 19"
																							fill="none"
																							xmlns="http://www.w3.org/2000/svg"
																						>
																							<path
																								d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																								fill="#2D2D3B"
																							/>
																						</svg>
																					</Dropdown.Item>
																					<Dropdown.Item
																						onClick={() => {
																							this.delete_Banner(
																								"three",
																								this.state.position3Banners[0].id
																							);
																						}}
																						className="d-flex align-items-center"
																					>
																						<span className="m-0">{buttonLanguage.delete}</span>
																						<svg
																							className="ms-auto"
																							width={18}
																							height={20}
																							viewBox="0 0 18 20"
																							fill="none"
																							xmlns="http://www.w3.org/2000/svg"
																						>
																							<path
																								d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
																								fill="#2D2D3B"
																							/>
																						</svg>
																					</Dropdown.Item>
																				</Dropdown.Menu>
																			</Dropdown>
																		</div>
																		<div className="banner-imag-main-div">
																			<img
																				src={

																					this.state.position3Banners[0]
																						.pc_english
																				}
																				alt=""
																				className="img-fluid w-100"
																			/>
																		</div>
																	</div>
																</div>
															) : (
																<div className="col-md-3 mb-3">
																	<div className="banner-main-box-ad">
																		<button
																			className="btn"
																			onClick={this.showPosition3}
																		>
																			<img src={plus} className="mb-3" />
																			<span>{masterLanguage.AddNewBanner}</span>
																		</button>
																	</div>
																</div>
															)}
														</div>
													</Accordion.Body>
												</Accordion.Item>
												<Accordion.Item eventKey="3">
													<Accordion.Header>
														{this.state.position4}
														<span>(Maximum 8 banners Active)</span>
														<Dropdown className="cust-drop text-end ms-auto">
															<Dropdown.Toggle
																className="bg-transparent "
																id="dropdown-basic"
																align="end"
															>
																<svg
																	xmlns="http://www.w3.org/2000/svg"
																	width={16}
																	height={16}
																	fill="currentColor"
																	className="bi bi-three-dots-vertical"
																	viewBox="0 0 16 16"
																>
																	<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																</svg>
															</Dropdown.Toggle>
															<Dropdown.Menu>
																<div className="d-flex align-items-center cust-switch-drop">
																	<span className="m-0">
																		{masterLanguage.active}
																	</span>
																	<label className="switch ms-auto">
																		<input
																			type="checkbox"
																			defaultChecked={
																				this.state.position4ActiveStatus
																			}
																			onChange={(e) =>
																				this.handleCheckbox(e, "four")
																			}
																		/>
																		<div className="slider round" />
																	</label>
																</div>
																<Dropdown.Item
																	onClick={() => this.editBannerShow("position4", 'four')}
																	className="d-flex align-items-center"
																>
																	<span className="m-0">
																		{buttonLanguage.edit}
																	</span>
																	<svg
																		className="ms-auto"
																		width={19}
																		height={18}
																		viewBox="0 0 19 19"
																		fill="none"
																		xmlns="http://www.w3.org/2000/svg"
																	>
																		<path
																			d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																			fill="#2D2D3B"
																		/>
																	</svg>
																</Dropdown.Item>
															</Dropdown.Menu>
														</Dropdown>
													</Accordion.Header>
													<Accordion.Body>
														<div className="row">
															{this.state.position4Banners &&
																this.state.position4Banners.length > 0 && (
																	<DragDropContext
																		onDragEnd={this.onPosition4DragEnd}
																	>
																		<Droppable
																			droppableId="droppable"
																			direction="horizontal"
																		>
																			{(provided, snapshot) => (
																				<div
																					className="drag-main-div col-md-10 d-flex mb-3"
																					ref={provided.innerRef}
																					style={getListStyle(
																						snapshot.isDraggingOver,
																						this.state.position4Banners.length
																					)}
																					{...provided.droppableProps}
																				>
																					{this.state.position4Banners.map(
																						(item, index) => (
																							<Draggable
																								key={item.banner_id.toString()}
																								draggableId={item.banner_id.toString()}
																								index={index}
																							>
																								{(provided, snapshot) => (
																									<div
																										className="drag-item-width"
																										ref={provided.innerRef}
																										{...provided.draggableProps}
																										{...provided.dragHandleProps}
																										style={getItemStyle(
																											snapshot.isDragging,
																											provided.draggableProps
																												.style
																										)}
																									>
																										<div className="iner-width-banner-drag-pos-4">
																											<div className=" position-relative">
																												<div className="banner-imag-main-div">
																													<img
																														src={

																															item.banner_image
																														}
																														alt=""
																														className="img-fluid"
																													/>
																													<div className="d-flex align-items-center">
																														<span className="fw-bold mx-auto">
																															{
																																item.banner_title_english
																															}
																														</span>
																														<Dropdown className="cust-drop ms-auto">
																															<Dropdown.Toggle
																																className="bg-transparent mb-0 p-0"
																																id="dropdown-basic"
																																align="end"
																															>
																																<svg
																																	xmlns="http://www.w3.org/2000/svg"
																																	width={16}
																																	height={16}
																																	fill="currentColor"
																																	className="bi bi-three-dots-vertical"
																																	viewBox="0 0 16 16"
																																>
																																	<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																																</svg>
																															</Dropdown.Toggle>
																															<Dropdown.Menu>
																																<div className="d-flex align-items-center cust-switch-drop">
																																	<span className="m-0">
																																		{
																																			masterLanguage.active
																																		}
																																	</span>
																																	<label className="switch ms-auto">
																																		<input
																																			type="checkbox"
																																			defaultChecked={
																																				item.status
																																			}
																																			onChange={(
																																				e
																																			) =>
																																				this.singleBannderStatusChange(
																																					e,
																																					item.id,
																																					"four"
																																				)
																																			}
																																		/>
																																		<div className="slider round" />
																																	</label>
																																</div>
																																<Dropdown.Item
																																	onClick={() => {
																																		this.showEditPosition4(
																																			item.id,
																																			"four"
																																		);
																																	}}
																																	className="d-flex align-items-center"
																																>
																																	<span className="m-0">
																																		{
																																			buttonLanguage.edit
																																		}
																																	</span>
																																	<svg
																																		className="ms-auto"
																																		width={19}
																																		height={18}
																																		viewBox="0 0 19 19"
																																		fill="none"
																																		xmlns="http://www.w3.org/2000/svg"
																																	>
																																		<path
																																			d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																																			fill="#2D2D3B"
																																		/>
																																	</svg>
																																</Dropdown.Item>
																																<Dropdown.Item
																																	onClick={() => {
																																		this.delete_Banner(
																																			"four",
																																			item.id
																																		);
																																	}}
																																	className="d-flex align-items-center"
																																>
																																	<span className="m-0">
																																		{buttonLanguage.delete}
																																	</span>
																																	<svg
																																		className="ms-auto"
																																		width={18}
																																		height={20}
																																		viewBox="0 0 18 20"
																																		fill="none"
																																		xmlns="http://www.w3.org/2000/svg"
																																	>
																																		<path
																																			d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
																																			fill="#2D2D3B"
																																		/>
																																	</svg>
																																</Dropdown.Item>
																															</Dropdown.Menu>
																														</Dropdown>
																													</div>
																												</div>
																											</div>
																										</div>
																									</div>
																								)}
																							</Draggable>
																						)
																					)}
																					{provided.placeholder}
																				</div>
																			)}
																		</Droppable>
																	</DragDropContext>
																)}

															{this.state.position4Banners.length < 8 && (
																<div className="col-md-2 mb-3">
																	<div className="banner-main-box-ad pos4-add-box">
																		<button
																			className="btn"
																			onClick={this.showPosition4}
																		>
																			<img src={plus} className="mb-3" />
																			<span>{masterLanguage.AddNewBanner}</span>
																		</button>
																	</div>
																</div>
															)}
														</div>
													</Accordion.Body>
												</Accordion.Item>
												<Accordion.Item eventKey="4">
													<Accordion.Header>
														{this.state.position5}{" "}
														<span>
															(Maximum 2 squares and 1 Rectengal banners Active)
														</span>
														<Dropdown className="cust-drop text-end ms-auto">
															<Dropdown.Toggle
																className="bg-transparent "
																id="dropdown-basic"
																align="end"
															>
																<svg
																	xmlns="http://www.w3.org/2000/svg"
																	width={16}
																	height={16}
																	fill="currentColor"
																	className="bi bi-three-dots-vertical"
																	viewBox="0 0 16 16"
																>
																	<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																</svg>
															</Dropdown.Toggle>
															<Dropdown.Menu>
																<div className="d-flex align-items-center cust-switch-drop">
																	<span className="m-0">
																		{masterLanguage.active}
																	</span>
																	<label className="switch ms-auto">
																		<input
																			type="checkbox"
																			defaultChecked={
																				this.state.position5ActiveStatus
																			}
																			onChange={(e) =>
																				this.handleCheckbox(e, "five")
																			}
																		/>
																		<div className="slider round" />
																	</label>
																</div>
																<Dropdown.Item
																	onClick={() => this.editBannerShow("position5", 'five')}
																	className="d-flex align-items-center"
																>
																	<span className="m-0">
																		{buttonLanguage.edit}
																	</span>
																	<svg
																		className="ms-auto"
																		width={19}
																		height={18}
																		viewBox="0 0 19 19"
																		fill="none"
																		xmlns="http://www.w3.org/2000/svg"
																	>
																		<path
																			d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																			fill="#2D2D3B"
																		/>
																	</svg>
																</Dropdown.Item>
															</Dropdown.Menu>
														</Dropdown>
													</Accordion.Header>
													<Accordion.Body>
														<div className="row">
															{this.state.position5Banners &&
																this.state.position5Banners.length > 0 &&
																this.state.position5Banners.map((item, i) => {
																	return (
																		<div className="col-md-10 mb-3" key={i}>
																			<div className="banner-main-box-ad position-relative">
																				<div className="drop-btn-banner">
																					<Dropdown className="cust-drop text-end">
																						<Dropdown.Toggle
																							className="bg-transparent "
																							id="dropdown-basic"
																							align="end"
																						>
																							<svg
																								xmlns="http://www.w3.org/2000/svg"
																								width={16}
																								height={16}
																								fill="currentColor"
																								className="bi bi-three-dots-vertical"
																								viewBox="0 0 16 16"
																							>
																								<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																							</svg>
																						</Dropdown.Toggle>
																						<Dropdown.Menu>
																							<div className="d-flex align-items-center cust-switch-drop">
																								<span className="m-0">
																									{masterLanguage.active}
																								</span>
																								<label className="switch ms-auto">
																									<input
																										type="checkbox"
																										defaultChecked={item.status}
																										onChange={(e) =>
																											this.singleBannderStatusChange(
																												e,
																												item.id,
																												"five"
																											)
																										}
																									/>
																									<div className="slider round" />
																								</label>
																							</div>
																							<Dropdown.Item
																								onClick={() => {
																									this.showEditPosition5(
																										item.id,
																										"five"
																									);
																								}}
																								className="d-flex align-items-center"
																							>
																								<span className="m-0">
																									{buttonLanguage.edit}
																								</span>
																								<svg
																									className="ms-auto"
																									width={19}
																									height={18}
																									viewBox="0 0 19 19"
																									fill="none"
																									xmlns="http://www.w3.org/2000/svg"
																								>
																									<path
																										d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																										fill="#2D2D3B"
																									/>
																								</svg>
																							</Dropdown.Item>
																							<Dropdown.Item
																								onClick={() => {
																									this.delete_Banner(
																										"five",
																										item.id
																									);
																								}}
																								className="d-flex align-items-center"
																							>
																								<span className="m-0">
																									{buttonLanguage.delete}
																								</span>
																								<svg
																									className="ms-auto"
																									width={18}
																									height={20}
																									viewBox="0 0 18 20"
																									fill="none"
																									xmlns="http://www.w3.org/2000/svg"
																								>
																									<path
																										d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
																										fill="#2D2D3B"
																									/>
																								</svg>
																							</Dropdown.Item>
																						</Dropdown.Menu>
																					</Dropdown>
																				</div>
																				<div className="banner-imag-main-div row align-items-center">
																					<div className="col-md-3 p-0">
																						<img
																							src={
																								item.banner_1_english
																							}
																							alt=""
																							className="img-fluid w-100"
																						/>
																					</div>
																					<div className="col-md-6 p-0">
																						<img
																							src={
																								item.banner_2_english
																							}
																							alt=""
																							className="img-fluid w-100 h-100"
																						/>
																					</div>
																					<div className="col-md-3 p-0">
																						<img
																							src={
																								item.banner_3_english
																							}
																							alt=""
																							className="img-fluid w-100"
																						/>
																					</div>
																				</div>
																			</div>
																		</div>
																	);
																})}
															{this.state.position5Banners.length < 1 && (
																<div className="col-md-2 mb-3">
																	<div className="banner-main-box-ad">
																		<button
																			className="btn"
																			onClick={this.showPosition5}
																		>
																			<img src={plus} className="mb-3" />
																			<span>{masterLanguage.AddNewBanner}</span>
																		</button>
																	</div>
																</div>
															)}
														</div>
													</Accordion.Body>
												</Accordion.Item>
												<Accordion.Item eventKey="11">
													<Accordion.Header>
														{this.state.Newposition6}
														<span>(Add Tag For display staff piked product in Home page)</span>
														<Dropdown className="cust-drop text-end ms-auto">
															<Dropdown.Toggle
																className="bg-transparent "
																id="dropdown-basic"
																align="end"
															>
																<svg
																	xmlns="http://www.w3.org/2000/svg"
																	width={16}
																	height={16}
																	fill="currentColor"
																	className="bi bi-three-dots-vertical"
																	viewBox="0 0 16 16"
																>
																	<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																</svg>
															</Dropdown.Toggle>
															<Dropdown.Menu>
																<div className="d-flex align-items-center cust-switch-drop">
																	<span className="m-0">
																		{masterLanguage.active}
																	</span>
																	<label className="switch ms-auto">
																		<input
																			type="checkbox"
																			defaultChecked={
																				this.state.Newposition6ActiveStatus
																			}
																			onChange={(e) =>
																				this.Tagsatus(e)
																			}
																		/>
																		<div className="slider round" />
																	</label>
																</div>
																{/* <Dropdown.Item
																	onClick={() => this.editBannerShow("position6-new", 'six-new')}
																	className="d-flex align-items-center"
																>
																	<span className="m-0">
																		{buttonLanguage.edit}
																	</span>
																	<svg
																		className="ms-auto"
																		width={19}
																		height={18}
																		viewBox="0 0 19 19"
																		fill="none"
																		xmlns="http://www.w3.org/2000/svg"
																	>
																		<path
																			d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																			fill="#2D2D3B"
																		/>
																	</svg>
																</Dropdown.Item> */}
															</Dropdown.Menu>
														</Dropdown>
													</Accordion.Header>
													<Accordion.Body>
														<div className="row">
															<div className="col-12 form-group">
																{/* <label>{''}</label> */}
																<div className="me-3 slim-wdh-cust d-flex  mb-3">
																	<label className="cust-radio mb-0 me-3">
																		<input type="radio" id="free" value="1" name="discount" onChange={this.onCatagoryTypeChange} checked={this.state.TagCatagoryType == 1} />
																		<span className="checkmark"></span>
																		<span>{'specificCategory'} </span>
																	</label>
																	<label className="cust-radio mb-0 me-3">
																		<input type="radio" id="percentage" value="0" name="discount" onChange={this.onCatagoryTypeChange} checked={this.state.TagCatagoryType == 0} />
																		<span className="checkmark"></span>
																		<span>{'all Category'} </span>
																	</label>
																</div>
																<div className="d-flex align-items-center mb-3">
																	<div className="me-3 slim-wdh-cust">
																		<select name="howToMeasure" value={''} onChange={this.handleTagChange} className="mb-0 form-select input-custom-class">
																			<option value="" defaultChecked>{'select'}</option>
																			{this.state.ActionTagArr &&
																				this.state.ActionTagArr.length > 0 &&
																				this.state.ActionTagArr.map((item, i) => {
																					return (
																						item != '' && item &&
																						<option value={item} key={i}>
																							{item}
																						</option>
																					);
																				})}
																		</select>
																	</div>
																	<div className="cust-tag-div slim-wdh-list">
																		<ul>
																			{this.state.selectedTags.length > 0 && this.state.selectedTags.map((item, i) => {
																				return (
																					<li className="d-inline-block align-middle">
																						<span>{item.tag}</span>
																						<mark className=" bg-transparent bi bi-x p-0" onClick={() => this.removeTag(item.id)}></mark>
																					</li>
																				)
																			})}
																			{/* <li className="d-inline-block align-middle">
																			<span>{'tag-1'}</span>
																			<mark className=" bg-transparent bi bi-x p-0"></mark>
																		</li>
																		<li className="d-inline-block align-middle">
																			<span>{'tag-1'}</span>
																			<mark className=" bg-transparent bi bi-x p-0"></mark>
																		</li>
																		<li className="d-inline-block align-middle">
																			<span>{'tag-1'}</span>
																			<mark className=" bg-transparent bi bi-x p-0"></mark>
																		</li> */}
																		</ul>
																		{/* {this.state.howToMeasureDataArr &&
																		this.state.howToMeasureDataArr.map((item, i) => {
																			let filtered = this.state.howToMeasureData.filter((l) => parseInt(item) === l.id);
																			return (
																				<ul key={i}>
																					{filtered &&
																						filtered.map((m, i) => {
																							return (
																								<li key={i}>
																									<span>{m.title_en}</span>
																									<mark onClick={() => this.removeMeasure(m.id)} className=" bg-transparent bi bi-x p-0"></mark>
																								</li>
																							);
																						})}
																				</ul>
																			);
																		})} */}
																	</div>
																</div>
															</div>
														</div>
													</Accordion.Body>
												</Accordion.Item>
												<Accordion.Item eventKey="5">
													<Accordion.Header>
														{this.state.position6}
														<span>(Maximum 1 banner Active)</span>
														<Dropdown className="cust-drop text-end ms-auto">
															<Dropdown.Toggle
																className="bg-transparent "
																id="dropdown-basic"
																align="end"
															>
																<svg
																	xmlns="http://www.w3.org/2000/svg"
																	width={16}
																	height={16}
																	fill="currentColor"
																	className="bi bi-three-dots-vertical"
																	viewBox="0 0 16 16"
																>
																	<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																</svg>
															</Dropdown.Toggle>
															<Dropdown.Menu>
																<div className="d-flex align-items-center cust-switch-drop">
																	<span className="m-0">
																		{masterLanguage.active}
																	</span>
																	<label className="switch ms-auto">
																		<input
																			type="checkbox"
																			defaultChecked={
																				this.state.position6ActiveStatus
																			}
																			onChange={(e) =>
																				this.handleCheckbox(e, "six")
																			}
																		/>
																		<div className="slider round" />
																	</label>
																</div>
																<Dropdown.Item
																	onClick={() => this.editBannerShow("position6", 'six')}
																	className="d-flex align-items-center"
																>
																	<span className="m-0">
																		{buttonLanguage.edit}
																	</span>
																	<svg
																		className="ms-auto"
																		width={19}
																		height={18}
																		viewBox="0 0 19 19"
																		fill="none"
																		xmlns="http://www.w3.org/2000/svg"
																	>
																		<path
																			d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																			fill="#2D2D3B"
																		/>
																	</svg>
																</Dropdown.Item>
															</Dropdown.Menu>
														</Dropdown>
													</Accordion.Header>
													<Accordion.Body>
														<div className="row">
															{this.state.position6Banners &&
																this.state.position6Banners.length > 0 ? (
																<div className="col-md-5 mb-3">
																	<div className="banner-main-box-ad position-relative">
																		<div className="drop-btn-banner">
																			<Dropdown className="cust-drop text-end">
																				<Dropdown.Toggle
																					className="bg-transparent "
																					id="dropdown-basic"
																					align="end"
																				>
																					<svg
																						xmlns="http://www.w3.org/2000/svg"
																						width={16}
																						height={16}
																						fill="currentColor"
																						className="bi bi-three-dots-vertical"
																						viewBox="0 0 16 16"
																					>
																						<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																					</svg>
																				</Dropdown.Toggle>
																				<Dropdown.Menu>
																					<div className="d-flex align-items-center cust-switch-drop">
																						<span className="m-0">
																							{masterLanguage.active}
																						</span>
																						<label className="switch ms-auto">
																							<input
																								type="checkbox"
																								defaultChecked={
																									this.state.position6Banners[0]
																										.status
																								}
																								onChange={(e) =>
																									this.singleBannderStatusChange(
																										e,
																										this.state.position6Banners[0]
																											.id,
																										"six"
																									)
																								}
																							/>
																							<div className="slider round" />
																						</label>
																					</div>
																					<Dropdown.Item
																						onClick={() => {
																							this.showEditPosition6(
																								this.state.position6Banners[0].id,
																								"six"
																							);
																						}}
																						className="d-flex align-items-center"
																					>
																						<span className="m-0">
																							{buttonLanguage.edit}
																						</span>
																						<svg
																							className="ms-auto"
																							width={19}
																							height={18}
																							viewBox="0 0 19 19"
																							fill="none"
																							xmlns="http://www.w3.org/2000/svg"
																						>
																							<path
																								d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																								fill="#2D2D3B"
																							/>
																						</svg>
																					</Dropdown.Item>
																					<Dropdown.Item
																						onClick={() => {
																							this.delete_Banner(
																								"six",
																								this.state.position6Banners[0].id
																							);
																						}}
																						className="d-flex align-items-center"
																					>
																						<span className="m-0">{buttonLanguage.delete}</span>
																						<svg
																							className="ms-auto"
																							width={18}
																							height={20}
																							viewBox="0 0 18 20"
																							fill="none"
																							xmlns="http://www.w3.org/2000/svg"
																						>
																							<path
																								d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
																								fill="#2D2D3B"
																							/>
																						</svg>
																					</Dropdown.Item>
																				</Dropdown.Menu>
																			</Dropdown>
																		</div>
																		<div className="banner-imag-main-div">
																			<img
																				src={

																					this.state.position6Banners[0]
																						.pc_english
																				}
																				alt=""
																				className="img-fluid w-100"
																			/>
																		</div>
																	</div>
																</div>
															) : (
																<div className="col-md-2 mb-3">
																	<div className="banner-main-box-ad">
																		<button
																			className="btn"
																			onClick={this.showPosition6}
																		>
																			<img src={plus} className="mb-3" />
																			<span>{masterLanguage.AddNewBanner}</span>
																		</button>
																	</div>
																</div>
															)}
														</div>
													</Accordion.Body>
												</Accordion.Item>
												<Accordion.Item eventKey="6">
													<Accordion.Header>
														{this.state.position7}{" "}
														<span>(Maximum 3 banner Actives)</span>
														<Dropdown className="cust-drop text-end ms-auto">
															<Dropdown.Toggle
																className="bg-transparent "
																id="dropdown-basic"
																align="end"
															>
																<svg
																	xmlns="http://www.w3.org/2000/svg"
																	width={16}
																	height={16}
																	fill="currentColor"
																	className="bi bi-three-dots-vertical"
																	viewBox="0 0 16 16"
																>
																	<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																</svg>
															</Dropdown.Toggle>
															<Dropdown.Menu>
																<div className="d-flex align-items-center cust-switch-drop">
																	<span className="m-0">
																		{masterLanguage.active}
																	</span>
																	<label className="switch ms-auto">
																		<input
																			type="checkbox"
																			defaultChecked={
																				this.state.position7ActiveStatus
																			}
																			onChange={(e) =>
																				this.handleCheckbox(e, "seven")
																			}
																		/>
																		<div className="slider round" />
																	</label>
																</div>
																<Dropdown.Item
																	onClick={() => this.editBannerShow("position7", 'seven')}
																	className="d-flex align-items-center"
																>
																	<span className="m-0">
																		{buttonLanguage.edit}
																	</span>
																	<svg
																		className="ms-auto"
																		width={19}
																		height={18}
																		viewBox="0 0 19 19"
																		fill="none"
																		xmlns="http://www.w3.org/2000/svg"
																	>
																		<path
																			d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																			fill="#2D2D3B"
																		/>
																	</svg>
																</Dropdown.Item>
															</Dropdown.Menu>
														</Dropdown>
													</Accordion.Header>
													<Accordion.Body>
														<div className="row">
															{this.state.position7Banners &&
																this.state.position7Banners.length > 0 && (
																	<DragDropContext
																		onDragEnd={this.onPosition7DragEnd}
																	>
																		<Droppable
																			droppableId="droppable"
																			direction="horizontal"
																		>
																			{(provided, snapshot) => (
																				<div
																					className="drag-main-div col-md-9 mb-3"
																					ref={provided.innerRef}
																					style={getListStyle(
																						snapshot.isDraggingOver,
																						this.state.position7Banners.length
																					)}
																					{...provided.droppableProps}
																				>
																					{this.state.position7Banners.map(
																						(item, index) => (
																							<Draggable
																								key={item.banner_id.toString()}
																								draggableId={item.banner_id.toString()}
																								index={index}
																							>
																								{(provided, snapshot) => (
																									<div
																										className="drag-item-width"
																										ref={provided.innerRef}
																										{...provided.draggableProps}
																										{...provided.dragHandleProps}
																										style={getItemStyle(
																											snapshot.isDragging,
																											provided.draggableProps
																												.style
																										)}
																									>
																										<div className="iner-width-banner-drag">
																											<div className="banner-main-box-ad position-relative">
																												<div className="drop-btn-banner">
																													<Dropdown className="cust-drop text-end">
																														<Dropdown.Toggle
																															className="bg-transparent "
																															id="dropdown-basic"
																															align="end"
																														>
																															<svg
																																xmlns="http://www.w3.org/2000/svg"
																																width={16}
																																height={16}
																																fill="currentColor"
																																className="bi bi-three-dots-vertical"
																																viewBox="0 0 16 16"
																															>
																																<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																															</svg>
																														</Dropdown.Toggle>
																														<Dropdown.Menu>
																															<div className="d-flex align-items-center cust-switch-drop">
																																<span className="m-0">
																																	Active
																																</span>
																																<label className="switch ms-auto">
																																	<input
																																		type="checkbox"
																																		defaultChecked={
																																			item.status
																																		}
																																		onChange={(
																																			e
																																		) =>
																																			this.singleBannderStatusChange(
																																				e,
																																				item.id,
																																				"seven"
																																			)
																																		}
																																	/>
																																	<div className="slider round" />
																																</label>
																															</div>
																															<Dropdown.Item
																																onClick={() => {
																																	this.showEditPosition4(
																																		item.id,
																																		"seven"
																																	);
																																}}
																																className="d-flex align-items-center"
																															>
																																<span className="m-0">
																																	{
																																		buttonLanguage.edit
																																	}
																																</span>
																																<svg
																																	className="ms-auto"
																																	width={19}
																																	height={18}
																																	viewBox="0 0 19 19"
																																	fill="none"
																																	xmlns="http://www.w3.org/2000/svg"
																																>
																																	<path
																																		d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																																		fill="#2D2D3B"
																																	/>
																																</svg>
																															</Dropdown.Item>
																															<Dropdown.Item
																																onClick={() => {
																																	this.delete_Banner(
																																		"seven",
																																		item.id
																																	);
																																}}
																																className="d-flex align-items-center"
																															>
																																<span className="m-0">
																																	{buttonLanguage.delete}
																																</span>
																																<svg
																																	className="ms-auto"
																																	width={18}
																																	height={20}
																																	viewBox="0 0 18 20"
																																	fill="none"
																																	xmlns="http://www.w3.org/2000/svg"
																																>
																																	<path
																																		d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
																																		fill="#2D2D3B"
																																	/>
																																</svg>
																															</Dropdown.Item>
																														</Dropdown.Menu>
																													</Dropdown>
																												</div>
																												<div className="banner-imag-main-div">
																													<img
																														src={

																															item.pc_english
																														}
																														alt=""
																														className="img-fluid w-100"
																													/>
																												</div>
																											</div>
																										</div>
																									</div>
																								)}
																							</Draggable>
																						)
																					)}
																					{provided.placeholder}
																				</div>
																			)}
																		</Droppable>
																	</DragDropContext>
																)}

															{this.state.position7Banners.length < 3 && (
																<div className="col-md-3 mb-3">
																	<div className="banner-main-box-ad">
																		<button
																			className="btn d-flex align-items-center"
																			onClick={this.showPosition7}
																		>
																			<img src={plus} className=" me-2" />
																			<span>{masterLanguage.AddNewBanner}</span>
																		</button>
																	</div>
																</div>
															)}
														</div>
													</Accordion.Body>
												</Accordion.Item>
												<Accordion.Item eventKey="7">
													<Accordion.Header>
														{this.state.position8}
														<span>(Maximum 6 banners Active)</span>
														<Dropdown className="cust-drop text-end ms-auto">
															<Dropdown.Toggle
																className="bg-transparent "
																id="dropdown-basic"
																align="end"
															>
																<svg
																	xmlns="http://www.w3.org/2000/svg"
																	width={16}
																	height={16}
																	fill="currentColor"
																	className="bi bi-three-dots-vertical"
																	viewBox="0 0 16 16"
																>
																	<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																</svg>
															</Dropdown.Toggle>
															<Dropdown.Menu>
																<div className="d-flex align-items-center cust-switch-drop">
																	<span className="m-0">
																		{masterLanguage.active}
																	</span>
																	<label className="switch ms-auto">
																		<input
																			type="checkbox"
																			defaultChecked={
																				this.state.position8ActiveStatus
																			}
																			onChange={(e) =>
																				this.handleCheckbox(e, "eight")
																			}
																		/>
																		<div className="slider round" />
																	</label>
																</div>
																<Dropdown.Item
																	onClick={() => this.editBannerShow("position8", 'eight')}
																	className="d-flex align-items-center"
																>
																	<span className="m-0">
																		{buttonLanguage.edit}
																	</span>
																	<svg
																		className="ms-auto"
																		width={19}
																		height={18}
																		viewBox="0 0 19 19"
																		fill="none"
																		xmlns="http://www.w3.org/2000/svg"
																	>
																		<path
																			d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																			fill="#2D2D3B"
																		/>
																	</svg>
																</Dropdown.Item>
															</Dropdown.Menu>
														</Dropdown>
													</Accordion.Header>
													<Accordion.Body>
														<div className="row">
															{this.state.position8Banners &&
																this.state.position8Banners.length > 0 && (
																	<DragDropContext
																		onDragEnd={this.onPosition8DragEnd}
																	>
																		<Droppable
																			droppableId="droppable"
																			direction="horizontal"
																		>
																			{(provided, snapshot) => (
																				<div
																					className="drag-main-div col-md-10 mb-3"
																					ref={provided.innerRef}
																					style={getListStyle(
																						snapshot.isDraggingOver,
																						this.state.position8Banners.length
																					)}
																					{...provided.droppableProps}
																				>
																					{this.state.position8Banners.map(
																						(item, index) => (
																							<Draggable
																								key={item.banner_id.toString()}
																								draggableId={item.banner_id.toString()}
																								index={index}
																							>
																								{(provided, snapshot) => (
																									<div
																										ref={provided.innerRef}
																										{...provided.draggableProps}
																										{...provided.dragHandleProps}
																										style={getItemStyle(
																											snapshot.isDragging,
																											provided.draggableProps
																												.style
																										)}
																									>
																										<div className="me-3">
																											<div className="banner-main-box-ad position-relative">
																												<div className="drop-btn-banner">
																													<Dropdown className="cust-drop text-end">
																														<Dropdown.Toggle
																															className="bg-transparent "
																															id="dropdown-basic"
																															align="end"
																														>
																															<svg
																																xmlns="http://www.w3.org/2000/svg"
																																width={16}
																																height={16}
																																fill="currentColor"
																																className="bi bi-three-dots-vertical"
																																viewBox="0 0 16 16"
																															>
																																<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																															</svg>
																														</Dropdown.Toggle>
																														<Dropdown.Menu>
																															<div className="d-flex align-items-center cust-switch-drop">
																																<span className="m-0">
																																	Active
																																</span>
																																<label className="switch ms-auto">
																																	<input
																																		type="checkbox"
																																		defaultChecked={
																																			item.status
																																		}
																																		onChange={(
																																			e
																																		) =>
																																			this.singleBannderStatusChange(
																																				e,
																																				item.id,
																																				"eight"
																																			)
																																		}
																																	/>
																																	<div className="slider round" />
																																</label>
																															</div>
																															<Dropdown.Item
																																onClick={() => {
																																	this.showEditPosition8(
																																		item.id,
																																		"eight"
																																	);
																																}}
																																className="d-flex align-items-center"
																															>
																																<span className="m-0">
																																	{
																																		buttonLanguage.edit
																																	}
																																</span>
																																<svg
																																	className="ms-auto"
																																	width={19}
																																	height={18}
																																	viewBox="0 0 19 19"
																																	fill="none"
																																	xmlns="http://www.w3.org/2000/svg"
																																>
																																	<path
																																		d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																																		fill="#2D2D3B"
																																	/>
																																</svg>
																															</Dropdown.Item>
																															<Dropdown.Item
																																onClick={() => {
																																	this.delete_Banner(
																																		"eight",
																																		item.id
																																	);
																																}}
																																className="d-flex align-items-center"
																															>
																																<span className="m-0">
																																	{buttonLanguage.delete}
																																</span>
																																<svg
																																	className="ms-auto"
																																	width={18}
																																	height={20}
																																	viewBox="0 0 18 20"
																																	fill="none"
																																	xmlns="http://www.w3.org/2000/svg"
																																>
																																	<path
																																		d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
																																		fill="#2D2D3B"
																																	/>
																																</svg>
																															</Dropdown.Item>
																														</Dropdown.Menu>
																													</Dropdown>
																												</div>
																												<div className="banner-imag-main-div">
																													<img
																														src={

																															item.pc_english
																														}
																														alt=""
																														className="img-fluid w-100"
																													/>
																												</div>
																											</div>
																										</div>
																									</div>
																								)}
																							</Draggable>
																						)
																					)}
																					{provided.placeholder}
																				</div>
																			)}
																		</Droppable>
																	</DragDropContext>
																)}

															{this.state.position8Banners.length < 6 && (
																<div className="col-md-2 mb-3">
																	<div className="banner-main-box-ad">
																		<button
																			className="btn"
																			onClick={this.showPosition8}
																		>
																			<img src={plus} className="mb-3" />
																			<span>{masterLanguage.AddNewBanner}</span>
																		</button>
																	</div>
																</div>
															)}
														</div>
													</Accordion.Body>
												</Accordion.Item>
												<Accordion.Item eventKey="8">
													<Accordion.Header>
														{this.state.position9}
														<span>(Maximum 1 banner Active)</span>
														<Dropdown className="cust-drop text-end ms-auto">
															<Dropdown.Toggle
																className="bg-transparent "
																id="dropdown-basic"
																align="end"
															>
																<svg
																	xmlns="http://www.w3.org/2000/svg"
																	width={16}
																	height={16}
																	fill="currentColor"
																	className="bi bi-three-dots-vertical"
																	viewBox="0 0 16 16"
																>
																	<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																</svg>
															</Dropdown.Toggle>
															<Dropdown.Menu>
																<div className="d-flex align-items-center cust-switch-drop">
																	<span className="m-0">
																		{masterLanguage.active}
																	</span>
																	<label className="switch ms-auto">
																		<input
																			type="checkbox"
																			defaultChecked={
																				this.state.position9ActiveStatus
																			}
																			onChange={(e) =>
																				this.handleCheckbox(e, "nine")
																			}
																		/>
																		<div className="slider round" />
																	</label>
																</div>
																<Dropdown.Item
																	onClick={() => this.editBannerShow("position9", 'nine')}
																	className="d-flex align-items-center"
																>
																	<span className="m-0">
																		{buttonLanguage.edit}
																	</span>
																	<svg
																		className="ms-auto"
																		width={19}
																		height={18}
																		viewBox="0 0 19 19"
																		fill="none"
																		xmlns="http://www.w3.org/2000/svg"
																	>
																		<path
																			d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																			fill="#2D2D3B"
																		/>
																	</svg>
																</Dropdown.Item>
															</Dropdown.Menu>
														</Dropdown>
													</Accordion.Header>
													<Accordion.Body>
														<div className="row">
															{this.state.position9Banners &&
																this.state.position9Banners.length > 0 ? (
																<div className="col-md-4 mb-3">
																	<div className="banner-main-box-ad position-relative">
																		<div className="drop-btn-banner">
																			<Dropdown className="cust-drop text-end">
																				<Dropdown.Toggle
																					className="bg-transparent "
																					id="dropdown-basic"
																					align="end"
																				>
																					<svg
																						xmlns="http://www.w3.org/2000/svg"
																						width={16}
																						height={16}
																						fill="currentColor"
																						className="bi bi-three-dots-vertical"
																						viewBox="0 0 16 16"
																					>
																						<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																					</svg>
																				</Dropdown.Toggle>
																				<Dropdown.Menu>
																					<div className="d-flex align-items-center cust-switch-drop">
																						<span className="m-0">
																							{masterLanguage.active}
																						</span>
																						<label className="switch ms-auto">
																							<input
																								type="checkbox"
																								defaultChecked={
																									this.state.position9Banners[0]
																										.status
																								}
																								onChange={(e) =>
																									this.singleBannderStatusChange(
																										e,
																										this.state.position9Banners[0]
																											.id,
																										"nine"
																									)
																								}
																							/>
																							<div className="slider round" />
																						</label>
																					</div>
																					<Dropdown.Item
																						onClick={() => {
																							this.showEditPosition9(
																								this.state.position9Banners[0].id,
																								"nine"
																							);
																						}}
																						className="d-flex align-items-center"
																					>
																						<span className="m-0">
																							{buttonLanguage.edit}
																						</span>
																						<svg
																							className="ms-auto"
																							width={19}
																							height={18}
																							viewBox="0 0 19 19"
																							fill="none"
																							xmlns="http://www.w3.org/2000/svg"
																						>
																							<path
																								d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																								fill="#2D2D3B"
																							/>
																						</svg>
																					</Dropdown.Item>
																					<Dropdown.Item
																						onClick={() => {
																							this.delete_Banner(
																								"nine",
																								this.state.position9Banners[0].id
																							);
																						}}
																						className="d-flex align-items-center"
																					>
																						<span className="m-0">{buttonLanguage.delete}</span>
																						<svg
																							className="ms-auto"
																							width={18}
																							height={20}
																							viewBox="0 0 18 20"
																							fill="none"
																							xmlns="http://www.w3.org/2000/svg"
																						>
																							<path
																								d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
																								fill="#2D2D3B"
																							/>
																						</svg>
																					</Dropdown.Item>
																				</Dropdown.Menu>
																			</Dropdown>
																		</div>
																		<div className="banner-imag-main-div">
																			<img
																				src={

																					this.state.position9Banners[0]
																						.pc_english
																				}
																				alt=""
																				className="img-fluid w-100"
																			/>
																		</div>
																	</div>
																</div>
															) : (
																<div className="col-md-4 mb-3">
																	<div className="banner-main-box-ad">
																		<button
																			className="btn"
																			onClick={this.showPosition9}
																		>
																			<img src={plus} className="mb-3" />
																			<span>{masterLanguage.AddNewBanner}</span>
																		</button>
																	</div>
																</div>
															)}
														</div>
													</Accordion.Body>
												</Accordion.Item>
												<Accordion.Item eventKey="9">
													<Accordion.Header>
														{this.state.position10}{" "}
														<span>(Maximum 4 banners Active)</span>
														<Dropdown className="cust-drop text-end ms-auto">
															<Dropdown.Toggle
																className="bg-transparent "
																id="dropdown-basic"
																align="end"
															>
																<svg
																	xmlns="http://www.w3.org/2000/svg"
																	width={16}
																	height={16}
																	fill="currentColor"
																	className="bi bi-three-dots-vertical"
																	viewBox="0 0 16 16"
																>
																	<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																</svg>
															</Dropdown.Toggle>
															<Dropdown.Menu>
																<div className="d-flex align-items-center cust-switch-drop">
																	<span className="m-0">
																		{masterLanguage.active}
																	</span>
																	<label className="switch ms-auto">
																		<input
																			type="checkbox"
																			defaultChecked={
																				this.state.position10ActiveStatus
																			}
																			onChange={(e) =>
																				this.handleCheckbox(e, "ten")
																			}
																		/>
																		<div className="slider round" />
																	</label>
																</div>
																<Dropdown.Item
																	onClick={() =>
																		this.editBannerShow("position10", 'ten')
																	}
																	className="d-flex align-items-center"
																>
																	<span className="m-0">
																		{buttonLanguage.edit}
																	</span>
																	<svg
																		className="ms-auto"
																		width={19}
																		height={18}
																		viewBox="0 0 19 19"
																		fill="none"
																		xmlns="http://www.w3.org/2000/svg"
																	>
																		<path
																			d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																			fill="#2D2D3B"
																		/>
																	</svg>
																</Dropdown.Item>
															</Dropdown.Menu>
														</Dropdown>
													</Accordion.Header>
													<Accordion.Body>
														<div className="row">
															{this.state.position10Banners &&
																this.state.position10Banners.length > 0 && (
																	<DragDropContext
																		onDragEnd={this.onPosition10DragEnd}
																	>
																		<Droppable
																			droppableId="droppable"
																			direction="horizontal"
																		>
																			{(provided, snapshot) => (
																				<div
																					className="drag-main-div col-md-10 mb-3"
																					ref={provided.innerRef}
																					style={getListStyle(
																						snapshot.isDraggingOver,
																						this.state.position10Banners.length
																					)}
																					{...provided.droppableProps}
																				>
																					{this.state.position10Banners.map(
																						(item, index) => (
																							<Draggable
																								key={item.banner_id.toString()}
																								draggableId={item.banner_id.toString()}
																								index={index}
																							>
																								{(provided, snapshot) => (
																									<div
																										className="drag-item-width"
																										ref={provided.innerRef}
																										{...provided.draggableProps}
																										{...provided.dragHandleProps}
																										style={getItemStyle(
																											snapshot.isDragging,
																											provided.draggableProps
																												.style
																										)}
																									>
																										<div className="me-3">
																											<div className="banner-main-box-ad position-relative">
																												<div className="drop-btn-banner">
																													<Dropdown className="cust-drop text-end">
																														<Dropdown.Toggle
																															className="bg-transparent "
																															id="dropdown-basic"
																															align="end"
																														>
																															<svg
																																xmlns="http://www.w3.org/2000/svg"
																																width={16}
																																height={16}
																																fill="currentColor"
																																className="bi bi-three-dots-vertical"
																																viewBox="0 0 16 16"
																															>
																																<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																															</svg>
																														</Dropdown.Toggle>
																														<Dropdown.Menu>
																															<div className="d-flex align-items-center cust-switch-drop">
																																<span className="m-0">
																																	Active
																																</span>
																																<label className="switch ms-auto">
																																	<input
																																		type="checkbox"
																																		defaultChecked={
																																			this.state
																																				.position10Banners[0]
																																				.status
																																		}
																																		onChange={(
																																			e
																																		) =>
																																			this.singleBannderStatusChange(
																																				e,
																																				this.state
																																					.position10Banners[0]
																																					.id,
																																				"ten"
																																			)
																																		}
																																	/>
																																	<div className="slider round" />
																																</label>
																															</div>
																															<Dropdown.Item
																																onClick={() => {
																																	this.showEditPosition10(
																																		item.id,
																																		"ten"
																																	);
																																}}
																																className="d-flex align-items-center"
																															>
																																<span className="m-0">
																																	{
																																		buttonLanguage.edit
																																	}
																																</span>
																																<svg
																																	className="ms-auto"
																																	width={19}
																																	height={18}
																																	viewBox="0 0 19 19"
																																	fill="none"
																																	xmlns="http://www.w3.org/2000/svg"
																																>
																																	<path
																																		d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																																		fill="#2D2D3B"
																																	/>
																																</svg>
																															</Dropdown.Item>
																															<Dropdown.Item
																																onClick={() => {
																																	this.delete_Banner(
																																		"ten",
																																		item.id
																																	);
																																}}
																																className="d-flex align-items-center"
																															>
																																<span className="m-0">
																																	{buttonLanguage.delete}
																																</span>
																																<svg
																																	className="ms-auto"
																																	width={18}
																																	height={20}
																																	viewBox="0 0 18 20"
																																	fill="none"
																																	xmlns="http://www.w3.org/2000/svg"
																																>
																																	<path
																																		d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
																																		fill="#2D2D3B"
																																	/>
																																</svg>
																															</Dropdown.Item>
																														</Dropdown.Menu>
																													</Dropdown>
																												</div>
																												<div className="banner-imag-main-div">
																													<img
																														src={

																															item.pc_english
																														}
																														alt=""
																														className="img-fluid w-100"
																													/>
																												</div>
																											</div>
																										</div>
																									</div>
																								)}
																							</Draggable>
																						)
																					)}
																					{provided.placeholder}
																				</div>
																			)}
																		</Droppable>
																	</DragDropContext>
																)}

															{this.state.position10Banners.length < 4 && (
																<div className="col-md-2 mb-3">
																	<div className="banner-main-box-ad">
																		<button
																			className="btn"
																			onClick={this.showPosition10}
																		>
																			<img src={plus} className="mb-3" />
																			<span>{masterLanguage.AddNewBanner}</span>
																		</button>
																	</div>
																</div>
															)}
														</div>
													</Accordion.Body>
												</Accordion.Item>
												<Accordion.Item eventKey="10">
													<Accordion.Header>
														{this.state.position11}
														<span>(Maximum 2 banners Active)</span>
														<Dropdown className="cust-drop text-end ms-auto">
															<Dropdown.Toggle
																className="bg-transparent "
																id="dropdown-basic"
																align="end"
															>
																<svg
																	xmlns="http://www.w3.org/2000/svg"
																	width={16}
																	height={16}
																	fill="currentColor"
																	className="bi bi-three-dots-vertical"
																	viewBox="0 0 16 16"
																>
																	<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																</svg>
															</Dropdown.Toggle>
															<Dropdown.Menu>
																<div className="d-flex align-items-center cust-switch-drop">
																	<span className="m-0">
																		{masterLanguage.active}
																	</span>
																	<label className="switch ms-auto">
																		<input
																			type="checkbox"
																			defaultChecked={
																				this.state.position11ActiveStatus
																			}
																			onChange={(e) =>
																				this.handleCheckbox(e, "eleven")
																			}
																		/>
																		<div className="slider round" />
																	</label>
																</div>
																<Dropdown.Item
																	onClick={() =>
																		this.editBannerShow("position11", 'eleven')
																	}
																	className="d-flex align-items-center"
																>
																	<span className="m-0">
																		{buttonLanguage.edit}
																	</span>
																	<svg
																		className="ms-auto"
																		width={19}
																		height={18}
																		viewBox="0 0 19 19"
																		fill="none"
																		xmlns="http://www.w3.org/2000/svg"
																	>
																		<path
																			d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																			fill="#2D2D3B"
																		/>
																	</svg>
																</Dropdown.Item>
															</Dropdown.Menu>
														</Dropdown>
													</Accordion.Header>
													<Accordion.Body>
														<div className="row">
															{this.state.position11Banners &&
																this.state.position11Banners.length > 0 && (
																	<DragDropContext
																		onDragEnd={this.onPosition11DragEnd}
																	>
																		<Droppable
																			droppableId="droppable"
																			direction="horizontal"
																		>
																			{(provided, snapshot) => (
																				<div
																					className="drag-main-div col-md-8 mb-3"
																					ref={provided.innerRef}
																					style={getListStyle(
																						snapshot.isDraggingOver,
																						this.state.position11Banners.length
																					)}
																					{...provided.droppableProps}
																				>
																					{this.state.position11Banners.map(
																						(item, index) => (
																							<Draggable
																								key={item.banner_id.toString()}
																								draggableId={item.banner_id.toString()}
																								index={index}
																							>
																								{(provided, snapshot) => (
																									<div
																										ref={provided.innerRef}
																										{...provided.draggableProps}
																										{...provided.dragHandleProps}
																										style={getItemStyle(
																											snapshot.isDragging,
																											provided.draggableProps
																												.style
																										)}
																									>
																										<div className="me-3">
																											<div className="banner-main-box-ad position-relative">
																												<div className="drop-btn-banner">
																													<Dropdown className="cust-drop text-end">
																														<Dropdown.Toggle
																															className="bg-transparent "
																															id="dropdown-basic"
																															align="end"
																														>
																															<svg
																																xmlns="http://www.w3.org/2000/svg"
																																width={16}
																																height={16}
																																fill="currentColor"
																																className="bi bi-three-dots-vertical"
																																viewBox="0 0 16 16"
																															>
																																<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																															</svg>
																														</Dropdown.Toggle>
																														<Dropdown.Menu>
																															<div className="d-flex align-items-center cust-switch-drop">
																																<span className="m-0">
																																	{
																																		masterLanguage.active
																																	}
																																</span>
																																<label className="switch ms-auto">
																																	<input
																																		type="checkbox"
																																		defaultChecked={
																																			item.status
																																		}
																																		onChange={(
																																			e
																																		) =>
																																			this.singleBannderStatusChange(
																																				e,
																																				item.id,
																																				"eleven"
																																			)
																																		}
																																	/>
																																	<div className="slider round" />
																																</label>
																															</div>
																															<Dropdown.Item
																																onClick={() => {
																																	this.showEditPosition11(
																																		item.id,
																																		"eleven"
																																	);
																																}}
																																className="d-flex align-items-center"
																															>
																																<span className="m-0">
																																	{
																																		buttonLanguage.edit
																																	}
																																</span>
																																<svg
																																	className="ms-auto"
																																	width={19}
																																	height={18}
																																	viewBox="0 0 19 19"
																																	fill="none"
																																	xmlns="http://www.w3.org/2000/svg"
																																>
																																	<path
																																		d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
																																		fill="#2D2D3B"
																																	/>
																																</svg>
																															</Dropdown.Item>
																															<Dropdown.Item
																																onClick={() => {
																																	this.delete_Banner(
																																		"eleven",
																																		item.id
																																	);
																																}}
																																className="d-flex align-items-center"
																															>
																																<span className="m-0">
																																	{buttonLanguage.delete}
																																</span>
																																<svg
																																	className="ms-auto"
																																	width={18}
																																	height={20}
																																	viewBox="0 0 18 20"
																																	fill="none"
																																	xmlns="http://www.w3.org/2000/svg"
																																>
																																	<path
																																		d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
																																		fill="#2D2D3B"
																																	/>
																																</svg>
																															</Dropdown.Item>
																														</Dropdown.Menu>
																													</Dropdown>
																												</div>
																												<div className="banner-imag-main-div">
																													<img
																														src={

																															item.pc_english
																														}
																														alt=""
																														className="img-fluid w-100"
																													/>
																												</div>
																											</div>
																										</div>
																									</div>
																								)}
																							</Draggable>
																						)
																					)}
																					{provided.placeholder}
																				</div>
																			)}
																		</Droppable>
																	</DragDropContext>
																)}

															{this.state.position11Banners.length < 2 && (
																<div className="col-md-4 mb-3">
																	<div className="banner-main-box-ad">
																		<button
																			className="btn"
																			onClick={this.showPosition11}
																		>
																			<img src={plus} className="mb-3" />
																			<span>{masterLanguage.AddNewBanner}</span>
																		</button>
																	</div>
																</div>
															)}
														</div>
													</Accordion.Body>
												</Accordion.Item>
											</Accordion>
										</div>
									</div>
									{this.state.maincategoryData.length > 0 &&
										<>
											{this.state.Position1 &&
												<Position1
													masterCatagoryData={this.state.maincategoryData}
													show={this.state.Position1}
													closePosition1={this.closePosition1}
													submitPosition1={this.submitPosition1}
													selectedCatagory={this.state.selectedMainCatagory}
												/>
											}
											{this.state.Position2 &&
												<Position2
													masterCatagoryData={this.state.maincategoryData}
													show={this.state.Position2}
													closePosition2={this.closePosition2}
													submitPosition2={this.submitPosition2}
													selectedCatagory={this.state.selectedMainCatagory}
												/>
											}
											{this.state.Position3 &&
												<Position3
													masterCatagoryData={this.state.maincategoryData}
													show={this.state.Position3}
													closePosition3={this.closePosition3}
													submitPosition3={this.submitPosition3}
													selectedCatagory={this.state.selectedMainCatagory}
												/>
											}
											{this.state.Position4 &&
												<Position4
													masterCatagoryData={this.state.maincategoryData}
													show={this.state.Position4}
													closePosition4={this.closePosition4}
													submitPosition4={this.submitPosition4}
													selectedCatagory={this.state.selectedMainCatagory}
												/>
											}
											{this.state.Position5 &&
												<Position5
													masterCatagoryData={this.state.maincategoryData}
													show={this.state.Position5}
													closePosition5={this.closePosition5}
													submitPosition5={this.submitPosition5}
													selectedCatagory={this.state.selectedMainCatagory}
												/>
											}
											{this.state.Position6 &&
												<Position6
													masterCatagoryData={this.state.maincategoryData}
													show={this.state.Position6}
													closePosition6={this.closePosition6}
													submitPosition6={this.submitPosition6}
													selectedCatagory={this.state.selectedMainCatagory}
												/>
											}
											{this.state.Position7 &&
												<Position7
													masterCatagoryData={this.state.maincategoryData}
													show={this.state.Position7}
													closePosition7={this.closePosition7}
													submitPosition7={this.submitPosition7}
													selectedCatagory={this.state.selectedMainCatagory}
												/>
											}
											{this.state.Position8 &&
												<Position8
													masterCatagoryData={this.state.maincategoryData}
													show={this.state.Position8}
													closePosition8={this.closePosition8}
													submitPosition8={this.submitPosition8}
													selectedCatagory={this.state.selectedMainCatagory}
												/>
											}
											{this.state.Position9 &&
												<Position9
													masterCatagoryData={this.state.maincategoryData}
													show={this.state.Position9}
													closePosition9={this.closePosition9}
													submitPosition9={this.submitPosition9}
													selectedCatagory={this.state.selectedMainCatagory}
												/>
											}
											{this.state.Position10 &&
												<Position10
													masterCatagoryData={this.state.maincategoryData}
													show={this.state.Position10}
													closePosition10={this.closePosition10}
													submitPosition10={this.submitPosition10}
													selectedCatagory={this.state.selectedMainCatagory}
												/>
											}
											{this.state.Position11 &&
												<Position11
													masterCatagoryData={this.state.maincategoryData}
													show={this.state.Position11}
													closePosition11={this.closePosition11}
													submitPosition11={this.submitPosition11}
													selectedCatagory={this.state.selectedMainCatagory}
												/>
											}
										</>
									}
									{this.state.editPosition1 && (
										<EditPosition1
											masterCatagoryData={this.state.maincategoryData}
											show={this.state.editPosition1}
											closeEditPosition1={this.closeEditPosition1}
											submitEditPosition1={this.submitEditPosition1}
											data={this.state.editBannerData}
											selectedCatagory={this.state.selectedMainCatagory}
										// masterCatagory={}
										/>
									)}

									{this.state.editPosition2 && (
										<EditPosition2
											show={this.state.editPosition2}
											closeEditPosition2={this.closeEditPosition2}
											submitEditPosition2={this.submitEditPosition2}
											data={this.state.editBannerData}
											selectedCatagory={this.state.selectedMainCatagory}
										/>
									)}

									{this.state.editPosition3 && (
										<EditPosition3
											show={this.state.editPosition3}
											closeEditPosition3={this.closeEditPosition3}
											submitEditPosition3={this.submitEditPosition3}
											data={this.state.editBannerData}
											selectedCatagory={this.state.selectedMainCatagory}
										/>
									)}

									{this.state.editPosition4 && (
										<EditPosition4
											show={this.state.editPosition4}
											closeEditPosition4={this.closeEditPosition4}
											submitEditPosition4={this.submitEditPosition4}
											data={this.state.editBannerData}
											selectedCatagory={this.state.selectedMainCatagory}
										/>
									)}

									{this.state.editPosition5 && (
										<EditPosition5
											show={this.state.editPosition5}
											closeEditPosition5={this.closeEditPosition5}
											submitEditPosition5={this.submitEditPosition5}
											data={this.state.editBannerData}
											selectedCatagory={this.state.selectedMainCatagory}
										/>
									)}

									{this.state.editPosition6 && (
										<EditPosition6
											show={this.state.editPosition6}
											closeEditPosition6={this.closeEditPosition6}
											submitEditPosition6={this.submitEditPosition6}
											data={this.state.editBannerData}
											selectedCatagory={this.state.selectedMainCatagory}
										/>
									)}

									{this.state.editPosition7 && (
										<EditPosition7
											show={this.state.editPosition7}
											closeEditPosition7={this.closeEditPosition7}
											submitEditPosition7={this.submitEditPosition7}
											data={this.state.editBannerData}
											selectedCatagory={this.state.selectedMainCatagory}
										/>
									)}

									{this.state.editPosition8 && (
										<EditPosition8
											show={this.state.editPosition8}
											closeEditPosition8={this.closeEditPosition8}
											submitEditPosition8={this.submitEditPosition8}
											data={this.state.editBannerData}
											selectedCatagory={this.state.selectedMainCatagory}
										/>
									)}

									{this.state.editPosition9 && (
										<EditPosition9
											show={this.state.editPosition9}
											closeEditPosition9={this.closeEditPosition9}
											submitEditPosition9={this.submitEditPosition9}
											data={this.state.editBannerData}
											selectedCatagory={this.state.selectedMainCatagory}
										/>
									)}

									{this.state.editPosition10 && (
										<EditPosition10
											show={this.state.editPosition10}
											closeEditPosition10={this.closeEditPosition10}
											submitEditPosition10={this.submitEditPosition10}
											data={this.state.editBannerData}
											selectedCatagory={this.state.selectedMainCatagory}
										/>
									)}

									{this.state.editPosition11 && (
										<EditPosition11
											show={this.state.editPosition11}
											closeEditPosition11={this.closeEditPosition11}
											submitEditPosition11={this.submitEditPosition11}
											data={this.state.editBannerData}
											selectedCatagory={this.state.selectedMainCatagory}
										/>
									)}

									<Modal
										dialogClassName="modal-dialog-centered"
										className="edit-user-modal cust-modal"
										size="xl"
										ref={(el) => {
											this.dialog = el;
										}}
										show={this.state.bannerNameEdit}
										onHide={this.editBannerClose}
									>
										<Modal.Header>
											<Modal.Title>
												<h1 className="modal-title">{titleLanguage.editBannerName}</h1>
											</Modal.Title>
											<button
												type="button"
												onClick={this.editBannerClose}
												className="close btn-close"
											></button>
										</Modal.Header>
										<Modal.Body>
											<div className="row">
												<div className="col-md-6 form-group">
													<label>{titleLanguage.BannerNameEnglish}</label>
													<input
														type="text"
														name="editBannerNameEnglish"
														value={this.state.editBannerNameEnglish}
														onChange={this.handleChange}
														className="form-control input-custom-class"
													/>
												</div>
												<div className="col-md-6 form-group">
													<label>{titleLanguage.BannerNameArabic}</label>

													<input
														type="text"
														name="editBannerNameArabic"
														value={this.state.editBannerNameArabic}
														onChange={this.handleChange}
														className="form-control input-custom-class"
													/>
												</div>
												<div className="col-md-12 text-center form-group">
													<button
														onClick={this.submitEditBannerName}
														className="red-btn"
													>
														{titleLanguage.Submit}
													</button>
												</div>
											</div>
										</Modal.Body>
									</Modal>
								</div>
							</div>
						</div>
					</Adminlayout>
				}
			</>
		);
	}
}

export default Master;
