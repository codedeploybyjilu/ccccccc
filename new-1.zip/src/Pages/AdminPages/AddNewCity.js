import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import plusicon from "../../images/plus-icn.svg";
import toastr from "toastr";
import LanguageContext from "../../contexts/languageContext";
import { Formik } from "formik";
import * as Yup from "yup";
import { API_Path, locationArabic, locationEnglish, productArabic, productEnglish } from "../../const";
import { PostApi } from "../../helper/APIService";
import { Router } from "react-router";
import { withRouter } from "react-router-dom";

export class AddNewCity extends Component {
  static contextType = LanguageContext;
  constructor(props) {
    super(props);
    this.state = {
      deliveryTimeApprox: "",
      shippingCompany: "",
      shippingCharges: "",
      cityEnglish: "",
      cityArabic: "",
      codStatus: true,
      onlineStatus: true,
      cityStatus: true,
      shippingCompanyData: []
    };
  }

  componentDidMount = () => {
    this.getShippingData();
    let id = window.location.href.substr(window.location.href.lastIndexOf("/") + 1);
    if (document.getElementById("online-status")) {
      document.getElementById("online-status").checked = true;
    }
    if (document.getElementById("cod-status")) {
      document.getElementById("cod-status").checked = true;
    }
    if (document.getElementById("city-status")) {
      document.getElementById("city-status").checked = true;
    }
    this.setState({ deliveryTimeApprox: 3, shippingCharges: 25 })
  };

  submitFormData = (formData, resetForm) => {
    let data = {
      english: formData.cityEnglish,
      arabic: formData.cityArabic,
      shipping_charge: formData.shippingCharges,
      delivery_time: formData.deliveryTimeApprox,
      shipping_company: formData.shippingCompany,
      cod_status: this.state.codStatus,
      online_status: this.state.onlineStatus,
    }

    let path = API_Path.addShippingCity
    const addShippingCityPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    addShippingCityPromise.then((res) => {
      if (res) {
        toastr.success(res.data.message)
        // this.props.history.push('/location')
      } else {
        toastr.error(res.data.message)
      }
    });
  };

  getShippingData = () => {

    let data = {};
    let path = API_Path.getShippingCompany;
    const getShippingDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getShippingDataPromise.then((res) => {
      if (res) {
        this.setState({ shippingCompanyData: res.data.data, shippingCompany: res.data.data[0].id?.toString() });
      }
    });
  };

  errorContainer = (form, field) => {
    return form.touched[field] && form.errors[field] ? <span className="error text-danger">{form.errors[field]}</span> : null;
  };

  formAttr = (form, field) => ({
    onBlur: form.handleBlur,
    onChange: form.handleChange,
    value: form.values[field],
  });

  handleCheckBox = (e) => {
    this.setState({ [e.target.name]: e.target.checked });
  };

  render() {
    let locationLanguage = this.context.language === "english" ? locationEnglish : locationArabic;
    let productLanguage = this.context.language === "english" ? productEnglish : productArabic;
    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space">
            <div className="col-lg-6" >
              <div className="row">
                <div className="col-12 mb-3">
                  <div className="d-flex align-items-center">
                    <div className="common-header-txt">
                      <h3>City Details</h3>
                    </div>
                    <label className="switch ms-auto pop-switch">
                      <input name="cityStatus" id="city-status" type="checkbox" onChange={this.handleCheckBox} value={this.state.cityStatus} />
                      <div className="slider round" />
                      <span className="text" />
                    </label>
                  </div>
                </div>
                <div className="col-12">
                  <div className="white-box">
                    <Formik
                      innerRef={this.runforms}
                      enableReinitialize
                      initialValues={{
                        cityEnglish: "",
                        cityArabic: "",
                        shippingCharges: this.state.shippingCharges,
                        shippingCompany: this.state.shippingCompany,
                        deliveryTimeApprox: this.state.deliveryTimeApprox,
                      }}
                      validationSchema={Yup.object({
                        cityEnglish: Yup.string().required("Required."),
                        cityArabic: Yup.string().required("Required."),
                      })}
                      onSubmit={(formData, { resetForm }) => {
                        this.submitFormData(formData, resetForm);
                      }}
                    >
                      {(runform) => (
                        <form onSubmit={runform.handleSubmit} autoComplete="off">
                          <div className="row modal-form">
                            <div className="col-md-6 form-group">
                              <label>{locationLanguage.cityNameinEnglish}</label>
                              <input name="cityEnglish" {...this.formAttr(runform, "cityEnglish")} className="form-control" placeholder="Abha" />
                              {this.errorContainer(runform, "cityEnglish")}
                            </div>
                            <div className="col-md-6 form-group">
                              <label>{locationLanguage.cityNameinArabic}</label>
                              <input name="cityArabic" {...this.formAttr(runform, "cityArabic")} className="form-control" placeholder="Azizia" />
                              {this.errorContainer(runform, "cityArabic")}
                            </div>
                            <div className="col-md-6 form-group form-group d-flex align-items-center mb-3">
                              <label>{locationLanguage.COD}</label>
                              <label className="switch ms-auto pop-switch">
                                <input name="codStatus" value={this.state.codStatus} id="cod-status" onChange={this.handleCheckBox} type="checkbox" />
                                <div className="slider round" />
                                <span className="text" />
                              </label>
                            </div>
                            <div className="col-md-6 form-group form-group d-flex align-items-center mb-3">
                              <label>{locationLanguage.onlinePayment}</label>
                              <label className="switch ms-auto pop-switch">
                                <input name="onlineStatus" value={this.state.onlineStatus} id="online-status" onChange={this.handleCheckBox} type="checkbox" />
                                <div className="slider round" />
                                <span className="text" />
                              </label>
                            </div>
                            <div className="col-md-6 form-group">
                              <label>{locationLanguage.shippingCharges}(SR)</label>
                              <input name="shippingCharges" type="number" className="form-control" placeholder="SR100"  {...this.formAttr(runform, "shippingCharges")} />
                            </div>
                            <div className="col-md-6 form-group">
                              <label>{locationLanguage.deliveryTimeApprox}</label>
                              <input name="deliveryTimeApprox" type="number" className="form-control"  {...this.formAttr(runform, "deliveryTimeApprox")} />
                            </div>
                            <div className="col-md-12 form-group">
                              <label>{locationLanguage.shippingCompany}(default)</label>
                              <select name="shippingCompany" {...this.formAttr(runform, "shippingCompany")} className="form-select form-control">
                                {this.state.shippingCompanyData &&
                                  this.state.shippingCompanyData.map((item, i) => {
                                    return (
                                      <option value={item.id} key={item.id}>
                                        {item.english}
                                      </option>
                                    );
                                  })}
                              </select>
                              {this.errorContainer(runform, "shippingCompany")}
                            </div>
                            <div className="col-md-12 text-end form-group my-3">
                              <button id="addCityData" type="submit" className="btn red-btn px-5">
                                {locationLanguage.save}
                              </button>
                            </div>
                          </div>
                        </form>
                      )}
                    </Formik>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Adminlayout >
    );
  }
}
export default withRouter(AddNewCity);