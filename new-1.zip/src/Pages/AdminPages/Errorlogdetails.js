import React, { Component } from 'react';
import Adminlayout from '../../Components/AdminLayout/Adminlayout';
import { TableFieldArabic, TableFieldEnglish, titleArabic, titleEnglish } from '../../const';
import LanguageContext from '../../contexts/languageContext'

class Errorlogdetails extends Component {
    static contextType = LanguageContext;
    render() {
        let Language = this.context.language === 'english' ? TableFieldEnglish : TableFieldArabic
        let titleLanguage = this.context.language === 'english' ? titleEnglish : titleArabic
        return (
            <Adminlayout>
                <div className="container-fluid">
                    <div className="row common-space">
                        <div className="col-sm-12 text-sm-start text-center rtl-txt-start">
                            <div className="common-header-txt">
                                <h3>{titleLanguage.errorLogDetail}</h3>
                            </div>
                        </div>
                    </div>
                    <div className="row common-space">
                        <div className="col-md-12">
                            <div className="white-box">
                                <form className="row cust-form-user">
                                    <div className="form-group col-md-6">
                                        <label>{Language.id}</label>
                                        <input type="number" className="form-control" value="1" readOnly />
                                    </div>

                                    <div className="form-group col-md-6">
                                        <label>{Language.dateTime}</label>
                                        <input type="text" className="form-control" value="25/09/2021 at 7:00 PM" readOnly />
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>{Language.deviceName}</label>
                                        <input type="text" className="form-control" value="OnePlus 6T" readOnly />
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>{Language.modelName}</label>
                                        <input type="text" className="form-control" value="6T" readOnly />
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>{Language.osVersion}</label>
                                        <input type="text" className="form-control" value="OnePlus Node CE" readOnly />
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>{Language.appVersion}</label>
                                        <input type="text" className="form-control" value="Cordova App Version docs" readOnly />
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </Adminlayout>
        );
    }
}

export default Errorlogdetails;