import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import ProfileImg from "../../images/img-preview.png";
import eyeCLose from "../../images/eye-close.svg";
import eyeOpen from "../../images/eye-show.svg";
import {
  buttonEnglish,
  buttonArabic,
  settingEnglish,
  settingArabic,
} from "../../const";
import LanguageContext from "../../contexts/languageContext";
// import jwt from 'jsonwebtoken';
import { jwtDecode } from "jwt-decode";

class Profile extends Component {
  static contextType = LanguageContext;
  state = {
    fullName: "",
    email: "",
    phone: "",
    img: "",
  };

  password = () => {
    document.getElementById("passtoggler").classList.toggle("active");
    var x = document.getElementById("password");
    if (x.type === "password") {
      x.type = "text";
    } else {
      x.type = "password";
    }
  };
  password2 = () => {
    document.getElementById("passtoggler2").classList.toggle("active");
    var x = document.getElementById("password2");
    if (x.type === "password") {
      x.type = "text";
    } else {
      x.type = "password";
    }
  };
  password3 = () => {
    document.getElementById("passtoggler3").classList.toggle("active");
    var x = document.getElementById("password3");
    if (x.type === "password") {
      x.type = "text";
    } else {
      x.type = "password";
    }
  };

  componentDidMount() {
    let token = localStorage.getItem("_a_token");
    var decoded = jwtDecode(token);
    let fullName = decoded.data[0].first_name;
    let email = decoded.data[0].email;
    let phone = decoded.data[0].phone;
    this.setState({ fullName, email, phone });
  }

  render() {
    let settingLanguage =
      this.context.language === "english" ? settingEnglish : settingArabic;
    let ButtonLanguage =
      this.context.language === "english" ? buttonEnglish : buttonArabic;
    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space">
            <div className="col-md-12">
              <div className="white-box">
                <div className="common-header-txt d-flex align-items-center header-profile-line">
                  <h3 className="mb-0">{settingLanguage.PersonalDetails}</h3>
                  <div className="rounded-circle-edit">
                    <svg
                      width={15}
                      height={15}
                      viewBox="0 0 19 19"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
                        fill="#2D2D3B"
                      />
                    </svg>
                  </div>
                </div>
                <div className="img-upload">
                  <div className="avatar-preview">
                    <div id="imagePreview">
                      <img src={ProfileImg} alt="" />
                    </div>
                  </div>
                  <div className="avtar-txt">
                    <p>{settingLanguage.Uploadyourprofile}</p>
                    <span>{ButtonLanguage.uploadimagemaxsize} 256*256px.</span>
                    <div className="avatar-edit">
                      <input
                        className="d-none"
                        type="file"
                        id="imageUpload"
                        accept=".png, .jpg, .jpeg"
                      />
                      <label
                        className="btn red-btn  mt-3"
                        htmlFor="imageUpload"
                      >
                        <i className="bi bi-upload me-2" />{" "}
                        {ButtonLanguage.Uploadimage}
                      </label>
                    </div>
                  </div>
                </div>
                <form className="row">
                  <div className="form-group col-md-4">
                    <label>{settingLanguage.FullName}</label>
                    <input
                      type="text"
                      readOnly
                      value={this.state.fullName}
                      className="form-control input-custom-class w-100"
                      placeholder="Ex. John deo"
                    />
                  </div>
                  <div className="form-group col-md-4">
                    <label>{settingLanguage.EmailAddress}</label>
                    <input
                      type="email"
                      readOnly
                      value={this.state.email}
                      className="form-control input-custom-class w-100"
                      placeholder="Ex. Johndeo@gmail.com"
                    />
                  </div>
                  <div className="form-group col-md-4">
                    <label>Mobile Number</label>
                    <input
                      type="tel"
                      readOnly
                      value={this.state.phone}
                      className="form-control input-custom-class w-100"
                      placeholder="Ex. 123 465 7892"
                    />
                  </div>
                </form>
              </div>
            </div>
          </div>

          <div className="row common-space">
            <div className="col-md-12">
              <div className="white-box">
                <div className="common-header-txt d-flex align-items-center header-profile-line">
                  <h3 className="mb-0">Change Password</h3>
                  <div className="rounded-circle-edit">
                    <svg
                      width={15}
                      height={15}
                      viewBox="0 0 19 19"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
                        fill="#2D2D3B"
                      />
                    </svg>
                  </div>
                </div>
                <form className="row mt-5">
                  <div
                    className="form-group col-md-4 position-relative pass-main-click"
                    id="passtoggler"
                  >
                    <label>{settingLanguage.Oldpassword}</label>
                    <input
                      type="password"
                      className="form-control input-custom-class"
                      placeholder="******"
                      id="password"
                    />
                    <label
                      className="input-right-icon pass-show-hide mb-0"
                      onClick={this.password}
                    >
                      <img src={eyeCLose} className="pass-close-image" alt="" />
                      <img src={eyeOpen} className="pass-show-image" alt="" />
                    </label>
                  </div>
                  <div
                    className="form-group col-md-4 position-relative pass-main-click"
                    id="passtoggler2"
                  >
                    <label>{settingLanguage.Newpassword}</label>
                    <input
                      type="password"
                      className="form-control input-custom-class"
                      placeholder="******"
                      id="password2"
                    />
                    <label
                      className="input-right-icon pass-show-hide mb-0"
                      onClick={this.password2}
                    >
                      <img src={eyeCLose} className="pass-close-image" alt="" />
                      <img src={eyeOpen} className="pass-show-image" alt="" />
                    </label>
                  </div>
                  <div
                    className="form-group col-md-4 position-relative pass-main-click"
                    id="passtoggler3"
                  >
                    <label>{settingLanguage.Confirmpassword}</label>
                    <input
                      type="password"
                      className="form-control input-custom-class"
                      placeholder="******"
                      id="password3"
                    />
                    <label
                      className="input-right-icon pass-show-hide mb-0"
                      onClick={this.password3}
                    >
                      <img src={eyeCLose} className="pass-close-image" alt="" />
                      <img src={eyeOpen} className="pass-show-image" alt="" />
                    </label>
                  </div>
                </form>
              </div>
            </div>

            <div className="col-md-12 mt-3 text-md-start text-center rtl-txt-start">
              <button className="btn red-btn">{settingLanguage.Save}</button>
            </div>
          </div>
        </div>
      </Adminlayout>
    );
  }
}

export default Profile;
