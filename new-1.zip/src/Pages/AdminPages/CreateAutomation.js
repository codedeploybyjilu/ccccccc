import React, { Component, useState } from 'react';
import Adminlayout from '../../Components/AdminLayout/Adminlayout';
import TriggerIco from "../../images/trigger-ico.svg";
import EditIco from "../../images/edit-ico-automation.svg";
import DeleteIco from "../../images/delete-ico-automation.svg";
import PlusIco from "../../images/plus-icon-gray.svg";
import PushIco from "../../images/push-notification-ico.svg";
import SendPush from "../../images/send-push-notification-ico.svg";
import DelayIco from "../../images/delay-ic-gray.svg";
import PlusIcoFill from "../../images/plus-icon-fill.svg";
import { Modal } from 'react-bootstrap';

class CreateAutomation extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectaudience_modal: false,
        }
    }

    selectaudience_modal = () => {
        this.setState({ selectaudience_modal: true })
    }

    selectaudience_close = () => {
        this.setState({ selectaudience_modal: false })
    }

    render() {
        return (
            <Adminlayout>
                <div className="container-fluid container-auto-height d-none">
                    <div className='row h-100 align-items-center'>
                        <div className='col-12 h-100'>
                            <div className='text-center h-100 d-flex flex-column justify-content-center align-items-center'>
                                <span className='span-block text-automation-info'>Build a new workflow automation</span>
                                <div className='pt-3'>
                                    <button className="btn red-btn" type="button">
                                        Add Trigger
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="container-fluid">
                    <div className="row common-space">
                        <div className="col-sm-6 text-sm-start text-center rtl-txt-start">
                            <div className="common-header-txt mb-sm-0 mb-2">
                                <h3>
                                    Automations
                                </h3>
                            </div>
                        </div>
                        <div className='col-sm-6 ms-md-auto text-sm-end text-center rtl-txt-end'>
                            <div className="d-flex align-items-center justify-content-sm-end justify-content-center tabs-campn-info-main">
                                <div className="form-check form-switch me-3 d-flex align-items-center">
                                    <input className="form-check-input" name="sheduleNotification" type="radio" id="Now" />
                                    <label className="form-check-label ms-2" htmlFor="Now">Active</label>
                                </div>
                                <button className="btn black-btn me-2" type="button">Close</button>
                                <button className="btn red-btn" type="button">Save</button>
                            </div>
                        </div>
                    </div>
                    <div className='row common-space'>
                        <div className='col-xxl-4 d-xxl-block d-none'>
                        </div>
                        <div className='col-xxl-4 col-lg-5 col-md-6 ms-lg-auto'>
                            <div className='trigger-section-center'>
                                <div className='trigger-ctr-blank'>
                                    <div className='trigger-ctr-list'>
                                    </div>
                                    <div className='text-center trigger-ctr-icons mx-auto'>
                                        <bdi className='d-inline-block'></bdi>
                                        <div className='trigger-ctr-icons-div mx-auto'>
                                            <button type='button' className='border-0 p-0 bg-transparent'>
                                                <img src={PlusIco} alt="automations" />
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <>
                                    <div className='mt-4'>
                                        <>
                                            <div className='trigger-ctr-fill-space'>
                                                <div className='trigger-ctr-fill position-relative'>
                                                    <div className='text-center trigr-info-fix'>
                                                        <div className='trigr-info-top'>Trigger</div>
                                                    </div>
                                                    <div className='d-flex align-items-lg-center trigger-ctr-fill-list'>
                                                        <img src={TriggerIco} alt="automations" />
                                                        <p className='mb-0'>
                                                            When a user is added to a segment
                                                        </p>
                                                    </div>
                                                    <div className='trigger-btns-fix'>
                                                        <button type='button' className='border-0 p-0 bg-transparent my-1'>
                                                            <img src={EditIco} alt="automations" />
                                                        </button>
                                                        <button type='button' className='border-0 p-0 bg-transparent my-1'>
                                                            <img src={DeleteIco} alt="automations" />
                                                        </button>
                                                    </div>
                                                </div>
                                                <div className='text-center trigger-ctr-icons mx-auto'>
                                                    <bdi className='d-inline-block'></bdi>
                                                    <div className='trigger-ctr-icons-div mx-auto'>
                                                        <button type='button' className='border-0 p-0 bg-transparent'>
                                                            <img src={PlusIcoFill} alt="automations" />
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <>
                                                <>
                                                    <div className='text-center trigger-ctr-icons'>
                                                        <bdi className='d-inline-block'></bdi>
                                                    </div>
                                                    <div className='trigger-ctr-blank'>
                                                        <div className='trigger-ctr-list'>
                                                        </div>
                                                        <div className='text-center trigger-ctr-icons mx-auto'>
                                                            <bdi className='d-inline-block'></bdi>
                                                            <div className='trigger-ctr-icons-div mx-auto'>
                                                                <button type='button' className='border-0 p-0 bg-transparent'>
                                                                    <img src={PlusIco} alt="automations" />
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </>

                                                <>
                                                    <div className='text-center trigger-ctr-icons'>
                                                        <bdi className='d-inline-block'></bdi>
                                                    </div>
                                                    <div className='trigger-ctr-fill-space mt-2'>
                                                        <div className='trigger-ctr-fill position-relative'>
                                                            <div className='text-center trigr-info-fix'>
                                                                <div className='trigr-info-top trigr-action-color trigr-action2-color'>action</div>
                                                            </div>
                                                            <>
                                                                <div className='d-flex align-items-lg-center trigger-ctr-fill-list'>
                                                                    <img src={DelayIco} alt="automations" />
                                                                    <p className='mb-0'>
                                                                        Delay for minutes
                                                                    </p>
                                                                </div>
                                                            </>

                                                            {/* <>
                                                                <div className='d-flex align-items-lg-center trigger-ctr-fill-list'>
                                                                    <img src={SendPush} alt="automations" />
                                                                    <p className='mb-0'>
                                                                        Send push notification
                                                                    </p>
                                                                </div>
                                                                <div className='push-ntfc-main'>
                                                                    <div className='push-ntfc-info d-flex align-items-center'>
                                                                        <img src='{item.notification_data.image}' alt="automations" />
                                                                        <div className='overflow-hidden'>
                                                                            <bdi className='d-block'>45</bdi>
                                                                            <p className='mb-0'>6</p>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            </> */}
                                                            <div className='trigger-btns-fix'>
                                                                <button type='button' className='border-0 p-0 bg-transparent my-1'>
                                                                    <img src={EditIco} alt="automations" />
                                                                </button>
                                                                <button type='button' className='border-0 p-0 bg-transparent my-1'>
                                                                    <img src={DeleteIco} alt="automations" />
                                                                </button>
                                                            </div>
                                                        </div>
                                                        <div className='text-center trigger-ctr-icons mx-auto'>
                                                            <bdi className='d-inline-block'></bdi>
                                                            <div className='trigger-ctr-icons-div mx-auto'>
                                                                <button type='button' className='border-0 p-0 bg-transparent'>
                                                                    <img src={PlusIcoFill} alt="automations" />
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </>
                                            </>
                                        </>
                                    </div>
                                </>
                            </div>
                        </div>
                        <div className='col-xxl-4 col-lg-5 col-md-6 ms-auto'>
                            <div className="trigger-section-div">
                                {/* ----------- trigger section ----------- */}
                                <div className='trigger-section-list'>
                                    <div className='trigger-section-hdr d-flex'>
                                        <div className='trigger-hdr-left'>1</div>
                                        <div>
                                            <div className='trigger-hdr-right-top'>Trigger</div>
                                            <div className='trigger-hdr-right-bottom'>Select the triggering condition from where you want to automate</div>
                                        </div>
                                    </div>
                                    <div className='mt-4'>
                                        <div className='trigger-section-ctr-scroll'>
                                            <bdi className='d-block acts-text pb-3'>Actions</bdi>
                                            <div className=''>
                                                <div onClick={() => this.selectaudience_modal()} className="d-flex trigger-actions-list">
                                                    <img src={TriggerIco} loading='lazy' alt="automations" />
                                                    <p className='mb-0'>
                                                        When a user is added to a segment
                                                    </p>
                                                </div>
                                                <div className="d-flex trigger-actions-list">
                                                    <img src={TriggerIco} loading='lazy' alt="automations" />
                                                    <p className='mb-0'>
                                                        When a user adds something to the cart
                                                    </p>
                                                </div>
                                                <div className="d-flex trigger-actions-list">
                                                    <img src={TriggerIco} loading='lazy' alt="automations" />
                                                    <p className='mb-0'>
                                                        When places an order
                                                    </p>
                                                </div>
                                                <div className="d-flex trigger-actions-list">
                                                    <div className='w-100'>
                                                        <div className='d-flex align-items-center'>
                                                            <img src={TriggerIco} loading='lazy' alt="automations" />
                                                            <p className='mb-0'>
                                                                When order status change
                                                            </p>
                                                        </div>
                                                        <div className='pt-3'>
                                                            <select id="order_status_dropdown" className="form-select input-custom-class">
                                                                <option selected disabled value="" >Choose order status</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className='align-items-center d-flex justify-content-end mt-2'>
                                        <button className='btn black-btn' type='button'>Cancel</button>
                                        <button className='btn red-btn' type="button">Apply Trigger</button>
                                    </div>
                                </div>

                                {/* ----------- action section ----------- */}
                                <div className='trigger-section-list d-none'>
                                    <div className='trigger-section-hdr d-flex'>
                                        <div className='trigger-hdr-left'>2</div>
                                        <div>
                                            <div className='trigger-hdr-right-top'>Action</div>
                                            <div className='trigger-hdr-right-bottom'>Choose action to be performed after trigger</div>
                                        </div>
                                    </div>
                                    <div className='mt-4'>
                                        <div className='trigger-section-ctr-scroll'>
                                            <div className="btn-group trigger-actions-radios flex-column w-100">
                                                <input type="radio" className="btn-check" name="btnradio" id="btnradio1" autocomplete="off" value="delay_time" />
                                                <label className="btn btn-outline-primary delay-info-btn" htmlFor="btnradio1">
                                                    <div className='d-flex trigger-actions-list'>
                                                        <img src={DelayIco} alt="automations" />
                                                        <p className='mb-0'>
                                                            Delay
                                                        </p>
                                                    </div>
                                                </label>
                                                <input type="radio" className="btn-check" name="btnradio" id="btnradio2" autocomplete="off" value="push" />
                                                <label className="btn btn-outline-primary notification-info-btn" htmlFor="btnradio2">
                                                    <div className='d-flex trigger-actions-list'>
                                                        <img src={PushIco} alt="automations" />
                                                        <p className='mb-0'>
                                                            Push notification
                                                        </p>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div className='align-items-center d-flex justify-content-end mt-2'>
                                        <button className='btn black-btn' type="button">Cancel</button>
                                        <button className='btn red-btn' type="button">Next</button>
                                    </div>
                                </div>

                                {/* ------------- action delay section ----------- */}
                                <div className='trigger-section-list d-none'>
                                    <div className='trigger-section-hdr d-flex'>
                                        <div className='trigger-hdr-left'>2</div>
                                        <div>
                                            <div className='trigger-hdr-right-top'>Action - Delay</div>
                                            <div className='trigger-hdr-right-bottom'>Select a predefined time or enter a custom
                                                time to delay the action</div>
                                        </div>
                                    </div>
                                    <div className='mt-4'>
                                        <div className='trigger-section-ctr-scroll'>
                                            <bdi className='d-block acts-text pb-3'>Duration (Required)</bdi>
                                            <div className='pb-3'>
                                                <label class="cust-radio mb-0 d-inline-block me-4">
                                                    <input type="radio" id="Predefined" name="Duration" value="0" />
                                                    <span class="checkmark"></span>
                                                    <span>Predefined </span>
                                                </label>
                                                <label class="cust-radio mb-0 d-inline-block me-4">
                                                    <input type="radio" id="Custom" name="Duration" value="1" />
                                                    <span class="checkmark"></span>
                                                    <span>Custom </span>
                                                </label>
                                            </div>
                                            <div className="">
                                                <select className="form-select input-custom-class form-select-duration" id="" >
                                                    <option selected disabled value="">Select predefined duration</option>
                                                    <option value="1800">30 minutes</option>
                                                    <option value="14400">4 hours</option>
                                                    <option value="86400">1 day</option>
                                                    <option value="172800">2 day</option>
                                                    <option value="259200">3 day</option>
                                                    <option value="345600">4 day</option>
                                                    <option value="432000">5 day</option>
                                                    <option value="518400">6 day</option>
                                                    <option value="604800">7 day</option>
                                                    <option value="1209600">2 weeks</option>
                                                    <option value="1814400">3 weeks</option>
                                                    <option value="2419200">4 weeks</option>
                                                </select>
                                            </div>
                                            <div className="">
                                                <div className='row me-0'>
                                                    <div className='col-4 pe-0'>
                                                        <input type="number" className="form-control input-custom-class form-select-duration" />
                                                    </div>
                                                    <div className='col-4 pe-0'>
                                                        <select className="form-select input-custom-class form-select-duration" id="">
                                                            <option selected disabled value="">Select</option>
                                                            <option value="1">Minute(s)</option>
                                                            <option value="2">hour(s)</option>
                                                            <option value="3">day(s)</option>
                                                            <option value="4">weeks(s)</option>
                                                        </select>
                                                    </div>
                                                    <div className='col-12'>
                                                        <div className="cust-checkbox-new pt-2">
                                                            <label className="cust-chk-bx">
                                                                <input type="checkbox" id="" name="" />
                                                                <span className="cust-chkmark m-0 p-0"></span> Skip weekends
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className='d-flex align-items-center'>
                                        <button style={{ color: '#a81a1c' }} className='fw-bold d-flex align-items-center bg-transparent p-0 border-0' type="button">
                                            <svg className='me-2' width="16" height="12" viewBox="0 0 16 12" fill="none">
                                                <path d="M3.83 5L7.41 1.41L6 0L0 6L6 12L7.41 10.59L3.83 7H16V5H3.83Z" fill="#a81a1c" />
                                            </svg>
                                            Back
                                        </button>
                                        <button className='btn black-btn ms-auto' type="button">Cancel</button>
                                        <button className='btn red-btn' type="button">Apply Action</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <Modal show={this.state.selectaudience_modal} className="cust-modal signout-modal" onHide={this.selectaudience_close} size="md" centered>
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">Select Audience</h1>
                        </Modal.Title>
                        <button
                            type="button"
                            onClick={this.selectaudience_close}
                            className="close btn-close"
                        ></button>
                    </Modal.Header>
                    <Modal.Body>
                        <form className=''>
                            <div className='form-group mb-3'>
                                <select className="form-select input-custom-class" id="">
                                    <option selected>Choose...</option>
                                    <option value="1">One</option>
                                    <option value="2">Two</option>
                                    <option value="3">Three</option>
                                </select>
                            </div>
                            <div className='form-group py-3 text-center'>
                                <button type='button' className='btn black-btn me-3'>Cancel</button>
                                <button style={{ padding: '10px 25px' }} type='button' className='btn red-btn'>submit</button>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>

            </Adminlayout >
        );
    }
}

export default CreateAutomation;