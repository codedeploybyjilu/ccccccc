import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import DataTable from "../../Components/DataTable";
import { textFilter } from "react-bootstrap-table2-filter";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";
import { DateRangePicker } from 'react-date-range';
import { Dropdown, Modal } from "react-bootstrap";
import {
	buttonArabic,
	buttonEnglish,
	SidebarArabic,
	SidebarEnglish,
	UserEnglish,
	UserArabic,
	AdminEnglish,
	AdminArabic,
	orderEnglish,
	orderArabic,
	TableFieldArabic,
	TableFieldEnglish,
	titleArabic,
	titleEnglish,
	notificationEnglish,
	notificationArabic,
	API_Path,
	marketingArabic,
	marketingEnglish,
} from "../../const";
import LanguageContext from "../../contexts/languageContext";
import { GetApi, PostApi } from "../../helper/APIService";
import { withRouter } from "react-router-dom";
import toastr from "toastr";
import moment from "moment";
import PhoneInput from 'react-phone-input-2';
import 'react-phone-input-2/lib/style.css';
import { CSVLink } from "react-csv";
import { Link } from "react-router-dom";

class Users extends Component {
	static contextType = LanguageContext;
	constructor(props) {
		super(props);
		this.state = {
			page: 1,
			sizePerPage: 50,
			totalSize: 1000,
			defaultSorted: [{
				dataField: "id",
				order: "desc",
			}],
			searchText: '',
			search_val: {
				address: '',
				email: '',
				name: ''
			},
			user_data: [],
			filter: {},
			editCustomerData: '',
			editCustomerName: '',
			editCustomerLName: '',
			editCustomerNumber: '',
			editCustomerEmail: '',
			editCustomerGender: '',
			editCustomerLaguage: '',
			editCustomerDOB: '',
			editCustomerMark: '',
			editCustomerAddress: '',
			customerId: '',
			userDetail: '',
			customerName: '',
			customerPhone: '',
			emailId: '',
			lastOrdered: '',
			amountSpentFrom: '',
			amountSpentTo: '',
			walletAmountFrom: '',
			walletAmountTo: '',
			OrdersFrom: '',
			OrdersTo: '',
			returnsFrom: '',
			returnsTo: '',
			customerMark: '',
			CityData: '',
			constcityData: '',
			selectedCityAr: '',
			selectedCityEn: '',
			constAreaData: '',
			selectedAreaEn: '',
			selectedAreaAr: '',
			areaData: '',
			areaID: '',
			CityId: '',
			selectionRange: {
				startDate: new Date(),
				endDate: new Date(),
				key: 'selection',
			},
			csvEportData: ''
		};
	}

	componentDidMount() {
		this.getUserData();
		this.getUserExportData()
	}


	getUserExportData = () => {
		new Promise((resolve) => {
			resolve(PostApi(API_Path.exportUserData))
		}).then((res) => {
			let ResData = res.data.resdata
			// let arr=[]
			for (let i = 0; i < ResData.length; i++) {
				ResData[i].status = ResData[i].status == 1 ? 'Active' : 'Deactive'
				ResData[i].return_order = !ResData[i].return_order ? 0 : ResData[i].return_order
				ResData[i].total_order = !ResData[i].total_order ? 0 : ResData[i].total_order
				ResData[i].createdat = moment(ResData[i].createdat).format("DD/MM/YYYY hh:mm A")
				ResData[i].days = !ResData[i].days ? '0 Days' : ResData[i].days + 'Days'
			}
			this.setState({ csvEportData: ResData })
			// console.log(res.data.resdata, "[==]");
		})
	}

	getUserData = (filter, date) => {
		const data = {
			sizePerPage: this.state.sizePerPage,
			page: this.state.page,
			defaultSorted: this.state.defaultSorted,
			searchText: this.state.searchText,
			search_val: filter ? filter : '',
			from: date && date.from,
			to: date && date.to
		}
		const getUserDataPromise = new Promise((resolve) => {
			resolve(PostApi(API_Path.getUserData, data))
		});
		getUserDataPromise.then((res) => {
			if (res.data.success) {
				this.setState({ user_data: res.data.data, totalSize: res.data.totalRecord })
			}
		})
	}

	selectmonthmodalShow = () => {
		this.setState({ selectmonthmodal: true });
	};

	selectmonthmodalclose = () => {
		this.setState({ selectmonthmodal: false });
	};

	filter_handleShow = (e) => {
		this.setState({ filter_show: true }, () => {
			this.getCityData()
		});
	};

	filterClose = (e) => {
		this.setState({ filter_show: false });
	};

	handleSearchValue = (e) => {
		this.setState({ searchText: e.target.value, page: 1 }, () => {
			this.getUserData()
		})
	}

	edit_userClose = () => {
		this.setState({ search_show: false });
	};

	edit_handleShow = (e, data) => {
		e.preventDefault();

		const GetUserDetailsPromise = new Promise((resolve) => {
			resolve(PostApi(API_Path.getUserDetails, { user_id: data.id }));
		});

		GetUserDetailsPromise.then((res) => {
			console.log(res.data.data[0], "///");
			if (res) {
				this.setState({ userDetail: res.data.data[0] }, () => {
					let userData = this.state.userDetail
					this.setState({
						search_show: true,
						editCustomerName: userData.first_name,
						editCustomerLName: userData.last_name,
						editCustomerNumber: userData.phone.substring(0, 3) !== '966' ? '966' + userData.phone : userData.phone,
						editCustomerEmail: userData.email,
						editCustomerMark: userData.mark,
						editCustomerGender: userData.gender,
						customerId: userData.id,
						editCustomerLaguage: userData.language,
						editCustomerDOB: moment(userData.date_of_birth).format('YYYY-MM-DD')
					}, () => {
						document.getElementById(userData.mark).checked = true
					});
				});
			}
		});

		// console.log(e, "data::", data);
	};

	delete_record = (id) => {
		confirmAlert({
			customUI: ({ onClose }) => {
				return (
					<div className="custom-ui">
						<h1>Are you sure?</h1>
						<p>You want to delete this file?</p>
						<button className="btn red-btn me-2" onClick={onClose}>No</button>
						<button className="btn red-btn" onClick={() => { this.finaly_delete_record(id); onClose(); }}>Yes, Delete it!</button>
					</div>
				);
			},
		});
	};

	handleChange = (e) => {
		this.setState({ [e.target.name]: e.target.value });
	};

	handleSelect = (data) => {
		this.setState({ selectionRange: data.selection })
	}

	finaly_delete_record = (id) => {
		alert(id);
	};

	handleTableChange = (type, { page, sizePerPage, filters, sortField, sortOrder }) => {
		switch (type) {
			case "pagination":
				this.setState({ page, sizePerPage }, () => this.getUserData());
				break;
			case "sort":
				this.setState({ defaultSorted: [{ dataField: sortField, order: sortOrder }] },
					() => this.getUserData()
				);
				break;
			default:
				break;
		}
		return true;
	};

	userDetail = (userId) => {
		console.log(userId)
		this.props.history.push("/user-details/" + userId)
	}

	changeDelay = (e) => {
		if (this.state.timer) {
			clearTimeout(this.state.timer);
			this.setState({ timer: null });

		}
		this.setState({
			timer:
				setTimeout(() => {
					let tempFilter = this.state.filter;
					tempFilter[e.target.name] = e.target.value;
					this.setState({ filter: tempFilter })
				}, 2500)
		});
	}

	handleEditCustomerChange = (e) => {
		this.setState({ [e.target.name]: e.target.value })
	}

	handleEditMarkChange = (e) => {
		this.setState({ editCustomerMark: e.target.id })
	}

	handleEditPhoneChange = (phone) => {
		this.setState({ editCustomerNumber: phone }, () => {
			console.log(this.state.editCustomerNumber);
		})
	}

	SaveEditCustomerData = () => {
		let data = {
			first_name: this.state.editCustomerName,
			// last_name: this.state.editCustomerLName,
			phone: this.state.userDetail.phone.substring(0, 3) !== '966' ? this.state.editCustomerNumber.substring(3) : this.state.editCustomerNumber,
			email: this.state.editCustomerEmail,
			gender: this.state.editCustomerGender,
			language: this.state.editCustomerLaguage,
			date_of_birth: this.state.editCustomerDOB,
			mark: this.state.editCustomerMark,
			user_id: this.state.customerId
		}
		console.log(data, "::::data");
		new Promise((resolve) => {
			resolve(PostApi(API_Path.editCostmerData, data))
		}).then((res) => {
			console.log(res, "edit Data");
			if (res.data.success === true) {
				toastr.success(res.data.message)
				this.getUserData()
				this.edit_userClose()
			}
		})
	}
	getCityData = (value) => {
		let data = { search_val: value };

		let path = API_Path.getCityData;
		const getCityDataPromise = new Promise((resolve) => {
			resolve(PostApi(path, data));
		});

		getCityDataPromise.then((res) => {
			if (res.data.success) {
				this.setState({ CityData: res.data.data, constcityData: res.data.data }, () => {
					// this.state.CityData.map((item, i) => {
					//     if (i === 0) {
					//         this.setState({ city: item.id });
					//     }
					// });
				});
			}
		});
	};
	selectCity = (data) => {
		this.setState({ selectedCityEn: data.english, selectedCityAr: data.arabic, CityId: data.id }, () => {
			this.GetArea(data.id)
		})
	}
	GetArea = (value) => {
		let data = { city_id: value };

		let path = API_Path.getArea;
		const getAreaDataPromise = new Promise((resolve) => {
			resolve(PostApi(path, data));
		});

		getAreaDataPromise.then((res) => {
			if (res.data.success) {
				this.setState({ areaData: res.data.data, constAreaData: res.data.data }, () => {
					// this.state.areaData.map((item, i) => {
					//     if (i === 0) {
					//         this.setState({ area: item.id });
					//     }
					// });
				});
			}
		});
	};
	selectArea = (data) => {
		this.setState({ selectedAreaEn: data.english, selectedAreaAr: data.arabic, areaID: data.id })
	}
	searchCity = (e) => {
		if (e.target.value != '') {
			let filteredData = this.state.CityData.filter(item => item.english.toLowerCase().includes(e.target.value.toLowerCase()))
			this.setState({ CityData: filteredData })
		} else {
			this.setState({ CityData: this.state.constcityData })
		}
	}
	searchArea = (e) => {
		if (e.target.value != '') {
			let filteredData = this.state.areaData.filter(item => item.english.toLowerCase().includes(e.target.value.toLowerCase()))
			this.setState({ areaData: filteredData })
		} else {
			this.setState({ areaData: this.state.constAreaData })
		}
	}
	handleFilterCustomer = (date) => {
		let data = {
			name: this.state.customerName,
			phone: this.state.customerPhone,
			email: this.state.emailId,
			days: this.state.lastOrdered,
			min_amount: this.state.amountSpentFrom,
			max_amount: this.state.amountSpentTo,
			min_wallet: this.state.walletAmountFrom,
			max_wallet: this.state.walletAmountTo,
			min_orders: this.state.OrdersFrom,
			max_orders: this.state.OrdersTo,
			min_return: this.state.returnsFrom,
			max_return: this.state.returnsTo,
			mark: this.state.customerMark,
			city_id: this.state.CityId,
			area_id: this.state.areaID,
		}
		this.getUserData(data)
		this.filterClose()

	}
	filterByRegisterDate = () => {
		let DateRange = this.state.selectionRange
		this.getUserData(null, { from: moment(DateRange.startDate).format('YYYY-MM-DD'), to: moment(DateRange.endDate).format('YYYY-MM-DD') })
		this.selectmonthmodalclose()
	}

	render() {
		const selectionRange = {
			startDate: new Date(),
			endDate: new Date(),
			key: 'selection',
		}
		let Language = this.context.language === "english" ? TableFieldEnglish : TableFieldArabic;
		let buttonLanguage = this.context.language === "english" ? buttonEnglish : buttonArabic;
		let marketingLanguage = this.context.language === "english" ? marketingEnglish : marketingArabic;
		let UserLanguage = this.context.language === "english" ? UserEnglish : UserArabic;
		let AdminLanguage = this.context.language === "english" ? AdminEnglish : AdminArabic;
		let notificationLanguage = this.context.language === "english" ? notificationEnglish : notificationArabic;
		let orderLanguage = this.context.language === "english" ? orderEnglish : orderArabic;

		const csv_header = [
			{ label: "Name", key: "name" },
			{ label: "Phone", key: "phone" },
			{ label: "Email", key: "email" },
			{ label: "Registered Date", key: "createdat" },
			{ label: "Days Since Last Purchase", key: "days" },
			{ label: "Shipment Address", key: "address" },
			{ label: "Orders", key: "total_order" },
			{ label: "Return", key: "return_order" },
			{ label: "Wallet", key: "my_wallet" },
			{ label: "Mark", key: "mark" },
			{ label: "Status", key: "status" },
		];

		const columns = [
			{
				dataField: "id",
				text: "Id",
				hidden: true,
			},
			{
				dataField: "name",
				text: UserLanguage.Name,
				sort: true,
				hidden: false,
				formatter: (cell, row, rowIndex) => {
					return (
						<React.Fragment>
							<div className="product-name">
								<Link to={'/user-details/' + row.user_id} target="_blank" className="hover-user-name">
									{/* <a target="_blank"> */}
									{row.name ? row.name : '-'}
									{/* </a> */}
								</Link>
							</div>
						</React.Fragment>
					);
				},
			},
			{
				dataField: "phone",
				text: AdminLanguage.phoneNumber,
				sort: true,
				hidden: false,
				formatter: (cell, row, rowIndex) => {
					if (row.phone) {
						return (
							<React.Fragment>
								<div className="product-name">
									{row.phone.substring(0, 3) !== '966' ? row.phone : row.phone.substring(3)}
								</div>
							</React.Fragment>
						);
					}
				},
			},
			{
				dataField: "email",
				text: Language.emailAddress,
				sort: true,
				hidden: false,
				formatter: (cell, row, rowIndex) => {
					return (
						<React.Fragment>
							<div className="product-name">
								{row.email ? row.email : '-'}
							</div>
						</React.Fragment>
					);
				},
			},
			{
				dataField: "createdat",
				text: Language.registerdDate,
				sort: true,
				hidden: false,
				formatter: (cell, row, rowIndex) => {
					return (
						<React.Fragment>
							<div className="product-name">
								{moment(row.createdat).format("DD/MM/YYYY hh:mm A")}
							</div>
						</React.Fragment>
					);
				},
			},
			{
				dataField: "days",
				text: UserLanguage.DaysSinceLastPurchase,
				sort: true,
				hidden: false,
				formatter: (cell, row, rowIndex) => {
					return (
						<React.Fragment>
							{row.days ? row.days : 0} Days
						</React.Fragment>
					);
				},
			},
			{
				dataField: "address",
				text: Language.shipmentAdd,
				sort: true,
				hidden: false,
				formatter: (cell, row, rowIndex) => {
					return (
						<React.Fragment>
							<div className="product-name">
								{row.address ? row.address : '-'}
							</div>
						</React.Fragment>
					);
				},
			},
			{
				dataField: "user_id",
				text: UserLanguage.Orders,
				sort: true,
				hidden: false,
				formatter: (cell, row, rowIndex) => {
					return (
						<React.Fragment>
							{row.total_order ? row.total_order : 0}
						</React.Fragment>
					);
				},
			},
			{
				dataField: "return_order",
				text: UserLanguage.Returns,
				sort: true,
				hidden: false,
				formatter: (cell, row, rowIndex) => {
					return (
						<React.Fragment>
							{row.return_order ? row.return_order : 0}
						</React.Fragment>
					);
				},
			},
			{
				dataField: "my_wallet",
				text: UserLanguage.wallet,
				sort: true,
				hidden: false
			},
			{
				dataField: "mark",
				text: UserLanguage.Mark,
				sort: false,
				hidden: false,
				formatter: (cell, row, rowIndex) => {
					return (
						<React.Fragment>
							{row.mark ? row.mark : '-'}
						</React.Fragment>
					);
				},
			},
			{
				dataField: "status",
				text: Language.status,
				sort: true,
				hidden: false,
				classes: "",
				formatter: (cell, row, rowIndex) => {
					return (
						<div style={{ width: '105px' }}>
							<label className="switch ">
								<input type="checkbox" defaultChecked={row.status == 1} />
								<div className="slider round" />
								<div className="text"></div>
							</label>
						</div>
					);
				},
			},
			{
				dataField: "action",
				text: Language.action,
				hidden: false,
				csvExport: false,
				headerClasses: "text-center",
				classes: "text-center",
				formatter: (cell, row, rowIndex) => {
					return (
						<React.Fragment>
							<Dropdown className="cust-drop">
								<Dropdown.Toggle className="bg-transparent " id="dropdown-basic" align="end">
									<svg xmlns="http://www.w3.org/2000/svg" width={16} height={16} fill="currentColor" className="bi bi-three-dots-vertical" viewBox="0 0 16 16">
										<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
									</svg>
								</Dropdown.Toggle>
								<Dropdown.Menu>
									<Dropdown.Item onClick={() => this.userDetail(row.user_id)}>
										<svg width={20} height={15} viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg">
											<path d="M10 14C8.35987 14.0204 6.7367 13.6665 5.254 12.965C4.10469 12.4042 3.07265 11.6298 2.213 10.683C1.30243 9.70413 0.585467 8.56167 0.1 7.31601L0 7.00001L0.105 6.68401C0.590815 5.43944 1.30624 4.29728 2.214 3.31701C3.07334 2.37032 4.10504 1.59587 5.254 1.03501C6.73671 0.333598 8.35988 -0.0203796 10 9.39617e-06C11.6401 -0.0203444 13.2633 0.333631 14.746 1.03501C15.8953 1.59574 16.9274 2.3702 17.787 3.31701C18.6993 4.29456 19.4165 5.43737 19.9 6.68401L20 7.00001L19.895 7.31601C18.3262 11.3998 14.3742 14.0694 10 14ZM10 2.00001C6.59587 1.89334 3.47142 3.8751 2.117 7.00001C3.4712 10.1251 6.59579 12.107 10 12C13.4041 12.1064 16.5284 10.1247 17.883 7.00001C16.5304 3.87359 13.4047 1.89109 10 2.00001ZM10 10C8.55733 10.0096 7.30937 8.99737 7.02097 7.58378C6.73256 6.1702 7.48427 4.75003 8.81538 4.19367C10.1465 3.63731 11.6852 4.10014 12.4885 5.29852C13.2919 6.49689 13.1354 8.09609 12.115 9.11601C11.5563 9.68127 10.7948 9.99957 10 10Z" fill="#2D2D3B" />
										</svg>
										<span>{buttonLanguage.view}</span>
									</Dropdown.Item>
									<Dropdown.Item href="#" onClick={(e) => this.edit_handleShow(e, row)}>
										<svg width={19} height={18} viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
											<path d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z" fill="#2D2D3B" />
										</svg>
										<span>{buttonLanguage.edit}</span>
									</Dropdown.Item>
									<Dropdown.Item href="#" onClick={() => this.delete_record(row.id)}>
										<svg width={18} height={20} viewBox="0 0 18 20" fill="none" xmlns="http://www.w3.org/2000/svg">
											<path d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z" fill="#2D2D3B" />
										</svg>
										<span>{buttonLanguage.delete}</span>
									</Dropdown.Item>
								</Dropdown.Menu>
							</Dropdown>
						</React.Fragment>
					);
				},
			},
		];

		return (
			<Adminlayout>
				<div className="container-fluid">
					<div className="row common-space align-items-center">
						<div className="col-6 text-start rtl-txt-start">
							<div className="common-header-txt">
								<h3>{marketingLanguage.customers}</h3>
							</div>
						</div>
						<div className="col-6 text-end rtl-txt-end">
							<CSVLink data={this.state.csvEportData} headers={csv_header} filename={'UserData.csv'}>
								<div className="common-red-btn">
									<a className="btn red-btn">{buttonLanguage.exportList}</a>
								</div>
							</CSVLink>
						</div>
					</div>
					<div className="row common-space align-items-center">
						<div className="col-12  text-start rtl-txt-start">
							<div className="common-header-txt">
								<div className="master-btn-group">
									<div
										className="btn-group justify-content-center"
										role="group"
										aria-label="Basic radio toggle button group"
										onChange={this.handleChangeForRadio}
									>
										<input
											type="radio"
											className="btn-check"
											name="btnradio"
											id="women"
											autoComplete="off"
											defaultChecked
										/>
										<label className="btn" htmlFor="women">
											{marketingLanguage.AllCustomers}
										</label>
										<input
											type="radio"
											className="btn-check"
											name="btnradio"
											id="men"
											autoComplete="off"
										/>
										<label className="btn" htmlFor="men">
											{marketingLanguage.SegmentGroups}
										</label>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div className="row common-space">
						<div className="col-md-12">
							<div className="white-box">
								<div className="d-md-flex align-items-center mb-md-3">
									<div className="me-md-auto mb-md-0 mb-3 customer-search-bar position-relative w-100">
										<input type="search" className="form-control" placeholder={marketingLanguage.SearchByNameEmail} onChange={this.handleSearchValue} />
										<svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
											<path d="M6.31802 1C5.26621 1 4.23803 1.31189 3.36349 1.89622C2.48894 2.48055 1.80732 3.31108 1.40481 4.28279C1.0023 5.2545 0.89699 6.32374 1.10219 7.3553C1.30738 8.38686 1.81388 9.33441 2.55761 10.0781C3.30135 10.8218 4.24893 11.3283 5.28052 11.5335C6.31212 11.7387 7.38139 11.6334 8.35313 11.2309C9.32487 10.8284 10.1554 10.1468 10.7398 9.27228C11.3241 8.39776 11.636 7.36961 11.636 6.31784C11.6359 4.90749 11.0756 3.55493 10.0783 2.55766C9.08102 1.56039 7.72842 1.00009 6.31802 1V1Z" stroke="#C4C4C4" strokeWidth="1.875" strokeMiterlimit="10" />
											<path d="M10.2856 10.2803L13.9997 13.9942" stroke="#C4C4C4" strokeWidth="1.875" strokeMiterlimit="10" strokeLinecap="round" />
										</svg>
									</div>
									<div className="btn-list-order mb-3 mb-md-0">
										<button className="btn white-btn me-sm-2 me-0 me-2" onClick={this.selectmonthmodalShow}>
											<svg className="me-2" width="18" height="20" viewBox="0 0 18 20" fill="none" xmlns="http://www.w3.org/2000/svg">
												<path d="M16 20H2C0.89543 20 0 19.1046 0 18V4C0 2.89543 0.89543 2 2 2H4V0H6V2H12V0H14V2H16C17.1046 2 18 2.89543 18 4V18C18 19.1046 17.1046 20 16 20ZM2 8V18H16V8H2ZM2 4V6H16V4H2ZM14 16H12V14H14V16ZM10 16H8V14H10V16ZM6 16H4V14H6V16ZM14 12H12V10H14V12ZM10 12H8V10H10V12ZM6 12H4V10H6V12Z" fill="#323232" />
											</svg>
											Lifetime
											<i className="bi bi-caret-down-fill ms-2" />
										</button>
										<button
											className="btn white-btn me-sm-2 me-0"
											onClick={this.filter_handleShow}
										>
											<svg className="me-2" width="18" height="12" viewBox="0 0 18 12" fill="none" xmlns="http://www.w3.org/2000/svg">
												<path d="M7 12H11V10H7V12ZM0 0V2H18V0H0ZM3 7H15V5H3V7Z" fill="#1F2937" />
											</svg>
											{orderLanguage.filter}
											<i className="bi bi-caret-down-fill ms-2" />
										</button>
									</div>
								</div>

								{/* <div className="d-md-flex align-items-end user-sec justify-content-end text-center">
									<div className="d-flex align-items-center me-2 mb-md-0 mb-3">
										<label>{UserLanguage.From}:</label>
										<input type="date" name={"fromDate"} className="white-btn ms-2" onChange={this.changeDelay} />
									</div>
									<div className=" d-flex align-items-center me-2 mb-md-0 mb-3">
										<label>{UserLanguage.To}:</label>
										<input type="date" name={"toDate"} className="white-btn ms-2" onChange={this.changeDelay} />
									</div>
									<div className="d-flex align-items-center me-2 mb-md-0 mb-3">
										<select className="white-btn">
											<option>{UserLanguage.SelectCountry}</option>
											<option>abc</option>
											<option>abc</option>
										</select>
									</div>
								</div> */}
								<div className="custom-table table-style-change user-data-table" >
									<div className="table-responsive dataTables_wrapper no-footer">
										{this.state.user_data.length > 0 ? (
											<DataTable
												keyField="id"
												loading={this.state.loading}
												columns={columns}
												data={this.state.user_data}
												page={this.state.page}
												sizePerPage={this.state.sizePerPage}
												totalSize={this.state.totalSize}
												defaultSorted={this.state.defaultSorted}
												onTableChange={this.handleTableChange}
												language={this.context.language}
												selectableRows
											/>
										) : (
											<DataTable
												keyField="id"
												loading={this.state.loading}
												columns={columns}
												data={this.state.user_data}
												page={this.state.page}
												sizePerPage={this.state.sizePerPage}
												totalSize={this.state.totalSize}
												defaultSorted={this.state.defaultSorted}
												onTableChange={this.handleTableChange}
												language={this.context.language}
												selectableRows
											/>
										)}
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				{/* ---------------------modal-date-------------------- */}
				<Modal
					dialogClassName="modal-dialog-centered cust-modal-white-content"
					className="cust-white-modal"
					ref={(el) => {
						this.dialog = el;
					}
					}
					show={this.state.selectmonthmodal}
					onHide={this.selectmonthmodalclose}
					size="xl"
				>
					<Modal.Header>
						<button type="button" onClick={this.selectmonthmodalclose} className="close btn-close" ></button>
					</Modal.Header>
					<Modal.Body className="cust-datepicker">
						<>

							<div className="row">
								<div className="col-12">
									<DateRangePicker
										ranges={[this.state.selectionRange]}
										onChange={this.handleSelect}
										showSelectionPreview={true}
										moveRangeOnFirstSelection={false}
										months={2}
										direction="horizontal"
									/>
								</div>
								<div className="col-lg-4 text-lg-end text-center ms-auto">
									<div className="common-red-btn">
										<button className="btn red-border-btn  me-2" onClick={this.selectmonthmodalclose}>
											Cancel
										</button>
										<button className="btn red-btn" type="submit" onClick={this.filterByRegisterDate}>
											Set
										</button>
									</div>
								</div>
							</div>
						</>
					</Modal.Body>
				</Modal>

				{/* ------------filter modal--------------------------- */}
				<Modal
					dialogClassName="modal-dialog-centered cust-modal-white-content filter"
					className="cust-white-modal"
					ref={(el) => {
						this.dialog = el;
					}}
					show={this.state.filter_show}
					onHide={this.filterClose}
				>
					<Modal.Body>
						<form className="row modal-form">
							<div className="col-md-6 form-group">
								<label>{buttonLanguage.Customername}</label>
								<input
									className="form-control"
									type="text"
									name="customerName"
									placeholder=""
									value={this.state.customerName}
									onChange={this.handleChange}
								/>
							</div>
							<div className="col-md-6 form-group">
								<label>{buttonLanguage.CustomerPhone}</label>
								<input
									className="form-control"
									type="tel"
									placeholder=""
									name="customerPhone"
									value={this.state.customerPhone}
									onChange={this.handleChange}
								/>
							</div>
							<div className="col-md-6 form-group">
								<label>{buttonLanguage.CustomerCity}</label>
								<Dropdown autoClose={true}>
									<Dropdown.Toggle className="btn dropdown-toggle cust-search-button w-100">
										<span>{this.context.language === "english" ? this.state.selectedCityEn : this.state.selectedCityAr}</span>
									</Dropdown.Toggle>
									<Dropdown.Menu className="w-100 cust-drop-box">
										<div className="u-search-dw">
											<div className="sear-u-inp p-2 bg-transparent">
												<div className="position-relative">
													<input
														className="form-control"
														type="search"
														placeholder={UserLanguage.search}
														onChange={this.searchCity}
													/>
												</div>
												<div className="drop-body-cust">
													<ul>
														{this.state.CityData.length > 0 && this.state.CityData.map((item) => {
															return (
																<Dropdown.Item>
																	<li onClick={() => this.selectCity(item)}>
																		<span>{this.context.language === "english" ? item.english : item.arabic}</span>
																	</li>
																</Dropdown.Item>
															)
														})}
														{/* <li>
															<span>Austin</span>
														</li>
														<li>
															<span>Columbus</span>
														</li> */}
													</ul>
												</div>
											</div>
										</div>
									</Dropdown.Menu>
								</Dropdown>
							</div>
							<div className="col-md-6 form-group">
								<label>{UserLanguage.Area}</label>
								<Dropdown autoClose={true}>
									<Dropdown.Toggle className="btn dropdown-toggle cust-search-button w-100">
										<span>{this.context.language === "english" ? this.state.selectedAreaEn : this.state.selectedAreaAr}</span>
									</Dropdown.Toggle>
									<Dropdown.Menu className="w-100 cust-drop-box">
										<div className="u-search-dw">
											<div className="sear-u-inp p-2 bg-transparent">
												<div className="position-relative">
													<input
														className="form-control"
														type="search"
														placeholder={UserLanguage.search}
														onChange={this.searchArea}
													/>
												</div>
												<div className="drop-body-cust">
													<ul>
														{this.state.areaData.length > 0 && this.state.areaData.map((item) => {
															return (
																<Dropdown.Item>
																	<li onClick={() => this.selectArea(item)}>
																		<span>{this.context.language === "english" ? item.english : item.arabic}</span>
																	</li>
																</Dropdown.Item>
															)
														})}
													</ul>
												</div>
											</div>
										</div>
									</Dropdown.Menu>
								</Dropdown>
							</div>
							<div className="col-md-6 form-group">
								<label>{Language.EmailID}</label>
								<input
									className="form-control"
									type="email"
									placeholder=""
									name="emailId"
									value={this.state.emailId}
									onChange={this.handleChange}
								/>
							</div>
							<div className="col-md-6 form-group">
								<label>{Language.Lastorderedindays}</label>
								<input
									className="form-control"
									type="number"
									placeholder=""
									name="lastOrdered"
									value={this.state.lastOrdered}
									onChange={this.handleChange}
								/>
							</div>
							<div className="col-md-6 form-group">
								<label>{Language.Amountspent}</label>
								<div className="d-flex align-items-center">
									<input
										className="form-control"
										type="tel"
										placeholder="1000 SAR"
										name="amountSpentFrom"
										value={this.state.amountSpentFrom}
										onChange={this.handleChange}
									/>
									<div className="mx-2 mb-3">-</div>
									<input
										className="form-control"
										type="tel"
										placeholder="2000 SAR"
										name="amountSpentTo"
										value={this.state.amountSpentTo}
										onChange={this.handleChange}
									/>
								</div>
							</div>
							<div className="col-md-6 form-group">
								<label>{Language.Walletamount}</label>
								<div className="d-flex align-items-center">
									<input
										className="form-control"
										type="tel"
										placeholder="0 SAR"
										name="walletAmountFrom"
										value={this.state.walletAmountFrom}
										onChange={this.handleChange}
									/>
									<div className="mx-2 mb-3">-</div>
									<input
										className="form-control"
										type="tel"
										placeholder="200 SAR"
										name="walletAmountTo"
										value={this.state.walletAmountTo}
										onChange={this.handleChange}
									/>
								</div>
							</div>
							<div className="col-md-6 form-group">
								<label>{UserLanguage.Orders}</label>
								<div className="d-flex align-items-center">
									<input
										className="form-control"
										type="number"
										placeholder=""
										name="OrdersFrom"
										value={this.state.OrdersFrom}
										onChange={this.handleChange}
									/>
									<div className="mx-2 mb-3">-</div>
									<input
										className="form-control"
										type="number"
										placeholder=""
										name="OrdersTo"
										value={this.state.OrdersTo}
										onChange={this.handleChange}
									/>
								</div>
							</div>
							<div className="col-md-6 form-group">
								<label>{UserLanguage.Returns}</label>
								<div className="d-flex align-items-center">
									<input
										className="form-control"
										type="number"
										placeholder=""
										name="returnsFrom"
										value={this.state.returnsFrom}
										onChange={this.handleChange}
									/>
									<div className="mx-2 mb-3">-</div>
									<input
										className="form-control"
										type="number"
										placeholder=""
										name="returnsTo"
										value={this.state.returnsTo}
										onChange={this.handleChange}
									/>
								</div>
							</div>
							<div className="col-md-6 form-group">
								<label>{UserLanguage.Customermark}</label>
								<select className="form-control form-select" name="customerMark" value={this.state.customerMark} onChange={this.handleChange}>
									<option value="VIP">VIP Customer</option>
									<option value="Standard Customer">Standard Customer</option>
									<option value="Bad Customer">Bad Customer</option>
									<option value="Good Customer">Good Customer</option>
								</select>
							</div>
							<div className="col-md-12 form-group text-center mb-3">
								<button type="button" className="btn red-btn  w-100" onClick={this.handleFilterCustomer}>
									{orderLanguage.filter}
								</button>
							</div>
						</form>
					</Modal.Body >
				</Modal >

				{/* ------------------------modal-------------------------- */}
				<Modal
					dialogClassName="modal-dialog-centered cust-width-modal"
					className="edit-user-modal cust-modal"
					ref={(el) => {
						this.dialog = el;
					}}
					show={this.state.search_show}
					onHide={this.edit_userClose}
				>
					<Modal.Header>
						<Modal.Title>
							<h1 className="modal-title">Edit Customer</h1>
						</Modal.Title>
						<button type="button" onClick={this.edit_userClose} className="close btn-close" />
					</Modal.Header>
					<Modal.Body>
						<div className="row modal-form">
							<div className="col-md-6 form-group">
								<label>Full Name</label>
								<input
									className="form-control"
									type="text"
									name="editCustomerName"
									placeholder="John Doe"
									value={this.state.editCustomerName}
									onChange={this.handleEditCustomerChange}
								/>
							</div>
							{/* <div className="col-md-6 form-group">
								<label>Last Name</label>
								<input
									className="form-control"
									type="text"
									name="editCustomerLName"
									placeholder="John Doe"
									value={this.state.editCustomerLName}
									onChange={this.handleEditCustomerChange}
								/>
							</div> */}
							<div className="col-md-6 form-group">
								<label>Phone Number</label>
								<PhoneInput
									country={'sa'}
									className="form-control"
									value={this.state.editCustomerNumber}
									onChange={this.handleEditPhoneChange} />
								{/* <input
									className="form-control"
									type="tel"
									name="editCustomerNumber"
									placeholder="+956 508946664"
									value={this.state.editCustomerNumber}
									onChange={this.handleEditCustomerChange}
								/> */}
							</div>
							<div className="col-md-6 form-group">
								<label>Email Address</label>
								<input
									className="form-control"
									type="email"
									placeholder="salimthottupoyil@gmail.com"
									name="editCustomerEmail"
									value={this.state.editCustomerEmail}
									onChange={this.handleEditCustomerChange}
								/>
							</div>
							<div className="col-md-6 form-group">
								<label>Gender </label>
								<select className="form-control form-select" name="editCustomerGender" value={this.state.editCustomerGender} onChange={this.handleEditCustomerChange}>
									<option>select</option>
									<option value={'male'}>Male</option>
									<option value={'female'}>Female</option>
									<option value={'other'}>Other</option>
								</select>
							</div>
							<div className="col-md-6 form-group">
								<label>Prefered language</label>
								<select className="form-control form-select" name="editCustomerLaguage" value={this.state.editCustomerLaguage} onChange={this.handleEditCustomerChange}>
									<option >Select</option>
									<option value={'arabic'}>Arabic</option>
									<option value={'english'}>English</option>
								</select>
							</div>
							<div className="col-md-6 form-group">
								<label>Date of Birth</label>
								<input
									className="form-control"
									type="date"
									placeholder=""
									name="editCustomerDOB"
									value={this.state.editCustomerDOB}
									onChange={this.handleEditCustomerChange}
								/>
							</div>
							<div className="col-md-12 form-group">
								<label>{UserLanguage.Mark}</label>
								<ul className="user-pop-radio">
									<li>
										<div className="help-support-txt">
											<label className="cust-radio">
												<input type="radio" name="editCustomerMark" id='Premium' onChange={this.handleEditMarkChange} />
												<span className="checkmark" />
											</label>
											<span className> {UserLanguage.Premium}</span>
										</div>
									</li>
									<li>
										<div className="help-support-txt">
											<label className="cust-radio">
												<input type="radio" name="editCustomerMark" id='Standard' onChange={this.handleEditMarkChange} />
												<span className="checkmark" />
											</label>
											<span className> {UserLanguage.Standard}</span>
										</div>
									</li>
									<li>
										<div className="help-support-txt">
											<label className="cust-radio">
												<input type="radio" name="editCustomerMark" id='Bad Customer' onChange={this.handleEditMarkChange} />
												<span className="checkmark" />
											</label>
											<span className> {UserLanguage.BadCustomers}</span>
										</div>
									</li>
									<li>
										<div className="help-support-txt">
											<label className="cust-radio">
												<input type="radio" name="editCustomerMark" id='Good Customer' onChange={this.handleEditMarkChange} />
												<span className="checkmark" />
											</label>
											<span className> {UserLanguage.GoodCustomers}</span>
										</div>
									</li>
								</ul>
							</div>
							<div className="col-md-12 form-group text-center mb-3">
								<button type="button" className="btn red-btn" onClick={this.SaveEditCustomerData}>
									{buttonLanguage.save}
								</button>
							</div>
						</div>
					</Modal.Body>
				</Modal>
			</Adminlayout >
		);
	}
}

export default withRouter(Users);
