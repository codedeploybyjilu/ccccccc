import React, { Component } from 'react';
import Adminlayout from '../../Components/AdminLayout/Adminlayout';
import DataTable from '../../Components/DataTable';
import LanguageContext from '../../contexts/languageContext'
import { confirmAlert } from 'react-confirm-alert';
import imgWidth from '../../images/profile.png'


class orderactivitylog extends Component {
    static contextType = LanguageContext;
    constructor(props) {
        super(props);
        this.state = {

            page: 1,
            sizePerPage: 10,
            totalSize: 100,
            defaultSorted: [{
                dataField: 'id',
                order: 'asc'
            }],

            order_data: [],
        }
    }
    handleTableChange = (type, { page, sizePerPage, filters, sortField, sortOrder }) => {
        switch (type) {
            case "pagination":
                this.setState({
                    page,
                    sizePerPage
                }, () => this.get_order_data());
                break;
            case "filter":
                let search_val = this.state.search_val;
                let newFilter = {};
                if (Object.keys(filters).length) {
                    for (const dataField in filters) {
                        newFilter[dataField] = filters[dataField].filterVal;
                    }
                    newFilter = {
                        ...search_val,
                        ...newFilter
                    };
                } else {
                    newFilter = {
                        title: '',
                        indicator: '',
                        definition: ''
                    };
                }
                this.setState({
                    search_val: newFilter
                }, () => this.get_order_data())
                break;
            case "sort":
                this.setState({
                    defaultSorted: [{
                        dataField: sortField,
                        order: sortOrder
                    }]
                }, () => this.get_order_data());
                break;
            default:
                break;
        }
        return true;
    }
    delete_record = (id) => {
        confirmAlert({
            customUI: ({ onClose }) => {
                return (
                    <div className='custom-ui'>
                        <h1>Are you sure?</h1>
                        <p>You want to delete this file?</p>
                        <button className="btn red-btn me-2" onClick={onClose}>No</button>
                        <button className="btn red-btn"
                            onClick={() => {
                                this.finaly_delete_record(id);
                                onClose();
                            }}
                        >
                            Yes, Delete it!
                        </button>
                    </div>
                );
            }
        });
    }
    get_order_data = () => {

    }
    render() {
        const columns = [
            {
                dataField: 'id',
                text: 'Id',
                hidden: true,
            },
            {
                dataField: 'Admin_details',
                text: 'Admin details',
                sort: true,
                hidden: false,
                formatter: (cell, row, rowIndex) => {
                    return (
                        <React.Fragment>
                            <img className={imgWidth} alt='' />
                        </React.Fragment>
                    );
                }
            },
            {
                dataField: 'Date_Time',
                text: 'Date & Time',
                sort: true,
                hidden: false,

            },
            {
                dataField: 'Details',
                text: 'Details',
                sort: true,
                hidden: false,

            },

        ]
        return (

            <Adminlayout>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12 mt-4">

                            <div className='white-box'>
                                <div className="custom-table">
                                    <div className="table-responsive dataTables_wrapper no-footer">
                                        {
                                            this.state.order_data &&
                                            <DataTable
                                                keyField='id'
                                                loading={this.state.loading}
                                                columns={columns}
                                                data={this.state.order_data}
                                                page={this.state.page}
                                                sizePerPage={this.state.sizePerPage}
                                                totalSize={this.state.totalSize}
                                                defaultSorted={this.state.defaultSorted}
                                                onTableChange={this.handleTableChange}
                                                language={this.context.language}

                                            />
                                        }
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </Adminlayout >
        );
    }
}

export default orderactivitylog;