import React, { Component, createRef } from "react";
import Select from "react-select";
import dragimg from "../../images/file-upload.svg";
import imgprev from "../../images/img-prev.png";
import videoicn from "../../images//video-icn.svg";
import { Formik } from "formik";
import * as EmailValidator from "email-validator";
import * as Yup from "yup";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import { PostApi } from "../../helper/APIService";
import { Modal } from "react-bootstrap";
import plusImg from "../../images/plus-icn.svg";
import loader from "../../images/loader.gif";
import toastr from "toastr";
import "toastr/build/toastr.min.css";
import { APIBaseUrl, API_Path, buttonArabic, buttonEnglish, SidebarArabic, SidebarEnglish, TableFieldArabic, TableFieldEnglish, titleArabic, titleEnglish, productEnglish, productArabic, LIVE_FILE_URL } from "../../const";
import LanguageContext from "../../contexts/languageContext";
import { Prompt } from "react-router-dom";

let ImageFileArray = [];
let images = [];
let videos = [];
let TagValue = [];
let TagArray = [];
let RowArray = [];
let columnArray = [];
let modelwearArray = [];

const reorder = (list, startIndex, endIndex) => {
  const result = Array.from(list);
  const [removed] = result.splice(startIndex, 1);
  result.splice(endIndex, 0, removed);

  return result;
};

const grid = 8;

const getItemStyle = (isDragging, draggableStyle) => ({
  // some basic styles to make the items look a bit nicer
  userSelect: "none",
  padding: grid,

  // change background colour if dragging
  background: isDragging ? "#A81A1C" : "#F7F7F7",

  // styles we need to apply on draggables
  ...draggableStyle,
});

const getListStyle = (isDraggingOver, itemsLength) => ({
  background: isDraggingOver ? "#f7f7f7" : "#fff",
  display: "flex",
  flexWrap: "wrap",
  padding: grid,
  width: itemsLength * 150 + 10,
});

class EditBasicDetails extends Component {
  static contextType = LanguageContext;

  constructor(props) {
    super(props);

    this.state = {
      selectedOption: "",
      selectedOptiontags: "",
      count: 0,
      items: "",
      videoFiles: "",
      englishTitle: "",
      arabicTitle: "",
      englishDescription: "",
      arabicDescription: "",
      mainCategory: "",
      category: "",
      subCategory: "",
      barcode: "",
      productCode: "",
      design: "",
      material: "",
      length: "",
      sleeveLength: "",
      neckline: "",
      waistType: "",
      careInstructions: "",
      tags: "",
      tagsForDisplay: [],
      tagsValue: [],
      maincategoryData: "",
      categoryData: "",
      subCategoryData: "",
      designData: "",
      materialData: "",
      careInstructionData: "",
      previewTable: false,
      rowOption: [
        { value: "XS", label: "XS" },
        { value: "S", label: "S" },
        { value: "M", label: "M" },
        { value: "L", label: "L" },
        { value: "XL", label: "XL" },
        { value: "XXL", label: "XXL" },
        { value: "XXXL", label: "XXXL" },
      ],
      columnOption: [],
      selectedRow: "",
      selectedColumn: "",
      sizeGuideData: "",
      sizeImage: "",
      thumbnailImg: "",
      sizeImageUrl: "",
      thumbnailImgUrl: "",
      isLoading: false,
      product_id: "",
      selectedRowData: [],
      oldData: "",
      type: "",
      sizeGuideline: "",
      status: "",
      shouldBlockNavigation: false,
      sizeGuideLineType: ''
    };
    this.runforms = createRef();
    this.onDragEnd = this.onDragEnd.bind(this);
  }

  componentDidMount() {
    this.getMainCategoryData();
    this.getdesignData();
    this.getMaterialData();
    this.getcareInstructionData();

    let productId = window.location.href;
    productId = productId.substr(productId.lastIndexOf("/") + 1);
    this.setState({ product_id: productId }, () => {
      this.get_product_details(this.state.product_id);
    });
  }

  getSizeGuideLine = (Select_id) => {
    let data = {
      main_category: this.state.mainCategory,
      category: this.state.category,
      sub_category: this.state.subCategory,
    };

    let path = API_Path.getSizeGuideLineByCategories;
    const getSizeGuideLineDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getSizeGuideLineDataPromise.then((res) => {
      if (res) {
        // console.log("res is :: ", res.data.data);
        this.setState({ sizeGuideData: res.data.data }, () => {
          if (this.state.sizeGuideData.length > 0) {
            let filteredData = this.state.sizeGuideData.filter(obj => obj.id == Select_id)
            console.log(filteredData, "filteredData");
            if (filteredData.length > 0) {
              this.setState({
                sizeImageUrl: Select_id ? filteredData[0].size_guide_img : this.state.sizeGuideData[0].size_guide_img,
                sizeGuideline: Select_id ? Select_id : this.state.sizeGuideData[0].id,

              }, () => {
                this.setState({ sizeGuideLineType: 0 })
              });
            }
          }
        });
      }
    });
  };

  RemoveSizeGuideline = () => {
    this.setState({ sizeImageUrl: "", sizeGuideline: "" });

    // this.setState({ showSizeGuide: false });
  };

  get_product_details = (id) => {
    TagValue = []
    TagArray = []
    const data = { product_id: id };
    const getProductDetailDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(API_Path.getProductDetailById, data));
    });
    getProductDetailDataPromise.then((res) => {
      // console.log(res.data.data[0], "-------");
      if (res.status === 200) {
        this.setState({ oldData: res.data.data[0] }, () => {
          this.setState(
            {
              englishTitle: this.state.oldData.title_en,
              arabicTitle: this.state.oldData.title_ar,
              englishDescription: this.state.oldData.description_en,
              arabicDescription: this.state.oldData.description_ar,
              mainCategory: this.state.oldData.main_category,
              category: this.state.oldData.category,
              subCategory: this.state.oldData.sub_category,
              barcode: this.state.oldData.barcode,
              productCode: this.state.oldData.code,
              // design: this.state.oldData.design,
              // material: this.state.oldData.material,
              sizeGuideline: this.state.oldData.size_guide_type == 0 || !this.state.oldData.size_guide_type ? this.state.oldData.size_guide_id : '',
              // thumbnailImgUrl: this.state.oldData.thumbnail,
              status: this.state.oldData.status,
              // status: this.state.oldData.status,
              type: this.state.oldData.status == 2 ? "draft" : this.state.oldData.status == 1 ? "publish" : "",

            },
            () => {
              // console.log(this.state.oldData.status);
              if (!this.state.oldData.size_guide_type || this.state.oldData.size_guide_type == 0) {
                this.getSizeGuideLine(this.state.oldData.size_guide_id);
              } else {
                this.setState({ sizeGuideLineType: this.state.oldData.size_guide_type })
              }
              this.getCategoryData(this.state.mainCategory);
              this.getSubCategoryData(this.state.category);
              this.props.getProductCode(this.state.productCode);
            }
          );
        });
        // console.log(res.data.data[0], "product details");
        if (res.data.data[0].tags) {
          let array = res.data.data[0].tags.split(",");
          for (let i = 0; i < array.length; i++) {
            let data = {
              value: array[i],
              id: Date.now(),
            };
            TagArray.push(data);
            TagValue.push(data.value);
          }
          this.setState({ tags: "", tagsForDisplay: TagArray, tagsValue: TagValue });
        } else {
          this.setState({ tags: "", tagsForDisplay: [], tagsValue: [] });
        }
        // if (res.data.data.length > 0) {
        //     var product_code = res.data.data[0]["code"];
        //     this.setState({ product_details: res.data.data[0], productCode: product_code }, () => { })
        // }
      } else {
        toastr.error(res.message);
      }
    });
  };

  size_show = () => {
    this.setState({ sizeguide_show: true });
  };

  edit_Close = () => {
    this.setState({
      sizeguide_show: false,
      previewTable: false,
      selectedColumn: [],
      selectedRow: [],
    });
  };

  onDragEnd(result) {
    // dropped outside the list
    if (!result.destination) {
      return;
    }

    const items = reorder(this.state.items, result.source.index, result.destination.index);

    this.setState({
      items,
    });
  }

  errorContainer = (form, field) => {
    return form.touched[field] && form.errors[field] ? <span className="error text-danger">{form.errors[field]}</span> : null;
  };

  formAttr = (form, field) => ({
    onBlur: form.handleBlur,
    onChange: form.handleChange,
    value: form.values[field],
  });

  getMainCategoryData = () => {

    let data = {};

    let path = API_Path.getMainCategory;
    const getMainCategoryPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getMainCategoryPromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data);
        this.setState({ maincategoryData: res.data.data });
      }
    });
  };

  getdesignData = () => {

    let data = {};

    let path = API_Path.getDesign;
    const getDesignPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getDesignPromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data);
        this.setState({ designData: res.data.data });
      }
    });
  };

  getMaterialData = () => {

    let data = {};

    let path = API_Path.getMaterial;
    const getMaterialPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getMaterialPromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data);
        this.setState({ materialData: res.data.data });
      }
    });
  };

  getcareInstructionData = () => {

    let data = {};

    let path = API_Path.getCareInstruction;
    const getcareInstructionDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getcareInstructionDataPromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res);
        this.setState({ careInstructionData: res.data.data });
      }
    });
  };

  getCategoryData = (val) => {
    if (val) {

      let data = { main_category_id: val };
      let path = API_Path.getCategoryRelative;
      const getCategoryPromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      getCategoryPromise.then((res) => {
        if (res.data.success) {
          // console.log('res is :: ', res.data.data);
          this.setState({ categoryData: res.data.data });
        }
      });
    } else {

      let data = {};

      let path = API_Path.getCategory;
      const getCategoryPromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      getCategoryPromise.then((res) => {
        if (res) {
          // console.log('res is :: ', res.data.data);
          this.setState({ categoryData: res.data.data });
        }
      });
    }
  };

  getSubCategoryData = (val) => {
    // console.log(val);
    if (val) {

      let data = { category_id: val };

      let path = API_Path.getSubCategoryRelative;
      const getSubCategoryPromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      getSubCategoryPromise.then((res) => {
        if (res) {
          // console.log('res is :: ', res.data.data);
          this.setState({ subCategoryData: res.data.data });
        }
      });
    } else {

      let data = {};

      let path = API_Path.getSubCategory;
      const getSubCategoryPromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      getSubCategoryPromise.then((res) => {
        if (res) {
          // console.log('res is :: ', res.data.data);
          this.setState({ subCategoryData: res.data.data });
        }
      });
    }
  };

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value, shouldBlockNavigation: true }, () => {
      if (this.state.barcode !== "") {
        document.getElementById("barcodeNoId").style.display = "none";
      }
    });
  };

  handleChange1 = (e) => {
    this.setState({ shouldBlockNavigation: true })
    if (e.target.name == "mainCategory") {
      this.getCategoryData(e.target.value);
      this.setState({ mainCategory: e.target.value });
    }
    if (e.target.name == "category") {
      this.getSubCategoryData(e.target.value);
      this.setState({ category: e.target.value });
    }
    if (e.target.name == "subCategory") {
      this.setState({ subCategory: e.target.value }, () => {
        this.getSizeGuideLine();
      });
    }
  };

  // handleStatusChange = (e) => {
  //   console.log("e Is :: ", e.target.checked);
  //   this.setState({ status: e.target.checked });
  // };

  handleAddTag = () => {
    if (this.state.tags !== "") {
      let data = {
        value: this.state.tags,
        id: Date.now(),
      };
      TagArray.push(data);
      TagValue.push(data.value);
      this.setState({ tags: "", tagsForDisplay: TagArray, tagsValue: TagValue });
      // console.log('tag :: ', TagArray);
    }
  };

  removeTag = (idToRemove) => {
    const filteredTag = TagArray.filter((item) => item.id !== idToRemove);
    TagArray = filteredTag;
    if (filteredTag?.length > 0) {
      filteredTag?.map((item) => {
        TagValue.push(item.value)
      })
    } else {
      TagValue = []
    }
    this.setState({ tagsForDisplay: filteredTag, tagsValue: TagValue });
  };

  handleSelect = (selectedOption) => {
    this.setState({ selectedOption }, () => {
      if (this.state.selectedOption.length > 0) {
        document.getElementById("selectedOptionError").style.display = "none";
      } else {
        document.getElementById("selectedOptionError").style.display = "block";
      }
    });
  };

  handleRowSelect = (selectedRow) => {
    this.setState({ selectedRow }, () => {
      if (this.state.selectedRow.length < 1) {
        document.getElementById("selectedRowError").style.display = "block";
      } else {
        document.getElementById("selectedRowError").style.display = "none";
      }
    });
  };

  handleColumnSelect = (selectedColumn) => {
    this.setState({ selectedColumn }, () => {
      if (this.state.selectedColumn.length < 1) {
        document.getElementById("selectedColumnError").style.display = "block";
      } else {
        document.getElementById("selectedColumnError").style.display = "none";
      }
    });
  };

  handleTableSubmit = () => {
    if (this.state.selectedColumn.length > 0 && this.state.selectedRow.length > 0) {
      this.setState({ previewTable: true });
    } else {
      if (this.state.selectedColumn.length < 1) {
        document.getElementById("selectedColumnError").style.display = "block";
      } else {
        document.getElementById("selectedColumnError").style.display = "none";
      }
      if (this.state.selectedRow.length < 1) {
        document.getElementById("selectedRowError").style.display = "block";
      } else {
        document.getElementById("selectedRowError").style.display = "none";
      }
    }
  };

  addThumbnail = (e) => {
    this.setState({ thumbnailImg: Object.values(e.target.files) }, () => {
      this.setState({ isLoading: true });
      if (this.state.thumbnailImg !== "") {
        this.addThumbnailToStorage(this.state.thumbnailImg);
      }
    });
  };

  removeThumbnail = () => {
    this.setState({ thumbnailImg: "", thumbnailImgUrl: "" });
    document.getElementById("thumbnailInput").value = "";
  };

  addImageToStorage = (files) => {


    // console.log('files is :: ', files);

    var formData = new FormData();
    for (var i = 0; i < files.length; i++) {
      formData.append("file", files[i]);
    }

    let path = API_Path.addFileInS3;
    const addFileInS3Promise = new Promise((resolve, reject) => {
      resolve(PostApi(path, formData));
    });

    addFileInS3Promise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data[0]);
        this.setState({ sizeImageUrl: res.data.data[0] }, () => {
          this.setState({ isLoading: false });
          document.getElementById("imagesizeError").style.display = "none";
        });
      }
    });
  };

  handleSizeImage = (e) => {
    // console.log('e', Object.values(e.target.files));
    this.setState({ sizeImage: Object.values(e.target.files) }, () => {
      this.setState({ isLoading: true });
      this.addImageToStorage(this.state.sizeImage);
    });
  };

  addThumbnailToStorage = (files) => {


    // console.log('files is :: ', files);

    var formData = new FormData();
    for (var i = 0; i < files.length; i++) {
      formData.append("file", files[i]);
    }

    let path = API_Path.addFileInS3;
    const addFileInS3Promise = new Promise((resolve, reject) => {
      resolve(PostApi(path, formData));
    });

    addFileInS3Promise.then((res) => {
      if (res) {
        if (res.data.success) {
          this.setState({ thumbnailImgUrl: res.data.data[0] }, () => {
            this.setState({ isLoading: false });
            // document.getElementById('thumbnailError').style.display = 'none'
          });
        } else {
          this.setState({ isLoading: false });
        }
      }
    });
  };

  handleSizeguidelineChange = (e) => {
    this.setState({ shouldBlockNavigation: true })
    let url = e.target.value;
    let id = url.substr(url.lastIndexOf("-") + 1);
    let image = url.substr(0, url.lastIndexOf("-"));
    this.setState({ sizeGuideline: parseInt(id), sizeImageUrl: image });
  };

  handleModelWearSize = (e) => {
    this.setState({ modelwear: e.target.value }, () => {
      if (e.keyCode === 13) {
        if (this.state.modelwear !== "") {
          this.state.modelwear
            .trim()
            .split(/\s+/)
            .map((item, i) => {
              let data = {
                value: item,
                id: this.makeId(7),
              };
              modelwearArray.push(data);
            });
          let modelValueArray = [];
          modelwearArray.map((l) => {
            let value = l.value;
            modelValueArray.push(value);
          });
          this.setState(
            {
              modelwear: "",
              modelForDisplay: modelwearArray,
              modelValueForDisplay: modelValueArray,
            },
            () => {
              document.getElementById("modelwear").value = "";
            }
          );
        }
      }
    });
  };

  makeId = (length) => {
    var result = "";
    var characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    var charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  };

  removeModel = (idToRemove) => {
    const modelSize = modelwearArray.filter((item) => item.id !== idToRemove);
    modelwearArray = modelSize;
    this.setState({ modelForDisplay: modelSize });
  };

  handlePromptChange = () => {
    this.setState({ shouldBlockNavigation: true })
  }

  handleSizeguidelineTypeChange = (e) => {
    this.setState({ sizeGuideLineType: e.target.value })
    if (e.target.value == 0) {
      this.getSizeGuideLine()
      this.props.selectSpecificSizeGuid(false)
    } else {
      this.setState({ sizeGuideline: '', sizeImageUrl: '' })
      this.props.selectSpecificSizeGuid(true)
    }
  }

  render() {
    let Language = this.context.language === "english" ? TableFieldEnglish : TableFieldArabic;
    let ButtonLanguage = this.context.language === "english" ? buttonEnglish : buttonArabic;
    let titleLanguage = this.context.language === "english" ? titleEnglish : titleArabic;
    let productLanguage = this.context.language === "english" ? productEnglish : productArabic;
    // var product_details = this.props.productDetails;
    return (
      <React.Fragment>
        <Prompt when={this.state.shouldBlockNavigation === true} message="You have unsaved changes, are you sure you want to leave?" />

        {this.state.isLoading && (
          <div className="loader-main">
            <div className="loader-inr">
              <img src={loader} alt="" />
            </div>
          </div>
        )}
        {this.state.oldData !== "" && (
          <Formik
            innerRef={this.runforms}
            enableReinitialize={true}
            initialValues={{
              englishTitle: this.state.oldData.title_en,
              arabicTitle: this.state.oldData.title_ar,
              englishDescription: this.state.oldData.description_en,
              arabicDescription: this.state.oldData.description_ar,
              mainCategory: this.state.oldData.main_category,
              category: this.state.oldData.category,
              subCategory: this.state.oldData.sub_category,
              barcode: this.state.oldData.barcode,
              productCode: this.state.oldData.code,
              // design: this.state.oldData.design,
              // material: this.state.oldData.material,
              // length: this.state.oldData.length,
              // sleeveLength: this.state.oldData.sleeveLength,
              // neckline: this.state.oldData.neckline,
              // waistType: this.state.oldData.waistType,
              // careInstructions: this.state.oldData.care_instruction,
              // productImage: "",
              // modelWearSize: this.state.oldData.model_size,
              // modelwear: this.state.oldData.model_size,
              status: this.state.oldData.status,
            }}
            validationSchema={Yup.object().shape({
              englishTitle: Yup.string().required("Required"),
              arabicTitle: Yup.string().required("Required"),
              // englishDescription: Yup.string().required("Required"),
              // arabicDescription: Yup.string().required("Required"),
              mainCategory: Yup.string().required("Required"),
              category: Yup.string().required("Required"),
              subCategory: Yup.string().required("Required"),
              // productImage: Yup.string().required("Required"),
              barcode: Yup.string().required("Required"),
              // productCode: Yup.string().required("Required"),
              // design: Yup.string().required("Required"),
              // material: Yup.string().required("Required"),
              // length: Yup.string().required("Required"),
              // sleeveLength: Yup.string().required("Required"),
              // neckline: Yup.string().required("Required"),
              // waistType: Yup.string().required("Required"),
              // careInstructions: Yup.string().required("Required"),
              // modelwear: Yup.string().required("Required"),
              // status: Yup.string().required("Required"),
            })}
            onSubmit={(values, { setSubmitting }) => {
              // console.log("Logging in", values);
              setSubmitting(false);
            }}
          >
            {(props) => {
              const { values, touched, errors, isSubmitting, handleChange, handleBlur, handleSubmit } = props;
              return (
                <form className="row mt-3 align-items-end" onSubmit={handleSubmit}>
                  <div className="form-group col-md-6">
                    <div className="d-flex align-items-center justify-content-end">
                      <label className="mb-2">{productLanguage.productTitleara}</label>
                    </div>
                    <input type="text" dir="rtl" name="arabicTitle" value={values.arabicTitle} onChange={handleChange} onChangeCapture={this.handlePromptChange} onBlur={handleBlur} className="form-control input-custom-class" placeholder="Enter Product Title/Name in Arabic" />
                    {errors.arabicTitle && touched.arabicTitle && <div className="input-feedback text-danger">{errors.arabicTitle}</div>}
                  </div>
                  <div className="form-group col-md-6">
                    <div className="d-flex align-items-center ">
                      <label className="mb-2">{productLanguage.productTitle}</label>
                    </div>
                    <input type="text" name="englishTitle" value={values.englishTitle} onChange={handleChange} onChangeCapture={this.handlePromptChange} onBlur={handleBlur} className="form-control input-custom-class eng-start" placeholder={productLanguage.EnterProductTitleNameinEnglish} />

                    {errors.englishTitle && touched.englishTitle && <div className="input-feedback text-danger">{errors.englishTitle}</div>}
                  </div>
                  <div className="form-group col-md-6">
                    <div className="d-flex align-items-center justify-content-end">
                      <label className="mb-2">{productLanguage.ProductDescriptionInArabic}</label>
                    </div>
                    <textarea dir="rtl" rows="4" name="arabicDescription" value={values.arabicDescription} onChange={handleChange} onChangeCapture={this.handlePromptChange} onBlur={handleBlur} className="form-control input-custom-class h-auto" placeholder="Enter Product Description in Arabic"></textarea>
                    {errors.arabicDescription && touched.arabicDescription && <div className="input-feedback text-danger">{errors.arabicDescription}</div>}
                  </div>
                  <div className="form-group col-md-6">
                    <div className="d-flex align-items-center ">
                      <label className="mb-2">{productLanguage.ProductDescriptionInEng}</label>
                    </div>
                    <textarea rows="4" name="englishDescription" value={values.englishDescription} onChange={handleChange} onChangeCapture={this.handlePromptChange} onBlur={handleBlur} className="eng-start form-control input-custom-class h-auto" placeholder="Enter Product Description in English"></textarea>
                    {errors.englishDescription && touched.englishDescription && <div className="input-feedback text-danger">{errors.englishDescription}</div>}
                  </div>
                  {/* {console.log(productLanguage.MainCategory)} */}
                  <div className="form-group col-xl-3 col-md-4">
                    <label>{productLanguage.MainCategory}</label>
                    <select name="mainCategory" value={values.mainCategory} onChange={handleChange} onChangeCapture={this.handleChange1} onBlur={handleBlur} className="form-select input-custom-class">
                      <option>{productLanguage.chooseMainCategory} </option>
                      {this.state.maincategoryData &&
                        this.state.maincategoryData.length > 0 &&
                        this.state.maincategoryData.map((item, i) => {
                          return (
                            <option value={item.id} key={i}>
                              {item.english} | {item.arabic}
                            </option>
                          );
                        })}
                    </select>
                    {errors.mainCategory && touched.mainCategory && <div className="input-feedback text-danger">{errors.mainCategory}</div>}
                  </div>

                  <div className="form-group col-xl-3 col-md-4">
                    <label>{productLanguage.category}</label>
                    <select name="category" value={values.category} onChange={handleChange} onChangeCapture={this.handleChange1} onBlur={handleBlur} className="form-select input-custom-class">
                      <option>{productLanguage.SelectCategory}</option>
                      {this.state.categoryData &&
                        this.state.categoryData.length > 0 &&
                        this.state.categoryData.map((item, i) => {
                          return (
                            <option value={item.id} key={i}>
                              {item.english} | {item.arabic}
                            </option>
                          );
                        })}
                    </select>
                    {errors.category && touched.category && <div className="input-feedback text-danger">{errors.category}</div>}
                  </div>
                  <div className="form-group col-xl-3 col-md-4">
                    <label>{productLanguage.subCategory}</label>
                    <select name="subCategory" value={values.subCategory} onChange={handleChange} onChangeCapture={this.handleChange1} onBlur={handleBlur} className="form-select input-custom-class">
                      <option>{productLanguage.SelectSubCategory}</option>
                      {this.state.subCategoryData &&
                        this.state.subCategoryData.length > 0 &&
                        this.state.subCategoryData.map((item, i) => {
                          return (
                            <option value={item.id} key={i}>
                              {item.english} | {item.arabic}
                            </option>
                          );
                        })}
                    </select>
                    {errors.subCategory && touched.subCategory && <div className="input-feedback text-danger">{errors.subCategory}</div>}
                  </div>
                  <div className="form-group col-xl-3 col-md-4">
                    <label>{productLanguage.BarcodeNo} </label>
                    <input type="text" name="barcode" value={values.barcode} onChange={handleChange} onChangeCapture={this.handlePromptChange} className="form-control input-custom-class" placeholder="Enter Barcode No." />
                    <div id="barcodeNoId" style={{ display: "none" }} className="input-feedback text-danger">
                      Required !!
                    </div>
                    {/* {errors.barcode && touched.barcode && (
                                        <div className="input-feedback text-danger">{errors.barcode}</div>
                                    )} */}
                  </div>
                  <div className="form-group col-xl-3 col-md-4">
                    <label>{productLanguage.ProductCode} </label>
                    <input type="text" name="productCode" value={values.productCode} readOnly className="form-control input-custom-class w-100" placeholder="Enter Product Code" />
                  </div>
                  {/* <div className="form-group col-xl-3 col-md-4">
                    <label>{productLanguage.Design}</label>
                    <select name="design" value={values.design} onChange={handleChange} onBlur={handleBlur} className="form-select input-custom-class">
                      <option>{productLanguage.SelectDesign}</option>
                      {this.state.designData &&
                        this.state.designData.length > 0 &&
                        this.state.designData.map((item, i) => {
                          return (
                            <option value={item.id} key={i}>
                              {item.english} | {item.arabic}
                            </option>
                          );
                        })}
                    </select>
                    {errors.design && touched.design && <div className="input-feedback text-danger">{errors.design}</div>}
                  </div>
                  <div className="form-group col-xl-3 col-md-4">
                    <label>{productLanguage.Material}</label>
                    <select name="material" value={values.material} onChange={handleChange} onBlur={handleBlur} className="form-select input-custom-class">
                      <option>{productLanguage.Selectmaterial}</option>
                      {this.state.materialData &&
                        this.state.materialData.length > 0 &&
                        this.state.materialData.map((item, i) => {
                          return (
                            <option value={item.id} key={i}>
                              {item.english} | {item.arabic}
                            </option>
                          );
                        })}
                    </select>
                    {errors.material && touched.material && <div className="input-feedback text-danger">{errors.material}</div>}
                  </div>
                  <div className="form-group col-xl-3 col-md-4">
                    <label>{productLanguage.Length}</label>
                    <select name="length" value={values.length} onChange={handleChange} onBlur={handleBlur} className="form-select input-custom-class">
                      <option>{productLanguage.SelectLength}</option>
                      {this.state.materialData &&
                        this.state.materialData.length > 0 &&
                        this.state.materialData.map((item, i) => {
                          return (
                            <option value={item.id} key={i}>
                              {item.english} | {item.arabic}
                            </option>
                          );
                        })}
                    </select>
                    {errors.length && touched.length && <div className="input-feedback text-danger">{errors.length}</div>}
                  </div>
                  <div className="form-group col-xl-3 col-md-4">
                    <label>{productLanguage.SleeveLength}</label>
                    <select name="sleeveLength" value={values.sleeveLength} onChange={handleChange} onBlur={handleBlur} className="form-select input-custom-class">
                      <option>{productLanguage.SelectSleeveLength}</option>
                      <option value="XS">XS</option>
                      <option value="S">S</option>
                      <option value="M">M</option>
                      <option value="L">L</option>
                      <option value="XL">XL</option>
                      <option value="XXL">XXL</option>
                      <option value="XXXL">XXXL</option>
                    </select>
                    {errors.sleeveLength && touched.sleeveLength && <div className="input-feedback text-danger">{errors.sleeveLength}</div>}
                  </div>
                  <div className="form-group col-xl-3 col-md-4">
                    <label>{productLanguage.Neckline}</label>
                    <select name="neckline" value={values.neckline} onChange={handleChange} onBlur={handleBlur} className="form-select input-custom-class">
                      <option>{productLanguage.SelectNeckline}</option>
                      <option value="XS">XS</option>
                      <option value="S">S</option>
                      <option value="M">M</option>
                      <option value="L">L</option>
                      <option value="XL">XL</option>
                      <option value="XXL">XXL</option>
                      <option value="XXXL">XXXL</option>
                    </select>
                    {errors.neckline && touched.neckline && <div className="input-feedback text-danger">{errors.neckline}</div>}
                  </div>
                  <div className="form-group col-xl-3 col-md-4">
                    <label>{productLanguage.WaistType}</label>
                    <select name="waistType" value={values.waistType} onChange={handleChange} onBlur={handleBlur} className="form-select input-custom-class">
                      <option>{productLanguage.SelectWaistType}</option>
                      <option value="XS">XS</option>
                      <option value="S">S</option>
                      <option value="M">M</option>
                      <option value="L">L</option>
                      <option value="XL">XL</option>
                      <option value="XXL">XXL</option>
                      <option value="XXXL">XXXL</option>
                    </select>
                    {errors.waistType && touched.waistType && <div className="input-feedback text-danger">{errors.waistType}</div>}
                  </div>
                  <div className="form-group col-xl-3 col-md-4">
                    <label>{productLanguage.ModelWearingSize}</label>
                    <input placeholder="Type model wearing size." className="form-control input-custom-class" name="modelwear" onKeyDown={this.handleModelWearSize} id="modelwear" />
                    <div>
                      {this.state.modelForDisplay && this.state.modelForDisplay.length > 0 && (
                        <ul className="d-flex align-items-center flex-wrap">
                          {this.state.modelForDisplay !== "" &&
                            this.state.modelForDisplay.map((item, i) => {
                              return (
                                <li key={i} className="me-2 mb-3">
                                  <bdi className="barcode-bg py-1 px-2 mx-2 rounded">{item.value}</bdi>
                                  <mark onClick={() => this.removeModel(item.id)} className="bg-transparent bi bi-x p-0"></mark>
                                </li>
                              );
                            })}
                        </ul>
                      )}
                    </div>
                  </div>

                  <div className="form-group col-xl-3 col-md-4">
                    <label>{productLanguage.careInstructions}</label>
                    <select name="careInstructions" value={values.careInstructions} onChange={handleChange} onBlur={handleBlur} className="form-select input-custom-class">
                      <option>{productLanguage.SelectCareInstruction}</option>
                      {this.state.careInstructionData &&
                        this.state.careInstructionData.length > 0 &&
                        this.state.careInstructionData.map((item, i) => {
                          return (
                            <option value={item.id} key={i}>
                              {item.english} | {item.arabic}
                            </option>
                          );
                        })}
                    </select>
                    {errors.careInstructions && touched.careInstructions && <div className="input-feedback text-danger">{errors.careInstructions}</div>}
                  </div> */}
                  <div className="form-group col-xl-3 col-md-4">
                    <label>{productLanguage.Tag}</label>
                    <div className="d-flex align-items-center">
                      <input type="text" className="form-control input-custom-class me-2" onChange={this.handleChange} value={this.state.tags} name="tags" placeholder={productLanguage.EnterTagsName} />

                      <div onClick={this.handleAddTag} className="btn light-red-btn">
                        <img src={plusImg} />
                      </div>
                    </div>
                    {this.state.tagsForDisplay && this.state.tagsForDisplay.length > 0 && (
                      <div className="cust-select-cate-drop cust-tag-div">
                        <ul>
                          {this.state.tagsForDisplay.map((item, i) => {
                            return (
                              <li key={i}>
                                <span>{item.value}</span>
                                <mark onClick={() => this.removeTag(item.id)} className=" bg-transparent bi bi-x p-0"></mark>
                              </li>
                            );
                          })}
                        </ul>
                      </div>
                    )}
                    <div id="selectedOptiontagsError" style={{ display: "none" }} className="input-feedback text-danger">
                      Required
                    </div>
                  </div>
                  {/* <div className="form-group col-xl-3 col-md-4">
                    <div className="form-group ">
                      <label> {productLanguage.AddThumbnail}</label>
                      <div className="d-flex flex-wrap">
                        <div className="upload-btn-wrapper mb-3">
                          <span className="btn">{productLanguage.Uploadfile}</span>
                          <input onChange={this.addThumbnail} type="file" accept="image/*" id="thumbnailInput" name="thumbnailImg" />
                        </div>
                        {this.state.thumbnailImgUrl && this.state.thumbnailImgUrl !== "" && (
                          // console.log(this.state.thumbnailImgUrl, '========'),
                          <div className="img-preview ps-3 wdth-click-main">
                            <ul className="justify-content-center">
                              <div className="img-bdr-main">
                                <div className="img-bdr-main-inr">
                                  <li>
                                    <div className="img-preview-main position-relative">
                                      <img src={this.state.thumbnailImgUrl} alt="" />
                                      <div onClick={this.removeThumbnail} className="remove-img-btn">
                                        <i className="bi bi-x-circle-fill"></i>
                                      </div>
                                    </div>
                                  </li>
                                </div>
                              </div>
                            </ul>
                          </div>
                        )}
                      </div>
                      <div className="input-group mb-3">
                                            <input type="file" onChange={this.addThumbnail} id='thumbnailInput' className="form-control input-custom-class cust-line-height" />
                                        </div>
                      <div id="thumbnailError" style={{ display: "none" }} className="input-feedback text-danger">
                        Required !!
                      </div>
                    </div>
                  </div> */}
                  <div className="form-group col-xl-3 col-md-4">
                    <label>{productLanguage.Productstatus}</label>

                    <select name="status" className="form-select input-custom-class" onChange={handleChange} onChangeCapture={this.handlePromptChange} onBlur={handleBlur} value={values.status}>
                      <option value="1" selected>
                        {productLanguage.Active}
                      </option>
                      <option value="0">{productLanguage.dective}</option>
                      <option value="3">{productLanguage.postpone}</option>
                      <option value="2">{productLanguage.saveToDraft}</option>
                    </select>
                    {/* {errors.status && touched.status && <div className="input-feedback text-danger">{errors.status}</div>} */}
                  </div>

                  <div className="form-group col-xl-3 col-md-4">
                    <label>{productLanguage.Returnable}</label>

                    <select name="returnable" className="form-select input-custom-class" onChange={this.handleChange} onBlur={handleBlur} value={this.state.returnable}>
                      <option value="1" selected>
                        {productLanguage.Yes}
                      </option>
                      <option value="0"> {productLanguage.No}</option>
                    </select>
                    {/* {errors.status && touched.status && <div className="input-feedback text-danger">{errors.status}</div>} */}
                  </div>
                  {/* <div className="col-12 form-group d-flex align-items-center">
                    <label>Product Activation Status</label>
                    <label className="switch ms-2">
                      <input type="checkbox" checked={this.state.status == 1 ? true : false} onChange={this.handleStatusChange} />
                      <div className="slider round"></div>
                    </label>
                  </div> */}
                  <div className="form-group col-xl-3 col-md-4">
                    <div className=" d-flex">
                      <div className="w-100">
                        <label>{productLanguage.SelectSizeGuideline}</label>
                        <select name="sizeGuideLineType" value={this.state.sizeGuideLineType} onChange={this.handleSizeguidelineTypeChange} className="form-select input-custom-class">
                          <option>{productLanguage.SelectSizeGuideline}</option>
                          <option value={0} selected>Stander SizeGuideline</option>
                          <option value={1}>Specific SizeGuideline</option>
                        </select>
                        {/* <bdi className="red-underline d-block cursor-pointer" onClick={this.size_show}>Add</bdi> */}
                      </div>
                    </div>
                    <div id="sizeGuidelineError" style={{ display: "none" }} className="input-feedback text-danger">
                      Required
                    </div>
                  </div>
                  {this.state.sizeGuideLineType == 0 &&
                    <div className="form-group col-xl-3 col-md-4">
                      <div className=" d-flex">
                        <>
                          <div className="w-100">
                            <label>{productLanguage.AddSizeGuideline}</label>
                            <select name="sizeGuideLine" onChange={this.handleSizeguidelineChange} className="form-select input-custom-class">
                              <option>{productLanguage.SelectSizeguideline}</option>
                              {this.state.sizeGuideData.length > 0 &&
                                this.state.sizeGuideData.map((item, i) => {
                                  return (
                                    <>
                                      {item.id == this.state.sizeGuideline ? (
                                        <option key={i} selected value={item.size_guide_img + "-" + item.id}>
                                          {item.size_guide_name_english + " | " + item.size_guide_name_arabic}
                                        </option>
                                      ) : (
                                        <option key={i} value={item.size_guide_img + "-" + item.id}>
                                          {item.size_guide_name_english + " | " + item.size_guide_name_arabic}
                                        </option>
                                      )}
                                    </>
                                  );
                                })}
                            </select>
                          </div>
                          {
                            this.state.sizeImageUrl && (
                              <div className=" flex-wrap align-items-center ms-2">
                                <div className=" text-center my-3">
                                  <div className="img-with-close-varia position-relative">
                                    <img src={this.state.sizeImageUrl} alt="" />

                                    <div onClick={this.RemoveSizeGuideline} className="remove-img-btn">
                                      <i className="bi bi-x-circle-fill"></i>
                                    </div>
                                    {/* <div onClick={this.RemoveSizeGuideline} className="close_variant"><i className="bi bi-x-lg"></i></div> */}
                                  </div>
                                </div>
                              </div>
                            )
                          }
                        </>
                      </div>
                      <div id="sizeGuidelineError" style={{ display: "none" }} className="input-feedback text-danger">
                        Required
                      </div>
                    </div>
                  }
                  <div style={{ display: "none" }} className="col-12">
                    <div className="btn-comn-div pt-5 text-center">
                      <button id="basicDetailSubmit" disabled={isSubmitting} type="submit" className="btn-comn">
                        <span>{productLanguage.submit}</span>
                      </button>
                    </div>
                  </div>
                </form>
              );
            }}
          </Formik>
        )}
      </React.Fragment>
    );
  }
}

export default EditBasicDetails;
