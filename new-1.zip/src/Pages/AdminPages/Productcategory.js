import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import { APIBaseUrl, API_Path, buttonArabic, buttonEnglish, SidebarArabic, SidebarEnglish, TableFieldArabic, TableFieldEnglish, titleArabic, titleEnglish, productArabic, productEnglish } from "../../const";
import LanguageContext from "../../contexts/languageContext";
import { PostApi } from "../../helper/APIService";
import plusicon from "../../images/plus-icn.svg";
import toastr from "toastr";
import { Select } from "react-select";
import { confirmAlert } from "react-confirm-alert";
import { Tab, Tabs } from "react-bootstrap"

class Productcategory extends Component {
  static contextType = LanguageContext;

  state = {
    // mainCategoryEnglish: "",
    // mainCategoryArabic: "",
    // CategoryEnglish: "",
    // CategoryArabic: "",
    // SubCategoryEnglish: "",
    // SubCategoryArabic: "",
    ishowtomeasureEdit: false,
    howtomeasureData: "",
    howtomeasureEnglish: "",
    howtomeasureArabic: "",
    howtomeasuredescEnglish: "",
    howtomeasuredescArabic: "",
    isIcon: false,
    careIcon: "",
    colorValue: "#000000",
    agesizesEnglish: "",
    agesizesArabic: "",
    brasizesEnglish: "",
    brasizesArabic: "",
    miscEnglish: "",
    miscArabic: "",
    designEnglish: "",
    designArabic: "",
    internationalsizesEnglish: "",
    internationalsizesArabic: "",
    numericalsizesEnglish: "",
    numericalsizesArabic: "",
    closureEnglish: "",
    closureArabic: "",
    occasionEnglish: "",
    occasionArabic: "",
    styleEnglish: "",
    styleArabic: "",
    fitEnglish: "",
    fitArabic: "",
    materialEnglish: "",
    materialArabic: "",
    lengthEnglish: "",
    lengthArabic: "",
    SleevelengthEnglish: "",
    SleevelengthArabic: "",
    sleevelengthEnglish: "",
    sleevelengthArabic: "",
    necklineEnglish: "",
    necklineArabic: "",
    CharacterEnglish: "",
    CharacterArabic: "",
    waisttypeEnglish: "",
    waisttypeArabic: "",
    waistTypeEnglish: "",
    waistTypeArabic: "",
    modelWearingSizeEnglish: "",
    modelWearingSizeArabic: "",
    careInstructionEnglish: "",
    careInstructionArabic: "",
    bodyComponentEnglish: "",
    bodyComponentArabic: "",
    colorEnglish: "",
    colorArabic: "",
    promotionEnglish: "",
    promotionArabic: "",
    piecesEnglish: "",
    piecesArabic: "",
    // maincategoryData: "",
    // categoryData: "",
    // subCategoryData: "",
    designData: "",
    materialData: "",
    careInstructionData: "",
    bodyComponentData: "",
    colorData: "",
    promotionData: "",
    styleData: "",
    occasionData: "",
    fitData: "",
    lengthData: "",
    sleevelengthData: "",
    necklineData: "",
    waisttypeData: "",
    closureData: "",
    piecesData: "",
    internationalsizesData: "",
    numericalsizesData: "",
    agesizesData: "",
    brasizesData: "",
    miscData: "",
    // mainCategory: "",
    // mainsubCategory: "",
    // choseCategory: "",
    isCityEdit: false,
    iscareInstructionsEdit: false,
    isagesizesEdit: false,
    isnumericalsizesEdit: false,
    isshippingCompanyEdit: false,
    isinternationalsizesEdit: false,
    isbrasizesEdit: false,
    ismiscEdit: false,
    isdesignEdit: false,
    isstyleEdit: false,
    ispiecesEdit: false,
    ismaterialEdit: false,
    isclosureEdit: false,
    ischaracterEdit: false,
    iswaisttypeEdit: false,
    isnecklineEdit: false,
    issleevelengthEdit: false,
    islengthEdit: false,
    isfitEdit: false,
    isoccasionEdit: false,
    iscolorEdit: false,
    // cityEnglish: "",
    // cityArabic: "",
    // cityData: "",
    deliveryEnglish: "",
    deliveryArabic: "",
    deliveryData: "",
    shippingCompanyEnglish: "",
    shippingCompanyArabic: "",
    shippingCompanyData: "",
    // main_category_id: "",
    // newSubCategory: "",
  };

  componentDidMount() {
    // this.getMainCategoryData();
    // this.getCategoryData();
    // this.getSubCategoryData();
    this.getdesignData();
    this.getnecklineData();
    this.getlengthData();
    this.getMaterialData();
    this.getcareInstructionData();
    this.getclosureData();
    this.getBodyComponentData();
    this.getColorData();
    this.getPromotionData();
    // this.getcityData();
    this.getDeliveryData();
    this.getShippingData();
    this.getStyleData();
    this.getOccasionData();
    this.getFitData();
    this.getsleeveData();
    this.getwaisttypeData();
    this.getcharacterData();
    this.getpiecesData();
    this.getinternationalsizesData();
    this.getnumericalsizesData();
    this.getagesizesData();
    this.getbrasizesData();
    this.getmiscData();
    this.gethowtomeasureData();
  }

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value })
  };

  handleIconChange = (e) => {

    var form = new FormData();
    for (var i = 0; i < e.target.files.length; i++) {
      form.append("file", e.target.files[i]);
    }
    let path = API_Path.addFileInS3;
    const addFileInS3Promise = new Promise((resolve, reject) => {
      resolve(PostApi(path, form));
    });
    addFileInS3Promise.then((res) => {
      if (res) {
        console.log("res is :: ", res.data.data[0]);
        this.setState({ careIcon: res.data.data[0], isIcon: true })
      }
    });
  };

  // handleSubChange = (e) => {
  //   this.setState({ main_category_id: e.target.value }, () => {
  //     this.getRelativeCategoryData();
  //   });
  // };

  // getMainCategoryData = () => {
  //
  //   let data = {};

  //   let path = API_Path.getMainCategory;
  //   const getMainCategoryPromise = new Promise((resolve, reject) => {
  //     resolve(PostApi(path, data));
  //   });

  //   getMainCategoryPromise.then((res) => {
  //     if (res) {
  //       // console.log('res is :: ', res.data.data);
  //       this.setState({ maincategoryData: res.data.data });
  //     }
  //   });
  // };

  // getCategoryData = () => {
  //
  //   let data = {};

  //   let path = API_Path.getCategory;
  //   const getCategoryPromise = new Promise((resolve, reject) => {
  //     resolve(PostApi(path, data));
  //   });

  //   getCategoryPromise.then((res) => {
  //     if (res) {
  //       // console.log('res is :: ', res.data.data);
  //       this.setState({ categoryData: res.data.data });
  //     }
  //   });
  // };

  // getSubCategoryData = () => {
  //
  //   let data = {};

  //   let path = API_Path.getSubCategory;
  //   const getSubCategoryPromise = new Promise((resolve, reject) => {
  //     resolve(PostApi(path, data));
  //   });

  //   getSubCategoryPromise.then((res) => {
  //     if (res) {
  //       // console.log('res is :: ', res.data.data);
  //       this.setState({ subCategoryData: res.data.data });
  //     }
  //   });
  // };

  getRelativeCategoryData = () => {


    let data = { main_category_id: parseInt(this.state.main_category_id) };
    let path = API_Path.getCategoryRelative;
    const getSubCategoryRelativePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getSubCategoryRelativePromise.then((res) => {
      if (res) {
        this.setState({ newSubCategory: res.data.data });
        console.log("res is :: ", res.data.data);
        // this.setState({ subCategoryData: res.data.data }, () => {
        //   console.log(this.state.subCategoryData.main_category);
        // });
      }
    });
  };

  getdesignData = () => {

    let data = {};

    let path = API_Path.getDesign;
    const getDesignPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getDesignPromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data);
        this.setState({ designData: res.data.data });
      }
    });
  };

  getbrasizesData = () => {

    let data = {};

    let path = API_Path.getBrasizes;
    const getBraSizesPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getBraSizesPromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data);
        this.setState({ brasizesData: res.data.data });
      }
    });
  };

  getmiscData = () => {

    let data = {};

    let path = API_Path.getMisc;
    const getMiscPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getMiscPromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data);
        this.setState({ miscData: res.data.data });
      }
    });
  };

  getagesizesData = () => {

    let data = {};

    let path = API_Path.getAgesizes;
    const getAgesizesPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getAgesizesPromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data);
        this.setState({ agesizesData: res.data.data });
      }
    });
  };

  gethowtomeasureData = () => {


    let data = {};

    let path = API_Path.gethowtomeasure;
    const getmeasurePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getmeasurePromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data);
        this.setState({ howtomeasureData: res.data.data });
      }
    });
  };

  getnecklineData = () => {

    let data = {};

    let path = API_Path.getNeckline;
    const getNecklinePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getNecklinePromise.then((res) => {
      if (res) {
        this.setState({ necklineData: res.data.data });
      }
    });
  };

  getlengthData = () => {

    let data = {};

    let path = API_Path.getLength;
    const getLengthPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getLengthPromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data);
        this.setState({ lengthData: res.data.data });
      }
    });
  };

  delete_data = (name, type, item) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>{this.context.language === "english" ? productEnglish.AreYouSure : productArabic.AreYouSure}</h1>
            <p>{this.context.language === "english" ? productEnglish.Youwanttodeletethis : productArabic.Youwanttodeletethis}{" "}{name}?</p>
            <button className="btn red-btn me-2" onClick={onClose}>
              {this.context.language === "english" ? productEnglish.No : productArabic.No}
            </button>
            <button
              className="btn red-btn"
              onClick={() => { onClose(); this.deleteItem(type, item.id); }}
            >
              {this.context.language === "english" ? productEnglish.YesDeleteit : productArabic.YesDeleteit}
            </button>
          </div>
        );
      },
    });
  };

  getMaterialData = () => {

    let data = {};

    let path = API_Path.getMaterial;
    const getMaterialPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getMaterialPromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data);
        this.setState({ materialData: res.data.data });
      }
    });
  };

  getcareInstructionData = () => {

    let data = {};

    let path = API_Path.getCareInstruction;
    const getcareInstructionDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getcareInstructionDataPromise.then((res) => {
      if (res) {
        this.setState({ careInstructionData: res.data.data });
      }
    });
  };

  getBodyComponentData = () => {

    let data = {};

    let path = API_Path.getBodyComponent;
    const getBodyComponentDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getBodyComponentDataPromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res);
        this.setState({ bodyComponentData: res.data.data });
      }
    });
  };

  getColorData = () => {

    let data = {};

    let path = API_Path.getColor;
    const getColorDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getColorDataPromise.then((res) => {
      if (res) {
        this.setState({ colorData: res.data.data });
      }
    });
  };

  getclosureData = () => {

    let data = {};

    let path = API_Path.getClosure;
    const getClosureDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getClosureDataPromise.then((res) => {
      if (res) {
        this.setState({ closureData: res.data.data });
      }
    });
  };

  getPromotionData = () => {

    let data = {};

    let path = API_Path.getPromotion;
    const getPromotionDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getPromotionDataPromise.then((res) => {
      if (res) {
        this.setState({ promotionData: res.data.data });
      }
    });
  };

  // getcityData = () => {
  //
  //   let data = {};

  //   let path = API_Path.getCity;
  //   const getcityDataPromise = new Promise((resolve, reject) => {
  //     resolve(PostApi(path, data));
  //   });

  //   getcityDataPromise.then((res) => {
  //     if (res) {
  //       this.setState({ cityData: res.data.data });
  //     }
  //   });
  // };

  getDeliveryData = () => {

    let data = {};

    let path = API_Path.getDeliveryTime;
    const getDeliveryDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getDeliveryDataPromise.then((res) => {
      if (res) {
        this.setState({ deliveryData: res.data.data });
      }
    });
  };

  getShippingData = () => {

    let data = {};

    let path = API_Path.getShippingCompany;
    const getShippingDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getShippingDataPromise.then((res) => {
      if (res) {
        this.setState({ shippingCompanyData: res.data.data });
      }
    });
  };

  getStyleData = () => {

    let data = {};

    let path = API_Path.getStyle;
    const getStyleDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getStyleDataPromise.then((res) => {
      if (res) {
        this.setState({ styleData: res.data.data });
      }
    });
  };

  getFitData = () => {

    let data = {};

    let path = API_Path.getFit;
    const getFitDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getFitDataPromise.then((res) => {
      if (res) {
        this.setState({ fitData: res.data.data });
      }
    });
  };

  getpiecesData = () => {

    let data = {};

    let path = API_Path.getPieces;
    const getPiecesDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getPiecesDataPromise.then((res) => {
      if (res) {
        this.setState({ piecesData: res.data.data });
      }
    });
  };

  getnumericalsizesData = () => {

    let data = {};

    let path = API_Path.getNumericalsizes;
    const getnumericalsizesDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getnumericalsizesDataPromise.then((res) => {
      if (res) {
        this.setState({ numericalsizesData: res.data.data });
      }
    });
  };

  getinternationalsizesData = () => {

    let data = {};

    let path = API_Path.getInternationalsizes;
    const getinternationalsizesDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getinternationalsizesDataPromise.then((res) => {
      if (res) {
        this.setState({ internationalsizesData: res.data.data });
      }
    });
  };

  getsleeveData = () => {

    let data = {};

    let path = API_Path.getSleeve;
    const getSleeveDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getSleeveDataPromise.then((res) => {
      if (res) {
        this.setState({ sleevelengthData: res.data.data });
      }
    });
  };

  getwaisttypeData = () => {

    let data = {};

    let path = API_Path.getWaist;
    const getWaistTypeDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getWaistTypeDataPromise.then((res) => {
      if (res) {
        this.setState({ waisttypeData: res.data.data });
      }
    });
  };

  getcharacterData = () => {

    let data = {};

    let path = API_Path.getCharacter;
    const getChracterDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getChracterDataPromise.then((res) => {
      if (res) {
        this.setState({ characterData: res.data.data });
      }
    });
  };

  getOccasionData = () => {

    let data = {};

    let path = API_Path.getOccasion;
    const getOccasionDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getOccasionDataPromise.then((res) => {
      if (res) {
        this.setState({ occasionData: res.data.data });
      }
    });
  };

  addItem = (item) => {
    let data = "";

    // if (item === "mainCategory") {
    //   if (this.state.mainCategoryEnglish !== "" && this.state.mainCategoryArabic !== "") {
    //     data = {
    //       english: this.state.mainCategoryEnglish,
    //       arabic: this.state.mainCategoryArabic,
    //     };

    //     let path = API_Path.addMainCategory;
    //     const AddMainCategoryPromise = new Promise((resolve, reject) => {
    //       resolve(PostApi(path, data));
    //     });

    //     AddMainCategoryPromise.then((res) => {
    //       if (res) {
    //         // console.log('res is :: ', res);
    //         this.setState({ mainCategoryEnglish: "", mainCategoryArabic: "" });
    //         toastr.success(res.data.message);
    //         this.getMainCategoryData();
    //       }
    //     });
    //   } else {
    //     toastr.warning("please fill up MainCategory field");
    //   }
    // }
    // if (item === "category") {
    //   if (this.state.CategoryEnglish !== "" && this.state.CategoryArabic !== "" && this.state.mainCategory !== "") {
    //     data = {
    //       english: this.state.CategoryEnglish,
    //       arabic: this.state.CategoryArabic,
    //       maincatagory: this.state.mainCategory,
    //     };
    //     console.log(data);
    //     let path = API_Path.addCategory;
    //     const AddCategoryPromise = new Promise((resolve, reject) => {
    //       resolve(PostApi(path, data));
    //     });

    //     AddCategoryPromise.then((res) => {
    //       if (res.data.success) {
    //         // console.log('res is :: ', res);
    //         this.setState({
    //           CategoryEnglish: "",
    //           CategoryArabic: "",
    //           mainCategory: "",
    //         });
    //         toastr.success(res.data.message);
    //         this.getCategoryData();
    //       }
    //     });
    //   } else {
    //     toastr.warning("please fill up Category field");
    //   }
    // }
    // if (item === "subCategory") {
    //   if (this.state.SubCategoryEnglish !== "" && this.state.SubCategoryArabic !== "") {
    //     data = {
    //       english: this.state.SubCategoryEnglish,
    //       arabic: this.state.SubCategoryArabic,
    //       mainsubcata: this.state.mainsubCategory,
    //       catagory: this.state.choseCategory,
    //     };
    //     let path = API_Path.addSubCategory;
    //     const addSubCategoryPromise = new Promise((resolve, reject) => {
    //       resolve(PostApi(path, data));
    //     });

    //     addSubCategoryPromise.then((res) => {
    //       if (res) {
    //         // console.log('res is :: ', res);
    //         this.setState({
    //           SubCategoryArabic: "",
    //           SubCategoryEnglish: "",
    //           mainsubCategory: "",
    //           choseCategory: "",
    //         });
    //         toastr.success(res.data.message);
    //         this.getSubCategoryData();
    //       }
    //     });
    //   } else {
    //     toastr.warning("please fill up SubCategory field");
    //   }
    // }
    if (item === "howtomeasure") {
      if (this.state.howtomeasureEnglish !== "" && this.state.howtomeasureArabic !== "" && this.state.howtomeasuredescArabic !== "" && this.state.howtomeasuredescEnglish !== "") {
        data = {
          title_en: this.state.howtomeasureEnglish,
          title_ar: this.state.howtomeasureArabic,
          description_en: this.state.howtomeasuredescEnglish,
          description_ar: this.state.howtomeasuredescArabic,
        };
        let path = API_Path.addhowtomeasure;
        const addDesignPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addDesignPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ howtomeasureArabic: "", howtomeasureEnglish: "", howtomeasuredescArabic: "", howtomeasuredescEnglish: "" });
            toastr.success(res.data.message);
            this.gethowtomeasureData();
          }
        });
      } else {
        toastr.warning("please fill up how to measure data field");
      }
    }
    if (item === "design") {
      if (this.state.designEnglish !== "" && this.state.designArabic !== "") {
        data = {
          english: this.state.designEnglish,
          arabic: this.state.designArabic,
        };
        let path = API_Path.addDesign;
        const addDesignPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addDesignPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ designArabic: "", designEnglish: "" });
            toastr.success(res.data.message);
            this.getdesignData();
          }
        });
      } else {
        toastr.warning("please fill up Design field");
      }
    }
    if (item === "brasizes") {
      if (this.state.brasizesEnglish !== "" && this.state.brasizesArabic !== "") {
        data = {
          english: this.state.brasizesEnglish,
          arabic: this.state.brasizesArabic,
        };
        let path = API_Path.addBrasizes;
        const addBraSizesPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addBraSizesPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ brasizesArabic: "", brasizesEnglish: "" });
            toastr.success(res.data.message);
            this.getbrasizesData();
          }
        });
      } else {
        toastr.warning("please fill up Bra Sizes field");
      }
    }
    if (item === "misc") {
      if (this.state.miscEnglish !== "" && this.state.miscArabic !== "") {
        data = {
          english: this.state.miscEnglish,
          arabic: this.state.miscArabic,
        };
        let path = API_Path.addMisc;
        const addMiscPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addMiscPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ miscArabic: "", miscEnglish: "" });
            toastr.success(res.data.message);
            this.getmiscData();
          }
        });
      } else {
        toastr.warning("please fill up misc. field");
      }
    }
    if (item === "agesizes") {
      if (this.state.agesizesEnglish !== "" && this.state.agesizesArabic !== "") {
        data = {
          english: this.state.agesizesEnglish,
          arabic: this.state.agesizesArabic,
        };
        let path = API_Path.addAgesizes;
        const addAgesizesPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addAgesizesPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ agesizesArabic: "", agesizesEnglish: "" });
            toastr.success(res.data.message);
            this.getagesizesData();
          }
        });
      } else {
        toastr.warning("please fill up Age Sizes field");
      }
    }
    if (item === "numericalsizes") {
      if (this.state.numericalsizesEnglish !== "" && this.state.numericalsizesArabic !== "") {
        data = {
          english: this.state.numericalsizesEnglish,
          arabic: this.state.numericalsizesArabic,
        };
        let path = API_Path.addNumericalsizes;
        const addnumericalsizesPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addnumericalsizesPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ numericalsizesArabic: "", numericalsizesEnglish: "" });
            toastr.success(res.data.message);
            this.getnumericalsizesData();
          }
        });
      } else {
        toastr.warning("please fill up Numerical Sizes field");
      }
    }
    if (item === "internationalsizes") {
      if (this.state.internationalsizesEnglish !== "" && this.state.internationalsizesArabic !== "") {
        data = {
          english: this.state.internationalsizesEnglish,
          arabic: this.state.internationalsizesArabic,
        };
        let path = API_Path.addInternationalsizes;
        const addinternationalsizesPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addinternationalsizesPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ internationalsizesArabic: "", internationalsizesEnglish: "" });
            toastr.success(res.data.message);
            this.getinternationalsizesData();
          }
        });
      } else {
        toastr.warning("please fill up International Sizes field");
      }
    }

    if (item === "pieces") {
      if (this.state.piecesEnglish !== "" && this.state.piecesArabic !== "") {
        data = {
          english: this.state.piecesEnglish,
          arabic: this.state.piecesArabic,
        };
        let path = API_Path.addPieces;
        const addPiecesPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addPiecesPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ piecesArabic: "", piecesEnglish: "" });
            toastr.success(res.data.message);
            this.getpiecesData();
          }
        });
      } else {
        toastr.warning("please fill up Pieces field");
      }
    }

    if (item === "closure") {
      if (this.state.closureEnglish !== "" && this.state.closureArabic !== "") {
        data = {
          english: this.state.closureEnglish,
          arabic: this.state.closureArabic,
        };
        let path = API_Path.addClosure;
        const addClosurePromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addClosurePromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ closureArabic: "", closureEnglish: "" });
            toastr.success(res.data.message);
            this.getclosureData();
          }
        });
      } else {
        toastr.warning("please fill up Design field");
      }
    }

    if (item === "waisttype") {
      if (this.state.waisttypeEnglish !== "" && this.state.waisttypeArabic !== "") {
        data = {
          english: this.state.waisttypeEnglish,
          arabic: this.state.waisttypeArabic,
        };
        let path = API_Path.addWaist;
        const addWaistTypePromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addWaistTypePromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ waisttypeArabic: "", waisttypeEnglish: "" });
            toastr.success(res.data.message);
            this.getwaisttypeData();
          }
        });
      } else {
        toastr.warning("please fill up Waist Type field");
      }
    }

    if (item === "character") {
      if (this.state.CharacterEnglish !== "" && this.state.CharacterArabic !== "") {
        data = {
          english: this.state.CharacterEnglish,
          arabic: this.state.CharacterArabic,
        };
        let path = API_Path.addCharacter;
        const addCharacterPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addCharacterPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ CharacterArabic: "", CharacterEnglish: "" });
            toastr.success(res.data.message);
            this.getcharacterData();
          }
        });
      } else {
        toastr.warning("please fill up Character field");
      }
    }

    if (item === "neckline") {
      if (this.state.necklineEnglish !== "" && this.state.necklineArabic !== "") {
        data = {
          english: this.state.necklineEnglish,
          arabic: this.state.necklineArabic,
        };
        let path = API_Path.addNeckline;
        const addNecklinePromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addNecklinePromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ necklineArabic: "", necklineEnglish: "" });
            toastr.success(res.data.message);
            this.getnecklineData();
          }
        });
      } else {
        toastr.warning("please fill up Neckline field");
      }
    }

    if (item === "sleevelength") {
      if (this.state.sleevelengthEnglish !== "" && this.state.sleevelengthArabic !== "") {
        data = {
          english: this.state.sleevelengthEnglish,
          arabic: this.state.sleevelengthArabic,
        };
        let path = API_Path.addSleeve;
        const addsleevelengthPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addsleevelengthPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ sleevelengthArabic: "", sleevelengthEnglish: "" });
            toastr.success(res.data.message);
            this.getsleeveData();
          }
        });
      } else {
        toastr.warning("please fill up Sleeve Length field");
      }
    }

    if (item === "length") {
      if (this.state.lengthEnglish !== "" && this.state.lengthArabic !== "") {
        data = {
          english: this.state.lengthEnglish,
          arabic: this.state.lengthArabic,
        };
        let path = API_Path.addLength;
        const addlengthPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addlengthPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ lengthArabic: "", lengthEnglish: "" });
            toastr.success(res.data.message);
            this.getlengthData();
          }
        });
      } else {
        toastr.warning("please fill up Length field");
      }
    }

    if (item === "fit") {
      if (this.state.fitEnglish !== "" && this.state.fitArabic !== "") {
        data = {
          english: this.state.fitEnglish,
          arabic: this.state.fitArabic,
        };
        let path = API_Path.addFit;
        const addfitPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addfitPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ fitArabic: "", fitEnglish: "" });
            toastr.success(res.data.message);
            this.getFitData();
          }
        });
      } else {
        toastr.warning("please fill up fit field");
      }
    }

    if (item === "occasion") {
      if (this.state.occasionEnglish !== "" && this.state.occasionArabic !== "") {
        data = {
          english: this.state.occasionEnglish,
          arabic: this.state.occasionArabic,
        };
        let path = API_Path.addOccasion;
        const addOccasionPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addOccasionPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ occasionArabic: "", occasionEnglish: "" });
            toastr.success(res.data.message);
            this.getOccasionData();
          }
        });
      } else {
        toastr.warning("please fill up Occasion field");
      }
    }

    if (item === "style") {
      if (this.state.styleEnglish !== "" && this.state.styleArabic !== "") {
        data = {
          english: this.state.styleEnglish,
          arabic: this.state.styleArabic,
        };
        let path = API_Path.addStyle;
        const addStylePromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addStylePromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ styleArabic: "", styleEnglish: "" });
            toastr.success(res.data.message);
            this.getStyleData();
          }
        });
      } else {
        toastr.warning("please fill up Style field");
      }
    }

    if (item === "material") {
      if (this.state.materialEnglish !== "" && this.state.materialArabic !== "") {
        data = {
          english: this.state.materialEnglish,
          arabic: this.state.materialArabic,
        };
        let path = API_Path.addMaterial;
        const addMaterialPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addMaterialPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ materialArabic: "", materialEnglish: "" });
            toastr.success(res.data.message);
            this.getMaterialData();
          }
        });
      } else {
        toastr.warning("please fill up Material field");
      }
    }

    if (item === "careInstruction") {
      if (this.state.careInstructionEnglish !== "" && this.state.careInstructionArabic !== "" && this.state.careIcon !== "") {
        data = {
          english: this.state.careInstructionEnglish,
          arabic: this.state.careInstructionArabic,
          image: this.state.careIcon,
        };
        let path = API_Path.addCareInstruction;
        const addCareInstructionPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addCareInstructionPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({
              careInstructionArabic: "",
              careInstructionEnglish: "",
              careIcon: "",
              isIcon: false
            });
            toastr.success(res.data.message);
            this.getcareInstructionData();
          }
        });
      } else {
        toastr.warning("please fill up CareInstruction field");
      }
    }

    if (item === "bodyComponent") {
      if (this.state.bodyComponentEnglish !== "" && this.state.bodyComponentArabic !== "") {
        data = {
          english: this.state.bodyComponentEnglish,
          arabic: this.state.bodyComponentArabic,
        };
        let path = API_Path.addBodyComponent;
        const addbodyComponentPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addbodyComponentPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({
              bodyComponentArabic: "",
              bodyComponentEnglish: "",
            });
            toastr.success(res.data.message);
            this.getBodyComponentData();
          }
        });
      } else {
        toastr.warning("please fill up BodyComponent field");
      }
    }

    if (item === "color") {
      if (this.state.colorEnglish !== "" && this.state.colorArabic !== "" && this.state.colorValue !== "") {
        data = {
          english: this.state.colorEnglish,
          arabic: this.state.colorArabic,
          hex: this.state.colorValue,
        };
        let path = API_Path.addcolor;
        const addcolorPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addcolorPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ colorArabic: "", colorEnglish: "", colorValue: "#000000" });
            toastr.success(res.data.message);
            this.getColorData();
          }
        });
      } else {
        toastr.warning("please fill up Color field");
      }
    }

    if (item === "promotion") {
      if (this.state.promotionEnglish !== "" && this.state.promotionArabic !== "") {
        data = {
          english: this.state.promotionEnglish,
          arabic: this.state.promotionArabic,
        };
        let path = API_Path.addpromotion;
        const addPromotionPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addPromotionPromise.then((res) => {
          if (res) {
            this.setState({ promotionEnglish: "", promotionArabic: "" });
            toastr.success(res.data.message);
            this.getPromotionData();
          }
        });
      } else {
        toastr.warning("please fill up Promotion field");
      }
    }

    if (item === "delivery") {
      if (this.state.deliveryEnglish !== "" && this.state.deliveryArabic !== "") {
        data = {
          english: this.state.deliveryEnglish,
          arabic: this.state.deliveryArabic,
        };
        let path = API_Path.addDeliveryTime;
        const addDeliveryTimePromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addDeliveryTimePromise.then((res) => {
          if (res) {
            this.setState({ deliveryEnglish: "", deliveryArabic: "" });
            toastr.success(res.data.message);
            this.getDeliveryData();
          }
        });
      } else {
        toastr.warning("please fill up Promotion field");
      }
    }

    if (item === "shippingCompany") {
      if (this.state.shippingCompanyEnglish !== "" && this.state.shippingCompanyArabic !== "") {
        data = {
          english: this.state.shippingCompanyEnglish,
          arabic: this.state.shippingCompanyArabic,
        };
        let path = API_Path.addShippingCompany;
        const addShippingCompanyPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addShippingCompanyPromise.then((res) => {
          if (res) {
            this.setState({
              shippingCompanyEnglish: "",
              shippingCompanyArabic: "",
            });
            toastr.success(res.data.message);
            this.getShippingData();
          }
        });
      } else {
        toastr.warning("please fill up Promotion field");
      }
    }
    // console.log('data is :: ', data);
  };

  editItem = (name, id) => {
    this.setState({ id: id })
    // if (name === "city") {
    //   let filterData = this.state.cityData.filter((item) => item.id === id)
    //   this.setState({ cityArabic: filterData[0].arabic, cityEnglish: filterData[0].english, isCityEdit: true })
    // }
    if (name === "brasizes") {
      let filterData = this.state.brasizesData.filter((item) => item.id === id)
      this.setState({ brasizesArabic: filterData[0].arabic, brasizesEnglish: filterData[0].english, isbrasizesEdit: true })
    }
    if (name === "misc") {
      let filterData = this.state.miscData.filter((item) => item.id === id)
      this.setState({ miscArabic: filterData[0].arabic, miscEnglish: filterData[0].english, ismiscEdit: true })
    }
    if (name === "internationalsizes") {
      let filterData = this.state.internationalsizesData.filter((item) => item.id === id)
      this.setState({ internationalsizesArabic: filterData[0].arabic, internationalsizesEnglish: filterData[0].english, isinternationalsizesEdit: true })
    }
    if (name === "numericalsizes") {
      let filterData = this.state.numericalsizesData.filter((item) => item.id === id)
      this.setState({ numericalsizesArabic: filterData[0].arabic, numericalsizesEnglish: filterData[0].english, isnumericalsizesEdit: true })
    }
    if (name === "agesizes") {
      let filterData = this.state.agesizesData.filter((item) => item.id === id)
      this.setState({ agesizesArabic: filterData[0].arabic, agesizesEnglish: filterData[0].english, isagesizesEdit: true })
    }
    if (name === "shippingCompany") {
      let filterData = this.state.shippingCompanyData.filter((item) => item.id === id)
      this.setState({ shippingCompanyArabic: filterData[0].arabic, shippingCompanyEnglish: filterData[0].english, isshippingCompanyEdit: true })
    }
    if (name === "design") {
      let filterData = this.state.designData.filter((item) => item.id === id)
      this.setState({ designArabic: filterData[0].arabic, designEnglish: filterData[0].english, isdesignEdit: true })
    }
    if (name === "style") {
      let filterData = this.state.styleData.filter((item) => item.id === id)
      this.setState({ styleArabic: filterData[0].arabic, styleEnglish: filterData[0].english, isstyleEdit: true })
    }
    if (name === "occasion") {
      let filterData = this.state.occasionData.filter((item) => item.id === id)
      this.setState({ occasionArabic: filterData[0].arabic, occasionEnglish: filterData[0].english, isoccasionEdit: true })
    }
    if (name === "fit") {
      let filterData = this.state.fitData.filter((item) => item.id === id)
      this.setState({ fitArabic: filterData[0].arabic, fitEnglish: filterData[0].english, isfitEdit: true })
    }
    if (name === "length") {
      let filterData = this.state.lengthData.filter((item) => item.id === id)
      this.setState({ lengthArabic: filterData[0].arabic, lengthEnglish: filterData[0].english, islengthEdit: true })
    }
    if (name === "sleevelength") {
      let filterData = this.state.sleevelengthData.filter((item) => item.id === id)
      this.setState({ sleevelengthArabic: filterData[0].arabic, sleevelengthEnglish: filterData[0].english, issleevelengthEdit: true })
    }
    if (name === "neckline") {
      let filterData = this.state.necklineData.filter((item) => item.id === id)
      this.setState({ necklineArabic: filterData[0].arabic, necklineEnglish: filterData[0].english, isnecklineEdit: true })
    }
    if (name === "waisttype") {
      let filterData = this.state.waisttypeData.filter((item) => item.id === id)
      this.setState({ waisttypeArabic: filterData[0].arabic, waisttypeEnglish: filterData[0].english, iswaisttypeEdit: true })
    }
    if (name === "character") {
      let filterData = this.state.characterData.filter((item) => item.id === id)
      this.setState({ CharacterArabic: filterData[0].arabic, CharacterEnglish: filterData[0].english, ischaracterEdit: true })
    }
    if (name === "closure") {
      let filterData = this.state.closureData.filter((item) => item.id === id)
      this.setState({ closureArabic: filterData[0].arabic, closureEnglish: filterData[0].english, isclosureEdit: true })
    }
    if (name === "material") {
      let filterData = this.state.materialData.filter((item) => item.id === id)
      this.setState({ materialArabic: filterData[0].arabic, materialEnglish: filterData[0].english, ismaterialEdit: true })
    }
    if (name === "pieces") {
      let filterData = this.state.piecesData.filter((item) => item.id === id)
      this.setState({ piecesArabic: filterData[0].arabic, piecesEnglish: filterData[0].english, ispiecesEdit: true })
    }
    if (name === "color") {
      let filterData = this.state.colorData.filter((item) => item.id === id)
      this.setState({ colorArabic: filterData[0].arabic, colorEnglish: filterData[0].english, colorValue: filterData[0].hex, iscolorEdit: true })
    }
    if (name === "careInstruction") {
      let filterData = this.state.careInstructionData.filter((item) => item.id === id)
      this.setState({ careInstructionArabic: filterData[0].arabic, careInstructionEnglish: filterData[0].english, careIcon: filterData[0].image, iscareInstructionsEdit: true, isIcon: true })
    }
    if (name === "howtomeasure") {
      let filterData = this.state.howtomeasureData.filter((item) => item.id === id)
      this.setState({ howtomeasureArabic: filterData[0].title_ar, howtomeasureEnglish: filterData[0].title_en, howtomeasuredescEnglish: filterData[0].description_en, howtomeasuredescArabic: filterData[0].description_ar, ishowtomeasureEdit: true, })
    }

  }

  editAddItem = (item) => {
    let data = "";

    if (item === "design") {
      if (this.state.designEnglish !== "" && this.state.designArabic !== "") {
        data = {
          id: this.state.id,
          english: this.state.designEnglish,
          arabic: this.state.designArabic,
        };
        let path = API_Path.editDesign;
        const addDesignPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addDesignPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ designArabic: "", designEnglish: "", isdesignEdit: false });
            toastr.success(res.data.message);
            this.getdesignData();
          }
        });
      } else {
        toastr.warning("please fill up Design field");
      }
    }
    if (item === "howtomeasure") {
      if (this.state.howtomeasureEnglish !== "" && this.state.howtomeasureArabic !== "" && this.state.howtomeasuredescArabic !== "" && this.state.howtomeasuredescEnglish !== "") {
        data = {
          id: this.state.id,
          title_en: this.state.howtomeasureEnglish,
          title_ar: this.state.howtomeasureArabic,
          description_en: this.state.howtomeasuredescEnglish,
          description_ar: this.state.howtomeasuredescArabic,
        };
        let path = API_Path.edithowtomeasure;
        const addDesignPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addDesignPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ howtomeasureArabic: "", howtomeasureEnglish: "", howtomeasuredescArabic: "", howtomeasuredescEnglish: "", ishowtomeasureEdit: false });
            toastr.success(res.data.message);
            this.gethowtomeasureData();
          }
        });
      } else {
        toastr.warning("please fill up how to measure data field");
      }
    }
    if (item === "brasizes") {
      if (this.state.brasizesEnglish !== "" && this.state.brasizesArabic !== "") {
        data = {
          id: this.state.id,
          english: this.state.brasizesEnglish,
          arabic: this.state.brasizesArabic,
        };
        let path = API_Path.editBrasizes;
        const addBraSizesPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addBraSizesPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ brasizesArabic: "", brasizesEnglish: "", isbrasizesEdit: false });
            toastr.success(res.data.message);
            this.getbrasizesData();
          }
        });
      } else {
        toastr.warning("please fill up Bra Sizes field");
      }
    }
    if (item === "misc") {
      if (this.state.miscEnglish !== "" && this.state.miscArabic !== "") {
        data = {
          id: this.state.id,
          english: this.state.miscEnglish,
          arabic: this.state.miscArabic,
        };
        let path = API_Path.editMisc;
        const addMiscPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addMiscPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ miscArabic: "", miscEnglish: "", ismiscEdit: false });
            toastr.success(res.data.message);
            this.getmiscData();
          }
        });
      } else {
        toastr.warning("please fill up Bra Sizes field");
      }
    }
    if (item === "agesizes") {
      if (this.state.agesizesEnglish !== "" && this.state.agesizesArabic !== "") {
        data = {
          id: this.state.id,
          english: this.state.agesizesEnglish,
          arabic: this.state.agesizesArabic,
        };
        let path = API_Path.editAgesizes;
        const addAgesizesPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addAgesizesPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ agesizesArabic: "", agesizesEnglish: "", isagesizesEdit: false });
            toastr.success(res.data.message);
            this.getagesizesData();
          }
        });
      } else {
        toastr.warning("please fill up Age Sizes field");
      }
    }
    if (item === "numericalsizes") {
      if (this.state.numericalsizesEnglish !== "" && this.state.numericalsizesArabic !== "") {
        data = {
          id: this.state.id,
          english: this.state.numericalsizesEnglish,
          arabic: this.state.numericalsizesArabic,
        };
        let path = API_Path.editNumericalsizes;
        const addnumericalsizesPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addnumericalsizesPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ numericalsizesArabic: "", numericalsizesEnglish: "", isnumericalsizesEdit: false });
            toastr.success(res.data.message);
            this.getnumericalsizesData();
          }
        });
      } else {
        toastr.warning("please fill up Numerical Sizes field");
      }
    }
    if (item === "internationalsizes") {
      if (this.state.internationalsizesEnglish !== "" && this.state.internationalsizesArabic !== "") {
        data = {
          id: this.state.id,
          english: this.state.internationalsizesEnglish,
          arabic: this.state.internationalsizesArabic,
        };
        let path = API_Path.editInternationalsizes;
        const addinternationalsizesPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addinternationalsizesPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ internationalsizesArabic: "", internationalsizesEnglish: "", isinternationalsizesEdit: false });
            toastr.success(res.data.message);
            this.getinternationalsizesData();
          }
        });
      } else {
        toastr.warning("please fill up International Sizes field");
      }
    }

    if (item === "pieces") {
      if (this.state.piecesEnglish !== "" && this.state.piecesArabic !== "") {
        data = {
          id: this.state.id,
          english: this.state.piecesEnglish,
          arabic: this.state.piecesArabic,
        };
        let path = API_Path.editPieces;
        const addPiecesPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addPiecesPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ piecesArabic: "", piecesEnglish: "", ispiecesEdit: false });
            toastr.success(res.data.message);
            this.getpiecesData();
          }
        });
      } else {
        toastr.warning("please fill up Pieces field");
      }
    }

    if (item === "closure") {
      if (this.state.closureEnglish !== "" && this.state.closureArabic !== "") {
        data = {
          id: this.state.id,
          english: this.state.closureEnglish,
          arabic: this.state.closureArabic,
        };
        let path = API_Path.editClosure;
        const addClosurePromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addClosurePromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ closureArabic: "", closureEnglish: "", isclosureEdit: false });
            toastr.success(res.data.message);
            this.getclosureData();
          }
        });
      } else {
        toastr.warning("please fill up Design field");
      }
    }

    if (item === "waisttype") {
      if (this.state.waisttypeEnglish !== "" && this.state.waisttypeArabic !== "") {
        data = {
          id: this.state.id,
          english: this.state.waisttypeEnglish,
          arabic: this.state.waisttypeArabic,
        };
        let path = API_Path.editWaist;
        const addWaistTypePromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addWaistTypePromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ waisttypeArabic: "", waisttypeEnglish: "", iswaisttypeEdit: false });
            toastr.success(res.data.message);
            this.getwaisttypeData();
          }
        });
      } else {
        toastr.warning("please fill up Waist Type field");
      }
    }

    if (item === "character") {
      if (this.state.CharacterEnglish !== "" && this.state.CharacterArabic !== "") {
        data = {
          id: this.state.id,
          english: this.state.CharacterEnglish,
          arabic: this.state.CharacterArabic,
        };
        let path = API_Path.editCharacter;
        const addCharacterPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addCharacterPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ CharacterArabic: "", CharacterEnglish: "", ischaracterEdit: false });
            toastr.success(res.data.message);
            this.getcharacterData();
          }
        });
      } else {
        toastr.warning("please fill up Character field");
      }
    }

    if (item === "neckline") {
      if (this.state.necklineEnglish !== "" && this.state.necklineArabic !== "") {
        data = {
          id: this.state.id,
          english: this.state.necklineEnglish,
          arabic: this.state.necklineArabic,
        };
        let path = API_Path.editNeckline;
        const addNecklinePromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addNecklinePromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ necklineArabic: "", necklineEnglish: "", isnecklineEdit: false });
            toastr.success(res.data.message);
            this.getnecklineData();
          }
        });
      } else {
        toastr.warning("please fill up Neckline field");
      }
    }

    if (item === "sleevelength") {
      if (this.state.sleevelengthEnglish !== "" && this.state.sleevelengthArabic !== "") {
        data = {
          id: this.state.id,
          english: this.state.sleevelengthEnglish,
          arabic: this.state.sleevelengthArabic,
        };
        let path = API_Path.editSleeve;
        const addsleevelengthPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addsleevelengthPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ sleevelengthArabic: "", sleevelengthEnglish: "", issleevelengthEdit: false });
            toastr.success(res.data.message);
            this.getsleeveData();
          }
        });
      } else {
        toastr.warning("please fill up Sleeve Length field");
      }
    }

    if (item === "length") {
      if (this.state.lengthEnglish !== "" && this.state.lengthArabic !== "") {
        data = {
          id: this.state.id,
          english: this.state.lengthEnglish,
          arabic: this.state.lengthArabic,
        };
        let path = API_Path.editLength;
        const addlengthPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addlengthPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ lengthArabic: "", lengthEnglish: "", islengthEdit: false });
            toastr.success(res.data.message);
            this.getlengthData();
          }
        });
      } else {
        toastr.warning("please fill up Length field");
      }
    }

    if (item === "fit") {
      if (this.state.fitEnglish !== "" && this.state.fitArabic !== "") {
        data = {
          id: this.state.id,
          english: this.state.fitEnglish,
          arabic: this.state.fitArabic,
        };
        let path = API_Path.editFit;
        const addfitPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addfitPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ fitArabic: "", fitEnglish: "", isfitEdit: false });
            toastr.success(res.data.message);
            this.getFitData();
          }
        });
      } else {
        toastr.warning("please fill up fit field");
      }
    }

    if (item === "occasion") {
      if (this.state.occasionEnglish !== "" && this.state.occasionArabic !== "") {
        data = {
          id: this.state.id,
          english: this.state.occasionEnglish,
          arabic: this.state.occasionArabic,
        };
        let path = API_Path.editOccasion;
        const addOccasionPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addOccasionPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ occasionArabic: "", occasionEnglish: "", isoccasionEdit: false });
            toastr.success(res.data.message);
            this.getOccasionData();
          }
        });
      } else {
        toastr.warning("please fill up Occasion field");
      }
    }

    if (item === "style") {
      if (this.state.styleEnglish !== "" && this.state.styleArabic !== "") {
        data = {
          id: this.state.id,
          english: this.state.styleEnglish,
          arabic: this.state.styleArabic,
        };
        let path = API_Path.editStyle;
        const addStylePromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addStylePromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ styleArabic: "", styleEnglish: "", isstyleEdit: false });
            toastr.success(res.data.message);
            this.getStyleData();
          }
        });
      } else {
        toastr.warning("please fill up Style field");
      }
    }

    if (item === "material") {
      if (this.state.materialEnglish !== "" && this.state.materialArabic !== "") {
        data = {
          id: this.state.id,
          english: this.state.materialEnglish,
          arabic: this.state.materialArabic,
        };
        let path = API_Path.editMaterial;
        const addMaterialPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addMaterialPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ materialArabic: "", materialEnglish: "", ismaterialEdit: false });
            toastr.success(res.data.message);
            this.getMaterialData();
          }
        });
      } else {
        toastr.warning("please fill up Material field");
      }
    }

    if (item === "careInstruction") {
      if (this.state.careInstructionEnglish !== "" && this.state.careInstructionArabic !== "" && this.state.careIcon !== "") {
        data = {
          id: this.state.id,
          english: this.state.careInstructionEnglish,
          arabic: this.state.careInstructionArabic,
          image: this.state.careIcon
        };
        let path = API_Path.editCareInstruction;
        const addCareInstructionPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addCareInstructionPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({
              careInstructionArabic: "",
              careInstructionEnglish: "",
              iscareInstructionsEdit: false,
              isIcon: false,
            });
            toastr.success(res.data.message);
            this.getcareInstructionData();
          }
        });
      } else {
        toastr.warning("please fill up CareInstruction field");
      }
    }

    if (item === "bodyComponent") {
      if (this.state.bodyComponentEnglish !== "" && this.state.bodyComponentArabic !== "") {
        data = {
          english: this.state.bodyComponentEnglish,
          arabic: this.state.bodyComponentArabic,
        };
        let path = API_Path.addBodyComponent;
        const addbodyComponentPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addbodyComponentPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({
              bodyComponentArabic: "",
              bodyComponentEnglish: "",
            });
            toastr.success(res.data.message);
            this.getBodyComponentData();
          }
        });
      } else {
        toastr.warning("please fill up BodyComponent field");
      }
    }

    if (item === "color") {
      if (this.state.colorEnglish !== "" && this.state.colorArabic !== "") {
        data = {
          id: this.state.id,
          english: this.state.colorEnglish,
          arabic: this.state.colorArabic,
          hex: this.state.colorValue,
        };
        let path = API_Path.editcolor;
        const addcolorPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addcolorPromise.then((res) => {
          if (res) {
            // console.log('res is :: ', res);
            this.setState({ colorArabic: "", colorEnglish: "", iscolorEdit: false });
            toastr.success(res.data.message);
            this.getColorData();
          }
        });
      } else {
        toastr.warning("please fill up Color field");
      }
    }

    if (item === "promotion") {
      if (this.state.promotionEnglish !== "" && this.state.promotionArabic !== "") {
        data = {
          english: this.state.promotionEnglish,
          arabic: this.state.promotionArabic,
        };
        let path = API_Path.addpromotion;
        const addPromotionPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addPromotionPromise.then((res) => {
          if (res) {
            this.setState({ promotionEnglish: "", promotionArabic: "" });
            toastr.success(res.data.message);
            this.getPromotionData();
          }
        });
      } else {
        toastr.warning("please fill up Promotion field");
      }
    }

    if (item === "delivery") {
      if (this.state.deliveryEnglish !== "" && this.state.deliveryArabic !== "") {
        data = {
          english: this.state.deliveryEnglish,
          arabic: this.state.deliveryArabic,
        };
        let path = API_Path.addDeliveryTime;
        const addDeliveryTimePromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addDeliveryTimePromise.then((res) => {
          if (res) {
            this.setState({ deliveryEnglish: "", deliveryArabic: "" });
            toastr.success(res.data.message);
            this.getDeliveryData();
          }
        });
      } else {
        toastr.warning("please fill up Promotion field");
      }
    }

    if (item === "shippingCompany") {
      if (this.state.shippingCompanyEnglish !== "" && this.state.shippingCompanyArabic !== "") {
        data = {
          id: this.state.id,
          english: this.state.shippingCompanyEnglish,
          arabic: this.state.shippingCompanyArabic,
        };
        let path = API_Path.editShippingCompany;
        const addShippingCompanyPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        addShippingCompanyPromise.then((res) => {
          if (res) {
            this.setState({
              shippingCompanyEnglish: "",
              shippingCompanyArabic: "",
              isshippingCompanyEdit: false
            });
            toastr.success(res.data.message);
            this.getShippingData();
          }
        });
      } else {
        toastr.warning("please fill up Promotion field");
      }
    }
    // console.log('data is :: ', data);
  };

  deleteItem = (type, itemToDelete) => {
    let path;
    // if (type === "mainCategory") {
    //   path = API_Path.deleteMainCategory;
    // }
    // if (type === "category") {
    //   path = API_Path.deleteCategory;
    // }
    // if (type === "subCategory") {
    //   path = API_Path.deleteSubCategory;
    // }
    if (type === "design") {
      path = API_Path.deleteDesign;
    }
    if (type === "howtomeasure") {
      path = API_Path.deletehowtomeasure;
    }
    if (type === "brasizes") {
      path = API_Path.deleteBrasizes;
    }
    if (type === "misc") {
      path = API_Path.deleteMisc;
    }
    if (type === "agesizes") {
      path = API_Path.deleteAgesizes;
    }
    if (type === "pieces") {
      path = API_Path.deletePieces;
    }
    if (type === "numericalsizes") {
      path = API_Path.deleteNumericalsizes;
    }
    if (type === "internationalsizes") {
      path = API_Path.deleteInternationalsizes;
    }
    if (type === "closure") {
      path = API_Path.deleteClosure;
    }
    if (type === "character") {
      path = API_Path.deleteCharacter;
    }
    if (type === "waisttype") {
      path = API_Path.deleteWaist;
    }
    if (type === "neckline") {
      path = API_Path.deleteNeckline;
    }
    if (type === "sleevelength") {
      path = API_Path.deleteSleeve;
    }
    if (type === "length") {
      path = API_Path.deleteLength;
    }
    if (type === "fit") {
      path = API_Path.deleteFit;
    }
    if (type === "material") {
      path = API_Path.deleteMaterial;
    }
    if (type === "careInstruction") {
      path = API_Path.deleteCareInstruction;
    }
    if (type === "bodyComponent") {
      path = API_Path.deleteBodyComponent;
    }
    if (type === "color") {
      path = API_Path.deletecolor;
    }
    if (type === "promotion") {
      path = API_Path.deletepromotion;
    }
    // if (type === "city") {
    //   path = API_Path.deleteCity;
    // }
    if (type === "delivery") {
      path = API_Path.deleteDeliveryTime;
    }
    if (type === "shippingCompany") {
      path = API_Path.deleteShippingCompany;
    }
    if (type === "style") {
      path = API_Path.deleteStyle;
    }
    if (type === "occasion") {
      path = API_Path.deleteOccasion;
    }

    let data = {
      id: itemToDelete,
    };
    const deleteItem = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    deleteItem.then((res) => {
      if (res) {
        // console.log('res is :: ', res);
        // if (type === "mainCategory") {
        //   toastr.success(res.data.message);
        //   this.getMainCategoryData();
        // }
        // if (type === "category") {
        //   toastr.success(res.data.message);
        //   this.getCategoryData();
        // }
        // if (type === "subCategory") {
        //   toastr.success(res.data.message);
        //   this.getSubCategoryData();
        // }
        if (type === "design") {
          toastr.success(res.data.message);
          this.getdesignData();
        }
        if (type === "howtomeasure") {
          toastr.success(res.data.message);
          this.gethowtomeasureData();
        }
        if (type === "agesizes") {
          toastr.success(res.data.message);
          this.getagesizesData();
        }
        if (type === "numericalsizes") {
          toastr.success(res.data.message);
          this.getnumericalsizesData();
        }
        if (type === "internationalsizes") {
          toastr.success(res.data.message);
          this.getinternationalsizesData();
        }
        if (type === "brasizes") {
          toastr.success(res.data.message);
          this.getbrasizesData();
        }
        if (type === "misc") {
          toastr.success(res.data.message);
          this.getmiscData();
        }
        if (type === "closure") {
          toastr.success(res.data.message);
          this.getclosureData();
        }
        if (type === "pieces") {
          toastr.success(res.data.message);
          this.getpiecesData();
        }
        if (type === "character") {
          toastr.success(res.data.message);
          this.getcharacterData();
        }
        if (type === "waisttype") {
          toastr.success(res.data.message);
          this.getwaisttypeData();
        }
        if (type === "neckline") {
          toastr.success(res.data.message);
          this.getnecklineData();
        }
        if (type === "fit") {
          toastr.success(res.data.message);
          this.getFitData();
        }
        if (type === "material") {
          toastr.success(res.data.message);
          this.getMaterialData();
        }
        if (type === "style") {
          toastr.success(res.data.message);
          this.getStyleData();
        }
        if (type === "length") {
          toastr.success(res.data.message);
          this.getlengthData();
        }
        if (type === "sleevelength") {
          toastr.success(res.data.message);
          this.getsleeveData();
        }
        if (type === "occasion") {
          toastr.success(res.data.message);
          this.getOccasionData();
        }
        if (type === "careInstruction") {
          toastr.success(res.data.message);
          this.getcareInstructionData();
        }
        if (type === "bodyComponent") {
          toastr.success(res.data.message);
          this.getBodyComponentData();
        }
        if (type === "color") {
          toastr.success(res.data.message);
          this.getColorData();
        }
        if (type === "promotion") {
          toastr.success(res.data.message);
          this.getPromotionData();
        }
        // if (type === "city") {
        //   toastr.success(res.data.message);
        //   this.getcityData();
        // }
        if (type === "delivery") {
          toastr.success(res.data.message);
          this.getDeliveryData();
        }
        if (type === "shippingCompany") {
          toastr.success(res.data.message);
          this.getShippingData();
        }
      }
    });
  };

  render() {
    let Language = this.context.language === "english" ? TableFieldEnglish : TableFieldArabic;
    let ButtonLanguage = this.context.language === "english" ? buttonEnglish : buttonArabic;
    let titleLanguage = this.context.language === "english" ? titleEnglish : titleArabic;
    let productLanguage = this.context.language === "english" ? productEnglish : productArabic;
    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space align-items-center">
            <div className="col-12">
              <div className="market-cysrom-tabs-comn">
                <Tabs defaultActiveKey="product_attributes" id="product_attributes_data">
                  <Tab eventKey="product_attributes" title={titleLanguage.ProductAttributes}>
                    <div className="row common-space">
                      <div className="col-xl-4 col-md-6 mb-3">
                        <div className="white-box">
                          <div className="row">
                            <>
                              {/* <div className="col-xl-6 col-lg-12 mb-3 form-group">
                              <label>{productLanguage.mainCategory}</label>
                              <div className="d-flex align-items-center">
                                <input type="text" className="form-control input-custom-class me-2" name="mainCategoryEnglish" value={this.state.mainCategoryEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterCategoryInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="mainCategoryArabic" value={this.state.mainCategoryArabic} onChange={this.handleChange} placeholder={productLanguage.EnterCategoryInEnglish} />
                                <button onClick={() => this.addItem("mainCategory")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.maincategoryData &&
                                    this.state.maincategoryData.length > 0 &&
                                    this.state.maincategoryData.map((item, i) => {
                                      return (
                                        <li key={i}>
                                          <span>{item.english}</span>
                                          <bdi className="mx-2">|</bdi>
                                          <span>{item.arabic}</span>
                                          <mark onClick={() => this.deleteItem("mainCategory", item.id)} className="ms-auto bg-transparent bi bi-x p-0"></mark>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                            <div className="col-xl-6 col-lg-12  mb-3 form-group">
                              <label>{productLanguage.category}</label>
                              <div className="d-flex align-items-center">
                                <select className="form-control input-custom-class me-2 form-select" name="mainCategory" value={this.state.mainCategory} onChange={this.handleChange}>
                                  <option defaultValue>{productLanguage.chooseMainCategory}</option>
                                  {this.state.maincategoryData.length > 0 &&
                                    this.state.maincategoryData?.map((item, i) => {
                                      return (
                                        <option key={i} value={item.id}>
                                          {item.english} | {item.arabic}
                                        </option>
                                      );
                                    })}
                                </select>
                                <input type="text" className="form-control input-custom-class me-2" name="CategoryEnglish" value={this.state.CategoryEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterCategoryInEnglish} />
                                <input type="text" className="form-control input-custom-class me-2" dir="rtl" name="CategoryArabic" value={this.state.CategoryArabic} onChange={this.handleChange} placeholder={productLanguage.EnterCategoryInArabic} />
                                <button onClick={() => this.addItem("category")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.categoryData &&
                                    this.state.categoryData.length > 0 &&
                                    this.state.categoryData.map((item, i) => {
                                      return (
                                        <li key={i}>
                                          <span>{item.main_category_english}</span>
                                          <bdi className="mx-2">|</bdi>
                                          <span>{item.main_category_arabic}</span>
                                          &nbsp;&nbsp;
                                          <bdi>
                                            <b>&rArr;</b>
                                          </bdi>
                                          &nbsp;&nbsp;
                                          <span>{item.english}</span>
                                          <bdi className="mx-2">|</bdi>
                                          <span>{item.arabic}</span>
                                          <mark onClick={() => this.deleteItem("category", item.id)} className="ms-auto bg-transparent bi bi-x p-0"></mark>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                            <div className="col-xl-6 col-lg-12  mb-3 form-group">
                              <label>{productLanguage.subCategory}</label>

                              <div className="d-flex align-items-center">
                                <select
                                  className="form-control input-custom-class me-2 form-select"
                                  name="mainsubCategory"
                                  value={this.state.mainsubCategory}
                                  onChange={this.handleSubChange}
                                  // onChange={this.handleChange}
                                >
                                  <option>{productLanguage.chooseMainCategory}</option>
                                  {this.state.maincategoryData.length > 0 &&
                                    this.state.maincategoryData?.map((item, i) => {
                                      return (
                                        <option key={i} value={item.id}>
                                          {item.english} | {item.arabic}
                                        </option>
                                      );
                                    })}
                                </select>
                                <select className="form-control input-custom-class me-2 form-select" name="choseCategory" value={this.state.choseCategory} onChange={this.handleChange}>
                                  <option>{productLanguage.chooseCategory}</option>
                                  {this.state.newSubCategory.length > 0 &&
                                    this.state.newSubCategory?.map((item, i) => {
                                      // console.log(item);
                                      return (
                                        <option key={i} value={item.id}>
                                          {item.english} | {item.arabic}
                                        </option>
                                      );
                                    })}
                                </select>
                                <input type="text" className="form-control input-custom-class me-2" name="SubCategoryEnglish" value={this.state.SubCategoryEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterSubCategoryInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="SubCategoryArabic" value={this.state.SubCategoryArabic} onChange={this.handleChange} placeholder={productLanguage.EnterSubCategoryInArabic} />
                                <button onClick={() => this.addItem("subCategory")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.subCategoryData &&
                                    this.state.subCategoryData.length > 0 &&
                                    this.state.subCategoryData.map((item, i) => {
                                      return (
                                        <li key={i}>
                                          <span>{item.main_english}</span>
                                          <bdi className="mx-2">|</bdi>
                                          <span>{item.main_arabic}</span>&nbsp;&nbsp;
                                          <bdi>
                                            <b>&rArr;</b>
                                          </bdi>
                                          &nbsp;&nbsp;
                                          <span>{item.category_english}</span>
                                          <bdi className="mx-2">|</bdi>
                                          <span>{item.category_arabic}</span>&nbsp;&nbsp;
                                          <bdi>
                                            <b>&rArr;</b>
                                          </bdi>
                                          &nbsp;&nbsp;
                                          <span>{item.english}</span>
                                          <bdi className="mx-2">|</bdi>
                                          <span>{item.arabic}</span>
                                          <mark onClick={() => this.deleteItem("subCategory", item.id)} className="ms-auto bg-transparent bi bi-x p-0"></mark>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div> */}
                            </>
                            <div className="col-12 mb-3 form-group">
                              <label>{productLanguage.Design}</label>
                              <div className="d-flex align-items-center">
                                <input type="text" className="form-control input-custom-class me-2" name="designEnglish" value={this.state.designEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterDesignNameInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="designArabic" value={this.state.designArabic} onChange={this.handleChange} placeholder={productLanguage.EnterDesignNameInArabic} />
                                <button onClick={() => this.state.isdesignEdit ? this.editAddItem("design") : this.addItem("design")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.designData &&
                                    this.state.designData.length > 0 &&
                                    this.state.designData.map((item, i) => {
                                      return (
                                        <li key={i} className="d-flex justify-content-between">
                                          <div>
                                            <span>{item.english}</span>
                                            <bdi className="mx-2">|</bdi>
                                            <span>{item.arabic}</span>
                                          </div>
                                          <div>
                                            <bdi onClick={() => this.editItem("design", item.id)} className="cursor-pointer" title="edit">
                                              <i class="bi bi-pencil-square"></i>
                                            </bdi>
                                            <mark onClick={() => this.delete_data(productLanguage.Design, "design", item)} className="ms-3 bg-transparent bi bi-x p-0"></mark>
                                          </div>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-xl-4 col-md-6 mb-3">
                        <div className="white-box">
                          <div className="row">
                            <div className="col-12 mb-3 form-group">
                              <label>{productLanguage.style}</label>
                              <div className="d-flex align-items-center">
                                <input type="text" className="form-control input-custom-class me-2" name="styleEnglish" value={this.state.styleEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterStyleNameInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="styleArabic" value={this.state.styleArabic} onChange={this.handleChange} placeholder={productLanguage.EnterStyleNameInArabic} />
                                <button onClick={() => this.state.isstyleEdit ? this.editAddItem("style") : this.addItem("style")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.styleData &&
                                    this.state.styleData.length > 0 &&
                                    this.state.styleData.map((item, i) => {
                                      return (
                                        <li key={i} className="d-flex justify-content-between">
                                          <div>
                                            <span>{item.english}</span>
                                            <bdi className="mx-2">|</bdi>
                                            <span>{item.arabic}</span>
                                          </div>
                                          <div>
                                            <bdi onClick={() => this.editItem("style", item.id)} className="cursor-pointer" title="edit">
                                              <i class="bi bi-pencil-square"></i>
                                            </bdi>
                                            <mark onClick={() => this.delete_data(productLanguage.style, "style", item)} className="ms-3 bg-transparent bi bi-x p-0"></mark>
                                          </div>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-xl-4 col-md-6 mb-3">
                        <div className="white-box">
                          <div className="row">
                            <div className="col-12 mb-3 form-group">
                              <label>{productLanguage.occasion}</label>
                              <div className="d-flex align-items-center">
                                <input type="text" className="form-control input-custom-class me-2" name="occasionEnglish" value={this.state.occasionEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterOccasionNameInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="occasionArabic" value={this.state.occasionArabic} onChange={this.handleChange} placeholder={productLanguage.EnterOccasionNameInArabic} />
                                <button onClick={() => this.state.isoccasionEdit ? this.editAddItem("occasion") : this.addItem("occasion")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.occasionData &&
                                    this.state.occasionData.length > 0 &&
                                    this.state.occasionData.map((item, i) => {
                                      return (
                                        <li key={i} className="d-flex justify-content-between">
                                          <div>
                                            <span>{item.english}</span>
                                            <bdi className="mx-2">|</bdi>
                                            <span>{item.arabic}</span>
                                          </div>
                                          <div>
                                            <bdi onClick={() => this.editItem("occasion", item.id)} className="cursor-pointer" title="edit">
                                              <i class="bi bi-pencil-square"></i>
                                            </bdi>
                                            <mark onClick={() => this.delete_data(productLanguage.occasion, "occasion", item)} className="ms-3 bg-transparent bi bi-x p-0"></mark>
                                          </div>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-xl-4 col-md-6 mb-3">
                        <div className="white-box">
                          <div className="row">
                            <div className="col-12 mb-3 form-group">
                              <label>{productLanguage.fit}</label>
                              <div className="d-flex align-items-center">
                                <input type="text" className="form-control input-custom-class me-2" name="fitEnglish" value={this.state.fitEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterFitNameInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="fitArabic" value={this.state.fitArabic} onChange={this.handleChange} placeholder={productLanguage.EnterFitNameInArabic} />
                                <button onClick={() => this.state.isfitEdit ? this.editAddItem("fit") : this.addItem("fit")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.fitData &&
                                    this.state.fitData.length > 0 &&
                                    this.state.fitData.map((item, i) => {
                                      return (
                                        <li key={i} className="d-flex justify-content-between">
                                          <div>
                                            <span>{item.english}</span>
                                            <bdi className="mx-2">|</bdi>
                                            <span>{item.arabic}</span>
                                          </div>
                                          <div>
                                            <bdi onClick={() => this.editItem("fit", item.id)} className="cursor-pointer" title="edit">
                                              <i class="bi bi-pencil-square"></i>
                                            </bdi>
                                            <mark onClick={() => this.delete_data(productLanguage.fit, "fit", item)} className="ms-3 bg-transparent bi bi-x p-0"></mark>
                                          </div>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-xl-4 col-md-6 mb-3">
                        <div className="white-box">
                          <div className="row">
                            <div className="col-12 mb-3 form-group">
                              <label>{productLanguage.Length}</label>
                              <div className="d-flex align-items-center">
                                <input type="text" className="form-control input-custom-class me-2" name="lengthEnglish" value={this.state.lengthEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterLengthNameInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="lengthArabic" value={this.state.lengthArabic} onChange={this.handleChange} placeholder={productLanguage.EnterLengthNameInArabic} />
                                <button onClick={() => this.state.islengthEdit ? this.editAddItem("length") : this.addItem("length")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.lengthData &&
                                    this.state.lengthData.length > 0 &&
                                    this.state.lengthData.map((item, i) => {
                                      return (
                                        <li key={i} className="d-flex justify-content-between">
                                          <div>
                                            <span>{item.english}</span>
                                            <bdi className="mx-2">|</bdi>
                                            <span>{item.arabic}</span>
                                          </div>
                                          <div>
                                            <bdi onClick={() => this.editItem("length", item.id)} className="cursor-pointer" title="edit">
                                              <i class="bi bi-pencil-square"></i>
                                            </bdi>
                                            <mark onClick={() => this.delete_data(productLanguage.Length, "length", item)} className="ms-3 bg-transparent bi bi-x p-0"></mark>
                                          </div>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-xl-4 col-md-6 mb-3">
                        <div className="white-box">
                          <div className="row">
                            <div className="col-12 mb-3 form-group">
                              <label>{productLanguage.SleeveLength}</label>
                              <div className="d-flex align-items-center">
                                <input type="text" className="form-control input-custom-class me-2" name="sleevelengthEnglish" value={this.state.sleevelengthEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterSleeveLengthInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="sleevelengthArabic" value={this.state.sleevelengthArabic} onChange={this.handleChange} placeholder={productLanguage.EnterSleeveLengthInArabic} />
                                <button onClick={() => this.state.issleevelengthEdit ? this.editAddItem("sleevelength") : this.addItem("sleevelength")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.sleevelengthData &&
                                    this.state.sleevelengthData.length > 0 &&
                                    this.state.sleevelengthData.map((item, i) => {
                                      return (
                                        <li key={i} className="d-flex justify-content-between">
                                          <div>
                                            <span>{item.english}</span>
                                            <bdi className="mx-2">|</bdi>
                                            <span>{item.arabic}</span>
                                          </div>
                                          <div>
                                            <bdi onClick={() => this.editItem("sleevelength", item.id)} className="cursor-pointer" title="edit">
                                              <i class="bi bi-pencil-square"></i>
                                            </bdi>
                                            <mark onClick={() => this.delete_data(productLanguage.SleeveLength, "sleevelength", item)} className="ms-3 bg-transparent bi bi-x p-0"></mark>
                                          </div>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-xl-4 col-md-6 mb-3">
                        <div className="white-box">
                          <div className="row">
                            <div className="col-12 mb-3 form-group">
                              <label>{productLanguage.Neckline}</label>
                              <div className="d-flex align-items-center">
                                <input type="text" className="form-control input-custom-class me-2" name="necklineEnglish" value={this.state.necklineEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterNecklineNameInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="necklineArabic" value={this.state.necklineArabic} onChange={this.handleChange} placeholder={productLanguage.EnterNecklineNameInArabic} />
                                <button onClick={() => this.state.isnecklineEdit ? this.editAddItem("neckline") : this.addItem("neckline")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.necklineData &&
                                    this.state.necklineData.length > 0 &&
                                    this.state.necklineData.map((item, i) => {
                                      return (
                                        <li key={i} className="d-flex justify-content-between">
                                          <div>
                                            <span>{item.english}</span>
                                            <bdi className="mx-2">|</bdi>
                                            <span>{item.arabic}</span>
                                          </div>
                                          <div>
                                            <bdi onClick={() => this.editItem("neckline", item.id)} className="cursor-pointer" title="edit">
                                              <i class="bi bi-pencil-square"></i>
                                            </bdi>
                                            <mark onClick={() => this.delete_data(productLanguage.Neckline, "neckline", item)} className="ms-3 bg-transparent bi bi-x p-0"></mark>
                                          </div>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-xl-4 col-md-6 mb-3">
                        <div className="white-box">
                          <div className="row">
                            <div className="col-12 mb-3 form-group">
                              <label>{productLanguage.WaistType}</label>
                              <div className="d-flex align-items-center">
                                <input type="text" className="form-control input-custom-class me-2" name="waisttypeEnglish" value={this.state.waisttypeEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterWaistTypeInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="waisttypeArabic" value={this.state.waisttypeArabic} onChange={this.handleChange} placeholder={productLanguage.EnterWaistTypeInArabic} />
                                <button onClick={() => this.state.iswaisttypeEdit ? this.editAddItem("waisttype") : this.addItem("waisttype")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.waisttypeData &&
                                    this.state.waisttypeData.length > 0 &&
                                    this.state.waisttypeData.map((item, i) => {
                                      return (
                                        <li key={i} className="d-flex justify-content-between">
                                          <div>
                                            <span>{item.english}</span>
                                            <bdi className="mx-2">|</bdi>
                                            <span>{item.arabic}</span>
                                          </div>
                                          <div>
                                            <bdi onClick={() => this.editItem("waisttype", item.id)} className="cursor-pointer" title="edit">
                                              <i class="bi bi-pencil-square"></i>
                                            </bdi>
                                            <mark onClick={() => this.delete_data(productLanguage.WaistType, "waisttype", item)} className="ms-3 bg-transparent bi bi-x p-0"></mark>
                                          </div>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-xl-4 col-md-6 mb-3">
                        <div className="white-box">
                          <div className="row">
                            <div className="col-12 mb-3 form-group">
                              <label>{productLanguage.Character}</label>
                              <div className="d-flex align-items-center">
                                <input type="text" className="form-control input-custom-class me-2" name="CharacterEnglish" value={this.state.CharacterEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterCharacterNameInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="CharacterArabic" value={this.state.CharacterArabic} onChange={this.handleChange} placeholder={productLanguage.EnterCharacterNameInArabic} />
                                <button onClick={() => this.state.ischaracterEdit ? this.editAddItem("character") : this.addItem("character")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.characterData &&
                                    this.state.characterData.length > 0 &&
                                    this.state.characterData.map((item, i) => {
                                      return (
                                        <li key={i} className="d-flex justify-content-between">
                                          <div>
                                            <span>{item.english}</span>
                                            <bdi className="mx-2">|</bdi>
                                            <span>{item.arabic}</span>
                                          </div>
                                          <div>
                                            <bdi onClick={() => this.editItem("character", item.id)} className="cursor-pointer" title="edit">
                                              <i class="bi bi-pencil-square"></i>
                                            </bdi>
                                            <mark onClick={() => this.delete_data(productLanguage.Character, "character", item)} className="ms-3 bg-transparent bi bi-x p-0"></mark>
                                          </div>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-xl-4 col-md-6 mb-3">
                        <div className="white-box">
                          <div className="row">
                            <div className="col-12 mb-3 form-group">
                              <label>{productLanguage.Closure}</label>
                              <div className="d-flex align-items-center">
                                <input type="text" className="form-control input-custom-class me-2" name="closureEnglish" value={this.state.closureEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterClosureNameInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="closureArabic" value={this.state.closureArabic} onChange={this.handleChange} placeholder={productLanguage.EnterClosureNameInArabic} />
                                <button onClick={() => this.state.isclosureEdit ? this.editAddItem("closure") : this.addItem("closure")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.closureData &&
                                    this.state.closureData.length > 0 &&
                                    this.state.closureData.map((item, i) => {
                                      return (
                                        <li key={i} className="d-flex justify-content-between">
                                          <div>
                                            <span>{item.english}</span>
                                            <bdi className="mx-2">|</bdi>
                                            <span>{item.arabic}</span>
                                          </div>
                                          <div>
                                            <bdi onClick={() => this.editItem("closure", item.id)} className="cursor-pointer" title="edit">
                                              <i class="bi bi-pencil-square"></i>
                                            </bdi>
                                            <mark onClick={() => this.delete_data(productLanguage.Closure, "closure", item)} className="ms-3 bg-transparent bi bi-x p-0"></mark>
                                          </div>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-xl-4 col-md-6 mb-3">
                        <div className="white-box">
                          <div className="row">
                            <div className="col-12  mb-3 form-group">
                              <label>{productLanguage.material}</label>
                              <div className="d-flex align-items-center">
                                <input type="text" className="form-control input-custom-class me-2" name="materialEnglish" value={this.state.materialEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterMaterialNameInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="materialArabic" value={this.state.materialArabic} onChange={this.handleChange} placeholder={productLanguage.EnterMaterialNameInArabic} />
                                <button onClick={() => this.state.ismaterialEdit ? this.editAddItem("material") : this.addItem("material")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.materialData &&
                                    this.state.materialData.length > 0 &&
                                    this.state.materialData.map((item, i) => {
                                      return (
                                        <li key={i} className="d-flex justify-content-between">
                                          <div>
                                            <span>{item.english}</span>
                                            <bdi className="mx-2">|</bdi>
                                            <span>{item.arabic}</span>
                                          </div>
                                          <div>
                                            <bdi onClick={() => this.editItem("material", item.id)} className="cursor-pointer" title="edit">
                                              <i class="bi bi-pencil-square"></i>
                                            </bdi>
                                            <mark onClick={() => this.delete_data(productLanguage.material, "material", item)} className="ms-3 bg-transparent bi bi-x p-0"></mark>
                                          </div>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-xl-4 col-md-6 mb-3">
                        <div className="white-box">
                          <div className="row">
                            <div className="col-12  mb-3 form-group">
                              <label>{productLanguage.Pieces}</label>
                              <div className="d-flex align-items-center">
                                <input type="text" className="form-control input-custom-class me-2" name="piecesEnglish" value={this.state.piecesEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterPiecesNameInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="piecesArabic" value={this.state.piecesArabic} onChange={this.handleChange} placeholder={productLanguage.EnterPiecesNameInArabic} />
                                <button onClick={() => this.state.ispiecesEdit ? this.editAddItem("pieces") : this.addItem("pieces")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.piecesData &&
                                    this.state.piecesData.length > 0 &&
                                    this.state.piecesData.map((item, i) => {
                                      return (
                                        <li key={i} className="d-flex justify-content-between">
                                          <div>
                                            <span>{item.english}</span>
                                            <bdi className="mx-2">|</bdi>
                                            <span>{item.arabic}</span>
                                          </div>
                                          <div>
                                            <bdi onClick={() => this.editItem("pieces", item.id)} className="cursor-pointer" title="edit">
                                              <i class="bi bi-pencil-square"></i>
                                            </bdi>
                                            <mark onClick={() => this.delete_data(productLanguage.Pieces, "pieces", item)} className="ms-3 bg-transparent bi bi-x p-0"></mark>
                                          </div>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Tab>
                  <Tab eventKey="other_attributes" title={titleLanguage.OtherAttributes}>
                    <div className="row common-space">
                      <div className="col-lg-6 mb-3">
                        <div className="white-box">
                          <div className="row">
                            <div className="col-12  mb-3 form-group">
                              <label>{productLanguage.color}</label>
                              <div className="d-flex align-items-center">
                                <input type="text" className="form-control input-custom-class me-2" name="colorEnglish" value={this.state.colorEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterColorInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="colorArabic" value={this.state.colorArabic} onChange={this.handleChange} placeholder={productLanguage.EnterColorInArabic} />
                                <input type="text" readOnly className="form-control input-custom-class me-2 " value={this.state.colorValue} />
                                <input type="color" className="form-control input-custom-class me-2 color-picker-att p-0" name="colorValue" value={this.state.colorValue} onChangeCapture={this.handleChange} />
                                <button onClick={() => this.state.iscolorEdit ? this.editAddItem("color") : this.addItem("color")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  <li className="d-flex">
                                    <div className="me-2 color-show-div multi-color" ></div>
                                    <div>
                                      <span>Multicolor</span>
                                      <bdi className="mx-2">|</bdi>
                                      <span>متعدد اللألوان</span>
                                    </div>
                                  </li>
                                  {this.state.colorData &&
                                    this.state.colorData.length > 0 &&
                                    this.state.colorData.map((item, i) => {
                                      return (
                                        <li key={i} className="d-flex">
                                          <div className="me-2 color-show-div" style={{ 'backgroundColor': item.hex }}></div>
                                          <div >
                                            <span>{item.english}</span>
                                            <bdi className="mx-2">|</bdi>
                                            <span>{item.arabic}</span>
                                          </div>
                                          <div className="ms-auto">
                                            <bdi onClick={() => this.editItem("color", item.id)} className="cursor-pointer" title="edit">
                                              <i class="bi bi-pencil-square"></i>
                                            </bdi>
                                            <mark onClick={() => this.delete_data(productLanguage.color, "color", item)} className="ms-3 bg-transparent bi bi-x p-0"></mark>
                                          </div>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className=" col-lg-6 mb-3">
                        <div className="white-box">
                          <div className="row">
                            <div className="col-12  mb-3 form-group">
                              <label>{productLanguage.careInstructions}</label>
                              <div className="d-flex align-items-center">
                                <input type="text" className="form-control input-custom-class me-2" name="careInstructionEnglish" value={this.state.careInstructionEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterCareInstructionsInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="careInstructionArabic" value={this.state.careInstructionArabic} onChange={this.handleChange} placeholder={productLanguage.EnterCareInstructionsInArabic} />
                                <label htmlFor="care-icon" className="icon-image-set me-2">
                                  <input type="file" id="care-icon" className="form-control input-custom-class " accept="image/*" onChange={this.handleIconChange} />add icon
                                </label>
                                {this.state.isIcon &&
                                  <div className="me-2 d-flex align-items-center h-100">
                                    <img className="care-show-div mb-2" src={this.state.careIcon && this.state.careIcon} alt="" />
                                    {/* <div className="care-show-div mb-2" style={{ 'backgroundImage': `url(${this.state.careIcon && this.state.careIcon})` }}></div> */}
                                  </div>
                                }
                                <button onClick={() => this.state.iscareInstructionsEdit ? this.editAddItem("careInstruction") : this.addItem("careInstruction")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.careInstructionData &&
                                    this.state.careInstructionData.length > 0 &&
                                    this.state.careInstructionData.map((item, i) => {
                                      return (
                                        <li key={i} className="d-flex">
                                          <img alt="" src={item.image} className="color-show-div me-2" />
                                          <div>
                                            <span>{item.english}</span>
                                            <bdi className="mx-2">|</bdi>
                                            <span>{item.arabic}</span>
                                          </div>
                                          <div className="ms-auto">
                                            <bdi onClick={() => this.editItem("careInstruction", item.id)} className="cursor-pointer" title="edit">
                                              <i class="bi bi-pencil-square"></i>
                                            </bdi>
                                            <mark onClick={() => this.delete_data(productLanguage.careInstructions, "careInstruction", item)} className="ms-3 bg-transparent bi bi-x p-0"></mark>
                                          </div>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-lg-6 mb-3">
                        <div className="white-box">
                          <div className="row">
                            <div className="col-12  mb-3 form-group">
                              <label>{productLanguage.howtomeasure}</label>
                              <div className="d-flex">
                                <div className="w-100 d-flex flex-column">
                                  <div className="d-flex align-items-center">
                                    <input type="text" className="form-control input-custom-class me-2" name="howtomeasureEnglish" value={this.state.howtomeasureEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterhowtomeasureInEnglish} />
                                    <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="howtomeasureArabic" value={this.state.howtomeasureArabic} onChange={this.handleChange} placeholder={productLanguage.EnterhowtomeasureInArabic} />
                                  </div>
                                  <div className="d-flex align-items-center">
                                    <textarea type="text" className="form-control input-custom-class me-2 h-auto" rows={3} name="howtomeasuredescEnglish" value={this.state.howtomeasuredescEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterhowtomeasuredescInEnglish} />
                                    <textarea type="text" dir="rtl" rows={3} className="form-control input-custom-class me-2 h-auto" name="howtomeasuredescArabic" value={this.state.howtomeasuredescArabic} onChange={this.handleChange} placeholder={productLanguage.EnterhowtomeasuredescInArabic} />
                                  </div>
                                </div>
                                <div>
                                  <button onClick={() => this.state.ishowtomeasureEdit ? this.editAddItem("howtomeasure") : this.addItem("howtomeasure")} className="btn light-red-btn">
                                    <img src={plusicon} />
                                  </button>
                                </div>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.howtomeasureData &&
                                    this.state.howtomeasureData.length > 0 &&
                                    this.state.howtomeasureData.map((item, i) => {
                                      return (
                                        <li key={i} className="d-flex align-items-center">
                                          <div >
                                            <p className="mb-0">
                                              <span className="fw-bold">{item.title_en}-</span>{item.description_en}
                                            </p>
                                          </div>
                                          <div dir="rtl" className="ms-auto">
                                            <p className="mb-0">
                                              <span className="fw-bold">{item.title_ar}-</span>{item.description_ar}
                                            </p>
                                          </div>
                                          <div className="ms-3 d-flex">
                                            <bdi onClick={() => this.editItem("howtomeasure", item.id)} className="cursor-pointer" title="edit">
                                              <i class="bi bi-pencil-square"></i>
                                            </bdi>
                                            <mark onClick={() => this.delete_data(productLanguage.howtomeasure, "howtomeasure", item)} className="ms-3 bg-transparent bi bi-x p-0"></mark>
                                          </div>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Tab>
                  <Tab eventKey="misc" title={titleLanguage.misc}>
                    <div className="row common-space">
                      <div className="col-xl-4 col-md-6 mb-3">
                        <div className="white-box">
                          <div className="row">
                            <div className="col-12 mb-3 form-group">
                              <label>{productLanguage.internationalsizes}</label>
                              <div className="d-flex align-items-center">
                                <input type="text" className="form-control input-custom-class me-2" name="internationalsizesEnglish" value={this.state.internationalsizesEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterInternationalSizesInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="internationalsizesArabic" value={this.state.internationalsizesArabic} onChange={this.handleChange} placeholder={productLanguage.EnterInternationalSizesInArabic} />
                                <button onClick={() => this.state.isinternationalsizesEdit ? this.editAddItem("internationalsizes") : this.addItem("internationalsizes")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.internationalsizesData &&
                                    this.state.internationalsizesData.length > 0 &&
                                    this.state.internationalsizesData.map((item, i) => {
                                      return (
                                        <li key={i} className="d-flex justify-content-between">
                                          <div>
                                            <span>{item.english}</span>
                                            <bdi className="mx-2">|</bdi>
                                            <span>{item.arabic}</span>
                                          </div>
                                          <div>
                                            <bdi onClick={() => this.editItem("internationalsizes", item.id)} className="cursor-pointer" title="edit">
                                              <i class="bi bi-pencil-square"></i>
                                            </bdi>
                                            <mark onClick={() => this.delete_data(productLanguage.internationalsizes, "internationalsizes", item)} className="ms-3 bg-transparent bi bi-x p-0"></mark>
                                          </div>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-xl-4 col-md-6 mb-3">
                        <div className="white-box">
                          <div className="row">
                            <div className="col-12 mb-3 form-group">
                              <label>{productLanguage.numericalsizes}</label>
                              <div className="d-flex align-items-center">
                                <input type="text" className="form-control input-custom-class me-2" name="numericalsizesEnglish" value={this.state.numericalsizesEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterNumericalSizesInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="numericalsizesArabic" value={this.state.numericalsizesArabic} onChange={this.handleChange} placeholder={productLanguage.EnterNumericalSizesInArabic} />
                                <button onClick={() => this.state.isnumericalsizesEdit ? this.editAddItem("numericalsizes") : this.addItem("numericalsizes")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.numericalsizesData &&
                                    this.state.numericalsizesData.length > 0 &&
                                    this.state.numericalsizesData.map((item, i) => {
                                      return (
                                        <li key={i} className="d-flex justify-content-between">
                                          <div>
                                            <span>{item.english}</span>
                                            <bdi className="mx-2">|</bdi>
                                            <span>{item.arabic}</span>
                                          </div>
                                          <div>
                                            <bdi onClick={() => this.editItem("numericalsizes", item.id)} className="cursor-pointer" title="edit">
                                              <i class="bi bi-pencil-square"></i>
                                            </bdi>
                                            <mark onClick={() => this.delete_data(productLanguage.numericalsizes, "numericalsizes", item)} className="ms-3 bg-transparent bi bi-x p-0"></mark>
                                          </div>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-xl-4 col-md-6 mb-3">
                        <div className="white-box">
                          <div className="row">
                            <div className="col-12 mb-3 form-group">
                              <label>{productLanguage.agesizes}</label>
                              <div className="d-flex align-items-center">
                                <input type="text" className="form-control input-custom-class me-2" name="agesizesEnglish" value={this.state.agesizesEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterAgeSizesInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="agesizesArabic" value={this.state.agesizesArabic} onChange={this.handleChange} placeholder={productLanguage.EnterAgeSizesInArabic} />
                                <button onClick={() => this.state.isagesizesEdit ? this.editAddItem("agesizes") : this.addItem("agesizes")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.agesizesData &&
                                    this.state.agesizesData.length > 0 &&
                                    this.state.agesizesData.map((item, i) => {
                                      return (
                                        <li key={i} className="d-flex justify-content-between">
                                          <div>
                                            <span>{item.english}</span>
                                            <bdi className="mx-2">|</bdi>
                                            <span>{item.arabic}</span>
                                          </div>
                                          <div>
                                            <bdi onClick={() => this.editItem("agesizes", item.id)} className="cursor-pointer" title="edit">
                                              <i class="bi bi-pencil-square"></i>
                                            </bdi>
                                            <mark onClick={() => this.delete_data(productLanguage.agesizes, "agesizes", item)} className="ms-3 bg-transparent bi bi-x p-0"></mark>
                                          </div>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-xl-4 col-md-6 mb-3">
                        <div className="white-box">
                          <div className="row">
                            <div className="col-12 mb-3 form-group">
                              <label>{productLanguage.brasizes}</label>
                              <div className="d-flex align-items-center">
                                <input type="text" className="form-control input-custom-class me-2" name="brasizesEnglish" value={this.state.brasizesEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterBraSizesInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="brasizesArabic" value={this.state.brasizesArabic} onChange={this.handleChange} placeholder={productLanguage.EnterBraSizesInArabic} />
                                <button onClick={() => this.state.isbrasizesEdit ? this.editAddItem("brasizes") : this.addItem("brasizes")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.brasizesData &&
                                    this.state.brasizesData.length > 0 &&
                                    this.state.brasizesData.map((item, i) => {
                                      return (
                                        <li key={i} className="d-flex justify-content-between">
                                          <div>
                                            <span>{item.english}</span>
                                            <bdi className="mx-2">|</bdi>
                                            <span>{item.arabic}</span>
                                          </div>
                                          <div>
                                            <bdi onClick={() => this.editItem("brasizes", item.id)} className="cursor-pointer" title="edit">
                                              <i class="bi bi-pencil-square"></i>
                                            </bdi>
                                            <mark onClick={() => this.delete_data(productLanguage.brasizes, "brasizes", item)} className="ms-3 bg-transparent bi bi-x p-0"></mark>
                                          </div>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-xl-4 col-md-6 mb-3">
                        <div className="white-box">
                          <div className="row">
                            <div className="col-12 mb-3 form-group">
                              <label>{productLanguage.misc}</label>
                              <div className="d-flex align-items-center">
                                <input type="text" className="form-control input-custom-class me-2" name="miscEnglish" value={this.state.miscEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterMiscInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="miscArabic" value={this.state.miscArabic} onChange={this.handleChange} placeholder={productLanguage.EnterMiscInArabic} />
                                <button onClick={() => this.state.ismiscEdit ? this.editAddItem("misc") : this.addItem("misc")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.miscData &&
                                    this.state.miscData.length > 0 &&
                                    this.state.miscData.map((item, i) => {
                                      return (
                                        <li key={i} className="d-flex justify-content-between">
                                          <div>
                                            <span>{item.english}</span>
                                            <bdi className="mx-2">|</bdi>
                                            <span>{item.arabic}</span>
                                          </div>
                                          <div>
                                            <bdi onClick={() => this.editItem("misc", item.id)} className="cursor-pointer" title="edit">
                                              <i class="bi bi-pencil-square"></i>
                                            </bdi>
                                            <mark onClick={() => this.delete_data(productLanguage.misc, "misc", item)} className="ms-3 bg-transparent bi bi-x p-0"></mark>
                                          </div>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-xl-4 col-md-6 mb-3">
                        <div className="white-box">
                          <div className="row">
                            <div className="col-12 mb-3 form-group">
                              <label>{productLanguage.shippingCompany}</label>
                              <div className="d-flex align-items-center">
                                <input type="text" className="form-control input-custom-class me-2" name="shippingCompanyEnglish" value={this.state.shippingCompanyEnglish} onChange={this.handleChange} placeholder={productLanguage.EnterCityInEnglish} />
                                <input type="text" dir="rtl" className="form-control input-custom-class me-2" name="shippingCompanyArabic" value={this.state.shippingCompanyArabic} onChange={this.handleChange} placeholder={productLanguage.EnterCityInArabic} />
                                <button onClick={() => this.state.isshippingCompanyEdit ? this.editAddItem("shippingCompany") : this.addItem("shippingCompany")} className="btn light-red-btn">
                                  <img src={plusicon} />
                                </button>
                              </div>
                              <div className="cust-select-cate-drop">
                                <ul>
                                  {this.state.shippingCompanyData &&
                                    this.state.shippingCompanyData.length > 0 &&
                                    this.state.shippingCompanyData.map((item, i) => {
                                      return (
                                        <li key={i} className="d-flex justify-content-between">
                                          <div>
                                            <span>{item.english}</span>
                                            <bdi className="mx-2">|</bdi>
                                            <span>{item.arabic}</span>
                                          </div>
                                          <div>
                                            <bdi onClick={() => this.editItem("shippingCompany", item.id)} className="cursor-pointer" title="edit">
                                              <i class="bi bi-pencil-square"></i>
                                            </bdi>
                                            <mark onClick={() => this.delete_data("shippingCompany", "shippingCompany", item)} className="ms-3 bg-transparent bi bi-x p-0"></mark>
                                          </div>
                                        </li>
                                      );
                                    })}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Tab>
                </Tabs>
              </div>
            </div>
          </div>
        </div>
      </Adminlayout>
    );
  }
}

export default Productcategory;
