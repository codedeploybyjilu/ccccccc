import React, { Component } from 'react'
import {
    // APIBaseUrl,
    // API_Path,
    // buttonArabic,
    // buttonEnglish,
    // LIVE_FILE_URL,
    productArabic,
    // sizeGuidelinesArabic,
    // sizeGuidelinesEnglish,
    // TableFieldArabic,
    // TableFieldEnglish,
    // titleArabic,
    // titleEnglish,
    productEnglish
} from "../../const";
import LanguageContext from "../../contexts/languageContext";

export default class SizeGuideRow extends Component {
    static contextType = LanguageContext;
    componentDidMount() {
        this.props.setVal({ variation_id: this.props.index }, this.props.index)

    }
    render() {
        let productLanguage = this.context.language === "english" ? productEnglish : productArabic;
        if (this.props?.formVals) {
            const { formVals, index, setVal, removeElement, addElement, columns } = this.props;
            // console.log('columns is :: ', columns);
            const inputAttr = (field) => ({
                value: formVals[field],
                onChange: (e) => {
                    console.log('field Is :: ', field);
                    if (field === 'events') {
                        this.handleEventChange(e);
                    }
                    setVal({ [field]: e.target.value }, index);
                }

            })
            return (


                <tr className=''>
                    {columns.includes('size') && <td className="">
                        <div className='d-flex align-items-center'>
                            <input type='text' name="size" {...inputAttr('size')} placeholder={productLanguage.Entersize} className="form-control frnt-input-style" />
                        </div>
                    </td>}
                    {columns.includes('sizeArabic') && <td className="">
                        <div className='d-flex align-items-center'>
                            <input type='text' name="sizeArabic" {...inputAttr('sizeArabic')} placeholder={productLanguage.Entersizeinarabic} className="form-control frnt-input-style" />
                        </div>
                    </td>}
                    {columns.includes('topLength') && <td className="">
                        <div className='d-flex align-items-center'>
                            <input type='number' name="topLength" {...inputAttr('topLength')} placeholder='0' className="form-control frnt-input-style" />
                        </div>
                    </td>}
                    {columns.includes('shoulder') && <td className="">
                        <div className='d-flex align-items-center'>
                            <input type='number' name="shoulder" {...inputAttr('shoulder')} placeholder='0' className="form-control frnt-input-style" />
                        </div>
                    </td>}
                    {columns.includes('length') && <td className="">
                        <div className='d-flex align-items-center'>
                            <input type='number' name="length" {...inputAttr('length')} placeholder='0' className="form-control frnt-input-style" />
                        </div>
                    </td>}
                    {columns.includes('bust') && <td className="">
                        <div className='d-flex align-items-center'>
                            <input type='number' name="bust" {...inputAttr('bust')} placeholder='0' className="form-control frnt-input-style" />
                        </div>
                    </td>}
                    {columns.includes('chest') && <td className="">
                        <div className='d-flex align-items-center'>
                            <input type='number' name="chest" {...inputAttr('chest')} placeholder='0' className="form-control frnt-input-style" />
                        </div>
                    </td>}
                    {columns.includes('waist') && <td className="">
                        <div className='d-flex align-items-center'>
                            <input type='number' name="waist" {...inputAttr('waist')} placeholder='0' className="form-control frnt-input-style" />
                        </div>
                    </td>}
                    {columns.includes('hips') && <td className="">
                        <div className='d-flex align-items-center'>
                            <input type='number' name="hips" {...inputAttr('hips')} placeholder='0' className="form-control frnt-input-style" />
                        </div>
                    </td>}
                    {columns.includes('rise') && <td className="">
                        <div className='d-flex align-items-center'>
                            <input type='number' name="rise" {...inputAttr('rise')} placeholder='0' className="form-control frnt-input-style" />
                        </div>
                    </td>}
                    {columns.includes('inseamLength') && <td className="">
                        <div className='d-flex align-items-center'>
                            <input type='number' name="inseamLength" {...inputAttr('inseamLength')} placeholder='0' className="form-control frnt-input-style" />
                        </div>
                    </td>}
                    {columns.includes('outseamLength') && <td className="">
                        <div className='d-flex align-items-center'>
                            <input type='number' name="outseamLength" {...inputAttr('outseamLength')} placeholder='0' className="form-control frnt-input-style" />
                        </div>
                    </td>}
                    {columns.includes('sleeveLength') && <td className="">
                        <div className='d-flex align-items-center'>
                            <input type='number' name="sleeveLength" {...inputAttr('sleeveLength')} placeholder='0' className="form-control frnt-input-style" />
                        </div>
                    </td>}
                    {columns.includes('armWidth') && <td className="">
                        <div className='d-flex align-items-center'>
                            <input type='number' name="armWidth" {...inputAttr('armWidth')} placeholder='0' className="form-control frnt-input-style" />
                        </div>
                    </td>}
                    {columns.includes('skirtLength') && <td className="">
                        <div className='d-flex align-items-center'>
                            <input type='number' name="skirtLength" {...inputAttr('skirtLength')} placeholder='0' className="form-control frnt-input-style" />
                        </div>
                    </td>}
                    {columns.includes('overBust') && <td className="">
                        <div className='d-flex align-items-center'>
                            <input type='number' name="overBust" {...inputAttr('overBust')} placeholder='0' className="form-control frnt-input-style" />
                        </div>
                    </td>}
                    {columns.includes('underBust') && <td className="">
                        <div className='d-flex align-items-center'>
                            <input type='number' name="underBust" {...inputAttr('underBust')} placeholder='0' className="form-control frnt-input-style" />
                        </div>
                    </td>}
                    {columns.includes('bottomLength') && <td className="">
                        <div className='d-flex align-items-center'>
                            <input type='number' name="bottomLength" {...inputAttr('bottomLength')} placeholder='0' className="form-control frnt-input-style" />
                        </div>
                    </td>}


                    <div className="col-md-1 col-12 mt-2 d-flex">
                        {(index === 0) ? null : (
                            <button id='removeButton'
                                className={"white-btn btn-danger me-1 "}
                                onClick={() => removeElement(index)}
                            >-</button>
                        )}
                        <button id={'plus-' + index} className='white-btn w-auto' onClick={() => addElement(index)} > +</button>
                    </div>
                </tr>
            )
        } else {
            return null;
        }
    }
}
