import React, { Component, createRef } from "react";
// import { Formik } from "formik";
// import * as Yup from "yup";
// import DragDrop from "../../helper/DragDrop";
import dragimg from "../../images/file-upload.svg";
// import imgprev from "../../images/img-prev.png";
// import productimg from "../../images/product-img.png";
import videoicn from "../../images//video-icn.svg";
import { Dropdown, Modal } from "react-bootstrap";
import toastr from "toastr";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import { PostApi } from "../../helper/APIService";
import loader from "../../images/loader.gif";
import { API_Path, buttonArabic, buttonEnglish, productArabic, productEnglish } from "../../const";
import LanguageContext from "../../contexts/languageContext";
import { confirmAlert } from "react-confirm-alert";
import { Prompt } from "react-router-dom";
import { ImageCompress } from "../../Components/ImageCompress";
import { object } from "yup";
// import { arrayMove, SortableContainer, SortableElement } from 'react-sortable-hoc'

let ImageFileArray = [];
let variationArray = [];
let variationSizeArray = [];
// let newVariationSizeArray = [];
let editImageArray = [];
let editVariationSizeArray = [];
let objIndex;
let EVobjIndex;

const reorder = (list, startIndex, endIndex) => {
	console.log(list, "list");
	const result = Array.from(list);
	const [removed] = result.splice(startIndex, 1);
	result.splice(endIndex, 0, removed);

	return result;
};
// const reorderRtL = (list, startIndex, endIndex) => {
//   console.log(list, "listRtl", startIndex, "[]", endIndex);
//   const result = list;
//   console.log(result, "result");
//   const [removed] = result.splice(startIndex, 1);
//   result.splice(endIndex, 0, removed);

//   return result;
// };

const grid = 8;

const getItemStyle = (isDragging, draggableStyle) => ({
	// some basic styles to make the items look a bit nicer
	userSelect: "none",
	padding: grid,

	// change background colour if dragging
	background: isDragging ? "#A81A1C" : "#F7F7F7",

	// styles we need to apply on draggables
	...draggableStyle,
});

const getListStyle = (isDraggingOver, itemsLength) => ({
	background: isDraggingOver ? "#f7f7f7" : "#fff",
	display: "flex",
	flexWrap: "wrap",
	padding: grid,
	width: itemsLength * 150 + 10,
});
// const SortableItem = SortableElement(({ value, removeImg }) => (
//   <li className="d-inline-block me-2 mb-2 cursor-grab">
//     <div className="img-preview-main position-relative">
//       <img src={URL.createObjectURL(value.src)} alt="" />
//       <div className="remove-img-btn">
//         <i
//           onClick={() => {
//             removeImg(value.id);
//           }}
//           className="bi bi-x-circle-fill"
//         />
//       </div>
//     </div>
//   </li>
// ));

// const SortableList = SortableContainer(({ items, removeImg }) => {
//   return (
//     <ul>
//       {items.map((value, index) => (
//         <SortableItem key={`item-${value}`} index={index} value={value} removeImg={removeImg} />
//       ))}
//     </ul>
//   );
// });

export default class Variations extends Component {
	static contextType = LanguageContext;
	constructor(params) {
		super(params);
		this.state = {
			skuCode: "A",
			color: [],
			promotion: [],
			selectSize: 0,
			selectPromotion: "",
			selectcolor: "",
			promotionEnglish: "",
			variationName_en: "",
			variationName_ar: "",
			promotionArabic: "",
			price: "",
			discount: "",
			discountPrice: "",
			realprice: "",

			items: "",
			videoFiles: "",
			variationList: "",
			agesizesData: "",
			brasizesData: "",
			miscData: "",
			internationalsizesData: "",
			numericalsizesData: "",
			isVariationShow: false,
			addproduct_show: false,
			editVariantShow: false,
			size_en: "",
			size_ar: "",
			search_val_en: "",
			search_val_ar: "",
			sizeQuantity: "",
			editSize_en: "",
			editSize_ar: "",
			editSizeQuantity: "",
			variationSizeList: [],
			isImageUploaded: false,
			uploadedImages: "",
			isVideoUploaded: true,
			uploadedVideo: "",
			isLoading: false,
			editVariationDetails: "",
			editVariationImages: "",
			editVariationVideo: "",
			editVariationNameEn: "",
			editVariationNameAr: "",
			editVariationColor: "",
			editVariationPrice: "",
			editVariationDiscount: "",
			editVariationPromotion: "",
			editVariationRealPrice: "",
			editImageToUpload: "",
			editVariationSizeList: "",
			editVariationAddSize_en: "",
			editVariationAddSize_ar: "",
			editVariationAddSizeQuantity: "",
			editVariationEditSize_en: "",
			editVariationEditSize_ar: "",
			editVariationEditSizeQuantity: "",
			editVariatioinId: "",
			serverImg: '',

			shouldBlockNavigation: false,
			SizeGroupSizes: '',
			selectedVariantSize: '',
			tempfiles: [],
			isImageUpdate: false
		};
		this.messagesEndRef = createRef();
		this.onDragEnd = this.onDragEnd.bind(this);
	}

	componentDidMount = () => {
		this.getColorData();
		this.getPromotionData();
		// this.addImageToStorage()
	};

	componentDidUpdate(prevprops) {
		if (prevprops != this.props) {
			// console.log(this.state.tempfiles)
		}
	}

	getmiscData = () => {

		let data = {};

		let path = API_Path.getMisc;
		const getMiscPromise = new Promise((resolve, reject) => {
			resolve(PostApi(path, data));
		});

		getMiscPromise.then((res) => {
			if (res) {
				// console.log('res is :: ', res.data.data);
				this.setState({ miscData: res.data.data, SizeGroupSizes: res.data.data });
			}
		});
	};

	getbrasizesData = () => {

		let data = {};

		let path = API_Path.getBrasizes;
		const getBraSizesPromise = new Promise((resolve, reject) => {
			resolve(PostApi(path, data));
		});

		getBraSizesPromise.then((res) => {
			if (res) {
				// console.log('res is :: ', res.data.data);
				this.setState({ brasizesData: res.data.data, SizeGroupSizes: res.data.data });
			}
		});
	};

	getagesizesData = () => {

		let data = {};

		let path = API_Path.getAgesizes;
		const getAgesizesPromise = new Promise((resolve, reject) => {
			resolve(PostApi(path, data));
		});

		getAgesizesPromise.then((res) => {
			if (res) {
				// console.log('res is :: ', res.data.data);
				this.setState({ agesizesData: res.data.data, SizeGroupSizes: res.data.data });
			}
		});
	};

	getnumericalsizesData = () => {

		let data = {};

		let path = API_Path.getNumericalsizes;
		const getnumericalsizesDataPromise = new Promise((resolve, reject) => {
			resolve(PostApi(path, data));
		});

		getnumericalsizesDataPromise.then((res) => {
			if (res) {
				this.setState({ numericalsizesData: res.data.data, SizeGroupSizes: res.data.data });
			}
		});
	};

	getinternationalsizesData = () => {

		let data = {};

		let path = API_Path.getInternationalsizes;
		const getinternationalsizesDataPromise = new Promise((resolve, reject) => {
			resolve(PostApi(path, data));
		});

		getinternationalsizesDataPromise.then((res) => {
			if (res) {
				this.setState({ internationalsizesData: res.data.data, SizeGroupSizes: res.data.data });
			}
		});
	};

	onDragEndTable = (result) => {
		console.log(result);
		if (!result.destination) {
			return;
		} else if (result.destination.index === result.source.index) {
			return;
		} else {
			console.log(this.state.variationSizeList);
			const sorted = reorder(this.state.variationSizeList, result.source.index, result.destination.index);
			// this.state.variationSizeList = sorted;
			variationSizeArray = sorted;
			this.setState({ variationSizeList: sorted });
		}
	};

	onDragEndVariant = (result) => {
		// console.log(result)
		if (!result.destination) {
			return;
		}
		if (result.destination.index === result.source.index) {
			return;
		}
		const variant = reorder(this.state.variationList, result.source.index, result.destination.index);
		this.setState({ variationList: variant });
	};

	onDragEndEditTable = (result) => {
		if (!result.destination) {
			return;
		} else if (result.destination.index === result.source.index) {
			return;
		} else {
			// console.log(this.state.variationSizeList)
			const sorted = reorder(this.state.editVariationSizeList, result.source.index, result.destination.index);
			// this.state.editVariationSizeList = sorted;
			variationSizeArray = sorted;
			this.setState({ editVariationSizeList: sorted });
		}
	};
	dataURLtoFile = (dataURL, filename) => {
		const arr = dataURL.split(',');
		const mime = arr[0].match(/:(.*?);/)[1];
		const bstr = atob(arr[1]);
		let n = bstr.length;
		const u8arr = new Uint8Array(n);
		while (n--) {
			u8arr[n] = bstr.charCodeAt(n);
		}
		return new File([u8arr], filename, { type: mime });
	}
	handleImageFile = (e) => {
		this.setState({ shouldBlockNavigation: true })
		e.preventDefault();
		let array = Object.values(e.target.files);
		this.setState({ serverImg: array })
		for (let i = 0; i < array.length; i++) {
			let imageObject = {
				src: array[i],
				id: this.makeid(8),
			};

			ImageFileArray.push(imageObject);
		}
		console.log(ImageFileArray, "ImageFileArray");
		this.setState({ items: ImageFileArray }, () => {
			document.getElementById("SelectProductImage").value = "";
			if (this.state.items.length > 0) {
				document.getElementById("imageArrayError").style.display = "none";
			}
		});
	};

	handleEditImages = (e) => {
		let array = Object.values(e.target.files);
		for (let i = 0; i < array.length; i++) {
			let imageObject = {
				image: array[i],
				id: this.makeid(8),
			};

			editImageArray.push(imageObject);
			// console.log(URL.createObjectURL(array[i]), "[[[[]]]]")
		}
		this.setState({ editVariationImages: editImageArray, isImageUpdate: true });
		// this.setState({ editImageToUpload: array }, () => {
		// 	// console.log('edit image to upload :: ', this.state.editImageToUpload);

		// 	var formData = new FormData();
		// 	for (var i = 0; i < this.state.editImageToUpload.length; i++) {
		// 		formData.append("file", this.state.editImageToUpload[i]);
		// 	}

		// 	let path = API_Path.addFileInS3;
		// 	const addFileInS3Promise = new Promise((resolve, reject) => {
		// 		resolve(PostApi(path, formData));
		// 	});

		// 	addFileInS3Promise.then((res) => {
		// 		if (res) {
		// 			// console.log('res is :: ', res);
		// 			for (let i = 0; i < res.data.data.length; i++) {
		// 				let obj = {
		// 					image: res.data.data[i],
		// 					id: this.makeid(8),
		// 				};
		// 				editImageArray.push(obj);
		// 			}
		// 			this.setState({ editVariationImages: editImageArray });
		// 		}
		// 	});
		// });
	};

	onDragEnd(result) {
		// dropped outside the list
		if (!result.destination) {
			return;
		}
		const revers = []
		this.state.items.forEach(element => {
			revers.unshift(element)
		});
		// console.log(revers, "revers");
		// console.log(this.state.items, "////");
		// console.log('source :: ', result.source);
		// console.log('destination :: ', result.destination);
		const items = reorder(this.state.items, result.source.index, result.destination.index);

		this.setState({
			items,
		});
	}

	onEditDragEnd = (result) => {
		// dropped outside the list
		if (!result.destination) {
			return;
		}
		// console.log('edit :: ', this.state.editVariationImages);
		const editVariationImages = reorder(this.state.editVariationImages, result.source.index, result.destination.index);

		this.setState({
			editVariationImages,
		});
	};

	removeImage = (id) => {
		document.getElementById("SelectProductImage").value = "";
		const filteredimage = this.state.items.filter((item) => item.id !== id);
		ImageFileArray = filteredimage;
		// console.log('filter :: ', filteredimage);
		this.setState({ items: filteredimage ? filteredimage : [] }, () => {
			if (this.state.items.length === 0) {
				document.getElementById("imageArrayError").style.display = "block";
			}
		});
	};

	editVariationremoveImage = (id) => {
		document.getElementById("SelectProductImage").value = "";
		const filteredimage = this.state.editVariationImages.filter((item) => item.id !== id);
		editImageArray = filteredimage;
		// console.log('filter :: ', filteredimage);
		this.setState({ editVariationImages: filteredimage }, () => {
			if (this.state.editVariationImages.length === 0) {
				document.getElementById("imageArrayError").style.display = "block";
			}
		});
	};

	handleEditRow = (item) => {
		this.setState({
			editVariantShow: true,
			editSizeQuantity: item.quantity,
			editSize_en: item.size_en,
			editSize_ar: item.size_ar,
		});

		objIndex = this.state.variationSizeList.findIndex((obj) => obj.id === item.id);
	};

	editVariationEditRow = (item) => {
		this.setState({
			editVariationSizeVariantShow: true,
			editVariationEditSizeQuantity: item.quantity,
			editVariationEditSize_en: item.size_en,
			editVariationEditSize_ar: item.size_ar,
		});
		EVobjIndex = this.state.editVariationSizeList.findIndex((obj) => obj.id === item.id);
	};

	handleVideoFile = (e) => {
		this.setState({ shouldBlockNavigation: true })
		let video = [];
		video.push(e.target.files[0]);
		if (video.length > 0) {
			for (let i = 0; i < video.length; i++) {
				const fsize = video[i].size;
				const file = Math.round(fsize / 1024);
				if (file >= 5000) {
					toastr.error("File too Big, please select a file less than 5 mb");
				} else {
					// video.push(file)
					this.setState({ videoFiles: video }, () => {
						document.getElementById("SelectProductVideo").value = "";
						this.setState({ isVideoUploaded: false });
					});
				}
			}
		}
	};

	handleEditVideoFile = (e) => {
		let editVideo = [];
		editVideo.push(e.target.files[0]);
		console.log("edit video :: ", editVideo);
		if (editVideo.length > 0) {
			for (let i = 0; i < editVideo.length; i++) {
				const Efsiz = editVideo[i].size;
				const Efile = Math.round(Efsiz / 1024);
				if (Efile >= 5000) {
					toastr.error("File too Big, please select a file less than 5 mb");
				} else {
					this.setState({ editVariationVideo: editVideo }, () => {
						document.getElementById("SelectProductVideoEdit").value = "";
						this.setState({ isVideoUploaded: false });
					});
				}
			}
		}
	};

	removeVideo = () => {
		this.setState({ videoFiles: "", isVideoUploaded: true });
	};

	removeEditVideo = () => {
		this.setState({ editVariationVideo: "", isVideoUploaded: true });
	};

	showVariation = () => {
		this.setState(
			{
				isVariationShow: true
			},
			() => {
				let char = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
				let sku = char.charAt(this.state.variationList.length)
				this.setState({ skuCode: sku })

				this.scrollToBottom();
			}
		);
	};

	hideVariation = () => {
		this.setState({ isVariationShow: false, variationSizeList: [] });
	};

	makeid = (length) => {
		var result = "";
		var characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		var charactersLength = characters.length;
		for (var i = 0; i < length; i++) {
			result += characters.charAt(Math.floor(Math.random() * charactersLength));
		}
		return result;
	};
	Alphabetmakeid = (length) => {
		let result = "";
		const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
		const charactersLength = characters.length;
		for (let i = 0; i < length; i++) {
			result += characters.charAt(Math.floor(Math.random() * charactersLength));
		}
		return result;
	};
	addImageToStorage = async () => {
		let imageArr = this.state.serverImg
		let imgarray = await ImageCompress(imageArr) // compress image before upload in server
		var formData = new FormData();
		for (var i = 0; i < imgarray.length; i++) {
			formData.append("file", imgarray[i]);
		}
		let path = API_Path.addFileInS3;
		const addFileInS3Promise = new Promise((resolve, reject) => {
			resolve(PostApi(path, formData));
		});

		addFileInS3Promise.then((res) => {

			if (res) {
				if (res.data.data) {
					let imagesUrl = [];
					for (let i = 0; i < res.data.data.length; i++) {
						let obj = {
							image: res.data.data[i],
							id: this.makeid(8),
						};
						imagesUrl.push(obj);
					}
					this.setState({ uploadedImages: imagesUrl, isImageUploaded: true });
				} else {
					this.setState({ isImageUploaded: true });
				}
			}
		});
	};

	uploadVideoToStorage = () => {
		if (this.state.videoFiles !== "") {


			const formData = new FormData();
			for (let i = 0; i < this.state.videoFiles.length; i++) {
				formData.append("file", this.state.videoFiles[i]);
			}

			let path = API_Path.addFileInS3;
			const addFileInS3Promise = new Promise((resolve, reject) => {
				resolve(PostApi(path, formData));
			});

			addFileInS3Promise.then((res) => {
				if (res.data.data) {
					this.setState({
						isVideoUploaded: true,
						uploadedVideo: res.data.data,
					});
				} else {
					this.setState({ isVideoUploaded: true });
				}
			});
		}
	};

	handleSubmit = () => {
		if (this.state.items === "") {
			document.getElementById("imageArrayError").style.display = "block";
		}
		// if (this.state.selectcolor === "") {
		//   document.getElementById("selectColor").style.display = "block";
		// }
		// if (this.state.colorEnglish === '') {
		//     document.getElementById('englishColor').style.display = 'block'
		// }
		// if (this.state.colorArabic === '') {
		//     document.getElementById('arabicColor').style.display = 'block'
		// }
		if (this.state.price === "") {
			document.getElementById("priceVariant").style.display = "block";
		}
		if (this.state.variationSizeList.length == 0 || (this.state.variationSizeList && this.state.variationSizeList.length === 0)) {
			document.getElementById("variationSizeListError").style.display = "block";
		}
		if (this.state.items !== "" && this.state.price !== "" && this.state.variationSizeList.length > 0 && this.state.variationSizeList.length > 0) {
			this.setState({ isLoading: true });
			ImageFileArray = [];
			this.addImageToStorage();
			this.uploadVideoToStorage();

			let createVariationInterval = setInterval(() => {
				if (this.state.isImageUploaded && this.state.isVideoUploaded) {
					clearInterval(createVariationInterval);
					this.createVariation();
				}
			}, 3000);
		}
	};

	createVariation = () => {
		let sDiscount = this.state.discount.toString();
		let data = {
			images: this.state.uploadedImages,
			variationName_en: this.state.variationName_en,
			variationName_ar: this.state.variationName_ar,
			video: this.state.uploadedVideo,
			color: this.state.selectcolor,
			promotion: this.state.selectPromotion,
			// promotionArabic: this.state.promotionArabic,
			price: this.state.price,
			...(this.state.realprice !== "" && { discount: sDiscount }),
			realPrice: this.state.realprice,
			size_group: parseInt(this.state.selectSize),
			sizeList: this.state.variationSizeList,
			id: Date.now(),
		};
		variationArray.push(data);
		if (variationArray.length > 0) {
			this.setState({ variationList: variationArray ? variationArray : [] }, () => {
				this.props.getVariationList(this.state.variationList);
				this.clearState();
				this.setState({ isLoading: false, variationSizeList: [] });
				variationSizeArray = [];
			});
		}
		// console.log(this.props.getVariationList());
	};

	updateVariation = async () => {
		this.setState({ isLoading: true })
		let objectIndex = variationArray.findIndex((obj) => obj.id === this.state.editVariatioinId);
		if (this.state.isImageUpdate) {

			let img = this.state.editVariationImages
			let c_Img = []
			img.map((item) =>
				typeof item.image == 'object' && c_Img.push(item.image)
			)
			console.log(c_Img, "c_Img");
			let compressedImg = await ImageCompress(c_Img) // compress image before upload in server
			var formData = new FormData();
			for (var i = 0; i < Object.values(compressedImg).length; i++) {
				formData.append("file", Object.values(compressedImg)[i]);
			}
			let path = API_Path.addFileInS3;
			const addFileInS3Promise = new Promise((resolve, reject) => {
				resolve(PostApi(path, formData));
			});

			addFileInS3Promise.then((res) => {
				if (res) {
					let finalImg = editImageArray.filter(obj => typeof obj.image !== 'object')
					editImageArray = finalImg
					for (let i = 0; i < res.data.data.length; i++) {
						let obj = {
							image: res.data.data[i],
							id: this.makeid(8),
						};
						editImageArray.push(obj);
					}
					this.setState({ editVariationImages: editImageArray, isLoading: false, isImageUpdate: false }, () => {
						variationArray[objectIndex].images = this.state.editVariationImages;
						variationArray[objectIndex].variationName_en = this.state.editVariationNameEn;
						variationArray[objectIndex].variationName_ar = this.state.editVariationNameAr;
						variationArray[objectIndex].video = this.state.editVariationVideo;
						variationArray[objectIndex].color = this.state.editVariationColor;
						variationArray[objectIndex].promotion = this.state.editVariationPromotion;
						variationArray[objectIndex].price = this.state.editVariationPrice;
						variationArray[objectIndex].discount = this.state.editVariationDiscount;
						variationArray[objectIndex].realPrice = this.state.editVariationRealPrice;
						variationArray[objectIndex].sizeList = this.state.editVariationSizeList;
						variationArray[objectIndex].selectedSize = this.state.selectSize;
						if (variationArray.length > 0) {
							this.setState({ variationList: variationArray }, () => {
								this.props.getVariationList(this.state.variationList);
								this.clearState();
								this.setState({ isLoading: false, variationSizeList: [] });
								variationSizeArray = [];
								this.edit_var_Close();
							});
						}
					});
				}
			});
		} else {
			variationArray[objectIndex].images = this.state.editVariationImages;
			variationArray[objectIndex].variationName_en = this.state.editVariationNameEn;
			variationArray[objectIndex].variationName_ar = this.state.editVariationNameAr;
			variationArray[objectIndex].video = this.state.editVariationVideo;
			variationArray[objectIndex].color = this.state.editVariationColor;
			variationArray[objectIndex].promotion = this.state.editVariationPromotion;
			variationArray[objectIndex].price = this.state.editVariationPrice;
			variationArray[objectIndex].discount = this.state.editVariationDiscount;
			variationArray[objectIndex].realPrice = this.state.editVariationRealPrice;
			variationArray[objectIndex].sizeList = this.state.editVariationSizeList;
			variationArray[objectIndex].selectedSize = this.state.selectSize;
			if (variationArray.length > 0) {
				this.setState({ variationList: variationArray }, () => {
					this.props.getVariationList(this.state.variationList);
					this.clearState();
					this.setState({ isLoading: false, variationSizeList: [] });
					variationSizeArray = [];
					this.edit_var_Close();
				});
			}
		}

		//Log object to console again.



		// if (filtered && filtered.length === 0) {
		//   document.getElementById("variationSizeListError").style.display = "block";
		// } else {
		// }
		// console.log("update variation", variationArray[0].sizeList.length === 0);
	};

	clearState = () => {
		this.setState({
			items: "",
			videoFiles: "",
			variationName_en: "",
			variationName_ar: "",
			selectcolor: "",
			isVariationShow: false,
			uploadedImages: "",
			isImageUploaded: false,
		});
	};

	errorContainer = (form, field) => {
		return form.touched[field] && form.errors[field] ? <span className="error text-danger">{form.errors[field]}</span> : null;
	};

	formAttr = (form, field) => ({
		onBlur: form.handleBlur,
		onChange: form.handleChange,
		value: form.values[field],
	});

	handleNumberChange = (e) => {
		if (e.target.value >= 0) {
			this.setState({ [e.target.name]: e.target.value });
		}
	};

	handlePriceChange = (e) => {
		this.setState({ shouldBlockNavigation: true })
		if (e.target.value >= 0) {
			this.setState({ realprice: parseFloat(e.target.value).toFixed(2) })
			if (this.state.realprice !== "") {
				this.setState({ price: e.target.value }, () => {
					document.getElementById("priceVariant").style.display = "none";
				});
			} else {
				this.setState({ price: e.target.value }, () => {
					document.getElementById("priceVariant").style.display = "none";
					this.setState({ realprice: parseFloat(e.target.value).toFixed(2) });
				});
			}
		}
	};

	handleDiscountChange = (e) => {
		this.setState({ shouldBlockNavigation: true })
		if (e.target.value >= 0) {
			if (this.state.price !== "") {
				document.getElementById("priceVariant").style.display = "none";
				if (e.target.value < 100) {
					this.setState({ discount: e.target.value }, () => {
						let totalDiscountPrice = (this.state.price / 100) * this.state.discount;
						let updatedRealPrice = this.state.price - totalDiscountPrice;
						this.setState({ realprice: parseFloat(updatedRealPrice).toFixed(2) });
					});
				}
			} else {
				document.getElementById("priceVariant").style.display = "block";
			}
		}
	};

	handleRealPriceChange = (e) => {
		this.setState({ shouldBlockNavigation: true })
		if (e.target.value >= 0) {
			if (this.state.price !== "") {
				document.getElementById("priceVariant").style.display = "none";
				if (parseFloat(e.target.value) <= parseFloat(this.state.price) || e.target.value === "") {
					if (this.state.discount !== '') {
						this.setState({ realprice: e.target.value }, () => {
							let discount = (this.state.realprice / this.state.price) * 100;
							let discountPer = 100 - discount;
							this.setState({ discount: parseFloat(discountPer).toFixed(2) });
						});
					}
				}
			} else {
				document.getElementById("priceVariant").style.display = "block";
			}
		}
	};

	handleEditPriceChange = (e) => {
		if (e.target.value >= 0) {
			if (this.state.editVariationRealPrice !== "") {
				if (parseFloat(this.state.editVariationRealPrice) <= parseFloat(e.target.value) || this.state.editVariationRealPrice === 0) {
					this.setState({ editVariationPrice: e.target.value }, () => {
						document.getElementById("priceVariant").style.display = "none";
						if (this.state.editVariationRealPrice !== "") {
							let discount = (this.state.editVariationRealPrice / this.state.editVariationPrice) * 100;
							let discountPer = 100 - discount;
							this.setState({
								editVariationDiscount: parseFloat(discountPer).toFixed(2),
							});
						} else if (this.state.editVariationDiscount !== "") {
							let totalDiscountPrice = (this.state.editVariationPrice / 100) * this.state.editVariationDiscount;
							let updatedRealPrice = this.state.editVariationPrice - totalDiscountPrice;
							this.setState({
								editVariationRealPrice: parseFloat(updatedRealPrice).toFixed(2),
							});
						}
					});
				} else {
					console.log("come");
				}
			} else {
				this.setState({ editVariationPrice: e.target.value }, () => {
					document.getElementById("priceVariant").style.display = "none";
					if (this.state.editVariationRealPrice !== "") {
						let discount = (this.state.editVariationRealPrice / this.state.editVariationPrice) * 100;
						let discountPer = 100 - discount;
						this.setState({
							editVariationDiscount: parseFloat(discountPer).toFixed(2),
						});
					} else if (this.state.editVariationDiscount !== "") {
						let totalDiscountPrice = (this.state.editVariationPrice / 100) * this.state.editVariationDiscount;
						let updatedRealPrice = this.state.editVariationPrice - totalDiscountPrice;
						this.setState({
							editVariationRealPrice: parseFloat(updatedRealPrice).toFixed(2),
						});
					}
				});
			}
		}
	};

	handleEditDiscountChange = (e) => {
		if (e.target.value >= 0) {
			if (this.state.editVariationPrice !== "") {
				document.getElementById("priceVariant").style.display = "none";
				if (e.target.value < 100) {
					this.setState({ editVariationDiscount: e.target.value }, () => {
						let totalDiscountPrice = (this.state.editVariationPrice / 100) * this.state.editVariationDiscount;
						let updatedRealPrice = this.state.editVariationPrice - totalDiscountPrice;

						this.setState({
							editVariationRealPrice: parseFloat(updatedRealPrice).toFixed(2),
						});
					});
				}
			} else {
				document.getElementById("priceVariant").style.display = "block";
			}
		}
	};

	handleEditRealPriceChange = (e) => {
		if (e.target.value >= 0) {
			if (this.state.editVariationPrice !== "") {
				document.getElementById("priceVariant").style.display = "none";
				console.log("e :: ", e.target.value);
				if (parseFloat(e.target.value) < parseFloat(this.state.editVariationPrice) || e.target.value === "") {
					this.setState({ editVariationRealPrice: e.target.value }, () => {
						console.log("object", parseFloat(this.state.realprice) > parseFloat(this.state.editVariationPrice));
						// this.setState({ realPrice: this.state.price }, () => {
						let discount = (this.state.editVariationRealPrice / this.state.editVariationPrice) * 100;
						let discountPer = 100 - discount;
						this.setState({
							editVariationDiscount: parseFloat(discountPer).toFixed(2),
						});
						// })
					});
				}
			} else {
				document.getElementById("priceVariant").style.display = "block";
			}
		}
	};

	// handleEditNumberChange = (e) => {
	//     if (e.target.value >= 0) {
	//         this.setState({ [e.target.name]: e.target.value }, () => {
	//             if (this.state.editVariationPrice !== '') {
	//                 document.getElementById('priceVariant').style.display = 'none'
	//             } else {
	//                 document.getElementById('priceVariant').style.display = 'block'
	//             }
	//             if (this.state.editVariationRealPrice === '') {
	//                 this.setState({ editVariationDiscount: 0 })
	//             } else {
	//                 this.setState({
	//                     editVariationDiscount: parseInt(100 - (this.state.editVariationRealPrice / this.state.editVariationPrice) * 100),
	//                 })
	//             }
	//         })
	//     }
	// }

	handleSearchFocus = () => {
		if (document.getElementById("pro-list")) {
			document.getElementById("pro-list").classList.add("active");
		}
	};

	handleSearchBlur = () => {
		setTimeout(() => {
			if (document.getElementById("pro-list")) {
				document.getElementById("pro-list").classList.remove("active");
			}
		}, 500);
	};

	handleTextChange = (e) => {
		// var index = e.target.selectedIndex;
		// var el = e.target.childNodes[index]
		// var sizeId = el?.getAttribute('id');
		if (document.getElementById("pro-list")) {
			document.getElementById("pro-list").classList.add("active");
		}
		this.setState({ search_val_en: e.target.value?.split('|')[0], search_val_ar: e.target.value?.split('|')[e.target.value?.split('|')?.length - 1] }, () => {
			// this.setState({ search_val_en: e.target.value?.split('|')[0], search_val_ar: e.target.value?.split('|')[e.target.value?.split('|')?.length - 1], selectedVariantSize: sizeId, size_en: e.target.value?.split('|')[0], size_ar: e.target.value?.split('|')[e.target.value?.split('|')?.length - 1], editSize_en: e.target.value?.split('|')[0], editSize_ar: e.target.value?.split('|')[e.target.value?.split('|')?.length - 1], editVariationAddSize_en: e.target.value?.split('|')[0], editVariationAddSize_ar: e.target.value?.split('|')[e.target.value?.split('|')?.length - 1], editVariationEditSize_en: e.target.value?.split('|')[0], editVariationEditSize_ar: e.target.value?.split('|')[e.target.value?.split('|')?.length - 1] }, () => {
			// if (document.getElementById('errorSize')) {
			//   document.getElementById('errorSize').classList.add('d-none')
			//   document.getElementById('errorSize').classList.remove('d-block')
			// }
			// if (document.getElementById('addErrorSize')) {
			//   document.getElementById('addErrorSize').classList.add('d-none')
			//   document.getElementById('addErrorSize').classList.remove('d-block')
			// }
		});
	};

	handleClickSize = (english, arabic, id) => {
		this.setState({ search_val_en: english, size_en: english, size_ar: arabic, editSize_en: english, editSize_ar: arabic, editVariationAddSize_en: english, editVariationAddSize_ar: arabic, editVariationEditSize_en: english, editVariationEditSize_ar: arabic, selectedVariantSize: id }, () => {
			if (document.getElementById('sizeInput')) {
				document.getElementById('sizeInput').value = this.context.language === 'english' ? english : arabic
			}
			if (document.getElementById('editSizeInput')) {
				document.getElementById('editSizeInput').value = this.context.language === 'english' ? english : arabic
			}
			if (document.getElementById('errorSize')) {
				document.getElementById('errorSize').classList.add('d-none')
				document.getElementById('errorSize').classList.remove('d-block')
			}
			if (document.getElementById('addErrorSize')) {
				document.getElementById('addErrorSize').classList.add('d-none')
				document.getElementById('addErrorSize').classList.remove('d-block')
			}
		});
	}

	handleColorChange = (e) => {
		this.setState({ [e.target.name]: e.target.value, shouldBlockNavigation: true });
	};

	handlePromotionChange = (e) => {
		this.setState({ [e.target.name]: e.target.value, shouldBlockNavigation: true });
	};

	handleClear = (itemToClear) => {
		this.setState({ [itemToClear]: 0 });
	};

	removeVariation = (id) => {
		const filteredVariations = this.state.variationList.filter((item) => item.id !== id);
		// console.log('filter :: ', filteredVariations);
		variationArray = filteredVariations ? filteredVariations : [];
		this.setState({ variationList: filteredVariations }, () => {
			this.props.getVariationList(this.state.variationList);
		});
	};

	scrollToBottom = () => {
		this.messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
	};

	addpro = () => {
		this.setState({ addproduct_show: true, sizeQuantity: "" });
	};

	editVariationAddPro = () => {
		this.setState({
			editVariationAddproduct_show: true,
			editVariationAddSizeQuantity: "",
		});
	};

	edit_Close = () => {
		this.setState({ addproduct_show: false });
	};

	editVariationAddProductPopupClose = () => {
		this.setState({ editVariationAddproduct_show: false });
	};

	edit_variation = (variationDetails) => {
		this.setState(
			{
				edit_var: true,
				editVariationDetails: variationDetails,
				editVariationImages: variationDetails.images,
				editVariationVideo: variationDetails.video,
				editVariationNameEn: variationDetails.variationName_en,
				editVariationNameAr: variationDetails.variationName_ar,
				editVariationColor: variationDetails.color,
				editVariationPromotion: variationDetails.promotion,
				editVariationRealPrice: variationDetails.realPrice,
				editVariationPrice: variationDetails.price,
				editVariationDiscount: variationDetails.discount,
				editVariationSizeList: variationDetails.sizeList,
				selectSize: variationDetails.size_group,
				editVariatioinId: variationDetails.id,
			},
			() => {
				editImageArray = variationDetails.images;

				editVariationSizeArray = variationDetails.sizeList;
				// console.log("state images :: ", editVariationSizeArray);
				// console.log("variationa detail :: ", variationDetails);
				// console.log("size  :: ", variationDetails.selectedSize);
			}
		);
	};

	edit_var_Close = () => {
		this.setState({ edit_var: false });
	};

	handleModalSubmit = () => {
		if (this.state.sizeQuantity !== "") {
			const d = Date.now();
			let nid = d.toString();
			let data = {
				size_en: this.state.size_en,
				size_ar: this.state.size_ar,
				size_id: this.state.selectedVariantSize,
				sku: ((this.props.productCode) + (this.state.skuCode) + (this.context.language === 'english' ? this.state.size_en : this.state.size_ar)).toUpperCase(),
				quantity: this.state.sizeQuantity,
				id: this.Alphabetmakeid(8),
				selectedSize: this.state.selectSize,
			};

			let addarrsize = []
			console.log(this.state.variationSizeList, "this.state.variationSizeList");
			variationSizeArray = this.state.variationSizeList

			this.state.variationSizeList && this.state.variationSizeList.map((item) => {
				addarrsize.push(item.size_en + " | " + item.size_ar)
			})
			if (!addarrsize.includes(data.size_en + " | " + data.size_ar)) {
				variationSizeArray.push(data);
				this.setState({ variationSizeList: variationSizeArray }, () => {
					variationSizeArray = []
					this.edit_Close();
				});
			} else {
				document.getElementById('addErrorSize').classList.remove('d-none')
				document.getElementById('addErrorSize').classList.add('d-block')
			}

			this.setState(
				{
					size_en: "",
					size_ar: "",
					search_val_en: "",
					search_val_ar: "",
					editSizeQuantity: this.state.sizeQuantity,
				},
				() => {
					document.getElementById("variationSizeListError").style.display = "none";
				}
			);
		} else {
			toastr.error("Please add quantity");
		}
	};

	handleSizeChange = (e) => {
		this.setState({ shouldBlockNavigation: true, selectSize: e.target.value, ErrMsg: "", ErrMsg1: "" }, () => {
			if (this.state.selectSize === '1') {
				this.getinternationalsizesData();
			}
			else if (this.state.selectSize === '2') {
				this.getnumericalsizesData();
			}
			else if (this.state.selectSize === '3') {
				this.getagesizesData();
			}
			else if (this.state.selectSize === '4') {
				this.getbrasizesData();
			}
			else if (this.state.selectSize === '5') {
				this.getmiscData();
			}
			document.getElementById("variationSizeListError").style.display = "none";

		});
	};

	handleEditVariationAddProModalSubmit = () => {
		if (this.state.editVariationAddSizeQuantity !== "") {
			const d = Date.now();
			let nid = d.toString();
			let data = {
				size_en: this.state.editVariationAddSize_en,
				size_ar: this.state.editVariationAddSize_ar,
				size_id: this.state.selectedVariantSize,
				sku: `${((this.props.productCode) + (this.state.skuCode) + (this.context.language === 'english' ? this.state.editVariationAddSize_en : this.state.editVariationAddSize_ar)).toUpperCase()}`,
				quantity: this.state.editVariationAddSizeQuantity,
				id: this.Alphabetmakeid(8),
				selectedSize: this.state.selectSize,
			};

			let arrsize = []
			this.state.editVariationSizeList && this.state.editVariationSizeList.map((item) => {
				arrsize.push(item.size_en + " | " + item.size_ar)
			})
			if (!arrsize.includes(data.size_en + " | " + data.size_ar)) {
				editVariationSizeArray.push(data);
				this.setState({ editVariationSizeList: editVariationSizeArray }, () => {
					this.editVariationAddProductPopupClose();
				});
			} else {
				document.getElementById('errorSize').classList.remove('d-none')
				document.getElementById('errorSize').classList.add('d-block')
			}

			this.setState(
				{
					editVariationAddSize_en: "",
					editVariationAddSize_ar: "",
					editVariationAddSizeQuantity: "",
					search_val_en: "",
					search_val_ar: "",
				},
				() => {
					document.getElementById("variationSizeListError").style.display = "none";
				}
			);
		} else {
			toastr.error("Please add quantity");
		}
	};

	handleEditModalSubmit = (id) => {
		console.log("object is :: ", this.state.variationSizeList);
		// console.log("id :: ", id);
		this.state.variationSizeList[objIndex].quantity = this.state.editSizeQuantity;
		this.state.variationSizeList[objIndex].size_en = this.state.editSize_en;
		this.state.variationSizeList[objIndex].size_ar = this.state.editSize_ar;
		this.state.variationSizeList[objIndex].sku = this.props.productCode + this.state.skuCode + (this.context.language === 'english' ? this.state.editSize_en : this.state.editSize_ar);

		this.editVariantClose();
		// }
		// );
	};

	handleEditVariationEditModalSubmit = (id) => {
		// console.log('object is :: ', this.state.variationSizeList);
		this.state.editVariationSizeList[EVobjIndex].quantity = this.state.editVariationEditSizeQuantity;
		this.state.editVariationSizeList[EVobjIndex].size_en = this.state.editVariationEditSize_en;
		this.state.editVariationSizeList[EVobjIndex].size_ar = this.state.editVariationEditSize_ar;
		this.state.editVariationSizeList[EVobjIndex].sku = this.props.productCode + this.state.skuCode + this.context.language === 'english' ? this.state.editVariationEditSize_en : this.state.editVariationEditSize_ar;
		this.editvariationEditsizePopupClose();

	};

	editVariantClose = () => {
		this.setState({ editVariantShow: false });
	};

	editvariationEditsizePopupClose = () => {
		this.setState({ editVariationSizeVariantShow: false });
	};

	handleRemoveRow = (id) => {
		variationSizeArray = this.state.variationSizeList
		console.log(id, "id", variationSizeArray);
		const filteredSize = variationSizeArray.length > 0 && variationSizeArray.filter((item) => item.id !== id);
		const filteredSize1 = filteredSize.length > 0 && filteredSize.filter((item) => item.selectedSize === this.state.selectSize);

		// const filteredSize = variationSizeArray.filter((item) => item.id !== id);
		variationSizeArray = filteredSize1 ? filteredSize : [];

		this.setState({
			variationSizeList: variationSizeArray,
		});
	};

	handleRemoveEditRow = (id) => {
		editVariationSizeArray = this.state.editVariationSizeList
		const filteredEditSize = editVariationSizeArray.length > 0 && editVariationSizeArray.filter((item) => item.id !== id);
		const filteredEditSize1 = filteredEditSize.length > 0 && filteredEditSize.filter((item) => item.selectedSize === this.state.selectSize);
		console.log(filteredEditSize1);

		editVariationSizeArray = filteredEditSize1 ? filteredEditSize : [];
		this.setState({
			editVariationSizeList: editVariationSizeArray,
		});
	};

	editVariationRemoveRow = (id) => {
		const filteredEditSize = editVariationSizeArray.length > 0 && editVariationSizeArray.filter((item) => item.id !== id);
		const filteredEditSize1 = filteredEditSize.length > 0 && filteredEditSize.filter((item) => item.selectedSize === this.state.selectSize);
		console.log(filteredEditSize1);

		editVariationSizeArray = filteredEditSize1 ? filteredEditSize1 : [];
		this.setState({ editVariationSizeList: filteredEditSize1 });
	};

	delete_variation = (id) => {
		confirmAlert({
			customUI: ({ onClose }) => {
				return (
					<div className="custom-ui">
						<h1>Are you sure?</h1>
						<p> Do you want to delete this Variation?</p>
						<button className="btn red-btn me-2" onClick={onClose}>
							No
						</button>
						<button
							className="btn red-btn"
							onClick={() => {
								// this.finaly_delete_record(id);
								onClose();
								this.removeVariation(id);
							}}
						>
							Delete
						</button>
					</div>
				);
			},
		});
	};

	delete_record = (id) => {
		confirmAlert({
			customUI: ({ onClose }) => {
				return (
					<div className="custom-ui">
						<h1>Are you sure?</h1>
						<p> Do you want to clear this item?</p>
						<button className="btn red-btn me-2" onClick={onClose}>
							No
						</button>
						<button
							className="btn red-btn"
							onClick={() => {
								// this.finaly_delete_record(id);
								onClose();
								this.handleRemoveRow(id);
								this.handleRemoveEditRow(id);
							}}
						>
							Clear
						</button>
					</div>
				);
			},
		});
	};

	editVariationDelete_record = (id) => {
		confirmAlert({
			customUI: ({ onClose }) => {
				return (
					<div className="custom-ui">
						<h1>Are you sure?</h1>
						<p> Do you want to delete this item?</p>
						<button className="btn red-btn me-2" onClick={onClose}>
							No
						</button>
						<button
							className="btn red-btn"
							onClick={() => {
								// this.finaly_delete_record(id);
								onClose();
								this.editVariationRemoveRow(id);
							}}
						>
							Delete
						</button>
					</div>
				);
			},
		});
	};

	finaly_delete_record = (id) => {
		alert(id);
	};

	getColorData = () => {
		let path = API_Path.getColor;
		const getColorPromise = new Promise((resolve) => {
			resolve(PostApi(path));
		});
		getColorPromise.then((respons) => {
			if (respons) {
				this.setState({ color: respons.data.data });
				// console.log(respons.data.data);
			}
		});
	};

	getPromotionData = () => {
		let path = API_Path.getPromotion;
		const getPromotionPromise = new Promise((resolve) => {
			resolve(PostApi(path));
		});
		getPromotionPromise.then((respons) => {
			if (respons) {
				this.setState({ promotion: respons.data.data });
				// console.log(respons.data.data);
			}
		});
	};

	handleQuantityChange = (e) => {
		this.setState({ [e.target.name]: e.target.value });
	};

	// onSortEnd = ({ oldIndex, newIndex }) => {
	//   this.setState(({ items }) => ({
	//     items: arrayMove(items, oldIndex, newIndex),
	//   }));
	// };

	render() {
		// let Language = this.context.language === "english" ? TableFieldEnglish : TableFieldArabic;
		let ButtonLanguage = this.context.language === "english" ? buttonEnglish : buttonArabic;
		// let titleLanguage = this.context.language === "english" ? titleEnglish : titleArabic;
		let productLanguage = this.context.language === "english" ? productEnglish : productArabic;

		return (
			<React.Fragment>
				<Prompt when={this.state.shouldBlockNavigation === true} message="You have unsaved changes, are you sure you want to leave?" />

				{this.state.isLoading && (
					<div className="loader-main">
						<div className="loader-inr">
							<img src={loader} alt="" />
						</div>
					</div>
				)}
				<div ref={this.messagesEndRef}>
					<div className="row common-space">
						<div className="col-12">
							<div className="white-box">
								<div className="custom-bx-drop-varant">
									<div className="img-preview d-inline-block align-middle">
										<ul>
											{this.state.variationList.length > 0 && (
												<DragDropContext onDragEnd={this.onDragEndVariant}>
													<Droppable droppableId="droppable" direction="horizontal">
														{(provided, snapshot) => (
															<div ref={provided.innerRef} style={getListStyle(snapshot.isDraggingOver, this.state.variationList.length)} {...provided.droppableProps}>
																{this.state.variationList.map((item, index) => (
																	<Draggable key={item.id.toString()} draggableId={item.id.toString()} index={index}>
																		{(provided, snapshot) => (
																			<div ref={provided.innerRef} {...provided.draggableProps} {...provided.dragHandleProps} style={getItemStyle(snapshot.isDragging, provided.draggableProps.style)}>
																				<li key={index}>
																					<div className="img-preview-main position-relative">
																						<img src={item.images.length > 0 ? item.images[0].image : ""} alt="" onClick={() => this.edit_variation(item)} />
																						<div className="remove-img-btn">
																							<i onClick={() => this.delete_variation(item.id)} className="bi bi-x-circle-fill" />
																						</div>
																					</div>
																				</li>
																			</div>
																		)}
																	</Draggable>
																))}
																{provided.placeholder}
															</div>
														)}
													</Droppable>
												</DragDropContext>
											)}
										</ul>
									</div>
									<div onClick={this.showVariation} className="img-with-close-varia position-relative cursor-pointer ms-3 align-middle">
										<p>
											<i className="bi bi-plus-lg"></i>
										</p>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div ref={this.messagesEndRef}>
						{this.state.isVariationShow && (
							<div className="row common-space">
								<div className="col-md-12">
									<div className="white-box">
										<div className="row">
											<div className="col-lg-6 mb-lg-0 mb-3">
												<div className="row ">
													<div className="col-md-12">
														<div className="product-in-title d-flex align-items-center pb-3 custom-border-title">
															<span>{productLanguage.ProductImage}</span>
														</div>
													</div>
													<div className="col-md-12 mt-3">
														<div className="upload-file-section-new position-relative">
															<div className="file-selecter text-center position-relative h-auto">
																<div className="file-area position-relative py-3">
																	<input type="file" name="productImage" id="SelectProductImage" onChange={this.handleImageFile} accept="image/*" multiple />
																	<div className="file-dummy">
																		<div className="file-upload-content mb-3">
																			<img className="file-dummy-image" src={dragimg} alt="" />
																		</div>
																		<span>
																			{productLanguage.DragDrop}
																			<bdi className="d-block">{productLanguage.or}</bdi>
																		</span>
																		<button className="btn red-btn mt-3">{productLanguage.BrowseFiles}</button>
																	</div>
																</div>
															</div>
														</div>
														<div id="imageArrayError" style={{ display: "none" }} className="input-feedback text-danger">
															Required
														</div>
													</div>

													<div className="col-md-12">
														<span>{productLanguage.UploadedImageFile}</span>
														{/* {this.state.items.length > 0 &&
                              < SortableList items={this.state.items} onSortEnd={this.onSortEnd} axis={'xy'} removeImg={this.removeImage} transitionDuration={500} pressDelay={100} />
                            } */}
														<div className="img-preview">
															<ul>
																{this.state.items.length > 0 && (
																	<DragDropContext onDragEnd={this.onDragEnd}>
																		<Droppable droppableId="droppable" direction="horizontal">
																			{(provided, snapshot) => (
																				<div ref={provided.innerRef} style={getListStyle(snapshot.isDraggingOver, this.state.items.length)} {...provided.droppableProps}>
																					{this.state.items.map((item, index) => (
																						<Draggable key={item.id} draggableId={item.id} index={index}>
																							{(provided, snapshot) => (
																								<div ref={provided.innerRef} {...provided.draggableProps} {...provided.dragHandleProps} style={getItemStyle(snapshot.isDragging, provided.draggableProps.style)}>
																									<li key={index}>
																										<div className="img-preview-main position-relative">

																											<img src={URL.createObjectURL(item.src)} alt="" />
																											<div className="remove-img-btn">
																												<i
																													onClick={() => {
																														this.removeImage(item.id);
																													}}
																													className="bi bi-x-circle-fill"
																												/>
																											</div>
																										</div>
																									</li>
																								</div>
																							)}
																						</Draggable>
																					))}
																					{provided.placeholder}
																				</div>
																			)}
																		</Droppable>
																	</DragDropContext>
																)}
															</ul>
														</div>
													</div>
												</div>
											</div>
											<div className="col-lg-6 mb-lg-0 mb-3">
												<div className="row">
													<div className="col-md-12">
														<div className="product-in-title d-flex align-items-center pb-3 custom-border-title">
															<span>{productLanguage.VideoOptional}</span>
														</div>
													</div>
													<div className="col-md-12 mt-3">
														<div className="upload-file-section-new position-relative">
															<div className="file-selecter text-center position-relative h-auto">
																<div className="file-area position-relative py-3">
																	<input type="file" name="licence_image_temp" onChange={this.handleVideoFile} accept="video/*" id="SelectProductVideo" />
																	<div className="file-dummy">
																		<div className="file-upload-content mb-3">
																			<img className="file-dummy-image" src={dragimg} alt="" />
																		</div>
																		<span>
																			{productLanguage.DragDrop}
																			<bdi className="d-block">{productLanguage.or}</bdi>
																		</span>
																		<button className="btn red-btn mt-3">{productLanguage.UploadVideo}</button>
																	</div>
																</div>
															</div>
														</div>
														<span>{productLanguage.UploadVideoFile} (mp4, flv)</span>
													</div>
													<div className="col-md-12 mt-3">
														<span>{productLanguage.UploadedVideoFile}</span>
														<div className="video-preview">
															<ul>
																{this.state.videoFiles.length > 0 && (
																	<li className="gray-bg-video d-flex align-items-center my-2">
																		<div className="video-thumb position-relative">
																			{/* <img src="" alt="" /> */}
																			<div className="video-icn-pro">
																				<img src={videoicn} alt="" />
																			</div>
																		</div>
																		<div className="vide-prev-txt ms-2">
																			<p className="mb-0">{this.state.videoFiles[0].name}</p>
																			<bdi>{parseFloat(this.state.videoFiles[0].size / 1024).toFixed(2)} kb</bdi>
																		</div>
																		<div className="ms-auto pe-2">
																			<i onClick={this.removeVideo} className="bi bi-x-circle-fill"></i>
																		</div>
																	</li>
																)}
															</ul>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div className="row">
											<div className="col-lg-6 mb-lg-0 mb-3">
												<div className="row">
													{/* <div className="form-group col-md-6">
                            <label>
                              {productLanguage.VariationNameinEnglish}
                            </label>
                            <input
                              type="text"
                              className="input-custom-class form-control"
                              placeholder={productLanguage.VariationName}
                              name="variationName_en"
                              defaultValue={this.state.variationName_en}
                              onChange={this.handleTextChange}
                            />
                            <span
                              style={{ display: "none" }}
                              className="input-feedback text-danger"
                            >
                              Required
                            </span>
                          </div> */}
													{/* <div className="form-group col-md-6">
                            <label>
                              {productLanguage.VariationNameinArabic}
                            </label>
                            <input
                              type="text"
                              dir="rtl"
                              className="input-custom-class form-control"
                              placeholder="اسم الاختلاف"
                              name="variationName_ar"
                              defaultValue={this.state.variationName_ar}
                              onChange={this.handleTextChange}
                            />
                            <span
                              style={{ display: "none" }}
                              className="input-feedback text-danger"
                            >
                              Required
                            </span>
                          </div> */}
													<div className="form-group col-md-12">
														<label>{productLanguage.selectColor}</label>
														<select className="form-select input-custom-class" name="selectcolor" onChange={this.handleColorChange}>
															<option defaultValue>{productLanguage.selectColor}</option>
															{/* <option value="0">
                                Multicolor | متعدد اللألوان
                              </option> */}
															{this.state.color &&
																this.state.color.length > 0 &&
																this.state.color?.map((item, i) => {
																	return (
																		<option key={i} value={item.id}>
																			{item.english} | {item.arabic}
																		</option>
																	);
																})}
														</select>
													</div>
													<div className="form-group col-md-12">
														<label>{productLanguage.addPromotion}</label>

														<select className="form-select input-custom-class" name="selectPromotion" onChange={this.handlePromotionChange}>
															<option defaultValue>{productLanguage.selectPromotion}</option>
															{this.state.promotion.length > 0 &&
																this.state.promotion?.map((item, i) => {
																	return (
																		<option key={i} value={item.id}>
																			{item.english} | {item.arabic}
																		</option>
																	);
																})}
														</select>
													</div>
													<div className="form-group col-md-12">
														<label>{productLanguage.Price}</label>
														<input type="number" className="input-custom-class form-control" name="price" value={this.state.price} onChange={this.handlePriceChange} placeholder="SR 200" />
														<span id="priceVariant" style={{ display: "none" }} className="input-feedback text-danger">
															Required
														</span>
													</div>

													<div className="form-group col-md-12">
														<label>{productLanguage.Discount}</label>
														<input type="number" className="input-custom-class form-control" name="discount" value={this.state.discount} onChange={this.handleDiscountChange} placeholder="10%" />
														<span id="discountVariant" style={{ display: "none" }} className="input-feedback text-danger">
															Required
														</span>
													</div>
													<div className="form-group col-md-12">
														<label>{productLanguage.realPrice}</label>
														<input type="number" className="input-custom-class form-control" name="realprice" value={this.state.realprice} onChange={this.handleRealPriceChange} placeholder="SR 100" />
														<span id="realpriceVariant" style={{ display: "none" }} className="input-feedback text-danger">
															Required
														</span>
													</div>
													<div className="form-group col-md-12">
														<label>{productLanguage.sizeGroup}</label>
														<select className="form-select input-custom-class" value={this.state.selectSize} name="selectsize" onChange={this.handleSizeChange}>
															<option value="0">{productLanguage.selectSize}</option>
															<option value="1">{productLanguage.international}</option>
															<option value="2">{productLanguage.numerical}</option>
															<option value="3">{productLanguage.ageWise}</option>
															<option value="4">{productLanguage.braSize}</option>
															<option value="5">{productLanguage.misc}</option>
														</select>
														{ }
														<p className="input-feedback text-danger mt-3">{this.state.ErrMsg1}</p>
													</div>
												</div>
											</div>
											<div className="col-lg-6">
												<div className="row">
													<div className="col-md-12">
														<div className="product-in-title d-flex align-items-center">
															<span>{productLanguage.SelectVariantInfo}</span>
															<span id="variationSizeListError" style={{ display: "none" }} className="ms-2 input-feedback text-danger fs-6 fw-normal">
																Required
															</span>
														</div>
													</div>
													<div className="col-md-12 mt-3">
														<div className="custom-table-product">
															<div className="table-responsive dataTables_wrapper no-footer">
																<DragDropContext onDragEnd={this.onDragEndTable}>
																	<table className="fixed-height-set">
																		<thead>
																			<tr>
																				<th>{productLanguage.size}</th>
																				<th>SKU</th>
																				<th>{productLanguage.quantity}</th>
																				<th>{productLanguage.action}</th>
																			</tr>
																		</thead>
																		{this.state.variationSizeList.length > 0 && (
																			<Droppable droppableId="droppable" direction="vertical">
																				{(provided) => (
																					<tbody {...provided.droppableProps} ref={provided.innerRef}>
																						{this.state.variationSizeList.map((item, index) => (
																							// console.log("-------------",item),
																							<Draggable key={item.id} draggableId={item.id} index={index}>
																								{(provided) => (
																									<tr ref={provided.innerRef} {...provided.draggableProps} {...provided.dragHandleProps}>
																										<td>{this.context.language === 'english' ? item.size_en : item.size_ar}</td>
																										<td>{item.sku}</td>
																										<td>{item.quantity}</td>
																										<td>
																											<Dropdown className="cust-drop">
																												<Dropdown.Toggle className="bg-transparent " id="dropdown-basic" align="end">
																													<svg xmlns="http://www.w3.org/2000/svg" width={16} height={16} fill="currentColor" className="bi bi-three-dots-vertical" viewBox="0 0 16 16">
																														<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																													</svg>
																												</Dropdown.Toggle>
																												<Dropdown.Menu>
																													<Dropdown.Item href="#" className="bi bi-pencil-square me-1" onClick={() => this.handleEditRow(item)}>
																														<span>Edit</span>
																													</Dropdown.Item>
																													<Dropdown.Item href="#" onClick={() => this.delete_record(item.sizeListId ? item.sizeListId : item.id)}>
																														<svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} fill="currentColor" className="bi bi-trash" viewBox="0 0 16 16">
																															<path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
																															<path fillRule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" />
																														</svg>
																														<span>Delete</span>
																													</Dropdown.Item>
																												</Dropdown.Menu>
																											</Dropdown>
																										</td>
																										{/* <td>
                                                      <button className="text-decoration-underline btn text-dark" onClick={() => this.delete_record(item.id)}>
                                                        <span>{ButtonLanguage.clear}</span>
                                                      </button>
                                                    </td> */}
																									</tr>
																								)}
																							</Draggable>
																						))}
																						{provided.placeholder}
																					</tbody>
																				)}
																			</Droppable>
																		)}
																		{this.state.selectSize <= 0 ? (
																			<div className="clear_btn cursor-pointer" onClick={() => this.setState({ ErrMsg: "Please select Size Group", ErrMsg1: "Required" })}>
																				+{productLanguage.Add}
																			</div>
																		) : (
																			<div className="clear_btn cursor-pointer " onClick={this.addpro}>
																				+{productLanguage.Add}
																			</div>
																		)}
																		<p className="input-feedback text-danger mt-3">{this.state.ErrMsg}</p>
																	</table>
																</DragDropContext>
																<span id="variationSizeListError" style={{ display: "none" }} className="input-feedback text-danger">
																	Required
																</span>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div className="row">
											<div className="col-md-12 text-center">
												<button onClick={this.handleSubmit} className="btn red-btn me-2">
													{productLanguage.submit}{" "}
												</button>
												<button onClick={this.hideVariation} className="btn black-btn">
													{ButtonLanguage.cancel}
												</button>
											</div>
										</div>
									</div>
								</div>
							</div>
						)}
						{/* ===============================================================add-variant-popup======================================= */}
						<Modal
							dialogClassName="modal-dialog-centered"
							className="edit-user-modal cust-modal"
							size="lg"
							ref={(el) => {
								this.dialog = el;
							}}
							show={this.state.addproduct_show}
							onHide={this.edit_Close}
						>
							<Modal.Header>
								<Modal.Title>
									<h1 className="modal-title">{productLanguage.SelectVariantInfo}</h1>
								</Modal.Title>
								<button type="button" onClick={this.edit_Close} className="close btn-close"></button>
							</Modal.Header>
							<Modal.Body>
								<div className="row">
									<div className="col-md-4 form-group">
										<label>{productLanguage.size}</label>
										{/* <select name="sizeOptions" onChange={this.handleTextChange} className="form-select">
                      <option>{productLanguage.SelectSize}</option>
                      {this.state.SizeGroupSizes &&
                        this.state.SizeGroupSizes.map((item, i) => {
                          return <option key={i} id={item.id}>{item.english} | {item.arabic}</option>;
                        })}
                    </select> */}
										<div className="position-relative">
											<input type="text" name="sizeOptions" className="form-control form-select" autoComplete="off" id="sizeInput" value={this.context.language === 'english' ? this.state.search_val_en : this.state.search_val_ar} onChange={this.handleTextChange} onBlur={this.handleSearchBlur} onFocus={this.handleSearchFocus} placeholder={productLanguage.SearchSelectsize} />
											<div className="opt-product-list start-0 end-0 opt-product-list-cust" id="pro-list">
												<ul>
													{
														this.state.SizeGroupSizes &&
														this.state.SizeGroupSizes?.filter((search) => this.context.language === 'english' ? (search.english.toLowerCase().includes(this.state.search_val_en)) : (search.english.toLowerCase().includes(this.state.search_val_ar)))?.length === 0 && (
															<li>There is no sizes.</li>
														)
													}
													{
														this.state.SizeGroupSizes &&
														this.state.SizeGroupSizes?.filter((search) => this.context.language === 'english' ? (search.english.toLowerCase().includes(this.state.search_val_en)) : (search.english.toLowerCase().includes(this.state.search_val_ar))).map((item, i) => {
															return <li key={i} id={item.id} onClick={() => this.handleClickSize(item.english, item.arabic, item.id)}>{item.english} | {item.arabic}</li>;
														})
													}
												</ul>
											</div>
										</div>
										<span className="red-txt d-none" id="addErrorSize">This size already exist.</span>
									</div>
									<div className="col-md-4 form-group">
										<label>SKU</label>
										<input type="text" className="form-control input-custom-class" value={`${((this.props.productCode) + (this.state.skuCode) + (this.context.language === 'english' ? this.state.size_en : this.state.size_ar)).toUpperCase()}`} readOnly />
									</div>
									<div className="col-md-4 form-group">
										<label>{productLanguage.quantity}</label>
										<input type="number" name="sizeQuantity" value={this.state.sizeQuantity} onChange={this.handleNumberChange} className="form-control input-custom-class m-auto" placeholder="1" />
									</div>

									<div className="col-md-12 text-center">
										<button onClick={this.handleModalSubmit} className="red-btn">
											{productLanguage.submit}
										</button>
									</div>
								</div>
							</Modal.Body>
						</Modal>

						<Modal
							dialogClassName="modal-dialog-centered"
							className="edit-user-modal cust-modal"
							size="lg"
							ref={(el) => {
								this.dialog = el;
							}}
							show={this.state.editVariationAddproduct_show}
							onHide={this.editVariationAddProductPopupClose}
						>
							<Modal.Header>
								<Modal.Title>
									<h1 className="modal-title">{productLanguage.SelectVariantInfo}</h1>
								</Modal.Title>
								<button type="button" onClick={this.editVariationAddProductPopupClose} className="close btn-close"></button>
							</Modal.Header>
							<Modal.Body>
								<div className="row">
									<div className="col-md-4 form-group">
										<label>{productLanguage.size}</label>
										{/* <select name="editVariationAddSizeOptions" id="" onChange={this.handleTextChange} className="form-select">
                      {this.state.SizeGroupSizes &&
                        this.state.SizeGroupSizes.map((item, i) => {
                          return (
                            <>
                              {this.state.editVariationAddSize_en === item.english ? (
                                <option key={i} selected value={item.english} id={item.id}>
                                  {item.english} | {item.arabic}
                                </option>
                              ) : (
                                <option key={i} value={item.english} id={item.id}>
                                  {item.english} | {item.arabic}
                                </option>
                              )}
                            </>
                          );
                        })}
                    </select> */}
										<div className="position-relative">
											<input type="text" name="editVariationAddSizeOptions" className="form-control form-select" autoComplete="off" id="editSizeInput" value={this.context.language === 'english' ? this.state.search_val_en : this.state.search_val_ar} onChange={this.handleTextChange} onBlur={this.handleSearchBlur} onFocus={this.handleSearchFocus} placeholder={productLanguage.SearchSelectsize} />
											<div className="opt-product-list start-0 end-0 opt-product-list-cust" id="pro-list">
												<ul>
													{
														this.state.SizeGroupSizes &&
														this.state.SizeGroupSizes?.filter((search) => this.context.language === 'english' ? (search.english.toLowerCase().includes(this.state.search_val_en)) : (search.english.toLowerCase().includes(this.state.search_val_ar)))?.length === 0 && (
															<li>There is no sizes.</li>
														)
													}
													{
														this.state.SizeGroupSizes &&
														this.state.SizeGroupSizes?.filter((search) => this.context.language === 'english' ? (search.english.toLowerCase().includes(this.state.search_val_en)) : (search.english.toLowerCase().includes(this.state.search_val_ar)))
															.map((item, i) => {
																return (
																	<>
																		<li key={i} id={item.id} onClick={() => this.handleClickSize(item.english, item.arabic, item.id)}>
																			{item.english} | {item.arabic}
																		</li>
																	</>
																)
															})
													}
												</ul>
											</div>
										</div>
										<span className="red-txt d-none" id="errorSize">This size already exist.</span>
									</div>
									<div className="col-md-4 form-group">
										<label>SKU</label>
										<input type="text" className="form-control input-custom-class" value={(this.props.productCode) + (this.state.skuCode) + (this.context.language === 'english' ? this.state.editVariationAddSize_en : this.state.editVariationAddSize_ar)} readOnly />
									</div>
									<div className="col-md-4 form-group">
										<label>{productLanguage.quantity}</label>

										<input type="number" name="editVariationAddSizeQuantity" value={this.state.editVariationAddSizeQuantity} onChange={this.handleNumberChange} className="form-control input-custom-class m-auto" placeholder="1" />
									</div>

									<div className="col-md-12 text-center">
										<button onClick={this.handleEditVariationAddProModalSubmit} className="red-btn">
											{productLanguage.submit}
										</button>
									</div>
								</div>
							</Modal.Body>
						</Modal>

						<Modal
							dialogClassName="modal-dialog-centered"
							className="edit-user-modal cust-modal"
							size="lg"
							ref={(el) => {
								this.dialog = el;
							}}
							show={this.state.editVariantShow}
							onHide={this.editVariantClose}
						>
							<Modal.Header>
								<Modal.Title>
									<h1 className="modal-title">Edit Quantity</h1>
								</Modal.Title>
								<button type="button" onClick={this.editVariantClose} className="close btn-close"></button>
							</Modal.Header>
							<Modal.Body>
								<div className="row">
									<div className="col-md-4 form-group">
										<label>{productLanguage.size}</label>
										<select name="editSizeOptions" id="" disabled value={this.state.editSize_en + " | " + this.state.editSize_ar} onChange={this.handleTextChange} className="form-select">
											<option>{this.state.editSize_en + '|' + this.state.editSize_ar}</option>
											{/* {this.state.SizeGroupSizes &&
                        this.state.SizeGroupSizes.map((item, i) => {
                          console.log(this.state.editSize_en, "===", item.english);
                          if (this.state.editSize_en === item.english) {
                            return <option key={i}>{item.english} | {item.arabic}</option>
                          }

                        })} */}
										</select>
									</div>
									<div className="col-md-4 form-group">
										<label>SKU</label>
										<input type="text" className="form-control input-custom-class" value={`${((this.props.productCode) + (this.state.skuCode) + (this.context.language === 'english' ? this.state.editSize_en : this.state.editSize_ar)).toUpperCase()}`} readOnly />
									</div>
									<div className="col-md-4 form-group">
										<label>Quantity</label>
										<input type="number" name="editSizeQuantity" value={this.state.editSizeQuantity} onChange={this.handleQuantityChange} className="form-control input-custom-class m-auto" placeholder="1" />
									</div>
									<div className="col-md-12 text-center">
										<button onClick={this.handleEditModalSubmit} className="red-btn">
											{productLanguage.submit}
										</button>
									</div>
								</div>
							</Modal.Body>
						</Modal>

						<Modal
							dialogClassName="modal-dialog-centered"
							className="edit-user-modal cust-modal"
							size="lg"
							ref={(el) => {
								this.dialog = el;
							}}
							show={this.state.editVariationSizeVariantShow}
							onHide={this.editvariationEditsizePopupClose}
						>
							<Modal.Header>
								<Modal.Title>
									<h1 className="modal-title">{productLanguage.SelectVariantInfo}</h1>
								</Modal.Title>
								<button type="button" onClick={this.editvariationEditsizePopupClose} className="close btn-close"></button>
							</Modal.Header>
							<Modal.Body>
								<div className="row">
									<div className="col-md-4 form-group">
										<label>{productLanguage.size}</label>
										<select name="editVariationEditSizeOptions" id="" disabled value={this.state.editVariationEditSize_en + " | " + this.state.editVariationEditSize_ar} onChange={this.handleTextChange} className="form-select">
											<option>{productLanguage.SelectSize}</option>
											{this.state.SizeGroupSizes &&
												this.state.SizeGroupSizes.map((item, i) => {
													return <option key={i}>{item.english} | {item.arabic}</option>;
												})}
										</select>
									</div>
									<div className="col-md-4 form-group">
										<label>SKU</label>
										<input type="text" className="form-control input-custom-class" value={`${((this.props.productCode) + (this.state.skuCode) + (this.context.language === 'english' ? this.state.editVariationEditSize_en : this.state.editVariationEditSize_ar)).toUpperCase()}`} readOnly />
									</div>

									<div className="col-md-4 form-group">
										<label>Quantity</label>
										<input type="number" name="editVariationEditSizeQuantity" value={this.state.editVariationEditSizeQuantity} onChange={this.handleQuantityChange} className="form-control input-custom-class m-auto" placeholder="1" />
									</div>
									<div className="col-md-12 text-center">
										<button onClick={this.handleEditVariationEditModalSubmit} className="red-btn">
											{productLanguage.submit}
										</button>
									</div>
								</div>
							</Modal.Body>
						</Modal>

						<Modal
							dialogClassName="modal-dialog-centered"
							className="edit-user-modal cust-modal bg-modal"
							size="xl"
							ref={(el) => {
								this.dialog = el;
							}}
							show={this.state.edit_var}
							onHide={this.edit_var_Close}
						>
							<Modal.Header>
								<Modal.Title>
									<h1 className="modal-title">{productLanguage.EditVariant}</h1>
								</Modal.Title>
								<button type="button" onClick={this.edit_var_Close} className="close btn-close"></button>
							</Modal.Header>
							<Modal.Body>
								<div className="row">
									<div className="col-md-12">
										<div className="white-box">
											<div className="row">
												<div className="col-lg-6 mb-lg-0 mb-3">
													<div className="row ">
														<div className="col-md-12">
															<div className="product-in-title d-flex align-items-center pb-3 custom-border-title">
																<span>{productLanguage.ProductImage}</span>
															</div>
														</div>
														<div className="col-md-12 mt-3">
															<div className="upload-file-section-new position-relative">
																<div className="file-selecter text-center position-relative h-auto">
																	<div className="file-area position-relative py-3">
																		<input type="file" name="productImage" id="SelectProductImage" onChange={this.handleEditImages} accept="image/*" multiple />
																		<div className="file-dummy">
																			<div className="file-upload-content mb-3">
																				<img className="file-dummy-image" src={dragimg} alt="" />
																			</div>
																			<span>
																				{productLanguage.DragDrop}
																				<bdi className="d-block">{productLanguage.or}</bdi>
																			</span>
																			<button className="btn red-btn mt-3">{productLanguage.BrowseFiles}</button>
																		</div>
																	</div>
																</div>
															</div>
															<div id="imageArrayError" style={{ display: "none" }} className="input-feedback text-danger">
																Required
															</div>
														</div>
														<div className="col-md-12">
															<span>{productLanguage.UploadedImageFile}</span>
															<div className="img-preview">
																<ul>
																	{this.state.editVariationImages !== "" && this.state.editVariationImages.length > 0 && (
																		<DragDropContext onDragEnd={this.onEditDragEnd}>
																			<Droppable droppableId="droppable" direction="horizontal">
																				{(provided, snapshot) => (
																					<div ref={provided.innerRef} style={getListStyle(snapshot.isDraggingOver, this.state.editVariationImages.length)} {...provided.droppableProps}>
																						{this.state.editVariationImages?.map((item, index) => (
																							<Draggable key={item.id} draggableId={item.id} index={index}>
																								{(provided, snapshot) => (
																									<div ref={provided.innerRef} {...provided.draggableProps} {...provided.dragHandleProps} style={getItemStyle(snapshot.isDragging, provided.draggableProps.style)}>
																										<li key={index}>
																											<div className="img-preview-main position-relative">
																												<img src={typeof item.image == 'object' ? URL.createObjectURL(item.image) : item.image} alt="" />
																												<div className="remove-img-btn">
																													<i
																														onClick={() => {
																															this.editVariationremoveImage(item.id);
																														}}
																														className="bi bi-x-circle-fill"
																													/>
																												</div>
																											</div>
																										</li>
																									</div>
																								)}
																							</Draggable>
																						))}
																						{provided.placeholder}
																					</div>
																				)}
																			</Droppable>
																		</DragDropContext>
																	)}
																</ul>
															</div>
														</div>
													</div>
												</div>
												<div className="col-lg-6 mb-lg-0 mb-3">
													<div className="row">
														<div className="col-md-12">
															<div className="product-in-title d-flex align-items-center pb-3 custom-border-title">
																<span>{productLanguage.VideoOptional}</span>
															</div>
														</div>
														<div className="col-md-12 mt-3">
															<div className="upload-file-section-new position-relative">
																<div className="file-selecter text-center position-relative h-auto">
																	<div className="file-area position-relative py-3">
																		<input type="file" name="licence_image_temp" onChange={this.handleEditVideoFile} accept="video/*" id="SelectProductVideoEdit" />
																		<div className="file-dummy">
																			<div className="file-upload-content mb-3">
																				<img className="file-dummy-image" src={dragimg} alt="" />
																			</div>
																			<span>
																				{productLanguage.DragDrop}
																				<bdi className="d-block">or</bdi>
																			</span>
																			<button className="btn red-btn mt-3">{productLanguage.UploadVideo}</button>
																		</div>
																	</div>
																</div>
															</div>
															<span>{productLanguage.UploadedVideoFile} (mp4, flv)</span>
														</div>
														<div className="col-md-12 mt-3">
															<span>{productLanguage.UploadedVideoFile}</span>
															<div className="video-preview">
																<ul>
																	{this.state.editVariationVideo.length > 0 && (
																		<li className="gray-bg-video d-flex align-items-center my-2">
																			<div className="video-thumb position-relative">
																				{/* <img src="" alt="" /> */}
																				<div className="video-icn-pro">
																					<img src={videoicn} alt="" />
																				</div>
																			</div>
																			<div className="vide-prev-txt ms-2">
																				<p className="mb-0">{this.state.editVariationVideo[0].name}</p>
																				<bdi>{parseFloat(this.state.editVariationVideo[0].size / 1024).toFixed(2)} kb</bdi>
																			</div>
																			<div className="ms-auto pe-2">
																				<i onClick={this.removeEditVideo} className="bi bi-x-circle-fill"></i>
																			</div>
																		</li>
																	)}
																</ul>
															</div>
														</div>
													</div>
												</div>
											</div>
											<div className="row">
												<div className="col-lg-6 mb-lg-0 mb-3">
													<div className="row">
														<div className="form-group col-md-12">
															<label>{productLanguage.selectColor}</label>
															<select className="form-select input-custom-class" name="editVariationColor" onChange={this.handleColorChange}>
																<option defaultValue>{productLanguage.selectColor}</option>
																{/* <option selected value="0">
                                  Multicolor | متعدد اللألوان
                                </option> */}
																{this.state.color &&
																	this.state.color.length > 0 &&
																	this.state.color?.map((item, i) => {
																		return item.id === this.state.editVariationColor ? (
																			<option key={i} selected value={item.id}>
																				{item.english} | {item.arabic}
																			</option>
																		) : (
																			<option key={i} value={item.id}>
																				{item.english} | {item.arabic}
																			</option>
																		);
																	})}
															</select>
															<span id="selectColor" style={{ display: "none" }} className="input-feedback text-danger">
																Required
															</span>
														</div>
														<div className="form-group col-md-12">
															<label>{productLanguage.PromotionEnglish}</label>
															<select className="form-select input-custom-class" name="editVariationPromotion" onChange={this.handlePromotionChange}>
																<option defaultValue>{productLanguage.selectPromotion}</option>
																{this.state.promotion &&
																	this.state.promotion.length > 0 &&
																	this.state.promotion.map((item, i) => {
																		return item.id === this.state.editVariationPromotion ? (
																			<option key={i} selected value={item.id}>
																				{item.english} | {item.arabic}
																			</option>
																		) : (
																			<option key={i} value={item.id}>
																				{item.english} | {item.arabic}
																			</option>
																		);
																	})}
															</select>
														</div>
														<div className="form-group col-md-12">
															<label>{productLanguage.Price}</label>
															<input type="number" className="input-custom-class form-control" name="editVariationPrice" value={this.state.editVariationPrice} onChange={this.handleEditPriceChange} placeholder="SR 200" />
															<span id="priceVariant" style={{ display: "none" }} className="input-feedback text-danger">
																Required
															</span>
														</div>
														<div className="form-group col-md-12">
															<label>{productLanguage.Discount}</label>
															<input type="number" className="input-custom-class form-control" name="editVariationDiscount" value={this.state.editVariationDiscount} onChange={this.handleEditDiscountChange} placeholder="10%" />
															<span id="discountVariant" style={{ display: "none" }} className="input-feedback text-danger">
																Required
															</span>
														</div>
														<div className="form-group col-md-12">
															<label>{productLanguage.realPrice}</label>
															<input type="number" className="input-custom-class form-control" name="editVariationRealPrice" value={this.state.editVariationRealPrice} onChange={this.handleEditRealPriceChange} placeholder="SR 100" />
															<span id="realpriceVariant" style={{ display: "none" }} className="input-feedback text-danger">
																Required
															</span>
														</div>
														<div className="form-group col-md-12">
															<label>{productLanguage.sizeGroup}</label>
															<select className="form-select input-custom-class" value={this.state.selectSize} name="selectsize" onChange={this.handleSizeChange}>
																<option value="0">{productLanguage.selectSize}</option>
																<option value="1">{productLanguage.international}</option>
																<option value="2">{productLanguage.numerical}</option>
																<option value="3">{productLanguage.ageWise}</option>
																<option value="4">{productLanguage.braSize}</option>
																<option value="5">{productLanguage.misc}</option>
															</select>
															<p className="input-feedback text-danger mt-3">{this.state.ErrMsg1}</p>
														</div>
													</div>
												</div>
												<div className="col-lg-6">
													<div className="row">
														<div className="col-md-12">
															<div className="product-in-title d-flex align-items-center">
																<span>{productLanguage.SelectVariantInfo}</span>
																<span id="variationSizeListError" style={{ display: "none" }} className="ms-2 input-feedback text-danger fs-6 fw-normal">
																	Required
																</span>
															</div>
														</div>
														<div className="col-md-12 mt-3">
															<div className="custom-table-product">
																<div className="table-responsive dataTables_wrapper no-footer">
																	<DragDropContext onDragEnd={this.onDragEndEditTable}>
																		<table className="fixed-height-set">
																			<thead>
																				<tr>
																					<th>{productLanguage.size}</th>
																					<th>SKU</th>
																					<th>{productLanguage.quantity}</th>
																					<th>{productLanguage.action}</th>
																					{/* <th>Sales</th> */}
																				</tr>
																			</thead>
																			{this.state.editVariationSizeList.length > 0 && (
																				<Droppable droppableId="droppable" direction="vertical">
																					{(provided) => (
																						<tbody {...provided.droppableProps} ref={provided.innerRef}>
																							{this.state.editVariationSizeList.map((item, index) => (
																								// console.log("-------------",item),
																								<Draggable key={item.id} draggableId={item.id} index={index}>
																									{(provided) => (
																										<tr ref={provided.innerRef} {...provided.draggableProps} {...provided.dragHandleProps}>
																											<td>{this.context.language === 'english' ? item.size_en : item.size_ar}</td>
																											<td>{item.sku}</td>
																											<td>{item.quantity}</td>
																											<td>
																												<Dropdown className="cust-drop">
																													<Dropdown.Toggle className="bg-transparent " id="dropdown-basic" align="end">
																														<svg xmlns="http://www.w3.org/2000/svg" width={16} height={16} fill="currentColor" className="bi bi-three-dots-vertical" viewBox="0 0 16 16">
																															<path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
																														</svg>
																													</Dropdown.Toggle>
																													<Dropdown.Menu>
																														<Dropdown.Item href="#" className="bi bi-pencil-square me-1" onClick={() => this.editVariationEditRow(item)}>
																															<span>Edit</span>
																														</Dropdown.Item>
																														<Dropdown.Item href="#" onClick={() => this.delete_record(item.sizeListId ? item.sizeListId : item.id)}>
																															<svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} fill="currentColor" className="bi bi-trash" viewBox="0 0 16 16">
																																<path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
																																<path fillRule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" />
																															</svg>
																															<span>Delete</span>
																														</Dropdown.Item>
																													</Dropdown.Menu>
																												</Dropdown>
																											</td>
																											{/* <td>
                                                        <button className="text-decoration-underline btn text-dark" onClick={() => this.delete_record(item.id)}>
                                                          <span>{ButtonLanguage.clear}</span>
                                                        </button>
                                                      </td> */}
																										</tr>
																									)}
																								</Draggable>
																							))}
																							{provided.placeholder}
																						</tbody>
																					)}
																				</Droppable>
																			)}
																			{this.state.selectSize <= "0" ? (
																				<div className="clear_btn cursor-pointer" onClick={() => this.setState({ ErrMsg: "Please select Size Group", ErrMsg1: "Required" })}>
																					+{productLanguage.Add}
																				</div>
																			) : (
																				<div className="clear_btn cursor-pointer " onClick={this.editVariationAddPro}>
																					+{productLanguage.Add}
																				</div>
																			)}
																			<p className="input-feedback text-danger mt-3">{this.state.ErrMsg}</p>
																		</table>
																	</DragDropContext>
																	<span id="variationSizeListError" style={{ display: "none" }} className="input-feedback text-danger">
																		Required
																	</span>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
											<div className="col-md-12 text-center">
												<div className="common-red-btn">
													<button onClick={this.updateVariation} className="btn red-btn">
														{ButtonLanguage.submit}{" "}
													</button>
												</div>
											</div>
										</div>
									</div>
								</div>
							</Modal.Body>
						</Modal>
					</div>
				</div>
			</React.Fragment >
		);
	}
}
