import React, { Component } from 'react';
import Select from "react-select";
import Adminlayout from '../../Components/AdminLayout/Adminlayout';


class AddNotification extends Component {

    constructor(props) {
        super(props);
        this.state = {
            selectedOption: '',
        }

    }
    options = [
        { value: "Summer", label: "Summer" },
        { value: "winter", label: "winter" },
        { value: "monsoon", label: "monsoon" },

    ];
    handleChanges = selectedOption => {
        this.setState({ selectedOption });
    };
    customStyles = {
        control: () => ({
            height: '50px',
            backgroundColor: '#F7F7F7',
            border: '1px solid #F7F7F7',
            borderRadius: '10px',
            fontSize: '16px',
            color: '#5E5E6C',
            marginBottom: '15px',
            display: 'flex',
        }),

        indicatorSeparator: () => ({
            backgroundColor: 'transparent'
        }),

        indicatorContainer: () => ({
            backgroundColor: '#000',
        })
    }
    render() {
        return (
            <Adminlayout>
                <div className="container-fluid">
                    <div className="row common-space">
                        <div className="col-sm-6 text-sm-start text-center">
                            <div className="common-header-txt">
                                <h3>Add Notifications</h3>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-md-12">
                            <div className="white-box">
                                <form className="row">
                                    <div className="form-group col-md-6">
                                        <label>Title</label>
                                        <input type="text" className="form-control input-custom-class" placeholder="Lorem ipsum is a dummy text" />
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>Title</label>
                                        <Select
                                            isMulti
                                            value={this.state.selectedOption}
                                            onChange={this.handleChanges}
                                            options={this.options}
                                            styles={this.customStyles}
                                        />
                                    </div>
                                    <div className="form-group col-md-12">
                                        <label>Description</label>
                                        <textarea rows="4" className="form-control input-custom-class h-auto" placeholder="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged."></textarea>
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>Destination</label>
                                        <input type="url" className="form-control input-custom-class" placeholder="https://libsimarkah.com/" />
                                        <div className="common-red-btn">
                                            <a href="#" className="btn red-btn">Send Now</a>
                                        </div>
                                    </div>
                                </form>
                                <form className="row mt-5">
                                    <div className="col-md-6 form-group add-notification">
                                        <h3>Schedule</h3>
                                        <label>Date & Time</label>
                                        <input type="datetime-local" className="form-control input-custom-class" />
                                        <div className="common-red-btn">
                                            <a href="#" className="btn red-btn">Sent</a>
                                        </div>

                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                    <div className="row common-space">
                        <div className="col-sm-12">
                            <div className="white-box">
                                <div className="add-notification">
                                    <h3>Setup an Alert</h3>
                                </div>
                                <form className="row">
                                    <div className="col-md-6 form-group  d-flex align-items-center mb-3">
                                        <label>Setup Alert?</label>
                                        <label className="switch pop-switch ms-5">
                                            <input type="checkbox" />
                                            <div className="slider round" />
                                            <span className="text" />
                                        </label>
                                    </div>

                                    <div className="col-md-6 d-flex  form-group mb-3">
                                        <label className="mb-0 me-5">Before</label>
                                        <div className="ms-5">
                                            <ul className="d-flex align-items-center flex-wrap">
                                                <li className="d-flex align-items-center me-3">

                                                    <label className="cust-radio add-noti">
                                                        <input type="radio" name="radio" />
                                                        <span className="checkmark" />
                                                    </label>
                                                    <span>Daily</span>
                                                </li>
                                                <li className="d-flex align-items-center me-3">

                                                    <label className="cust-radio add-noti">
                                                        <input type="radio" name="radio" />
                                                        <span className="checkmark" />
                                                    </label>
                                                    <span>Weeks</span>
                                                </li>
                                                <li className="d-flex align-items-center">

                                                    <label className="cust-radio add-noti">
                                                        <input type="radio" name="radio" />
                                                        <span className="checkmark" />
                                                    </label>
                                                    <span>Months</span>
                                                </li>
                                            </ul>

                                        </div>
                                    </div>
                                    <div className="col-md-6 d-flex align-items-center form-group mb-3 ">
                                        <label className="me-4">Recurrence</label>
                                        <div className="ms-5">
                                            <ul className="d-flex align-items-center flex-wrap">
                                                <li className="d-flex align-items-center me-3">
                                                    <div className="cust-checkbox-new">
                                                        <label className="cust-chk-bx">
                                                            <input type="checkbox" />
                                                            <span className="cust-chkmark" />
                                                            Daily
                                                        </label>
                                                    </div>

                                                </li>
                                                <li className="d-flex align-items-center me-3">
                                                    <div className="cust-checkbox-new">
                                                        <label className="cust-chk-bx">
                                                            <input type="checkbox" />
                                                            <span className="cust-chkmark" />
                                                            Weekly
                                                        </label>
                                                    </div>
                                                </li>
                                                <li className="d-flex align-items-center me-3">
                                                    <div className="cust-checkbox-new">
                                                        <label className="cust-chk-bx">
                                                            <input type="checkbox" />
                                                            <span className="cust-chkmark" />
                                                            Monthly
                                                        </label>
                                                    </div>
                                                </li>
                                                <li className="d-flex align-items-center me-3">
                                                    <div className="cust-checkbox-new">
                                                        <label className="cust-chk-bx">
                                                            <input type="checkbox" />
                                                            <span className="cust-chkmark" />
                                                            Annually
                                                        </label>
                                                    </div>
                                                </li>

                                            </ul>

                                        </div>
                                    </div>
                                    <div className="col-md-6 form-group  d-flex align-items-center mb-3">
                                        <label>Email Reminder?</label>
                                        <label className="switch pop-switch ms-5">
                                            <input type="checkbox" />
                                            <div className="slider round" />
                                            <span className="text" />
                                        </label>
                                    </div>
                                    <div className="col-md-6 form-group ">
                                        <label>Number of date of reminder?</label>
                                        <input type="datetime-local" className="form-control input-custom-class" defaultValue="13-10-2021" />
                                    </div>
                                    <div className="col-md-6 form-group ">
                                        <label>Email ID</label>
                                        <input type="email" className="form-control input-custom-class" placeholder="Enter Email address" />
                                    </div>
                                    <div className="col-md-12">
                                        <div className="common-red-btn">
                                            <a href="#" className="btn red-btn">Set Alert</a>
                                        </div>

                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </Adminlayout>
        );
    }
}

export default AddNotification;