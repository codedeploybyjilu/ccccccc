import moment from 'moment';
import React, { Component } from 'react'
import Barcode from "react-barcode";
import { API_Path } from '../../const';
import LanguageContext from '../../contexts/languageContext';
import { PostApi } from '../../helper/APIService';
import html2pdf from 'html2pdf.js';
import ReactToPrint from 'react-to-print';

export class OrderDetailsPrint extends Component {
    static contextType = LanguageContext
    constructor(props) {
        super(props)
        this.state = {
            barcodeoption: {
                width: 2,
                font: "Poppins",
                rodchanges: null,
            },
            barcode: "",
            orderItem: [],
            detailData: {},
            p_pieces: ''
        }
    }

    componentDidMount() {
        let id = window.location.href?.split('/')[window.location.href?.split('/')?.length - 1]
        this.getOrderDetailData(id);
    }

    getOrderDetailData = (id) => {
        let data = {
            id: id,
        };
        const getDetailDataPromise = new Promise((resolve) => {
            resolve(PostApi(API_Path.getOrderById, data));
        });
        getDetailDataPromise.then((response) => {
            if (response) {
                const data = response.data.data;
                this.setState({
                    detailData: data[0],
                    barcode: data[0]?.id,
                    orderItem: data[0]?.order_item,
                }, () => {
                    const product = data[0].order_item.filter((item) => {
                        if (item.status == 0 && item.quantity !== 0) {
                            return item;
                        }
                    });
                    let pices = product.reduce((a, b) => a = a + b.quantity, 0)
                    this.setState({ p_pieces: pices }, () => {
                    })
                });
            }
        });
    };

    handleOrderPrint = () => {

    }

    goBack = () => {
        window.history.go(-1)
    }

    render() {
        return (
            <>
                <div className='content-wrapper-section m-0 p-0'>
                    <div className='pdf-data-box print-fix-width-class'>

                        <div className='py-3 d-flex justify-content-between align-items-center'>
                            {/* <a onClick={this.goBack}>
                                <i className="bi bi-arrow-left fs-4" />
                            </a> */}
                            <ReactToPrint
                                trigger={() => {
                                    // NOTE: could just as easily return <SomeComponent />. Do NOT pass an `onClick` prop
                                    // to the root node of the returned component as it will be overwritten.
                                    return <button className="btn red-btn px-5">Print</button>;
                                }}
                                content={() => this.componentRef}
                            />
                        </div>
                        <div className='white-pdf-box' ref={el => (this.componentRef = el)}>
                            <div className=''>
                                <div>
                                    <div className='product-title-main d-flex align-items-center'>
                                        <span>Product list ({this.state.p_pieces} Pieces)</span>
                                        <bdi className='ms-auto'>{moment(this.state.detailData?.createdat).format('DD/MM/YYYY hh:mm a')}</bdi>
                                    </div>
                                </div>
                                <div className='text-center my-3'>
                                    <div className='barcode-box'>
                                        <Barcode value={this.state.barcode} option={this.state.barcodeoption} />
                                    </div>
                                </div>
                            </div>
                            <div className=''>
                                {
                                    this.state.orderItem?.length > 0 &&
                                    this.state.orderItem?.map((item) => {
                                        console.log(item, "item");
                                        return (
                                            <>
                                                {
                                                    item.quantity !== 0 && (
                                                        <div className='product-list-main-div mt-3'>
                                                            <div className='d-flex'>
                                                                <div className='w-50'>
                                                                    <div className='product-img-div'>
                                                                        <img src={item.image?.split(',')[0]} alt="" className="" />
                                                                    </div>
                                                                </div>
                                                                <div className="w-50 product-pize-div">

                                                                    <div className="prize-product">
                                                                        <ul className="mt-2">
                                                                            <li>
                                                                                <div className="product-title-list">
                                                                                    <span>{this.context.language === 'english' ? item.title_en : item.title_ar}</span>
                                                                                </div>
                                                                            </li>
                                                                            <li className='barcode-txt'>
                                                                                <span>Barcode: <span className="mx-1">{item.barcode}</span></span>
                                                                            </li>
                                                                            <li>
                                                                                <span>Size: <span className="mx-1">{this.context.language === 'english' ? item.size_en : item.size_ar}</span></span>
                                                                            </li>
                                                                            {
                                                                                item.color_en !== null && (
                                                                                    <li>
                                                                                        <span>Color: <span className="mx-1">{this.context.language === 'english' ? item.color_en : item.color_ar}</span></span>
                                                                                    </li>
                                                                                )
                                                                            }
                                                                            <li>
                                                                                <div className="quality-div">
                                                                                    <span className='d-block'>Qty: {item.quantity}</span>
                                                                                </div>
                                                                            </li>
                                                                            <li className='mt-2'>
                                                                                <span className='fs-6 fw-bold'>{item.total_discounted_price?.toFixed(2)} </span><bdi style={{ fontSize: '13px' }}>SR</bdi>
                                                                                {item.discount !== 0 && <span className="text-secondary text-decoration-line-through ms-2">{item.product_price?.toFixed(2)}</span>}
                                                                            </li>
                                                                        </ul>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    )
                                                }
                                            </>
                                        )
                                    })
                                }

                            </div>
                        </div>
                    </div>
                </div>
            </>
        )
    }
}

export default OrderDetailsPrint