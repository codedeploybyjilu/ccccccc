import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import { Dropdown } from "react-bootstrap";
import LanguageContext from "../../contexts/languageContext";
import DataTable from "../../Components/DataTable";
import { textFilter } from "react-bootstrap-table2-filter";
import {
  // APIBaseUrl,
  API_Path,
  // buttonArabic,
  // buttonEnglish,
  // SidebarArabic,
  sizeGuidelinesArabic,
  sizeGuidelinesEnglish,
  // SidebarEnglish,
  // TableFieldArabic,
  // TableFieldEnglish,
  titleArabic,
  titleEnglish,
  // LIVE_FILE_URL,
} from "../../const";
import { confirmAlert } from "react-confirm-alert";
import toastr from "toastr";
// import sizeimg from "../../images/size-img.png";
import { PostApi } from "../../helper/APIService";
import { Link, withRouter } from "react-router-dom";

class sizeguidelines extends Component {
  static contextType = LanguageContext;

  constructor(props) {
    super(props);
    this.state = {
      page: 1,
      sizePerPage: 10,
      totalSize: 100,
      defaultSorted: [
        {
          dataField: "id",
          order: "asc",
        },
      ],

      order_data: [],
    };
  }

  componentDidMount() {
    this.getGuideData();
  }

  get_order_data = () => { };

  getGuideData = () => {
    let path = API_Path.getSizeGuideLine;
    let data = {};
    const addSizeGuidePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    addSizeGuidePromise.then((res) => {
      if (res) {
        if (res.data.success) {
          this.setState({ order_data: res.data.data });
        }
      }
    });
  };

  cloneData = (id) => {
    let path = API_Path.cloneSizeGuideLine;
    let data = { id: id };
    const addSizeGuidePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    addSizeGuidePromise.then((res) => {
      if (res) {
        toastr.success(res.data.message);
        this.getGuideData();
      }
    });
  };

  // editSizeGuideLine = (id) => {
  //   // console.log('props P:: ', this.props.history.push('editsizeguideline/' + id));
  //   // this.props.history.push("editsizeguideline/" + id);
  //   window.location.href = 'editsizeguideline/' + id
  // };

  delete_record = (id) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>Are you sure?</h1>
            <p>You want to delete this file?</p>
            <button className="btn red-btn me-2" onClick={onClose}>
              No
            </button>
            <button
              className="btn red-btn"
              onClick={() => {
                this.finaly_delete_record(id);
                onClose();
              }}
            >
              Yes, Delete it!
            </button>
          </div>
        );
      },
    });
  };

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  finaly_delete_record = (id) => {
    let path = API_Path.deleteSizeGuideLine;
    let data = {
      id: id,
    };
    const addSizeGuidePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    addSizeGuidePromise.then((res) => {
      if (res) {
        toastr.success(res.data.message);
        this.getGuideData();
      }
    });
  };
  handleTableChange = (
    type,
    { page, sizePerPage, filters, sortField, sortOrder }
  ) => {
    switch (type) {
      case "pagination":
        this.setState(
          {
            page,
            sizePerPage,
          },
          () => this.getGuideData()
        );
        break;
      case "filter":
        let search_val = this.state.search_val;
        let newFilter = {};
        if (Object.keys(filters).length) {
          for (const dataField in filters) {
            newFilter[dataField] = filters[dataField].filterVal;
          }
          newFilter = {
            ...search_val,
            ...newFilter,
          };
        } else {
          newFilter = {
            title: "",
            indicator: "",
            definition: "",
          };
        }
        this.setState(
          {
            search_val: newFilter,
          },
          () => this.getGuideData()
        );
        break;
      case "sort":
        this.setState(
          {
            defaultSorted: [
              {
                dataField: sortField,
                order: sortOrder,
              },
            ],
          },
          () => this.getGuideData()
        );
        break;
      default:
        break;
    }
    return true;
  };
  render() {
    // let Language =
    //   this.context.language === "english"
    //     ? TableFieldEnglish
    //     : TableFieldArabic;
    // let buttonLanguage =
    //   this.context.language === "english" ? buttonEnglish : buttonArabic;
    let titleLanguage =
      this.context.language === "english" ? titleEnglish : titleArabic;
    let sizeGuidelinesLanguage =
      this.context.language === "english"
        ? sizeGuidelinesEnglish
        : sizeGuidelinesArabic;
    const columns = [
      {
        dataField: "id",
        text: "Id",
        hidden: true,
      },
      {
        dataField: "size_guide_img",
        text: sizeGuidelinesLanguage.illustration,
        sort: true,
        hidden: false,
        formatter: (cell, row, rowIndex) => {
          return (
            <React.Fragment>
              <img
                className="imgWidth"
                src={row.size_guide_img}
                alt=""
              />
            </React.Fragment>
          );
        },
      },
      {
        dataField: "size_guide_number",
        text: sizeGuidelinesLanguage.guideNumber,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: titleLanguage.search,
        }),
      },
      {
        dataField: "size_guide_name_english",
        text: sizeGuidelinesLanguage.guideName,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: titleLanguage.search,
        }),
      },
      {
        dataField: "action",
        text: sizeGuidelinesLanguage.action,
        hidden: false,
        csvExport: false,
        headerClasses: "text-center",
        classes: "text-center",
        formatter: (cell, row, rowIndex) => {
          return (
            <React.Fragment>
              <Dropdown className="cust-drop">
                <Dropdown.Toggle
                  className="bg-transparent "
                  id="dropdown-basic"
                  align="end"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width={16}
                    height={16}
                    fill="currentColor"
                    className="bi bi-three-dots-vertical"
                    viewBox="0 0 16 16"
                  >
                    <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                  </svg>
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  <Dropdown.Item
                    href={"editsizeguideline/" + row.id}
                  // onClick={() => this.editSizeGuideLine(row.id)}
                  >
                    <svg
                      width={19}
                      height={18}
                      viewBox="0 0 19 19"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
                        fill="#2D2D3B"
                      />
                    </svg>
                    <span>{sizeGuidelinesLanguage.Edit}</span>
                  </Dropdown.Item>
                  <Dropdown.Item
                    href="#"
                    onClick={() => this.delete_record(row.id)}
                  >
                    <svg
                      width={18}
                      height={20}
                      viewBox="0 0 18 20"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
                        fill="#2D2D3B"
                      />
                    </svg>
                    <span>{sizeGuidelinesLanguage.Delete}</span>
                  </Dropdown.Item>
                  <Dropdown.Item onClick={() => this.cloneData(row.id)}>
                    <svg
                      width={20}
                      height={20}
                      viewBox="0 0 18 18"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M10.6665 17.3333H2.33317C1.88656 17.3488 1.45356 17.1782 1.13757 16.8622C0.821587 16.5462 0.650981 16.1132 0.666501 15.6666V7.33329C0.650981 6.88669 0.821587 6.45369 1.13757 6.1377C1.45356 5.82171 1.88656 5.6511 2.33317 5.66662H5.6665V2.33329C5.65098 1.88669 5.82159 1.45368 6.13758 1.1377C6.45356 0.821709 6.88656 0.651103 7.33317 0.666623H15.6665C16.1131 0.651103 16.5461 0.821709 16.8621 1.1377C17.1781 1.45368 17.3487 1.88669 17.3332 2.33329V10.6666C17.3484 11.1132 17.1778 11.546 16.8618 11.8619C16.5459 12.1779 16.113 12.3486 15.6665 12.3333H12.3332V15.6666C12.3484 16.1132 12.1778 16.546 11.8618 16.8619C11.5459 17.1779 11.113 17.3486 10.6665 17.3333ZM2.33317 7.33329V15.6666H10.6665V12.3333H7.33317C6.88663 12.3486 6.45378 12.1779 6.13785 11.8619C5.82192 11.546 5.65123 11.1132 5.6665 10.6666V7.33329H2.33317ZM7.33317 2.33329V10.6666H15.6665V2.33329H7.33317Z"
                        fill="#2D2D3B"
                      />
                    </svg>

                    <span>{sizeGuidelinesLanguage.Clone}</span>
                  </Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </React.Fragment>
          );
        },
      },
    ];
    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space align-items-center">
            <div className="col-sm-6 text-sm-start text-center rtl-txt-start">
              <div className="common-header-txt">
                <h3>{sizeGuidelinesLanguage.sizeGuidelines}</h3>
              </div>
            </div>
            <div className="col-sm-6 text-sm-end text-center rtl-txt-end">
              <div className="common-red-btn">
                <Link to={"addsizeguideline"}>
                  <a className="btn red-btn">
                    {sizeGuidelinesLanguage.addSizeGuideline}
                  </a>
                </Link>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-md-12 pt-3">
              <div className="white-box">
                <div className="custom-table">
                  <div className="table-responsive dataTables_wrapper no-footer">
                    {this.state.order_data && (
                      <DataTable
                        keyField="id"
                        loading={this.state.loading}
                        columns={columns}
                        data={this.state.order_data}
                        page={this.state.page}
                        sizePerPage={this.state.sizePerPage}
                        totalSize={this.state.totalSize}
                        defaultSorted={this.state.defaultSorted}
                        onTableChange={this.handleTableChange}
                        language={this.context.language}
                        selectableRows
                      />
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Adminlayout>
    );
  }
}

export default withRouter(sizeguidelines);
