import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import {
  buttonArabic,
  buttonEnglish,
  ReportEnglish,
  ReportArabic,
  SidebarArabic,
  SidebarEnglish,
  TableFieldArabic,
  TableFieldEnglish,
  titleArabic,
  titleEnglish,
} from "../../const";
import { confirmAlert } from "react-confirm-alert";
import LanguageContext from "../../contexts/languageContext";

import productimg from "../../images/product-img.png";
import { textFilter } from "react-bootstrap-table2-filter";
import DataTable from "../../Components/DataTable";

import { Tabs, Tab } from "react-bootstrap";

class Reports extends Component {
  static contextType = LanguageContext;

  constructor(props) {
    super(props);
    this.state = {
      page: 1,
      sizePerPage: 10,
      totalSize: 100,
      defaultSorted: [
        {
          dataField: "id",
          order: "asc",
        },
      ],

      order_data: [
        {
          id: 1,
          itemcode: "12345",
          productname: "Black top",
          category: "Kids",
          subcategory: "Top",
          price: "$500",
          sales: "50",
          date: "30 Apr 12:30 pm",
        },
        {
          id: 2,
          itemcode: "12345",
          productname: "Black top",
          category: "Kids",
          subcategory: "Top",
          price: "$500",
          sales: "50",
          date: "30 Apr 12:30 pm",
        },
        {
          id: 3,
          itemcode: "12345",
          productname: "Black top",
          category: "Kids",
          subcategory: "Top",
          price: "$500",
          sales: "50",
          date: "30 Apr 12:30 pm",
        },
        {
          id: 4,
          itemcode: "12345",
          productname: "Black top",
          category: "Kids",
          subcategory: "Top",
          price: "$500",
          sales: "50",
          date: "30 Apr 12:30 pm",
        },
        {
          id: 5,
          itemcode: "12345",
          productname: "Black top",
          category: "Kids",
          subcategory: "Top",
          price: "$500",
          sales: "50",
          date: "30 Apr 12:30 pm",
        },
        {
          id: 6,
          itemcode: "12345",
          productname: "Black top",
          category: "Kids",
          subcategory: "Top",
          price: "$500",
          sales: "50",
          date: "30 Apr 12:30 pm",
        },
        {
          id: 7,
          itemcode: "12345",
          productname: "Black top",
          category: "Kids",
          subcategory: "Top",
          price: "$500",
          sales: "50",
          date: "30 Apr 12:30 pm",
        },
        {
          id: 8,
          itemcode: "12345",
          productname: "Black top",
          category: "Kids",
          subcategory: "Top",
          price: "$500",
          sales: "50",
          date: "30 Apr 12:30 pm",
        },
        {
          id: 9,
          itemcode: "12345",
          productname: "Black top",
          category: "Kids",
          subcategory: "Top",
          price: "$500",
          sales: "50",
          date: "30 Apr 12:30 pm",
        },
        {
          id: 10,
          itemcode: "12345",
          productname: "Black top",
          category: "Kids",
          subcategory: "Top",
          price: "$500",
          sales: "50",
          date: "30 Apr 12:30 pm",
        },
      ],
    };
  }
  handleTableChange = (
    type,
    { page, sizePerPage, filters, sortField, sortOrder }
  ) => {
    switch (type) {
      case "pagination":
        this.setState(
          {
            page,
            sizePerPage,
          },
          () => this.get_order_data()
        );
        break;
      case "filter":
        let search_val = this.state.search_val;
        let newFilter = {};
        if (Object.keys(filters).length) {
          for (const dataField in filters) {
            newFilter[dataField] = filters[dataField].filterVal;
          }
          newFilter = {
            ...search_val,
            ...newFilter,
          };
        } else {
          newFilter = {
            title: "",
            indicator: "",
            definition: "",
          };
        }
        this.setState(
          {
            search_val: newFilter,
          },
          () => this.get_order_data()
        );
        break;
      case "sort":
        this.setState(
          {
            defaultSorted: [
              {
                dataField: sortField,
                order: sortOrder,
              },
            ],
          },
          () => this.get_order_data()
        );
        break;
      default:
        break;
    }
    return true;
  };
  delete_record = (id) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>Are you sure?</h1>
            <p>You want to delete this file?</p>
            <button className="btn red-btn me-2" onClick={onClose}>
              No
            </button>
            <button
              className="btn red-btn"
              onClick={() => {
                this.finaly_delete_record(id);
                onClose();
              }}
            >
              Yes, Delete it!
            </button>
          </div>
        );
      },
    });
  };
  get_order_data = () => { };
  render() {
    let Language =
      this.context.language === "english"
        ? TableFieldEnglish
        : TableFieldArabic;
    let ButtonLanguage =
      this.context.language === "english" ? buttonEnglish : buttonArabic;
    let titleLanguage =
      this.context.language === "english" ? titleEnglish : titleArabic;
    let ReportLanguage =
      this.context.language === "english" ? ReportEnglish : ReportArabic;
    const columns = [
      {
        dataField: "id",
        text: "Id",
        hidden: true,
      },
      {
        dataField: "photo",
        text: ReportLanguage.Photo,
        sort: true,
        hidden: false,
        formatter: (cell, row, rowIndex) => {
          return (
            <React.Fragment>
              <img src={productimg} alt="" />
            </React.Fragment>
          );
        },
      },
      {
        dataField: "itemcode",
        text: ReportLanguage.ItemCode,
        sort: true,
        hidden: false,
      },
      {
        dataField: "productname",
        text: ReportLanguage.ProductName,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: ReportLanguage.search,
        }),
      },
      {
        dataField: "category",
        text: ReportLanguage.Category,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: ReportLanguage.search,
        }),
      },

      {
        dataField: "subcategory",
        text: ReportLanguage.SubCategory,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: ReportLanguage.search,
        }),
      },
      {
        dataField: "price",
        text: ReportLanguage.Price,
        sort: true,
        hidden: false,
      },
      {
        dataField: "sales",
        text: ReportLanguage.Sales,
        sort: true,
        hidden: false,
      },

      {
        dataField: "date",
        text: ReportLanguage.Date,
        sort: true,
        hidden: false,
      },
    ];

    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space align-items-center">
            <div className="col-6  text-start rtl-txt-start">
              <div className="common-header-txt">
                <h3>{ReportLanguage.Reports}</h3>
              </div>
            </div>
            <div className="col-6  text-end rtl-txt-end">
              <div className="common-red-btn">
                <a href="#" className="btn red-btn">
                  {ReportLanguage.Export}
                </a>
              </div>
            </div>
          </div>
          <div className="row mt-2">
            <div className="col-md-12 m-auto">
              <Tabs
                defaultActiveKey="profile"
                transition={false}
                id="noanim-tab-example"
                className="mb-3 cust-tab-report"
              >
                <Tab eventKey="home" title={ReportLanguage.Delivered}>
                  1
                </Tab>
                <Tab eventKey="profile" title={ReportLanguage.NotDelivered}>
                  <div className="row mt-3">
                    <div className="col-md-12">
                      <div className="white-box">
                        <div className="custom-table">
                          <div className="table-responsive dataTables_wrapper no-footer">
                            {this.state.order_data && (
                              <DataTable
                                keyField="id"
                                loading={this.state.loading}
                                columns={columns}
                                data={this.state.order_data}
                                page={this.state.page}
                                sizePerPage={this.state.sizePerPage}
                                totalSize={this.state.totalSize}
                                defaultSorted={this.state.defaultSorted}
                                onTableChange={this.handleTableChange}
                                language={this.context.language}
                                selectableRows
                              />
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </Tab>
                <Tab eventKey="contact" title={ReportLanguage.Returned}>
                  3
                </Tab>
              </Tabs>
            </div>
          </div>
        </div>
      </Adminlayout>
    );
  }
}

export default Reports;
