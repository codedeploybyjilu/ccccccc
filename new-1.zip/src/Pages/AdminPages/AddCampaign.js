import React, { Component } from 'react';
import Adminlayout from '../../Components/AdminLayout/Adminlayout';
import { Tab, Tabs } from 'react-bootstrap';
import PlaceholderImage from "../../images/login-banner.jpg";
import PhoneImage from "../../images/iphone-image.png";
import PhoneSmall from "../../images/image-small.png";
import PlusImage from "../../images/plus-icon.svg";

class AddCampaign extends Component {

    handleClassChange = () => {
        document.getElementById("mobile-viw").classList.toggle("active");
    };

    render() {
        return (
            <Adminlayout>
                <div className="container-fluid">
                    <div className="row common-space">
                        <div className="col-12 text-sm-start text-center rtl-txt-start">
                            <div className="common-header-txt">
                                <h3>
                                    <a href='/campaign'>
                                        <svg className='me-2' width="16" height="12" viewBox="0 0 16 12" fill="none"><path d="M3.83 5L7.41 1.41L6 0L0 6L6 12L7.41 10.59L3.83 7H16V5H3.83Z" fill="#2d2d3b"></path></svg>
                                    </a>
                                    Create Campaign
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div className='row common-space'>
                        <div className='col-xxl-9 mx-auto mb-4'>
                            <div className='white-box'>
                                <div className="tabs-campn-info-main">
                                    <div className="tabs-campn-info-hdr d-flex align-items-center justify-content-center">
                                        <svg className="me-2" width="24" height="24" viewBox="0 0 26 21" fill="none" >
                                            <path d="M17.3793 20.9999H1.93103C0.864553 20.9999 0 20.1354 0 19.0689V5.55164C0 4.48516 0.864553 3.62061 1.93103 3.62061H17.3793C18.4458 3.62061 19.3103 4.48516 19.3103 5.55164V19.0689C19.3103 20.1354 18.4458 20.9999 17.3793 20.9999ZM1.93103 7.48267V19.0689H17.3793V7.48267H1.93103Z" fill="#2d2d3b" />
                                            <circle cx="19.3104" cy="6.03448" r="4.82759" fill="#2d2d3b" stroke="white" strokeWidth="2.41379" />
                                        </svg>
                                        Push Notification
                                    </div>
                                    <div className="tabs-campn-info-inr">
                                        <div className="row me-0">
                                            <div className="col-lg-8 col-md-7 pe-0">
                                                <div className="cust-campaign-accrds">
                                                    <div className="cust-push-noti-form">
                                                        <div className="cust-form-main-wrapper">
                                                            <div className="cust-from-body">
                                                                <label className="lbl-frnt-side">Type</label>
                                                                <form>
                                                                    <div className="tabs-prd-clt-new-all">
                                                                        <Tabs defaultActiveKey="product" transition={false}>
                                                                            <Tab eventKey="product" title="Product" name="product-tab">
                                                                                <div className="col-12 custom-dropdown-select">
                                                                                    <select class="form-select input-custom-class" id="">
                                                                                        <option selected>Choose...</option>
                                                                                        <option value="1">One</option>
                                                                                        <option value="2">Two</option>
                                                                                        <option value="3">Three</option>
                                                                                    </select>
                                                                                </div>
                                                                            </Tab>
                                                                            <Tab eventKey="collection" title="Collection" name="collection-tab">
                                                                                <div className="col-12 custom-dropdown-select">
                                                                                    <select class="form-select input-custom-class" id="">
                                                                                        <option selected>Choose...</option>
                                                                                        <option value="1">One</option>
                                                                                        <option value="2">Two</option>
                                                                                        <option value="3">Three</option>
                                                                                    </select>
                                                                                </div>
                                                                            </Tab>
                                                                            <Tab eventKey="abandonedCart" title="Abandoned cart" name="cart-tab">
                                                                                <div className="col-12">
                                                                                    <label className="lbl-frnt-side">Abandoned cart</label>
                                                                                </div>
                                                                            </Tab>
                                                                            <Tab eventKey="url" title="URL" name="url-tab">
                                                                                <div className="col-12">
                                                                                    <label className="lbl-frnt-side">URL</label>
                                                                                    <div className="custom-dropdown-select mb-3">
                                                                                        <input type="url" className="form-control input-custom-class" placeholder="Enter Web URL" name="weburl" autoComplete="off" />
                                                                                        <div className="cust-checkbox-new d-inline-block pt-1">
                                                                                            <label className="cust-chk-bx">
                                                                                                <input type="checkbox" id="" name="" />
                                                                                                <span className="cust-chkmark"></span>
                                                                                                Open outside the app
                                                                                            </label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </Tab>
                                                                            <Tab eventKey="page" title="Page" name="page-tab">
                                                                                <div className="col-12">
                                                                                    <label className="lbl-frnt-side">Page</label>
                                                                                    <div className="custom-dropdown-select mb-3">
                                                                                        <select class="form-select input-custom-class" id="">
                                                                                            <option selected>Choose...</option>
                                                                                            <option value="1">One</option>
                                                                                            <option value="2">Two</option>
                                                                                            <option value="3">Three</option>
                                                                                        </select>
                                                                                    </div>
                                                                                </div>
                                                                            </Tab>
                                                                        </Tabs>
                                                                    </div>
                                                                    <div id="image-input" className="bdr-row-class-choose mb-3 ">
                                                                        <div className="row me-0">
                                                                            <div className="col-lg-3 col-sm-6 pe-0 mb-2">
                                                                                <div className="bdr-row-class-choose-image">
                                                                                    <div className="upload-file-dash-new position-relative mx-auto h-100">
                                                                                        <div className="file-selecter text-center position-relative h-100 bg-white border-0">
                                                                                            <div className="file-area position-relative">
                                                                                                <input type="file" accept="image/jpg,image/gif,image/png,image/jpeg,image/webp" />
                                                                                                <div className="file-dummy p-3">
                                                                                                    <div className="file-upload-content" style={{ overflow: "hidden" }}>
                                                                                                        <img src={PlusImage} alt="" />
                                                                                                    </div>
                                                                                                    <bdi className="d-block pt-2">Upload Image</bdi>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <span style={{ display: "none" }} id="img-error" className="error text-danger">
                                                                                        Please select an image
                                                                                    </span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                        <div className="cust-form-main-wrapper">
                                                            <div className="cust-from-body">
                                                                {/* <div className="form-group mb-3 count-number-info">
                                                                    <label className="lbl-frnt-side">Discount</label>
                                                                    <div className="position-relative">
                                                                        <input name="maxDiscount" type="number" inputMode="numeric" className="form-control input-custom-class" placeholder="Please enter maximum discount percentage you would like to offer." />
                                                                        <span className="count-number-fix position-absolute d-flex align-items-center">
                                                                            <bdi>%</bdi>
                                                                        </span>
                                                                    </div>
                                                                    <span style={{ display: "none" }} id="discount-error" className="error text-danger">
                                                                        Please Enter a discount
                                                                    </span>
                                                                </div> */}
                                                                <div className="form-group mb-3 count-number-info">
                                                                    <label className="lbl-frnt-side">Title </label>
                                                                    <div className="position-relative">
                                                                        <input maxLength="65" name="title" type="text" className="form-control input-custom-class" placeholder="" />
                                                                        <span className="count-number-fix position-absolute d-flex align-items-center">
                                                                            <bdi>1</bdi>/65
                                                                        </span>
                                                                    </div>
                                                                    <span style={{ display: "none" }} id="title-error" className="error text-danger">
                                                                        Please Enter a title
                                                                    </span>
                                                                </div>
                                                                <div className="form-group mb-3 count-number-info">
                                                                    <label className="lbl-frnt-side">Description</label>
                                                                    <div className="position-relative">
                                                                        <textarea className="form-control input-custom-class h-auto" maxLength="178" rows="6" name="description" placeholder='Enter Description' />
                                                                        <span className="count-number-fix position-absolute d-flex align-items-end">
                                                                            <bdi>1</bdi>/178
                                                                        </span>
                                                                    </div>
                                                                    <span style={{ display: "none" }} id="description-error" className="error text-danger">
                                                                        Please Enter a description
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="cust-form-main-wrapper">
                                                            <div className="cust-from-body">
                                                                <div className="form-group mb-3">
                                                                    <label className="lbl-frnt-side">Audience</label>
                                                                    <div className="custom-dropdown-select">
                                                                        <select class="form-select input-custom-class" id="">
                                                                            <option selected>Choose...</option>
                                                                            <option value="1">One</option>
                                                                            <option value="2">Two</option>
                                                                            <option value="3">Three</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="cust-form-main-wrapper">
                                                            <div className="cust-from-body " id="schedule-radio">
                                                                <div className="d-flex align-items-center switch-toggle-info mb-3">
                                                                    <div className="switch-toggle-info-left">
                                                                        <span className="d-block">Now Your Push?</span>
                                                                        <bdi className="d-block">Sending your push now</bdi>
                                                                    </div>
                                                                    <div className="ms-auto">
                                                                        <div className="form-check form-switch">
                                                                            <input className="form-check-input" name="sheduleNotification" defaultChecked type="radio" value="now" role="switch" id="Now" />
                                                                            <label className="form-check-label" htmlFor="Now" />
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div>
                                                                    <div className="d-flex align-items-center switch-toggle-info">
                                                                        <div className="switch-toggle-info-left">
                                                                            <span className="d-block">Schedule Your Push?</span>
                                                                            <bdi className="d-block">Instead of sending your push now, Schedule for any date/time </bdi>
                                                                        </div>
                                                                        <div className="ms-auto">
                                                                            <div className="form-check form-switch">
                                                                                <input className="form-check-input" name="sheduleNotification" value="schedule" type="radio" role="switch" id="Schedule" />
                                                                                <label className="form-check-label" htmlFor="Schedule" />
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div className="pt-3 date-show-info-hide active" id="date-show">
                                                                        <div className="row me-0">
                                                                            <div className="col-md-12 col-sm-8 pe-0">
                                                                                <div className="mb-3 custom-date-picker-react position-relative">
                                                                                    <input type='datetime-local' className='form-control input-custom-class' placeholder='' />
                                                                                    {/* <div className="date-picker-icon position-absolute top-0 bottom-0 mt-auto mb-auto d-flex align-items-center">
                                                                                        <svg width="18" height="20" viewBox="0 0 18 20" fill="none" >
                                                                                            <path d="M16 20H2C0.89543 20 0 19.1046 0 18V4C0 2.89543 0.89543 2 2 2H4V0H6V2H12V0H14V2H16C17.1046 2 18 2.89543 18 4V18C18 19.1046 17.1046 20 16 20ZM2 8V18H16V8H2ZM2 4V6H16V4H2ZM14 16H12V14H14V16ZM10 16H8V14H10V16ZM6 16H4V14H6V16ZM14 12H12V10H14V12ZM10 12H8V10H10V12ZM6 12H4V10H6V12Z" fill="#2d2d3b" />
                                                                                        </svg>
                                                                                    </div> */}
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="d-sm-flex align-items-center text-center py-3 mt-3">
                                                    <div>
                                                        <span className="d-flex align-items-center usrs-sub-info">
                                                            <svg className="me-2" width="30" height="30" viewBox="0 0 33 33" fill="none" >
                                                                <circle cx="16.5" cy="16.5" r="16.5" fill="#a81a1d1a" />
                                                                <path fillRule="evenodd" clipRule="evenodd" d="M19.5024 17.8477C20.5299 18.5452 21.2499 19.4902 21.2499 20.7502V23.0002H24.2499V20.7502C24.2499 19.1152 21.5724 18.1477 19.5024 17.8477Z" fill="#a81a1c" />
                                                                <path d="M13.75 17C15.4069 17 16.75 15.6569 16.75 14C16.75 12.3431 15.4069 11 13.75 11C12.0931 11 10.75 12.3431 10.75 14C10.75 15.6569 12.0931 17 13.75 17Z" fill="#a81a1c" />
                                                                <path fillRule="evenodd" clipRule="evenodd" d="M18.2499 17C19.9074 17 21.2499 15.6575 21.2499 14C21.2499 12.3425 19.9074 11 18.2499 11C17.8974 11 17.5674 11.075 17.2524 11.18C17.8749 11.9525 18.2499 12.935 18.2499 14C18.2499 15.065 17.8749 16.0475 17.2524 16.82C17.5674 16.925 17.8974 17 18.2499 17Z" fill="#a81a1c" />
                                                                <path fillRule="evenodd" clipRule="evenodd" d="M13.75 17.75C11.7475 17.75 7.75 18.755 7.75 20.75V23H19.75V20.75C19.75 18.755 15.7525 17.75 13.75 17.75Z" fill="#a81a1c" />
                                                            </svg>
                                                            You have push subscribers
                                                        </span>
                                                    </div>
                                                    <div className="ms-auto pt-3 pt-sm-0">
                                                        <button type="submit" className="btn red-btn">
                                                            <span>Send Push Notification</span>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-lg-4 col-md-5 pt-5 pt-md-0 pe-0">
                                                <div className="mobile-viw-right-info mx-auto position-sticky pt-3" id="mobile-viw">
                                                    <div className="position-relative">
                                                        <img src={PhoneImage} className="img-fluid w-100" alt="" />
                                                        <div className="noti-baar-app-info m-auto">
                                                            <div className="d-flex align-items-center">
                                                                <div className="hdr-phone-show-left d-flex align-items-center">
                                                                    <img src={PhoneSmall} className="img-fluid me-2" alt="" />
                                                                    <span>App Name</span>
                                                                </div>
                                                                <div className="hdr-phone-show-right ms-auto">Now</div>
                                                            </div>
                                                            <div className="collaps-div-after">
                                                                <img src={PlaceholderImage} className="w-100" alt="" />
                                                            </div>
                                                            <div className="d-flex align-items-center pt-2">
                                                                <div className="body-phone-show-left overflow-hidden">
                                                                    <span className="d-block">aaa</span>
                                                                    <p>123</p>
                                                                    <bdi>See more...</bdi>
                                                                </div>
                                                                <div className="body-phone-show-right ps-2 ms-auto">
                                                                    <img src={PlaceholderImage} className="img-fluid" alt="" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="expd-collaps-btn pt-4 text-center pb-2">
                                                        <button onClick={this.handleClassChange} className="text-center mx-auto border-0" id="expand-btn-shw" type="button">
                                                            <span className="first-spn">Expand</span>
                                                            <span className="last-spn">Collapse</span>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </Adminlayout >
        );
    }
}

export default AddCampaign;
