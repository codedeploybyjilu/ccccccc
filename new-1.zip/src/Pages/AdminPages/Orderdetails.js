import React, { Component } from "react";
import emailjs from "@emailjs/browser";
import {
  Modal,
  OverlayTrigger,
  Tooltip,
  Accordion,
  Alert,
} from "react-bootstrap";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import productimg from "../../images/product-img.png";
import Barcode from "react-barcode";
import { CopyToClipboard } from "react-copy-to-clipboard";
import madaicon from "../../images/mada-icon.svg";
import Verified from "../../images/verify-phone.svg";
import ErrorImg from "../../images/notverified-phone.svg";
import QRCode from "react-qr-code";
import toastr from "toastr";
import {
  APIBaseUrl,
  API_Path,
  buttonArabic,
  buttonEnglish,
  orderArabic,
  orderEnglish,
  DashboardArabic,
  DashboardEnglish,
  TableFieldArabic,
  TableFieldEnglish,
  titleArabic,
  titleEnglish,
  LIVE_FILE_URL,
  UserEnglish,
  UserArabic,
} from "../../const";
import { GetApi, PostApi } from "../../helper/APIService";
import { withRouter } from "react-router-dom";
import LanguageContext from "../../contexts/languageContext";
import moment from "moment";
import Graph25 from "../../images/Graph-25.svg";
import Graph50 from "../../images/Graph-50.svg";
import Graph75 from "../../images/Graph-75.svg";
import Graph100 from "../../images/Graph-100.svg";
import loader from "../../images/loader.gif";

let total1 = 0;
let total2 = 0;
let total_price = 0;

const enableFieldsOnUpdateShipment = {
  10: ["customerName", "phoneNumber", "city", "area", "line_1", "line_2"],
  11: ["customerName", "phoneNumber", "email", "cityArea", "line_1", "line_2"],
};

let order_item = [];
class Orderdetails extends Component {
  static contextType = LanguageContext;
  constructor(props) {
    super(props);
    this.state = {
      sendmsgmodal: "",
      refundmodal: "",
      addnotes: "",
      detailData: [],
      cancelled_item: [],
      returned_item: [],
      product: [],
      create_show: false,
      emailToCopy: "salim@libsimarkah.com",
      addressToCopy: "Near Jamiu KabeerShipping",
      phoneToCopy: "0508946664",
      // invoice edit state
      isBarcodeShow: false,
      invoice_number: "",
      invoice_svg: "",
      tracking_link: "",
      tracking_number: null,
      ShipmentID: "",
      ShipmentCompany: "",
      // cancel item state
      cancelButton: false,
      order_id: null,
      item_id: null,
      user_id: null,
      order_item: [],
      order_status: null,
      orderStatusValue: "",
      checkButton: false,
      optionSelected: false,
      orderStatusCheckBox: true,
      status: null,
      SubTotal: 0,
      total1: 0,
      total2: 0,
      total_price: 0,
      qeneratecode: "",
      barcode: "",
      notes: "",
      barcodeoption: {
        width: 2,
        font: "Poppins",
        rodchanges: null,
      },
      DisplayNotes: "",
      Editaddnotes: false,
      Editnotes: "",
      note_id: "",
      quantity: 1,
      shippingCompany: "",
      labelType: "",
      customerName: "",
      shipmentCustomerName: "",
      phoneNumber: "",
      cityArea: "",
      line_1: "",
      line_2: "",
      referenceNumber: "",
      trackingNumber: "",
      codValue: 0,
      shipmentComments: "",
      shippingCompanyData: [],
      pickupRequest: false,
      ClosingTime: moment().add(3, "day").format("YYYY-MM-DDThh:mm"),
      LastPickupTime: moment().add(2, "day").format("YYYY-MM-DDThh:mm"),
      ReadyTime: moment().format("YYYY-MM-DDThh:mm"),
      PickupDate: moment().add(30, "minute").format("YYYY-MM-DDThh:mm"),
      redboxPickupTime: moment().format("HH:mm"),
      validation: false,
      ShipperData: "",
      ShippingLabel: "",
      createPopup: "",
      PickUpID: "",
      messageTextBox: "",
      CancelItems: [],
      qtys: "1",
      reasons: "",
      RefundMode: "",
      refundAmountType: "",
      RefundDescription: "",
      RefundAmount: "",
      refund_amount: "",
      r_amount: false,
      p_pieces: "",
      shippingUpdateCode: "",
      shippingDescription: "",
      // redboxPickupNotes: '',
      coustom_tracking_link: "",
      qr_invoice_show: false,
      qr_invoice_number: "",
      QRCode: "",
      cancelComfirmModelshow: false,
      installments: [],
      dimensionUnit: "CM",
      dimensionWidth: null,
      dimensionHeigth: null,
      dimensionLength: null,
      weightUnit: "GM",
      weightValue: null,
      loading: true,
      warehouses: [],
      warehouse: "",
      isUpdateShipment: false,
      AllCity: [],
      AllArea: [],
      city: null,
      area: null,

      isShipmentReset: false,
      isPickupStore: false,

      cancelRefundBtnName: null,
      showCancelConfirmModal: false,
      cancelSource: "1",
      activeSpinnerBtn: false,
      invoice_show: false,
    };
  }

  isShippingCompanyRedbox = () => this.state.shippingCompany === "11";

  componentDidMount() {
    let url = window.location.href;
    let idString = url?.split("/")[url?.split("/")?.length - 1];
    let id = parseInt(idString);
    this.setState({ order_id: id });
    this.get_city_and_area();
    this.getOrderDetailData(id);
    this.getNotes(id);
    this.getShippingData();
    this.getSetting();
    // var module = {
    //   options: [],
    //   header: [
    //     navigator.platform,
    //     navigator.userAgent,
    //     navigator.appVersion,
    //     navigator.vendor,
    //     window.opera,
    //   ],
    //   dataos: [
    //     { name: "Windows Phone", value: "Windows Phone", version: "OS" },
    //     { name: "Windows", value: "Win", version: "NT" },
    //     { name: "iPhone", value: "iPhone", version: "OS" },
    //     { name: "iPad", value: "iPad", version: "OS" },
    //     { name: "Kindle", value: "Silk", version: "Silk" },
    //     { name: "Android", value: "Android", version: "Android" },
    //     { name: "PlayBook", value: "PlayBook", version: "OS" },
    //     { name: "BlackBerry", value: "BlackBerry", version: "/" },
    //     { name: "Macintosh", value: "Mac", version: "OS X" },
    //     { name: "Linux", value: "Linux", version: "rv" },
    //     { name: "Palm", value: "Palm", version: "PalmOS" },
    //   ],
    //   databrowser: [
    //     { name: "Chrome", value: "Chrome", version: "Chrome" },
    //     { name: "Firefox", value: "Firefox", version: "Firefox" },
    //     { name: "Safari", value: "Safari", version: "Version" },
    //     { name: "Internet Explorer", value: "MSIE", version: "MSIE" },
    //     { name: "Opera", value: "Opera", version: "Opera" },
    //     { name: "BlackBerry", value: "CLDC", version: "CLDC" },
    //     { name: "Mozilla", value: "Mozilla", version: "Mozilla" },
    //   ],
    //   init: function () {
    //     var agent = this.header.join(" "),
    //       os = this.matchItem(agent, this.dataos),
    //       browser = this.matchItem(agent, this.databrowser);

    //     return { os: os, browser: browser };
    //   },
    //   matchItem: function (string, data) {
    //     var i = 0,
    //       j = 0,
    //       html = "",
    //       regex,
    //       regexv,
    //       match,
    //       matches,
    //       version;

    //     for (i = 0; i < data.length; i += 1) {
    //       regex = new RegExp(data[i].value, "i");
    //       match = regex.test(string);
    //       if (match) {
    //         regexv = new RegExp(data[i].version + "[- /:;]([\\d._]+)", "i");
    //         matches = string.match(regexv);
    //         version = "";
    //         if (matches) {
    //           if (matches[1]) {
    //             matches = matches[1];
    //           }
    //         }
    //         if (matches) {
    //           matches = matches.split(/[._]+/);
    //           for (j = 0; j < matches.length; j += 1) {
    //             if (j === 0) {
    //               version += matches[j] + ".";
    //             } else {
    //               version += matches[j];
    //             }
    //           }
    //         } else {
    //           version = "0";
    //         }
    //         return {
    //           name: data[i].name,
    //           version: parseFloat(version),
    //         };
    //       }
    //     }
    //     return { name: "unknown", version: 0 };
    //   },
    // };

    // var e = module.init(),
    //   debug = "";

    // debug += "os.name = " + e.os.name + "<br/>";
    // debug += "os.version = " + e.os.version + "<br/>";
    // debug += "browser.name = " + e.browser.name + "<br/>";
    // debug += "browser.version = " + e.browser.version + "<br/>";

    // debug += "<br/>";
    // debug += "navigator.userAgent = " + navigator.userAgent + "<br/>";
    // debug += "navigator.appVersion = " + navigator.appVersion + "<br/>";
    // debug += "navigator.platform = " + navigator.platform + "<br/>";
    // debug += "navigator.vendor = " + navigator.vendor + "<br/>";
  }

  getInstallmentDetails = () => {
    const getInstallmentDetailsPromise = new Promise((resolve) => {
      resolve(GetApi(`${API_Path.tabbyInstallments}/${this.state.order_id}`));
    });
    getInstallmentDetailsPromise.then((res) => {
      if (res && res.data.message[0]) {
        const parsedResponse =
          JSON.parse(res.data.message[0].installments)[0] ??
          JSON.parse(res.data.message[0].installments);
        const installments = [
          {
            amount: parsedResponse?.downpayment_total,
            due_date: moment(this.state.detailData[0].createdat).format(
              "DD-MMM"
            ),
          },
          ...parsedResponse?.installments.map(({ amount, due_date }) => ({
            amount,
            due_date: moment(due_date).format("DD-MMM"),
          })),
        ];
        this.setState({ installments });
      }
    });
  };

  getSetting = () => {
    let path = API_Path.GetSetting;
    new Promise((resolve, reject) => {
      resolve(PostApi(path));
    }).then((res) => {
      if (res) {
        this.setState((state) => ({
          ShipperData: res.data.data[0].shipping,
          shippingCompany:
            state.shippingCompany.length !== 0
              ? state.shippingCompany
              : res.data.data[0]?.shipping?.default_shipping_company[0]?.id,
          ShipmentCompany:
            res.data.data[0]?.shipping?.default_shipping_company[0]?.id,
        }));
      }
    });
  };

  getShippingData = () => {
    let data = {};
    let path = API_Path.getShippingCompany;
    const getShippingDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getShippingDataPromise.then((res) => {
      if (res) {
        this.setState({ shippingCompanyData: res.data.data });
      }
    });
  };

  refundmodal = () => {
    this.setState({ refundAmountType: "", RefundMode: "" }, () => {
      this.setState({ refundmodal: true });
    });
  };

  refundmodalclose = () => {
    this.setState({ refundmodal: false });
  };

  addnotes = () => {
    this.setState({ addnotes: true });
  };

  addnotesclose = () => {
    this.setState({ addnotes: false });
  };

  Editaddnotesclose = () => {
    this.setState({ Editaddnotes: false });
  };

  handleNote = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  handleEditNote = (id) => {
    this.state.DisplayNotes.map((item) => {
      if (item.id == id) {
        this.setState({ Editnotes: item.note });
      }
    });
    this.setState({ Editaddnotes: true, note_id: id });
  };

  submitNote = (e) => {
    // this.setState({})
    e.preventDefault();
    this.addnotesclose();
  };

  getShipingLabel = (s_id, id) => {
    let data = {
      ship_id: s_id,
      orderID: id,
    };
    new Promise((resolve) => {
      resolve(PostApi(API_Path.creatLabel, data));
    }).then((res) => {
      this.setState(
        { ShippingLabel: res.data.data.ShipmentLabel.LabelURL },
        () => {
          this.getOrderDetailData(id);
        }
      );
    });
  };
  getWarehouses = () => {
    new Promise((resolve) => {
      resolve(GetApi(API_Path.getPickupLocations));
    }).then((res) => {
      this.setState({
        warehouses: res.data.warehouse,
        warehouse: res.data.warehouse[0]?.id ?? "",
      });
    });
  };

  getOrderDetailData = (id) => {
    let data = {
      id: id,
    };
    this.setState({ loading: true });
    const getDetailDataPromise = new Promise((resolve) => {
      resolve(PostApi(API_Path.getOrderById, data));
    });
    getDetailDataPromise
      .then((response) => {
        if (response) {
          const data = response.data.data;
          // console.log('getDetailDataPromise: ', data,API_Path.getOrderById);
          if (data) {
            if (data[0].pay_method === "TABBY") this.getInstallmentDetails();

            const shippingCompanyId = data[0].shipping_company_id;

            this.setState(
              (state) => ({
                detailData: data,
                barcode:
                  data[0]?.invoice_no !== null ? data[0]?.invoice_no : "",
                invoice_number:
                  data[0]?.invoice_no !== null ? data[0]?.invoice_no : "",
                isBarcodeShow: true,
                invoice_svg: data[0]?.invoice_svg,
                ShipmentID: data[0]?.ship_id,
                PickUpID: data[0]?.pickup_id,
                tracking_number: data[0]?.order_item_list[0]?.ship_id,
                tracking_link: data[0]?.tracking_link ?? data[0]?.track_url,
                orderStatusValue: data[0]?.status,
                emailToCopy:
                  data[0]?.user_details?.length > 0
                    ? data[0]?.user_details[0]?.email
                    : "",
                addressToCopy:
                  data[0]?.user_address?.length > 0
                    ? data[0]?.user_address[0]?.line_1
                    : "",
                phoneToCopy:
                  data[0]?.user_address?.length > 0
                    ? data[0]?.user_address[0]?.phone
                    : "",
                //*  --- DISCUSS: cod value calculation, since total_paymentable_price comes in negative after cancel and refund ---
                codValue:
                  data[0]?.pay_method === "COD"
                    ? data[0].total_placed_price.toFixed(2) -
                      data[0].order_payments_refund.reduce(
                        (a, b) => (a = a + b.amount),
                        0
                      )
                    : 0, //data[0]?.total_paymentable_price : 0,
                labelType: "6x4 Thermal printer",
                addressId: data[0]?.id,
                shipmentCustomerName: data[0]?.address?.name,
                line_1: data[0]?.address?.line_1,
                line_2: data[0]?.address?.line_2,
                cityArea:
                  data[0]?.address?.city_en + "-" + data[0]?.address?.area_en,
                city: data[0]?.address?.city_id,
                area: data[0]?.address?.area_id,
                phoneNumber:
                  data[0]?.address.phone?.substring(0, 3) !== "966"
                    ? data[0]?.address.phone
                    : data[0]?.address.phone?.substring(3),
                customerName: data[0]?.user_details[0]?.first_name,
                email: data[0]?.user_details[0]?.email,
                referenceNumber: data[0]?.id,
                trackingNumber: data[0]?.ship_id,
                ShippingLabel: data[0].label_url,
                user_id: data[0].user_id,
                shippingUpdateCode: data[0].shipment_code, // data[0].aramex_updateCode,
                shippingDescription: data[0].shipment_description, // data[0].aramex_updateDescription,
                ShipmentCompany: shippingCompanyId
                  ? shippingCompanyId.toString()
                  : state.ShipmentCompany !== ""
                  ? state.ShipmentCompany
                  : "",
                shippingCompany: shippingCompanyId
                  ? shippingCompanyId.toString()
                  : state.shippingCompany !== ""
                  ? state.shippingCompany
                  : "",
                coustom_tracking_link: data[0].track_url,
                qr_invoice_number: data[0].e_invoice_hash,
                QRCode: data[0].e_invoice_hash,
                qeneratecode: data[0].e_invoice_hash ?? "",
                isPickupStore: data[0].is_store === 1,
                cancelSource:
                  data[0]?.pay_method === "TAMARA" && data[0]?.status < 4
                    ? "2"
                    : "1",
              }),
              () => {}
            );
            if (data[0].invoice_number !== "" && data[0].invoice_number) {
              this.setState({ isBarcodeShow: true });
            }

            const product = data[0].order_item.filter((item) => {
              if (item.status == 0 && item.quantity !== 0) {
                return item;
              }
            });

            total_price =
              total_price +
              parseInt(data[0].price) +
              parseInt(data[0].shipping_cost) +
              parseInt(data[0].COD_cost) +
              parseInt(data[0].plateform_cost) +
              (parseInt(data[0].price) * 15) / 100 -
              parseInt(data[0].wallet_cost) -
              parseInt(data[0].coupon_price) -
              parseInt(data[0].discount);
            this.setState(
              {
                product: product,
                total_price: parseFloat(total_price)?.toFixed(2),
              },
              () => {
                let pices = this.state.product.reduce(
                  (a, b) => (a = a + b.quantity),
                  0
                );
                this.setState({ p_pieces: pices });
              }
            );

            // ====================================cancel-product==============================================
            let cancel_item = data[0].order_item_list.filter(
              (item) => item.cancelled === 1
            );
            for (let i = 0; i < cancel_item.length; i++) {
              let checked = data[0].order_item.findIndex(
                (e) => e.variant_id === cancel_item[i].variant_id
              );
              if (checked != -1) {
                cancel_item[i].img =
                  data[0].order_item[checked].image.split(",")[0];
                cancel_item[i].title_en = data[0].order_item[checked].title_en;
                cancel_item[i].title_ar = data[0].order_item[checked].title_ar;
                cancel_item[i].color_ar = data[0].order_item[checked].color_ar;
                cancel_item[i].color_en = data[0].order_item[checked].color_en;
                cancel_item[i].size_ar = data[0].order_item[checked].size_ar;
                cancel_item[i].size_en = data[0].order_item[checked].size_en;
                cancel_item[i].barcode = data[0].order_item[checked].barcode;
                cancel_item[i].discounted_price =
                  data[0].order_item[checked].discounted_price;
                cancel_item[i].paymentable_price =
                  (data[0].order_item[checked].discounted_price *
                    (100 - Number(data[0].discount_value))) /
                  100;
              }
            }
            if (cancel_item.length > 0) {
              this.setState(
                { cancelled_item: cancel_item, total1: total1 },
                () => {
                  let refund = this.state.cancelled_item.reduce(
                    (a, b) => (a = a + b.discounted_price),
                    0
                  );
                  this.setState({ total1: refund });
                }
              );
            }
            const returned_item = data[0].order_item.filter((item) => {
              if (item.status == 2) {
                total2 = total2 + parseInt(item.cart_price);
                return item;
              }
            });

            this.setState({ returned_item: returned_item, total2: total2 });
          }
        }
        this.setState({ loading: false });
      })
      .catch((err) => {
        console.log(err);
        this.setState({ loading: false });
      });
  };

  cancelProduct = (order_id, order_status, user_id, order_item) => {
    let data = {
      user_id: user_id,
      cancel_orders: order_item,
    };

    this.setState({ activeSpinnerBtn: true });
    const cancelProductPromise = new Promise((resolve) => {
      resolve(PostApi(API_Path.cancelOrderItem, data));
    });
    cancelProductPromise.then((response) => {
      if (response.data.success) {
        this.createRefundOnCancel();
        if (this.context.language === "english") {
          toastr.success(response.data.message);
        } else {
          toastr.success("منح التماس لإلغاء هذا الأمر");
        }
        for (let i = 0; i < this.state.product.length; i++) {
          document.getElementById("cancel-checked" + i).checked = false;
          document
            .getElementById("order-checked-id" + i)
            .classList.remove("active");
        }
        this.setState({ checkButton: false });

        this.getOrderDetailData(this.state.order_id);
      } else {
        toastr.error(response.data.message);
      }
    });
  };

  editInvoiceData = (
    invoice_number,
    invoice_svg,
    ShipmentID,
    tracking_number,
    tracking_link,
    status
  ) => {
    let fields = {
      shipping_id: ShipmentID,
      invoice_number: invoice_number,
      tracking_number: tracking_number,
      tracking_link: tracking_link,
      invoice_svg: invoice_svg,
      status: status,
    };
    const data = {
      id: this.state.detailData[0].id,
      fields: fields,
    };
    // console.log("editInvoiceData", data);
    const editInvoiceDataPromise = new Promise((resolve) => {
      resolve(PostApi(API_Path.editInvoiceData, data));
    });
    editInvoiceDataPromise.then((response) => {
      if (response.data.success) {
        toastr.success(response.data.message);

        this.getOrderDetailData(this.state.order_id);
      } else {
        toastr.error(response.data.message);
      }
    });
  };

  handleItemCancel = (e) => {
    const name = e.target.innerText;
    if (name === "Cancel Item") {
      if (this.state.checkButton && name && this.state.optionSelected) {
        this.setState({
          cancelRefundBtnName: name,
          showCancelConfirmModal: true,
        });
      } else {
        toastr.error("Please Select Reason");
      }
    } else {
      this.handleCancel(e);
    }
  };

  handleCancel = (e) => {
    let name = e ? e.target.innerText : this.state.cancelRefundBtnName;
    this.setState({ order_status: name === "Cancel Item" ? 6 : 2 }, () => {
      if (
        this.state.checkButton &&
        this.state.order_status !== null &&
        this.state.optionSelected
      ) {
        let arr = this.state.order_item.forEach((item) => {
          if ((item.reason && item.quantity) === "") {
            return false;
          }
        });
        const { refundCalculation, ...order_item } = this.state.order_item[0];
        this.cancelProduct(
          this.state.order_id,
          this.state.order_status,
          this.state.user_id,
          [order_item]
        );
      } else {
        toastr.error("Please Select Reason");
      }
    });
    if (name === "Cancel Item") {
      this.setState({ order_status: 1 }, () => {
        this.setState({ optionSelected: false });
      });
    } else if (name === "Return Item") {
      this.setState({ order_status: 2 }, () => {
        this.setState({ optionSelected: false });
      });
    }
    this.setState({ cancelButton: true }, () => {});
  };

  handleCheckBoxChange = (e, item, select) => {
    this.setState({ [e.target.name]: e.target.value }, () => {
      let optionSelected;
      if (e.target.option !== 0) {
        optionSelected = true;

        this.setState({ optionSelected: true });
      }
      let obj = { order_id: item.id, reason: e.target.value };
      let checked = true;
      if (this.state.order_item.length > 0) {
        this.state.order_item.filter((value) => {
          if (value.order_product_id === item.id) {
            return (checked = false);
          }
        });
      }
      if (this.state.reasons !== "") {
        let arr;
        if (checked) {
          let newObj = {
            order_id: item.order_id,
            order_product_id: item.id,
            quantity: this.state.qtys,
            reason: this.state.reasons,
            refundCalculation: {
              quantity: item.quantity,
              // price: item.discounted_price,
              price: item.paymentable_price / item.quantity,
            },
          };
          arr = [...this.state.order_item, newObj];
        } else {
          for (let i in this.state.order_item) {
            if (this.state.order_item[i].order_product_id === item.id) {
              this.state.order_item[i].order_id = item.order_id;
              this.state.order_item[i].order_product_id = item.id;
              this.state.order_item[i].quantity = this.state.qtys;
              this.state.order_item[i].reason = this.state.reasons;
            }
          }
          arr = this.state.order_item;
        }
        this.setState(
          {
            order_item: arr,
            order_id: item.order_id,
            user_id: item.user_id,
          }
          // , () => {
          //   console.log(this.state.order_item);

          // }
        );
      }
    });
  };

  DateTimeToTimeStemp = (value) => {
    const date = moment(value).unix(); //new Date(value)
    // const timestamp = date.getTime()
    return date;
  };

  handleCreateShipment = () => {
    // console.log('this.state.createPopup: ', this.state.createPopup);

    if (this.state.createPopup === "pickup") {
      this.setState({ validation: true });
      let ready_time = this.DateTimeToTimeStemp(this.state.ReadyTime);
      let Pickup_date = this.DateTimeToTimeStemp(this.state.PickupDate);
      let lastpickup_time = this.DateTimeToTimeStemp(this.state.LastPickupTime);
      let closing_time = this.DateTimeToTimeStemp(this.state.ClosingTime);
      let pickup_data = {
        orderID: this.state.order_id,
        quntity: this.state.quantity,
        shippingcompany: this.state.ShipmentCompany,
        labletype: this.state.labelType,
        customer: this.state.shipmentCustomerName,
        cityarea: this.state.cityArea?.split("-")[0],
        city: this.state.AllCity?.find((city) => city.id == this.state.city)
          ?.english,
        area: this.state.AllArea?.find((area) => area.id == this.state.area)
          ?.english,
        addess_line1: this.state.line_1,
        addess_line2: this.state.line_2,
        referenceno: this.state.referenceNumber,
        phone: this.state.phoneNumber,
        email: this.state.email,
        Cod: this.state.codValue,
        comment: this.state.shipmentComments,
        PickupDate: Pickup_date,
        ReadyTime: ready_time,
        LastPickupTime: lastpickup_time,
        ClosingTime: closing_time,
      };
      if (this.isShippingCompanyRedbox()) {
        pickup_data.redbox_data = {
          pickup_location_id: this.state.warehouse,
          pickup_location_reference: this.state.warehouses.find(
            ({ id }) => id === this.state.warehouse
          ).reference,
          pickup_time: moment(this.state.redboxPickupTime, "HH:mm").format(
            "MMM DD/MM/yyyy HH:mm"
          ),
          note: this.state.shipmentComments,
        };
      }

      if (ready_time < Pickup_date) {
        if (Pickup_date < lastpickup_time) {
          if (lastpickup_time < closing_time) {
            let path = API_Path.creatPickup;
            const creatPickupPromise = new Promise((resolve, reject) => {
              resolve(PostApi(path, pickup_data));
            });

            creatPickupPromise.then((res) => {
              if (res) {
                if (res.data.data) {
                  toastr.success(res.data.message);
                }
              } else {
                toastr.error(res.data.message);
              }
            });
          } else {
            toastr.error(
              "Last Pickup Time should be earlier then  Closing Time"
            );
          }
        } else {
          toastr.error(" Pickup Time should be earlier then Last Pickup Time");
        }
      } else {
        toastr.error("Redy Time  should be earlier then Pickup Time");
      }
    } else {
      if (!this.state.isUpdateShipment && this.state.pickupRequest) {
        this.setState({ validation: true });
        let ready_time = this.DateTimeToTimeStemp(this.state.ReadyTime);
        let Pickup_date = this.DateTimeToTimeStemp(this.state.PickupDate);
        let lastpickup_time = this.DateTimeToTimeStemp(
          this.state.LastPickupTime
        );
        let closing_time = this.DateTimeToTimeStemp(this.state.ClosingTime);
        let pickup_data = {
          orderID: this.state.order_id,
          quntity: this.state.quantity,
          shippingcompany: this.state.ShipmentCompany,
          labletype: this.state.labelType,
          customer: this.state.shipmentCustomerName,
          cityarea: this.state.cityArea?.split("-")[0],
          city: this.state.AllCity?.find((city) => city.id == this.state.city)
            ?.english,
          area: this.state.AllArea?.find((area) => area.id == this.state.area)
            ?.english,
          addess_line1: this.state.line_1,
          addess_line2: this.state.line_2,
          referenceno: this.state.referenceNumber,
          tracking: this.state.trackingNumber,
          phone: this.state.phoneNumber,
          email: this.state.email,
          Cod: this.state.codValue,
          comment: this.state.shipmentComments,
          PickupDate: Pickup_date,
          ReadyTime: ready_time,
          LastPickupTime: lastpickup_time,
          ClosingTime: closing_time,
        };
        if (this.isShippingCompanyRedbox()) {
          pickup_data.redbox_data = {
            pickup_location_id: this.state.warehouse,
            pickup_location_reference: this.state.warehouses.find(
              ({ id }) => id === this.state.warehouse
            ).reference,
            pickup_time: moment(this.state.redboxPickupTime, "HH:mm").format(
              "MMM DD/MM/yyyy HH:mm"
            ),
            note: this.state.shipmentComments,
          };
        }

        if (ready_time < Pickup_date) {
          if (Pickup_date < lastpickup_time) {
            if (lastpickup_time < closing_time) {
              let path = API_Path.creatPickup;
              const creatPickupPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, pickup_data));
              });

              creatPickupPromise.then((res) => {
                if (res) {
                  if (res.data.data) {
                    toastr.success(res.data.message);
                  }
                } else {
                  toastr.error(res.data.message);
                }
              });
            } else {
              toastr.error(
                "Last Pickup Time should be earlier then  Closing Time"
              );
            }
          } else {
            toastr.error(
              " Pickup Time should be earlier then Last Pickup Time"
            );
          }
        } else {
          toastr.error("Redy Time  should be earlier then Pickup Time");
        }
      }
      let data = {
        orderID: this.state.order_id,
        quntity: this.state.quantity,
        shippingcompany: this.state.shippingCompany,
        labletype: this.state.labelType,
        customer: this.state.shipmentCustomerName,
        cityarea: this.state.cityArea?.split("-")[0],
        city: this.state.AllCity?.find((city) => city.id == this.state.city)
          ?.english,
        area: this.state.AllArea?.find((area) => area.id == this.state.area)
          ?.english,
        addess_line1: this.state.line_1,
        addess_line2: this.state.line_2,
        referenceno: this.state.referenceNumber,
        tracking: this.state.trackingNumber,
        phone: this.state.phoneNumber,
        email: this.state.email,
        Cod: this.state.codValue,
        comment: this.state.shipmentComments,
      };

      // Map the products to the new format for redbox item
      const items = this.state.product.map((product) => ({
        name: product.title_en,
        quantity: product.quantity,
        description: product.description_en,
        unit_price: product.product_price,
        currency: "sar",
      }));

      if (this.state.shippingCompany === "10") {
        data.COD_cost = this.state.detailData[0].COD_cost;
        data.addressid = this.state.detailData[0].address.id;
        data.pay_method = this.state.detailData[0].pay_method;
        data.order_price = this.state.codValue;
        data.reff = this.state.order_id;
        data.shipping = this.state.ShipperData;
      }
      if (this.isShippingCompanyRedbox()) {
        let dataRedBox = {
          reference: this.state.order_id,
          items: items,
          original_tracking_number: this.state.trackingNumber,
          customer_name: this.state.customerName,
          customer_email: this.state.email ? this.state.email : "",
          customer_phone: this.state.phoneNumber ? this.state.phoneNumber : "",
          customer_address: `${this.state.line_1} ${this.state.line_2}`,
          customer_city: this.state.cityArea?.split("-")[0],
          // customer_country: this.state.ShipperData.city_detail[0].countryIso,
          // dimension_unit: this.state.dimensionUnit,
          // dimension_width: this.state.dimensionWidth,
          // dimension_height: this.state.dimensionHeigth,
          // dimension_length: this.state.dimensionLength,
          // weight_unit: this.state.weightUnit,
          // weight_value: this.state.weightValue,
          cod_amount: this.state.detailData[0].COD_cost,
          cod_currency: "SAR",
          shipping_price: this.state.detailData[0].shipping_cost,
          shipping_price_currency: "SAR",
          from_platform: "website",
          delivery_method: "point_pickup",
          pickup_location_id: this.state.warehouse,
          pickup_location_reference: this.state.warehouses.find(
            ({ id }) => id === this.state.warehouse
          ).reference,
          package_count: this.state.quantity,
        };

        data.redbox_data = dataRedBox;
      }

      let path = this.state.isUpdateShipment
        ? API_Path.updateShipment
        : API_Path.creatShipment;

      const creatShipmentPromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      creatShipmentPromise.then((res) => {
        if (res) {
          if (!res.data.success) {
            toastr.error(
              res.data.message_en
                ? this.context.language === "english"
                  ? res.data.message_en
                  : res.data.message_ar
                : res.data.message
            );
            return;
          }

          if (res.data.data) {
            toastr.success(
              res.data.message ??
                (this.context.language === "english"
                  ? res.data.message_en
                  : res.data.message_ar)
            );
            if (res.data.data?.Shipments?.[0]?.ID)
              this.getShipingLabel(
                res.data.data.Shipments[0].ID,
                this.state.order_id
              );
            if (res.data.data?.shipping?.pdf_label)
              this.setState(
                { ShippingLabel: res.data.data.shipping.pdf_label }
                // , () => {
                // }
              );
            this.getOrderDetailData(this.state.order_id);
            this.create_userClose();
          }
        } else {
          toastr.error(
            res?.data?.message ??
              (this.context.language === "english"
                ? "Error creating shipment"
                : "حدث خطأ أثناء إنشاء الشحنة")
          );
        }
      });
    }

    // const path = "https://ws.dev.aramex.net/ShippingAPI.V2/Shipping/Service_1_0.svc/json/CreateShipments";
    // const data = {
    //   ClientInfo: {
    //     UserName: "reem@reem.com",
    //     Password: "123456789",
    //     Version: "1.0",
    //     AccountNumber: "4004636",
    //     AccountPin: "432432",
    //     AccountEntity: "RUH",
    //     AccountCountryCode: "SA",
    //     Source: "24",
    //   },
    // };

    // const createShippmentPromise = new Promise((resolve, reject) => {
    //   resolve(TestPostApi(path, JSON.stringify(data)));
    // });
    // createShippmentPromise.then((response) => {
    //   console.log("response :: ", response);
    // });

    // const path =
    //   "https://ws.aramex.net/shippingapi.v2/shipping/service_1_0.svc/json";

    // const data = {
    //   AccountNumber: "60496246",
    //   AccountEntity: "JED",
    //   AccountPin: "165165",
    //   AccountCountryCode: "SAUDI ARABIA",
    //   UserName: "salim@libsimarkah.com",
    //   Password: "@Libsi123",
    //   Version: "v1",
    //   // Shipper:,
    //   // Consignee: ,
    //   // ShippingDateTime:,
    //   // Source:,
    //   // Details:ShipmentDetails,
    //   // Line1: Address ,
    //   // CountryCode:,
    //   // PersonName:User’s Name,
    //   // CompanyName:Company or Person name,
    //   // PhoneNumber1:Valid Phone Number
    // };
    // const PostApiData = axios
    //   .post(path, data, config)
    //   .then((response) => {
    //     console.log(response.data);
    //     console.log(response);

    //     return response;
    //   })
    //   .catch((err) => {
    //     console.log(err);
    //     return err;
    //   });
    // return PostApiData;
  };

  handleOrderStatus = (e) => {
    this.setState({
      checkButton: false,
      orderStatusCheckBox: e.target.value > "5" ? false : true,
    });
    if (e.target.value == "6") {
      this.setState({ cancelComfirmModelshow: true });
    } else {
      this.setState({ orderStatusValue: e.target.value }, () => {
        this.changeOrderStatus(this.state.orderStatusValue);
      });
    }
  };

  handleCloseConfirCancelModal = () => {
    this.setState({ cancelComfirmModelshow: false });
  };

  confirmCancelWholeOrder = () => {
    this.setState({ orderStatusValue: "6" }, () => {
      this.changeOrderStatus(this.state.orderStatusValue);
      this.handleCloseConfirCancelModal();
    });
  };

  changeOrderStatus = (status) => {
    let data = {
      order_status: status,
      order_id: this.state.order_id,
    };
    new Promise((resolve) => {
      resolve(PostApi(API_Path.changeOrderStatus, data));
    }).then((res) => {
      if (res) {
        toastr.success(res.data.message);
        this.getOrderDetailData(this.state.order_id);
      }
    });
  };

  edit_userClose = () => {
    this.setState({ search_show: false });
  };

  edit_userShow = (e) => {
    e.preventDefault();
    this.setState({ search_show: true });
  };

  edit_handleShow = (e) => {
    e.preventDefault();
    this.setState({ search_show: true });
  };

  create_handleShow = (value) => {
    // e.preventDefault();
    // this.getSetting()
    if (value === "pickup") {
      this.setState({ pickupRequest: true });
      this.setState({ createPopup: value, create_show: true });
    } else if (value === "shipment") {
      if (this.isShippingCompanyRedbox() && this.state.warehouses.length === 0)
        this.getWarehouses();
      this.setState({ createPopup: value, create_show: true });
    } else if (value === "updateShipment") {
      if (this.isShippingCompanyRedbox() && this.state.warehouses.length === 0)
        this.getWarehouses();
      this.setState({ isUpdateShipment: true, create_show: true });
    } else {
      let data = {
        shippingcompany: "9",
        shipId: "",
        track_url: this.state.coustom_tracking_link,
        orderID: this.state.order_id,
      };

      let path = API_Path.creatShipment;
      const creatShipmentPromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      creatShipmentPromise.then((res) => {
        if (res.data.success) {
          if (res.data.data) {
            toastr.success(res.data.message);
          }
        } else {
          toastr.error(res.data.message);
        }
      });
    }
  };

  create_userClose = () => {
    this.setState({ create_show: false });
  };

  create_userShow = (e) => {
    e.preventDefault();
    this.setState({ create_show: true });
  };

  handleChange = (e) => {
    if (e.target.name == "invoice_number") {
      this.setState({ isBarcodeShow: false });
    } else if (e.target.name === "pickupRequest") {
      this.setState({ pickupRequest: e.target.checked });
    } else {
      this.setState({ [e.target.name]: e.target.value });
    }
  };

  // handleSave = () => {
  //   console.log("save button clicked");
  //   this.editInvoiceData(this.state.invoice_number, this.state.invoice_svg, this.state.ShipmentID, this.state.tracking_number, this.state.tracking_link, this.state.orderStatusValue);
  //   this.getOrderDetailData(this.state.order_id);
  // };

  handleSaveInvoiceNumber = () => {
    if (this.state.invoice_number !== "") {
      this.setState({ isBarcodeShow: true }, () => {
        if (this.state.isBarcodeShow == true) {
          let value =
            document.getElementById("barcode-div") &&
            document.getElementById("barcode-div").innerHTML;
          this.setState({ invoice_svg: value }, () => {
            let data = {
              invoice_no: this.state.invoice_number,
              order_id: this.state.order_id,
            };
            let path = API_Path.updateInvoiceNumber;
            const updateInvoiceNumberPromise = new Promise(
              (resolve, reject) => {
                resolve(PostApi(path, data));
              }
            );

            updateInvoiceNumberPromise.then((res) => {
              if (res) {
                this.setState({ barcode: this.state.invoice_number });
                this.handleCloseInvoiceModal();
              } else {
                toastr.error(res.data.message);
              }
            });
          });
        }
      });
    } else {
      toastr.error("Please Add Bill Number");
    }
  };

  handleTrackChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  handleTrack = () => {
    let data = {
      ShipmentID: this.state.ShipmentID,
    };
    let path = API_Path.trackShipment;
    const trackPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    trackPromise.then((res) => {
      if (res) {
      } else {
        toastr.error(res.data.message);
      }
    });
  };

  handleShippingOption = (e) => {
    this.setState(
      { ShipmentCompany: e.target.value, shippingCompany: e.target.value },
      () => {}
    );
  };

  handleCheckboxChange = (e, i, id) => {
    this.setState({ qtys: "1", reasons: "" });
    if (e.target.checked) {
      document.getElementById("order-checked-id" + i).classList.add("active");
      this.setState({ checkButton: true });
    } else {
      this.setState({ checkButton: false });
      document
        .getElementById("order-checked-id" + i)
        .classList.remove("active");
      if (this.state.order_item.length > 0) {
        let updateArr = this.state.order_item.filter(
          (obj) => obj.order_product_id !== id
        );
        this.setState(
          { order_item: updateArr }
          //   , () => {
          //   console.log(this.state.order_item, "order_itemorder_item");
          // }
        );
      }
    }
  };

  sendmsgmodal = () => {
    this.setState({ sendmsgmodal: true, messageTextBox: "" });
  };

  sendmsgmodalclose = () => {
    this.setState({ sendmsgmodal: false });
  };

  qenerate = (e) => {
    this.setState({ qeneratecode: e.target.value });
  };

  barcode = (e) => {
    // this.setState({ barcode: e.target.value });
    if (e.target.name == "invoice_number") {
      this.setState({ isBarcodeShow: false, invoice_number: e.target.value });
    }
  };

  handleMessageChange = (e) => {
    this.setState({
      messageTextBox: e.target.value?.split(
        `Message from Libsimarkah related to order number: ${this.state.order_id}`
      )[
        e.target.value?.split(
          `Message from Libsimarkah related to order number: ${this.state.order_id}`
        )?.length - 1
      ],
    });
  };

  sendMsgViaEmail = (e) => {
    e.preventDefault();
    if (e.target[1].checked) {
      let phoneNo =
        this.state.detailData[0].user_details[0].phone.substring(0, 3) !== "966"
          ? "966" + this.state.detailData[0].user_details[0].phone
          : this.state.detailData[0].user_details[0].phone;
      let wp_url = `https://api.whatsapp.com/send/?phone=${phoneNo}&text=Message+from+Libsimarkah+related+to+order+number%3A+${this.state.order_id}%0A${this.state.messageTextBox}&type=phone_number&app_absent=0`;
      // let wp_url = `https://wa.me/${phoneNo}?text=Message%20from%20Libsimarkah%20related%20to%20order%20number%3a%20${this.state.order_id}%0a${this.state.messageTextBox}`
      window.open(wp_url, "_blank");
    }
    if (e.target[2].checked) {
      let data = {
        phone: this.state.detailData[0].user_details[0].phone,
        body: `Message from Libsimarkah related to order number: ${this.state.order_id} ${this.state.messageTextBox}`,
      };
      new Promise((resolve) => {
        resolve(PostApi(API_Path.SendMessageViaSMS, data));
      }).then((res) => {
        if (res.data.success) {
          toastr.success(res.data.message);
        }
      });
    }
    if (e.target[3].checked) {
      let data = {
        to: "jinal.mathukiya@rentechdigital.com",
        subject: `Message from Libsimarkah related to order number: ${this.state.order_id}`,
        html: this.state.messageTextBox,
      };
      new Promise((resolve) => {
        resolve(PostApi(API_Path.SendMessageViaEmail, data));
      }).then((res) => {
        if (res.data.success) {
          toastr.success(res.data.message);
        }
      });
    }
    this.sendmsgmodalclose();
  };

  SaveNote = () => {
    let data = {
      order_id: this.state.order_id,
      note: this.state.notes,
    };
    new Promise((resolve) => {
      resolve(PostApi(API_Path.AddNote, data));
    }).then((res) => {
      if (res.data.success) {
        this.setState({ notes: "" });
        toastr.success(res.data.message);
        this.getNotes(this.state.order_id);
      }
    });
  };

  getNotes = (id) => {
    let data = {
      order_id: id,
    };
    new Promise((resolve) => {
      resolve(PostApi(API_Path.GetOrderNotes, data));
    }).then((res) => {
      if (res) {
        if (res.data.success) {
          this.setState({ DisplayNotes: res.data.data });
        }
      }
    });
  };

  handleDelete = (id) => {
    let data = {
      note_id: id,
    };
    new Promise((resolve) => {
      resolve(PostApi(API_Path.DeleteOrderNotes, data));
    }).then((res) => {
      if (res.data.success) {
        toastr.success(res.data.message);
        this.getNotes(this.state.order_id);
      }
    });
  };

  EditNote = () => {
    let data = {
      note_id: this.state.note_id,
      note: this.state.Editnotes,
    };
    new Promise((resolve) => {
      resolve(PostApi(API_Path.EditOrderNotes, data));
    }).then((res) => {
      if (res.data.success) {
        toastr.success(res.data.message);
        this.getNotes(this.state.order_id);
        this.setState({ Editnotes: "" });
        this.Editaddnotesclose();
      }
    });
  };

  handleRefundChange = (e) => {
    this.setState({ [e.target.name]: e.target.value }, () => {
      if (this.state.refundAmountType === "partial") {
        this.setState({ r_amount: true });
      } else {
        this.setState({ r_amount: false });
      }
    });

    // switch (Value) {
    //   case 'card':

    //     break;
    //   case 'wallet':

    //     break;
    //   case 'bank':

    //     break;
    //   case 'full':

    //     break;
    //   case 'custom':

    //     break;

    //   default:
    //     break;
    // }
  };
  handleRefundinputChange = (e) => {
    let totalReFund =
      this.state.detailData[0] &&
      this.state.detailData[0].order_payments_refund.reduce(
        (a, b) => (a = a + b.amount),
        0
      );
    let refundAmount = parseFloat(e.target.value);
    let MinimiseValue =
      Number(this.state.detailData[0].total_placed_price) - totalReFund;
    if (refundAmount > 0 && refundAmount <= MinimiseValue) {
      this.setState({ refund_amount: refundAmount });
    } else {
      this.setState({ refund_amount: "" });
    }
  };

  CreateRefund = () => {
    if (this.state.RefundMode !== "") {
      let totalReFund =
        this.state.detailData[0] &&
        this.state.detailData[0].order_payments_refund.reduce(
          (a, b) => (a = a + b.amount),
          0
        );
      if (
        this.state.refundAmountType === "partial" &&
        this.state.refund_amount !== ""
      ) {
        let refundData = {
          user_id: this.state.user_id,
          order_id: ["TABBY", "TAMARA"].includes(
            this.state.detailData[0].pay_method
          )
            ? this.state.order_id.toString()
            : this.state.order_id,
          transaction_type: this.state.RefundMode,
          amount_type: this.state.refundAmountType,
          amount: this.state.refund_amount,
          currency: "SAR",
          reason: "requested_by_customer",
          description: this.state.RefundDescription,
          payment_gateway: ["TABBY", "TAMARA"].includes(
            this.state.detailData[0].pay_method
          )
            ? this.state.detailData[0].pay_method
            : "HYPER",
          method: "refund",
        };
        new Promise((resolve) => {
          resolve(PostApi(API_Path.CreateRefund, refundData));
        }).then((res) => {
          this.getOrderDetailData(this.state.order_id);
          this.refundmodalclose();
        });
      } else if (
        this.state.refundAmountType !== "partial" &&
        (
          Number(this.state.detailData[0].total_placed_price) - totalReFund
        ).toFixed(2) != 0
      ) {
        let refundData = {
          user_id: this.state.user_id,
          order_id: ["TABBY", "TAMARA"].includes(
            this.state.detailData[0].pay_method
          )
            ? this.state.order_id.toString()
            : this.state.order_id,
          transaction_type: this.state.RefundMode,
          amount_type: this.state.refundAmountType,
          amount: (
            Number(this.state.detailData[0].total_placed_price) - totalReFund
          ).toFixed(2),
          currency: "SAR",
          reason: "requested_by_customer",
          description: this.state.RefundDescription,
          payment_gateway: ["TABBY", "TAMARA"].includes(
            this.state.detailData[0].pay_method
          )
            ? this.state.detailData[0].pay_method
            : "HYPER",
          method: "refund",
        };
        new Promise((resolve) => {
          resolve(PostApi(API_Path.CreateRefund, refundData));
        }).then((res) => {
          this.getOrderDetailData(this.state.order_id);
          this.refundmodalclose();
        });
      } else {
        toastr.error("Please Enter Refund Amount");
      }
    } else {
      toastr.error("Please Select TransectionType");
    }
  };
  createRefundOnCancel = () => {
    const refundMode =
        this.state.cancelSource === "1"
          ? "wallet"
          : this.state.detailData[0].pay_method,
      refundAmountType =
        this.state.order_item.length < this.state.product.length ||
        this.state.order_item.some(
          (item) => item.quantity < item.refundCalculation.quantity
        )
          ? "partial"
          : "full",
      refund_amount =
        refundAmountType === "partial"
          ? this.state.order_item.reduce(
              (acc, item) =>
                (acc += item.quantity * item.refundCalculation.price),
              0
            )
          : this.state.detailData[0].total_paymentable_price;

    if (refundMode !== "") {
      let totalReFund =
        this.state.detailData[0] &&
        this.state.detailData[0].order_payments_refund.reduce(
          (a, b) => (a = a + b.amount),
          0
        );
      if (refundAmountType === "partial" && refund_amount !== "") {
        let refundData = {
          user_id: this.state.user_id,
          order_id: ["TABBY", "TAMARA"].includes(refundMode)
            ? this.state.order_id.toString()
            : this.state.order_id,
          transaction_type:
            refundMode === "COD"
              ? "wallet"
              : ["TABBY", "TAMARA"].includes(refundMode)
              ? "card"
              : refundMode,
          amount_type: refundAmountType,
          amount: Number(refund_amount),
          currency: "SAR",
          reason: "requested_by_customer",
          description: `cancellation: ${this.state.order_item[0].reason.replaceAll(
            " ",
            "_"
          )}`,
          payment_gateway: ["TABBY", "TAMARA"].includes(refundMode)
            ? refundMode
            : "HYPER",
          method: "cancel",
        };
        new Promise((resolve) => {
          resolve(PostApi(API_Path.CreateRefund, refundData));
        }).then((res) => {
          this.setState({
            activeSpinnerBtn: false,
            showCancelConfirmModal: false,
          });
          this.getOrderDetailData(this.state.order_id);
          this.refundmodalclose();
        });
      } else if (
        refundAmountType !== "partial" &&
        (
          Number(this.state.detailData[0].total_placed_price) - totalReFund
        ).toFixed(2) != 0
      ) {
        let refundData = {
          user_id: this.state.user_id,
          order_id: ["TABBY", "TAMARA"].includes(refundMode)
            ? this.state.order_id.toString()
            : this.state.order_id,
          transaction_type:
            refundMode === "COD"
              ? "wallet"
              : ["TABBY", "TAMARA"].includes(refundMode)
              ? "card"
              : refundMode,
          amount_type: refundAmountType,
          amount: (
            Number(this.state.detailData[0].total_placed_price) - totalReFund
          ).toFixed(2),
          currency: "SAR",
          reason: "requested_by_customer",
          description: `cancellation: ${this.state.order_item[0].reason.replaceAll(
            " ",
            "_"
          )}`,
          payment_gateway: ["TABBY", "TAMARA"].includes(refundMode)
            ? refundMode
            : "HYPER",
          method: "cancel",
        };
        new Promise((resolve) => {
          resolve(PostApi(API_Path.CreateRefund, refundData));
        }).then((res) => {
          toastr.success(res.data.message);
          this.getOrderDetailData(this.state.order_id);
          this.refundmodalclose();
          this.handleCancelConfirmModalClose();
        });
      } else {
        toastr.error("Please Enter Refund Amount");
      }
    } else {
      toastr.error("Please Select TransectionType");
    }
  };
  handleTrackLink = (e) => {
    this.setState({ coustom_tracking_link: e.target.value });
  };

  handleShowInvoiceModal = () => {
    this.getOrderDetailData(this.state.order_id);
    this.setState({ invoice_show: true });
  };

  handleCloseInvoiceModal = () => {
    this.setState({ invoice_show: false });
  };
  handleQrShow = () => {
    this.setState({ qr_invoice_show: true });
  };
  QRCode = (e) => {
    this.setState({ qr_invoice_number: e.target.value });
  };
  handleSaveQRInvoiceNumber = () => {
    let QRdata = {
      e_invoice_hash: this.state.qr_invoice_number,
      order_id: this.state.order_id,
    };
    new Promise((resolve) => {
      resolve(PostApi(API_Path.UpdateQrCode, QRdata));
    }).then((res) => {
      if (res) {
        this.setState({ QRCode: this.state.qr_invoice_number });
        this.handleCloseQrInvoiceModal();
        this.getOrderDetailData(this.state.order_id);
      }
    });
  };
  handleCloseQrInvoiceModal = () => {
    this.setState({ qr_invoice_show: false });
  };

  //  --- reset the shipping company and tracking details ---
  resetTrackingDetails = () => {
    const url = window.location.href;
    const idString = url?.split("/")[url?.split("/")?.length - 1];

    new Promise((resolve) => {
      resolve(
        PostApi(API_Path.resetShipment, {
          order_id: idString,
          tracking_number: this.state.ShipmentID,
        })
      );
    }).then((res) => {
      if (res.data.success) {
        this.setState({ isShipmentReset: true });
        toastr.success(
          this.context.language === "english"
            ? res.data.message_en
            : res.data.message_ar
        );

        this.getOrderDetailData(idString);
      } else {
        toastr.error(
          this.context.language === "english"
            ? res.data.message_en
            : res.data.message_ar
        );
      }
    });
  };

  handleShippingCompanyChange = (e) => {
    if (e.target.value === "11" && this.state.warehouses.length === 0) {
      this.getWarehouses();
    }
    this.handleChange(e);
  };

  get_city_and_area = () => {
    let city_path = API_Path.getCityData;
    let area_path = API_Path.getArea;
    const getCity = new Promise((resolve) => {
      resolve(PostApi(city_path));
    });
    const getArea = new Promise((resolve) => {
      resolve(PostApi(area_path));
    });
    Promise.all([getCity, getArea]).then((res) => {
      if (res[0] && res[1]) {
        this.setState({ AllCity: res[0].data.data, AllArea: res[1].data.data });
      }
    });
  };

  getAreaByCity = (city_id = "1") => {
    let area_path = API_Path.getArea;

    new Promise((resolve) => {
      resolve(PostApi(area_path, { city_id }));
    }).then((res) => {
      if (res) {
        this.setState({ AllArea: res.data.data });
      }
    });
  };

  handleSelectCancelSource = (e, index) => {
    this.setState({ cancelSource: index });
  };

  handleCancelConfirmModalClose = () => {
    this.setState({ showCancelConfirmModal: false });
  };

  render() {
    let Language =
      this.context.language === "english"
        ? TableFieldEnglish
        : TableFieldArabic;
    let titleLanguage =
      this.context.language === "english" ? titleEnglish : titleArabic;
    let ButtonLanguage =
      this.context.language === "english" ? buttonEnglish : buttonArabic;
    let UserLanguage =
      this.context.language === "english" ? UserEnglish : UserArabic;
    let orderLanguage =
      this.context.language === "english" ? orderEnglish : orderArabic;
    let DashboardLanguage =
      this.context.language === "english" ? DashboardEnglish : DashboardArabic;
    let totalReFund =
      this.state.detailData[0] &&
      this.state.detailData[0].order_payments_refund.reduce(
        (a, b) => (a = a + b.amount),
        0
      );

    const canUpdateShipment =
      this.state.ShipmentID &&
      ((this.state.ShipmentCompany === "10" &&
        this.state.shippingUpdateCode === "AY-0001") ||
        (this.state.ShipmentCompany === "11" &&
          ["101", "201"].includes(this.state.shippingUpdateCode)));
    const option = {
      width: 100,
      height: 100,
      displayValue: true,
      background: "#ffffff",
      lineColor: "#000000",
      font: "monospace",
      textAlign: "center",
      textPosition: "bottom",
    };

    const graphIcons = {
      graph25: Graph25,
      graph50: Graph50,
      graph75: Graph75,
      graph100: Graph100,
    };

    const enableFieldsOnUpdate = this.state.isUpdateShipment
      ? enableFieldsOnUpdateShipment[this.state.ShipmentCompany]
      : null;

    const isTamaraRefundNotAllowed =
      this.state.detailData[0]?.pay_method === "TAMARA" &&
      this.state.orderStatusValue < 4;

    const showRefundToWallet = !isTamaraRefundNotAllowed;

    return (
      <Adminlayout>
        {this.state.loading && (
          <div className="loader-main">
            <div className="loader-inr">
              <img src={loader} alt="" />
            </div>
          </div>
        )}
        <div className="order-fix-width-part">
          <div className="container-fluid">
            <div className="row common-space align-items-center">
              <div className="col-5  text-start rtl-txt-start">
                <div className="common-header-txt d-flex">
                  <span
                    onClick={() => {
                      this.props.history.goBack();
                    }}
                    className="cursor-pointer me-2"
                  >
                    <svg
                      width="36"
                      height="37"
                      viewBox="0 0 36 37"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <rect
                        y="0.5"
                        width="36"
                        height="36"
                        rx="5"
                        fill="#EFEFEF"
                      />
                      <path
                        d="M26.1666 18.5H9.83325"
                        stroke="#2D2D3B"
                        stroke-width="2.5"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      />
                      <path
                        d="M17.9999 26.6666L9.83325 18.5L17.9999 10.3333"
                        stroke="#2D2D3B"
                        stroke-width="2.5"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      />
                    </svg>
                  </span>
                  <h3>{orderLanguage.orderDetail}</h3>
                </div>
              </div>
              <div className="col-7  text-end rtl-txt-end">
                <div className="common-red-btn">
                  <a
                    className="btn print-btn me-2"
                    target="_blank"
                    href={`order-details-print/${this.state.order_id}`}
                  >
                    <i class="bi bi-printer me-2"></i>
                    {ButtonLanguage.print}
                  </a>
                  {/* <button className="btn red-btn px-5" onClick={this.handleSave}>
                    {ButtonLanguage.save}
                  </button> */}
                </div>
              </div>
            </div>
            <div className="row common-space">
              <div className="col-xl-8 col-lg-6">
                <div className="white-box h-auto">
                  <div className="row align-items-center border-bottom pb-3">
                    <div className="col-xxl-7 text-xxl-start rtl-text-xxl-start text-center">
                      <div className="common-header-txt order-det-header d-flex text-start align-items-center justify-content-xxl-between">
                        <span className="order-details-txt">
                          {orderLanguage.orderId}:
                          {this.state.detailData.length > 0 && (
                            <span className="order-detail-num">
                              {" "}
                              {this.state.detailData[0].id}
                            </span>
                          )}
                          <div className="mt-2 reduce-font">
                            <i className="bi bi-calendar3 text-black me-2" />
                            {this.state.detailData.length > 0 && (
                              <span className="text-secondary fs-6">
                                {moment(
                                  this.state.detailData[0].createdat
                                ).format("DD-MMM-YYYY, hh:mm A ")}
                              </span>
                            )}
                          </div>
                        </span>
                        <div className=" margin-class">
                          <div className="barcode-div">
                            <Barcode
                              option={option}
                              value={this.state.order_id}
                              height={40}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-xxl-5 mt-3 mt-sm-0 text-sm-end text-center">
                      <div className="common-red-btn order-det-header-right d-flex justify-content-end align-items-center">
                        <span className="text-secondary fs-6">
                          {orderLanguage.orderStatus} :
                        </span>
                        {/* <span className="status-product pending">Pending</span> */}
                        <select
                          className="form-select form-contol select-dif-color ms-2 w-auto"
                          style={{ backgroundColor: `#4cad45` }}
                          value={this.state.orderStatusValue}
                          onChange={this.handleOrderStatus}
                        >
                          <option value="1">{DashboardLanguage.Pending}</option>
                          <option value="2">{orderLanguage.prepared}</option>
                          <option value="3">{orderLanguage.readyToShip}</option>
                          <option value="4">{orderLanguage.shipped}</option>
                          <option value="5">
                            {DashboardLanguage.Delivered}
                          </option>
                          <option value="6">{orderLanguage.cancelled}</option>
                          <option value="7">{orderLanguage.archived}</option>
                          <option value="10">{titleLanguage.Refund}</option>
                          <option value="11">Payment Pending</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div className="row common-space">
                    <div className="col-12">
                      <div className="row">
                        {/* ordered item */}
                        {this.state.product.length > 0 && (
                          <div className="col-md-12">
                            <div className="custom-border">
                              <div className="d-flex p-2 align-items-center justify-content-between">
                                <span className="">
                                  {titleLanguage.Productlist} (
                                  {this.state.p_pieces} {titleLanguage.Pieces})
                                </span>
                                {/* {this.state.product.length > 0 && (
                              <div onClick={this.handleCancel} className="d-flex align-items-center">
                                {this.state.orderStatusCheckBox && this.state.orderStatusValue < 5 ? (
                                  <span name="cancel" className="order-details-txt">
                                    {orderLanguage.CancelItem}
                                  </span>
                                ) : (
                                  <span name="return" className="order-details-txt">
                                    {orderLanguage.ReturnItem}
                                  </span>
                                )}

                                <br />
                                <br />
                              </div>
                            )} */}
                              </div>
                              <div className="custom-table">
                                <div className="table-responsive dataTables_wrapper no-footer">
                                  <table>
                                    <thead>
                                      {this.state.product.length > 0 && (
                                        <tr>
                                          {this.state.orderStatusValue == "1" ||
                                          this.state.orderStatusValue == "2" ? (
                                            <th className="selection-cell-header"></th>
                                          ) : (
                                            ""
                                          )}
                                          <th>{orderLanguage.Items}</th>
                                          <th>{orderLanguage.Details}</th>
                                          <th>{orderLanguage.Size}</th>
                                          <th>{orderLanguage.Price}</th>
                                          <th>{orderLanguage.Qty}</th>
                                          <th>{orderLanguage.Total}</th>
                                        </tr>
                                      )}
                                    </thead>
                                    <tbody>
                                      {this.state.product.length > 0 &&
                                        this.state.product.map((item, i) => {
                                          let qty = Array.from(
                                            { length: item.quantity },
                                            (_, j) => j + 1
                                          );
                                          return (
                                            <tr
                                              className="order-checked"
                                              id={"order-checked-id" + i}
                                              key={i}
                                            >
                                              {this.state.orderStatusValue ==
                                                "1" ||
                                              this.state.orderStatusValue ==
                                                "2" ? (
                                                <td className="selection-cell position-relative">
                                                  <input
                                                    onChange={(e) => {
                                                      this.handleCheckboxChange(
                                                        e,
                                                        i,
                                                        item.id
                                                      );
                                                    }}
                                                    // onClick={(e) =>
                                                    //   this.handleClick(
                                                    //     e,
                                                    //     item.id,
                                                    //     item.order_id,
                                                    //     item.user_id
                                                    //   )
                                                    // }
                                                    id={"cancel-checked" + i}
                                                    className="mx-auto"
                                                    type="checkbox"
                                                    name="CancelItem"
                                                  />

                                                  <div className="request-select">
                                                    <div className="d-flex align-items-center">
                                                      <div>
                                                        <select
                                                          name="reasons"
                                                          onChange={(e) => {
                                                            this.handleCheckBoxChange(
                                                              e,
                                                              item,
                                                              "reason"
                                                            );
                                                          }}
                                                          className="form-select form-contol ms-2 w-auto"
                                                          value={
                                                            this.state.reasons
                                                          }
                                                        >
                                                          <option value={""}>
                                                            {
                                                              orderLanguage.SelectReason
                                                            }
                                                          </option>
                                                          <option
                                                            value={"By Request"}
                                                          >
                                                            {
                                                              orderLanguage.ByRequest
                                                            }
                                                          </option>
                                                          <option
                                                            value={
                                                              "Out of stock"
                                                            }
                                                          >
                                                            {
                                                              orderLanguage.OutOfStock
                                                            }
                                                          </option>
                                                        </select>
                                                      </div>
                                                      <div>
                                                        <select
                                                          className="form-select form-contol ms-3 w-auto"
                                                          name="qtys"
                                                          value={
                                                            this.state.qtys
                                                          }
                                                          onChange={(e) =>
                                                            this.handleCheckBoxChange(
                                                              e,
                                                              item,
                                                              "qty"
                                                            )
                                                          }
                                                        >
                                                          {/* <option>1</option> */}
                                                          {qty.map((q) => (
                                                            <option>{q}</option>
                                                          ))}
                                                          {/* <option>3</option> */}
                                                        </select>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </td>
                                              ) : (
                                                ""
                                              )}
                                              <td>
                                                <div className="edit-option imgWidth">
                                                  <img
                                                    className="imgWidth border rounded "
                                                    src={
                                                      item.image !== null
                                                        ? item.image?.split(
                                                            ","
                                                          )[0]
                                                        : ""
                                                    }
                                                    alt=""
                                                  />
                                                  <button className="edit-btn-class">
                                                    <a
                                                      href={
                                                        "/edit-product/" +
                                                        item.product_id
                                                      }
                                                      target="_blank"
                                                    >
                                                      <i className="bi bi-pencil-fill"></i>
                                                    </a>
                                                  </button>
                                                </div>
                                              </td>
                                              {this.context.language ===
                                              "english" ? (
                                                <>
                                                  <td>
                                                    <p className="mb-0 fw-bold dark-red-txt">
                                                      {item.barcode}
                                                    </p>
                                                    <p className="mb-0">
                                                      {item.title_en}
                                                    </p>
                                                    <p className="mb-0">
                                                      {item.color_en}
                                                    </p>
                                                  </td>
                                                  <td> {item.size_en}</td>
                                                </>
                                              ) : (
                                                <>
                                                  <td>
                                                    <p className="mb-0 fw-bold dark-red-txt">
                                                      {item.barcode}
                                                    </p>
                                                    <p className="mb-0">
                                                      {item.title_ar}
                                                    </p>
                                                    <p className="mb-0">
                                                      {item.color_ar}
                                                    </p>
                                                  </td>
                                                  <td> {item.size_ar}</td>
                                                </>
                                              )}
                                              <td>
                                                <div className="d-flex flex-column">
                                                  {item.discounted_price.toFixed(
                                                    2
                                                  )}
                                                  {item.discount !== 0 && (
                                                    <span className="text-secondary text-decoration-line-through">
                                                      {item.product_price?.toFixed(
                                                        2
                                                      )}
                                                    </span>
                                                  )}
                                                </div>
                                              </td>
                                              <td>{item.quantity}</td>
                                              <td
                                                className={`${
                                                  this.state.detailData[0]
                                                    .discount_type ==
                                                  "percentage"
                                                    ? "fix-width-pattu"
                                                    : ""
                                                }`}
                                              >
                                                {item.total_discounted_price.toFixed(
                                                  2
                                                )}
                                                {this.state.detailData[0]
                                                  .discount_type ==
                                                  "percentage" &&
                                                  (this.state.detailData[0]
                                                    .exclude_sale == 1 ? (
                                                    item.discount == 0 ? (
                                                      <span className="d-block table-total-price">
                                                        After Coupon:
                                                        {item.paymentable_price?.toFixed(
                                                          2
                                                        )}
                                                      </span>
                                                    ) : (
                                                      ""
                                                    )
                                                  ) : (
                                                    <span className="d-block table-total-price">
                                                      After Coupon:
                                                      {item.paymentable_price?.toFixed(
                                                        2
                                                      )}
                                                    </span>
                                                  ))}
                                              </td>
                                            </tr>
                                          );
                                        })}
                                    </tbody>
                                  </table>
                                </div>
                              </div>

                              <div className="row mx-0 my-3">
                                <div className="col-12">
                                  {/* {this.state.product.length > 0 && (
                                <div onClick={this.handleCancel}>
                                  {this.state.orderStatusCheckBox &&
                                    this.state.orderStatusValue < 5 ? (
                                    <span
                                      name="cancel"
                                      className="order-details-txt"
                                    >
                                      {orderLanguage.CancelItem}
                                    </span>
                                  ) : (
                                    <span
                                      name="return"
                                      className="order-details-txt"
                                    >
                                      {orderLanguage.ReturnItem}
                                    </span>
                                  )}

                                  <br />
                                  <br />
                                </div>
                              )} */}
                                  {this.state.product.length > 0 && (
                                    <div className="row mx-0 my-4 modal-form">
                                      <div className="col-xxl-7 col-lg-11 col-md-8 ">
                                        <div>
                                          <div className="form-group">
                                            {/* <label>
                                        {orderLanguage.AddBillingInvoiceNumber}
                                      </label> */}
                                            {/* <input
                                        type="text"
                                        name="invoice_number"
                                        onChange={this.handleChange}
                                        className="form-control"
                                        value={this.state.invoice_number}
                                      /> */}
                                            {/* <select className="form-select form-control">
                                        <option>Select reason</option>
                                      </select> */}
                                          </div>

                                          <div className="row align-items-center text-center">
                                            <div className="col-12">
                                              {/* <button onClick={this.handleSaveInvoiceNumber} className="red-btn w-100">
                                          Cancel selected items

                                          {/* {ButtonLanguage.save} */}
                                              {/* </button>  */}

                                              {this.state.checkButton && (
                                                <div className="d-flex align-items-center">
                                                  <button
                                                    onClick={
                                                      this.handleItemCancel
                                                    }
                                                    className="red-btn w-80"
                                                  >
                                                    {this.state
                                                      .orderStatusCheckBox &&
                                                    this.state
                                                      .orderStatusValue < 5 ? (
                                                      <span name="cancel">
                                                        {" "}
                                                        {
                                                          orderLanguage.CancelItem
                                                        }{" "}
                                                      </span>
                                                    ) : (
                                                      <span name="return">
                                                        {
                                                          orderLanguage.ReturnItem
                                                        }
                                                      </span>
                                                    )}
                                                    {/* {ButtonLanguage.save} */}
                                                  </button>
                                                  <div className="order-details-txt ms-3 cursor-pointer">
                                                    Never mind
                                                  </div>
                                                </div>
                                              )}
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                      {/* {this.state.isBarcodeShow && (
                                  <div className="col-md-7">
                                    <div className="barcode-div">
                                      <Barcode option={option} value={this.state.invoice_number} />
                                    </div>
                                  </div>
                                )} */}
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                        <div className="diff-bg-box mt-3">
                          <div className="row justify-content-end">
                            <div className="col-12 d-sm-flex">
                              <div className="table-fix-coupen">
                                {this.state.detailData[0] &&
                                  (this.state.detailData[0].coupon_discount !==
                                    0 ||
                                    this.state.detailData[0].wallet_cost !==
                                      0) && (
                                    <ul>
                                      {this.state.detailData[0]
                                        .discount_type === "fixed" ? (
                                        <li>
                                          <div className="fix-coupen-class d-flex align-items-center">
                                            <svg
                                              width="15"
                                              height="15"
                                              viewBox="0 0 15 13"
                                              className="me-2"
                                              fill="none"
                                              xmlns="http://www.w3.org/2000/svg"
                                            >
                                              <path
                                                d="M6.59289 1.70776L1.51422 10.1862C1.40951 10.3675 1.35411 10.5731 1.35352 10.7825C1.35293 10.9919 1.40719 11.1978 1.51088 11.3797C1.61457 11.5617 1.76409 11.7132 1.94456 11.8194C2.12504 11.9256 2.33017 11.9827 2.53955 11.985H12.6969C12.9063 11.9827 13.1114 11.9256 13.2919 11.8194C13.4723 11.7132 13.6219 11.5617 13.7256 11.3797C13.8293 11.1978 13.8835 10.9919 13.8829 10.7825C13.8823 10.5731 13.8269 10.3675 13.7222 10.1862L8.64355 1.70776C8.53666 1.53154 8.38615 1.38584 8.20655 1.28473C8.02696 1.18361 7.82433 1.13049 7.61822 1.13049C7.41212 1.13049 7.20949 1.18361 7.02989 1.28473C6.85029 1.38584 6.69979 1.53154 6.59289 1.70776V1.70776Z"
                                                stroke="#A81A1C"
                                                stroke-width="1.5"
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                              />
                                              <path
                                                d="M7.61816 4.78973V7.18816"
                                                stroke="#A81A1C"
                                                stroke-width="1.5"
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                              />
                                              <path
                                                d="M7.61816 9.58661H7.62499"
                                                stroke="#A81A1C"
                                                stroke-width="1.5"
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                              />
                                            </svg>
                                            {orderLanguage.FixedCouponused}
                                          </div>
                                        </li>
                                      ) : this.state.detailData[0]
                                          .discount_type === "percentage" ? (
                                        <li>
                                          <div className="per-coupen-class d-flex align-items-center">
                                            <svg
                                              width="15"
                                              height="13"
                                              viewBox="0 0 15 13"
                                              className="me-2"
                                              fill="none"
                                              xmlns="http://www.w3.org/2000/svg"
                                            >
                                              <path
                                                d="M6.59289 1.57727L1.51422 10.0557C1.40951 10.237 1.35411 10.4426 1.35352 10.652C1.35293 10.8614 1.40719 11.0673 1.51088 11.2492C1.61457 11.4312 1.76409 11.5828 1.94456 11.6889C2.12504 11.7951 2.33017 11.8522 2.53955 11.8545H12.6969C12.9063 11.8522 13.1114 11.7951 13.2919 11.6889C13.4723 11.5828 13.6219 11.4312 13.7256 11.2492C13.8293 11.0673 13.8835 10.8614 13.8829 10.652C13.8823 10.4426 13.8269 10.237 13.7222 10.0557L8.64355 1.57727C8.53666 1.40105 8.38615 1.25535 8.20655 1.15424C8.02696 1.05312 7.82433 1 7.61822 1C7.41212 1 7.20949 1.05312 7.02989 1.15424C6.85029 1.25535 6.69979 1.40105 6.59289 1.57727V1.57727Z"
                                                stroke="#675621"
                                                stroke-width="1.5"
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                              />
                                              <path
                                                d="M7.61816 4.65924V7.05767"
                                                stroke="#675621"
                                                stroke-width="1.5"
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                              />
                                              <path
                                                d="M7.61816 9.45612H7.62499"
                                                stroke="#675621"
                                                stroke-width="1.5"
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                              />
                                            </svg>
                                            % {orderLanguage.Couponused}
                                          </div>
                                        </li>
                                      ) : (
                                        ""
                                      )}
                                      {this.state.detailData[0].wallet_cost !==
                                        0 && (
                                        <li>
                                          <div className="wallet-coupen-class d-flex align-items-center">
                                            <svg
                                              width="14"
                                              height="14"
                                              viewBox="0 0 14 14"
                                              className="me-2"
                                              fill="none"
                                              xmlns="http://www.w3.org/2000/svg"
                                            >
                                              <path
                                                d="M7.19993 6.01412C7.02271 6.01412 6.85274 6.08452 6.72742 6.20984C6.6021 6.33516 6.5317 6.50512 6.5317 6.68235V9.35529C6.5317 9.53252 6.6021 9.70249 6.72742 9.82781C6.85274 9.95312 7.02271 10.0235 7.19993 10.0235C7.37716 10.0235 7.54713 9.95312 7.67245 9.82781C7.79776 9.70249 7.86817 9.53252 7.86817 9.35529V6.68235C7.86817 6.50512 7.79776 6.33516 7.67245 6.20984C7.54713 6.08452 7.37716 6.01412 7.19993 6.01412ZM7.45386 3.39463C7.29117 3.3278 7.10869 3.3278 6.946 3.39463C6.86398 3.42644 6.78904 3.47413 6.72549 3.53496C6.66646 3.59992 6.619 3.6745 6.58516 3.75548C6.54775 3.83479 6.52944 3.92175 6.5317 4.00941C6.53119 4.09735 6.54805 4.18453 6.5813 4.26595C6.61455 4.34737 6.66355 4.42142 6.72549 4.48386C6.79044 4.54288 6.86502 4.59035 6.946 4.62419C7.04724 4.66578 7.15714 4.68187 7.26605 4.67104C7.37496 4.66021 7.47955 4.6228 7.57061 4.56209C7.66168 4.50138 7.73644 4.41923 7.78832 4.32286C7.8402 4.22649 7.86762 4.11886 7.86817 4.00941C7.86571 3.83248 7.79649 3.66302 7.67438 3.53496C7.61083 3.47413 7.53589 3.42644 7.45386 3.39463ZM7.19993 0C5.87829 0 4.58632 0.391913 3.48742 1.12618C2.38851 1.86045 1.53202 2.90409 1.02624 4.12513C0.520473 5.34617 0.388141 6.68976 0.645981 7.98601C0.903821 9.28226 1.54025 10.4729 2.4748 11.4075C3.40934 12.342 4.60002 12.9785 5.89627 13.2363C7.19252 13.4941 8.53612 13.3618 9.75716 12.856C10.9782 12.3503 12.0218 11.4938 12.7561 10.3949C13.4904 9.29596 13.8823 8.00399 13.8823 6.68235C13.8823 5.80481 13.7094 4.93587 13.3736 4.12513C13.0378 3.31439 12.5456 2.57773 11.9251 1.95722C11.3046 1.3367 10.5679 0.844483 9.75716 0.508664C8.94642 0.172844 8.07747 0 7.19993 0ZM7.19993 12.0282C6.14262 12.0282 5.10905 11.7147 4.22992 11.1273C3.35079 10.5399 2.6656 9.70496 2.26098 8.72813C1.85637 7.7513 1.7505 6.67642 1.95677 5.63942C2.16304 4.60242 2.67219 3.64988 3.41982 2.90224C4.16746 2.15461 5.12 1.64546 6.157 1.43919C7.194 1.23292 8.26888 1.33878 9.24571 1.7434C10.2225 2.14802 11.0575 2.83321 11.6449 3.71234C12.2323 4.59146 12.5458 5.62504 12.5458 6.68235C12.5458 8.10017 11.9826 9.45991 10.98 10.4625C9.97749 11.465 8.61775 12.0282 7.19993 12.0282Z"
                                                fill="#3F79AA"
                                              />
                                            </svg>
                                            {orderLanguage.Walletbalanceused}
                                          </div>
                                        </li>
                                      )}
                                    </ul>
                                  )}
                              </div>

                              {/* {this.state.detailData.length > 0 &&
                                this.state.detailData.map((item, i) => {
                                  let SubTotal = 0;
                                  SubTotal = SubTotal + item.price;
                                })} */}
                              {this.state.detailData[0] && (
                                <div className="table-footer-pricing text-end ms-auto">
                                  <ul>
                                    <li>
                                      <span>{orderLanguage.SubTotal} :</span>
                                      <bdi>
                                        {Language.SR}{" "}
                                        {this.state.detailData[0]
                                          .final_ordered_price > 0
                                          ? this.state.detailData[0].final_ordered_price?.toFixed(
                                              2
                                            )
                                          : 0}
                                      </bdi>
                                    </li>
                                    {/* {this.state.detailData[0].total_discount !== 0 && this.state.detailData[0].total_discount !== null && (
                                      <li>
                                        <span>{orderLanguage.Discount} :</span>
                                        <bdi>{Language.SR} -{this.state.detailData[0].total_discount?.toFixed(2)}</bdi>
                                      </li>
                                    )} */}
                                    {this.state.detailData[0]
                                      .coupon_discount !== 0 &&
                                      this.state.detailData[0]
                                        .coupon_discount !== null && (
                                        <li>
                                          <span>
                                            {orderLanguage.voucher}:{" "}
                                            {
                                              this.state.detailData[0]
                                                .coupon_code
                                            }{" "}
                                            (
                                            {
                                              this.state.detailData[0]
                                                .discount_value
                                            }
                                            {this.state.detailData[0]
                                              .discount_type === "fixed"
                                              ? " SR"
                                              : "%"}
                                            ):
                                          </span>
                                          <bdi>
                                            {Language.SR} -
                                            {this.state.detailData[0].coupon_discount?.toFixed(
                                              2
                                            )}
                                          </bdi>
                                        </li>
                                      )}
                                    {this.state.detailData[0]
                                      .orderPrice_includeCoupon > 0 && (
                                      <li className="total-price">
                                        <span>
                                          {this.state.detailData[0].orderPrice_includeCoupon?.toFixed(
                                            2
                                          )}
                                        </span>
                                      </li>
                                    )}

                                    {this.state.detailData[0].shipping_cost !==
                                      0 &&
                                      this.state.detailData[0].shipping_cost !==
                                        null && (
                                        <li>
                                          <span>
                                            {orderLanguage.shippingCharges} :
                                          </span>
                                          <bdi>
                                            {Language.SR}{" "}
                                            {this.state.detailData[0].shipping_cost?.toFixed(
                                              2
                                            )}
                                          </bdi>
                                        </li>
                                      )}
                                    {/* <li>
                                      <span>COD Charge :</span>
                                      <bdi>{this.state.detailData[0].COD_cost}</bdi>
                                    </li> */}
                                    {/* <li className="total-price">
                                      <bdi>SR 2060.00</bdi>
                                    </li> */}
                                    {this.state.detailData[0].plateform_cost !==
                                      0 &&
                                      this.state.detailData[0]
                                        .plateform_cost !== null && (
                                        <li>
                                          <span>Plateform Cost :</span>
                                          <bdi>
                                            {Language.SR}{" "}
                                            {this.state.detailData[0].plateform_cost?.toFixed(
                                              2
                                            )}
                                          </bdi>
                                        </li>
                                      )}
                                    {this.state.detailData[0].COD_cost !== 0 &&
                                      this.state.detailData[0].COD_cost !==
                                        null && (
                                        <li>
                                          <span>
                                            {orderLanguage.CODCharge} :
                                          </span>
                                          <bdi>
                                            {Language.SR}{" "}
                                            {this.state.detailData[0].COD_cost?.toFixed(
                                              2
                                            )}
                                          </bdi>
                                        </li>
                                      )}

                                    {this.state.detailData[0].wallet_cost !==
                                      0 &&
                                      this.state.detailData[0].wallet_cost !==
                                        null && (
                                        <>
                                          <li className="total-price">
                                            <bdi>
                                              {Language.SR}{" "}
                                              {Number(
                                                this.state.detailData[0]
                                                  .COD_cost +
                                                  this.state.detailData[0]
                                                    .shipping_cost -
                                                  this.state.detailData[0]
                                                    .coupon_discount +
                                                  this.state.detailData[0]
                                                    .final_ordered_price
                                              ).toFixed(2)}
                                            </bdi>
                                          </li>
                                          <li>
                                            <span>
                                              {orderLanguage.WalletUsed} :
                                            </span>
                                            <bdi>
                                              {Language.SR} -
                                              {this.state.detailData[0].wallet_cost.toFixed(
                                                2
                                              )}
                                            </bdi>
                                          </li>
                                        </>
                                      )}

                                    <li className="total-price">
                                      <span>{orderLanguage.GrandTotal} :</span>
                                      <bdi>
                                        {Language.SR}{" "}
                                        {(this.state.detailData[0]
                                          .total_paymentable_price >= 0 ||
                                          this.state.detailData[0].pay_method ==
                                            "WALLET") &&
                                          this.state.detailData[0].total_paymentable_price?.toFixed(
                                            2
                                          )}
                                      </bdi>
                                    </li>
                                    {/* <li>
                                      <span>{orderLanguage.refunded} :</span>
                                      <bdi>$-160.00</bdi>
                                    </li> */}
                                    {/* <li className="total-price border-bottom-0">
                                      <span>{orderLanguage.Balance} :</span>
                                      <bdi>$1820.00</bdi>
                                    </li> */}
                                  </ul>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                {this.state.cancelled_item.length > 0 && (
                  <div className="white-box h-auto mt-3 p-0">
                    {/* canceled item  */}
                    <div className="row">
                      <div className="col-md-12">
                        <div className="table-header p-3 border-bottom">
                          <p>{orderLanguage.CancelledItems}</p>
                        </div>
                        <div className="table-responsive dataTables_wrapper no-footer">
                          <table className="order-table-part">
                            <tbody>
                              {this.state.cancelled_item.length > 0 &&
                                this.state.cancelled_item.map((item, i) => {
                                  return (
                                    <tr key={i}>
                                      {/* <td className="selection-cell position-relative">
                                        <input type="checkbox" className="mx-auto" />
                                      </td> */}
                                      <td>
                                        <div className="edit-option imgWidth">
                                          <img
                                            src={item.img}
                                            className="imgWidth border rounded"
                                            alt=""
                                          />
                                          <button className="edit-btn-class">
                                            <a
                                              href={
                                                "/edit-product/" +
                                                item.product_id
                                              }
                                              target="_blank"
                                            >
                                              <i className="bi bi-pencil-fill"></i>
                                            </a>
                                          </button>
                                        </div>
                                      </td>
                                      {this.context.language === "english" ? (
                                        <>
                                          <td>
                                            <span className="d-flex fw-bold dark-red-txt">
                                              {item.barcode}
                                            </span>
                                            <bdi>
                                              {item.title_en}{" "}
                                              <p>{item.color_en}</p>
                                            </bdi>
                                          </td>
                                          <td>
                                            <p className="mb-0">
                                              <span className="status-pending bg-transparent">
                                                {item.reason_item}
                                              </span>
                                            </p>
                                          </td>
                                        </>
                                      ) : (
                                        <>
                                          <td>
                                            <span className="d-flex fw-bold dark-red-txt">
                                              {item.barcode}
                                            </span>
                                            <bdi>
                                              {item.title_ar}{" "}
                                              <p>{item.color_ar}</p>
                                            </bdi>
                                          </td>
                                          <td>
                                            <p className="mb-0">
                                              <span className="status-pending bg-transparent">
                                                {item.reason_item}
                                              </span>
                                            </p>
                                          </td>
                                        </>
                                      )}
                                      <td>{item.cancel_reason}</td>
                                      <td>{item.size_ar}</td>
                                      <td className="text-end">
                                        {item.discounted_price?.toFixed(2)}
                                      </td>
                                      <td className="text-end">1</td>
                                      <td className="text-end">
                                        {Number(item.discounted_price)?.toFixed(
                                          2
                                        ) + " "}
                                        {this.state.detailData[0]
                                          .discount_type == "percentage" && (
                                          <span className="d-block table-total-price">
                                            After Coupon:
                                            {item.paymentable_price?.toFixed(2)}
                                          </span>
                                        )}
                                      </td>
                                    </tr>
                                  );
                                })}
                            </tbody>
                            <tfoot>
                              {this.state.cancelled_item.length > 0 && (
                                <tr>
                                  <td colSpan={4}></td>
                                  <td colSpan={2} className="text-end">
                                    <span>{orderLanguage.RefundAmount} :</span>
                                  </td>
                                  <td colSpan={2} className="text-end">
                                    <bdi className="">
                                      SR {this.state.total1.toFixed(2)}
                                    </bdi>
                                    {this.state.detailData[0].discount_type ==
                                      "percentage" && (
                                      <span className="d-block table-total-price">
                                        After Coupon:
                                        {((100 -
                                          Number(
                                            this.state.detailData[0]
                                              .discount_value
                                          )) *
                                          this.state.total1) /
                                          100}
                                      </span>
                                    )}{" "}
                                  </td>
                                  {/* <td><p className="status-cancelled bg-transparent">{orderLanguage.RequestRefund}</p></td> */}
                                </tr>
                              )}
                            </tfoot>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                {this.state.returned_item.length > 0 && (
                  <div className="white-box h-auto mt-3">
                    {/* Returned item  */}
                    <div className="row mt-3">
                      <div className="col-md-12">
                        <div className="table-header">
                          <p className="dark-red-txt fw-bold text-decoration-underline">
                            {orderLanguage.ReturnedItems}
                          </p>
                        </div>
                        <div className="table-responsive dataTables_wrapper no-footer">
                          <table>
                            {this.state.returned_item.length > 0 &&
                              this.state.returned_item.map((item, i) => {
                                return (
                                  <tbody key={i}>
                                    <tr>
                                      <td className="selection-cell position-relative">
                                        <input
                                          type="checkbox"
                                          className="mx-auto"
                                        />
                                      </td>
                                      <td>
                                        <img
                                          src={item.image?.split(",")[0]}
                                          alt=""
                                          className="imgWidth border rounded"
                                        />
                                      </td>
                                      <td>
                                        <p className="mb-0">
                                          <span className="status-pending bg-transparent">
                                            {item.reason_item}
                                          </span>
                                        </p>
                                        <bdi>
                                          {item.title_en} <p>{item.color_en}</p>
                                        </bdi>
                                      </td>
                                      <td>{item.size}</td>
                                      <td className="text-end">
                                        {item.cart_price /
                                          item.cart_item_quantity}
                                      </td>
                                      <td className="text-end">
                                        {item.cart_item_quantity}
                                      </td>
                                      <td className="text-end">
                                        {Number(item.cart_price)?.toFixed(2)}
                                      </td>
                                    </tr>
                                  </tbody>
                                );
                              })}
                            {this.state.returned_item.length > 0 && (
                              <tfoot>
                                <tr>
                                  <td colSpan={5}></td>
                                  <td className="text-end">
                                    <span>{orderLanguage.RefundAmount} :</span>
                                  </td>
                                  <td className="text-end">
                                    <bdi>SR {this.state.total2}</bdi>
                                  </td>
                                </tr>
                              </tfoot>
                            )}
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                <div className="mt-3 ">
                  <a href="orderactivitylog" className="order-details-txt">
                    {orderLanguage.OrderActivityLogs}
                  </a>
                </div>
              </div>
              <div className="col-xl-4 col-lg-6 mt-md-0 mt-3 p-0">
                <div className="order-detail-rgt-main">
                  <Accordion flush>
                    <Accordion.Item>
                      <Accordion.Header>
                        <div className="order-head-txt">
                          <span>{orderLanguage.billingDetails}</span>
                        </div>
                      </Accordion.Header>
                      <Accordion.Body>
                        <div className="table-responsive">
                          <table className="order-table w-100">
                            {this.state.detailData.length > 0 && (
                              <tbody>
                                <tr>
                                  <td>{orderLanguage.customerName}</td>
                                  <td>
                                    <a
                                      href={`user-details/${this.state.detailData[0]?.user_id}`}
                                      className="red-txt"
                                    >
                                      {this.state.detailData[0]?.user_details
                                        .length > 0 &&
                                        this.state.detailData[0].user_details[0]
                                          .first_name}
                                    </a>
                                  </td>
                                </tr>
                                <tr>
                                  <td>{orderLanguage.Email}</td>
                                  <td>
                                    {this.state.detailData[0]?.user_details
                                      .length > 0 &&
                                      this.state.detailData[0].user_details[0]
                                        .email}
                                  </td>
                                </tr>
                                <tr>
                                  <td>{orderLanguage.phoneNumber}</td>
                                  <td>
                                    <img
                                      src={Verified}
                                      alt=""
                                      className="me-2"
                                    />
                                    {/* <img src={ErrorImg} alt="" className="me-2"/> */}
                                    {this.state.detailData[0].user_details
                                      .length > 0 &&
                                      this.state.detailData[0].user_details[0]
                                        .phone}
                                  </td>
                                </tr>
                                <tr>
                                  <td>
                                    {/* <span className="text-decoration-none">{orderLanguage.order}</span> */}
                                    {orderLanguage.orderHistory}
                                  </td>
                                  <td>
                                    <a
                                      href={
                                        "orders?" +
                                        this.state.detailData[0].user_details[0]
                                          .phone
                                      }
                                      className="red-txt"
                                    >
                                      {this.state.detailData[0]?.total_order
                                        .length > 0 &&
                                        this.state.detailData[0].total_order[0]
                                          .order_count}{" "}
                                      {orderLanguage.orders}
                                    </a>
                                  </td>
                                </tr>
                                <tr>
                                  <td className="text-start">
                                    <span
                                      className="red-txt text-decoration-none cursor-pointer"
                                      onClick={this.sendmsgmodal}
                                    >
                                      {orderLanguage.SendMessage}
                                    </span>
                                  </td>
                                  {/* <td>
                                    <button className="btn gray-red-txt-btn">
                                      {orderLanguage.DownloadInvoice}
                                    </button>
                                  </td> */}
                                </tr>
                              </tbody>
                            )}
                          </table>
                        </div>
                      </Accordion.Body>
                    </Accordion.Item>
                  </Accordion>

                  {isTamaraRefundNotAllowed && (
                    <Alert variant="warning">
                      In case of Tamara, payment capture happens only when the
                      order is shipped
                    </Alert>
                  )}
                  <Accordion flush>
                    <Accordion.Item>
                      <Accordion.Header>
                        <div className="order-head-txt">
                          <span>{orderLanguage.PaymentDetails}</span>
                        </div>
                      </Accordion.Header>
                      <Accordion.Body>
                        <div className="table-responsive">
                          <table className="order-table w-100">
                            {this.state.detailData.length > 0 && (
                              <tbody>
                                <tr>
                                  <td>{orderLanguage.paymentMethod}</td>
                                  <td>
                                    {/* <img src={madaicon} className="me-2" /> */}
                                    {this.context.language === "english" &&
                                      (this.state.detailData[0].pay_method ===
                                      "COD"
                                        ? "COD"
                                        : this.state.detailData[0]
                                            .pay_method === "cardPayment"
                                        ? "Card Payment"
                                        : this.state.detailData[0]
                                            .pay_method === "APPLEPAY"
                                        ? "Apple Pay"
                                        : this.state.detailData[0]
                                            .pay_method === "TABBY"
                                        ? "TABBY"
                                        : this.state.detailData[0]
                                            .pay_method === "TAMARA"
                                        ? "TAMARA"
                                        : "Full Wallet")}
                                    {this.context.language !== "english" &&
                                      (this.state.detailData[0].pay_method ===
                                      "COD"
                                        ? "الدفع عند الإستلام"
                                        : this.state.detailData[0]
                                            .pay_method === "cardPayment"
                                        ? "بطاقة ائتمان"
                                        : this.state.detailData[0]
                                            .pay_method === "APPLEPAY"
                                        ? "أبل باي"
                                        : this.state.detailData[0]
                                            .pay_method === "TABBY"
                                        ? "تابي"
                                        : this.state.detailData[0]
                                            .pay_method === "TAMARA"
                                        ? "تمارا"
                                        : "محفظة كاملة")}
                                  </td>
                                </tr>
                                <tr>
                                  {this.state.detailData[0].pay_method ==
                                  "COD" ? (
                                    <td>{orderLanguage.placedAmount}:</td>
                                  ) : (
                                    <td>{orderLanguage.Paidamount}:</td>
                                  )}
                                  <td>
                                    {this.state.detailData[0]
                                      .total_placed_price ? (
                                      <bdi className="red-txt fw-bold">
                                        {this.state.detailData[0].total_placed_price.toFixed(
                                          2
                                        )}
                                      </bdi>
                                    ) : (
                                      ""
                                    )}
                                  </td>
                                </tr>
                                <tr>
                                  <td>
                                    <span className="red-txt text-decoration-none">
                                      {orderLanguage.capturefund}
                                    </span>
                                  </td>
                                  <td>
                                    <button
                                      disabled={isTamaraRefundNotAllowed}
                                      className="btn gray-red-txt-btn"
                                      onClick={this.refundmodal}
                                    >
                                      {orderLanguage.RefundAmount}
                                    </button>
                                  </td>
                                </tr>
                              </tbody>
                            )}
                          </table>
                        </div>
                        <div className="payment-notes-main">
                          <ul>
                            {this.state.detailData[0] &&
                              this.state.detailData[0].order_payments_refund.map(
                                (item) => {
                                  return (
                                    <li>
                                      <div className="d-flex payment-detail-note border-top-class py-2">
                                        <div>
                                          <span>{`SR.${
                                            item.amount
                                          } refunded to customer ${
                                            item.transaction_type == "wallet"
                                              ? "Wallet"
                                              : item.transaction_type == "card"
                                              ? "card refund"
                                              : "bank account"
                                          }`}</span>
                                          <span className="note-class">
                                            Note: {item.description}
                                          </span>
                                        </div>
                                        <div className="ms-auto">
                                          <bdi>
                                            {moment(item.createdat).format(
                                              "DD-MMM-YYYY hh:mm A"
                                            )}{" "}
                                          </bdi>
                                        </div>
                                      </div>
                                    </li>
                                  );
                                }
                              )}
                            {/* <li>
                              <div className="d-flex payment-detail-note border-top-class py-2">
                                <div>
                                  <span>SR.25 refunded to customer bank account (prepaid)</span>
                                  <span className="note-class">Note: Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span>
                                </div>
                                <div className="ms-auto">
                                  <bdi>17-Apr-2021 12:30 PM </bdi>
                                </div>
                              </div>
                            </li> */}
                          </ul>
                        </div>
                        <div className="border-top-class d-flex amount-refund-class pt-3">
                          <span>{orderLanguage.Amountafterrefund}</span>
                          {this.state.detailData[0] && (
                            <bdi className="ms-auto red-txt fw-bold">
                              {(
                                this.state.detailData[0].total_placed_price.toFixed(
                                  2
                                ) - totalReFund
                              ).toFixed(2)}
                            </bdi>
                          )}
                        </div>
                      </Accordion.Body>
                    </Accordion.Item>
                  </Accordion>
                  {this.state.installments.length > 0 && (
                    <Accordion flush>
                      <Accordion.Item>
                        <Accordion.Header>
                          <div className="order-head-txt d-flex align-items-center">
                            <span>{orderLanguage.InstallmentDetails}</span>
                          </div>
                        </Accordion.Header>
                        <Accordion.Body>
                          <div className="d-flex gap-3 text-center">
                            {this.state.installments.map(
                              ({ amount, due_date }, i) => (
                                <div
                                  key={due_date}
                                  className="py-2 px-3 flex-fill"
                                  style={{
                                    border: "1px solid rgb(212, 212, 212)",
                                    borderRadius: 4,
                                  }}
                                >
                                  <img
                                    src={graphIcons[`graph${25 * (i + 1)}`]}
                                    width={20}
                                    height={20}
                                    alt="installment-icon"
                                  />
                                  <div>
                                    <p
                                      className="m-0 mt-1"
                                      style={{
                                        fontSize: 12,
                                        fontWeight: "bold",
                                      }}
                                    >
                                      {amount}
                                    </p>
                                    <p className="m-0" style={{ fontSize: 12 }}>
                                      {due_date}
                                    </p>
                                  </div>
                                </div>
                              )
                            )}
                          </div>
                        </Accordion.Body>
                      </Accordion.Item>
                    </Accordion>
                  )}
                  <Accordion flush>
                    <Accordion.Item>
                      <Accordion.Header>
                        <div className="order-head-txt d-flex align-items-center">
                          <span>{orderLanguage.ShippingDetails}</span>
                          {/* <a href="#" className="ms-auto red-underline-txt mb-3">Edit</a> */}
                        </div>
                      </Accordion.Header>
                      <Accordion.Body>
                        <div className="table-responsive">
                          <table className="order-table w-100">
                            {this.state.detailData.length > 0 && (
                              <tbody>
                                <tr>
                                  <td>{orderLanguage.phoneNumber}</td>
                                  <td>
                                    {this.state.detailData[0].address.phone?.substring(
                                      0,
                                      3
                                    ) !== "966"
                                      ? this.state.detailData[0].address.phone
                                      : this.state.detailData[0].address.phone.substring(
                                          3
                                        )}
                                    <OverlayTrigger
                                      placement={"bottom"}
                                      delay={{ show: 250, hide: 400 }}
                                      overlay={
                                        <Tooltip>copy phone number</Tooltip>
                                      }
                                    >
                                      <CopyToClipboard
                                        text={
                                          this.state.detailData[0]?.address
                                            ?.phone
                                        }
                                        onCopy={() => toastr.success("Copied.")}
                                      >
                                        <svg
                                          className="ms-2  cursor-pointer"
                                          width={20}
                                          height={20}
                                          viewBox="0 0 18 18"
                                          fill="none"
                                          xmlns="http://www.w3.org/2000/svg"
                                        >
                                          <path
                                            d="M10.6665 17.3333H2.33317C1.88656 17.3488 1.45356 17.1782 1.13757 16.8622C0.821587 16.5462 0.650981 16.1132 0.666501 15.6666V7.33329C0.650981 6.88669 0.821587
                                            6.45369 1.13757 6.1377C1.45356 5.82171 1.88656 5.6511 2.33317 5.66662H5.6665V2.33329C5.65098 1.88669 5.82159 1.45368
                                            6.13758 1.1377C6.45356 0.821709 6.88656 0.651103 7.33317 0.666623H15.6665C16.1131 0.651103 16.5461 0.821709
                                            16.8621 1.1377C17.1781 1.45368 17.3487 1.88669 17.3332 2.33329V10.6666C17.3484 11.1132 17.1778 11.546 16.8618
                                            11.8619C16.5459 12.1779 16.113 12.3486 15.6665 12.3333H12.3332V15.6666C12.3484 16.1132 12.1778
                                            16.546 11.8618 16.8619C11.5459 17.1779 11.113 17.3486 10.6665 17.3333ZM2.33317
                                            7.33329V15.6666H10.6665V12.3333H7.33317C6.88663 12.3486 6.45378 12.1779 6.13785 11.8619C5.82192
                                            11.546 5.65123 11.1132 5.6665 10.6666V7.33329H2.33317ZM7.33317 2.33329V10.6666H15.6665V2.33329H7.33317Z"
                                            fill="#2D2D3B"
                                          />
                                        </svg>
                                      </CopyToClipboard>
                                    </OverlayTrigger>
                                  </td>
                                </tr>
                                <tr>
                                  <td>{orderLanguage.cityArea}</td>
                                  <td>
                                    {this.state.detailData[0].address.city_en}-{" "}
                                    {this.state.detailData[0].address.area_en}
                                  </td>
                                </tr>
                                <tr>
                                  <td>{orderLanguage.address}</td>
                                  <td>
                                    {this.state.detailData[0].address.line_1 +
                                      this.state.detailData[0].address.line_2}
                                    <OverlayTrigger
                                      placement={"bottom"}
                                      delay={{ show: 250, hide: 400 }}
                                      overlay={<Tooltip>Copy address</Tooltip>}
                                    >
                                      <CopyToClipboard
                                        text={
                                          this.state.detailData[0].address
                                            .line_1 +
                                          this.state.detailData[0].address
                                            .line_2
                                        }
                                        onCopy={() => toastr.success("Copied.")}
                                      >
                                        <svg
                                          className="ms-2 cursor-pointer"
                                          width={20}
                                          height={20}
                                          viewBox="0 0 18 18"
                                          fill="none"
                                          xmlns="http://www.w3.org/2000/svg"
                                        >
                                          <path
                                            d="M10.6665 17.3333H2.33317C1.88656 17.3488 1.45356 17.1782 1.13757 16.8622C0.821587 16.5462 0.650981 16.1132 0.666501 15.6666V7.33329C0.650981 6.88669 0.821587
                                            6.45369 1.13757 6.1377C1.45356 5.82171 1.88656 5.6511 2.33317 5.66662H5.6665V2.33329C5.65098 1.88669 5.82159 1.45368
                                            6.13758 1.1377C6.45356 0.821709 6.88656 0.651103 7.33317 0.666623H15.6665C16.1131 0.651103 16.5461 0.821709
                                            16.8621 1.1377C17.1781 1.45368 17.3487 1.88669 17.3332 2.33329V10.6666C17.3484 11.1132 17.1778 11.546 16.8618
                                            11.8619C16.5459 12.1779 16.113 12.3486 15.6665 12.3333H12.3332V15.6666C12.3484 16.1132 12.1778
                                            16.546 11.8618 16.8619C11.5459 17.1779 11.113 17.3486 10.6665 17.3333ZM2.33317
                                            7.33329V15.6666H10.6665V12.3333H7.33317C6.88663 12.3486 6.45378 12.1779 6.13785 11.8619C5.82192
                                            11.546 5.65123 11.1132 5.6665 10.6666V7.33329H2.33317ZM7.33317 2.33329V10.6666H15.6665V2.33329H7.33317Z"
                                            fill="#2D2D3B"
                                          />
                                        </svg>
                                      </CopyToClipboard>
                                    </OverlayTrigger>
                                  </td>
                                </tr>
                              </tbody>
                            )}
                          </table>
                        </div>
                        <div className="order-head-txt d-flex align-items-center border-top py-3">
                          <span>{orderLanguage.TrackingDetails}</span>
                        </div>
                        <div className="table-responsive">
                          <div className="px-3">
                            <div className="form-group modal-form">
                              <div className="d-flex align-items-center mb-1">
                                <label className="m-0">
                                  {orderLanguage.shippingCompany}
                                </label>
                                {canUpdateShipment && (
                                  <div className="ms-auto">
                                    <button
                                      className="btn dark-red-txt "
                                      onClick={this.resetTrackingDetails}
                                    >
                                      {orderLanguage.reset}
                                    </button>
                                  </div>
                                )}
                              </div>
                              <select
                                className="form-control form-select"
                                value={this.state.ShipmentCompany}
                                onChange={this.handleShippingOption}
                                disabled={this.state.ShipmentCompany === "11"}
                              >
                                {this.state.shippingCompanyData?.map((item) => {
                                  return (
                                    <option key={item.id} value={item.id}>
                                      {this.context.language === "english"
                                        ? item.english
                                        : item.arabic}
                                    </option>
                                  );
                                })}
                              </select>
                            </div>
                          </div>

                          {!this.state.isPickupStore && (
                            <>
                              <div className="px-3">
                                <div
                                  className="form-group modal-form"
                                  onChange={this.handleTrackChange}
                                >
                                  <div className="d-flex tracking-modal">
                                    <label>
                                      {orderLanguage.TrackingNumber}
                                    </label>
                                    <span className="ms-auto">
                                      {(this.state.shippingUpdateCode &&
                                        this.state.shippingDescription) !==
                                        "" && (
                                        <span className="text-end">
                                          <bdi className="dark-red-txt me-2">
                                            {this.state.shippingUpdateCode}
                                          </bdi>
                                          {this.state.shippingDescription}
                                        </span>
                                      )}
                                    </span>
                                  </div>
                                  <div className="d-flex ">
                                    <div className="input-group">
                                      {this.state.ShipmentCompany !== "9" && (
                                        <>
                                          <input
                                            type="text"
                                            name="tracking_number"
                                            value={this.state.ShipmentID}
                                            className="form-control"
                                            aria-label="Recipient's username"
                                            aria-describedby="basic-addon2"
                                            readOnly
                                          />
                                          <div className="input-group-append">
                                            <span
                                              className="input-group-text"
                                              id="basic-addon2"
                                            >
                                              <OverlayTrigger
                                                placement={"bottom"}
                                                delay={{ show: 250, hide: 400 }}
                                                overlay={
                                                  <Tooltip>
                                                    copy tracking number
                                                  </Tooltip>
                                                }
                                              >
                                                <CopyToClipboard
                                                  text={this.state.ShipmentID}
                                                  onCopy={() =>
                                                    this.state.ShipmentID
                                                      ? toastr.success(
                                                          "Copied."
                                                        )
                                                      : null
                                                  }
                                                >
                                                  <button
                                                    className="btn btn-text d-flex p-0 border-0"
                                                    disabled={
                                                      !this.state.ShipmentID
                                                    }
                                                  >
                                                    <svg
                                                      className="me-2"
                                                      width={20}
                                                      height={20}
                                                      viewBox="0 0 18 18"
                                                      fill="none"
                                                      xmlns="http://www.w3.org/2000/svg"
                                                    >
                                                      <path
                                                        d="M10.6665 17.3333H2.33317C1.88656 17.3488 1.45356 17.1782 1.13757 16.8622C0.821587 16.5462 0.650981 16.1132 0.666501 15.6666V7.33329C0.650981 6.88669 0.821587
                                                        6.45369 1.13757 6.1377C1.45356 5.82171 1.88656 5.6511 2.33317 5.66662H5.6665V2.33329C5.65098 1.88669 5.82159 1.45368
                                                        6.13758 1.1377C6.45356 0.821709 6.88656 0.651103 7.33317 0.666623H15.6665C16.1131 0.651103 16.5461 0.821709
                                                        16.8621 1.1377C17.1781 1.45368 17.3487 1.88669 17.3332 2.33329V10.6666C17.3484 11.1132 17.1778 11.546 16.8618
                                                        11.8619C16.5459 12.1779 16.113 12.3486 15.6665 12.3333H12.3332V15.6666C12.3484 16.1132 12.1778
                                                        16.546 11.8618 16.8619C11.5459 17.1779 11.113 17.3486 10.6665 17.3333ZM2.33317
                                                        7.33329V15.6666H10.6665V12.3333H7.33317C6.88663 12.3486 6.45378 12.1779 6.13785 11.8619C5.82192
                                                        11.546 5.65123 11.1132 5.6665 10.6666V7.33329H2.33317ZM7.33317
                                                        2.33329V10.6666H15.6665V2.33329H7.33317Z"
                                                        fill="#2D2D3B"
                                                      />
                                                    </svg>
                                                  </button>
                                                </CopyToClipboard>
                                              </OverlayTrigger>
                                              {/* <svg xmlns="http://www.w3.org/2000/svg" width={25} height={25} fill="currentColor" className="bi bi-link-45deg ms-2" viewBox="0 0 18 18">
                                              <path d="M4.715 6.542 3.343 7.914a3 3 0 1 0 4.243 4.243l1.828-1.829A3 3 0 0 0 8.586 5.5L8 6.086a1.002 1.002 0 0 0-.154.199 2 2 0 0 1 .861 3.337L6.88 11.45a2 2 0 1 1-2.83-2.83l.793-.792a4.018 4.018 0 0 1-.128-1.287z" />
                                              <path d="M6.586 4.672A3 3 0 0 0 7.414 9.5l.775-.776a2 2 0 0 1-.896-3.346L9.12 3.55a2 2 0 1 1 2.83 2.83l-.793.792c.112.42.155.855.128 1.287l1.372-1.372a3 3 0 1 0-4.243-4.243L6.586 4.672z" fill="#2D2D3B" />
                                            </svg> */}
                                            </span>
                                          </div>
                                        </>
                                      )}
                                    </div>
                                    <div className="ms-2">
                                      {this.state.ShipmentID !== 0 &&
                                      this.state.ShipmentID ? (
                                        this.state.detailData?.[0]
                                          ?.shipping_company_id === 7 ? (
                                          <a
                                            href={
                                              "https://www.aramex.com/us/en/track/results?mode=0&ShipmentNumber=" +
                                              this.state.ShipmentID
                                            }
                                            rel="noreferrer"
                                            className="black-btn"
                                            target="_blank"
                                          >
                                            {orderLanguage.track}
                                          </a>
                                        ) : this.state.tracking_link ? (
                                          <a
                                            href={this.state.tracking_link}
                                            rel="noreferrer"
                                            className="black-btn"
                                            target="_blank"
                                          >
                                            {orderLanguage.track}
                                          </a>
                                        ) : this.state.coustom_tracking_link !==
                                            "" &&
                                          this.state.ShipmentCompany === "9" ? (
                                          <a
                                            href={
                                              this.state.coustom_tracking_link
                                            }
                                            rel="noreferrer"
                                            className="black-btn"
                                            target="_blank"
                                          >
                                            {orderLanguage.track}
                                          </a>
                                        ) : (
                                          <button
                                            className="black-btn"
                                            onClick={() =>
                                              toastr.error(
                                                "shipment is not created"
                                              )
                                            }
                                          >
                                            {orderLanguage.track}
                                          </button>
                                        )
                                      ) : (
                                        <button
                                          className="black-btn"
                                          onClick={() =>
                                            toastr.error(
                                              "shipment is not created"
                                            )
                                          }
                                        >
                                          {orderLanguage.track}
                                        </button>
                                      )}
                                    </div>
                                  </div>
                                  {this.state.ShipmentID &&
                                    (this.state.ShipmentCompany === "9" ||
                                      this.state.ShipmentCompany === "10" ||
                                      this.state.ShipmentCompany === "11") && (
                                      <div className="form-group">
                                        <input
                                          type="text"
                                          readOnly
                                          name="tracking_link"
                                          className="form-control tracking-link"
                                          value={
                                            this.state.coustom_tracking_link
                                          }
                                          placeholder={
                                            orderLanguage.TrackingLink
                                          }
                                        />
                                      </div>
                                    )}
                                </div>
                              </div>
                              <ul className="table-btn-listed">
                                {this.state.ShipmentCompany === "9" ? (
                                  <button
                                    className="btn black-btn me-2 w-100"
                                    onClick={() =>
                                      this.create_handleShow("Custom")
                                    }
                                  >
                                    {ButtonLanguage.save}
                                  </button>
                                ) : (this.state.ShipmentID === 0 ||
                                    !this.state.ShipmentID) &&
                                  this.state.ShipmentCompany !== "9" ? (
                                  <li className="w-100 me-1">
                                    <button
                                      className="btn black-btn me-2 w-100"
                                      onClick={() =>
                                        this.create_handleShow("shipment")
                                      }
                                    >
                                      {orderLanguage.CreateShipment}
                                    </button>
                                  </li>
                                ) : canUpdateShipment ? (
                                  <li className="w-100 me-1">
                                    <button
                                      className="btn black-btn me-2 w-100"
                                      onClick={() =>
                                        this.create_handleShow("updateShipment")
                                      }
                                    >
                                      {"Update Shipment"}
                                    </button>
                                  </li>
                                ) : (this.state.PickUpID === "" ||
                                    !this.state.PickUpID) &&
                                  this.state.ShipmentCompany !== "9" &&
                                  this.state.shippingUpdateCode ===
                                    "AY-0005" ? (
                                  <li className="w-100 me-1">
                                    <button
                                      className="btn black-btn me-2 w-100"
                                      onClick={() =>
                                        this.create_handleShow("pickup")
                                      }
                                    >
                                      {orderLanguage.CreatePickup}
                                    </button>
                                  </li>
                                ) : (
                                  ""
                                )}
                                {this.state.ShippingLabel &&
                                  this.state.ShippingLabel !== "" && (
                                    <li className="w-100 ms-1">
                                      <a
                                        href={this.state.ShippingLabel}
                                        rel="noreferrer"
                                        className="btn white-btn me-2 py-2 w-100"
                                        download={"shipping.pdf"}
                                        target="_blank"
                                      >
                                        {orderLanguage.ReprintLabel}
                                      </a>
                                    </li>
                                  )}
                              </ul>
                            </>
                          )}
                        </div>
                      </Accordion.Body>
                    </Accordion.Item>
                  </Accordion>
                  <div className="white-box mb-3">
                    <div className="order-head-txt d-flex align-items-center border-bottom py-3">
                      <div>
                        <span>{ButtonLanguage.Privatenote}</span>
                        <p className="mb-0">
                          {ButtonLanguage.Onlyvisibletoyou}
                        </p>
                      </div>
                      <div className="ms-auto">
                        <button
                          className="btn dark-red-txt "
                          onClick={this.addnotes}
                        >
                          + {ButtonLanguage.AddNote}
                        </button>
                      </div>
                    </div>
                    <div className="private-note-main">
                      <ul>
                        {this.state.DisplayNotes.length > 0 &&
                          this.state.DisplayNotes.map((item, i) => {
                            return (
                              <li key={item.id}>
                                <div className="d-flex align-items-center">
                                  <span>
                                    {moment(item.updatedat).format(
                                      "MMM DD, hh:mm A"
                                    )}
                                  </span>
                                  <div className="ms-auto">
                                    <div>
                                      <button className="btn">
                                        <svg
                                          width={17}
                                          height={17}
                                          viewBox="0 0 17 17"
                                          fill="none"
                                          xmlns="http://www.w3.org/2000/svg"
                                          onClick={() =>
                                            this.handleEditNote(item.id)
                                          }
                                        >
                                          <path
                                            d="M1.68333 16.149C1.44956 16.1486 1.22672 16.0501 1.06916 15.8774C0.908699 15.7061 0.828965 15.4745 0.849995 15.2407L1.05416 12.9957L10.4858 3.56738L13.4333 6.51405L4.00416 15.9415L1.75916 16.1457C1.73333 16.1482 1.70749 16.149 1.68333 16.149ZM14.0217 5.92488L11.075 2.97821L12.8425 1.21071C12.9988 1.05423 13.2109 0.966309 13.4321 0.966309C13.6533 0.966309 13.8654 1.05423 14.0217 1.21071L15.7892 2.97821C15.9456 3.13452 16.0336 3.34662 16.0336 3.5678C16.0336 3.78897 15.9456 4.00107 15.7892 4.15738L14.0225 5.92405L14.0217 5.92488Z"
                                            fill="#2D2D3B"
                                          />
                                        </svg>
                                      </button>
                                      <button
                                        className="btn"
                                        onClick={() =>
                                          this.handleDelete(item.id)
                                        }
                                      >
                                        <svg
                                          width={18}
                                          height={20}
                                          viewBox="0 0 18 20"
                                          fill="none"
                                          xmlns="http://www.w3.org/2000/svg"
                                        >
                                          <path
                                            d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
                                            fill="#2D2D3B"
                                          />
                                        </svg>
                                      </button>
                                    </div>
                                  </div>
                                </div>
                                <p>{item.note}</p>
                              </li>
                            );
                          })}
                      </ul>
                    </div>
                  </div>
                  <Accordion flush>
                    <Accordion.Item>
                      <Accordion.Header>
                        <div className="order-head-txt d-flex align-items-center">
                          <span>{ButtonLanguage.InvoiceDetails}</span>
                        </div>
                      </Accordion.Header>
                      <Accordion.Body>
                        <div className="row border-bottom pb-3">
                          <label>{ButtonLanguage.InvoiceQRcode}</label>
                          {this.state.QRCode !== "" && this.state.QRCode && (
                            <div className="col-md-6">
                              <QRCode
                                value={this.state.qeneratecode}
                                size="160"
                              />
                            </div>
                          )}
                          <div className="col-md-6 mt-3">
                            <button
                              className="btn red-btn"
                              onClick={this.handleQrShow}
                            >
                              {this.state.QRCode !== "" && this.state.QRCode
                                ? ButtonLanguage.edit
                                : ButtonLanguage.add}
                            </button>
                          </div>
                        </div>
                        <div className="row border-bottom py-3">
                          <div className="col-md-6 form-group modal-form">
                            <label className="d-block">
                              {ButtonLanguage.ERPInvoiceNumber}
                            </label>
                            <button
                              className="btn red-btn"
                              onClick={this.handleShowInvoiceModal}
                            >
                              {this.state.barcode !== ""
                                ? ButtonLanguage.edit
                                : ButtonLanguage.add}
                            </button>
                          </div>

                          {this.state.isBarcodeShow && (
                            <div className="col-md-6">
                              <div className="barcode-div">
                                <Barcode
                                  option={option}
                                  value={this.state.invoice_number}
                                />
                              </div>
                            </div>
                          )}
                        </div>
                        <div className="row pt-3 align-items-center">
                          <div className="col-md-6">
                            <a
                              href={"invoice/" + this.state.order_id}
                              target="_blank"
                            >
                              <button className="btn dark-red-txt">
                                {ButtonLanguage.DownloadInvoice}
                              </button>
                            </a>
                          </div>
                        </div>
                      </Accordion.Body>
                    </Accordion.Item>
                  </Accordion>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ------------------------modal-cancel-confirm-------------------------- */}
        <Modal
          className=""
          show={this.state.showCancelConfirmModal}
          onHide={this.handleCancelConfirmModalClose}
          size="md"
          centered
        >
          <Modal.Body>
            <div className="return-order-items px-2">
              <h5 className="red-txt ps-3 pb-4 pt-3">
                Where would you like to receive the refund
              </h5>
              <div className="grey-box p-3 mb-4">
                {showRefundToWallet && (
                  <label className="cust-radio mb-0">
                    <input
                      type="radio"
                      name="cancelSource"
                      defaultChecked
                      onChange={(e) => this.handleSelectCancelSource(e, "1")}
                    />
                    <span className="checkmark" />
                    <span className="text-dark">Refund to wallet</span>
                  </label>
                )}
                {/* <p className="pt-3">
                  Return items to any one of our branches in Saudi Arabia.
                  <Link href="" passHref>
                    <a className="red-txt">
                      Easily get your refund or exchange items.
                    </a>
                  </Link>
                  </p> */}
                <label className="cust-radio mb-0 mt-2">
                  <input
                    type="radio"
                    defaultChecked={!showRefundToWallet}
                    name="cancelSource"
                    onChange={(e) => this.handleSelectCancelSource(e, "2")}
                  />
                  <span className="checkmark" />
                  <span className="text-dark">Return to original source</span>
                </label>
              </div>
              {/* <div className="grey-box p-3">
                <label className="cust-radio ps-0">
                  <input
                    type="radio"
                    name="cancelSource"
                    onChange={(e) => this.handleSelectCancelSource(e, "2")}
                  />
                  <span className="design" />
                  <span className="text-dark">Return online</span>
                </label>
                <p className="pt-3">
                  Submit Return request online, our logistics partner will pick
                  the items. Refund will take 3 to 7 for verifying returned
                  items by our team.
                </p>
              </div> */}
              <button
                onClick={this.handleCancel}
                disabled={this.state.activeSpinnerBtn}
                className="red-btn border-0 py-2 rounded w-100"
              >
                {this.state.activeSpinnerBtn ? (
                  <div class="spinner-border text-light"></div>
                ) : (
                  orderLanguage.CancelItem
                )}
              </button>
            </div>
          </Modal.Body>
        </Modal>

        {/* ------------------------modal-shipping-------------------------- */}
        <Modal
          dialogClassName="modal-dialog-centered cust-order-table"
          className="edit-user-modal cust-modal cust-order-table"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.create_show}
          onHide={this.create_userClose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">{ButtonLanguage.ShipmentCreation}</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.create_userClose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            {this.state.detailData.length > 0 && (
              <div
                className={`row modal-form cust-order-modal${
                  this.context.language === "english" ? "" : " ar"
                }`}
              >
                <div className="col-md-6">
                  <div className="row">
                    <div className="col-md-12 mb-3">
                      <div className="modal-txt-head">
                        <span>
                          {this.state.isUpdateShipment
                            ? ButtonLanguage.UpdateShipment
                            : ButtonLanguage.CreateShipment}
                        </span>
                      </div>
                    </div>
                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.QuantityofPieces}</label>
                      {/* <input name="quantity" className="form-control" type="text" placeholder="Enter quantity" onChange={this.handleChange} value={this.state.quantity} /> */}
                      <select
                        name="quantity"
                        className="form-select form-control"
                        onChange={this.handleChange}
                        value={this.state.quantity}
                        required
                        disabled={
                          (enableFieldsOnUpdate &&
                            !enableFieldsOnUpdate.includes("quantity")) ??
                          false
                        }
                      >
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                      </select>
                    </div>

                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.ShippingCompany}</label>
                      <select
                        className="form-select form-control"
                        name="shippingCompany"
                        onChange={this.handleShippingCompanyChange}
                        value={this.state.shippingCompany}
                        disabled={
                          this.state.ShipmentCompany === "11" ||
                          ((enableFieldsOnUpdate &&
                            !enableFieldsOnUpdate.includes(
                              "shippingCompany"
                            )) ??
                            false)
                        }
                        required
                      >
                        <option value="">
                          {ButtonLanguage.ShippingCompany}
                        </option>
                        {this.state.shippingCompanyData?.map((item) => {
                          return (
                            <option key={item.id} value={item.id}>
                              {this.context.language === "english"
                                ? item.english
                                : item.arabic}
                            </option>
                          );
                        })}
                      </select>
                    </div>
                    {/* only redbox */}
                    {(this.state.detailData[0].shipping_company === "Red Box" ||
                      this.isShippingCompanyRedbox()) && (
                      <>
                        <div className="col-md-12 form-group d-flex align-items-center">
                          <label>{ButtonLanguage.warehouse}</label>
                          <select
                            name="warehouse"
                            onChange={this.handleChange}
                            value={this.state.warehouse}
                            className="form-select form-control"
                            required
                            disabled={
                              (enableFieldsOnUpdate &&
                                !enableFieldsOnUpdate.includes("warehouse")) ??
                              false
                            }
                          >
                            {this.state.warehouses.map((item) => {
                              return (
                                <option value={item.id} key={item.id}>
                                  {item.address}
                                </option>
                              );
                            })}
                          </select>
                        </div>
                        {/* <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.DimesnsionsUnit}</label>
                      <select name="dimensionUnit" className="form-select form-control" onChange={this.handleChange} value={this.state.dimensionUnit}>
                        <option value="cm">CM</option>
                        <option value="m">M</option>
                        <option value="ft">FT</option>
                      </select>
                    </div>

                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.DimesnsionsWidth}</label>
                      <input className="form-control" type="number" name="dimensionWidth" onChange={this.handleChange} value={this.state.dimensionWidth} />
                    </div>

                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.DimesnsionsHeight}</label>
                      <input className="form-control" type="number" name="dimensionHeigth" onChange={this.handleChange} value={this.state.dimensionHeigth} />
                    </div>

                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.DimesnsionsLength}</label>
                      <input className="form-control" type="number" name="dimensionLength" onChange={this.handleChange} value={this.state.dimensionLength} />
                    </div>

                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.WeightUnit}</label>
                      <select name="weightUnit" className="form-select form-control" onChange={this.handleChange} value={this.state.weightUnit}>
                        <option value="gm">GM</option>
                        <option value="kg">KG</option>
                      </select>
                    </div>

                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.WeightValue}</label>
                      <input className="form-control" type="number" placeholder="Enter Weight" name="weightValue" onChange={this.handleChange} value={this.state.weightValue} />
                    </div> */}
                      </>
                    )}
                    {/* only redbox */}

                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.Labeltype}</label>
                      <select
                        className="form-select form-control"
                        name="labelType"
                        onChange={this.handleChange}
                        value={this.state.labelType}
                        disabled={
                          (enableFieldsOnUpdate &&
                            !enableFieldsOnUpdate.includes("labelType")) ??
                          false
                        }
                      >
                        <option value="">Select label</option>
                        <option value="6x4 Thermal printer" selected>
                          6x4 Thermal printer
                        </option>
                      </select>
                    </div>
                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.Customername}</label>
                      <input
                        className="form-control"
                        type="text"
                        placeholder="Enter customer name"
                        name="shipmentCustomerName"
                        onChange={this.handleChange}
                        value={this.state.shipmentCustomerName}
                        disabled={
                          (enableFieldsOnUpdate &&
                            !enableFieldsOnUpdate.includes("customerName")) ??
                          false
                        }
                      />
                    </div>
                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.PhoneNumber}</label>
                      <input
                        className="form-control"
                        type="text"
                        placeholder="Enter phone number"
                        name="phoneNumber"
                        onChange={this.handleChange}
                        value={this.state.phoneNumber}
                        disabled={
                          (enableFieldsOnUpdate &&
                            !enableFieldsOnUpdate.includes("phoneNumber")) ??
                          false
                        }
                      />
                    </div>
                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.EmailAddress}</label>
                      <input
                        className="form-control"
                        type="email"
                        placeholder="Enter email"
                        name="email"
                        onChange={this.handleChange}
                        value={this.state.email}
                        disabled={
                          (enableFieldsOnUpdate &&
                            !enableFieldsOnUpdate.includes("email")) ??
                          false
                        }
                      />
                    </div>
                    {this.state.shippingCompany === "10" ? (
                      <>
                        <div className="col-md-12 form-group d-flex align-items-center">
                          <label>{ButtonLanguage.City}</label>
                          <select
                            className="form-select input-custom-class"
                            name="city"
                            required
                            onChange={(e) => {
                              this.handleChange(e);
                              this.getAreaByCity(e.target.value);
                            }}
                            value={this.state.city}
                            disabled={
                              (enableFieldsOnUpdate &&
                                !enableFieldsOnUpdate.includes("city")) ??
                              false
                            }
                          >
                            <option value="">
                              {ButtonLanguage.Selectcity}
                            </option>
                            {this.state.AllCity.length > 0 &&
                              this.state.AllCity.map((item) => {
                                return (
                                  <option key={item.id} value={item.id}>
                                    {item.english}
                                  </option>
                                );
                              })}
                          </select>
                        </div>
                        <div className="col-md-12 form-group d-flex align-items-center">
                          <label>{UserLanguage.Area}</label>
                          <select
                            className="form-select input-custom-class"
                            name="area"
                            required
                            onChange={this.handleChange}
                            value={this.state.area}
                            disabled={
                              (enableFieldsOnUpdate &&
                                !enableFieldsOnUpdate.includes("area")) ??
                              false
                            }
                          >
                            <option value="">{UserLanguage.SelectArea}</option>
                            {this.state.AllArea.length > 0 &&
                              this.state.AllArea.map((item) => {
                                return (
                                  <option key={item.id} value={item.id}>
                                    {item.english}
                                  </option>
                                );
                              })}
                          </select>
                        </div>
                      </>
                    ) : (
                      <div className="col-md-12 form-group d-flex align-items-center">
                        <label>{ButtonLanguage.CityArea}</label>
                        <input
                          className="form-control"
                          type="text"
                          placeholder="Enter city-area name"
                          name="cityArea"
                          onChange={this.handleChange}
                          value={this.state.cityArea}
                          disabled={
                            (enableFieldsOnUpdate &&
                              !enableFieldsOnUpdate.includes("cityArea")) ??
                            false
                          }
                        />
                      </div>
                    )}
                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.Addressline} 1</label>
                      <input
                        className="form-control"
                        type="text"
                        placeholder="Enter Address line 1"
                        name="line_1"
                        onChange={this.handleChange}
                        value={this.state.line_1}
                        disabled={
                          (enableFieldsOnUpdate &&
                            !enableFieldsOnUpdate.includes("line_1")) ??
                          false
                        }
                      />
                    </div>
                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.Addressline} 2</label>
                      <input
                        className="form-control"
                        type="text"
                        placeholder="Enter Address line 2"
                        name="line_2"
                        onChange={this.handleChange}
                        value={this.state.line_2}
                        disabled={
                          (enableFieldsOnUpdate &&
                            !enableFieldsOnUpdate.includes("line_2")) ??
                          false
                        }
                      />
                    </div>
                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.ReferenceNo}</label>
                      <input
                        className="form-control"
                        type="text"
                        placeholder="Enter Reference number"
                        name="referenceNumber"
                        onChange={this.handleChange}
                        value={this.state.referenceNumber}
                        disabled={
                          (enableFieldsOnUpdate &&
                            !enableFieldsOnUpdate.includes(
                              "referenceNumber"
                            )) ??
                          false
                        }
                      />
                    </div>
                    {this.state.isUpdateShipment && (
                      <div className="col-md-12 form-group d-flex align-items-center">
                        <label>{orderLanguage.TrackingNumber}</label>
                        <input
                          className="form-control"
                          type="text"
                          placeholder="Enter Tracking number"
                          name="trackingNumber"
                          onChange={this.handleChange}
                          value={this.state.trackingNumber}
                          disabled={
                            (enableFieldsOnUpdate &&
                              !enableFieldsOnUpdate.includes(
                                "trackingNumber"
                              )) ??
                            false
                          }
                        />
                      </div>
                    )}
                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.CODValue}</label>
                      <input
                        className="form-control"
                        type="number"
                        placeholder="Enter COD value"
                        name="codValue"
                        onChange={this.handleChange}
                        value={this.state.codValue}
                        disabled={
                          (enableFieldsOnUpdate &&
                            !enableFieldsOnUpdate.includes("codValue")) ??
                          false
                        }
                      />
                    </div>
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="row">
                    <div className="col-md-12 mb-3">
                      <div className="modal-txt-head">
                        <span>{ButtonLanguage.ShippingFrom}</span>
                      </div>
                    </div>
                    <div className="col-md-12">
                      <div className="table-responsive">
                        <table className="order-table w-100">
                          <tbody>
                            <tr>
                              <td>{orderLanguage.shipperName}</td>
                              <td>
                                {this.state.ShipperData.contact_name &&
                                  this.state.ShipperData.contact_name}
                              </td>
                            </tr>
                            <tr>
                              <td>{orderLanguage.Email}</td>
                              <td>
                                {this.state.ShipperData.email
                                  ? this.state.ShipperData.email
                                  : ""}
                              </td>
                            </tr>
                            <tr>
                              <td>{ButtonLanguage.PhoneNumber}</td>
                              <td>
                                {this.state.ShipperData.contact_number
                                  ? this.state.ShipperData.contact_number
                                  : ""}
                              </td>
                            </tr>
                            <tr>
                              <td>{ButtonLanguage.City}</td>
                              <td>
                                {this.context.language === "english"
                                  ? this.state.ShipperData.city_detail &&
                                    this.state.ShipperData.city_detail[0]
                                      ?.english
                                  : this.state.ShipperData.city_detail &&
                                    this.state.ShipperData.city_detail[0]
                                      ?.arabic}
                              </td>
                            </tr>
                            <tr>
                              <td>{ButtonLanguage.Address}</td>
                              <td>
                                {this.state.ShipperData.address &&
                                  this.state.ShipperData.address}
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div className="col-md-12 mt-3">
                      {/* <div className="modal-txt-head">
                        <span>Shipment Comments</span>
                      </div>
                      <div className="custom-border mt-3">
                        <div className="notes-data">
                          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                        </div>
                      </div> */}
                      <div className="modal-txt-head mb-2">
                        <span>{ButtonLanguage.ShipmentComments}</span>
                      </div>
                      <textarea
                        rows="10"
                        name="shipmentComments"
                        className="form-control input-custom-class h-auto p-3"
                        placeholder="Add shipment comments"
                        onChange={this.handleChange}
                        value={this.state.shipmentComments}
                      />
                    </div>
                    {this.state.orderStatusValue !== 2 && (
                      <div className="col-md-12 mt-3">
                        <div className="cust-checkbox-new">
                          <label className="cust-chk-bx">
                            <input
                              type="checkbox"
                              name="pickupRequest"
                              onChange={this.handleChange}
                            />
                            <span className="cust-chkmark" />
                            <span className="ps-2">Create pickup request</span>
                          </label>
                        </div>
                      </div>
                    )}
                    {this.state.pickupRequest ? (
                      <div className="col-md-12 mt-3">
                        {this.state.shippingCompany !== "11" ? (
                          <>
                            <div>
                              <label>Ready Time</label>
                              {this.state.ReadyTime === "" &&
                                this.state.validation && (
                                  <span className="red-txt"> Require</span>
                                )}
                              <input
                                type="datetime-local"
                                className="form-control"
                                name="ReadyTime"
                                value={this.state.ReadyTime}
                                onChange={this.handleChange}
                              />
                            </div>
                            <div>
                              <label>Pickup Date</label>
                              {this.state.PickupDate === "" &&
                                this.state.validation && (
                                  <span className="red-txt"> Require</span>
                                )}
                              <input
                                type="datetime-local"
                                className="form-control"
                                name="PickupDate"
                                value={this.state.PickupDate}
                                onChange={this.handleChange}
                                min={moment().format("YYYY-MM-DDT00:00")}
                                max={moment()
                                  .add(7, "day")
                                  .format("YYYY-MM-DDT00:00")}
                              />
                            </div>
                            <div>
                              <label>LastPickup Time</label>
                              {this.state.LastPickupTime === "" &&
                                this.state.validation && (
                                  <span className="red-txt"> Require</span>
                                )}
                              <input
                                type="datetime-local"
                                className="form-control"
                                name="LastPickupTime"
                                value={this.state.LastPickupTime}
                                onChange={this.handleChange}
                              />
                            </div>
                            <div>
                              <label>Closing Time</label>
                              {this.state.ClosingTime === "" &&
                                this.state.validation && (
                                  <span className="red-txt"> Require</span>
                                )}
                              <input
                                type="datetime-local"
                                className="form-control"
                                name="ClosingTime"
                                value={this.state.ClosingTime}
                                onChange={this.handleChange}
                              />
                            </div>
                          </>
                        ) : (
                          <>
                            <div>
                              <label>Pickup Time</label>
                              {this.state.redboxPickupTime === "" &&
                                this.state.validation && (
                                  <span className="red-txt"> Require</span>
                                )}
                              <input
                                type="time"
                                className="form-control"
                                name="redboxPickupTime"
                                value={this.state.redboxPickupTime}
                                onChange={this.handleChange}
                              />
                            </div>
                            {/* <div>
                                <label>Notes</label>
                                <textarea
                                  rows="3"
                                  name="redboxPickupNotes"
                                  className="form-control input-custom-class h-auto p-3"
                                  placeholder="Add notes"
                                  onChange={this.handleChange}
                                  value={this.state.redboxPickupNotes}
                                />
                              </div> */}
                          </>
                        )}
                      </div>
                    ) : (
                      ""
                    )}
                  </div>
                </div>
                {/* <div className="col-md-12 form-group mt-3">
                  <label>Old Shipments :</label>
                  <p className="dark-red-txt">12345687903648.pdf</p>
                </div> */}
                <div className="col-md-12 text-md-end text-center">
                  <div className="common-red-btn">
                    <a
                      className="btn gray-red-txt-btn me-2"
                      onClick={this.create_userClose}
                    >
                      Reset
                    </a>
                    <a
                      onClick={this.handleCreateShipment}
                      className="btn red-btn "
                    >
                      {this.state.isUpdateShipment
                        ? orderLanguage.update
                        : "Create"}
                    </a>
                  </div>
                </div>
              </div>
            )}
          </Modal.Body>
        </Modal>

        {/* ========== send SMS ========== */}
        <Modal
          dialogClassName="modal-dialog-centered cust-modal-white-content"
          className="cust-white-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.sendmsgmodal}
          onHide={this.sendmsgmodalclose}
          size="xl"
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">
                {ButtonLanguage.Sendmessagecustomer}
              </h1>
              <p>{ButtonLanguage.Forwriteshortmessage}</p>
            </Modal.Title>
            <button
              type="button"
              onClick={this.sendmsgmodalclose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <>
              <form onSubmit={this.sendMsgViaEmail}>
                <div className="row modal-form cust-white-modal align-items-center">
                  <div className="col-md-12">
                    <textarea
                      className="form-control h-auto"
                      rows="9"
                      name="message"
                      onChange={this.handleMessageChange}
                    >
                      {`Message from Libsimarkah related to order number: ${this.state.order_id} ${this.state.messageTextBox}`}
                    </textarea>
                  </div>
                  <div className="col-lg-6 mb-lg-0 mb-3 cust-send-msg">
                    <ul className="d-sm-flex align-items-center">
                      <li>
                        <div className="cust-checkbox-new">
                          <label className="cust-chk-bx">
                            <input type="checkbox" />
                            <span className="cust-chkmark" />
                            <svg
                              className="me-2"
                              width={24}
                              height={24}
                              viewBox="0 0 24 24"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <path
                                fillRule="evenodd"
                                clipRule="evenodd"
                                d="M12 24C18.6274 24 24 18.6274 24 12C24 5.37258 18.6274 0 12 0C5.37258 0 0 5.37258 0 12C0 14.1522 0.566569 16.172 1.55869 17.9185L0 24L6.26988 22.5461C7.97261 23.4732 9.92479 24 12 24ZM12 22.1538C17.6078 22.1538 22.1538 17.6078 22.1538 12C22.1538 6.39219 17.6078 1.84615 12 1.84615C6.39219 1.84615 1.84615 6.39219 1.84615 12C1.84615 14.1652 2.52386 16.1721 3.67872 17.8202L2.76923 21.2308L6.23994 20.3631C7.8766 21.4925 9.86106 22.1538 12 22.1538Z"
                                fill="#A81A1C"
                              />
                              <path
                                d="M9.00002 6.42827C8.71471 5.8552 8.27702 5.90593 7.83486 5.90593C7.04465 5.90593 5.8125 6.85246 5.8125 8.61404C5.8125 10.0577 6.44867 11.6381 8.59236 14.0022C10.6612 16.2837 13.3795 17.4639 15.6362 17.4237C17.8929 17.3836 18.3572 15.4416 18.3572 14.7858C18.3572 14.4951 18.1768 14.3501 18.0525 14.3107C17.2835 13.9416 15.8651 13.2539 15.5424 13.1247C15.2197 12.9955 15.0512 13.1703 14.9464 13.2653C14.6538 13.5442 14.0736 14.3662 13.875 14.551C13.6764 14.7359 13.3802 14.6424 13.257 14.5725C12.8035 14.3905 11.5739 13.8436 10.5938 12.8935C9.38171 11.7185 9.31057 11.3142 9.0822 10.9543C8.89951 10.6665 9.03357 10.4898 9.10047 10.4126C9.36163 10.1113 9.72223 9.64607 9.88395 9.41487C10.0457 9.18368 9.91728 8.83266 9.84025 8.61404C9.50895 7.6738 9.22827 6.88672 9.00002 6.42827Z"
                                fill="#A81A1C"
                              />
                            </svg>
                            {ButtonLanguage.Whatsapp}
                          </label>
                        </div>
                      </li>
                      <li>
                        <div className="cust-checkbox-new">
                          <label className="cust-chk-bx">
                            <input type="checkbox" />
                            <span className="cust-chkmark" />
                            <svg
                              className="me-2"
                              width={20}
                              height={20}
                              viewBox="0 0 20 20"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <path
                                d="M2 2H18V14H3.17L2 15.17V2ZM2 0C0.9 0 0.00999999 0.9 0.00999999 2L0 20L4 16H18C19.1 16 20 15.1 20 14V2C20 0.9 19.1 0 18 0H2ZM4 10H12V12H4V10ZM4 7H16V9H4V7ZM4 4H16V6H4V4Z"
                                fill="#A81A1C"
                              />
                            </svg>
                            SMS
                          </label>
                        </div>
                      </li>
                      <li>
                        <div className="cust-checkbox-new">
                          <label className="cust-chk-bx">
                            <input type="checkbox" />
                            <span className="cust-chkmark" />
                            <svg
                              className="me-2"
                              width={21}
                              height={19}
                              viewBox="0 0 21 19"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <path
                                d="M18 0H2C0.9 0 0 0.9 0 2V14C0 15.1 0.9 16 2 16H11V14H2V4L10 9L18 4V9H20V2C20 0.9 19.1 0 18 0ZM10 7L2 2H18L10 7ZM17 11L21 15L17 19V16H13V14H17V11Z"
                                fill="#A81A1C"
                              />
                            </svg>
                            {ButtonLanguage.Email}
                          </label>
                        </div>
                      </li>
                    </ul>
                  </div>
                  <div className="col-lg-6 text-lg-end text-center">
                    <div className="common-red-btn">
                      <button
                        className="btn red-border-btn  me-2"
                        onClick={this.sendmsgmodalclose}
                      >
                        {ButtonLanguage.cancel}
                      </button>
                      <button className="btn red-btn" type="submit">
                        {ButtonLanguage.Send}
                      </button>
                    </div>
                  </div>
                </div>
              </form>
            </>
          </Modal.Body>
        </Modal>

        {/* ========== refund ========== */}
        <Modal
          dialogClassName="modal-dialog-centered cust-modal-white-content"
          className="cust-white-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.refundmodal}
          onHide={this.refundmodalclose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">{ButtonLanguage.RefundCustomer}</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.refundmodalclose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <div className="row modal-form cust-white-modal align-items-center">
              <div className="col-md-12 form-group">
                <ul>
                  <li>
                    <label className="cust-radio mb-3">
                      <input
                        type="radio"
                        id="1"
                        value="card"
                        name="RefundMode"
                        onChange={this.handleRefundChange}
                      />
                      <span className="checkmark"></span>
                      <span>{ButtonLanguage.RefundCard}</span>
                    </label>
                  </li>
                  <li>
                    <label className="cust-radio mb-3">
                      <input
                        type="radio"
                        id="2"
                        value="wallet"
                        name="RefundMode"
                        onChange={this.handleRefundChange}
                      />
                      <span className="checkmark"></span>
                      <span>{ButtonLanguage.Refundwallet}</span>
                    </label>
                  </li>
                  <li>
                    <label className="cust-radio mb-3">
                      <input
                        type="radio"
                        id="3"
                        value="bank"
                        name="RefundMode"
                        onChange={this.handleRefundChange}
                      />
                      <span className="checkmark"></span>
                      <span>{ButtonLanguage.Refundbanktransfer}</span>
                    </label>
                  </li>
                  {/* {
                    this.state.detailData[0]?.pay_method === "TABBY" && 
                    <li>
                      <label className="cust-radio mb-3">
                        <input type="radio" id="3" value="TABBY" name="RefundMode" onChange={this.handleRefundChange} />
                        <span className="checkmark"></span>
                        <span>{ButtonLanguage.RefundTabby}</span>
                      </label>
                    </li>
                  } */}
                </ul>
                <label>{ButtonLanguage.SetRefundAmount}</label>
                <ul>
                  <li>
                    <label className="cust-radio mb-3">
                      <input
                        type="radio"
                        id="0"
                        value="full"
                        name="refundAmountType"
                        onChange={this.handleRefundChange}
                      />
                      <span className="checkmark"></span>
                      <span>{ButtonLanguage.FullAmount}</span>
                      {this.state.detailData[0] && (
                        <bdi className="ms-3 order-details-txt dark-red-txt">
                          SR{" "}
                          {(
                            Number(
                              this.state.detailData[0].total_placed_price
                            ) - totalReFund
                          ).toFixed(2)}
                        </bdi>
                      )}
                    </label>
                  </li>
                  <li className="d-flex align-items-center">
                    <label className="cust-radio mb-3">
                      <input
                        type="radio"
                        id="1"
                        value="partial"
                        name="refundAmountType"
                        onChange={this.handleRefundChange}
                      />
                      <span className="checkmark"></span>
                      <span>{ButtonLanguage.PartialAmount}</span>
                    </label>
                    {this.state.r_amount ? (
                      <input
                        type="number"
                        className="form-control w-auto ms-2"
                        name="refund_amount"
                        value={this.state.refund_amount}
                        onChange={this.handleRefundinputChange}
                        onWheel={(e) => {
                          e.target?.value?.blur?.();
                        }}
                        min="1"
                      />
                    ) : (
                      ""
                    )}
                  </li>
                </ul>
              </div>
              <div className="col-md-12 form-group">
                <label>{ButtonLanguage.Notes}</label>
                <textarea
                  className="form-control h-auto"
                  rows="4"
                  name="RefundDescription"
                  onChange={this.handleRefundChange}
                ></textarea>
              </div>

              <div className="col-lg-12 text-lg-end text-center">
                <div className="common-red-btn">
                  <button
                    className="btn red-border-btn  me-2"
                    type="button"
                    onClick={this.refundmodalclose}
                  >
                    {ButtonLanguage.cancel}
                  </button>
                  <button
                    className="btn red-btn "
                    type="button"
                    onClick={this.CreateRefund}
                  >
                    {ButtonLanguage.Send}
                  </button>
                </div>
              </div>
            </div>
          </Modal.Body>
        </Modal>

        {/* ========= add note =========== */}
        <Modal
          dialogClassName="modal-dialog-centered cust-modal-white-content"
          className="cust-white-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.addnotes}
          onHide={this.addnotesclose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">{ButtonLanguage.Privatenote}</h1>
              <p>{ButtonLanguage.Onlyvisibletoyou}</p>
            </Modal.Title>
            <button
              type="button"
              onClick={this.addnotesclose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <form onSubmit={this.submitNote}>
              <div className="row modal-form cust-white-modal align-items-center">
                <div className="col-md-12 form-group">
                  <textarea
                    className="form-control h-auto"
                    name="notes"
                    value={this.state.notes}
                    onChange={this.handleNote}
                    rows="4"
                  ></textarea>
                </div>

                <div className="col-lg-12 text-lg-end text-center">
                  <div className="common-red-btn">
                    <button
                      className="btn red-border-btn  me-2"
                      type="reset"
                      onClick={this.addnotesclose}
                    >
                      {ButtonLanguage.cancel}
                    </button>
                    <button
                      className="btn red-btn "
                      type="submit"
                      onClick={this.SaveNote}
                    >
                      {ButtonLanguage.save}
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </Modal.Body>
        </Modal>

        {/* ========= edit note =========== */}
        <Modal
          dialogClassName="modal-dialog-centered cust-modal-white-content"
          className="cust-white-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.Editaddnotes}
          onHide={this.addnotesclose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">Private note</h1>
              <p>Only visible to you</p>
            </Modal.Title>
            <button
              type="button"
              onClick={this.Editaddnotesclose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <form onSubmit={this.submitNote}>
              <div className="row modal-form cust-white-modal align-items-center">
                <div className="col-md-12 form-group">
                  <textarea
                    className="form-control h-auto"
                    name="Editnotes"
                    value={this.state.Editnotes}
                    onChange={this.handleNote}
                    rows="4"
                  ></textarea>
                </div>

                <div className="col-lg-12 text-lg-end text-center">
                  <div className="common-red-btn">
                    <button
                      className="btn red-border-btn  me-2"
                      type="reset"
                      onClick={this.Editaddnotesclose}
                    >
                      Cancel
                    </button>
                    <button
                      className="btn red-btn "
                      type="submit"
                      onClick={this.EditNote}
                    >
                      Save
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </Modal.Body>
        </Modal>

        {/* ========= add invoice number =========== */}
        <Modal
          dialogClassName="modal-dialog-centered cust-modal-white-content"
          className="cust-white-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.invoice_show}
          onHide={this.handleCloseInvoiceModal}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">{ButtonLanguage.InvoiceNumber}</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.handleCloseInvoiceModal}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <form onSubmit={this.submitNote}>
              <div className="row modal-form cust-white-modal align-items-center">
                <div className="col-md-12 form-group">
                  <input
                    type="text"
                    className="form-control"
                    placeholder={ButtonLanguage.PleaseEnterInvoiceNumber}
                    name="invoice_number"
                    value={this.state.invoice_number}
                    onChange={this.barcode}
                  />
                </div>

                <div className="col-lg-12 text-lg-end text-center">
                  <div className="common-red-btn">
                    <button
                      className="btn red-border-btn  me-2"
                      type="reset"
                      onClick={this.handleCloseInvoiceModal}
                    >
                      {ButtonLanguage.cancel}
                    </button>
                    <button
                      className="btn black-btn"
                      onClick={this.handleSaveInvoiceNumber}
                    >
                      {ButtonLanguage.save}
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </Modal.Body>
        </Modal>

        {/* ===================================add-qr-e-hash======================================== */}
        <Modal
          dialogClassName="modal-dialog-centered cust-modal-white-content"
          className="cust-white-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.qr_invoice_show}
          onHide={this.handleCloseQrInvoiceModal}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">{ButtonLanguage.InvoiceNumber}</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.handleCloseQrInvoiceModal}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <form onSubmit={this.submitNote}>
              <div className="row modal-form cust-white-modal align-items-center">
                <div className="col-md-12 form-group">
                  <input
                    type="text"
                    className="form-control"
                    placeholder={ButtonLanguage.PleaseEnterInvoiceNumber}
                    name="qr_invoice_number"
                    value={this.state.qr_invoice_number}
                    onChange={this.QRCode}
                  />
                </div>

                <div className="col-lg-12 text-lg-end text-center">
                  <div className="common-red-btn">
                    <button
                      className="btn red-border-btn  me-2"
                      type="reset"
                      onClick={this.handleCloseQrInvoiceModal}
                    >
                      {ButtonLanguage.cancel}
                    </button>
                    <button
                      className="btn black-btn"
                      onClick={this.handleSaveQRInvoiceNumber}
                    >
                      {ButtonLanguage.save}
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </Modal.Body>
        </Modal>

        {/* ===================================confirm-cancel======================================== */}
        <Modal
          dialogClassName="modal-dialog-centered cust-modal-white-content"
          className="cust-white-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.cancelComfirmModelshow}
          onHide={this.handleCloseConfirCancelModal}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">Cancel Order</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.handleCloseConfirCancelModal}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <div className="row modal-form cust-white-modal align-items-center">
              <p>Are you Sure you want to cancel whole Order.</p>
              <div className="col-lg-12 text-lg-end text-center">
                <div className="common-red-btn">
                  <button
                    className="btn red-border-btn  me-2"
                    type="reset"
                    onClick={this.handleCloseConfirCancelModal}
                  >
                    {ButtonLanguage.No}
                  </button>
                  <button
                    className="btn black-btn"
                    onClick={this.confirmCancelWholeOrder}
                  >
                    {ButtonLanguage.Yes}
                  </button>
                </div>
              </div>
            </div>
          </Modal.Body>
        </Modal>
      </Adminlayout>
    );
  }
}

export default withRouter(Orderdetails);
