import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import { API_Path, APIBaseUrl, buttonArabic, buttonEnglish, TableFieldArabic, TableFieldEnglish, titleArabic, titleEnglish, productArabic, productEnglish } from "../../const";
import { PostApi } from "../../helper/APIService";
import toastr from "toastr";
import "toastr/build/toastr.min.css";
import BasicDetails from "./BasicDetails";
import Variations from "./Variations";
import EditBasicDetails from "./EditBasicDetails";
import EditVariations from "./EditVariations";
import LanguageContext from "../../contexts/languageContext";
import { Formik } from "formik";
import * as Yup from "yup";
import { Modal, Accordion } from "react-bootstrap";
import { Prompt, withRouter } from "react-router-dom";
import SpecificSizeGuide from "../../Components/SpecificSizeGuide";

let modelValueArray = [];
let modelwearArray = [];

class EditProduct extends Component {
  static contextType = LanguageContext;

  constructor(props) {
    super(props);
    this.state = {
      sizeguide_show: false,
      selectedOption: "",
      selectedOptiontags: "",
      count: 0,
      productCode: "",
      variationList: "",
      variations: [],
      new_variation: {
        color: "",
        promotion: "",
        price: "",
        discount: "",
        discountPrice: "",
        Xscount: "",
        Scount: "",
        Mcount: "",
        Lcount: "",
        Xlcount: "",
        Xxlcount: "",
        Xxxlcount: "",
      },
      product_id: "",
      product_details: [],
      product_variation: [],
      product_variant: [],
      currentVariation: "",
      currentVariant: "",
      design: "",
      material: "",
      length: "",
      sleeve: "",
      neckline: "",
      waist: "",
      style: "",
      occasion: "",
      fit: "",
      waist: "",
      character: "",
      closure: "",
      pieces: "",
      careInstructions: "",
      shouldBlockNavigation: false,
      showSpecificComp: false,
      specificSizeGuid: '',
      SpecificSizeGuideData: '',
    };
    this.BasicDetailsData = React.createRef();
  }

  componentDidMount() {
    this.setState(
      {
        product_id: window.location.href.split("/").pop(),
      },
      () => {
        this.get_product_variation(this.state.product_id);
        this.get_product_details(this.state.product_id);
      }
    );
    this.getdesignData();
    this.getStyleData();
    this.getMaterialData();
    this.getcareInstructionData();
    this.getOccasionData();
    this.getSleeveData();
    this.getFitData();
    this.getLengthData();
    this.getNecklineData();
    this.getWaistData();
    this.getCharacterData();
    this.getClosureData();
    this.getPiecesData();
  }

  getdesignData = () => {

    let data = {};
    let path = API_Path.getDesign;
    const getDesignPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getDesignPromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data);
        this.setState({ designData: res.data.data });
      }
    });
  };

  getStyleData = () => {

    let data = {};
    let path = API_Path.getStyle;
    const getStylePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getStylePromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data);
        this.setState({ styleData: res.data.data });
      }
    });
  };

  getFitData = () => {

    let data = {};
    let path = API_Path.getFit;
    const getFitPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getFitPromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data);
        this.setState({ fitData: res.data.data });
      }
    });
  };

  getLengthData = () => {

    let data = {};
    let path = API_Path.getLength;
    const getLengthPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getLengthPromise.then((res) => {
      if (res) {
        this.setState({ lengthData: res.data.data });
      }
    });
  };

  getSleeveData = () => {

    let data = {};
    let path = API_Path.getSleeve;
    const getSleevePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getSleevePromise.then((res) => {
      if (res) {
        this.setState({ sleeveData: res.data.data });
      }
    });
  };

  getNecklineData = () => {

    let data = {};
    let path = API_Path.getNeckline;
    const getNecklinePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getNecklinePromise.then((res) => {
      if (res) {
        this.setState({ necklineData: res.data.data });
      }
    });
  };

  getWaistData = () => {

    let data = {};
    let path = API_Path.getWaist;
    const getWaistDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getWaistDataPromise.then((res) => {
      if (res) {
        this.setState({ waistData: res.data.data });
      }
    });
  };

  getCharacterData = () => {

    let data = {};
    let path = API_Path.getCharacter;
    const getCharacterPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getCharacterPromise.then((res) => {
      if (res) {
        this.setState({ characterData: res.data.data });
      }
    });
  };

  getClosureData = () => {

    let data = {};
    let path = API_Path.getClosure;
    const getClosurePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getClosurePromise.then((res) => {
      if (res) {
        this.setState({ closureData: res.data.data });
      }
    });
  };

  getPiecesData = () => {

    let data = {};
    let path = API_Path.getPieces;
    const getPiecesPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getPiecesPromise.then((res) => {
      if (res) {
        this.setState({ piecesData: res.data.data });
      }
    });
  };

  getOccasionData = () => {

    let data = {};
    let path = API_Path.getOccasion;
    const getOccasionPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getOccasionPromise.then((res) => {
      if (res) {
        this.setState({ occasionData: res.data.data });
      }
    });
  };

  getMaterialData = () => {

    let data = {};
    let path = API_Path.getMaterial;
    const getMaterialPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getMaterialPromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data);
        this.setState({ materialData: res.data.data });
      }
    });
  };

  getcareInstructionData = () => {

    let data = {};
    let path = API_Path.getCareInstruction;
    const getcareInstructionDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getcareInstructionDataPromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res);
        this.setState({ careInstructionData: res.data.data });
      }
    });
  };

  get_product_variation = (id) => {
    const formData = { product_id: id };
    const getProductVariationDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(API_Path.getProductVariationById, formData));
    });
    getProductVariationDataPromise.then((response) => {
      if (response.status === 200) {
        // console.log(response.data.data, "variations");
        this.setState(
          {
            product_variation: response.data.data,
            currentVariation: response.data.data[0],
          },
          () => { }
        );
      } else {
        toastr.error(response.message);
      }
    });
  };

  get_product_details = (id) => {
    const data = { product_id: id };
    const getProductDetailDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(API_Path.getProductDetailById, data));
    });
    getProductDetailDataPromise.then((res) => {
      // console.log(res.data.data[0], "-------");
      if (res.status === 200) {
        this.setState({ oldData: res.data.data[0] }, () => {
          // modelValueArray = this.state.oldData.model_size?.split(',')
          // this.state.oldData.model_size?.split(',')?.map((item) => {
          //   let data = {}
          //   data = {
          //     value: item,
          //     id: this.makeId(7),
          //   };
          //   modelwearArray.push(data);
          // })
          this.setState(
            {
              design: this.state.oldData.design,
              material: this.state.oldData.material,
              length: this.state.oldData.length,
              sleeve: this.state.oldData.sleeve,
              neckline: this.state.oldData.neckline,
              waist: this.state.oldData.waist,
              style: this.state.oldData.style,
              occasion: this.state.oldData.occasion,
              fit: this.state.oldData.fit,
              character: this.state.oldData.character,
              closure: this.state.oldData.closure,
              pieces: this.state.oldData.pieces,
              careInstructions: this.state.oldData.care_instruction,
              modelwear: this.state.oldData.model_size,
              specificSizeGuid: JSON.parse(this.state.oldData.specific_size_guide),
              showSpecificComp: this.state.oldData.size_guide_type == 1 ? true : false
              // modelForDisplay: modelwearArray
            }, () => {
              // console.log(this.state.specificSizeGuid, "[[=][=]");
            });
        });
      } else {
        toastr.error(res.message);
      }
    });
  };

  getVariationList = (variations) => {
    // console.log('get edit variations is :: ', variations);
    this.setState({ variationList: variations });
  };

  getProductCode = (code) => {
    this.setState({ productCode: code });
  };

  makeId = (length) => {
    var result = "";
    var characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    var charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  };

  handleModelWearSize = (e) => {
    this.setState({ modelwear: e.target.value }, () => {
      if (e.keyCode === 13) {
        if (this.state.modelwear !== "") {
          this.state.modelwear
            .trim()
            .split(/\s+/)
            .map((item, i) => {
              let data = {
                value: item,
                id: this.makeId(7),
              };
              modelwearArray.push(data);
            });
          let modelValueArray = [];
          modelwearArray.map((l) => {
            let value = l.value;
            modelValueArray.push(value);
          });
          this.setState(
            {
              modelwear: "",
              modelForDisplay: modelwearArray,
              modelValueForDisplay: modelValueArray,
            },
            () => {
              document.getElementById("modelwear").value = "";
            }
          );
        }
      }
    });
  };

  removeModel = (idToRemove) => {
    modelValueArray = []
    const modelSize = modelwearArray.filter((item) => item.id !== idToRemove);
    modelwearArray = modelSize;
    modelwearArray.map((item) => {
      modelValueArray.push(item.value)
    })
    this.setState({ modelForDisplay: modelSize, modelValueForDisplay: modelValueArray }, () => {
      // console.log(this.state.modelForDisplay, this.state.modelValueForDisplay)
    });
  };

  handleEditProduct = () => {
    if (document.getElementById("AttributesSubmit")) {
      document.getElementById("AttributesSubmit").click();
    }
    setTimeout(() => {
      let basicData = this.BasicDetailsData.current.runforms.current.values;
      let basicStateData = this.BasicDetailsData.current.state;
      if (this.state.AttributesData) {
        let data = {
          id: this.state.product_id,
          englishTitle: basicData.englishTitle,
          arabicTitle: basicData.arabicTitle,
          englishDescription: basicData.englishDescription,
          arabicDescription: basicData.arabicDescription,
          mainCategory: basicData.mainCategory,
          category: basicData.category,
          subCategory: basicData.subCategory,
          barcode: basicData.barcode,
          productCode: this.state.productCode,
          design: this.state.AttributesData.design,
          material: this.state.AttributesData.material,
          length: this.state.AttributesData.length,
          sleeve: this.state.AttributesData.sleeve,
          neckline: this.state.AttributesData.neckline,
          waist: this.state.AttributesData.waist,
          thumbnail: basicStateData.thumbnailImgUrl,
          modalWearingSize: this.state.AttributesData?.modelwear,
          careInstructions: this.state.AttributesData.careInstructions,
          tags: basicStateData.tagsValue,
          sizeGuideLineData: this.state.showSpecificComp ? null : basicStateData.sizeGuideline * 1,
          productActivateStatus: parseInt(basicData.status),
          variations: this.state.variationList,
          productType: basicData.status === '2' ? 'draft' : 'publish',
          style: this.state.AttributesData.style,
          occasion: this.state.AttributesData.occasion,
          fit: this.state.AttributesData.fit,
          pieces: this.state.AttributesData.pieces,
          closure: this.state.AttributesData.closure,
          character: this.state.AttributesData.character,
          specific_size_guide: this.state.showSpecificComp ? JSON.stringify(this.state.SpecificSizeGuideData) : '',
          size_guide_type: this.state.showSpecificComp ? 1 : 0
        };
        let path = API_Path.editProduct;
        const editProductPromise = new Promise((resolve, reject) => {
          resolve(PostApi(path, data));
        });

        editProductPromise.then((res) => {
          if (res) {
            // console.log("res is :: ", res);
            if (res.data.success) {
              if (this.context.language === "english") {
                toastr.success(res.data.message);
              } else {
                toastr.success('تم  تعديل المنتج بنجاح')
              }
              setTimeout(() => {
                this.props.history.push("/products")
                // window.location.href = "products";
              }, 1000);
            }
          }
        });
      }
    }, 500);
  };

  handlePromptChange = () => {
    this.setState({ shouldBlockNavigation: true })
  }

  getSizeGuidlineData = (data) => {
    this.setState({ SpecificSizeGuideData: data }, () => {
      // console.log(this.state.SpecificSizeGuideData, "SpecificSizeGuideData===edit");
    })
  }
  ShowSpecificSizeGuide = (show) => {
    this.setState({ showSpecificComp: show })
  }

  render() {
    let Language = this.context.language === "english" ? TableFieldEnglish : TableFieldArabic;
    let ButtonLanguage = this.context.language === "english" ? buttonEnglish : buttonArabic;
    let titleLanguage = this.context.language === "english" ? titleEnglish : titleArabic;
    let productLanguage = this.context.language === "english" ? productEnglish : productArabic;
    return (
      <React.Fragment>
        <Prompt when={this.state.shouldBlockNavigation === true} message="You have unsaved changes, are you sure you want to leave?" />
        <Adminlayout>
          <div className="container-fluid">
            <div className="row common-space">
              <div className="col-sm-4 text-sm-start text-center rtl-txt-start">
                <div className="common-header-txt">
                  <h3>{productLanguage.editProducts}</h3>
                </div>
              </div>
              <div className="col-sm-8 text-sm-end text-center rtl-txt-end">
                <div className="common-red-btn">
                  <button onClick={this.handleEditProduct} className="btn black-btn me-2">
                    {ButtonLanguage.saveProduct}
                  </button>
                </div>
              </div>
            </div>
            <div className="row common-space">
              <div className="col-md-12">
                <div className="white-box">
                  <div className="row custom-border-title">
                    <div className="col-md-12">
                      <div className="product-header">
                        <span>{productLanguage.BasicDetails}</span>
                      </div>
                    </div>
                  </div>
                  {this.state.product_id && <EditBasicDetails ref={this.BasicDetailsData} productId={this.state.product_id} getProductCode={this.getProductCode} selectSpecificSizeGuid={this.ShowSpecificSizeGuide} />}
                </div>
              </div>
            </div>
            {this.state.showSpecificComp && this.state.specificSizeGuid != '' &&
              <div className="row common-space ">
                <div className="col-d-12">
                  <div className="attr-accor ">
                    <Accordion defaultActiveKey="0">
                      <Accordion.Item eventKey="0">
                        <Accordion.Header>
                          {productLanguage.sepcifiSizGuid}
                        </Accordion.Header>
                        <Accordion.Body>
                          <SpecificSizeGuide getSizeGuidlineData={this.getSizeGuidlineData} SizeData={this.state.specificSizeGuid} />
                        </Accordion.Body>
                      </Accordion.Item>
                    </Accordion>
                  </div>
                </div>
              </div>
            }
            <div className="row common-space ">
              <div className="col-d-12">
                <div className="attr-accor ">
                  <Accordion defaultActiveKey="0">
                    <Accordion.Item eventKey="0">
                      <Accordion.Header>
                        {productLanguage.attributes}
                      </Accordion.Header>
                      <Accordion.Body className="pt-0">
                        <Formik
                          innerRef={this.runforms}
                          enableReinitialize={true}
                          initialValues={{
                            design: this.state.design,
                            material: this.state.material,
                            length: this.state.length,
                            sleeve: this.state.sleeve,
                            neckline: this.state.neckline,
                            waist: this.state.waist,
                            style: this.state.style,
                            occasion: this.state.occasion,
                            fit: this.state.fit,
                            character: this.state.character,
                            closure: this.state.closure,
                            pieces: this.state.pieces,
                            careInstructions: this.state.careInstructions,
                            modelwear: this.state.modelwear
                          }}
                          onSubmit={(values, { setSubmitting }) => {
                            // console.log(values)
                            this.setState({ AttributesData: values })
                            setSubmitting(false);
                          }}
                        >
                          {(props) => {
                            const { values, touched, errors, isSubmitting, handleChange, handleBlur, handleSubmit } = props;
                            return (
                              <form className="row mt-3" onSubmit={handleSubmit}>
                                <div className="form-group col-xl-2 col-md-4">
                                  <label>{productLanguage.design}</label>
                                  <select name="design" value={values.design} onChangeCapture={this.handlePromptChange} onChange={handleChange} onBlur={handleBlur} className="form-select input-custom-class">
                                    <option>{productLanguage.SelectDesign}</option>
                                    {this.state.designData &&
                                      this.state.designData.length > 0 &&
                                      this.state.designData.map((item, i) => {
                                        return (
                                          <option value={item.id} key={i}>
                                            {item.english} | {item.arabic}
                                          </option>
                                        );
                                      })}
                                  </select>
                                </div>
                                <div className="form-group col-xl-2 col-md-4">
                                  <label>{productLanguage.style}</label>
                                  <select name="style" value={values.style} onChangeCapture={this.handlePromptChange} onChange={handleChange} onBlur={handleBlur} className="form-select input-custom-class">
                                    <option>{productLanguage.selectStyle}</option>
                                    {this.state.styleData &&
                                      this.state.styleData.length > 0 &&
                                      this.state.styleData.map((item, i) => {
                                        return (
                                          <option value={item.id} key={i}>
                                            {item.english} | {item.arabic}
                                          </option>
                                        );
                                      })}
                                  </select>
                                </div>
                                <div className="form-group col-xl-2 col-md-4">
                                  <label>{productLanguage.occasion}</label>
                                  <select name="occasion" value={values.occasion} onChangeCapture={this.handlePromptChange} onChange={handleChange} onBlur={handleBlur} className="form-select input-custom-class">
                                    <option>{productLanguage.selectOccasion}</option>
                                    {this.state.occasionData &&
                                      this.state.occasionData.length > 0 &&
                                      this.state.occasionData.map((item, i) => {
                                        return (
                                          <option value={item.id} key={i}>
                                            {item.english} | {item.arabic}
                                          </option>
                                        );
                                      })}
                                  </select>
                                </div>
                                <div className="form-group col-xl-2 col-md-4">
                                  <label>{productLanguage.fit}</label>
                                  <select name="fit" value={values.fit} onChangeCapture={this.handlePromptChange} onChange={handleChange} onBlur={handleBlur} className="form-select input-custom-class">
                                    <option>{productLanguage.selectFit}</option>
                                    {this.state.fitData &&
                                      this.state.fitData.length > 0 &&
                                      this.state.fitData.map((item, i) => {
                                        return (
                                          <option value={item.id} key={i}>
                                            {item.english} | {item.arabic}
                                          </option>
                                        );
                                      })}
                                  </select>
                                </div>
                                <div className="form-group col-xl-2 col-md-4">
                                  <label>{productLanguage.Length}</label>
                                  <select name="length" value={values.length} onChangeCapture={this.handlePromptChange} onChange={handleChange} onBlur={handleBlur} className="form-select input-custom-class">
                                    <option>{productLanguage.SelectLength}</option>
                                    {this.state.lengthData &&
                                      this.state.lengthData.length > 0 &&
                                      this.state.lengthData.map((item, i) => {
                                        return (
                                          <option value={item.id} key={i}>
                                            {item.english} | {item.arabic}
                                          </option>
                                        );
                                      })}
                                  </select>
                                </div>
                                <div className="form-group col-xl-2 col-md-4">
                                  <label>{productLanguage.SleeveLength}</label>
                                  <select name="sleeve" value={values.sleeve} onChangeCapture={this.handlePromptChange} onChange={handleChange} onBlur={handleBlur} className="form-select input-custom-class">
                                    <option>{productLanguage.SelectSleeveLength}</option>
                                    {this.state.sleeveData &&
                                      this.state.sleeveData.length > 0 &&
                                      this.state.sleeveData.map((item, i) => {
                                        return (
                                          <option value={item.id} key={i}>
                                            {item.english} | {item.arabic}
                                          </option>
                                        );
                                      })}
                                  </select>
                                </div>
                                <div className="form-group col-xl-2 col-md-4">
                                  <label>{productLanguage.Neckline}</label>
                                  <select name="neckline" value={values.neckline} onChangeCapture={this.handlePromptChange} onChange={handleChange} onBlur={handleBlur} className="form-select input-custom-class">
                                    <option>{productLanguage.SelectNeckline}</option>
                                    {this.state.necklineData &&
                                      this.state.necklineData.length > 0 &&
                                      this.state.necklineData.map((item, i) => {
                                        return (
                                          <option value={item.id} key={i}>
                                            {item.english} | {item.arabic}
                                          </option>
                                        );
                                      })}
                                  </select>
                                </div>
                                <div className="form-group col-xl-2 col-md-4">
                                  <label>{productLanguage.WaistType}</label>
                                  <select name="waist" value={values.waist} onChangeCapture={this.handlePromptChange} onChange={handleChange} onBlur={handleBlur} className="form-select input-custom-class">
                                    <option>{productLanguage.SelectWaistType}</option>
                                    {this.state.waistData &&
                                      this.state.waistData.length > 0 &&
                                      this.state.waistData.map((item, i) => {
                                        return (
                                          <option value={item.id} key={i}>
                                            {item.english} | {item.arabic}
                                          </option>
                                        );
                                      })}
                                  </select>
                                </div>
                                <div className="form-group col-xl-2 col-md-4">
                                  <label>{productLanguage.Character}</label>
                                  <select name="character" value={values.character} onChangeCapture={this.handlePromptChange} onChange={handleChange} onBlur={handleBlur} className="form-select input-custom-class">
                                    <option>{productLanguage.SelectCharacter}</option>
                                    {this.state.characterData &&
                                      this.state.characterData.length > 0 &&
                                      this.state.characterData.map((item, i) => {
                                        return (
                                          <option value={item.id} key={i}>
                                            {item.english} | {item.arabic}
                                          </option>
                                        );
                                      })}
                                  </select>
                                </div>
                                <div className="form-group col-xl-2 col-md-4">
                                  <label>{productLanguage.Closure}</label>
                                  <select name="closure" value={values.closure} onChangeCapture={this.handlePromptChange} onChange={handleChange} onBlur={handleBlur} className="form-select input-custom-class">
                                    <option>{productLanguage.SelectClosure}</option>
                                    {this.state.closureData &&
                                      this.state.closureData.length > 0 &&
                                      this.state.closureData.map((item, i) => {
                                        return (
                                          <option value={item.id} key={i}>
                                            {item.english} | {item.arabic}
                                          </option>
                                        );
                                      })}
                                  </select>
                                </div>
                                <div className="form-group col-xl-2 col-md-4">
                                  <label>{productLanguage.material}</label>
                                  <select name="material" value={values.material} onChangeCapture={this.handlePromptChange} onChange={handleChange} onBlur={handleBlur} className="form-select input-custom-class">
                                    <option>{productLanguage.Selectmaterial}</option>
                                    {this.state.materialData &&
                                      this.state.materialData.length > 0 &&
                                      this.state.materialData.map((item, i) => {
                                        return (
                                          <option value={item.id} key={i}>
                                            {item.english} | {item.arabic}
                                          </option>
                                        );
                                      })}
                                  </select>
                                </div>
                                <div className="form-group col-xl-2 col-md-4">
                                  <label>{productLanguage.Pieces}</label>
                                  <select name="pieces" value={values.pieces} onChangeCapture={this.handlePromptChange} onChange={handleChange} onBlur={handleBlur} className="form-select input-custom-class">
                                    <option>{productLanguage.SelectPieces}</option>
                                    {this.state.piecesData &&
                                      this.state.piecesData.length > 0 &&
                                      this.state.piecesData.map((item, i) => {
                                        return (
                                          <option value={item.id} key={i}>
                                            {item.english} | {item.arabic}
                                          </option>
                                        );
                                      })}
                                  </select>
                                </div>
                                <div className="form-group col-md-4">
                                  <label>{productLanguage.careInstructions}</label>
                                  <select multiple name="careInstructions" value={values.careInstructions} onChangeCapture={this.handlePromptChange} onChange={handleChange} onBlur={handleBlur} className="form-select input-custom-class h-auto">
                                    {this.state.careInstructionData &&
                                      this.state.careInstructionData.length > 0 &&
                                      this.state.careInstructionData.map((item, i) => {
                                        return (
                                          <option value={item.id} key={i}>
                                            {item.english} | {item.arabic}
                                          </option>
                                        );
                                      })}
                                  </select>
                                </div>
                                <div className="form-group col-xl-2 col-md-4">
                                  <label>{productLanguage.ModelWearingSize}</label>
                                  <input placeholder={productLanguage.TypeModelWearingSize} className="form-control input-custom-class" name="modelwear" value={values.modelwear} onChangeCapture={this.handlePromptChange} onChange={handleChange} onBlur={handleBlur} id="modelwear" />
                                  {/* <input placeholder="Type model wearing size." className="form-control input-custom-class" name="modelwear" onKeyDown={this.handleModelWearSize} id="modelwear" /> */}
                                  {/* <div>
                                    {this.state.modelForDisplay && this.state.modelForDisplay.length > 0 && (
                                      <ul className="d-flex align-items-center flex-wrap">
                                        {this.state.modelForDisplay !== "" &&
                                          this.state.modelForDisplay.map((item, i) => {
                                            return (
                                              <li key={i} className="me-2 mb-3">
                                                <bdi className="barcode-bg py-1 px-2 mx-2 rounded">{item.value}</bdi>
                                                <mark onClick={() => this.removeModel(item.id)} className="bg-transparent bi bi-x p-0"></mark>
                                              </li>
                                            );
                                          })}
                                      </ul>
                                    )}
                                  </div> */}
                                </div>
                                <div style={{ display: "none" }} className="col-12">
                                  <div className="btn-comn-div pt-5 text-center">
                                    <button id="AttributesSubmit" disabled={isSubmitting} type="submit" className="btn-comn">
                                      <span>{productLanguage.submit}</span>
                                    </button>
                                  </div>
                                </div>
                              </form>
                            );
                          }}
                        </Formik>
                      </Accordion.Body>
                    </Accordion.Item>
                  </Accordion>
                </div>
              </div>
            </div>
            <div className="row common-space">
              <div className="col-md-12">
                <div className="product-in-title">
                  <span>{productLanguage.Variants}</span>
                </div>
              </div>
            </div>
            {this.state.productCode !== "" && <EditVariations productCode={this.state.productCode} getVariationList={this.getVariationList} />}
          </div>
        </Adminlayout>
      </React.Fragment>
    );
  }
}

export default withRouter(EditProduct);
