import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import createReactClass from "create-react-class";
import LanguageContext from "../../contexts/languageContext";

import SizeGuideRow from "./sizeGuiderow";
import { APIBaseUrl, API_Path, buttonArabic, buttonEnglish, LIVE_FILE_URL, productArabic, sizeGuidelinesArabic, sizeGuidelinesEnglish, TableFieldArabic, TableFieldEnglish, titleArabic, titleEnglish, productEnglish } from "../../const";
import { PostApi } from "../../helper/APIService";
import toastr from "toastr";
import Select from 'react-select';
import { withRouter } from "react-router-dom";

let SizeGuidelineData = [];
let HowTOMeasureData = [];

const SizeGuidelineList = createReactClass({
  render: function () {
    if (this.props.variations) {
      SizeGuidelineData = this.props.variations;
      if (this.props.variations.length > 1)
        for (let i = 0; i < this.props.variations.length - 1; i++) {
          document.getElementById("plus-" + i).style.display = "none";
        }
    }
    const guidelineList = this.props.variations.map((val, i) => {
      let elm = React.createElement(SizeGuideRow, {
        formVals: val,
        index: i,
        setVal: (value, ind) => this.props.setVal(value, ind),
        removeElement: (ind) => this.props.removeElement(ind),
        addElement: (ind) => this.props.addElement(ind),
        columns: this.props.columns,
      });
      return <React.Fragment key={i}>{elm}</React.Fragment>;
    });
    return guidelineList;
  },
});

class AddSizeGuideline extends Component {
  static contextType = LanguageContext;

  state = {
    variations: [],
    new_variation: {
      variation_id: 0,
      sizeArabic: "",
      topLength: "",
      shoulder: "",
      length: "",
      bust: "",
      chest: "",
      waist: "",
      hips: "",
      rise: "",
      inseamLength: "",
      outseamLength: "",
      sleeveLength: "",
      armWidth: "",
      skirtLength: "",
      overBust: "",
      underBust: "",
      bottomLength: "",
    },
    sizeGuideLineImg: "",
    sizeGuideLineImgUrl: "",
    ColumnSelected: false,
    columns: "",
    guideNameEnglish: "",
    guideNameArabic: "",
    sizeGuideNumber: "",
    mainCategory: "",
    category: "",
    subCategory: "",
    maincategoryData: "",
    howToMeasureData: "",
    categoryData: "",
    subCategoryData: "",
    howToMeasureDataArr: [],
    firstAttempt: true,
  };

  componentDidMount() {
    this.getMainCategoryData();
    this.GenerateGuideNumber(10);
    this.getHowToMeasureData();
  }

  GenerateGuideNumber = (length) => {
    var result = "";
    var characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    var charactersLength = characters.length;
    for (var i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    this.setState({ sizeGuideNumber: result });
    // return result;
  };

  getHowToMeasureData = () => {
    let data = {};

    let path = API_Path.gethowtomeasure;
    const getHowToMeasurePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getHowToMeasurePromise.then((res) => {
      if (res) {
        // let arr = [];
        this.setState({ howToMeasureData: res.data.data }, () => {

          // this.state.howToMeasureData.map((item) => {
          //   let obj = {};
          //   obj.label = item.title_en
          //   obj.value = item.id
          //   arr.push(obj)
          // })
        });
        // this.setState({ howToMeasureData: arr })
      }
    });
  };

  getMainCategoryData = () => {
    let data = {};

    let path = API_Path.getMainCategory;
    const getMainCategoryPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getMainCategoryPromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data);
        this.setState({ maincategoryData: res.data.data });
      }
    });
  };

  getCategoryData = (val) => {
    if (val) {
      let data = { main_category_id: val };
      let path = API_Path.getCategoryRelative;
      const getCategoryPromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      getCategoryPromise.then((res) => {
        if (res) {
          // console.log('res is :: ', res.data.data);
          this.setState({ categoryData: res.data.data });
        }
      });
    } else {
      let data = {};

      let path = API_Path.getCategory;
      const getCategoryPromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      getCategoryPromise.then((res) => {
        if (res) {
          // console.log('res is :: ', res.data.data);
          this.setState({ categoryData: res.data.data });
        }
      });
    }
  };

  getSubCategoryData = (val) => {
    // console.log(val);
    if (val) {
      let data = { category_id: val };

      let path = API_Path.getSubCategoryRelative;
      const getSubCategoryPromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      getSubCategoryPromise.then((res) => {
        if (res) {
          // console.log('res is :: ', res.data.data);
          this.setState({ subCategoryData: res.data.data });
        }
      });
    } else {
      let data = {};
      let path = API_Path.getSubCategory;
      const getSubCategoryPromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      getSubCategoryPromise.then((res) => {
        if (res) {
          // console.log('res is :: ', res.data.data);
          this.setState({ subCategoryData: res.data.data });
        }
      });
    }
  };

  handleTextBoxChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  handleMeasureChange = (e) => {
    // e.map((item) => {
    // this.setState({ howToMeasureData: e.target.value })
    // })
    if (!HowTOMeasureData.includes(e.target.value)) {
      HowTOMeasureData.push(e.target.value);
    }
    this.setState({ howToMeasureDataArr: HowTOMeasureData });
  }

  removeMeasure = (id) => {
    let filtered = this.state.howToMeasureDataArr.filter((item, i) => parseInt(item) !== id);
    HowTOMeasureData = filtered;
    this.setState({ howToMeasureDataArr: filtered, howToMeasure: filtered });
  };

  handleTextBoxChange1 = (e) => {
    if (e.target.name == "mainCategory") {
      this.getCategoryData(e.target.value);
    }
    if (e.target.name == "category") {
      this.getSubCategoryData(e.target.value);
    }
  };

  addVariation = () => {
    this.setState({
      variations: [...this.state.variations, this.state.new_variation],
    });
  };

  setVal = (val, index) => {
    let variations = this.state.variations;
    if (typeof variations[index] !== "undefined") {
      variations[index] = {
        ...variations[index],
        ...val,
      };
    }
    this.setState({
      variations: variations,
    });
  };

  removeElement = (index) => {
    let variations = this.state.variations;
    if (variations.length > 1) {
      if (typeof variations[index] !== "undefined") {
        delete variations[index];
      }
      this.setState(
        {
          variations: variations.filter(Boolean),
        },
        () => {
          if (this.state.variations.length > 0) {
            document.getElementById("plus-" + (this.state.variations.length - 1).toString()).style.display = "block";
          }
        }
      );
    }
  };

  handleNumberChange = (e) => {
    if (e.target.value >= 0) {
      this.setState({ [e.target.name]: e.target.value });
    }
  };

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.checked });
  };

  handleSubmit = () => {
    let columnArray = ["size"];
    if (this.state.sizeArabic == true) {
      columnArray.push("sizeArabic");
    }
    if (this.state.topLength == true) {
      columnArray.push("topLength");
    }
    if (this.state.shoulder == true) {
      columnArray.push("shoulder");
    }
    if (this.state.length == true) {
      columnArray.push("length");
    }
    if (this.state.bust == true) {
      columnArray.push("bust");
    }
    if (this.state.chest == true) {
      columnArray.push("chest");
    }
    if (this.state.waist == true) {
      columnArray.push("waist");
    }
    if (this.state.hips == true) {
      columnArray.push("hips");
    }
    if (this.state.rise == true) {
      columnArray.push("rise");
    }
    if (this.state.inseamLength == true) {
      columnArray.push("inseamLength");
    }
    if (this.state.outseamLength == true) {
      columnArray.push("outseamLength");
    }
    if (this.state.sleeveLength == true) {
      columnArray.push("sleeveLength");
    }
    if (this.state.armWidth == true) {
      columnArray.push("armWidth");
    }
    if (this.state.skirtLength == true) {
      columnArray.push("skirtLength");
    }
    if (this.state.overBust == true) {
      columnArray.push("overBust");
    }
    if (this.state.underBust == true) {
      columnArray.push("underBust");
    }
    if (this.state.bottomLength == true) {
      columnArray.push("bottomLength");
    }

    let data = {
      variation_id: 0,
    };
    for (let i = 0; i < columnArray.length; i++) {
      let key = columnArray[i];
      data[key] = "";
    }
    // console.log('array :: ', columnArray);
    this.setState({ columns: columnArray, new_variation: data, ColumnSelected: true }, () => {
      if (this.state.firstAttempt) {
        this.setState({ firstAttempt: false });
        this.addVariation();
      }
    });
  };

  addsizeGuideLine = (e) => {
    this.setState({ sizeGuideLineImg: Object.values(e.target.files) }, () => {
      this.setState({ isLoading: true });
      this.addsizeGuideLineToStorage(this.state.sizeGuideLineImg);
    });
  };

  addsizeGuideLineToStorage = (files) => {


    // console.log('files is :: ', files);

    var formData = new FormData();
    for (var i = 0; i < files.length; i++) {
      formData.append("file", files[i]);
    }

    let path = API_Path.addFileInS3;
    const addFilePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, formData));
    });

    addFilePromise.then((res) => {
      if (res) {
        this.setState({ sizeGuideLineImgUrl: res.data.data[0] }, () => {
          this.setState({ isLoading: false });
          // document.getElementById('sizeGuideLineError').style.display = 'none'
        });
      }
    });
  };

  removesizeGuideLine = () => {
    this.setState({ sizeGuideLineImg: "", sizeGuideLineImgUrl: "" });
    document.getElementById("sizeGuideLineInput").value = "";
  };

  handleSave = () => {
    if (this.state.guideNameEnglish === "") {
      toastr.error("Please Enter Guide Name in English");
    } else if (this.state.guideNameArabic === "") {
      toastr.error("Please Enter Guide Name in Arabic");
    } else if (this.state.sizeGuideNumber === "") {
      toastr.error("Please Enter Guide Number");
    } else if (this.state.mainCategory === "") {
      toastr.error("Please Select Main Category");
    } else if (this.state.category === "") {
      toastr.error("Please Select  Category");
    } else if (this.state.subCategory === "") {
      toastr.error("Please Select Sub Category");
    } else if (this.state.columns === "") {
      toastr.error("Please Select Columns");
    } else if (SizeGuidelineData === []) {
      toastr.error("Please add size guide data");
    } else if (this.state.sizeGuideLineImgUrl === "") {
      toastr.error("Please Enter guide image");
    } else if (this.state.howToMeasureDataArr === []) {
      toastr.error("Please Select how to measure data");
    } else {
      let data = {
        size_guide_name_english: this.state.guideNameEnglish,
        size_guide_name_arabic: this.state.guideNameArabic,
        size_guide_number: this.state.sizeGuideNumber,
        main_category: this.state.mainCategory,
        category: this.state.category,
        sub_category: this.state.subCategory,
        columns: this.state.columns,
        size_guide_data: SizeGuidelineData,
        size_guide_img: this.state.sizeGuideLineImgUrl,
        new_variation: this.state.new_variation,
        measure: this.state.howToMeasureDataArr,
      };
      let path = API_Path.addSizeGuideLine;
      const addSizeGuidePromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      addSizeGuidePromise.then((res) => {
        if (res) {
          if (res.data.success) {
            toastr.success(res.data.message);
            this.props.history.push("/sizeguideline");
            // window.location.href = "sizeguideline";
            this.setState({ howToMeasureDataArr: [] })
            HowTOMeasureData = []
            this.clearState();
          }
        }
      });
    }
  };

  clearState = () => {
    this.setState({
      variations: [],
      new_variation: {
        variation_id: 0,
        sizeArabic: "",
        topLength: "",
        shoulder: "",
        length: "",
        bust: "",
        chest: "",
        waist: "",
        hips: "",
        rise: "",
        inseamLength: "",
        outseamLength: "",
        sleeveLength: "",
        armWidth: "",
        skirtLength: "",
        overBust: "",
        underBust: "",
        bottomLength: "",
      },
      sizeGuideLineImg: "",
      sizeGuideLineImgUrl: "",
      ColumnSelected: false,
      columns: "",
      guideNameEnglish: "",
      guideNameArabic: "",
      sizeGuideNumber: "",
      mainCategory: "",
      category: "",
      subCategory: "",
      maincategoryData: "",
      categoryData: "",
      subCategoryData: "",
    });
  };

  render() {
    let Language = this.context.language === "english" ? TableFieldEnglish : TableFieldArabic;
    let buttonLanguage = this.context.language === "english" ? buttonEnglish : buttonArabic;
    let titleLanguage = this.context.language === "english" ? titleEnglish : titleArabic;
    let sizeGuidelinesLanguage = this.context.language === "english" ? sizeGuidelinesEnglish : sizeGuidelinesArabic;
    let productLanguage = this.context.language === "english" ? productEnglish : productArabic;

    const checkBoxList = [
      {
        value: "sizeArabic",
        name: sizeGuidelinesLanguage.sizeInArabic,
      },
      {
        value: "topLength",
        name: sizeGuidelinesLanguage.topLength,
      },
      {
        value: "shoulder",
        name: sizeGuidelinesLanguage.shoulder,
      },
      {
        value: "length",
        name: sizeGuidelinesLanguage.length,
      },
      {
        value: "bust",
        name: sizeGuidelinesLanguage.bust,
      },
      {
        value: "chest",
        name: sizeGuidelinesLanguage.chest,
      },
      {
        value: "waist",
        name: sizeGuidelinesLanguage.waist,
      },
      {
        value: "hips",
        name: sizeGuidelinesLanguage.hips,
      },
      {
        value: "rise",
        name: sizeGuidelinesLanguage.rise,
      },
      {
        value: "inseamLength",
        name: sizeGuidelinesLanguage.inseamLength,
      },
      {
        value: "outseamLength",
        name: sizeGuidelinesLanguage.outseamLength,
      },
      {
        value: "sleeveLength",
        name: sizeGuidelinesLanguage.sleeveLength,
      },
      {
        value: "armWidth",
        name: sizeGuidelinesLanguage.armWidth,
      },
      {
        value: "skirtLength",
        name: sizeGuidelinesLanguage.skirtLength,
      },
      {
        value: "overBust",
        name: sizeGuidelinesLanguage.overBust,
      },
      {
        value: "underBust",
        name: sizeGuidelinesLanguage.underBust,
      },
      {
        value: "bottomLength",
        name: sizeGuidelinesLanguage.bottomLength,
      },
    ];



    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space align-items-center">
            <div className="col-12 text-md-start text-center rtl-txt-start">
              <div className="common-header-txt">
                <h3>{sizeGuidelinesLanguage.addSizeGuideline}</h3>
              </div>
            </div>
            <div className="col-md-12 pt-4">
              <div className="white-box">
                <form className="row border-bottom">
                  <div className="form-group col-md-4 mb-3">
                    <label>{sizeGuidelinesLanguage.guideNameInEnglish}</label>
                    <input type="text" onChange={this.handleTextBoxChange} value={this.state.guideNameEnglish} name="guideNameEnglish" className="form-control input-custom-class me-2" placeholder={sizeGuidelinesLanguage.sizeGuideNameInEnglish} />
                  </div>
                  <div className="form-group col-md-4 mb-3">
                    <label>{sizeGuidelinesLanguage.guideNameInArabic}</label>
                    <input type="text" onChange={this.handleTextBoxChange} value={this.state.guideNameArabic} name="guideNameArabic" className="form-control input-custom-class me-2" placeholder={sizeGuidelinesLanguage.sizeGuideNameInArabic} />
                  </div>
                  <div className="form-group col-md-4 mb-3">
                    <label>{sizeGuidelinesLanguage.guideNumber}</label>
                    <input
                      type="text"
                      // onChange={this.handleTextBoxChange}
                      value={this.state.sizeGuideNumber}
                      name="sizeGuideNumber"
                      className="form-control input-custom-class me-2"
                      placeholder={sizeGuidelinesLanguage.sizeGuideNumber}
                      readOnly
                      disabled
                    />
                  </div>
                  <div className="row">
                    <div className="col-md-4 form-group">
                      <label>{sizeGuidelinesLanguage.mainCategory}</label>
                      <select name="mainCategory" value={this.state.mainCategory} onChange={this.handleTextBoxChange} onChangeCapture={this.handleTextBoxChange1} className="form-select input-custom-class">
                        <option>{sizeGuidelinesLanguage.ChooseMainCategory}</option>
                        {this.state.maincategoryData &&
                          this.state.maincategoryData.length > 0 &&
                          this.state.maincategoryData.map((item, i) => {
                            return (
                              <option value={item.id} key={i}>
                                {this.context.language === "english" ? item.english : item.arabic}
                              </option>
                            );
                          })}
                      </select>
                    </div>
                    <div className="col-md-4 form-group">
                      <label>{sizeGuidelinesLanguage.category}</label>
                      <select name="category" value={this.state.category} onChange={this.handleTextBoxChange} onChangeCapture={this.handleTextBoxChange1} className="form-select input-custom-class">
                        <option>{productLanguage.SelectCategory}</option>
                        {this.state.categoryData &&
                          this.state.categoryData.length > 0 &&
                          this.state.categoryData.map((item, i) => {
                            return (
                              <option value={item.id} key={i}>
                                {this.context.language === "english" ? item.english : item.arabic}
                              </option>
                            );
                          })}
                      </select>
                    </div>
                    <div className="col-md-4 form-group">
                      <label>{sizeGuidelinesLanguage.subCategory}</label>
                      <select name="subCategory" value={this.state.subCategory} onChange={this.handleTextBoxChange} className="form-select input-custom-class">
                        <option>{sizeGuidelinesLanguage.SelectSubCategory}</option>
                        {this.state.subCategoryData &&
                          this.state.subCategoryData.length > 0 &&
                          this.state.subCategoryData.map((item, i) => {
                            return (
                              <option value={item.id} key={i}>
                                {this.context.language === "english" ? item.english : item.arabic}
                              </option>
                            );
                          })}
                      </select>
                    </div>
                  </div>
                </form>

                <div className="row my-3 border-bottom pb-3">
                  <div className="col-md-12 add-size-label mb-3 ">
                    <div className="row m-0">
                      {checkBoxList.map((item, i) => {
                        return (
                          <label key={i} className="cust-chk-bx col-xl-2 m-0 col-6">
                            <input name={item.value} onChange={this.handleChange} type="checkbox" />
                            <span className="cust-chkmark"></span>
                            <bdi>{item.name}</bdi>
                          </label>
                        );
                      })}
                    </div>
                  </div>
                  <div className="col-md-12 text-center">
                    <button className="btn red-btn" onClick={this.handleSubmit}>
                      {sizeGuidelinesLanguage.submit}
                    </button>
                  </div>
                </div>

                {this.state.ColumnSelected && (
                  <div className="row mt-3">
                    {" "}
                    <div className="col-md-9 mx-auto border py-2">
                      <div className="table-responsive cust-table-size">
                        <table>
                          <tr>
                            {this.state.columns.includes("size") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>{productLanguage.size}</label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("sizeArabic") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>{sizeGuidelinesLanguage.sizeInArabic}</label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("topLength") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>{sizeGuidelinesLanguage.topLength}</label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("shoulder") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>{sizeGuidelinesLanguage.shoulder}</label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("length") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>{sizeGuidelinesLanguage.length}</label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("bust") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>{sizeGuidelinesLanguage.bust}</label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("chest") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>{sizeGuidelinesLanguage.chest}</label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("waist") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>{sizeGuidelinesLanguage.waist}</label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("hips") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>{sizeGuidelinesLanguage.hips}</label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("rise") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>{sizeGuidelinesLanguage.rise}</label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("inseamLength") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>{sizeGuidelinesLanguage.inseamLength}</label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("outseamLength") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>{sizeGuidelinesLanguage.outseamLength}</label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("sleeveLength") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>{sizeGuidelinesLanguage.sleeveLength}</label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("armWidth") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>{sizeGuidelinesLanguage.armWidth}</label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("skirtLength") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>{sizeGuidelinesLanguage.skirtLength}</label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("overBust") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>{sizeGuidelinesLanguage.overBust}</label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("underBust") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>{sizeGuidelinesLanguage.underBust}</label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("bottomLength") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>{sizeGuidelinesLanguage.bottomLength}</label>
                                </div>
                              </td>
                            )}
                          </tr>
                          <SizeGuidelineList variations={this.state.variations} removeElement={(i) => this.removeElement(i)} addElement={(i) => this.addVariation(i)} columns={this.state.columns} setVal={(val, ind) => this.setVal(val, ind)} />
                        </table>
                      </div>
                    </div>
                  </div>
                )}
                <div className="row mt-3">
                  <div className="col-md-6">
                    <div className="form-group ">
                      <label>{sizeGuidelinesLanguage.addSizeGuideline}</label>
                      <div className="d-flex flex-wrap">
                        <div className="upload-btn-wrapper mb-3">
                          <span className="btn">{sizeGuidelinesLanguage.uploadAFile}</span>
                          <input onChange={this.addsizeGuideLine} type="file" accept="image/*" id="sizeGuideLineInput" name="sizeGuideLineImg" />
                        </div>
                        {this.state.sizeGuideLineImgUrl !== "" && (
                          <div className="img-preview ps-3 wdth-click-main">
                            <ul className="justify-content-center">
                              <div className="img-bdr-main">
                                <div className="img-bdr-main-inr">
                                  <li>
                                    <div className="img-preview-main position-relative">
                                      <img src={this.state.sizeGuideLineImgUrl} alt="" />
                                      <div onClick={this.removesizeGuideLine} className="remove-img-btn">
                                        <i className="bi bi-x-circle-fill"></i>
                                      </div>
                                    </div>
                                  </li>
                                </div>
                              </div>
                            </ul>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="col-md-6 form-group">
                    {/* {this.state.howToMeasureData &&
                      this.state.howToMeasureData.length > 0 &&
                      <Select options={this.state.howToMeasureData} isMulti={true} onChange={this.handleMeasureChange} />
                    } */}
                    <label>{sizeGuidelinesLanguage.Howtomeasure}</label>
                    <select name="howToMeasure" value={this.state.howToMeasure} onChange={this.handleMeasureChange} className="form-select input-custom-class">
                      <option value="">{sizeGuidelinesLanguage.SelectHowToMeasure}</option>
                      {this.state.howToMeasureData &&
                        this.state.howToMeasureData.length > 0 &&
                        this.state.howToMeasureData.map((item, i) => {
                          return (
                            <option value={item.id} key={i}>
                              {this.context.language === "english" ? item.title_en : item.title_ar}
                            </option>
                          );
                        })}
                    </select>
                    <div className="cust-tag-div d-flex">
                      {this.state.howToMeasureDataArr &&
                        this.state.howToMeasureDataArr.map((item, i) => {
                          let filtered = this.state.howToMeasureData.filter((l) => parseInt(item) === l.id);
                          return (
                            <ul key={i}>
                              {filtered &&
                                filtered.map((m, i) => {
                                  return (
                                    <li key={i}>
                                      <span>{m.title_en}</span>
                                      <mark onClick={() => this.removeMeasure(m.id)} className=" bg-transparent bi bi-x p-0"></mark>
                                    </li>
                                  );
                                })}
                            </ul>
                          );
                        })}
                    </div>
                  </div>
                </div>
                <div className="col-md-12 text-center mt-5">
                  <button onClick={this.handleSave} className="red-btn">
                    {sizeGuidelinesLanguage.save}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Adminlayout>
    );
  }
}

export default withRouter(AddSizeGuideline);