import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import DataTable from "../../Components/DataTable";
import { textFilter } from "react-bootstrap-table2-filter";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";
import { Dropdown, Modal } from "react-bootstrap";
import SearchIcon from "../../images/search-icon.svg";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import Moment from "moment";
import 'react-date-range/dist/styles.css';
import 'react-date-range/dist/theme/default.css';
import { DateRangePicker } from 'react-date-range';
import {
  APIBaseUrl,
  API_Path,
  buttonArabic,
  buttonEnglish,
  SidebarArabic,
  SidebarEnglish,
  TableFieldArabic,
  TableFieldEnglish,
  titleArabic,
  orderEnglish,
  orderArabic,
  titleEnglish,
  productEnglish,
  productArabic,
  LIVE_FILE_URL,
} from "../../const";
import LanguageContext from "../../contexts/languageContext";
import productimg from "../../images/product-img.png";
import dummyThumb from "../../images/store.png";
import Select from "react-select";
import moment from "moment";
import toastr from "toastr";
import MUITable from "../../Components/MUITable";
import "toastr/build/toastr.min.css";
import { PostApi } from "../../helper/APIService";
import ProductDetailModal from "./ProductDetailModal";
import plusImg from "../../images/plus-icn.svg";
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";
import { withRouter } from "react-router-dom";

let TagFilterArray = [];
let TagFilterValueArray = [];
let BarcodeArray = [];
let IdArr = [];
let tagActionArr = [];
let offerActionArr = [];

const theme = createMuiTheme({
  palette: {
    primary: {
      light: "#757ce8",
      main: "#a81a1c",
      dark: "#002884",
      contrastText: "#fff",
    },
    secondary: {
      light: "#ff7961",
      main: "#f44336",
      dark: "#ba000d",
      contrastText: "#000",
    },
  },
});

export class AbandonedCart extends Component {
  static contextType = LanguageContext;

  constructor(props) {
    super(props);
    this.state = {
      search_show: false,
      productCode: "",
      settingmodal: "",
      View_Product_id: "",
      Product_details_model_show: false,
      change_status_modal_show: false,
      add_tag_model_show: false,
      add_offer_model_show: false,
      change_category_model_show: false,
      filter_model_show: false,
      statusAction: "",
      tagAction: "",
      offerAction: "",
      id: "",
      categoryChangeAction: [],
      categoryArray: [],
      filterStatus: "",
      barcodeOption: "",
      barcodeNumber: "",
      productBehaviour: "",
      mainCategory: "",
      Category: "",
      subCategory: "",
      mainCategoryChange: "",
      CategoryChange: "",
      subCategoryChange: "",
      startDate: new Date(),
      endDate: new Date(),
      products: "",
      tag: "",
      tagsForDisplay: "",
      tagValueForDisplay: "",
      barcodeForDisplay: "",
      barcodeValueForDisplay: "",
      loading: true,
      selectedOption: "",
      page: 1,
      sizePerPage: 10,
      totalSize: 0,
      totalPage: 1,
      columnSort: "id",
      defaultSorted: [
        {
          dataField: "id",
          order: "desc",
        },
      ],
      order: "desc",
      product_data: [],
      isCloneshow: false,
      barcodeno: "",
      Pid: "",
      status: "",
      ActionTagArr: [
        {
          value: "A1",
          tagName: "Winter",
        },
        {
          value: "A2",
          tagName: "Back to school",
        },
        {
          value: "A3",
          tagName: "60% off",
        },
        {
          value: "A4",
          tagName: "60% off",
        },
        {
          value: "A5",
          tagName: "back to school",
        },
        {
          value: "A6",
          tagName: "60% off",
        },
        {
          value: "A7",
          tagName: "60% off",
        },
        {
          value: "A8",
          tagName: "60% off",
        },
        {
          value: "A9",
          tagName: "60% off",
        },
      ],
      ActionOfferArr: [
        {
          value: "B1",
          tagName: "CODE (FREESHIP) 10%",
        },
        {
          value: "B2",
          tagName: "RAMADAN OFFER SR50 OFF",
        },
        {
          value: "B3",
          tagName: "50% OFF",
        },
        {
          value: "B4",
          tagName: "30% OFF",
        },
        {
          value: "B5",
          tagName: "60% OFF",
        },
        {
          value: "B6",
          tagName: "NEW OFFER",
        },
        {
          value: "B7",
          tagName: "NEW YEAR",
        },
        {
          value: "B8",
          tagName: "EID OFFER",
        },
        {
          value: "B9",
          tagName: "BUNDLE OFFER 25SR",
        },
        {
          value: "B10",
          tagName: "BUY1 GET1",
        },
      ],
    };
  }

  options = [
    { value: "Summer", label: "Summer" },
    { value: "winter", label: "winter" },
    { value: "monsoon", label: "monsoon" },
  ];

  componentDidMount() {
    this.GenerateProductCode(6);
    this.get_product_data();
    this.getMainCategory();
  }

  get_product_data = () => {
    const data = {
      column: this.state.columnSort,
      sizePerPage: this.state.sizePerPage,
      page: this.state.page,
      order: this.state.order,
      search_val: this.state.searchProduct,
    };
    const getAllProductDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(API_Path.getAllProduct, data));
    });
    getAllProductDataPromise.then((response) => {
      if (response.data.success) {
        this.setState(
          {
            product_data: response.data.data,
            totalSize: response.data.totalRecord,
          },
          () => {
            this.setState({
              totalPage: this.state.totalSize / this.state.sizePerPage,
            });
          }
        );
      } else {
        toastr.error(response.data.message);
      }
    });
  };

  filterProducts = () => {
    const path = API_Path.filterProduct;
    const data = {
      search: this.state.searchProduct,
      barcodes: this.state.barcodeValueForDisplay,
      tags: this.state.tagValueForDisplay,
      status: this.state.filterStatus,
      main_category: this.state.mainCategoryChange,
      category: this.state.CategoryChange,
      sub_category: this.state.subCategoryChange,
      behaviour: this.state.productBehaviour,
      from_date: this.state.startDate,
      to_date: this.state.endDate,
    };
    const getAllProductDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getAllProductDataPromise.then((res) => {
      if (res.data.success) {
        BarcodeArray = [];
        this.setState({
          products: res.data.data,
          barcodeNumber: "",
          barcodeOption: "",
          barcodeForDisplay: "",
          barcodeValueForDisplay: "",
          tagsForDisplay: "",
          tagValueForDisplay: "",
          filterStatus: "",
          mainCategoryChange: "",
          CategoryChange: "",
          subCategoryChange: "",
          productBehaviour: "",
          startDate: "",
          endDate: "",
        });
        this.filteredProductsList();
      } else {
        this.setState({
          barcodeNumber: "",
          barcodeOption: "",
          barcodeForDisplay: "",
          barcodeValueForDisplay: "",
          tagsForDisplay: "",
          tagValueForDisplay: "",
          filterStatus: "",
          mainCategoryChange: "",
          CategoryChange: "",
          subCategoryChange: "",
          productBehaviour: "",
          startDate: "",
          endDate: "",
        });
        toastr.error(res.data.message);
      }
    });
    document.querySelector('button[aria-label="Close"]').click();
  };

  filteredProductsList = () => {
    let path = API_Path.filteredProductList;
    let data = {
      column: "id",
      order: "desc",
      page: this.state.page,
      sizePerPage: this.state.sizePerPage,
      products: this.state.products,
    };

    const filteredProductListPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    filteredProductListPromise.then((res) => {
      if (res) {
        if (res.data.success) {
          this.setState({ product_data: res.data.data });
          toastr.success(res.data.message);
        } else {
          console.log(res.data.message);
        }
      }
    });
  };

  getMainCategory = () => {
    const getMainCategoryPromise = new Promise((resolve, reject) => {
      resolve(PostApi(API_Path.mainCategory));
    });
    getMainCategoryPromise.then((res) => {
      if (res.data.success) {
        this.setState({ mainCategory: res.data.data });
      } else {
        console.log(res);
      }
    });
  };

  getRelativeCategoryData = (id) => {
    let data = { main_category_id: id };
    let path = API_Path.getCategoryRelative;
    const getSubCategoryRelativePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getSubCategoryRelativePromise.then((res) => {
      if (res.data.success) {
        this.setState({ Category: res.data.data });
      } else {
        console.log(res);
      }
    });
  };

  getRelativeSubCategoryData = (id) => {
    let data = { category_id: id };
    let path = API_Path.getSubCategoryRelative;
    const getSubCategoryRelativePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getSubCategoryRelativePromise.then((res) => {
      if (res.data.success) {
        this.setState({ subCategory: res.data.data });
      } else {
        console.log(res);
      }
    });
  };

  changeProductStatusAction = () => {
    let path = API_Path.getAllProductAction;
    let data = {
      action: "status",
      status: this.state.statusAction,
      products: this.state.id,
    };

    const changeProductStatusAction = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    changeProductStatusAction.then((res) => {
      if (res) {
        if (res.data.success) {
          toastr.success(res.data.message);
          this.setState({ statusAction: "" });
          this.change_status_handleClose();
        } else {
          toastr.error(res.data.message);
          this.change_status_handleClose();
        }
      }
    });
  };

  finalyDeleteProducts = () => {
    let path = API_Path.getAllProductAction;
    let data = {
      action: "remove",
      remove: true,
      products: this.state.id,
    };

    const deleteProductsAction = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    deleteProductsAction.then((res) => {
      if (res) {
        if (res.data.success) {
          toastr.success(res.data.message);
        } else {
          toastr.error(res.data.message);
        }
      }
    });
  };

  changeProductCategoryAction = () => {
    let path = API_Path.getAllProductAction;
    let categoryArr = [
      this.state.categoryChangeAction.mainCat,
      this.state.categoryChangeAction.Cat,
      this.state.categoryChangeAction.subCat,
    ];
    this.setState({ categoryArray: categoryArr }, () => {
      let data = {
        action: "category",
        category: this.state.categoryArray,
        products: this.state.id,
      };

      const changeProductCategoryAction = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      changeProductCategoryAction.then((res) => {
        if (res) {
          if (res.data.success) {
            console.log(res.data);
          } else {
            console.log(res.data);
          }
        }
      });
    });
  };

  addTagAction = () => {
    if (this.state.A1 == true) {
      tagActionArr.push("Winter");
    }
    if (this.state.A2 == true) {
      tagActionArr.push("Back to school");
    }
    if (this.state.A3 == true) {
      tagActionArr.push("60% off");
    }
    if (this.state.A4 == true) {
      tagActionArr.push("60% off");
    }
    if (this.state.A5 == true) {
      tagActionArr.push("back to school");
    }
    if (this.state.A6 == true) {
      tagActionArr.push("60% off");
    }
    if (this.state.A7 == true) {
      tagActionArr.push("60% off");
    }
    if (this.state.A8 == true) {
      tagActionArr.push("60% off");
    }
    if (this.state.A9 == true) {
      tagActionArr.push("60% off");
    }

    this.setState({ tagAction: tagActionArr }, () => {
      console.log(this.state.tagAction);
      let path = API_Path.getAllProductAction;
      let data = {
        action: "add_tag",
        products: this.state.id,
        tags: this.state.tagAction,
      };

      const addTagAction = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      addTagAction.then((res) => {
        if (res) {
          if (res.data.success) {
            toastr.success(res.data.message);
            this.add_tag_Close();
          } else {
            toastr.error(res.data.message);
          }
        }
      });
    });
  };

  removeTagAction = () => {
    let path = API_Path.getAllProductAction;
    let data = {
      action: "remove_tag",
      products: this.state.id,
      tags: this.state.tagAction,
    };

    const removeTagAction = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    removeTagAction.then((res) => {
      if (res) {
        if (res.data.success) {
          toastr.success(res.data.message);
        } else {
          toastr.error(res.data.message);
        }
      }
    });
  };

  addOfferAction = () => {
    let sum = 0;
    if (this.state.B1 == true) {
      sum = sum + 1;
    }
    if (this.state.B2 == true) {
      sum = sum + 1;
    }
    if (this.state.B3 == true) {
      sum = sum + 1;
    }
    if (this.state.B4 == true) {
      sum = sum + 1;
    }
    if (this.state.B5 == true) {
      sum = sum + 1;
    }
    if (this.state.B6 == true) {
      sum = sum + 1;
    }
    if (this.state.B7 == true) {
      sum = sum + 1;
    }
    if (this.state.B8 == true) {
      sum = sum + 1;
    }
    if (this.state.B9 == true) {
      sum = sum + 1;
    }
    if (this.state.B10 == true) {
      sum = sum + 1;
    }

    this.setState({ sum: sum }, () => {
      let path = API_Path.getAllProductAction;
      let data = {
        action: "add_offer",
        products: this.state.id,
        add_offer: this.state.sum,
      };

      const addOfferAction = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      addOfferAction.then((res) => {
        if (res) {
          if (res.data.success) {
            toastr.success(res.data.message);
            this.setState({ sum: 0 });
            this.add_offer_Close();
          } else {
            toastr.error(res.data.message);
          }
        }
      });
    });
  };

  removeOfferAction = () => {
    let path = API_Path.getAllProductAction;
    let data = {
      action: "remove_offer",
      products: this.state.id,
      remove_offer: true,
    };

    const removeOfferAction = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    removeOfferAction.then((res) => {
      if (res) {
        if (res.data.success) {
          toastr.success(res.data.message);
        } else {
          toastr.error(res.data.message);
        }
      }
    });
  };

  handleChanges = (selectedOption) => {
    this.setState({ selectedOption });
  };

  edit_userClose = () => {
    this.setState({ search_show: false });
  };

  edit_userShow = (e) => {
    e.preventDefault();
    this.setState({ search_show: true });
  };

  edit_handleShow = (e) => {
    e.preventDefault();
    this.setState({ search_show: true });
  };

  handleClone(id) {
    console.log(id);
    this.setState({ isCloneshow: true, Pid: id });
  }

  handleCloneClose = () => {
    this.setState({ isCloneshow: false });
  };

  handleBarcodeChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  GenerateProductCode = (length) => {
    var barcode = Math.floor(1000 + Math.random() * 9000);
    var result = "";
    var characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    var charactersLength = characters.length;
    for (var i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    this.setState({ productCode: result, barcodeno: barcode });
    // return result;
  };

  createCloneProduct = () => {
    // console.log(this.state.Pid, "-------");
    const data = {
      id: this.state.Pid,
      productCode: this.state.productCode,
      barcodeno: this.state.barcodeno,
    };
    console.log(data, "=======");
    const createDuplicateProductPromise = new Promise((resolve) => {
      resolve(PostApi(API_Path.duplicateProduct, data));
    });
    createDuplicateProductPromise.then((res) => {
      console.log(res);
      if (res.status == 200) {
        this.setState({ isCloneshow: false });
        this.handleCloneClose();
      } else {
        console.log(res.data.messgae);
      }
    });
  };

  delete_record = (id) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>Are you sure?</h1>
            <p>You want to delete this file?</p>
            <button className="btn red-btn me-2" onClick={onClose}>
              No
            </button>
            <button
              className="btn red-btn"
              onClick={() => {
                this.finaly_delete_record(id);
                onClose();
              }}
            >
              Yes, Delete it!
            </button>
          </div>
        );
      },
    });
  };

  finaly_delete_record = (id) => {
    let path = API_Path.getAllProductAction;
    let data = {
      action: "remove",
      remove: true,
      products: [id],
    };

    const deleteProductsAction = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    deleteProductsAction.then((res) => {
      if (res) {
        if (res.data.success) {
          toastr.success(res.data.message);
        } else {
          toastr.error(res.data.message);
        }
      }
    });
  };

  handleReturn = () => {
    this.props.history.push("/return-product");
  };

  customStyles = {
    control: () => ({
      height: "50px",
      backgroundColor: "#F7F7F7",
      border: "1px solid #F7F7F7",
      borderRadius: "10px",
      fontSize: "16px",
      color: "#5E5E6C",
      marginBottom: "15px",
      display: "flex",
    }),

    indicatorSeparator: () => ({
      backgroundColor: "transparent",
    }),

    indicatorContainer: () => ({
      backgroundColor: "#000",
    }),
  };

  View_product_detail_handleShow = (id) => {
    this.setState({ Product_details_model_show: true, View_Product_id: id });
  };

  View_product_detail_handleClose = () => {
    this.setState({ Product_details_model_show: false });
  };

  change_status_handleShow = () => {
    this.setState({ change_status_modal_show: true });
  };

  change_status_handleClose = () => {
    this.setState({ change_status_modal_show: false });
  };

  add_tag_show = () => {
    this.setState({ add_tag_model_show: true });
  };

  add_tag_Close = () => {
    this.setState({ add_tag_model_show: false });
  };

  add_offer_show = () => {
    this.setState({ add_offer_model_show: true });
  };

  add_offer_Close = () => {
    this.setState({ add_offer_model_show: false });
  };

  change_category_show = () => {
    this.setState({ change_category_model_show: true });
  };

  change_category_Close = () => {
    this.setState({ change_category_model_show: false });
  };

  handleTag = (e) => {
    this.setState({ tag: e.target.value });
  };

  handleAddTag = () => {
    if (this.state.tag !== "") {
      let data = {
        value: this.state.tag,
        id: Date.now(),
      };
      let value = this.state.tag;
      TagFilterValueArray.push(value);
      TagFilterArray.push(data);
      this.setState(
        {
          tag: "",
          tagsForDisplay: TagFilterArray,
          tagValueForDisplay: TagFilterValueArray,
        },
        () => {
          console.log("tags :: ", this.state.tagValueForDisplay);
        }
      );
    }
  };

  removeTag = (idToRemove) => {
    const filteredTag = TagFilterArray.filter((item) => item.id !== idToRemove);
    TagFilterArray = filteredTag;
    this.setState({ tagsForDisplay: filteredTag });
  };

  handleChangeStatus = (e) => {
    this.setState({ statusAction: e.target.value });
  };

  deleteProducts = () => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>Are you sure?</h1>
            <p>You want to delete this file?</p>
            <button className="btn red-btn me-2" onClick={onClose}>
              No
            </button>
            <button
              className="btn red-btn"
              onClick={() => {
                this.finalyDeleteProducts();
                onClose();
              }}
            >
              Yes, Delete it!
            </button>
          </div>
        );
      },
    });
  };

  makeId = (length) => {
    var result = "";
    var characters =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    var charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  };

  handleBarcodeButtonChange = (e) => {
    this.setState({ barcodeOption: e.target.value });
  };

  handleBarcodeNumber = (e) => {
    this.setState({ barcodeNumber: e.target.value }, () => {
      if (e.keyCode === 13) {
        if (this.state.barcodeNumber !== "") {
          this.state.barcodeNumber
            .trim()
            .split(/\s+/)
            .map((item, i) => {
              let data = {
                value: item,
                id: this.makeId(7),
              };
              BarcodeArray.push(data);
            });
          let BarcodeValueArray = [];
          BarcodeArray.map((l) => {
            let value = l.value;
            BarcodeValueArray.push(value);
          });
          this.setState(
            {
              barcodeNumber: "",
              barcodeForDisplay: BarcodeArray,
              barcodeValueForDisplay: BarcodeValueArray,
            },
            () => {
              document.getElementById("barcodeInput").value = "";
            }
          );
        }
      }
    });
  };

  removeBarcode = (idToRemove) => {
    const barcodeNum = BarcodeArray.filter((item) => item.id !== idToRemove);
    BarcodeArray = barcodeNum;
    this.setState({ barcodeForDisplay: barcodeNum });
  };

  changeStatusFilter = (e) => {
    this.setState({ filterStatus: e.target.value });
  };

  handleSelect(ranges) {
    console.log(ranges);
    // {
    //   selection: {
    //     startDate: [native Date Object],
    //     endDate: [native Date Object],
    //   }
    // }
  }

  changeProductBehaviour = (e) => {
    this.setState({ productBehaviour: e.target.value });
  };

  changeMainCategory = (e) => {
    this.setState({ mainCategoryChange: e.target.value }, () => {
      this.getRelativeCategoryData(e.target.value);
    });
  };

  changeCategory = (e) => {
    this.setState({ CategoryChange: e.target.value }, () => {
      this.getRelativeSubCategoryData(e.target.value);
    });
  };

  changeSubCategory = (e) => {
    this.setState({ subCategoryChange: e.target.value });
  };

  handleChangeStartDate = (e) => {
    this.setState({ startDate: Moment(e).format("YYYY-MM-DD") });
  };

  handleChangeEndDate = (e) => {
    this.setState({ endDate: Moment(e).format("YYYY-MM-DD") });
  };

  handleSearchChange = (e) => {
    let text = e.target.value;
    const search_val = text.slice(0, -1);
    this.setState({ searchProduct: search_val }, () => {
      this.get_product_data();
    });
  };

  handleSelectRow = (currentRowsSelected, allRowsSelected) => {
    if (currentRowsSelected.length > 0) {
      currentRowsSelected.map((l) => {
        let index = l.dataIndex;
        let idObj = this.state.product_data[index].id;
        IdArr.push(idObj);
        this.setState({ id: IdArr });
      });
    } else {
      IdArr = [];
    }
  };

  handleTagCheckBox = (e) => {
    this.setState({ [e.target.name]: e.target.checked });
  };

  handleOfferCheckBox = (e) => {
    this.setState({ [e.target.name]: e.target.checked });
  };

  handleCategoryActionChange = (e) => {
    this.setState({ categoryChangeAction: JSON.parse(e.target.value) }, () => {
      console.log(this.state.categoryChangeAction);
    });
  };

  handleOnChangeRowsPerPage = (numberOfRows) => {
    this.setState({ sizePerPage: numberOfRows }, () => {
      this.get_product_data();
    });
  };

  changePage = (page) => {
    this.setState(
      {
        page: page + 1,
      },
      () => {
        this.get_product_data();
      }
    );
  };

  onChangeColumnSort = (changedColumn, direction) => {
    this.setState({ columnSort: changedColumn }, () => {
      this.get_product_data();
    });
  };

  settingmodal = () => {
    this.setState({ settingmodal: true });
  };
  settingmodalclose = () => {
    this.setState({ settingmodal: false });
  };

  selectmonthmodalShow = () => {
    this.setState({ selectmonthmodal: true });
  };
  selectmonthmodalclose = () => {
    this.setState({ selectmonthmodal: false });
  };

  edit_filterClose = () => {
    this.setState({ search_show: false });
  };

  editfilter_Show = (e) => {
    e.preventDefault();
    this.setState({ search_show: true });
  };

  filter_handleShow = (e) => {
    e.preventDefault();
    this.setState({ search_show: true });
  };

  featured = (e, id) => {
    const data = {
      preference: e.target.checked ? true : false,
      product_id: id,
    };
    const getAllProductDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(API_Path.updatePreference, data));
    });
    getAllProductDataPromise.then((res) => {
      if (res.data.success) {
        this.get_product_data()
        toastr.success(res.data.message)
      } else {
        toastr.error(res.data.message);
      }
    });
  };

  render() {

    const selectionRange = {
      startDate: new Date(),
      endDate: new Date(),
      key: 'selection',
    }

    let Language =
      this.context.language === "english" ? TableFieldEnglish : TableFieldArabic;
    let ButtonLanguage =
      this.context.language === "english" ? buttonEnglish : buttonArabic;
    let titleLanguage =
      this.context.language === "english" ? titleEnglish : titleArabic;
    let productLanguage =
      this.context.language === "english" ? productEnglish : productArabic;
    let orderLanguage =
      this.context.language === "english" ? orderEnglish : orderArabic;

    const abandoned_data = [
      {
        checkout: "4234234234234",
        Customer_Name: "John Doe",
        Date: "30 Apr  2022  12:30 pm",
        products: "5",
        phone_number: "05050505686",
        value_sar: "526.00",
        cart_phase: "New"
      },
      {
        checkout: "4234234234234",
        Customer_Name: "John Doe",
        Date: "30 Apr  2022  12:30 pm",
        products: "5",
        phone_number: "05050505686",
        value_sar: "526.00",
        cart_phase: "New"
      },
      {
        checkout: "4234234234234",
        Customer_Name: "John Doe",
        Date: "30 Apr  2022  12:30 pm",
        products: "5",
        phone_number: "05050505686",
        value_sar: "526.00",
        cart_phase: "New"
      },
      {
        checkout: "4234234234234",
        Customer_Name: "John Doe",
        Date: "30 Apr  2022  12:30 pm",
        products: "5",
        phone_number: "05050505686",
        value_sar: "526.00",
        cart_phase: "New"
      },
      {
        checkout: "4234234234234",
        Customer_Name: "John Doe",
        Date: "30 Apr  2022  12:30 pm",
        products: "5",
        phone_number: "05050505686",
        value_sar: "526.00",
        cart_phase: "New"
      },
      {
        checkout: "4234234234234",
        Customer_Name: "John Doe",
        Date: "30 Apr  2022  12:30 pm",
        products: "5",
        phone_number: "05050505686",
        value_sar: "526.00",
        cart_phase: "New"
      },
    ];
    const columns = [
      {
        name: "checkout",
        label: "Checkout #",
        options: {
          customBodyRender: (value, tableMeta, updateValue) => {
            return (
              <label className="red-text-class">4234234234234</label>
            );
          },
        },
      },
      {
        name: "Customer_Name",
        label: "Customer Name",
        options: {},
      },
      {
        name: "Date",
        label: "Date",
        options: {
        },
      },
      {
        name: "products",
        label: "Products",
        options: {
          display: false,
        },
      },
      {
        name: "phone_number",
        label: "Phone number",
        options: {},
      },
      {
        name: "value_sar",
        label: "Value (SAR)",
        options: {},
      },
      {
        name: "cart_phase",
        label: "Cart  Phase",
        options: {},
      },
      {
        name: "status",
        label: productLanguage.status,
        options: {
          customBodyRender: (value, tableMeta, updateValue) => {
            return (
              <span className="status-text red-text-status">
                message sent
              </span>
            );
          },
        },
      },
      {
        name: "id",
        label: productLanguage.action,
        options: {
          sort: false,
          csvExport: false,
          customBodyRender: (value, tableMeta, updateValue) => {
            return (
              <React.Fragment>
                <Dropdown className="cust-drop">
                  <Dropdown.Toggle
                    className="bg-transparent "
                    id="dropdown-basic"
                    align="end"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width={16}
                      height={16}
                      fill="currentColor"
                      className="bi bi-three-dots-vertical"
                      viewBox="0 0 16 16"
                    >
                      <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                    </svg>
                  </Dropdown.Toggle>
                  <Dropdown.Menu>
                    {/* <Dropdown.Item href="#" onClick={() => this.View_product_detail_handleShow(value)}>
                                        <svg width={20} height={15} viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M10 14C8.35987 14.0204 6.7367 13.6665 5.254 12.965C4.10469 12.4042 3.07265 11.6298 2.213 10.683C1.30243 9.70413 0.585467 8.56167 0.1 7.31601L0 7.00001L0.105 6.68401C0.590815 5.43944 1.30624 4.29728 2.214 3.31701C3.07334 2.37032 4.10504 1.59587 5.254 1.03501C6.73671 0.333598 8.35988 -0.0203796 10 9.39617e-06C11.6401 -0.0203444 13.2633 0.333631 14.746 1.03501C15.8953 1.59574 16.9274 2.3702 17.787 3.31701C18.6993 4.29456 19.4165 5.43737 19.9 6.68401L20 7.00001L19.895 7.31601C18.3262 11.3998 14.3742 14.0694 10 14ZM10 2.00001C6.59587 1.89334 3.47142 3.8751 2.117 7.00001C3.4712 10.1251 6.59579 12.107 10 12C13.4041 12.1064 16.5284 10.1247 17.883 7.00001C16.5304 3.87359 13.4047 1.89109 10 2.00001ZM10 10C8.55733 10.0096 7.30937 8.99737 7.02097 7.58378C6.73256 6.1702 7.48427 4.75003 8.81538 4.19367C10.1465 3.63731 11.6852 4.10014 12.4885 5.29852C13.2919 6.49689 13.1354 8.09609 12.115 9.11601C11.5563 9.68127 10.7948 9.99957 10 10Z" fill="#2D2D3B" />
                                        </svg>
                                        <span>View</span>
                                    </Dropdown.Item> */}

                    <Dropdown.Item href={"product-details/" + value}>
                      <svg
                        width="19"
                        height="18"
                        viewBox="0 0 19 19"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
                          fill="#2D2D3B"
                        ></path>
                      </svg>
                      <span>View</span>
                    </Dropdown.Item>
                    <Dropdown.Item href="#">
                      <svg width="16" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M5 12L11 6M5.50003 6.5H5.51003M10.5 11.5H10.51M15 19V3C15 1.89543 14.1046 1 13 1H3C1.89543 1 1 1.89543 1 3V19L4.5 17L8 19L11.5 17L15 19ZM6 6.5C6 6.77614 5.77614 7 5.5 7C5.22386 7 5 6.77614 5 6.5C5 6.22386 5.22386 6 5.5 6C5.77614 6 6 6.22386 6 6.5ZM11 11.5C11 11.7761 10.7761 12 10.5 12C10.2239 12 10 11.7761 10 11.5C10 11.2239 10.2239 11 10.5 11C10.7761 11 11 11.2239 11 11.5Z" stroke="#111827" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                      <span>Send offer</span>
                    </Dropdown.Item>
                    <Dropdown.Item
                      href="#"
                    // onClick={() => this.delete_record(value)}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width={18}
                        height={18}
                        fill="currentColor"
                        className="bi bi-trash"
                        viewBox="0 0 16 16"
                      >
                        <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
                        <path
                          fillRule="evenodd"
                          d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"
                        />
                      </svg>
                      <span>Delete</span>
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              </React.Fragment>
            );
          },
        },
      },
    ];

    const option = {
      print: false,
      sortDescFirst: true,
      serverSide: true,
      responsive: "standard",
      confirmFilters: true,
      download: false,
      filter: false,
      viewColumns: false,
      search: false,
      pagination: true,
      jumpToPage: true,
      rowsPerPageOptions: [5, 10, 15, 50, 100],

    };



    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space">
            <div className="col-sm-6 text-sm-start text-center rtl-txt-start">
              <div className="common-header-txt">
                <h3>Abandoned carts</h3>
              </div>
            </div>
          </div>
          <div className="row common-space">
            <div className="col-md-9">
              <div className="white-box">
                <div className="row">
                  <div className="col-xxl-6 mb-xxl-0 mb-2">
                    <div className="new-red-box">
                      <div className="d-flex align-items-center">
                        <div className="me-auto">
                          <svg width="27" height="27" viewBox="0 0 27 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8.09981 24.3012C8.47261 24.3012 8.77482 23.999 8.77482 23.6262C8.77482 23.2534 8.47261 22.9512 8.09981 22.9512C7.72702 22.9512 7.4248 23.2534 7.4248 23.6262C7.4248 23.999 7.72702 24.3012 8.09981 24.3012Z" fill="#A81A1C" />
                            <path d="M18.675 5.35001C19.0478 5.35001 19.35 5.0478 19.35 4.67501C19.35 4.30221 19.0478 4 18.675 4C18.3022 4 18 4.30221 18 4.67501C18 5.0478 18.3022 5.35001 18.675 5.35001Z" fill="#A81A1C" />
                            <path d="M23.675 5.35001C24.0478 5.35001 24.35 5.0478 24.35 4.67501C24.35 4.30221 24.0478 4 23.675 4C23.3022 4 23 4.30221 23 4.67501C23 5.0478 23.3022 5.35001 23.675 5.35001Z" fill="#A81A1C" />
                            <path d="M21.5998 24.3012C21.9726 24.3012 22.2748 23.999 22.2748 23.6262C22.2748 23.2534 21.9726 22.9512 21.5998 22.9512C21.227 22.9512 20.9248 23.2534 20.9248 23.6262C20.9248 23.999 21.227 24.3012 21.5998 24.3012Z" fill="#A81A1C" />
                            <path d="M26.325 22.9504H24.907C24.5942 21.41 23.233 20.2504 21.5999 20.2504C19.9673 20.2504 18.6056 21.41 18.2929 22.9504H11.4051C11.1031 21.4731 9.83231 20.3543 8.28428 20.2689L6.06757 5.30128C6.04642 5.15774 5.97934 5.0259 5.8772 4.9228L1.15215 0.197756C0.888477 -0.0659186 0.46143 -0.0659186 0.197756 0.197756C-0.0659186 0.46143 -0.0659186 0.88853 0.197756 1.1522L4.76528 5.71883L6.94961 20.4646C5.6545 20.9366 4.72478 22.1674 4.72478 23.6254C4.72478 25.4893 6.2359 27.0004 8.09981 27.0004C9.73243 27.0004 11.0942 25.8408 11.4069 24.3004H18.2928C18.6056 25.8408 19.9673 27.0004 21.5999 27.0004C23.2325 27.0004 24.5942 25.8408 24.9069 24.3004H26.325C26.698 24.3004 27 23.9984 27 23.6254C27 23.2524 26.698 22.9504 26.325 22.9504ZM8.09981 25.6505C6.98336 25.6505 6.07479 24.7419 6.07479 23.6254C6.07479 22.509 6.98336 21.6004 8.09981 21.6004C9.21626 21.6004 10.1248 22.509 10.1248 23.6254C10.1248 24.7419 9.21626 25.6505 8.09981 25.6505ZM21.5999 25.6505C20.4835 25.6505 19.5749 24.7419 19.5749 23.6254C19.5749 22.509 20.4835 21.6004 21.5999 21.6004C22.7164 21.6004 23.625 22.509 23.625 23.6254C23.625 24.7419 22.7164 25.6505 21.5999 25.6505Z" fill="#A81A1C" />
                            <path d="M24.348 12.6572L22.9498 17.5501H10.3947L9.04467 8.10001H13.7877C13.6639 7.66442 13.5762 7.21396 13.5339 6.75H9.04467C8.65316 6.75 8.28144 6.91965 8.02493 7.21528C7.76843 7.51091 7.65278 7.90331 7.70858 8.29081L9.05859 17.7409C9.15309 18.406 9.72279 18.9001 10.3946 18.9001H22.9498C23.5523 18.9001 24.0824 18.5005 24.2481 17.9209L26.1196 11.3711C25.5981 11.8828 25.0013 12.3161 24.348 12.6572Z" fill="#A81A1C" />
                            <path d="M20.9247 0C17.5694 0 14.8496 2.71985 14.8496 6.07506C14.8496 9.43026 17.5694 12.1501 20.9247 12.1501C24.2799 12.1501 26.9997 9.43032 26.9997 6.07506C26.9997 2.7198 24.2799 0 20.9247 0ZM20.9247 10.8001C18.3191 10.8001 16.1996 8.68058 16.1996 6.07506C16.1996 3.46953 18.3191 1.35001 20.9247 1.35001C23.5302 1.35001 25.6497 3.46953 25.6497 6.07506C25.6497 8.68058 23.5302 10.8001 20.9247 10.8001Z" fill="#A81A1C" />
                            <path d="M19.1655 8.82789C20.1771 7.95718 21.823 7.95714 22.8345 8.82785C23.1011 9.05736 23.5334 9.05736 23.8 8.82785C24.0667 8.59834 24.0667 8.22626 23.8 7.99675C23.028 7.33216 22.0142 7 21 7C19.9861 7 18.9719 7.33231 18.2 7.99675C17.9333 8.22622 17.9333 8.59834 18.2 8.82785C18.4666 9.0574 18.8989 9.05736 19.1655 8.82789Z" fill="#A81A1C" />
                          </svg>
                        </div>
                        <div className="mx-2"><p>Total number of abandoned carts</p></div>
                        <span className="ms-auto">2500</span>
                      </div>
                    </div>
                  </div>
                  <div className="col-xxl-6">
                    <div className="new-green-box">
                      <div className="d-flex align-items-center">
                        <div className="me-auto">
                          <svg width="27" height="27" viewBox="0 0 27 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8.09981 24.3012C8.47261 24.3012 8.77482 23.999 8.77482 23.6262C8.77482 23.2534 8.47261 22.9512 8.09981 22.9512C7.72702 22.9512 7.4248 23.2534 7.4248 23.6262C7.4248 23.999 7.72702 24.3012 8.09981 24.3012Z" fill="#2C661E" />
                            <path d="M18.675 5.35001C19.0478 5.35001 19.35 5.0478 19.35 4.67501C19.35 4.30221 19.0478 4 18.675 4C18.3022 4 18 4.30221 18 4.67501C18 5.0478 18.3022 5.35001 18.675 5.35001Z" fill="#2C661E" />
                            <path d="M23.675 5.35001C24.0478 5.35001 24.35 5.0478 24.35 4.67501C24.35 4.30221 24.0478 4 23.675 4C23.3022 4 23 4.30221 23 4.67501C23 5.0478 23.3022 5.35001 23.675 5.35001Z" fill="#2C661E" />
                            <path d="M21.5998 24.3012C21.9726 24.3012 22.2748 23.999 22.2748 23.6262C22.2748 23.2534 21.9726 22.9512 21.5998 22.9512C21.227 22.9512 20.9248 23.2534 20.9248 23.6262C20.9248 23.999 21.227 24.3012 21.5998 24.3012Z" fill="#2C661E" />
                            <path d="M26.325 22.9504H24.907C24.5942 21.41 23.233 20.2504 21.5999 20.2504C19.9673 20.2504 18.6056 21.41 18.2929 22.9504H11.4051C11.1031 21.4731 9.83231 20.3543 8.28428 20.2689L6.06757 5.30128C6.04642 5.15774 5.97934 5.0259 5.8772 4.9228L1.15215 0.197756C0.888477 -0.0659186 0.46143 -0.0659186 0.197756 0.197756C-0.0659186 0.46143 -0.0659186 0.88853 0.197756 1.1522L4.76528 5.71883L6.94961 20.4646C5.6545 20.9366 4.72478 22.1674 4.72478 23.6254C4.72478 25.4893 6.2359 27.0004 8.09981 27.0004C9.73243 27.0004 11.0942 25.8408 11.4069 24.3004H18.2928C18.6056 25.8408 19.9673 27.0004 21.5999 27.0004C23.2325 27.0004 24.5942 25.8408 24.9069 24.3004H26.325C26.698 24.3004 27 23.9984 27 23.6254C27 23.2524 26.698 22.9504 26.325 22.9504ZM8.09981 25.6505C6.98336 25.6505 6.07479 24.7419 6.07479 23.6254C6.07479 22.509 6.98336 21.6004 8.09981 21.6004C9.21626 21.6004 10.1248 22.509 10.1248 23.6254C10.1248 24.7419 9.21626 25.6505 8.09981 25.6505ZM21.5999 25.6505C20.4835 25.6505 19.5749 24.7419 19.5749 23.6254C19.5749 22.509 20.4835 21.6004 21.5999 21.6004C22.7164 21.6004 23.625 22.509 23.625 23.6254C23.625 24.7419 22.7164 25.6505 21.5999 25.6505Z" fill="#2C661E" />
                            <path d="M24.348 12.6572L22.9498 17.5501H10.3947L9.04467 8.10001H13.7877C13.6639 7.66442 13.5762 7.21396 13.5339 6.75H9.04467C8.65316 6.75 8.28144 6.91965 8.02493 7.21528C7.76843 7.51091 7.65278 7.90331 7.70858 8.29081L9.05859 17.7409C9.15309 18.406 9.72279 18.9001 10.3946 18.9001H22.9498C23.5523 18.9001 24.0824 18.5005 24.2481 17.9209L26.1196 11.3711C25.5981 11.8828 25.0013 12.3161 24.348 12.6572Z" fill="#2C661E" />
                            <path d="M20.9247 0C17.5694 0 14.8496 2.71985 14.8496 6.07506C14.8496 9.43026 17.5694 12.1501 20.9247 12.1501C24.2799 12.1501 26.9997 9.43032 26.9997 6.07506C26.9997 2.7198 24.2799 0 20.9247 0ZM20.9247 10.8001C18.3191 10.8001 16.1996 8.68058 16.1996 6.07506C16.1996 3.46953 18.3191 1.35001 20.9247 1.35001C23.5302 1.35001 25.6497 3.46953 25.6497 6.07506C25.6497 8.68058 23.5302 10.8001 20.9247 10.8001Z" fill="#2C661E" />
                            <path d="M22.8345 7.17211C21.8229 8.04282 20.177 8.04286 19.1655 7.17215C18.8989 6.94264 18.4666 6.94264 18.2 7.17215C17.9333 7.40166 17.9333 7.77374 18.2 8.00325C18.972 8.66784 19.9858 9 21 9C22.0139 9 23.0281 8.66768 23.8 8.00325C24.0667 7.77378 24.0667 7.40166 23.8 7.17215C23.5334 6.9426 23.1011 6.94264 22.8345 7.17211Z" fill="#2C661E" />
                          </svg>
                        </div>
                        <div className="mx-2"><p>Total number of abandoned carts turned into orders</p></div>
                        <span className="ms-auto">256</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div className="d-lg-flex align-items-center h-100">
                <Dropdown className="cust-drop">
                  <Dropdown.Toggle
                    className="bg-transparent red-text-class"
                    id="dropdown-basic"
                    align="end"
                  >
                    Apply action
                  </Dropdown.Toggle>
                  <Dropdown.Menu>
                    <Dropdown.Item className="border-0">
                      <span className="m-0">Send offer</span>
                    </Dropdown.Item>
                    <Dropdown.Item>
                      <span className="m-0">Delete </span>
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
                <div className="ms-2 mt-lg-0 mt-2 w-100">
                  <button className="red-border-btn w-100" onClick={this.settingmodal}>Settings</button>
                </div>
              </div>
            </div>
          </div>
          <div className="row common-space">
            <div className="col-md-12">
              <div className="white-box">
                <div className="btn-list-order mb-3">
                  <button className="btn white-btn me-sm-2 me-0 me-2" onClick={this.selectmonthmodalShow}>
                    This month
                    <i className="bi bi-caret-down-fill ms-2" />
                  </button>
                  <button
                    className="btn white-btn"
                    onClick={this.filter_handleShow}
                  >
                    Filter
                    <i className="bi bi-caret-down-fill ms-2" />
                  </button>
                </div>
                <div className="table-responsive dataTables_wrapper no-footer">
                  {this.state.product_data && (
                    <MuiThemeProvider theme={theme}>
                      <MUITable
                        data={abandoned_data}
                        columns={columns}
                        options={option}
                      />
                    </MuiThemeProvider>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>



        {/* ------------------------modal-------------------------- */}
        <Modal
          dialogClassName="modal-dialog-centered cust-width-modal"
          className="edit-user-modal cust-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.search_show}
          onHide={this.edit_filterClose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">Filter</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.edit_filterClose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <form className="row modal-form">
              <div className="col-md-12 form-group text-end mb-3">
                <a href="#" className="red-underline">
                  Reset
                </a>
              </div>
              <div className="col-md-6 form-group">
                <label>{Language.status}</label>
                <select className="form-control form-select">
                  <option>All</option>
                  <option>Completed</option>
                  <option>Pending</option>
                  <option>Cancelled</option>
                </select>
              </div>
              <div className="col-md-6 form-group">
                <label>{ButtonLanguage.City}</label>
                <Dropdown>
                  <Dropdown.Toggle className="btn dropdown-toggle cust-search-button w-100">
                    <span>New York</span>
                  </Dropdown.Toggle>
                  <Dropdown.Menu className="w-100 cust-drop-box">
                    <div className="u-search-dw">
                      <div className="sear-u-inp p-2 bg-transparent">
                        <div className="position-relative">
                          <input
                            className="form-control"
                            type="search"
                            placeholder={titleLanguage.search}
                          />
                        </div>
                        <div className="drop-body-cust ">
                          <ul>
                            <li>
                              <span>New York</span>
                            </li>
                            <li>
                              <span>Austin</span>
                            </li>
                            <li>
                              <span>Columbus</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </Dropdown.Menu>
                </Dropdown>
              </div>
              <div className="col-md-6 form-group">
                <label>{orderLanguage.shippingMethod}</label>
                <select className="form-control form-select">
                  <option>Aramex</option>
                  <option>Libsi Markah</option>
                  <option>UPs Shipping</option>
                  <option>Shipa</option>
                </select>
              </div>
              <div className="col-md-6 form-group">
                <label>{orderLanguage.paymentMethod}</label>
                <select className="form-control form-select">
                  <option>Paypal</option>
                  <option>Google Pay</option>
                  <option>Credit Card</option>
                  <option>COD</option>
                </select>
              </div>
              <div className="col-md-12 form-group text-center mb-3">
                <button type="button" className="btn red-btn">
                  {ButtonLanguage.save}
                </button>
              </div>
            </form>
          </Modal.Body>
        </Modal>


        {/* ------------------------Setting modal-------------------------- */}
        <Modal
          dialogClassName="modal-dialog-centered cust-modal-white-content"
          className="cust-white-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.settingmodal}
          onHide={this.settingmodalclose}
          size="xl"
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">Settings</h1>
            </Modal.Title>
            <button type="button" onClick={this.settingmodalclose} className="close btn-close"></button>
          </Modal.Header>
          <Modal.Body>
            <>
              <form>
                <div className="row modal-form cust-white-modal setting-cart-modal align-items-center">
                  <div className="col-md-12 border-bottom">
                    <div className="d-lg-flex align-items-center mb-3">
                      <div className="d-flex align-items-center">
                        <div className="me-3 form-group">
                          <label className="mb-0">Time after Abandoned Cart (hours)</label>
                        </div>
                        <div className="me-3">
                          <input className="form-control input-custom-class mb-0" placeholder="5.00" type="text" />
                        </div>
                      </div>
                      <div className="d-flex align-items-center mt-2 mt-lg-0">
                        <div className="me-3 form-group">
                          <label className="mb-0">Offer validity time (hours)</label>
                        </div>
                        <div>
                          <input className="form-control input-custom-class mb-0" placeholder="5.00" type="text" />
                        </div>
                      </div>
                      <div className="ms-xl-auto mt-2 mt-lg-0 ms-2">
                        <label className="switch "><input type="checkbox" /><div className="slider round"></div></label>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-12 border-bottom mb-3">
                    <div className="my-2 set-col-part">
                      <div className="row justify-content-center">
                        <div className="col-xl-4 col-md-6 mb-xl-0 mb-3">
                          <div className="row">
                            <div className="col-12 mb-3">
                              <div className="setting-col-info">
                                <span>If cart value is SAR</span>
                                <div className="mx-2">
                                  <input className="form-control input-custom-class mb-0" type="text" />
                                </div>
                                <span>To</span>
                                <div className="ms-2">
                                  <input className="form-control input-custom-class mb-0" type="text" />
                                </div>
                              </div>
                            </div>
                            <div className="col-12 mb-3">
                              <div className="form-group">
                                <label>offer to customer</label>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    FREE SHIPPING
                                  </label>
                                </div>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    FREE CASH ON DELIVERY
                                  </label>
                                </div>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    OFFER
                                  </label>
                                </div>
                              </div>
                            </div>
                            <div className="col-sm-6 mb-3">
                              <div className="form-group">
                                <label>Discount Type</label>
                                <select className="form-select form-control input-custom-class">
                                  <option value="percentage">Percentage</option>
                                  <option value="fixed">Fixed</option>
                                </select>
                              </div>
                            </div>
                            <div className="col-sm-6 mb-3">
                              <div className="form-group">
                                <label>Discount value</label>
                                <input className=" form-control input-custom-class" type="text" />
                              </div>
                            </div>
                            <div className="col-12">
                              <label>Coupon Code</label>
                              <input className=" form-control input-custom-class" type="text" placeholder="SDVH" />
                            </div>
                          </div>
                        </div>
                        <div className="col-xl-4 col-md-6 mb-xl-0 mb-3">
                          <div className="row">
                            <div className="col-12 mb-3">
                              <div className="setting-col-info">
                                <span>If cart value is SAR</span>
                                <div className="mx-2">
                                  <input className="form-control input-custom-class mb-0" type="text" />
                                </div>
                                <span>To</span>
                                <div className="ms-2">
                                  <input className="form-control input-custom-class mb-0" type="text" />
                                </div>
                              </div>
                            </div>
                            <div className="col-12 mb-3">
                              <div className="form-group">
                                <label>offer to customer</label>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    FREE CASH ON DELIVERY
                                  </label>
                                </div>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    OFFER
                                  </label>
                                </div>
                              </div>
                            </div>
                            <div className="col-sm-6 mb-3">
                              <div className="form-group">
                                <label>Discount Type</label>
                                <select className="form-select form-control input-custom-class">
                                  <option value="percentage">Percentage</option>
                                  <option value="fixed">Fixed</option>
                                </select>
                              </div>
                            </div>
                            <div className="col-sm-6 mb-3">
                              <div className="form-group">
                                <label>Discount value</label>
                                <input className=" form-control input-custom-class" type="text" />
                              </div>
                            </div>
                            <div className="col-12">
                              <label>Coupon Code</label>
                              <input className=" form-control input-custom-class" type="text" placeholder="SDVH" />
                            </div>
                          </div>
                        </div>
                        <div className="col-xl-4 col-md-6">
                          <div className="row">
                            <div className="col-12 mb-3">
                              <div className="setting-col-info">
                                <span>If cart value is SAR</span>
                                <div className="mx-2">
                                  <input className="form-control input-custom-class mb-0" type="text" />
                                </div>
                                <span>To</span>
                                <div className="ms-2">
                                  <input className="form-control input-custom-class mb-0" type="text" />
                                </div>
                              </div>
                            </div>
                            <div className="col-12 mb-3">
                              <div className="form-group">
                                <label>offer to customer</label>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    FREE CASH ON DELIVERY
                                  </label>
                                </div>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    OFFER
                                  </label>
                                </div>
                              </div>
                            </div>
                            <div className="col-sm-6 mb-3">
                              <div className="form-group">
                                <label>Discount Type</label>
                                <select className="form-select form-control input-custom-class">
                                  <option value="percentage">Percentage</option>
                                  <option value="fixed">Fixed</option>
                                </select>
                              </div>
                            </div>
                            <div className="col-sm-6 mb-3">
                              <div className="form-group">
                                <label>Discount value</label>
                                <input className=" form-control input-custom-class" type="text" />
                              </div>
                            </div>
                            <div className="col-12">
                              <label>Coupon Code</label>
                              <input className=" form-control input-custom-class" type="text" placeholder="SDVH" />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-lg-8 cust-send-msg mb-lg-0 mb-3">
                    <ul className="d-lg-flex align-items-center social-white-space">
                      <li>
                        <div className="cust-checkbox-new">
                          <label className="cust-chk-bx">
                            <input type="checkbox" />
                            <span className="cust-chkmark" />
                            <svg className="me-2" width={24} height={24} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path fillRule="evenodd" clipRule="evenodd" d="M12 24C18.6274 24 24 18.6274 24 12C24 5.37258 18.6274 0 12 0C5.37258 0 0 5.37258 0 12C0 14.1522 0.566569 16.172 1.55869 17.9185L0 24L6.26988 22.5461C7.97261 23.4732 9.92479 24 12 24ZM12 22.1538C17.6078 22.1538 22.1538 17.6078 22.1538 12C22.1538 6.39219 17.6078 1.84615 12 1.84615C6.39219 1.84615 1.84615 6.39219 1.84615 12C1.84615 14.1652 2.52386 16.1721 3.67872 17.8202L2.76923 21.2308L6.23994 20.3631C7.8766 21.4925 9.86106 22.1538 12 22.1538Z" fill="#A81A1C" />
                              <path d="M9.00002 6.42827C8.71471 5.8552 8.27702 5.90593 7.83486 5.90593C7.04465 5.90593 5.8125 6.85246 5.8125 8.61404C5.8125 10.0577 6.44867 11.6381 8.59236 14.0022C10.6612 16.2837 13.3795 17.4639 15.6362 17.4237C17.8929 17.3836 18.3572 15.4416 18.3572 14.7858C18.3572 14.4951 18.1768 14.3501 18.0525 14.3107C17.2835 13.9416 15.8651 13.2539 15.5424 13.1247C15.2197 12.9955 15.0512 13.1703 14.9464 13.2653C14.6538 13.5442 14.0736 14.3662 13.875 14.551C13.6764 14.7359 13.3802 14.6424 13.257 14.5725C12.8035 14.3905 11.5739 13.8436 10.5938 12.8935C9.38171 11.7185 9.31057 11.3142 9.0822 10.9543C8.89951 10.6665 9.03357 10.4898 9.10047 10.4126C9.36163 10.1113 9.72223 9.64607 9.88395 9.41487C10.0457 9.18368 9.91728 8.83266 9.84025 8.61404C9.50895 7.6738 9.22827 6.88672 9.00002 6.42827Z" fill="#A81A1C" />
                            </svg>
                            Whatsapp
                          </label>
                        </div>
                      </li>
                      <li>
                        <div className="cust-checkbox-new">
                          <label className="cust-chk-bx">
                            <input type="checkbox" />
                            <span className="cust-chkmark" />
                            <svg className="me-2" width={20} height={20} viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M2 2H18V14H3.17L2 15.17V2ZM2 0C0.9 0 0.00999999 0.9 0.00999999 2L0 20L4 16H18C19.1 16 20 15.1 20 14V2C20 0.9 19.1 0 18 0H2ZM4 10H12V12H4V10ZM4 7H16V9H4V7ZM4 4H16V6H4V4Z" fill="#A81A1C" />
                            </svg>
                            SMS
                          </label>
                        </div>
                      </li>
                      <li>
                        <div className="cust-checkbox-new">
                          <label className="cust-chk-bx">
                            <input type="checkbox" />
                            <span className="cust-chkmark" />
                            <svg className="me-2" width={21} height={19} viewBox="0 0 21 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M18 0H2C0.9 0 0 0.9 0 2V14C0 15.1 0.9 16 2 16H11V14H2V4L10 9L18 4V9H20V2C20 0.9 19.1 0 18 0ZM10 7L2 2H18L10 7ZM17 11L21 15L17 19V16H13V14H17V11Z" fill="#A81A1C" />
                            </svg>
                            E-mail
                          </label>
                        </div>
                      </li>
                      <li>
                        <div className="cust-checkbox-new">
                          <label className="cust-chk-bx">
                            <input type="checkbox" />
                            <span className="cust-chkmark" />
                            <svg width="24" height="26" viewBox="0 0 24 26" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M20.4444 13.9736V11.6552H18.6667V14.3448C18.6667 14.5826 18.7604 14.8106 18.9271 14.9787L21.3333 17.4057V18.8276H1.77778V17.4057L4.184 14.9787C4.35071 14.8106 4.44439 14.5826 4.44444 14.3448V10.7586C4.44215 9.49886 4.76947 8.2608 5.39334 7.16944C6.01721 6.07809 6.91553 5.1721 7.99761 4.54295C9.07969 3.91379 10.3072 3.58377 11.5562 3.58619C12.8052 3.5886 14.0314 3.92339 15.1111 4.55672V2.55221C14.265 2.17437 13.365 1.93355 12.4444 1.83865V0H10.6667V1.83865C8.47527 2.06353 6.44438 3.09998 4.9667 4.74759C3.48902 6.3952 2.66952 8.53692 2.66667 10.7586V13.9736L0.260444 16.4006C0.0937339 16.5687 5.03444e-05 16.7967 0 17.0345V19.7241C0 19.9619 0.0936505 20.19 0.260349 20.3581C0.427048 20.5262 0.653141 20.6207 0.888889 20.6207H7.11111V21.5172C7.11111 22.7061 7.57936 23.8463 8.41286 24.687C9.24635 25.5277 10.3768 26 11.5556 26C12.7343 26 13.8648 25.5277 14.6983 24.687C15.5317 23.8463 16 22.7061 16 21.5172V20.6207H22.2222C22.458 20.6207 22.6841 20.5262 22.8508 20.3581C23.0175 20.19 23.1111 19.9619 23.1111 19.7241V17.0345C23.1111 16.7967 23.0174 16.5687 22.8507 16.4006L20.4444 13.9736ZM14.2222 21.5172C14.2222 22.2306 13.9413 22.9147 13.4412 23.4191C12.9411 23.9235 12.2628 24.2069 11.5556 24.2069C10.8483 24.2069 10.17 23.9235 9.66994 23.4191C9.16984 22.9147 8.88889 22.2306 8.88889 21.5172V20.6207H14.2222V21.5172Z" fill="#A81A1C" />
                              <path d="M20.4442 9.86187C22.4079 9.86187 23.9998 8.25627 23.9998 6.27566C23.9998 4.29505 22.4079 2.68945 20.4442 2.68945C18.4805 2.68945 16.8887 4.29505 16.8887 6.27566C16.8887 8.25627 18.4805 9.86187 20.4442 9.86187Z" fill="#A81A1C" />
                            </svg>
                            Push Notification
                          </label>
                        </div>
                      </li>
                    </ul>
                  </div>
                  <div className="col-lg-4 text-lg-end text-center">
                    <div className="common-red-btn">
                      <button className="btn red-border-btn  me-2" onClick={this.settingmodalclose}>
                        Cancel
                      </button>
                      <button className="btn red-btn" type="submit">
                        Save
                      </button>
                    </div>
                  </div>
                </div>
              </form>
            </>
          </Modal.Body>
        </Modal>

        {/* ---------------------modal-date-------------------- */}
        <Modal
          dialogClassName="modal-dialog-centered cust-modal-white-content"
          className="cust-white-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.selectmonthmodal}
          onHide={this.selectmonthmodalclose}
          size="xl"
        >
          <Modal.Header>
            <button type="button" onClick={this.selectmonthmodalclose} className="close btn-close" ></button>
          </Modal.Header>
          <Modal.Body className="cust-datepicker">
            <>

              <div className="row">
                <div className="col-12">
                  <DateRangePicker
                    ranges={[selectionRange]}
                    onChange={this.handleSelect}
                    showSelectionPreview={true}
                    moveRangeOnFirstSelection={false}
                    months={2}
                    direction="horizontal"
                  />
                </div>
                <div className="col-lg-4 text-lg-end text-center ms-auto">
                  <div className="common-red-btn">
                    <button className="btn red-border-btn  me-2" onClick={this.selectmonthmodalclose}>
                      Cancel
                    </button>
                    <button className="btn red-btn" type="submit">
                      Set
                    </button>
                  </div>
                </div>
              </div>
            </>
          </Modal.Body>
        </Modal>


      </Adminlayout>
    );
  }
}

export default withRouter(AbandonedCart);
