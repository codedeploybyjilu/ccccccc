import React, { Component } from 'react';
import Adminlayout from '../../Components/AdminLayout/Adminlayout';
import SearchIcon from "../../images/search-icon.svg";
import MUITable from "../../Components/MUITable";
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";
import { Dropdown } from 'react-bootstrap';

class AudienceSegment extends Component {

    render() {
        const options = {
            responsive: "standard",
            searchOpen: false,
            search: false,
            searchAlwaysOpen: false,
            print: false,
            serverSide: true,
            pagination: true,
            rowsPerPageOptions: [50, 100, 300, 500],
        };

        const columns = [
            {
                name: "audience_name",
                label: "Audience Name",
            },
            {
                name: "date",
                label: "Date",
            },
            {
                name: "description",
                label: "Description",
            },
            {
                name: "audience_size",
                label: "Audience Size",
            },
            {
                name: "action",
                label: "Action",
                options: {
                    customBodyRender: (value, tableMeta, updateValue) => {
                        return (
                            <div>
                                <Dropdown className="cust-drop">
                                    <Dropdown.Toggle className="bg-transparent" id="dropdown-basic" align="end">
                                        <svg width={16} height={16} fill="currentColor" className="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                            <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                        </svg>
                                    </Dropdown.Toggle>
                                    <Dropdown.Menu>
                                        <Dropdown.Item href="/audience-segment-details" className='d-flex align-item-center'>
                                            <svg width="19" height="19" fill="currentColor" class="bi bi-eye-fill" viewBox="0 0 16 16">
                                                <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z" />
                                                <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8zm8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z" />
                                            </svg>
                                            <span>View</span>
                                        </Dropdown.Item>
                                        <Dropdown.Item className='d-flex align-item-center'>
                                            <svg width="19" height="19" viewBox="0 0 18 20" fill="none">
                                                <path d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z" fill="#2D2D3B" />
                                            </svg>
                                            <span>Delete</span>
                                        </Dropdown.Item>
                                    </Dropdown.Menu>
                                </Dropdown>
                            </div>
                        );
                    },
                }
            },
        ];

        const data = [
            ["new users", "January 26, 2023 3:48 PM", "users that has downloaded the app in last 7 days", "0", ""],
            ["new users", "January 26, 2023 3:48 PM", "users that has downloaded the app in last 7 days", "0", ""],
            ["new users", "January 26, 2023 3:48 PM", "users that has downloaded the app in last 7 days", "0", ""],
            ["new users", "January 26, 2023 3:48 PM", "users that has downloaded the app in last 7 days", "0", ""],
            ["new users", "January 26, 2023 3:48 PM", "users that has downloaded the app in last 7 days", "0", ""],
        ];

        const theme = createMuiTheme({
            palette: {
                primary: {
                    light: "#757ce8",
                    main: "#a81a1c",
                    dark: "#002884",
                    contrastText: "#fff",
                },
                secondary: {
                    light: "#ff7961",
                    main: "#f44336",
                    dark: "#ba000d",
                    contrastText: "#000",
                },
            },
        });

        return (
            <Adminlayout>
                <div className="container-fluid">
                    <div className="row common-space">
                        <div className="col-sm-6 text-sm-start text-center rtl-txt-start">
                            <div className="common-header-txt">
                                <h3>Audience Segments</h3>
                            </div>
                        </div>
                        <div className="col-sm-6 text-end rtl-txt-end">
                            <button type="button" className="btn black-btn">Import</button>
                            <a href='/create-user-segment' className="btn red-btn ms-3">
                                Create Segment
                            </a>
                        </div>
                    </div>
                    <div className='row common-space'>
                        <div className='col-12'>
                            <div className='white-box'>
                                <div className="custom-table">
                                    <div className=" dataTables_wrapper no-footer">
                                        <MuiThemeProvider theme={theme}>
                                            <div className="right-menu table-over-fix-class ms-auto position-relative">
                                                <MUITable
                                                    columns={columns}
                                                    data={data}
                                                    options={options}
                                                />
                                                <div className="fix-search d-flex align-items-center">
                                                    <div className="position-relative search-sm-screen" id="search-menu">
                                                        <input type="search" name="search" className="form-control top-search ps-5 input-custom-class mb-0" placeholder="" />
                                                        <span className="search-icn position-absolute ms-3">
                                                            <img src={SearchIcon} alt="" />
                                                        </span>
                                                    </div>
                                                    {/* <button className="border-0 bg-transparent dark-red-txt w-100">Clear Filter x</button> */}
                                                </div>
                                            </div>
                                        </MuiThemeProvider>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </Adminlayout>
        );
    }
}

export default AudienceSegment;
