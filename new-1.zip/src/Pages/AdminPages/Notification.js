import React, { Component } from "react";
import { Dropdown, Tab, Tabs } from "react-bootstrap";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import {
  APIBaseUrl,
  API_Path,
  buttonArabic,
  buttonEnglish,
  notificationEnglish,
  DashboardArabic,
  DashboardEnglish,
  orderEnglish,
  orderArabic,
  notificationArabic,
  TableFieldArabic,
  TableFieldEnglish,
  titleArabic,
  titleEnglish,
} from "../../const";
import LanguageContext from "../../contexts/languageContext";

export class Notification extends Component {
  static contextType = LanguageContext;

  render() {
    let notificationLanguage =
      this.context.language === "english"
        ? notificationEnglish
        : notificationArabic;
    let orderLanguage =
      this.context.language === "english" ? orderEnglish : orderArabic;
    let DashboardLanguage =
      this.context.language === "english" ? DashboardEnglish : DashboardArabic;
    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space">
            <div className="col-sm-6 text-sm-start text-center rtl-txt-start">
              <div className="common-header-txt">
                <h3>{notificationLanguage.notification}</h3>
              </div>
            </div>
            <div className="col-sm-6 text-sm-end text-center rtl-txt-end">
              <div className="common-red-btn">
                <a href="add-notification" className="btn red-btn">
                  {notificationLanguage.addNotification}
                </a>
              </div>
            </div>
          </div>
          <div className="row common-space">
            <div className="col-sm-12">
              <div className="white-box">
                <div className="btn-list-order">
                  <Dropdown>
                    <Dropdown.Toggle className="btn dropdown-toggle cust-search-button mb-0 cust-date me-sm-2 me-0">
                      <span>{notificationLanguage.subscribedCustomers}</span>
                    </Dropdown.Toggle>
                    <Dropdown.Menu className="cust-drop-box">
                      <Dropdown.Item href="#/action-1">
                        {DashboardLanguage.Action}
                      </Dropdown.Item>
                      <Dropdown.Item href="#/action-2">
                        {DashboardLanguage.AnotherAction}
                      </Dropdown.Item>
                      <Dropdown.Item href="#/action-3">
                        {DashboardLanguage.SomethingElse}
                      </Dropdown.Item>
                    </Dropdown.Menu>
                  </Dropdown>
                  <Dropdown>
                    <Dropdown.Toggle className="btn dropdown-toggle cust-search-button mb-0 cust-date">
                      <span>{notificationLanguage.selectDate}</span>
                    </Dropdown.Toggle>
                    <Dropdown.Menu className="cust-drop-box fix-box-drop">
                      <div className="row m-0">
                        <div className="col-md-6 form-group pe-0">
                          <label>{orderLanguage.From}</label>
                          <input type="date" className="form-control" />
                        </div>
                        <div className="col-md-6 form-group">
                          <label>{orderLanguage.To}</label>
                          <input type="date" className="form-control" />
                        </div>
                        <div className="col-12">
                          <div
                            className="btn-group pt-3 pb-3 d-block"
                            role="group"
                            aria-label="Basic radio toggle button group"
                          >
                            <ul>
                              <li>
                                <input
                                  type="radio"
                                  className="btn-check date-checked"
                                  name="btnradio"
                                  id="btnradio1"
                                  autoComplete="off"
                                  defaultChecked
                                />
                                <label
                                  className="btn gray-btn-date w-100"
                                  htmlFor="btnradio1"
                                >
                                  {notificationLanguage.today}
                                </label>
                              </li>
                              <li>
                                <input
                                  type="radio"
                                  className="btn-check date-checked"
                                  name="btnradio"
                                  id="btnradio2"
                                  autoComplete="off"
                                />
                                <label
                                  className="btn gray-btn-date w-100"
                                  htmlFor="btnradio2"
                                >
                                  {notificationLanguage.yesterday}
                                </label>
                              </li>
                              <li>
                                <input
                                  type="radio"
                                  className="btn-check date-checked"
                                  name="btnradio"
                                  id="btnradio3"
                                  autoComplete="off"
                                />
                                <label
                                  className="btn gray-btn-date w-100"
                                  htmlFor="btnradio3"
                                >
                                  {orderLanguage.last_3_Months}
                                </label>
                              </li>

                              <li>
                                <input
                                  type="radio"
                                  className="btn-check date-checked"
                                  name="btnradio"
                                  id="btnradio4"
                                  autoComplete="off"
                                />
                                <label
                                  className="btn gray-btn-date w-100"
                                  htmlFor="btnradio4"
                                >
                                  {orderLanguage.thisYears}
                                </label>
                              </li>
                            </ul>
                          </div>
                          <div className="col-12 text-center">
                            <div className="common-red-btn">
                              <a href="#" className="btn black-btn me-2">
                                {orderLanguage.cancel}
                              </a>
                              <a href="add-admin" className="btn red-btn">
                                {orderLanguage.update}
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Dropdown.Menu>
                  </Dropdown>
                </div>
                <div className="cust-tab">
                  <Tabs
                    defaultActiveKey="notification"
                    id="uncontrolled-tab-example"
                    className="mb-3"
                  >
                    <Tab
                      eventKey="notification"
                      title={notificationLanguage.notification}
                    >
                      <div className="d-sm-flex cust-noti-page">
                        <div className="me-sm-4 me-0">
                          <svg
                            width={20}
                            height={20}
                            viewBox="0 0 20 20"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M20 20L16 16H5C4.73478 16 4.48043 15.8946 4.29289 15.7071C4.10536 15.5196 4 15.2652 4 15V13H17V4H19C19.2652 4 19.5196 4.10536 19.7071 4.29289C19.8946 4.48043 20 4.73478 20 5V20ZM0 15V1C0 0.734784 0.105357 0.48043 0.292893 0.292893C0.48043 0.105357 0.734784 0 1 0L14 0C14.2652 0 14.5196 0.105357 14.7071 0.292893C14.8946 0.48043 15 0.734784 15 1V10C15 10.2652 14.8946 10.5196 14.7071 10.7071C14.5196 10.8946 14.2652 11 14 11H4L0 15Z"
                              fill="#A81A1C"
                            />
                          </svg>
                        </div>
                        <div>
                          <p>
                            You have 3 new messages lorem Ipsum is simply dummy
                            text of the printing and typesetting industry. Lorem
                            Ipsum has been the industry's standard dummy text
                            ever since the.
                          </p>
                          <span>Fannie Douglas, Rena Warner + 5 more</span>
                        </div>
                        <div className="ms-auto margin-right-auto">
                          <bdi>2 hours ago</bdi>
                        </div>
                      </div>
                      <div className="d-sm-flex cust-noti-page">
                        <div className="me-sm-4 me-0">
                          <svg
                            width={20}
                            height={16}
                            viewBox="0 0 20 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M18 16.0001H2C1.46957 16.0001 0.960859 15.7894 0.585786 15.4143C0.210714 15.0392 0 14.5305 0 14.0001L0.01 2.00007C0.00652999 1.73731 0.0555589 1.4765 0.154212 1.23293C0.252864 0.98937 0.399155 0.767955 0.584505 0.581674C0.769855 0.395393 0.990533 0.247994 1.2336 0.148121C1.47666 0.048249 1.73722 -0.00208662 2 6.62523e-05H18C18.5304 6.62523e-05 19.0391 0.21078 19.4142 0.585853C19.7893 0.960925 20 1.46963 20 2.00007V14.0001C20 14.5305 19.7893 15.0392 19.4142 15.4143C19.0391 15.7894 18.5304 16.0001 18 16.0001ZM2 8.00007V14.0001H18V8.00007H2ZM2 2.00007V4.00007H18V2.00007H2Z"
                              fill="#A81A1C"
                            />
                          </svg>
                        </div>
                        <div>
                          <p>
                            You have 3 new messages lorem Ipsum is simply dummy
                            text of the printing and typesetting industry. Lorem
                            Ipsum has been the industry's standard dummy text
                            ever since the.
                          </p>
                          <span>Fannie Douglas, Rena Warner + 5 more</span>
                        </div>
                        <div className="ms-auto margin-right-auto">
                          <bdi>2 hours ago</bdi>
                        </div>
                      </div>
                      <div className="d-sm-flex cust-noti-page">
                        <div className="me-sm-4 me-0">
                          <svg
                            width={20}
                            height={15}
                            viewBox="0 0 20 15"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M15 15H5V0H15V15ZM20 13H16V2H20V13ZM4 13H0V2H4V13Z"
                              fill="#A81A1C"
                            />
                          </svg>
                        </div>
                        <div>
                          <p>
                            You have 3 new messages lorem Ipsum is simply dummy
                            text of the printing and typesetting industry. Lorem
                            Ipsum has been the industry's standard dummy text
                            ever since the.
                          </p>
                          <span>Fannie Douglas, Rena Warner + 5 more</span>
                        </div>
                        <div className="ms-auto margin-right-auto">
                          <bdi>2 hours ago</bdi>
                        </div>
                      </div>
                      <div className="d-sm-flex cust-noti-page">
                        <div className="me-sm-4 me-0">
                          <svg
                            width={16}
                            height={20}
                            viewBox="0 0 16 20"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M14 20H1.99C1.4613 19.9974 0.955159 19.7855 0.582246 19.4107C0.209334 19.0359 -6.6087e-06 18.5287 1.56476e-10 18L0.01 2C0.00999339 1.4713 0.219334 0.964097 0.592246 0.58931C0.965159 0.214524 1.4713 0.00264352 2 0H10L16 6V18C16 18.5304 15.7893 19.0391 15.4142 19.4142C15.0391 19.7893 14.5304 20 14 20ZM4 14V16H12V14H4ZM4 10V12H12V10H4ZM9 1.5V7H14.5L9 1.5Z"
                              fill="#A81A1C"
                            />
                          </svg>
                        </div>
                        <div>
                          <p>
                            You have 3 new messages lorem Ipsum is simply dummy
                            text of the printing and typesetting industry. Lorem
                            Ipsum has been the industry's standard dummy text
                            ever since the.
                          </p>
                          <span>Fannie Douglas, Rena Warner + 5 more</span>
                        </div>
                        <div className="ms-auto margin-right-auto">
                          <bdi>2 hours ago</bdi>
                        </div>
                      </div>
                      <div className="d-sm-flex cust-noti-page">
                        <div className="me-sm-4 me-0">
                          <svg
                            width={20}
                            height={15}
                            viewBox="0 0 20 15"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M15 15H5V0H15V15ZM20 13H16V2H20V13ZM4 13H0V2H4V13Z"
                              fill="#A81A1C"
                            />
                          </svg>
                        </div>
                        <div>
                          <p>
                            You have 3 new messages lorem Ipsum is simply dummy
                            text of the printing and typesetting industry. Lorem
                            Ipsum has been the industry's standard dummy text
                            ever since the.
                          </p>
                          <span>Fannie Douglas, Rena Warner + 5 more</span>
                        </div>
                        <div className="ms-auto margin-right-auto">
                          <bdi>2 hours ago</bdi>
                        </div>
                      </div>
                      <div className="d-sm-flex cust-noti-page">
                        <div className="me-sm-4 me-0">
                          <svg
                            width={20}
                            height={20}
                            viewBox="0 0 20 20"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M20 20L16 16H5C4.73478 16 4.48043 15.8946 4.29289 15.7071C4.10536 15.5196 4 15.2652 4 15V13H17V4H19C19.2652 4 19.5196 4.10536 19.7071 4.29289C19.8946 4.48043 20 4.73478 20 5V20ZM0 15V1C0 0.734784 0.105357 0.48043 0.292893 0.292893C0.48043 0.105357 0.734784 0 1 0L14 0C14.2652 0 14.5196 0.105357 14.7071 0.292893C14.8946 0.48043 15 0.734784 15 1V10C15 10.2652 14.8946 10.5196 14.7071 10.7071C14.5196 10.8946 14.2652 11 14 11H4L0 15Z"
                              fill="#A81A1C"
                            />
                          </svg>
                        </div>
                        <div>
                          <p>
                            You have 3 new messages lorem Ipsum is simply dummy
                            text of the printing and typesetting industry. Lorem
                            Ipsum has been the industry's standard dummy text
                            ever since the.
                          </p>
                          <span>Fannie Douglas, Rena Warner + 5 more</span>
                        </div>
                        <div className="ms-auto margin-right-auto">
                          <bdi>2 hours ago</bdi>
                        </div>
                      </div>
                    </Tab>
                    <Tab
                      eventKey="whatsapp_notification"
                      title={notificationLanguage.whatsAppNotification}
                    >
                      2
                    </Tab>
                    <Tab
                      eventKey="sms_notification"
                      title={notificationLanguage.SMSNotification}
                    >
                      3
                    </Tab>
                  </Tabs>
                </div>
              </div>
            </div>
          </div>
          {/* <div className="row common-space">
                        <div className="col-md-12">
                            <div className="row m-0 white-box">
                                <div className="col-md-6 p-0">
                                    <div className="help-support-txt ">
                                        <label className="cust-radio">
                                            <input type="radio" name="radio" />
                                            <span className="checkmark" />
                                        </label>
                                        <span>WhatsApp (Off platform Chat & Support service)</span>

                                    </div>
                                </div>
                                <div className="col-md-6 p-0">
                                    <div className="help-support-txt ">
                                        <label className="cust-radio">
                                            <input type="radio" checked={this.state.enableSwitch} onChange={this.handleSwitch} name="radio" />
                                            <span className="checkmark" />
                                        </label>

                                        <span>Tawk.to (On platform Chat & Support service)</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> */}
        </div>
      </Adminlayout>
    );
  }
}

export default Notification;
