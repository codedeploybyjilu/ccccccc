import React, { Component } from 'react'
import Adminlayout from '../../Components/AdminLayout/Adminlayout'

export class Maillisting extends Component {
    render() {
        return (
            <Adminlayout>

            </Adminlayout>
        )
    }
}

export default Maillisting
