import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import DataTable from "../../Components/DataTable";
import { textFilter } from "react-bootstrap-table2-filter";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";
import { Dropdown, Modal } from "react-bootstrap";
import SearchIcon from "../../images/search-icon.svg";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import Moment from "moment";
import { APIBaseUrl, API_Path, buttonArabic, buttonEnglish, SidebarArabic, SidebarEnglish, TableFieldArabic, TableFieldEnglish, titleArabic, titleEnglish, productEnglish, productArabic, LIVE_FILE_URL } from "../../const";
import LanguageContext from "../../contexts/languageContext";
import productimg from "../../images/product-img.png";
import dummyThumb from "../../images/store.png";
import Select from "react-select";
import toastr from "toastr";
import MUITable from "../../Components/MUITable";
import "toastr/build/toastr.min.css";
import { PostApi } from "../../helper/APIService";
import ProductDetailModal from "./ProductDetailModal";
import plusImg from "../../images/plus-icn.svg";
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";
import loader from "../../images/loader.gif";
import { Link, withRouter } from "react-router-dom";
import dragimg from "../../images/file-upload.svg";
import { set } from "date-fns";

let TagFilterArray = [];
let TagFilterValueArray = [];
let BarcodeArray = [];
let BarcodeValueArray = [];
let IdArr = [];
let tagActionArr = [];
let tagRemoveActionArr = [];
let offerActionArr = [];
let total = 0

const theme = createMuiTheme({
  palette: {
    primary: {
      light: "#757ce8",
      main: "#a81a1c",
      dark: "#002884",
      contrastText: "#fff",
    },
    secondary: {
      light: "#ff7961",
      main: "#f44336",
      dark: "#ba000d",
      contrastText: "#000",
    },
  },
});

export class Products extends Component {
  static contextType = LanguageContext;

  constructor(props) {
    super(props);
    this.getData = ''
    this.state = {
      search_show: false,
      productCode: "",
      View_Product_id: "",
      Product_details_model_show: false,
      change_status_modal_show: false,
      add_tag_model_show: false,
      add_offer_model_show: false,
      remove_tag_model_show: false,
      remove_offer_model_show: false,
      change_category_model_show: false,
      filter_model_show: false,
      statusAction: "",
      tagAction: "",
      tagRemoveAction: "",
      offerAction: "",
      Id: "",
      categoryChangeAction: [],
      categoryArray: [],
      filterStatus: "",
      barcodeOption: "",
      barcodeNumber: "",
      productBehaviour: "",
      mainCategory: "",
      Category: "",
      subCategory: "",
      mainCategoryChange: "",
      CategoryChange: "",
      subCategoryChange: "",
      startDate: "",
      endDate: "",
      products: "",
      tag: "",
      tagsForDisplay: "",
      tagValueForDisplay: "",
      barcodeForDisplay: "",
      barcodeValueForDisplay: "",
      loading: true,
      selectedOption: "",
      page: 1,
      sizePerPage: 100,
      totalSize: 0,
      totalPage: 1,
      columnSort: "createdat",
      cloned_product_show: false,
      // defaultSorted: [
      //   {
      //     dataField: "id",
      order: "desc",
      isLoading: true,
      isChangeClick: false,
      //   },
      // ],
      product_data: [],
      isCloneshow: false,
      barcodeno: "",
      Pid: "",
      id: false,
      sc_arabic: true,
      sc_english: true,
      c_arabic: false,
      c_english: false,
      mc_arabic: true,
      mc_english: true,
      title_ar: true,
      title_en: true,
      barcode: true,
      images: true,
      status: true,
      preference: true,
      createdat: true,
      sales: true,
      qty: true,
      price: false,
      discount_price: false,
      isFilterClick: false,
      ActionTagArr: [],
      ActionOfferArr: [
        {
          value: "B1",
          tagName: "CODE (FREESHIP) 10%",
        },
        {
          value: "B2",
          tagName: "RAMADAN OFFER SR50 OFF",
        },
        {
          value: "B3",
          tagName: "50% OFF",
        },
        {
          value: "B4",
          tagName: "30% OFF",
        },
        {
          value: "B5",
          tagName: "60% OFF",
        },
        {
          value: "B6",
          tagName: "NEW OFFER",
        },
        {
          value: "B7",
          tagName: "NEW YEAR",
        },
        {
          value: "B8",
          tagName: "EID OFFER",
        },
        {
          value: "B9",
          tagName: "BUNDLE OFFER 25SR",
        },
        {
          value: "B10",
          tagName: "BUY1 GET1",
        },
      ],
      fitlterCount: 0,
      uploadFileShow: false,
      uplodedFile: '',
      ProductAvailability: 'in-stock'
    };
  }

  options = [
    { value: "Summer", label: "Summer" },
    { value: "winter", label: "winter" },
    { value: "monsoon", label: "monsoon" },
  ];

  componentDidMount() {
    // this.GenerateProductCode(6);
    // this.get_product_data()
    this.filterProducts();
    this.getMainCategory();
    this.getSubCategory();
    this.getAllTags();
    // console.log(window.location.pathname);
  }

  // get_product_data = () => {
  //   const data = {
  //     column: this.state.columnSort,
  //     sizePerPage: this.state.sizePerPage,
  //     page: this.state.page,
  //     order: this.state.order,
  //     search_val: this.state.searchProduct,
  //   };
  //   const getAllProductDataPromise = new Promise((resolve, reject) => {
  //     resolve(PostApi(API_Path.getAllProduct, data));
  //   });
  //   getAllProductDataPromise.then((response) => {
  //     if (response) {
  //       if (response.data.success) {
  //         this.setState(
  //           {
  //             product_data: response.data.data,
  //             totalSize: response.data.totalRecord,
  //             isLoading: false,
  //           },
  //           () => {
  //             this.setState({
  //               totalPage: this.state.totalSize / this.state.sizePerPage,
  //             });
  //           }
  //         );
  //       } else {
  //         toastr.error(response.data.message);
  //       }
  //     }
  //   });
  // };

  getAllTags = () => {
    const data = {};
    const getAllTagsPromise = new Promise((resolve, reject) => {
      resolve(PostApi(API_Path.getAllTags, data));
    });
    getAllTagsPromise.then((response) => {
      if (response) {
        if (response.data.success) {
          this.setState({ ActionTagArr: response.data.data });
        } else {
          toastr.error(response.data.message);
        }
      }
    });
  };

  filterClick = () => {
    this.setState({ page: 1 });
    document.querySelector('button[aria-label="Close"]').click();
    this.filterProducts();
  };

  filterProducts = () => {
    let arr = []



    this.setState({ isLoading: true })
    const path = API_Path.filterProduct;
    const data = {
      search: this.state.searchProduct,
      barcodes: this.state.barcodeValueForDisplay,
      tags: this.state.tagValueForDisplay,
      status: this.state.filterStatus,
      main_category: this.state.mainCategoryChange,
      category: this.state.CategoryChange,
      sub_category: this.state.subCategoryChange,
      behaviour: this.state.productBehaviour,
      from_date: this.state.startDate,
      to_date: this.state.endDate,
      column: this.state.columnSort,
      sizePerPage: this.state.sizePerPage,
      page: this.state.page,
      order: this.state.order,
      search_val: this.state.searchProduct,
    };
    this.setState({ isFilterClick: true });



    const getAllProductDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getAllProductDataPromise.then((res) => {
      if (res.data.success) {
        BarcodeArray = [];
        this.setState({
          products: res.data.data,
          // barcodeNumber: "",
          // barcodeOption: "",
          // barcodeForDisplay: "",
          // barcodeValueForDisplay: "",
          // tagsForDisplay: "",
          // tagValueForDisplay: "",
          // filterStatus: "",
          // mainCategoryChange: "",
          // CategoryChange: "",
          // subCategoryChange: "",
          // productBehaviour: "",
          // startDate: "",
          // endDate: "",
        });
        this.filteredProductsList();
      } else {
        this.setState({
          // barcodeNumber: "",
          // barcodeOption: "",
          // barcodeForDisplay: "",
          // barcodeValueForDisplay: "",
          // tagsForDisplay: "",
          // tagValueForDisplay: "",
          // filterStatus: "",
          // mainCategoryChange: "",
          // CategoryChange: "",
          // subCategoryChange: "",
          // productBehaviour: "",
          // startDate: "",
          // endDate: "",
        });
        toastr.error(res.data.message);
      }
    });
  };

  clearFilterProduct = () => {
    total = 0
    this.setState({
      barcodeValueForDisplay: '',
      productBehaviour: '',
      CategoryChange: '',
      columnSort: 'createdat',
      startDate: '',
      mainCategoryChange: '',
      order: 'desc',
      page: 1,
      sizePerPage: 100,
      filterStatus: '',
      subCategoryChange: '',
      tagValueForDisplay: '',
      endDate: '',
      isLoading: false

    }, () => {
      document.querySelector('button[aria-label="Close"]').click();
      document.querySelector('button[aria-label="Filter Table"]').classList.remove('MUIDataTableToolbar-iconActive-131')
      this.filterProducts()
    })
  }

  filteredProductsList = () => {
    this.setState({ isLoading: true })
    let path = API_Path.filteredProductList;
    let data = {
      column: this.state.columnSort,
      order: this.state.order,
      page: this.state.page,
      sizePerPage: this.state.sizePerPage,
      products: this.state.products,
      availability: this.state.ProductAvailability
    };

    const filteredProductListPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    filteredProductListPromise.then((res) => {
      if (res) {
        if (res.data.success) {

          this.setState({ product_data: res.data.data, totalSize: res.data.totalRecord, isLoading: false });



          // toastr.success(res.data.message);
        } else {
          this.setState({ product_data: [], isLoading: false });
          // toastr.warning(res.data.message);
        }
      }
    });
  };

  getMainCategory = () => {
    let data = {}

    const getMainCategoryPromise = new Promise((resolve, reject) => {
      resolve(PostApi(API_Path.mainCategory, data));
    });
    getMainCategoryPromise.then((res) => {
      if (res.data.success) {
        this.setState({ mainCategory: res.data.data });
      } else {
        console.log(res);
      }
    });
  };

  getSubCategory = () => {
    let data = {}
    const getSubCategoryPromise = new Promise((resolve, reject) => {
      resolve(PostApi(API_Path.getSubCategory, data));
    });
    getSubCategoryPromise.then((res) => {
      if (res.data.success) {
        this.setState({ subCategoryData: res.data.data }, () => {
        });
      } else {
        console.log(res);
      }
    });
  };

  getRelativeCategoryData = (id) => {
    let data = { main_category_id: id };
    let path = API_Path.getCategoryRelative;
    const getSubCategoryRelativePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getSubCategoryRelativePromise.then((res) => {
      if (res.data.success) {
        this.setState({ Category: res.data.data });
      } else {
        console.log(res);
      }
    });
  };

  getRelativeSubCategoryData = (id) => {
    let data = { category_id: id };
    let path = API_Path.getSubCategoryRelative;
    const getSubCategoryRelativePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getSubCategoryRelativePromise.then((res) => {
      if (res.data.success) {
        this.setState({ subCategory: res.data.data }, () => {
          console.log(this.state.subCategory);
        });
      } else {
        console.log(res);
      }
    });
  };

  changeProductStatusAction = () => {
    let path = API_Path.getAllProductAction;
    let data = {
      action: "status",
      status: this.state.statusAction,
      products: this.state.Id,
    };

    const changeProductStatusAction = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    changeProductStatusAction.then((res) => {
      if (res) {
        if (res.data.success) {
          toastr.success(res.data.message);
          this.setState({ statusAction: "" });
          this.change_status_handleClose();
          this.filterProducts();
          IdArr = [];
        } else {
          toastr.error(res.data.message);
          this.change_status_handleClose();
        }
      }
    });
  };

  finalyDeleteProducts = () => {
    let path = API_Path.getAllProductAction;
    let data = {
      action: "remove",
      remove: true,
      products: this.state.Id,
    };

    const deleteProductsAction = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    deleteProductsAction.then((res) => {
      if (res) {
        if (res.data.success) {
          toastr.success(res.data.message);
          this.filterProducts();
          IdArr = [];
        } else {
          toastr.error(res.data.message);
        }
      }
    });
  };

  changeProductCategoryAction = () => {
    let path = API_Path.getAllProductAction;
    let categoryArr = [this.state.categoryChangeAction.mainCat, this.state.categoryChangeAction.Cat, this.state.categoryChangeAction.subCat];
    this.setState({ categoryArray: categoryArr }, () => {
      let data = {
        action: "category",
        category: this.state.categoryArray,
        products: this.state.Id,
      };

      const changeProductCategoryAction = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      changeProductCategoryAction.then((res) => {
        if (res) {
          if (res.data.success) {
            this.filterProducts();
            this.change_category_Close();
            IdArr = [];
          } else {
            console.log(res.data);
          }
        }
      });
    });
  };

  addTagAction = () => {
    this.setState({ tagAction: tagActionArr }, () => {
      let path = API_Path.getAllProductAction;
      let data = {
        action: "add_tag",
        products: this.state.Id,
        tags: this.state.tagAction,
      };

      const addTagAction = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      addTagAction.then((res) => {
        if (res) {
          if (res.data.success) {
            toastr.success(res.data.message);
            this.add_tag_Close();
            this.filterProducts();
            IdArr = [];
            tagActionArr = [];
          } else {
            toastr.error(res.data.message);
          }
        }
      });
    });
  };

  removeTagAction = () => {
    this.setState({ tagRemoveAction: tagRemoveActionArr }, () => {
      let path = API_Path.getAllProductAction;
      let data = {
        action: "remove_tag",
        products: this.state.Id,
        tags: this.state.tagRemoveAction,
      };

      const removeTagAction = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      removeTagAction.then((res) => {
        if (res) {
          if (res.data.success) {
            toastr.success(res.data.message);
            this.filterProducts();
            this.remove_tag_Close();
            IdArr = [];
            tagRemoveActionArr = []
          } else {
            toastr.error(res.data.message);
          }
        }
      });
    })
  };

  removeOfferAction = () => {
    let path = API_Path.getAllProductAction;
    let data = {
      action: "remove_tag",
      products: this.state.Id,
      tags: this.state.tagAction,
    };

    const removeTagAction = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    removeTagAction.then((res) => {
      if (res) {
        if (res.data.success) {
          toastr.success(res.data.message);
          this.filterProducts();
          IdArr = [];
        } else {
          toastr.error(res.data.message);
        }
      }
    });
  };

  addOfferAction = () => {
    let sum = 0;
    if (this.state.B1 == true) {
      sum = sum + 1;
    }
    if (this.state.B2 == true) {
      sum = sum + 1;
    }
    if (this.state.B3 == true) {
      sum = sum + 1;
    }
    if (this.state.B4 == true) {
      sum = sum + 1;
    }
    if (this.state.B5 == true) {
      sum = sum + 1;
    }
    if (this.state.B6 == true) {
      sum = sum + 1;
    }
    if (this.state.B7 == true) {
      sum = sum + 1;
    }
    if (this.state.B8 == true) {
      sum = sum + 1;
    }
    if (this.state.B9 == true) {
      sum = sum + 1;
    }
    if (this.state.B10 == true) {
      sum = sum + 1;
    }

    this.setState({ sum: sum }, () => {
      let path = API_Path.getAllProductAction;
      let data = {
        action: "add_offer",
        products: this.state.Id,
        add_offer: this.state.sum,
      };

      const addOfferAction = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      addOfferAction.then((res) => {
        if (res) {
          if (res.data.success) {
            toastr.success(res.data.message);
            this.setState({ sum: 0 });
            this.add_offer_Close();
            this.filterProducts();
            IdArr = [];
          } else {
            toastr.error(res.data.message);
          }
        }
      });
    });
  };

  removeOfferAction = () => {
    let path = API_Path.getAllProductAction;
    let data = {
      action: "remove_offer",
      products: this.state.Id,
      remove_offer: true,
    };

    const removeOfferAction = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    removeOfferAction.then((res) => {
      if (res) {
        if (res.data.success) {
          toastr.success(res.data.message);
          this.filterProducts();
          IdArr = [];
        } else {
          toastr.error(res.data.message);
        }
      }
    });
  };

  handleChanges = (selectedOption) => {
    this.setState({ selectedOption });
  };

  edit_userClose = () => {
    this.setState({ search_show: false });
  };

  edit_userShow = (e) => {
    e.preventDefault();
    this.setState({ search_show: true });
  };

  edit_handleShow = (e) => {
    e.preventDefault();
    this.setState({ search_show: true });
  };

  handleClone = (id) => {
    this.setState({ isCloneshow: true, Pid: id });
  }

  handleCloneClose = () => {
    this.setState({ isCloneshow: false });
  };

  handleBarcodeChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  GenerateProductCode = (length, value) => {
    var barcode = Math.floor(1000 + Math.random() * 9000);
    var result = "";
    var characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    var charactersLength = characters.length;
    for (var i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    this.setState({ productCode: result, barcodeno: barcode }, () => {
      this.handleClone(value)
    });
    // return result;
  };

  createCloneProduct = () => {
    const data = {
      id: this.state.Pid,
      productCode: this.state.productCode,
      barcodeno: this.state.barcodeno,
    };
    const createDuplicateProductPromise = new Promise((resolve) => {
      resolve(PostApi(API_Path.duplicateProduct, data));
    });
    createDuplicateProductPromise.then((res) => {
      if (res) {
        if (res.status == 200) {
          this.setState({ Id: res.data.data.productId }, () => {
            this.filterProducts();
            this.handleCloneClose();
            this.cloned_product_show();
            toastr.success(res.data.message);
          });
        } else {
          console.log(res.data.messgae);
        }
      }
    });
  };

  delete_record = (id) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>{this.context.language === "english" ? productEnglish.AreYouSure : productArabic.AreYouSure}</h1>
            <p>{this.context.language === "english" ? productEnglish.Youwanttodeletethisfile : productArabic.Youwanttodeletethisfile}</p>
            <button className="btn red-btn me-2" onClick={onClose}>
              {this.context.language === "english" ? productEnglish.No : productArabic.No}
            </button>
            <button
              className="btn red-btn"
              onClick={() => {
                this.finaly_delete_record(id);
                onClose();
              }}
            >
              {this.context.language === "english" ? productEnglish.YesDeleteit : productArabic.YesDeleteit}
            </button>
          </div>
        );
      },
    });
  };

  finaly_delete_record = (id) => {
    let path = API_Path.getAllProductAction;
    let data = {
      action: "remove",
      remove: true,
      products: [id],
    };

    const deleteProductsAction = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    deleteProductsAction.then((res) => {
      if (res) {
        if (res.data.success) {
          toastr.success(res.data.message);
          this.filterProducts();
        } else {
          toastr.error(res.data.message);
        }
      }
    });
  };

  handleReturn = () => {
    this.props.history.push("/return-product");
  };

  customStyles = {
    control: () => ({
      height: "50px",
      backgroundColor: "#F7F7F7",
      border: "1px solid #F7F7F7",
      borderRadius: "10px",
      fontSize: "16px",
      color: "#5E5E6C",
      marginBottom: "15px",
      display: "flex",
    }),

    indicatorSeparator: () => ({
      backgroundColor: "transparent",
    }),

    indicatorContainer: () => ({
      backgroundColor: "#000",
    }),
  };

  View_product_detail_handleShow = (id) => {
    this.setState({ Product_details_model_show: true, View_Product_id: id });
  };

  View_product_detail_handleClose = () => {
    this.setState({ Product_details_model_show: false });
  };

  change_status_handleShow = () => {
    this.setState({ change_status_modal_show: true });
  };

  change_status_handleClose = () => {
    this.setState({ change_status_modal_show: false });
  };

  add_tag_show = () => {
    this.setState({ add_tag_model_show: true });
  };

  add_tag_Close = () => {
    this.setState({ add_tag_model_show: false });
  };

  remove_offer_show = () => {
    console.log("entered in remove offer show");
    this.setState({ remove_offer_model_show: true });
  };

  remove_offer_Close = () => {
    this.setState({ remove_offer_model_show: false });
  };

  remove_tag_show = () => {
    console.log("entered in remove tag show");
    this.setState({ remove_tag_model_show: true });
  };

  remove_tag_Close = () => {
    this.setState({ remove_tag_model_show: false });
  };

  add_offer_show = () => {
    this.setState({ add_offer_model_show: true });
  };

  add_offer_Close = () => {
    this.setState({ add_offer_model_show: false });
  };

  change_category_show = () => {
    this.setState({ change_category_model_show: true });
  };

  change_category_Close = () => {
    this.setState({ change_category_model_show: false });
  };

  handleTag = (e) => {
    this.setState({ tag: e.target.value });
  };

  handleAddTag = () => {
    if (this.state.tag !== "") {
      let data = {
        value: this.state.tag,
        id: Date.now(),
      };
      let value = this.state.tag;
      TagFilterValueArray.push(value);
      TagFilterArray.push(data);
      this.setState(
        {
          tag: "",
          tagsForDisplay: TagFilterArray,
          tagValueForDisplay: TagFilterValueArray,
        },
        () => {
          console.log("tags :: ", this.state.tagValueForDisplay);
        }
      );
    }
  };

  removeTag = (idToRemove) => {
    const filteredTag = TagFilterArray.filter((item) => item.id !== idToRemove);
    TagFilterArray = filteredTag;
    this.setState({ tagsForDisplay: filteredTag });
  };

  handleChangeStatus = (e) => {
    this.setState({ statusAction: e.target.value });
  };

  deleteProducts = () => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>{this.context.language === "english" ? productEnglish.AreYouSure : productArabic.AreYouSure}</h1>
            <p>{this.context.language === "english" ? productEnglish.Youwanttodeletethisfile : productArabic.Youwanttodeletethisfile}</p>
            <button className="btn red-btn me-2" onClick={onClose}>
              {this.context.language === "english" ? productEnglish.No : productArabic.No}
            </button>
            <button
              className="btn red-btn"
              onClick={() => {
                this.finalyDeleteProducts();
                onClose();
              }}
            >
              {this.context.language === "english" ? productEnglish.YesDeleteit : productArabic.YesDeleteit}
            </button>
          </div>
        );
      },
    });
  };

  makeId = (length) => {
    var result = "";
    var characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    var charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  };

  handleBarcodeButtonChange = (e) => {
    this.setState({ barcodeOption: e.target.value });
  };

  handleBarcodeNumber = (e) => {
    this.setState({ barcodeNumber: e.target.value }, () => {
      if (e.keyCode === 13) {
        if (this.state.barcodeNumber !== "") {
          this.state.barcodeNumber
            .trim()
            .split(/\s+/)
            .map((item, i) => {
              let data = {
                value: item,
                id: this.makeId(7),
              };
              BarcodeArray.push(data);
            });
          // let BarcodeValueArray = [];
          BarcodeArray.map((l) => {
            let value = l.value;
            BarcodeValueArray.push(value);
          });
          this.setState(
            {
              barcodeNumber: "",
              barcodeForDisplay: BarcodeArray,
              barcodeValueForDisplay: BarcodeValueArray,
            },
            () => {
              document.getElementById("barcodeInput").value = "";
            }
          );
        }
      }
    });
  };

  removeBarcode = (idToRemove) => {
    const barcodeNum = BarcodeArray.filter((item) => item.id !== idToRemove);
    BarcodeArray = barcodeNum;
    this.setState({ barcodeForDisplay: barcodeNum });
  };

  changeStatusFilter = (e) => {
    // filterStatusArr.push(e.target.value)
    this.setState({ filterStatus: e.target.value });
  };

  changeProductBehaviour = (e) => {
    // filterBehaviourArr.push(e.target.value)
    this.setState({ productBehaviour: e.target.value });
  };

  changeMainCategory = (e) => {
    // filterMainCatArr.push(e.target.value)
    this.setState({ mainCategoryChange: e.target.value }, () => {
      this.getRelativeCategoryData(e.target.value);
    });
  };

  changeCategory = (e) => {
    // filterCatArr.push(e.target.value)
    this.setState({ CategoryChange: e.target.value }, () => {
      this.getRelativeSubCategoryData(e.target.value);
    });
  };

  changeSubCategory = (e) => {
    // filterSubCatArr.push(e.target.value)
    this.setState({ subCategoryChange: e.target.value });
  };

  handleChangeStartDate = (e) => {
    // filterFromDateArr.push(Moment(e).format("YYYY-MM-DD"))
    this.setState({ startDate: Moment(e).format("YYYY-MM-DD") });
    // if (document.getElementsByClassName('react-datepicker__day--keyboard-selected')) {
    //   document.getElementsByClassName('react-datepicker__day--keyboard-selected').classList.remove('react-datepicker__day--today')
    // }
  };

  handleChangeEndDate = (e) => {
    // filterEndDateArr.push(Moment(e).format("YYYY-MM-DD"))
    this.setState({ endDate: Moment(e).format("YYYY-MM-DD") });
  };

  handleSearchChange = (e) => {
    let text = e.target.value;
    // const search_val = text.slice(0, -1);
    // this.setState({ searchProduct: search_val }, () => {
    this.setState({ searchProduct: text }, () => {
      clearTimeout(this.getData)
      this.getData = setTimeout(() => {
        this.filterProducts();
      }, 500);
    });
  };

  handleSelectRow = (currentRowsSelected, allRowsSelected) => {
    console.log(currentRowsSelected)
    if (currentRowsSelected.length > 0) {
      currentRowsSelected.map((l) => {
        let index = l.dataIndex;
        let idObj = this.state.product_data[index].id;
        if (!IdArr.includes(idObj)) {
          IdArr.push(idObj);
        } else {
          let filtered = IdArr.filter((item) => item !== idObj);
          IdArr = filtered;
        }
        this.setState({ Id: IdArr });
      });
    } else {
      IdArr = [];
    }
  };

  handleTagRemoveCheckBox = (e) => {
    console.log(e.target.name)
    tagRemoveActionArr.push(e.target.name);
    console.log(tagRemoveActionArr)
  };

  handleTagCheckBox = (e) => {
    tagActionArr.push(e.target.name);
  };

  handleOfferCheckBox = (e) => {
    offerActionArr.push(e.target.name);
  };

  handleOfferCheckBox = (e) => {
    this.setState({ [e.target.name]: e.target.checked });
  };

  handleCategoryActionChange = (e) => {
    this.setState({ categoryChangeAction: JSON.parse(e.target.value) }, () => {
      console.log(this.state.categoryChangeAction);
    });
  };

  handleOnChangeRowsPerPage = (numberOfRows) => {
    this.setState({ sizePerPage: numberOfRows }, () => {
      this.filterProducts();
    });
  };

  changePage = (page) => {
    this.setState(
      {
        isChangeClick: true,
        page: page + 1,
      },
      () => {
        if (this.state.isFilterClick) {
          this.setState({ isFilterClick: false }, () => {
            this.filterProducts();
          });
        } else {
          this.filterProducts();
        }
      }
    );
  };

  onChangeColumnSort = (changedColumn, direction) => {
    this.setState({ columnSort: changedColumn }, () => {
      this.filterProducts();
    });
  };

  featured = (e, id) => {
    const data = {
      preference: e.target.checked ? 1 : 0,
      product_id: id,
    };
    const getAllProductDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(API_Path.updatePreference, data));
    });
    getAllProductDataPromise.then((res) => {
      if (res.data.success) {
        this.filterProducts();
        toastr.success(res.data.message);
      } else {
        toastr.error(res.data.message);
      }
    });
  };

  cloned_product_show = () => {
    this.setState({ cloned_product_show: true });
  };

  cloned_product_close = () => {
    this.setState({ cloned_product_show: false });
  };

  onViewColumnsChange = (changedColumn, action) => {
    let column = `${[changedColumn]}Column`;
    if (action === "add") {
      if ([changedColumn]) {
        this.setState({ [changedColumn]: true });
      }
    } else {
      if ([changedColumn]) {
        this.setState({ [changedColumn]: false });
      }
    }
  };

  firstButton = () => {
    this.changePage(0)
  }

  lastButton = () => {
    this.changePage(Math.ceil(this.state.totalPage - 1))
  }

  // customFooter = (count, page, rowsPerPage, changeRowsPerPage, changePage) => {
  //   return (

  //     <TableFooter>
  //       <TableRow>
  //         <TablePagination
  //           rowsPerPageOptions={[5, 10, 25, 50, 100]}
  //           // colSpan={3}
  //           count={count}
  //           rowsPerPage={rowsPerPage}
  //           page={page}
  //           showFirstButton={true}
  //           showLastButton={true}
  //           backIconButtonProps={{
  //             'aria-label': 'Previous Page',
  //           }}
  //           nextIconButtonProps={{
  //             'aria-label': 'Next Page',
  //           }}
  //           onChangePage={changePage}
  //           onChangeRowsPerPage={this.handleOnChangeRowsPerPage}
  //         />
  //       </TableRow>
  //     </TableFooter>
  //   )
  // }
  openUploadFileMode = () => {
    this.setState({ uploadFileShow: true })
  }
  uploadFileModelClose = () => {
    this.setState({ uploadFileShow: false })

  }
  handleUploadeFile = (e) => {
    console.log(e.target.files, "-=-=-");
    let file = e.target.files[0]
    this.setState({ uplodedFile: file }, () => {
    })

  }
  removeFile = () => {
    this.setState({ uplodedFile: '' })
  }
  uploadFileInDataBase = () => {
    var formData = new FormData();
    formData.append('file', this.state.uplodedFile)
    new Promise((resolve) => {
      resolve(PostApi(API_Path.addCsvFile, formData))
    }).then((res) => {
      if (res.data.success) {
        toastr.success(res.data.message)
        this.filterProducts()
        this.uploadFileModelClose()
        this.removeFile()
      }
    })
  }

  selectAvailability = (e) => {

    this.setState({ ProductAvailability: e.target.value }, () => {
      this.filteredProductsList()
    })
  }


  render() {
    let Language = this.context.language === "english" ? TableFieldEnglish : TableFieldArabic;
    let ButtonLanguage = this.context.language === "english" ? buttonEnglish : buttonArabic;
    let titleLanguage = this.context.language === "english" ? titleEnglish : titleArabic;
    let productLanguage = this.context.language === "english" ? productEnglish : productArabic;

    const columns = [
      {
        name: "id",
        label: productLanguage.id,
        options: {
          display: this.state.id,
        },
      },
      {
        name: "images",
        label: productLanguage.photo,
        options: {
          sort: false,
          display: this.state.images,
          customBodyRender: (value, tableMeta, updateValue) => {
            return (
              <React.Fragment>
                <div className="img-hover-main ">
                  <img className="imgWidth" src={value ? value.split(",")[0] : dummyThumb} alt="" />
                  <div className="table-img-hover">
                    <img className="h-100 img-fluid" src={value ? value.split(",")[0] : dummyThumb} alt="" />
                  </div>
                </div>
              </React.Fragment>
              // <React.Fragment>
              //   <img className="imgWidth" src={value ? value.replace("https://libsis3.s3.amazonaws.com/products/https://libsis3.s3.ap-south-1.amazonaws.com/products/", LIVE_FILE_URL) : dummyThumb} alt="" />
              // </React.Fragment>
            );
          },
        },
      },
      {
        name: "barcode",
        label: productLanguage.Barcode,
        options: {
          display: this.state.barcode,
          // setCellProps: (value) => {
          //   return {
          //     className: "font-bold-txt red-txt",
          //   };
          // },
          customBodyRender: (value, tableMeta, updateValue) => {
            return (
              <Link to={'edit-product/' + this.state.product_data[tableMeta.rowIndex].id} className="fw-bold dark-red-txt" >
                {value}
              </Link >
            );
          },
        },
      },
      {
        name: this.context.language === "english" ? "title_en" : "title_ar",
        label: productLanguage.productName,
        options: {
          display: this.context.language === "english" ? this.state.title_en : this.state.title_ar,
          setCellProps: () => {
            return { className: "product-name" }
          }
        },
      },
      {
        name: this.context.language === "english" ? "mc_english" : "mc_arabic",
        label: productLanguage.mainCategory,
        options: {
          display: this.context.language === "english" ? this.state.mc_english : this.state.mc_arabic,
        },
      },
      {
        name: this.context.language === "english" ? "c_english" : "c_arabic",
        label: productLanguage.category,
        options: {
          display: this.context.language === "english" ? this.state.c_english : this.state.c_arabic,
        },
      },
      {
        name: this.context.language === "english" ? "sc_english" : "sc_arabic",
        label: productLanguage.subCategory,
        options: {
          display: this.context.language === "english" ? this.state.sc_english : this.state.sc_arabic,
        },
      },
      {
        name: "price",
        label: productLanguage.Price,
        options: {
          display: this.state.price,
          viewColumns: false,
        },
      },
      {
        name: "discount_price",
        label: productLanguage.priceSR,
        options: {
          customBodyRender: (value, tableMeta, updateValue) => {
            return (
              <>
                <span>{Number(value).toFixed(2) + " "}</span>
                {value !== tableMeta.rowData[7] && <span className="text-secondary text-decoration-line-through">{tableMeta.rowData[7]}</span>}
              </>
            );
          },
        },
      },
      {
        name: "qty",
        label: productLanguage.quantity,
        options: {
          display: this.state.qty,
        },
      },
      {
        name: "sales",
        label: productLanguage.Sales,
        options: {
          display: this.state.sales,
        },
      },
      {
        name: "createdat",
        label: productLanguage.date,
        options: {
          display: this.state.createdat,
          customBodyRender: (value, tableMeta, updateValue) => {
            return Moment(value).format("DD/MM/YYYY hh:mm A");
            // return moment(value).calendar(null, {
            // sameDay: "[Today at] h:mm A",
            // lastDay: "[Yesterday at] h:mm A",
            // sameElse: "DD/MM/YYYY hh:mm A",
            // });
          },
        },
      },
      {
        name: "preference",
        label: productLanguage.Featured,
        options: {
          sort: false,
          display: this.state.preference,
          customBodyRender: (value, tableMeta, updateValue) => {
            return (
              <React.Fragment>
                <div className="cust-star-table-rating">
                  <input type="checkbox" checked={value == 0 ? false : true} className="btn-check" id={"btncheck1_" + tableMeta.rowData[0]} autoComplete="off" onChange={(e) => this.featured(e, tableMeta.rowData[0])} />
                  {value == 1 ? <label className="bi bi-star-fill" htmlFor={"btncheck1_" + tableMeta.rowData[0]} /> : <label className="bi bi-star" htmlFor={"btncheck1_" + tableMeta.rowData[0]} />}
                </div>
              </React.Fragment>
            );
          },
        },
      },
      {
        name: "status",
        label: productLanguage.status,
        options: {
          display: this.state.status,
          customBodyRender: (value, tableMeta, updateValue) => {
            return <label>{value == 0 ? productLanguage.dective : value == 1 ? productLanguage.Active : value == 2 ? ButtonLanguage.saveToDraft : value == 3 ? productLanguage.postpone : productLanguage.dective}</label>;
          },
        },
      },
      {
        name: "id",
        label: productLanguage.action,
        options: {
          sort: false,
          csvExport: false,
          customBodyRender: (value, tableMeta, updateValue) => {
            return (
              <React.Fragment>
                <Dropdown className="cust-drop">
                  <Dropdown.Toggle className="bg-transparent " id="dropdown-basic" align="end">
                    <svg xmlns="http://www.w3.org/2000/svg" width={16} height={16} fill="currentColor" className="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                      <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                    </svg>
                  </Dropdown.Toggle>
                  <Dropdown.Menu>
                    {/* <Dropdown.Item href="#" onClick={() => this.View_product_detail_handleShow(value)}>
                      <svg width={20} height={15} viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10 14C8.35987 14.0204 6.7367 13.6665 5.254 12.965C4.10469 12.4042 3.07265 11.6298 2.213 10.683C1.30243 9.70413 0.585467 8.56167 0.1 7.31601L0 7.00001L0.105 6.68401C0.590815 5.43944 1.30624 4.29728 2.214 3.31701C3.07334 2.37032 4.10504 1.59587 5.254 1.03501C6.73671 0.333598 8.35988 -0.0203796 10 9.39617e-06C11.6401 -0.0203444 13.2633 0.333631 14.746 1.03501C15.8953 1.59574 16.9274 2.3702 17.787 3.31701C18.6993 4.29456 19.4165 5.43737 19.9 6.68401L20 7.00001L19.895 7.31601C18.3262 11.3998 14.3742 14.0694 10 14ZM10 2.00001C6.59587 1.89334 3.47142 3.8751 2.117 7.00001C3.4712 10.1251 6.59579 12.107 10 12C13.4041 12.1064 16.5284 10.1247 17.883 7.00001C16.5304 3.87359 13.4047 1.89109 10 2.00001ZM10 10C8.55733 10.0096 7.30937 8.99737 7.02097 7.58378C6.73256 6.1702 7.48427 4.75003 8.81538 4.19367C10.1465 3.63731 11.6852 4.10014 12.4885 5.29852C13.2919 6.49689 13.1354 8.09609 12.115 9.11601C11.5563 9.68127 10.7948 9.99957 10 10Z" fill="#2D2D3B" />
                      </svg>
                      <span>View</span>
                    </Dropdown.Item> */}
                    <Dropdown.Item href={"edit-product/" + value}>
                      <svg width="19" height="18" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z" fill="#2D2D3B"></path>
                      </svg>
                      <span>{productLanguage.edit}</span>
                    </Dropdown.Item>
                    <Dropdown.Item href={`${process.env.REACT_APP_LIVE_DOMAIN}/sa-en/${this.state.product_data[tableMeta.rowIndex].mc_english && this.state.product_data[tableMeta.rowIndex].mc_english.replaceAll(" ", "-")}/${this.state.product_data[tableMeta.rowIndex].c_english && this.state.product_data[tableMeta.rowIndex].c_english.replaceAll(" ", "-")}/${this.state.product_data[tableMeta.rowIndex].sc_english && this.state.product_data[tableMeta.rowIndex].sc_english.replaceAll(" ", "-")}/${this.state.product_data[tableMeta.rowIndex].title_en && this.state.product_data[tableMeta.rowIndex].title_en.replaceAll(" ", "-")}-${this.state.product_data[tableMeta.rowIndex].id}-${this.state.product_data[tableMeta.rowIndex].variation_id}`} target="_blank">
                      <svg width={20} height={15} viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10 14C8.35987 14.0204 6.7367 13.6665 5.254 12.965C4.10469 12.4042 3.07265 11.6298 2.213 10.683C1.30243 9.70413 0.585467 8.56167 0.1 7.31601L0 7.00001L0.105 6.68401C0.590815 5.43944 1.30624 4.29728 2.214 3.31701C3.07334 2.37032 4.10504 1.59587 5.254 1.03501C6.73671 0.333598 8.35988 -0.0203796 10 9.39617e-06C11.6401 -0.0203444 13.2633 0.333631 14.746 1.03501C15.8953 1.59574 16.9274 2.3702 17.787 3.31701C18.6993 4.29456 19.4165 5.43737 19.9 6.68401L20 7.00001L19.895 7.31601C18.3262 11.3998 14.3742 14.0694 10 14ZM10 2.00001C6.59587 1.89334 3.47142 3.8751 2.117 7.00001C3.4712 10.1251 6.59579 12.107 10 12C13.4041 12.1064 16.5284 10.1247 17.883 7.00001C16.5304 3.87359 13.4047 1.89109 10 2.00001ZM10 10C8.55733 10.0096 7.30937 8.99737 7.02097 7.58378C6.73256 6.1702 7.48427 4.75003 8.81538 4.19367C10.1465 3.63731 11.6852 4.10014 12.4885 5.29852C13.2919 6.49689 13.1354 8.09609 12.115 9.11601C11.5563 9.68127 10.7948 9.99957 10 10Z" fill="#2D2D3B" />
                      </svg>
                      <span>{productLanguage.view}</span>
                    </Dropdown.Item>
                    <Dropdown.Item href="#" onClick={() => this.delete_record(value)}>
                      <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} fill="currentColor" className="bi bi-trash" viewBox="0 0 16 16">
                        <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
                        <path fillRule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" />
                      </svg>
                      <span>{productLanguage.delete}</span>
                    </Dropdown.Item>
                    <Dropdown.Item onClick={() => this.GenerateProductCode(6, value)}>
                      <svg width="19" height="18" aria-hidden="true" focusable="false" data-prefix="far" data-icon="clone" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" className="svg-inline--fa fa-clone fa-w-16 fa-3x">
                        <path fill="currentColor" d="M464 0H144c-26.51 0-48 21.49-48 48v48H48c-26.51 0-48 21.49-48 48v320c0 26.51 21.49 48 48 48h320c26.51 0 48-21.49 48-48v-48h48c26.51 0 48-21.49 48-48V48c0-26.51-21.49-48-48-48zM362 464H54a6 6 0 0 1-6-6V150a6 6 0 0 1 6-6h42v224c0 26.51 21.49 48 48 48h224v42a6 6 0 0 1-6 6zm96-96H150a6 6 0 0 1-6-6V54a6 6 0 0 1 6-6h308a6 6 0 0 1 6 6v308a6 6 0 0 1-6 6z" className=""></path>
                      </svg>
                      <span>{productLanguage.copy}</span>
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              </React.Fragment>
            );
          },
        },
      },
    ];

    const option = {
      fixedSelectColumn: true,
      print: false,
      sortDescFirst: true,
      serverSide: true,
      responsive: "standard",
      confirmFilters: true,
      textLabels: {
        body: {
          noMatch: productLanguage.Sorrynomatchingrecordsfound,
          toolTip: "Sort",
          columnHeaderTooltip: (column) => `${productLanguage.Sortfor} ${column.label}`,
        },
        pagination: {
          next: productLanguage.NextPage,
          previous: productLanguage.PreviousPage,
          rowsPerPage: productLanguage.Rowsperpage,
          displayRows: productLanguage.of,
          jumpToPage: productLanguage.jumptopage
        },
        toolbar: {
          downloadCsv: productLanguage.DownloadCSV,
          viewColumns: productLanguage.Viewcolumns,
          filterTable: productLanguage.FilterTable,
        },
        filter: {
          all: false,
          title: false,
          reset: false,
        },
        viewColumns: {
          title: productLanguage.ShowColumns,
          titleAria: "Show/Hide Table Columns",
        },
        selectedRows: {
          text: productLanguage.rowselected,
          delete: "",
          deleteAria: "Apply action on Selected Rows",
        },
      },
      customSearch: false,
      searchOpen: false,
      search: false,
      searchAlwaysOpen: false,
      count: this.state.totalSize,
      // count: Math.ceil(this.state.totalPage),
      pagination: true,
      jumpToPage: true,
      rowsPerPage: this.state.sizePerPage,
      rowsPerPageOptions: [50, 100, 300, 500],
      onChangeRowsPerPage: this.handleOnChangeRowsPerPage,
      onTableChange: (action, tableState) => {
        switch (action) {
          case "changePage":
            this.changePage(tableState.page);
            break;
          case "sort":
            this.setState(
              {
                // defaultSorted: [
                //   {
                //     dataField: sortField,
                columnSort: tableState.sortOrder.name,
                order: tableState.sortOrder.direction,
                //   },
                // ],
              },
              () => {
                this.setState({ isLoading: true });
                this.filterProducts();
              }
            );
            break;
          default:
          // console.log("does not changePage");
        }
      },
      onRowsSelect: this.handleSelectRow,
      // customFooter: this.customFooter,
      customToolbarSelect: (selectedRows, displayData, setSelectedRows) => {
        return (
          <div className="btn-list-order productbtn-list">
            <Dropdown>
              <Dropdown.Toggle className="btn dropdown-toggle cust-search-button mb-0 cust-date me-sm-2 me-0">
                <span className="px-3 py-1">{productLanguage.Applyaction}</span>
              </Dropdown.Toggle>
              <Dropdown.Menu className="cust-drop-box">
                <Dropdown.Item onClick={this.change_status_handleShow}>{productLanguage.Changestatus}</Dropdown.Item>
                <Dropdown.Item onClick={this.deleteProducts}>{productLanguage.DeleteProducts}</Dropdown.Item>
                <Dropdown.Item onClick={this.change_category_show}>{productLanguage.ChangeCategory}</Dropdown.Item>
                <hr />
                <Dropdown.Item onClick={this.add_tag_show}>{productLanguage.AddTag}</Dropdown.Item>
                <Dropdown.Item onClick={this.remove_tag_show}>{productLanguage.RemoveTag}</Dropdown.Item>
                <Dropdown.Item onClick={this.add_offer_show}>{productLanguage.AddOffer}</Dropdown.Item>
                <Dropdown.Item onClick={this.removeOfferAction}>{productLanguage.RemoveOffer}</Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </div>
        );
      },
      filter: true,
      filterType: "custom",
      display: true,
      customFilterDialogFooter: (currentFilterList, applyNewFilters) => {
        return (
          <div className="p-0 rounded-3" style={{ fontFamily: this.context.language === "english" ? "Poppins" : "Noto Kufi Arabic" }}>
            <div className="row">
              <div className="col-12 form-group mt-3">
                <label className="cust-radio mb-0">
                  {this.state.barcodeOption !== "" ? <input type="radio" id="barcode" onChange={this.handleBarcodeButtonChange} name="barcode" checked /> : <input type="radio" id="barcode" onChange={this.handleBarcodeButtonChange} name="barcode" />}
                  <span className="checkmark"></span>
                  <p>{productLanguage.BarcodeNumbers}</p>
                </label>
              </div>
              <div className="col-12 form-group">
                {this.state.barcodeOption !== "" && <textarea placeholder={productLanguage.TypeLineByLine} className="form-control input-custom-class h-auto" rows={5} name="barcodeNumber" onKeyUp={this.handleBarcodeNumber} id="barcodeInput" />}
                <div>
                  {this.state.barcodeForDisplay && this.state.barcodeForDisplay.length > 0 && (
                    <ul className="d-flex align-items-center flex-wrap">
                      {this.state.barcodeForDisplay !== "" &&
                        this.state.barcodeForDisplay.map((item, i) => {
                          return (
                            <li key={i} className="me-2 mb-3">
                              <bdi className="barcode-bg py-1 px-2 mx-2 rounded">{item.value}</bdi>
                              <mark onClick={() => this.removeBarcode(item.id)} className="bg-transparent bi bi-x p-0"></mark>
                            </li>
                          );
                        })}
                    </ul>
                  )}
                </div>
              </div>
              <div className="form-group col-12">
                <label className="d-block">{productLanguage.taggedWith}</label>
                <div className="d-flex align-items-center">
                  <input type="text" className="form-control input-custom-class me-2" onChange={this.handleTag} value={this.state.tag} name="tags" placeholder={productLanguage.Entertag} />
                  <div onClick={this.handleAddTag} className="btn light-red-btn">
                    <img src={plusImg} />
                  </div>
                </div>
                {this.state.tagsForDisplay && this.state.tagsForDisplay.length > 0 && (
                  // <div className="cust-tag-div">
                  <ul className="d-flex align-items-center text-center flex-wrap">
                    {this.state.tagsForDisplay.map((item, i) => {
                      return (
                        <li key={i} className="py-1 px-2 mx-2 mb-3 barcode-bg rounded">
                          <bdi className="me-2">{item.value}</bdi>
                          <mark onClick={() => this.removeTag(item.id)} className="bg-transparent bi bi-x p-0"></mark>
                        </li>
                      );
                    })}
                  </ul>
                  // </div>
                )}
              </div>
              <div className="col-6 form-group mt-2">
                <label className="d-block">{productLanguage.Productstatus}</label>
                <select className="form-select input-custom-class" value={this.state.filterStatus} onChange={this.changeStatusFilter}>
                  <option value="">{productLanguage.Selectcategorystatus}</option>
                  <option value="0">{productLanguage.dective}</option>
                  <option value="1">{productLanguage.Active}</option>
                  <option value="2">{ButtonLanguage.saveToDraft}</option>
                  <option value="3">{productLanguage.postpone}</option>
                </select>
              </div>
              <div className="col-6 form-group">
                <label className="d-block">{productLanguage.Productbehaviour}</label>
                <select className="form-select input-custom-class" value={this.state.productBehaviour} onChange={this.changeProductBehaviour}>
                  <option value="">{productLanguage.NotSelected}</option>
                  <option value="low_stock">{productLanguage.Lowstock}</option>
                  <option value="not_moving">{productLanguage.Notmoving}</option>
                  <option value="top_selling">{productLanguage.Topselling}</option>
                  <option value="most_returning">{productLanguage.Mostreturning}</option>
                  <option value="featured">{productLanguage.Featured}</option>
                  <option value="on_sale">{productLanguage.Havesaleprice}</option>
                </select>
              </div>
              <div className="col-12 form-group">
                <label className="d-block">{productLanguage.MainCategory}</label>
                <select className="form-select input-custom-class" name="mainCategoryChange" value={this.state.mainCategoryChange} onChange={this.changeMainCategory}>
                  <option defaultValue>{productLanguage.chooseMainCategory}</option>
                  {this.state.mainCategory.length > 0 &&
                    this.state.mainCategory.map((item, i) => {
                      return (
                        <option key={i} value={item.id}>
                          {this.context.language === "english" ? item.english : item.arabic}
                        </option>
                      );
                    })}
                </select>
              </div>
              <div className="col-12 form-group">
                <label className="d-block">{productLanguage.category}</label>
                <select className="form-select input-custom-class" name="CategoryChange" value={this.state.CategoryChange} onChange={this.changeCategory}>
                  <option defaultValue>{productLanguage.SelectCategory}</option>
                  {this.state.Category.length > 0 &&
                    this.state.Category.map((item, i) => {
                      return (
                        <option key={i} value={item.id}>
                          {this.context.language === "english" ? item.english : item.arabic}
                        </option>
                      );
                    })}
                </select>
              </div>
              <div className="col-12 form-group">
                <label className="d-block">{productLanguage.subCategory}</label>
                <select className="form-select input-custom-class" name="subCategoryChange" value={this.state.subCategoryChange} onChange={this.changeSubCategory}>
                  <option defaultValue>{productLanguage.SelectSubCategory}</option>
                  {this.state.subCategory.length > 0 &&
                    this.state.subCategory.map((item, i) => {
                      return (
                        <option key={i} value={item.id}>
                          {this.context.language === "english" ? item.english : item.arabic}
                        </option>
                      );
                    })}
                </select>
              </div>
              <div className="col-6 form-group">
                <label className="d-block">{productLanguage.FromDate}</label>
                <DatePicker name="startDate" className="form-control input-custom-class" onChange={this.handleChangeStartDate} value={this.state.startDate} placeholderText="YYYY-MM-DD" />
              </div>
              <div className="col-6 form-group">
                <label className="d-block">{productLanguage.ToDate}</label>
                <DatePicker name="endDate" className="form-control input-custom-class" onChange={this.handleChangeEndDate} value={this.state.endDate} placeholderText="YYYY-MM-DD" />
              </div>
              <div className="col-md-12 form-group text-center mt-5">
                <button type="button" className="btn red-btn me-3" onClick={() => this.filterClick()}>
                  {productLanguage.filter}
                </button>
                <a type="button" className="red-txt" onClick={() => this.clearFilterProduct()}>
                  {productLanguage.clearAll}
                </a>
              </div>
            </div>
          </div>
        );
      },
      onViewColumnsChange: this.onViewColumnsChange,
      onColumnSortChange: this.onChangeColumnSort,
      selectableRows: true,
      onFilterConfirm: (filterList) => {
        console.log(filterList);
      },
      onFilterDialogOpen: () => {
        console.log("filter dialog opened");
      },
      onFilterDialogClose: () => {
        console.log("filter dialog closed");
      },
    };

    return (
      <React.Fragment>
        {this.state.isLoading && (
          <div className="loader-main">
            <div className="loader-inr">
              <img src={loader} alt="" />
            </div>
          </div>
        )}
        <Adminlayout>
          <div className="container-fluid position-relative">
            <div className="row common-space pt-3">
              <div className="col-sm-6 text-sm-start text-center rtl-txt-start">
                <div className="common-header-txt">
                  <h3>{productLanguage.product}</h3>
                </div>
              </div>
              <div className="col-sm-6 text-sm-end text-center rtl-txt-end">
                <div className="common-red-btn">
                  {/* <a
                  href="#"
                  className="btn red-btn me-2"
                  onClick={this.edit_handleShow}
                >
                  {productLanguage.applyFeature}
                </a>
                <a href="#" className="btn black-btn me-2">
                  {productLanguage.exportList}
                </a> */}

                  <button type="button" className="btn red-btn me-2" onClick={this.openUploadFileMode}>Update Sales Price</button>
                  <a href="add-product" className="btn red-btn">
                    {productLanguage.addProduct}
                  </a>
                </div>
              </div>
            </div>
            <div className="row common-space pt-3">
              <div className="col-md-12">
                <div className="white-box pt-md-3 pt-5">
                  <div className="dataTables_wrapper product-list-tble no-footer">
                    {this.state.product_data && (
                      <MuiThemeProvider theme={theme}>
                        <div className="right-menu ms-auto position-relative product-tbl">

                          {/* <span className="filter-no-span">{''}</span> */}

                          <MUITable data={this.state.product_data} columns={columns} options={option} />
                          <div className="fix-search d-flex align-items-center">
                            <div className="position-relative search-sm-screen" id="search-menu">
                              <input type="search" name="search" className="form-control top-search ps-5 input-custom-class mb-0" placeholder={productLanguage.searchPlaceholder} onChange={this.handleSearchChange} />
                              <span className="search-icn position-absolute ms-3">
                                <img src={SearchIcon} alt="" />
                              </span>
                            </div>
                            <div className="d-flex align-items-center d-lg-flex d-none" value={this.state.ProductAvailability} onChange={this.selectAvailability}>
                              <div className="ms-3">
                                <label className="cust-radio mb-0">
                                  <input type="radio" id="1" value="in-stock" name="availability" defaultChecked />
                                  <span className="checkmark"></span>
                                  <span className="text-nowrap">{this.context.language === "english" ? 'in Stock' : 'متوفر'} </span>
                                </label>
                              </div>
                              <div className="ms-3">
                                <label className="cust-radio mb-0">
                                  <input type="radio" id="2" value="out-of-stock" name="availability" />
                                  <span className="checkmark"></span>
                                  <span className="text-nowrap">{this.context.language === "english" ? 'out of stock' : 'منتهى الكمية'}</span>
                                </label>
                              </div>
                              <div className="ms-3">
                                <label className="cust-radio mb-0">
                                  <input type="radio" id="3" value="all" name="availability" />
                                  <span className="checkmark"></span>
                                  <span className="text-nowrap">{this.context.language === "english" ? 'All' : 'الكل'}</span>
                                </label>
                              </div>
                            </div>
                            <div className="ms-3 w-100 d-lg-none">
                              <select className="border-0 bg-transparent pe-2" value={this.state.ProductAvailability} onChange={this.selectAvailability}>
                                <option value={'in-stock'}>in Stock</option>
                                <option value={'out-of-stock'}>out of Stock</option>
                                <option value={'all'}>All</option>
                              </select>
                            </div>
                          </div>
                          <button className=" bg-transparent border-0 first-btn" onClick={this.firstButton}>
                            <i className="bi bi-chevron-double-left"></i>
                          </button>
                          <button className=" bg-transparent border-0 last-btn" onClick={this.lastButton}>
                            <i className="bi bi-chevron-double-right"></i>
                          </button>
                        </div>
                      </MuiThemeProvider>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* ---------------------------cloneProduct-------------------- */}

          <Modal dialogClassName="modal-dialog-centered cust-width-modal" className="edit-user-modal cust-modal" show={this.state.isCloneshow} onHide={this.handleCloneClose}>
            <Modal.Header>
              <Modal.Title>
                <h1 className="modal-title">{productLanguage.Barcode}</h1>
              </Modal.Title>
              <button type="button" onClick={this.handleCloneClose} className="close btn-close"></button>
            </Modal.Header>
            <Modal.Body>
              <div className="row modal-form">
                <div className="col-md-12 form-group">
                  <label>{productLanguage.EnterBarcodeNo}</label>
                  <input name="barcodeno" value={this.state.barcodeno} onChange={this.handleBarcodeChange} className="form-control" placeholder="1234" />
                </div>
                <div className="col-md-12 form-group">
                  <label>{productLanguage.product} SKU</label>
                  <input name="barcodeno" value={this.state.productCode} className="form-control" placeholder="1234" />
                </div>
                <div className="col-md-12 from-group text-center">
                  <button type="button" className="btn red-btn" onClick={this.createCloneProduct}>
                    {productLanguage.submit}
                  </button>
                </div>
              </div>
            </Modal.Body>
          </Modal>

          {/* ------------------------modal-------------------------- */}

          <Modal
            dialogClassName="modal-dialog-centered cust-width-modal"
            className="edit-user-modal cust-modal"
            ref={(el) => {
              this.dialog = el;
            }}
            show={this.state.search_show}
            onHide={this.edit_userClose}
          >
            <Modal.Header>
              <Modal.Title>
                <h1 className="modal-title">{productLanguage.Feature}</h1>
              </Modal.Title>
              <button type="button" onClick={this.edit_userClose} className="close btn-close"></button>
            </Modal.Header>
            <Modal.Body>
              <div className="row modal-form">
                <div className="col-md-12 form-group">
                  <label>{productLanguage.offer}</label>
                  <ul className="product-list-check-offer">
                    <li>
                      <div className="cust-checkbox-new">
                        <label className="cust-chk-bx">
                          <input type="checkbox" />
                          <span className="cust-chkmark" />
                          50% off
                        </label>
                      </div>
                    </li>
                    <li>
                      <div className="cust-checkbox-new">
                        <label className="cust-chk-bx">
                          <input type="checkbox" />
                          <span className="cust-chkmark" />
                          10% off
                        </label>
                      </div>
                    </li>
                    <li>
                      <div className="cust-checkbox-new">
                        <label className="cust-chk-bx">
                          <input type="checkbox" />
                          <span className="cust-chkmark" />
                          50% off
                        </label>
                      </div>
                    </li>
                    <li>
                      <div className="cust-checkbox-new">
                        <label className="cust-chk-bx">
                          <input type="checkbox" />
                          <span className="cust-chkmark" />
                          20% off
                        </label>
                      </div>
                    </li>
                    <li>
                      <div className="cust-checkbox-new">
                        <label className="cust-chk-bx">
                          <input type="checkbox" />
                          <span className="cust-chkmark" />
                          10% off
                        </label>
                      </div>
                    </li>
                    <li>
                      <div className="cust-checkbox-new">
                        <label className="cust-chk-bx">
                          <input type="checkbox" />
                          <span className="cust-chkmark" />
                          60% off
                        </label>
                      </div>
                    </li>
                  </ul>
                </div>
                <div className="col-md-12 form-group">
                  <label>{productLanguage.Tag}</label>
                  <Select isMulti value={this.state.selectedOption} onChange={this.handleChanges} options={this.options} styles={this.customStyles} />
                </div>
                <div className="col-md-12 form-group">
                  <label>{productLanguage.status}</label>
                  <label className="switch d-block">
                    <input type="checkbox" />
                    <div className="slider round" />
                    <div className="text" />
                  </label>
                </div>

                <div className="col-md-12 form-group text-center mb-3">
                  <button type="button" className="btn red-btn">
                    {ButtonLanguage.apply}
                  </button>
                </div>
              </div>
            </Modal.Body>
          </Modal>

          {/* ------------------------Product Details modal Start-------------------------- */}

          <Modal
            dialogClassName="modal-xl modal-dialog-centered"
            className="edit-user-modal cust-modal"
            ref={(el) => {
              this.dialog = el;
            }}
            show={this.state.Product_details_model_show}
            onHide={this.View_product_detail_handleClose}
          >
            <ProductDetailModal View_product_detail_handleClose={this.View_product_detail_handleClose} View_Product_id={this.state.View_Product_id} />
          </Modal>

          {/* ------------------------Product Details modal Close-------------------------- */}

          {/* ------------------------Change Status Modal Open-------------------------- */}

          <Modal
            dialogClassName="modal-dialog-centered modal-md edit-user-modal cust-modal"
            ref={(el) => {
              this.dialog = el;
            }}
            show={this.state.change_status_modal_show}
            onHide={this.change_status_handleClose}
          >
            <Modal.Header>
              <Modal.Title>
                <h1 className="modal-title">{productLanguage.Changestatus}</h1>
              </Modal.Title>
              <button type="button" onClick={this.change_status_handleClose} className="close btn-close"></button>
            </Modal.Header>
            <Modal.Body>
              <form>
                <div className="row me-0">
                  <div className="form-group col-md-12 pe-0">
                    <select name="statusSelect" className="form-select input-custom-class" onChange={this.handleChangeStatus} value={this.state.statusAction}>
                      <option value="">{productLanguage.Selectcategorystatus}</option>
                      <option value="0">{productLanguage.dective}</option>
                      <option value="1">{productLanguage.Active}</option>
                      <option value="2">{ButtonLanguage.saveToDraft}</option>
                      <option value="3">{productLanguage.postpone}</option>
                    </select>
                  </div>
                  <div className="form-group col-12 text-center pt-5">
                    <button type="button" className="btn red-btn" onClick={this.changeProductStatusAction}>
                      {productLanguage.apply}
                    </button>
                  </div>
                </div>
              </form>
            </Modal.Body>
          </Modal>

          {/* ------------------------Change Status Modal Close-------------------------- */}

          {/* ------------------------Change Category Modal Open-------------------------- */}

          <Modal
            dialogClassName="modal-dialog-centered cust-width-modal"
            className="edit-user-modal cust-modal"
            ref={(el) => {
              this.dialog = el;
            }}
            show={this.state.change_category_model_show}
            onHide={this.change_category_Close}
          >
            <Modal.Header>
              <Modal.Title>
                <h1 className="modal-title">{productLanguage.ChangeCategory}</h1>
              </Modal.Title>
              <button type="button" onClick={this.change_category_Close} className="close btn-close"></button>
            </Modal.Header>
            <Modal.Body>
              <div className="row right-menu ms-auto">
                <div className="col-md-8 position-relative search-sm-screen mb-4" id="search-menu">
                  <input type="search" className="form-control top-search" placeholder={productLanguage.Searchtofindcategoriesavailable} />
                </div>
              </div>
              <div className="row modal-form">
                <div className="col-md-12 form-group">
                  <label>{productLanguage.Selectoneofthecategory}</label>
                  <div className="row">
                    <div className="col-12">
                      {this.state.subCategoryData &&
                        this.state.subCategoryData.map((item) => {
                          return (
                            <>
                              {
                                item && item.map((l) => {
                                  let data = {
                                    mainCat: l.main_category,
                                    Cat: l.category,
                                    subCat: l.id,
                                  };
                                  data = JSON.stringify(data);
                                  return (
                                    <label className="cust-radio mb-0" key={l.id}>
                                      <input type="radio" value={data} name="categories" onChange={this.handleCategoryActionChange} />
                                      <span className="checkmark"></span>
                                      <p>
                                        <span>{l.main_english + " > "}</span>
                                        <span>{l.category_english + " > "}</span>
                                        <span>{l.english}</span>
                                      </p>
                                    </label>
                                  );
                                })
                              }
                            </>
                          )
                        })}
                    </div>
                  </div>
                </div>
                <div className="col-md-12 form-group text-center mb-3">
                  <button type="button" className="btn red-btn" onClick={this.changeProductCategoryAction}>
                    {productLanguage.apply}
                  </button>
                </div>
              </div>
            </Modal.Body>
          </Modal>

          {/* ------------------------Change Category Modal Close-------------------------- */}

          {/* ------------------------Add Tag Modal Open-------------------------- */}

          <Modal
            dialogClassName="modal-dialog-centered cust-width-modal"
            className="edit-user-modal cust-modal"
            ref={(el) => {
              this.dialog = el;
            }}
            show={this.state.add_tag_model_show}
            onHide={this.add_tag_Close}
          >
            <Modal.Header>
              <Modal.Title>
                <h1 className="modal-title">{productLanguage.Addtagstoproducts}</h1>
              </Modal.Title>
              <button type="button" onClick={this.add_tag_Close} className="close btn-close"></button>
            </Modal.Header>
            <Modal.Body>
              {/* <div className="row right-menu ms-auto">
              <div
                className="col-md-8 position-relative search-sm-screen mb-4"
                id="search-menu"
              >
                <input
                  type="search"
                  className="form-control top-search"
                  placeholder="Search to find or create tags"
                />
              </div>
            </div> */}
              <div className="row modal-form">
                <div className="col-md-12 form-group">
                  <ul className="ps-4">
                    {/* <label className="fw-bold">TO ADD</label>
                  {
                    tagActionToAdd.length > 0 &&
                    tagActionToAdd.map((item, i) => {
                      console.log(item)
                      return (
                        <li className="mb-2">
                          <div className="cust-checkbox-new">
                            <label className="cust-chk-bx">
                              <input type="checkbox" />
                              <span className="cust-chkmark" />
                              <bdi>{item}</bdi>
                            </label>
                          </div>
                        </li>
                      )
                    })
                  } */}
                    <label className="fw-bold mt-3">{productLanguage.AVAILABLE}</label>
                    {this.state.ActionTagArr.length > 0 &&
                      this.state.ActionTagArr.map((item, i) => {
                        return (
                          <li key={i}>
                            <div className="cust-checkbox-new">
                              <label className="cust-chk-bx">
                                <input name={item} type="checkbox" onChange={this.handleTagCheckBox} />
                                <span className="cust-chkmark" />
                                <bdi>{item}</bdi>
                              </label>
                            </div>
                          </li>
                        );
                      })}
                  </ul>
                </div>
                <div className="col-md-12 form-group text-center mb-3">
                  <button type="button" className="btn red-btn" onClick={this.addTagAction}>
                    {productLanguage.apply}
                  </button>
                </div>
              </div>
            </Modal.Body>
          </Modal>

          {/* ------------------------Add Tag Modal Close-------------------------- */}

          {/* ------------------------Remove Tag Modal Open-------------------------- */}

          <Modal
            dialogClassName="modal-dialog-centered cust-width-modal"
            className="edit-user-modal cust-modal"
            ref={(el) => {
              this.dialog = el;
            }}
            show={this.state.remove_tag_model_show}
            onHide={this.remove_tag_Close}
          >
            <Modal.Header>
              <Modal.Title>
                <h1 className="modal-title">{productLanguage.Removetagsfromproducts}</h1>
              </Modal.Title>
              <button type="button" onClick={this.remove_tag_Close} className="close btn-close"></button>
            </Modal.Header>
            <Modal.Body>
              <div className="row modal-form">
                <div className="col-md-12 form-group">
                  <ul className="ps-4">
                    <label className="fw-bold mt-3">{productLanguage.AVAILABLE}</label>
                    {this.state.ActionTagArr.length > 0 &&
                      this.state.ActionTagArr.map((item, i) => {
                        return (
                          <li key={i}>
                            <div className="cust-checkbox-new">
                              <label className="cust-chk-bx">
                                <input name={item} type="checkbox" onChange={this.handleTagRemoveCheckBox} />
                                <span className="cust-chkmark" />

                                <bdi>{item}</bdi>
                              </label>
                            </div>
                          </li>
                        );
                      })}
                  </ul>
                </div>
                <div className="col-md-12 form-group text-center mb-3">
                  <button type="button" className="btn red-btn" onClick={this.removeTagAction}>
                    {productLanguage.apply}
                  </button>
                </div>
              </div>
            </Modal.Body>
          </Modal>

          {/* ------------------------Remove Tag Modal Close-------------------------- */}

          {/* ------------------------Add Offer Modal Open-------------------------- */}

          <Modal
            dialogClassName="modal-dialog-centered cust-width-modal"
            className="edit-user-modal cust-modal"
            ref={(el) => {
              this.dialog = el;
            }}
            show={this.state.add_offer_model_show}
            onHide={this.add_offer_Close}
          >
            <Modal.Header>
              <Modal.Title>
                <h1 className="modal-title">{productLanguage.Addofferstoproducts}</h1>
              </Modal.Title>
              <button type="button" onClick={this.add_offer_Close} className="close btn-close"></button>
            </Modal.Header>
            <Modal.Body>
              {/* <div className="row right-menu ms-auto">
              <div
                className="col-md-8 position-relative search-sm-screen mb-4"
                id="search-menu"
              >
                <input
                  type="search"
                  className="form-control top-search"
                  placeholder="Search to find offers"
                />
              </div>
            </div> */}
              <div className="row modal-form">
                <div className="col-md-12 form-group">
                  <ul className="ps-4">
                    {/* <label className="fw-bold">TO ADD</label>
                  <li className="mb-2">
                    <div className="cust-checkbox-new">
                      <label className="cust-chk-bx">
                        <input type="checkbox" />
                        <span className="cust-chkmark" />
                        <bdi></bdi>
                      </label>
                    </div>
                  </li> */}
                    <label className="fw-bold mt-3">{productLanguage.AVAILABLE}</label>
                    {this.state.ActionOfferArr.length > 0 &&
                      this.state.ActionOfferArr.map((item, i) => {
                        return (
                          <li key={i}>
                            <div className="cust-checkbox-new">
                              <label className="cust-chk-bx">
                                <input name={item.value} type="checkbox" onChange={this.handleOfferCheckBox} />
                                <span className="cust-chkmark" />

                                <bdi>{item.tagName}</bdi>
                              </label>
                            </div>
                          </li>
                        );
                      })}
                  </ul>
                </div>
                <div className="col-md-12 form-group text-center mb-3">
                  <button type="button" className="btn red-btn" onClick={this.addOfferAction}>
                    {productLanguage.apply}
                  </button>
                </div>
              </div>
            </Modal.Body>
          </Modal>

          {/* ------------------------Add Offer Modal Close-------------------------- */}

          {/* ------------------------Remove Offer Modal Open-------------------------- */}

          <Modal
            dialogClassName="modal-dialog-centered cust-width-modal"
            className="edit-user-modal cust-modal"
            ref={(el) => {
              this.dialog = el;
            }}
            show={this.state.remove_offer_model_show}
            onHide={this.remove_offer_Close}
          >
            <Modal.Header>
              <Modal.Title>
                <h1 className="modal-title">{productLanguage.Removeoffersfromproducts}</h1>
              </Modal.Title>
              <button type="button" onClick={this.remove_offer_Close} className="close btn-close"></button>
            </Modal.Header>
            <Modal.Body>
              <div className="row modal-form">
                <div className="col-md-12 form-group">
                  <ul className="ps-4">
                    <label className="fw-bold mt-3">{productLanguage.AVAILABLE}</label>
                    {this.state.ActionOfferArr.length > 0 &&
                      this.state.ActionOfferArr.map((item, i) => {
                        return (
                          <li key={i}>
                            <div className="cust-checkbox-new">
                              <label className="cust-chk-bx">
                                <input name={item.value} type="checkbox" onChange={this.handleOfferCheckBox} />
                                <span className="cust-chkmark" />

                                <bdi>{item.offerName}</bdi>
                              </label>
                            </div>
                          </li>
                        );
                      })}
                  </ul>
                </div>
                <div className="col-md-12 form-group text-center mb-3">
                  <button type="button" className="btn red-btn" onClick={this.removeOfferAction}>
                    {productLanguage.apply}
                  </button>
                </div>
              </div>
            </Modal.Body>
          </Modal>

          {/* ------------------------Remove Tag Modal Close-------------------------- */}

          {/* ------------------------clone product show-------------------------- */}

          <Modal show={this.state.cloned_product_show} className="cust-white-modal  signout-modal" onHide={this.cloned_product_close} size="md" centered>
            <Modal.Header className="border-0" closeButton></Modal.Header>
            <Modal.Body className="pt-0">
              <div className="text-center p-4 pt-0">
                <h5 className="mb-3 mx-3">Do you want to edit or view coppied product?</h5>
                <a href={"product-details/" + this.state.Id}>
                  <button className="btn red-btn me-2">VIEW</button>
                </a>
                <a href={"edit-product/" + this.state.Id}>
                  <button className="btn red-btn">EDIT</button>
                </a>
              </div>
            </Modal.Body>
          </Modal>

          {/* ------------------------clone product Close-------------------------- */}
          {/* ----------------------------------uploade-salse-price-file-model-------------------------------------- */}
          <Modal dialogClassName="modal-dialog-centered cust-width-modal" className="edit-user-modal cust-modal" ref={el => {
            this.dialog = el;
          }} show={this.state.uploadFileShow} onHide={this.uploadFileModelClose}>
            <Modal.Header>
              <Modal.Title>
                <h1 className="modal-title">Uploade CSV File</h1>
              </Modal.Title>
              <button type="button" onClick={this.uploadFileModelClose}
                className="close btn-close"></button>
            </Modal.Header>
            <Modal.Body>
              {this.state.uplodedFile === '' ?
                <div className="upload-file-section-new position-relative">
                  <div className="file-selecter text-center position-relative h-auto">
                    <div className="file-area position-relative py-3">
                      <input type="file" name="productImage" id="SelectProductxls" onChange={this.handleUploadeFile} accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel" />
                      <div className="file-dummy">
                        <div className="file-upload-content mb-3">
                          <img className="file-dummy-image" src={dragimg} alt="" />
                        </div>
                        {/* <span>
                          {productLanguage.DragDrop}
                          <bdi className="d-block">{productLanguage.or}</bdi>
                        </span> */}
                        <button className="btn red-btn mt-3">{productLanguage.BrowseFiles}</button>
                      </div>
                    </div>
                  </div>
                </div>
                :
                <div className="pdf-download-div d-flex align-items-center justify-content-between">
                  <div>
                    <svg className="me-2" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M21 7V17C21 20 19.5 22 16 22H8C4.5 22 3 20 3 17V7C3 4 4.5 2 8 2H16C19.5 2 21 4 21 7Z" stroke="#18191F" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                      <path d="M14.5 4.5V6.5C14.5 7.6 15.4 8.5 16.5 8.5H18.5" stroke="#18191F" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                      <path d="M8 13H12" stroke="#18191F" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                      <path d="M8 17H16" stroke="#18191F" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                    <span>{this.state.uplodedFile.name}</span>
                  </div>
                  <div>
                    <button type="button" className="bg-transparent p-0 border-0" onClick={this.removeFile}><i className="bi bi-x-circle-fill" /></button>
                  </div>
                </div>
              }
            </Modal.Body>
            <Modal.Footer>
              <button type="button" className="btn red-btn" onClick={this.uploadFileInDataBase}>Save</button>
            </Modal.Footer>
          </Modal>
          {/* ----------------------------------uploade-salse-price-file-model-close-------------------------------------- */}
        </Adminlayout>
      </React.Fragment>
    );
  }
}

export default Products;
