import React, { Component } from 'react';
import Adminlayout from '../../Components/AdminLayout/Adminlayout';
import { AdminArabic, AdminEnglish, API_Path, TableFieldArabic, TableFieldEnglish } from '../../const';
import LanguageContext from '../../contexts/languageContext'
import { PostApi } from '../../helper/APIService';

class AdminDetails extends Component {
    static contextType = LanguageContext;

    state = {
        adminDetail: ''
    }

    componentDidMount() {

        let url = window.location.href
        let adminId = url.substr(url.lastIndexOf('/') + 1)

        let data = {
            id: adminId
        }
        let path = API_Path.getAdminDetails


        const GetAdminDetailsPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        GetAdminDetailsPromise.then((res) => {
            if (res) {
                this.setState({ adminDetail: res.data.data[0] })
            }
        });
    }

    render() {
        let Language = this.context.language === 'english' ? TableFieldEnglish : TableFieldArabic
        let adminLanguage = this.context.language === 'english' ? AdminEnglish : AdminArabic
        return (
            <Adminlayout>
                <div className="container-fluid">
                    <div className="row common-space">
                        <div className="col-sm-12 text-sm-start text-center">
                            <div className="common-header-txt">
                                <h3>{adminLanguage.adminDetail}</h3>
                            </div>
                        </div>
                    </div>
                    {this.state.adminDetail !== '' && <div className="row common-space">
                        <div className="col-md-12">
                            <div className="white-box">
                                <form className="row cust-form-user">
                                    <div className="form-group col-md-6">
                                        <label>{Language.firstName}</label>
                                        <input type="text" className="form-control" readOnly value={this.state.adminDetail.first_name} />
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>{Language.lastName}</label>
                                        <input type="text" className="form-control" readOnly value={this.state.adminDetail.last_name} />
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>{Language.emailAddress}</label>
                                        <input type="email" className="form-control" readOnly value={this.state.adminDetail.email} />
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>{Language.mobileNumber}</label>
                                        <input type="tel" className="form-control" readOnly value={this.state.adminDetail.phone} />
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>}
                </div>

            </Adminlayout>
        );
    }
}

export default AdminDetails;