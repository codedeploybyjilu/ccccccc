import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import DataTable from "../../Components/DataTable";
import { textFilter } from "react-bootstrap-table2-filter";
import { confirmAlert } from "react-confirm-alert";
import LanguageContext from "../../contexts/languageContext";
import {
  buttonArabic,
  buttonEnglish,
  TableFieldArabic,
  TableFieldEnglish,
  titleArabic,
  titleEnglish,
} from "../../const";

class DeviceInformation extends Component {
  static contextType = LanguageContext;
  constructor(props) {
    super(props);
    this.state = {
      page: 1,
      sizePerPage: 10,
      totalSize: 100,
      defaultSorted: [
        {
          dataField: "id",
          order: "asc",
        },
      ],
      order_data: [
        {
          id: 1,
          firstname: "john",
          lastname: "Doe",
          devicename: "OnePlus 6T",
          devicetype: "Smartphone",
          devicemodelname: "6T",
          osversion: "OnePlus Nord CE",
          appversion: "Cordova",
          email: "johndoe12@gmail.com",
          firstopened: "20/02/2020",
          lastopened: "13/09/2021",
          phonenumber: "+1 1234567898",
        },
        {
          id: 2,
          firstname: "john",
          lastname: "Doe",
          devicename: "OnePlus 6T",
          devicetype: "Smartphone",
          devicemodelname: "6T",
          osversion: "OnePlus Nord CE",
          appversion: "Cordova",
          email: "johndoe12@gmail.com",
          firstopened: "20/02/2020",
          lastopened: "13/09/2021",
          phonenumber: "+1 1234567898",
        },
        {
          id: 3,
          firstname: "john",
          lastname: "Doe",
          devicename: "OnePlus 6T",
          devicetype: "Smartphone",
          devicemodelname: "6T",
          osversion: "OnePlus Nord CE",
          appversion: "Cordova",
          email: "johndoe12@gmail.com",
          firstopened: "20/02/2020",
          lastopened: "13/09/2021",
          phonenumber: "+1 1234567898",
        },
        {
          id: 4,
          firstname: "john",
          lastname: "Doe",
          devicename: "OnePlus 6T",
          devicetype: "Smartphone",
          devicemodelname: "6T",
          osversion: "OnePlus Nord CE",
          appversion: "Cordova",
          email: "johndoe12@gmail.com",
          firstopened: "20/02/2020",
          lastopened: "13/09/2021",
          phonenumber: "+1 1234567898",
        },
        {
          id: 5,
          firstname: "john",
          lastname: "Doe",
          devicename: "OnePlus 6T",
          devicetype: "Smartphone",
          devicemodelname: "6T",
          osversion: "OnePlus Nord CE",
          appversion: "Cordova",
          email: "johndoe12@gmail.com",
          firstopened: "20/02/2020",
          lastopened: "13/09/2021",
          phonenumber: "+1 1234567898",
        },
        {
          id: 6,
          firstname: "john",
          lastname: "Doe",
          devicename: "OnePlus 6T",
          devicetype: "Smartphone",
          devicemodelname: "6T",
          osversion: "OnePlus Nord CE",
          appversion: "Cordova",
          email: "johndoe12@gmail.com",
          firstopened: "20/02/2020",
          lastopened: "13/09/2021",
          phonenumber: "+1 1234567898",
        },
        {
          id: 7,
          firstname: "john",
          lastname: "Doe",
          devicename: "OnePlus 6T",
          devicetype: "Smartphone",
          devicemodelname: "6T",
          osversion: "OnePlus Nord CE",
          appversion: "Cordova",
          email: "johndoe12@gmail.com",
          firstopened: "20/02/2020",
          lastopened: "13/09/2021",
          phonenumber: "+1 1234567898",
        },
        {
          id: 8,
          firstname: "john",
          lastname: "Doe",
          devicename: "OnePlus 6T",
          devicetype: "Smartphone",
          devicemodelname: "6T",
          osversion: "OnePlus Nord CE",
          appversion: "Cordova",
          email: "johndoe12@gmail.com",
          firstopened: "20/02/2020",
          lastopened: "13/09/2021",
          phonenumber: "+1 1234567898",
        },
        {
          id: 9,
          firstname: "john",
          lastname: "Doe",
          devicename: "OnePlus 6T",
          devicetype: "Smartphone",
          devicemodelname: "6T",
          osversion: "OnePlus Nord CE",
          appversion: "Cordova",
          email: "johndoe12@gmail.com",
          firstopened: "20/02/2020",
          lastopened: "13/09/2021",
          phonenumber: "+1 1234567898",
        },
        {
          id: 10,
          firstname: "john",
          lastname: "Doe",
          devicename: "OnePlus 6T",
          devicetype: "Smartphone",
          devicemodelname: "6T",
          osversion: "OnePlus Nord CE",
          appversion: "Cordova",
          email: "johndoe12@gmail.com",
          firstopened: "20/02/2020",
          lastopened: "13/09/2021",
          phonenumber: "+1 1234567898",
        },
        {
          id: 11,
          firstname: "john",
          lastname: "Doe",
          devicename: "OnePlus 6T",
          devicetype: "Smartphone",
          devicemodelname: "6T",
          osversion: "OnePlus Nord CE",
          appversion: "Cordova",
          email: "johndoe12@gmail.com",
          firstopened: "20/02/2020",
          lastopened: "13/09/2021",
          phonenumber: "+1 1234567898",
        },
      ],
    };
  }
  edit_userClose = () => {
    this.setState({ search_show: false });
  };

  edit_userShow = (e) => {
    e.preventDefault();
    this.setState({ search_show: true });
  };
  edit_handleShow = (e) => {
    e.preventDefault();
    this.setState({ search_show: true });
  };
  get_order_data = () => { };
  delete_record = (id) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>Are you sure?</h1>
            <p>You want to delete this file?</p>
            <button className="btn red-btn me-2" onClick={onClose}>
              No
            </button>
            <button
              className="btn red-btn"
              onClick={() => {
                this.finaly_delete_record(id);
                onClose();
              }}
            >
              Yes, Delete it!
            </button>
          </div>
        );
      },
    });
  };

  finaly_delete_record = (id) => {
    alert(id);
  };
  handleTableChange = (
    type,
    { page, sizePerPage, filters, sortField, sortOrder }
  ) => {
    switch (type) {
      case "pagination":
        this.setState(
          {
            page,
            sizePerPage,
          },
          () => this.get_order_data()
        );
        break;
      case "filter":
        let search_val = this.state.search_val;
        let newFilter = {};
        if (Object.keys(filters).length) {
          for (const dataField in filters) {
            newFilter[dataField] = filters[dataField].filterVal;
          }
          newFilter = {
            ...search_val,
            ...newFilter,
          };
        } else {
          newFilter = {
            title: "",
            indicator: "",
            definition: "",
          };
        }
        this.setState(
          {
            search_val: newFilter,
          },
          () => this.get_order_data()
        );
        break;
      case "sort":
        this.setState(
          {
            defaultSorted: [
              {
                dataField: sortField,
                order: sortOrder,
              },
            ],
          },
          () => this.get_order_data()
        );
        break;
      default:
        break;
    }
    return true;
  };

  render() {
    let Language =
      this.context.language === "english"
        ? TableFieldEnglish
        : TableFieldArabic;
    let titleLanguage =
      this.context.language === "english" ? titleEnglish : titleArabic;
    let buttonLanguage =
      this.context.language === "english" ? buttonEnglish : buttonArabic;
    const columns = [
      {
        dataField: "id",
        text: Language.userId,
        hidden: false,
      },
      {
        dataField: "firstname",
        text: Language.firstName,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: titleLanguage.search,
        }),
      },
      {
        dataField: "lastname",
        text: Language.lastName,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: titleLanguage.search,
        }),
      },
      {
        dataField: "devicemakename",
        text: Language.deviceName,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: titleLanguage.search,
        }),
      },
      {
        dataField: "devicetype",
        text: Language.deviceType,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: titleLanguage.search,
        }),
      },
      {
        dataField: "devicemodelname",
        text: Language.modelName,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: titleLanguage.search,
        }),
      },
      {
        dataField: "osversion",
        text: Language.osVersion,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: titleLanguage.search,
        }),
      },
      {
        dataField: "appversion",
        text: Language.appVersion,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: titleLanguage.search,
        }),
      },
      {
        dataField: "firstopened",
        text: Language.firstOpen,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: titleLanguage.search,
        }),
      },
      {
        dataField: "lastopened",
        text: Language.lastOpen,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: titleLanguage.search,
        }),
      },
      {
        dataField: "email",
        text: Language.emailAddress,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: titleLanguage.search,
        }),
      },
    ];
    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space align-items-center">
            <div className="col-6 text-left rtl-txt-start">
              <div className="common-header-txt">
                <h3>{titleLanguage.deviceInfo}</h3>
              </div>
            </div>
            <div className="col-6  text-end rtl-txt-end">
              <div className="common-red-btn">
                <a href="#" className="btn red-btn">
                  {buttonLanguage.exportList}
                </a>
              </div>
            </div>
          </div>
          <div className="row common-space">
            <div className="col-md-12">
              <div className="white-box">
                <div className="custom-table">
                  <div className="table-responsive dataTables_wrapper no-footer">
                    {this.state.order_data && (
                      <DataTable
                        keyField="id"
                        loading={this.state.loading}
                        columns={columns}
                        data={this.state.order_data}
                        page={this.state.page}
                        sizePerPage={this.state.sizePerPage}
                        totalSize={this.state.totalSize}
                        defaultSorted={this.state.defaultSorted}
                        onTableChange={this.handleTableChange}
                        language={this.context.language}
                        selectableRows
                      />
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Adminlayout>
    );
  }
}

export default DeviceInformation;
