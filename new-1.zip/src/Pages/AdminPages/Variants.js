import React, { Component, createRef } from "react";
// import { Formik } from "formik";
// import * as Yup from "yup";
// import DragDrop from "../../helper/DragDrop";
import dragimg from "../../images/file-upload.svg";
// import imgprev from "../../images/img-prev.png";
import videoicn from "../../images//video-icn.svg";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import { productArabic, productEnglish } from "../../const";
import LanguageContext from "../../contexts/languageContext";

let ImageFileArray = [];
// let images = [];
// let videos = [];

// const reorder = (list, startIndex, endIndex) => {
//   const result = Array.from(list);
//   const [removed] = result.splice(startIndex, 1);
//   result.splice(endIndex, 0, removed);

//   return result;
// };

const grid = 8;

const getItemStyle = (isDragging, draggableStyle) => ({
  // some basic styles to make the items look a bit nicer
  userSelect: "none",
  padding: grid,

  // change background colour if dragging
  background: isDragging ? "#A81A1C" : "#F7F7F7",

  // styles we need to apply on draggables
  ...draggableStyle,
});

const getListStyle = (isDraggingOver, itemsLength) => ({
  background: isDraggingOver ? "#f7f7f7" : "#fff",
  display: "flex",
  flexWrap: "wrap",
  padding: grid,
  width: itemsLength * 150 + 10,
});

export default class Variants extends Component {
  static contextType = LanguageContext;

  constructor(params) {
    super(params);
    this.state = {
      color: "",
      promotion: "",
      price: "",
      discount: "",
      discountPrice: "",
      Xscount: 0,
      Scount: 0,
      Mcount: 0,
      Lcount: 0,
      Xlcount: 0,
      Xxlcount: 0,
      Xxxlcount: 0,
      items: "",
      videoFiles: "",
    };
    this.runforms = createRef();
  }

  handleImageFile = (e) => {
    let array = Object.values(e.target.files);

    for (let i = 0; i < array.length; i++) {
      let imageObject = {
        src: array[i],
        id: (Math.floor(Math.random() * 1000000) + 1).toString(),
      };

      ImageFileArray.push(imageObject);
      // images.push(URL.createObjectURL(array[i]))
    }
    this.setState({ items: ImageFileArray }, () => {
      if (this.state.items.length > 0) {
        document.getElementById("imageArrayError").style.display = "none";
      }
    });
  };

  removeImage = (id) => {
    const filteredimage = this.state.items.filter((item) => item.id !== id);
    // console.log('filter :: ', filteredimage);
    this.setState({ items: filteredimage }, () => {
      if (this.state.items.length === 0) {
        document.getElementById("imageArrayError").style.display = "block";
      }
    });
  };

  handleVideoFile = (e) => {
    this.setState({ videoFiles: e.target.files[0] }, () => {
      console.log("object", this.state.videoFiles);
    });
  };

  removeVideo = () => {
    this.setState({ videoFiles: "" });
  };

  errorContainer = (form, field) => {
    return form.touched[field] && form.errors[field] ? <span className="error text-danger">{form.errors[field]}</span> : null;
  };

  formAttr = (form, field) => ({
    onBlur: form.handleBlur,
    onChange: form.handleChange,
    value: form.values[field],
  });

  submitPurchasePraposalFormData = (formData, resetForm) => {
    console.log("formdata :: ", formData, resetForm);
  };

  // handleChange = (e) => {
  //     if (e.target.value >= 0) {
  //         this.setState({ [e.target.name]: e.target.value })
  //     }
  // }

  // handleTextChange = (e) => {
  //     this.setState({ [e.target.name]: e.target.value })
  // }

  // handleClear = (itemToClear) => {
  //     this.setState({ [itemToClear]: 0 })
  // }

  render() {
    // let Language = this.context.language === "english" ? TableFieldEnglish : TableFieldArabic;
    // let buttonLanguage = this.context.language === "english" ? buttonEnglish : buttonArabic;
    // let titleLanguage = this.context.language === "english" ? titleEnglish : titleArabic;
    let productLanguage = this.context.language === "english" ? productEnglish : productArabic;
    if (this.props?.formVals) {
      const { formVals, index, setVal, removeElement, clearQuantity } = this.props;
      const inputAttr = (field) => ({
        value: formVals[field],
        onChange: (e) => {
          setVal({ [field]: e.target.value }, index);
        },
      });
      return (
        <div className="row common-space">
          <div className="col-md-12">
            <div className="white-box">
              {index === 0 ? null : (
                <div className="close-btn-white-box">
                  <button className="btn btn-cancel" onClick={() => removeElement(index)}>
                    <i className="bi bi-x-lg"></i>
                  </button>
                </div>
              )}
              <div className="row">
                <div className="col-lg-6 mb-lg-0 mb-3">
                  <div className="row ">
                    <div className="col-md-12">
                      <div className="product-in-title d-flex align-items-center pb-3 custom-border-title">
                        <span>{productLanguage.ProductImage}</span>
                      </div>
                    </div>
                    <div className="col-md-12 mt-3">
                      <div className="upload-file-section-new position-relative">
                        <div className="file-selecter text-center position-relative h-auto">
                          <div className="file-area position-relative py-3">
                            <input type="file" name="productImage" onChange={this.handleImageFile} accept="image/*" multiple />
                            <div className="file-dummy">
                              <div className="file-upload-content mb-3">
                                <img className="file-dummy-image" src={dragimg} alt="" />
                              </div>
                              <span>
                                {productLanguage.DragDrop}
                                <bdi className="d-block">{productLanguage.or}</bdi>
                              </span>
                              <button className="btn red-btn mt-3">{productLanguage.BrowseFiles}</button>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div id="imageArrayError" style={{ display: "none" }} className="input-feedback text-danger">
                        Required
                      </div>
                    </div>
                    <div className="col-md-12">
                      <span>{productLanguage.UploadedImageFile}</span>
                      <div className="img-preview">
                        <ul>
                          {this.state.items.length > 0 && (
                            <DragDropContext onDragEnd={this.onDragEnd}>
                              <Droppable droppableId="droppable" direction="horizontal">
                                {(provided, snapshot) => (
                                  <div ref={provided.innerRef} style={getListStyle(snapshot.isDraggingOver, this.state.items.length)} {...provided.droppableProps}>
                                    {this.state.items.map((item, index) => (
                                      <Draggable key={item.id} draggableId={item.id} index={index}>
                                        {(provided, snapshot) => (
                                          <div ref={provided.innerRef} {...provided.draggableProps} {...provided.dragHandleProps} style={getItemStyle(snapshot.isDragging, provided.draggableProps.style)}>
                                            <li key={index}>
                                              <div className="img-preview-main position-relative">
                                                <img src={URL.createObjectURL(item.src)} alt="" />
                                                <div className="remove-img-btn">
                                                  <i
                                                    onClick={() => {
                                                      this.removeImage(item.id);
                                                    }}
                                                    className="bi bi-x-circle-fill"
                                                  />
                                                </div>
                                              </div>
                                            </li>
                                          </div>
                                        )}
                                      </Draggable>
                                    ))}
                                    {provided.placeholder}
                                  </div>
                                )}
                              </Droppable>
                            </DragDropContext>
                          )}

                          {/* {this.state.imageFiles.length > 0 && this.state.imageFiles.map((item, i) => {
                                                            return (
                                                                <li key={i}>
                                                                    <div className="img-preview-main position-relative">
                                                                        <img src={item} alt="" />
                                                                        <div className="remove-img-btn">
                                                                            <i onClick={() => { this.removeImage(item) }} className="bi bi-x-circle-fill" />
                                                                        </div>
                                                                    </div>
                                                                </li>
                                                            )
                                                        })} */}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-lg-6 mb-lg-0 mb-3">
                  <div className="row">
                    <div className="col-md-12">
                      <div className="product-in-title d-flex align-items-center pb-3 custom-border-title">
                        <span>{productLanguage.VideoOptional}</span>
                      </div>
                    </div>
                    <div className="col-md-12 mt-3">
                      <div className="upload-file-section-new position-relative">
                        <div className="file-selecter text-center position-relative h-auto">
                          <div className="file-area position-relative py-3">
                            <input type="file" name="licence_image_temp" onChange={this.handleVideoFile} accept="video/*" />
                            <div className="file-dummy">
                              <div className="file-upload-content mb-3">
                                <img className="file-dummy-image" src={dragimg} alt="" />
                              </div>
                              <span>
                                {productLanguage.DragDrop}
                                <bdi className="d-block">{productLanguage.or}</bdi>
                              </span>
                              <button className="btn red-btn mt-3">{productLanguage.UploadVideo}</button>
                            </div>
                          </div>
                        </div>
                      </div>
                      <span>{productLanguage.UploadVideoFile}</span>
                    </div>
                    <div className="col-md-12 mt-3">
                      <span>{productLanguage.UploadedVideoFile}</span>
                      <div className="video-preview">
                        <ul>
                          {this.state.videoFiles && (
                            <li className="gray-bg-video d-flex align-items-center my-2">
                              <div className="video-thumb position-relative">
                                {/* <img src="" alt="" /> */}
                                <div className="video-icn-pro">
                                  <img src={videoicn} alt="" />
                                </div>
                              </div>
                              <div className="vide-prev-txt ms-2">
                                <p className="mb-0">{this.state.videoFiles.name}</p>
                                <bdi>{this.state.videoFiles.size}</bdi>
                              </div>
                              <div className="ms-auto pe-2">
                                <i onClick={this.removeVideo} className="bi bi-x-circle-fill"></i>
                              </div>
                            </li>
                          )}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-lg-6 mb-lg-0 mb-3">
                  <div className="form-group col-md-12">
                    <label>{productLanguage.color}</label>
                    <input type="text" className="input-custom-class form-control" name="color" {...inputAttr("color")} placeholder="Black" />
                    <span id={"titleerr_" + index} className="form-text" style={{ color: "red" }}></span>
                  </div>
                  <div className="form-group col-md-12">
                    <label>{productLanguage.promotion}</label>
                    <input type="text" className="input-custom-class form-control" name="promotion" {...inputAttr("promotion")} placeholder="2 for 50" />
                    <span id={"promerr_" + index} className="form-text" style={{ color: "red" }}></span>
                  </div>
                  <div className="form-group col-md-12">
                    <label>{productLanguage.Price}</label>
                    <input type="number" className="input-custom-class form-control" name="price" {...inputAttr("price")} placeholder="$200" />
                    <span id={"priceerr_" + index} className="form-text" style={{ color: "red" }}></span>
                  </div>
                  <div className="form-group col-md-12">
                    <label>{productLanguage.Discount}</label>
                    <input type="number" className="input-custom-class form-control" name="discount" {...inputAttr("discount")} placeholder="10%" />
                    <span id={"discounterr_" + index} className="form-text" style={{ color: "red" }}></span>
                  </div>
                  <div className="form-group col-md-12">
                    <label>{productLanguage.Discount}</label>
                    <input type="number" className="input-custom-class form-control" name="discountPrice" {...inputAttr("discountPrice")} placeholder="$100" />
                    <span id={"discountPriceerr_" + index} className="form-text" style={{ color: "red" }}></span>
                  </div>
                </div>
                <div className="col-lg-6">
                  <div className="row">
                    <div className="col-md-12">
                      <div className="product-in-title">
                        <span>{productEnglish.SelectVariantInfo}</span>
                      </div>
                    </div>

                    <div className="col-md-12 mt-3">
                      <div className="custom-table-product">
                        <div className="table-responsive dataTables_wrapper no-footer">
                          <table className="fixed-table">
                            <thead>
                              <tr>
                                <th>{productLanguage.size}</th>
                                <th>SKU</th>
                                <th className="text-center">{productLanguage.quantity}</th>
                                <th>{productLanguage.action}</th>
                                {/* <th>Sales</th> */}
                              </tr>
                            </thead>
                            <tbody>
                              <tr id="1">
                                <td> XS</td>
                                <td> {this.props.productCode + "AXS"} </td>
                                <td className="text-center">
                                  <input type="number" name="Xscount" {...inputAttr("Xscount")} className="form-control input-custom-class w-auto m-auto" placeholder="1" />
                                </td>
                                <td>
                                  {" "}
                                  <a onClick={() => clearQuantity(index, "Xscount")} className="clear_btn">
                                    clear
                                  </a>
                                </td>
                              </tr>
                              <tr id="2">
                                <td> S</td>
                                <td> {this.props.productCode + "AS"}</td>
                                <td className="text-center">
                                  <input type="number" name="Scount" {...inputAttr("Scount")} className="form-control input-custom-class w-auto m-auto" placeholder="1" />
                                </td>
                                <td>
                                  {" "}
                                  <a onClick={() => clearQuantity(index, "Scount")} className="clear_btn">
                                    clear
                                  </a>{" "}
                                </td>
                              </tr>
                              <tr id="3">
                                <td> M </td>
                                <td> {this.props.productCode + "AM"} </td>
                                <td className="text-center">
                                  <input type="number" name="Mcount" {...inputAttr("Mcount")} className="form-control input-custom-class w-auto m-auto" placeholder="1" />
                                </td>
                                <td>
                                  {" "}
                                  <a onClick={() => clearQuantity(index, "Mcount")} className="clear_btn">
                                    clear
                                  </a>{" "}
                                </td>
                              </tr>
                              <tr id="4">
                                <td> L </td>
                                <td> {this.props.productCode + "AL"} </td>
                                <td className="text-center">
                                  <input type="number" name="Lcount" {...inputAttr("Lcount")} className="form-control input-custom-class w-auto m-auto" placeholder="1" />
                                </td>
                                <td>
                                  {" "}
                                  <a onClick={() => clearQuantity(index, "Lcount")} className="clear_btn">
                                    clear
                                  </a>{" "}
                                </td>
                              </tr>
                              <tr id="5">
                                <td> XL </td>
                                <td> {this.props.productCode + "AXL"} </td>
                                <td className="text-center">
                                  <input type="number" name="Xlcount" {...inputAttr("Xlcount")} className="form-control input-custom-class w-auto m-auto" placeholder="1" />
                                </td>
                                <td>
                                  {" "}
                                  <a onClick={() => clearQuantity(index, "Xlcount")} className="clear_btn">
                                    clear
                                  </a>{" "}
                                </td>
                              </tr>
                              <tr id="6">
                                <td> XXL </td>
                                <td> {this.props.productCode + "AXXL"} </td>
                                <td className="text-center">
                                  <input type="number" name="Xxlcount" {...inputAttr("Xxlcount")} className="form-control input-custom-class w-auto m-auto" placeholder="1" />
                                </td>
                                <td>
                                  {" "}
                                  <a onClick={() => clearQuantity(index, "Xxlcount")} className="clear_btn">
                                    clear
                                  </a>{" "}
                                </td>
                              </tr>
                              <tr id="7">
                                <td> XXXL </td>
                                <td> {this.props.productCode + "AXXXL"}</td>
                                <td className="text-center">
                                  <input type="number" name="Xxxlcount" {...inputAttr("Xxxlcount")} className="form-control input-custom-class w-auto m-auto" placeholder="1" />
                                </td>
                                <td>
                                  {" "}
                                  <a onClick={() => clearQuantity(index, "Xxxlcount")} className="clear_btn">
                                    clear
                                  </a>{" "}
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    } else {
      return null;
    }
  }
}
