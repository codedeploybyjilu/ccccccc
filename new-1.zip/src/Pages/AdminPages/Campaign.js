import React, { Component } from 'react';
import Adminlayout from '../../Components/AdminLayout/Adminlayout';
import SearchIcon from "../../images/search-icon.svg";
import MUITable from "../../Components/MUITable";
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";
import { Dropdown } from 'react-bootstrap';

class Campaign extends Component {

    render() {
        const options = {
            selectableRows: false,
            responsive: "standard",
            searchOpen: false,
            search: false,
            searchAlwaysOpen: false,
            print: false,
            serverSide: true,
            pagination: true,
            rowsPerPageOptions: [50, 100, 300, 500],
        };

        const columns = [
            {
                name: "image",
                label: "Image",
                options: {
                    customBodyRender: (value, tableMeta, updateValue) => {
                        return (
                            <img src='' className='table_logo' loading='lazy' alt='' />
                        );
                    },
                }
            },
            {
                name: "title",
                label: "Title",
            },
            {
                name: "description",
                label: "Description",
            },
            {
                name: "notifications_sent",
                label: "Notifications Sent",
            },
            {
                name: "view_rate",
                label: "View Rate",
            },
            {
                name: "views",
                label: "Views",
            },
            {
                name: "date_time",
                label: "Date & Time",
            },
            {
                name: "status",
                label: "Status",
                options: {
                    customBodyRender: (value, tableMeta, updateValue) => {
                        return (
                            <div className='staus-span-tag-new status-sent'>
                                Sent
                            </div>
                        );
                    },
                }
            },
            {
                name: "action",
                label: "Action",
                options: {
                    customBodyRender: (value, tableMeta, updateValue) => {
                        return (
                            <div>
                                <Dropdown className="cust-drop">
                                    <Dropdown.Toggle className="bg-transparent" id="dropdown-basic" align="end">
                                        <svg width={16} height={16} fill="currentColor" className="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                            <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                        </svg>
                                    </Dropdown.Toggle>
                                    <Dropdown.Menu>
                                        <Dropdown.Item href="/view-campaign-analytics" className='d-flex align-item-center'>
                                            <svg width="19" height="19" fill="currentColor" class="bi bi-eye-fill" viewBox="0 0 16 16">
                                                <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z" />
                                                <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8zm8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z" />
                                            </svg>
                                            <span>View</span>
                                        </Dropdown.Item>
                                        <Dropdown.Item className='d-flex align-item-center'>
                                            <svg width="19" height="19" fill="currentColor" class="bi bi-copy" viewBox="0 0 16 16">
                                                <path fill-rule="evenodd" d="M4 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V2Zm2-1a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H6ZM2 5a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1v-1h1v1a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h1v1H2Z" />
                                            </svg>
                                            <span>Duplicate</span>
                                        </Dropdown.Item>
                                    </Dropdown.Menu>
                                </Dropdown>
                            </div>
                        );
                    },
                }
            },
        ];

        const data = [
            ["", "adas", "adasda", "13", "0.00%", "0", "February 20, 2023 2:07 PM", "", "",],
            ["", "adas", "adasda", "13", "0.00%", "0", "February 20, 2023 2:07 PM", "", "",],
            ["", "adas", "adasda", "13", "0.00%", "0", "February 20, 2023 2:07 PM", "", "",],
            ["", "adas", "adasda", "13", "0.00%", "0", "February 20, 2023 2:07 PM", "", "",],
            ["", "adas", "adasda", "13", "0.00%", "0", "February 20, 2023 2:07 PM", "", "",],
        ];

        const theme = createMuiTheme({
            palette: {
                primary: {
                    light: "#757ce8",
                    main: "#a81a1c",
                    dark: "#002884",
                    contrastText: "#fff",
                },
                secondary: {
                    light: "#ff7961",
                    main: "#f44336",
                    dark: "#ba000d",
                    contrastText: "#000",
                },
            },
        });

        return (
            <Adminlayout>
                <div className="container-fluid">
                    <div className="row common-space">
                        <div className="col-sm-6 text-sm-start text-center rtl-txt-start">
                            <div className="common-header-txt">
                                <h3>Campaigns</h3>
                            </div>
                        </div>
                        <div className="col-sm-6 text-end rtl-txt-end">
                            <a href='/add-campaign' className="btn red-btn ms-3">
                                Create campaign
                            </a>
                        </div>
                    </div>
                    <div className='row common-space'>
                        <div className='col-12'>
                            <div className='white-box'>
                                <div className="custom-table">
                                    <div className=" dataTables_wrapper no-footer">
                                        <MuiThemeProvider theme={theme}>
                                            <div className="right-menu table-over-fix-class ms-auto position-relative">
                                                <MUITable
                                                    columns={columns}
                                                    data={data}
                                                    options={options}
                                                />
                                                <div className="fix-search d-flex align-items-center">
                                                    <div className="position-relative search-sm-screen" id="search-menu">
                                                        <input type="search" name="search" className="form-control top-search ps-5 input-custom-class mb-0" placeholder="" />
                                                        <span className="search-icn position-absolute ms-3">
                                                            <img src={SearchIcon} alt="" />
                                                        </span>
                                                    </div>
                                                    {/* <button className="border-0 bg-transparent dark-red-txt w-100">Clear Filter x</button> */}
                                                </div>
                                            </div>
                                        </MuiThemeProvider>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </Adminlayout>
        );
    }
}

export default Campaign;
