import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import createReactClass from "create-react-class";
import SizeGuideRow from "./sizeGuiderow";
import {
  // APIBaseUrl,
  API_Path,
  // buttonArabic,
  // buttonEnglish,
  // LIVE_FILE_URL,
  sizeGuidelinesArabic,
  sizeGuidelinesEnglish,
  // TableFieldArabic,
  // TableFieldEnglish,
  // titleArabic,
  // titleEnglish,
  productArabic, productEnglish
} from "../../const";
import { PostApi } from "../../helper/APIService";
import LanguageContext from "../../contexts/languageContext";
import toastr from "toastr";
import { withRouter } from "react-router-dom";

let SizeGuidelineData = [];
let HowTOMeasureData = [];

const SizeGuidelineList = createReactClass({
  render: function () {
    if (this.props.variations) {
      // console.log('props :: ', this.props.variations);
      SizeGuidelineData = this.props.variations;
      let interval = setInterval(() => {
        if (this.props.variations.length > 1) {
          clearInterval(interval);
          for (let i = 0; i < this.props.variations.length - 1; i++) {
            if (document.getElementById("plus-" + i)) {
              document.getElementById("plus-" + i).style.display = "none";
            }
          }
        }
      }, 10);
    }
    const guidelineList = this.props.variations.map((val, i) => {
      let elm = React.createElement(SizeGuideRow, {
        formVals: val,
        index: i,
        setVal: (value, ind) => this.props.setVal(value, ind),
        removeElement: (ind) => this.props.removeElement(ind),
        addElement: (ind) => this.props.addElement(ind),
        columns: this.props.columns,
      });
      return <React.Fragment key={i}>{elm}</React.Fragment>;
    });
    return guidelineList;
  },
});

class EditSizeGuideline extends Component {
  static contextType = LanguageContext;

  state = {
    variations: [],
    new_variation: {
      variation_id: 0,
      sizeArabic: "",
      topLength: "",
      shoulder: "",
      length: "",
      bust: "",
      chest: "",
      waist: "",
      hips: "",
      rise: "",
      inseamLength: "",
      outseamLength: "",
      sleeveLength: "",
      armWidth: "",
      skirtLength: "",
      overBust: "",
      underBust: "",
      bottomLength: "",
    },
    size: "",
    sizeArabic: "",
    topLength: "",
    shoulder: "",
    length: "",
    bust: "",
    chest: "",
    waist: "",
    hips: "",
    rise: "",
    inseamLength: "",
    outseamLength: "",
    sleeveLength: "",
    armWidth: "",
    skirtLength: "",
    overBust: "",
    underBust: "",
    bottomLength: "",
    sizeGuideLineImg: "",
    sizeGuideLineImgUrl: "",
    ColumnSelected: false,
    columns: "",
    guideNameEnglish: "",
    guideNameArabic: "",
    sizeGuideNumber: "",
    mainCategory: "",
    category: "",
    subCategory: "",
    maincategoryData: "",
    categoryData: "",
    subCategoryData: "",
    id: "",
    firstAttempt: false,
    howToMeasureData: [],
    checkBoxList: [
      {
        value: "sizeArabic",
        englishName: sizeGuidelinesEnglish.sizeInArabic,
        arabicName: sizeGuidelinesArabic.sizeInArabic,
      },
      {
        value: "topLength",
        englishName: sizeGuidelinesEnglish.topLength,
        arabicName: sizeGuidelinesArabic.topLength,
      },
      {
        value: "shoulder",
        englishName: sizeGuidelinesEnglish.shoulder,
        arabicName: sizeGuidelinesArabic.shoulder,
      },
      {
        value: "length",
        englishName: sizeGuidelinesEnglish.length,
        arabicName: sizeGuidelinesArabic.length,
      },
      {
        value: "bust",
        englishName: sizeGuidelinesEnglish.bust,
        arabicName: sizeGuidelinesArabic.bust,
      },
      {
        value: "chest",
        englishName: sizeGuidelinesEnglish.chest,
        arabicName: sizeGuidelinesArabic.chest,
      },
      {
        value: "waist",
        englishName: sizeGuidelinesEnglish.waist,
        arabicName: sizeGuidelinesArabic.waist,
      },
      {
        value: "hips",
        englishName: sizeGuidelinesEnglish.hips,
        arabicName: sizeGuidelinesArabic.hips,
      },
      {
        value: "rise",
        englishName: sizeGuidelinesEnglish.rise,
        arabicName: sizeGuidelinesArabic.rise,
      },
      {
        value: "inseamLength",
        englishName: sizeGuidelinesEnglish.inseamLength,
        arabicName: sizeGuidelinesArabic.inseamLength,
      },
      {
        value: "outseamLength",
        englishName: sizeGuidelinesEnglish.outseamLength,
        arabicName: sizeGuidelinesArabic.outseamLength,
      },
      {
        value: "sleeveLength",
        englishName: sizeGuidelinesEnglish.sleeveLength,
        arabicName: sizeGuidelinesArabic.sleeveLength,
      },
      {
        value: "armWidth",
        englishName: sizeGuidelinesEnglish.armWidth,
        arabicName: sizeGuidelinesArabic.armWidth,
      },
      {
        value: "skirtLength",
        englishName: sizeGuidelinesEnglish.skirtLength,
        arabicName: sizeGuidelinesArabic.skirtLength,
      },
      {
        value: "overBust",
        englishName: sizeGuidelinesEnglish.overBust,
        arabicName: sizeGuidelinesArabic.overBust,
      },
      {
        value: "underBust",
        englishName: sizeGuidelinesEnglish.underBust,
        arabicName: sizeGuidelinesArabic.underBust,
      },
      {
        value: "bottomLength",
        englishName: sizeGuidelinesEnglish.bottomLength,
        arabicName: sizeGuidelinesArabic.bottomLength,
      },
    ],
  };

  componentDidMount() {
    let url = window.location.href;
    let id = url.substr(url.lastIndexOf("/") + 1);
    this.setState({ id: id });
    this.getSizeGuideline(id);
    this.getHowToMeasureData();
  }

  getSizeGuideline = (id) => {
    let path = API_Path.getSizeGuideLineById;
    let data = { id: id };
    const addSizeGuidePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    addSizeGuidePromise.then((res) => {
      if (res) {
        this.getMainCategoryData();
        this.getCategoryData(res.data.data.main_category);
        this.getSubCategoryData(res.data.data.category);
        this.setState(
          {
            variations: res.data.data.size_guide_data,
            columns: res.data.data.columns,
            guideNameEnglish: res.data.data.size_guide_name_english,
            guideNameArabic: res.data.data.size_guide_name_arabic,
            sizeGuideLineImgUrl: res.data.data.size_guide_img,
            sizeGuideNumber: res.data.data.size_guide_number,
            ColumnSelected: true,
            mainCategory: res.data.data.main_category,
            category: res.data.data.category,
            subCategory: res.data.data.sub_category,
            howToMeasureData: res.data.data.measure !== null ? res.data.data.measure.split(',') : [],
          },
          () => {
            HowTOMeasureData = res.data.data.measure !== null ? res.data.data.measure.split(',') : []
            this.setState({ howToMeasureDataArr: this.state.howToMeasureData })
            for (let i = 0; i < this.state.checkBoxList.length; i++) {
              if (
                this.state.columns.includes(this.state.checkBoxList[i].value)
              ) {
                document
                  .getElementById(this.state.checkBoxList[i].value + "Checkbox")
                  .click();
              }
            }
          }
        );
      }
    });
  };

  getHowToMeasureData = () => {
    let data = {};

    let path = API_Path.gethowtomeasure;
    const getHowToMeasurePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getHowToMeasurePromise.then((res) => {
      if (res) {
        this.setState({ howToMeasureData: res.data.data });
      }
    });
  };

  getMainCategoryData = () => {
    let data = {};

    let path = API_Path.getMainCategory;
    const getMainCategoryPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getMainCategoryPromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data);
        this.setState({ maincategoryData: res.data.data });
      }
    });
  };

  getCategoryData = (val) => {
    if (val) {
      let data = { main_category_id: val };
      let path = API_Path.getCategoryRelative;
      const getCategoryPromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      getCategoryPromise.then((res) => {
        if (res) {
          // console.log('res is :: ', res.data.data);
          this.setState({ categoryData: res.data.data });
        }
      });
    } else {
      let data = {};

      let path = API_Path.getCategory;
      const getCategoryPromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      getCategoryPromise.then((res) => {
        if (res) {
          // console.log('res is :: ', res.data.data);
          this.setState({ categoryData: res.data.data });
        }
      });
    }
  };

  getSubCategoryData = (val) => {
    // console.log(val);
    if (val) {
      let data = { category_id: val };

      let path = API_Path.getSubCategoryRelative;
      const getSubCategoryPromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      getSubCategoryPromise.then((res) => {
        if (res) {
          // console.log('res is :: ', res.data.data);
          this.setState({ subCategoryData: res.data.data });
        }
      });
    } else {
      let data = {};
      let path = API_Path.getSubCategory;
      const getSubCategoryPromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      getSubCategoryPromise.then((res) => {
        if (res) {
          // console.log('res is :: ', res.data.data);
          this.setState({ subCategoryData: res.data.data });
        }
      });
    }
  };

  handleTextBoxChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  handleMeasureChange = (e) => {
    this.setState({ howToMeasure: e.target.value })
    if (!HowTOMeasureData.includes(e.target.value)) {
      console.log(e.target.value)
      HowTOMeasureData.push(e.target.value);
    }
    this.setState({ howToMeasureDataArr: HowTOMeasureData });
  }

  removeMeasure = (id) => {
    let filtered = this.state.howToMeasureDataArr.filter((item, i) => parseInt(item) !== id);
    HowTOMeasureData = filtered;
    this.setState({ howToMeasureDataArr: filtered, howToMeasure: filtered });
  };

  handleTextBoxChange1 = (e) => {
    if (e.target.name === "mainCategory") {
      this.getCategoryData(e.target.value);
    }
    if (e.target.name === "category") {
      this.getSubCategoryData(e.target.value);
    }
  };

  addVariation = () => {
    this.setState({
      variations: [...this.state.variations, this.state.new_variation],
    });
  };

  setVal = (val, index) => {
    let variations = this.state.variations;
    if (typeof variations[index] !== "undefined") {
      variations[index] = {
        ...variations[index],
        ...val,
      };
    }
    this.setState({
      variations: variations,
    });
  };

  removeElement = (index) => {
    let variations = this.state.variations;
    if (variations.length > 1) {
      if (typeof variations[index] !== "undefined") {
        delete variations[index];
      }
      this.setState(
        {
          variations: variations.filter(Boolean),
        },
        () => {
          if (this.state.variations.length > 0) {
            document.getElementById(
              "plus-" + (this.state.variations.length - 1).toString()
            ).style.display = "block";
          }
        }
      );
    }
  };

  handleNumberChange = (e) => {
    if (e.target.value >= 0) {
      this.setState({ [e.target.name]: e.target.value });
    }
  };

  handleChange = (e) => {
    console.log(e.target.name, " :: ", e.target.checked);
    this.setState({ [e.target.name]: e.target.checked });
  };

  handleSubmit = () => {
    let columnArray = ["size"];
    if (this.state.sizeArabic === true) {
      columnArray.push("sizeArabic");
    }
    if (this.state.topLength === true) {
      columnArray.push("topLength");
    }
    if (this.state.shoulder === true) {
      columnArray.push("shoulder");
    }
    if (this.state.length === true) {
      columnArray.push("length");
    }
    if (this.state.bust === true) {
      columnArray.push("bust");
    }
    if (this.state.chest === true) {
      columnArray.push("chest");
    }
    if (this.state.waist === true) {
      columnArray.push("waist");
    }
    if (this.state.hips === true) {
      columnArray.push("hips");
    }
    if (this.state.rise === true) {
      columnArray.push("rise");
    }
    if (this.state.inseamLength === true) {
      columnArray.push("inseamLength");
    }
    if (this.state.outseamLength === true) {
      columnArray.push("outseamLength");
    }
    if (this.state.sleeveLength === true) {
      columnArray.push("sleeveLength");
    }
    if (this.state.armWidth === true) {
      columnArray.push("armWidth");
    }
    if (this.state.skirtLength === true) {
      columnArray.push("skirtLength");
    }
    if (this.state.overBust === true) {
      columnArray.push("overBust");
    }
    if (this.state.underBust === true) {
      columnArray.push("underBust");
    }
    if (this.state.bottomLength === true) {
      columnArray.push("bottomLength");
    }
    let data = {
      variation_id: 0,
    };
    for (let i = 0; i < columnArray.length; i++) {
      let key = columnArray[i];
      data[key] = "";
    }
    console.log("array :: ", columnArray);
    this.setState(
      { columns: columnArray, new_variation: data, ColumnSelected: true },
      () => {
        if (this.state.firstAttempt) {
          this.setState({ firstAttempt: false });
          this.addVariation();
        }
      }
    );
  };

  addsizeGuideLine = (e) => {
    this.setState({ sizeGuideLineImg: Object.values(e.target.files) }, () => {
      this.setState({ isLoading: true });
      this.addsizeGuideLineToStorage(this.state.sizeGuideLineImg);
    });
  };

  addsizeGuideLineToStorage = (files) => {


    // console.log('files is :: ', files);

    var formData = new FormData();
    for (var i = 0; i < files.length; i++) {
      formData.append("file", files[i]);
    }

    let path = API_Path.addFileInS3;
    const addFilePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, formData));
    });

    addFilePromise.then((res) => {
      if (res) {
        // console.log('res is :: ', res.data.data[0]);
        this.setState({ sizeGuideLineImgUrl: res.data.data[0] }, () => {
          this.setState({ isLoading: false });
          // document.getElementById('sizeGuideLineError').style.display = 'none'
        });
      }
    });
  };

  removesizeGuideLine = () => {
    this.setState({ sizeGuideLineImg: "", sizeGuideLineImgUrl: "" });
    document.getElementById("sizeGuideLineInput").value = "";
  };

  handleSave = () => {
    if (this.state.guideNameEnglish === "") {
      toastr.error("Please Enter Guide Name in English");
    } else if (this.state.guideNameArabic === "") {
      toastr.error("Please Enter Guide Name in Arabic");
    } else if (this.state.sizeGuideNumber === "") {
      toastr.error("Please Enter Guide Number");
    } else if (this.state.mainCategory === "") {
      toastr.error("Please Select Main Category");
    } else if (this.state.category === "") {
      toastr.error("Please Select  Category");
    } else if (this.state.subCategory === "") {
      toastr.error("Please Select Sub Category");
    } else if (this.state.columns === "") {
      toastr.error("Please Select Columns");
    } else if (this.state.howToMeasureDataArr === ['']) {
      toastr.error("Please Select measure");
    } else if (SizeGuidelineData === []) {
      toastr.error("Please add size guide data");
    } else if (this.state.sizeGuideLineImgUrl === "") {
      toastr.error("Please Enter guide image");
    } else {
      let data = {
        size_guide_name_english: this.state.guideNameEnglish,
        size_guide_name_arabic: this.state.guideNameArabic,
        size_guide_number: this.state.sizeGuideNumber,
        main_category: this.state.mainCategory,
        category: this.state.category,
        sub_category: this.state.subCategory,
        columns: this.state.columns,
        size_guide_data: SizeGuidelineData,
        size_guide_img: this.state.sizeGuideLineImgUrl,
        new_variation: this.state.new_variation,
        id: this.state.id,
        measure: this.state.howToMeasureDataArr,
      };
      // console.log('data is :: ', data);
      let path = API_Path.addSizeGuideLine;
      const addSizeGuidePromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      addSizeGuidePromise.then((res) => {
        if (res) {
          if (res.data.success) {
            this.clearState();
            this.props.history.push("/sizeguideline")
            // window.location.href = "sizeguideline";
            this.setState({ howToMeasureDataArr: [], howToMeasureData: [] })
            HowTOMeasureData = []
            toastr.success(res.data.message);
          } else {
            toastr.error(res.data.message)
          }
        }
      });
    }
  };

  clearState = () => {
    this.setState({
      variations: [],
      new_variation: {
        variation_id: 0,
        sizeArabic: "",
        topLength: "",
        shoulder: "",
        length: "",
        bust: "",
        chest: "",
        waist: "",
        hips: "",
        rise: "",
        inseamLength: "",
        outseamLength: "",
        sleeveLength: "",
        armWidth: "",
        skirtLength: "",
        overBust: "",
        underBust: "",
        bottomLength: "",
      },
      sizeGuideLineImg: "",
      sizeGuideLineImgUrl: "",
      ColumnSelected: false,
      columns: "",
      guideNameEnglish: "",
      guideNameArabic: "",
      mainCategory: "",
      category: "",
      subCategory: "",
      maincategoryData: "",
      categoryData: "",
      subCategoryData: "",
    });
  };

  render() {
    let sizeGuidelinesLanguage =
      this.context.language === "english"
        ? sizeGuidelinesEnglish
        : sizeGuidelinesArabic;
    let productLanguage = this.context.language === "english" ? productEnglish : productArabic;
    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space align-items-center">
            <div className="col-12 text-md-start text-center rtl-txt-start">
              <div className="common-header-txt">
                <h3>
                  {this.context.language === "english"
                    ? sizeGuidelinesEnglish.addSizeGuideline
                    : sizeGuidelinesArabic.addSizeGuideline}
                </h3>
              </div>
            </div>
            <div className="col-md-12 pt-4">
              <div className="white-box">
                <form className="row border-bottom">
                  <div className="form-group col-md-4 mb-3">
                    <label>
                      {this.context.language === "english"
                        ? sizeGuidelinesEnglish.guideNameInEnglish
                        : sizeGuidelinesArabic.guideNameInEnglish}
                    </label>
                    <input
                      type="text"
                      onChange={this.handleTextBoxChange}
                      value={this.state.guideNameEnglish}
                      name="guideNameEnglish"
                      className="form-control input-custom-class me-2"
                      placeholder={sizeGuidelinesLanguage.sizeGuideNameInEnglish}
                    />
                  </div>
                  <div className="form-group col-md-4 mb-3">
                    <label>
                      {this.context.language === "english"
                        ? sizeGuidelinesEnglish.guideNameInArabic
                        : sizeGuidelinesArabic.guideNameInArabic}
                    </label>
                    <input
                      type="text"
                      onChange={this.handleTextBoxChange}
                      value={this.state.guideNameArabic}
                      name="guideNameArabic"
                      className="form-control input-custom-class me-2"
                      placeholder={sizeGuidelinesLanguage.sizeGuideNameInArabic}
                    />
                  </div>
                  <div className="form-group col-md-4 mb-3">
                    <label>
                      {this.context.language === "english"
                        ? sizeGuidelinesEnglish.guideName
                        : sizeGuidelinesArabic.guideName}
                    </label>
                    <input
                      type="text"
                      onChange={this.handleTextBoxChange}
                      value={this.state.sizeGuideNumber}
                      name="sizeGuideNumber"
                      className="form-control input-custom-class me-2"
                      placeholder={sizeGuidelinesLanguage.sizeGuideNumber}
                    />
                  </div>
                  <div className="row">
                    <div className="col-md-4 form-group">
                      <label>
                        {this.context.language === "english"
                          ? sizeGuidelinesEnglish.mainCategory
                          : sizeGuidelinesArabic.mainCategory}
                      </label>
                      <select
                        name="mainCategory"
                        value={this.state.mainCategory}
                        onChange={this.handleTextBoxChange}
                        onChangeCapture={this.handleTextBoxChange1}
                        className="form-select input-custom-class"
                      >
                        <option>{productLanguage.SelectSubCategory}</option>
                        {this.state.maincategoryData &&
                          this.state.maincategoryData.length > 0 &&
                          this.state.maincategoryData.map((item, i) => {
                            return (
                              <>
                                {this.state.mainCategory === item.id && (
                                  <option value={item.id} selected key={i}>
                                    {item.english} | {item.arabic}
                                  </option>
                                )}
                                {this.state.mainCategory !== item.id && (
                                  <option value={item.id} key={i}>
                                    {item.english} | {item.arabic}
                                  </option>
                                )}
                              </>
                            );
                          })}
                      </select>
                    </div>
                    <div className="col-md-4 form-group">
                      <label>
                        {this.context.language === "english"
                          ? sizeGuidelinesEnglish.category
                          : sizeGuidelinesArabic.category}
                      </label>
                      <select
                        name="category"
                        value={this.state.category}
                        onChange={this.handleTextBoxChange}
                        onChangeCapture={this.handleTextBoxChange1}
                        className="form-select input-custom-class"
                      >
                        <option>{sizeGuidelinesLanguage.category}</option>
                        {this.state.categoryData &&
                          this.state.categoryData.length > 0 &&
                          this.state.categoryData.map((item, i) => {
                            return (
                              <>
                                {this.state.category === item.id && (
                                  <option value={item.id} selected key={i}>
                                    {item.english} | {item.arabic}
                                  </option>
                                )}
                                {this.state.category !== item.id && (
                                  <option value={item.id} key={i}>
                                    {item.english} | {item.arabic}
                                  </option>
                                )}
                              </>
                            );
                          })}
                      </select>
                    </div>
                    <div className="col-md-4 form-group">
                      <label>
                        {this.context.language === "english"
                          ? sizeGuidelinesEnglish.subCategory
                          : sizeGuidelinesArabic.subCategory}
                      </label>
                      <select
                        name="subCategory"
                        value={this.state.subCategory}
                        onChange={this.handleTextBoxChange}
                        className="form-select input-custom-class"
                      >
                        <option>{sizeGuidelinesLanguage.subCategory}</option>
                        {this.state.subCategoryData &&
                          this.state.subCategoryData.length > 0 &&
                          this.state.subCategoryData.map((item, i) => {
                            return (
                              <>
                                {this.state.subCategory === item.id && (
                                  <option value={item.id} selected key={i}>
                                    {item.english} | {item.arabic}
                                  </option>
                                )}
                                {this.state.subCategory !== item.id && (
                                  <option value={item.id} key={i}>
                                    {item.english} | {item.arabic}
                                  </option>
                                )}
                              </>
                            );
                          })}
                      </select>
                    </div>
                  </div>
                </form>

                <div className="row my-3 border-bottom pb-3">
                  <div className="col-md-12 add-size-label mb-3 ">
                    <div className="row m-0">
                      {this.state.checkBoxList.map((item, i) => {
                        return (
                          <label
                            key={i}
                            className="cust-chk-bx col-xl-2 m-0 col-6"
                          >
                            <input
                              id={item.value + "Checkbox"}
                              name={item.value}
                              onChange={this.handleChange}
                              type="checkbox"
                            />
                            <span className="cust-chkmark"></span>
                            <bdi>
                              {this.context.language === "english"
                                ? item.englishName
                                : item.arabicName}
                            </bdi>
                          </label>
                        );
                      })}
                    </div>
                  </div>
                  <div className="col-md-12 text-center">
                    <button className="btn red-btn" onClick={this.handleSubmit}>
                      {this.context.language === "english"
                        ? sizeGuidelinesEnglish.save
                        : sizeGuidelinesArabic.save}
                    </button>
                  </div>
                </div>

                {this.state.ColumnSelected && (
                  <div className="row mt-3">
                    {" "}
                    <div className="col-md-9 mx-auto border py-2">
                      <div className="table-responsive cust-table-size">
                        <table>
                          <tr>
                            {this.state.columns.includes("size") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>Size</label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("sizeArabic") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>
                                    {this.context.language === "english"
                                      ? sizeGuidelinesEnglish.sizeInArabic
                                      : sizeGuidelinesArabic.sizeInArabic}
                                  </label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("topLength") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>
                                    {this.context.language === "english"
                                      ? sizeGuidelinesEnglish.topLength
                                      : sizeGuidelinesArabic.topLength}
                                  </label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("shoulder") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>
                                    {this.context.language === "english"
                                      ? sizeGuidelinesEnglish.shoulder
                                      : sizeGuidelinesArabic.shoulder}
                                  </label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("length") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>
                                    {this.context.language === "english"
                                      ? sizeGuidelinesEnglish.length
                                      : sizeGuidelinesArabic.length}
                                  </label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("bust") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>
                                    {this.context.language === "english"
                                      ? sizeGuidelinesEnglish.bust
                                      : sizeGuidelinesArabic.bust}
                                  </label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("chest") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>
                                    {this.context.language === "english"
                                      ? sizeGuidelinesEnglish.chest
                                      : sizeGuidelinesArabic.chest}
                                  </label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("waist") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>
                                    {this.context.language === "english"
                                      ? sizeGuidelinesEnglish.waist
                                      : sizeGuidelinesArabic.waist}
                                  </label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("hips") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>
                                    {this.context.language === "english"
                                      ? sizeGuidelinesEnglish.hips
                                      : sizeGuidelinesArabic.hips}
                                  </label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("rise") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>
                                    {this.context.language === "english"
                                      ? sizeGuidelinesEnglish.rise
                                      : sizeGuidelinesArabic.rise}
                                  </label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("inseamLength") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>
                                    {this.context.language === "english"
                                      ? sizeGuidelinesEnglish.inseamLength
                                      : sizeGuidelinesArabic.inseamLength}{" "}
                                  </label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("outseamLength") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>
                                    {this.context.language === "english"
                                      ? sizeGuidelinesEnglish.outseamLength
                                      : sizeGuidelinesArabic.outseamLength}
                                  </label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("sleeveLength") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>
                                    {this.context.language === "english"
                                      ? sizeGuidelinesEnglish.sleeveLength
                                      : sizeGuidelinesArabic.sleeveLength}
                                  </label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("armWidth") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>
                                    {this.context.language === "english"
                                      ? sizeGuidelinesEnglish.armWidth
                                      : sizeGuidelinesArabic.armWidth}
                                  </label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("skirtLength") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>
                                    {this.context.language === "english"
                                      ? sizeGuidelinesEnglish.skirtLength
                                      : sizeGuidelinesArabic.skirtLength}{" "}
                                  </label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("overBust") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>
                                    {this.context.language === "english"
                                      ? sizeGuidelinesEnglish.overBust
                                      : sizeGuidelinesArabic.overBust}{" "}
                                  </label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("underBust") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>
                                    {this.context.language === "english"
                                      ? sizeGuidelinesEnglish.underBust
                                      : sizeGuidelinesArabic.underBust}{" "}
                                  </label>
                                </div>
                              </td>
                            )}
                            {this.state.columns.includes("bottomLength") && (
                              <td className="">
                                <div className="d-flex align-items-center">
                                  <label>
                                    {this.context.language === "english"
                                      ? sizeGuidelinesEnglish.bottomLength
                                      : sizeGuidelinesArabic.bottomLength}{" "}
                                  </label>
                                </div>
                              </td>
                            )}
                          </tr>
                          <SizeGuidelineList
                            variations={this.state.variations}
                            removeElement={(i) => this.removeElement(i)}
                            addElement={(i) => this.addVariation(i)}
                            columns={this.state.columns}
                            setVal={(val, ind) => this.setVal(val, ind)}
                          />
                        </table>
                      </div>
                    </div>
                  </div>
                )}
                <div className="row mt-3">
                  <div className="col-md-6">
                    <div className="form-group ">
                      <label>
                        {" "}
                        {this.context.language === "english"
                          ? sizeGuidelinesEnglish.addSizeGuideline
                          : sizeGuidelinesArabic.addSizeGuideline}
                      </label>
                      <div className="d-flex flex-wrap">
                        <div className="upload-btn-wrapper mb-3">
                          <span className="btn">
                            {this.context.language === "english"
                              ? sizeGuidelinesEnglish.uploadAFile
                              : sizeGuidelinesArabic.uploadAFile}
                          </span>
                          <input
                            onChange={this.addsizeGuideLine}
                            type="file"
                            accept="image/*"
                            id="sizeGuideLineInput"
                            name="sizeGuideLineImg"
                          />
                        </div>
                        {this.state.sizeGuideLineImgUrl !== "" && (
                          <div className="img-preview ps-3 wdth-click-main">
                            <ul className="justify-content-center">
                              <div className="img-bdr-main">
                                <div className="img-bdr-main-inr">
                                  <li>
                                    <div className="img-preview-main position-relative">
                                      <img
                                        src={

                                          this.state.sizeGuideLineImgUrl
                                        }
                                        alt=""
                                      />
                                      <div
                                        onClick={this.removesizeGuideLine}
                                        className="remove-img-btn"
                                      >
                                        <i className="bi bi-x-circle-fill"></i>
                                      </div>
                                    </div>
                                  </li>
                                </div>
                              </div>
                            </ul>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="col-md-6 form-group">
                    <label>{sizeGuidelinesLanguage.Howtomeasure}</label>
                    <select name="howToMeasure" value={this.state.howToMeasure} onChange={this.handleMeasureChange} className="form-select input-custom-class">
                      <option value="">{sizeGuidelinesLanguage.SelectHowToMeasure}</option>
                      {this.state.howToMeasureData &&
                        this.state.howToMeasureData.length > 0 &&
                        this.state.howToMeasureData.map((item, i) => {
                          return (
                            <option value={item.id} key={i}>
                              {this.context.language === "english" ? item.title_en : item.title_ar}
                            </option>
                          );
                        })}
                    </select>
                    <div className="cust-tag-div d-flex">
                      {this.state.howToMeasureDataArr &&
                        this.state.howToMeasureDataArr.map((item, i) => {
                          let filtered = this.state.howToMeasureData.filter((l) => parseInt(item) === l.id);
                          return (
                            <ul key={i}>
                              {filtered &&
                                filtered.map((m, index) => {
                                  return (
                                    <li key={index}>
                                      <span>{m.title_en}</span>
                                      <mark onClick={() => this.removeMeasure(m.id)} className=" bg-transparent bi bi-x p-0"></mark>
                                    </li>
                                  );
                                })}
                            </ul>
                          );
                        })}
                    </div>
                  </div>
                </div>
                <div className="col-md-12 text-center mt-5">
                  <button onClick={this.handleSave} className="red-btn">
                    {this.context.language === "english"
                      ? sizeGuidelinesEnglish.save
                      : sizeGuidelinesArabic.save}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Adminlayout>
    );
  }
}

export default withRouter(EditSizeGuideline);
