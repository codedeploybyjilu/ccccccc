import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import { Dropdown, Modal } from "react-bootstrap";
import LanguageContext from "../../contexts/languageContext";
import DataTable from "../../Components/DataTable";
import { textFilter } from "react-bootstrap-table2-filter";
import {
  APIBaseUrl,
  API_Path,
  buttonArabic,
  buttonEnglish,
  teamArabic,
  teamEnglish,
  TableFieldArabic,
  TableFieldEnglish,
  titleArabic,
  titleEnglish,
  LIVE_FILE_URL,
} from "../../const";
import { confirmAlert } from "react-confirm-alert";
import teamimg from "../../images/team-img.png";
import { PostApi } from "../../helper/APIService";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import toastr, { clear } from "toastr";
let selectedModules = [];

class Team extends Component {
  static contextType = LanguageContext;

  constructor(props) {
    super(props);
    this.state = {
      edit_role_modal_show: false,
      add_edit_modal_show: false,
      editedMemberId: "",
      profileImage: "",
      profileImageUrl: "",
      role_name_english: "",
      role_name_arabic: "",
      products: "",
      addProducts: "",
      viewProducts: "",
      deleteProducts: "",
      cloneProducts: "",
      editProducts: "",
      addCategory: "",
      viewEditCategory: "",
      editSizeGuideLine: "",
      orders: "",
      marketing: "",
      settings: "",
      teamUser: "",
      reports: "",
      viewOrders: "",
      editOrders: "",
      pendingOrdersTab: "",
      readyToShipOrders: "",
      shippedOrders: "",
      deliveredOrders: "",
      cancelledOrders: "",
      archivedOrders: "",
      memberName: "",
      memberFirstName: "",
      memberLastName: "",
      memberEmail: "",
      memberNumber: "",
      roleSelect: "",
      memberPassword: "",
      modalType: "add",
      roleModalType: "add",
      permissionsList: [],
      productsArray: [
        {
          englishName: teamEnglish.addProducts,
          arabicName: teamArabic.addProducts,
          value: "1",
        },

        {
          value: "2",
          englishName: teamEnglish.viewProducts,
          arabicName: teamArabic.viewProducts,
        },
        {
          value: "3",
          englishName: teamEnglish.deleteProducts,
          arabicName: teamArabic.deleteProducts,
        },
        {
          value: "4",
          englishName: teamEnglish.cloneProducts,
          arabicName: teamArabic.cloneProducts,
        },
        {
          value: "5",
          englishName: teamEnglish.editProducts,
          arabicName: teamArabic.editProducts,
        },
        {
          value: "6",
          englishName: teamEnglish.addCategory,
          arabicName: teamArabic.addCategory,
        },
        {
          value: "7",
          englishName: teamEnglish.viewEditCategory,
          arabicName: teamArabic.viewEditCategory,
        },
        {
          value: "8",
          englishName: teamEnglish.editSizeGuideline,
          arabicName: teamArabic.editSizeGuideline,
        },
        {
          value: "9",
          englishName: teamEnglish.editInventory,
          arabicName: teamArabic.editInventory,
        },
      ],
      ordersArray: [
        {
          englishName: teamEnglish.viewOrders,
          arabicName: teamArabic.viewOrders,

          value: "10",
        },
        {
          englishName: teamEnglish.editOrders,
          arabicName: teamArabic.editOrders,

          value: "11",
        },
        {
          englishName: teamEnglish.pendingOrdersTab,
          arabicName: teamArabic.pendingOrdersTab,

          value: "12",
        },
        {
          englishName: teamEnglish.readyToShipOrders,
          arabicName: teamArabic.readyToShipOrders,

          value: "13",
        },
        {
          englishName: teamEnglish.shippedOrders,
          arabicName: teamArabic.shippedOrders,

          value: "14",
        },
        {
          englishName: teamEnglish.deliveredOredrs,
          arabicName: teamArabic.deliveredOredrs,

          value: "15",
        },
        {
          englishName: teamEnglish.cancelledOrders,
          arabicName: teamArabic.cancelledOrders,

          value: "16",
        },
        {
          englishName: teamEnglish.archivedOrders,
          arabicName: teamArabic.archivedOrders,
          value: "17",
        },
        {
          englishName: teamEnglish.manageRefunds,
          arabicName: teamArabic.manageRefunds,
          value: "18",
        },
        {
          englishName: teamEnglish.manageReturns,
          arabicName: teamArabic.manageReturns,
          value: "19",
        },
        {
          englishName: teamEnglish.createShipLable,
          arabicName: teamArabic.createShipLable,
          value: "20",
        },
      ],
      MarketingArray: [
        {
          englishName: teamEnglish.masterPage,
          arabicName: teamArabic.masterPage,
          value: "21",
        },
        {
          englishName: teamEnglish.coupons,
          arabicName: teamArabic.coupons,
          value: "22",
        },
        {
          englishName: teamEnglish.promotions,
          arabicName: teamArabic.promotions,
          value: "23",
        },
        {
          englishName: teamEnglish.notification,
          arabicName: teamArabic.notification,
          value: "24",
        },
        {
          englishName: teamEnglish.SMSWhatsapp,
          arabicName: teamArabic.SMSWhatsapp,
          value: "25",
        },
        {
          englishName: teamEnglish.AbandonedCarts,
          arabicName: teamArabic.AbandonedCarts,
          value: "26",
        },
        {
          englishName: teamEnglish.EmailMarketing,
          arabicName: teamArabic.EmailMarketing,
          value: "27",
        },
        {
          englishName: teamEnglish.SMSMarketing,
          arabicName: teamArabic.SMSMarketing,
          value: "28",
        },
      ],
      SettingsArray: [
        {
          englishName: teamEnglish.Notification,
          arabicName: teamArabic.Notification,
          value: "29",
        },
        {
          englishName: teamEnglish.SMSGateway,
          arabicName: teamArabic.SMSGateway,
          value: "30",
        },
        {
          englishName: teamEnglish.Whatsapp,
          arabicName: teamArabic.Whatsapp,
          value: "31",
        },
        {
          englishName: teamEnglish.TaxManagement,
          arabicName: teamArabic.TaxManagement,
          value: "32",
        },
        {
          englishName: teamEnglish.CODShioppingCharges,
          arabicName: teamArabic.CODShioppingCharges,
          value: "33",
        },
        {
          englishName: teamEnglish.PolicyPages,
          arabicName: teamArabic.PolicyPages,
          value: "34",
        },
        {
          englishName: teamEnglish.Logo,
          arabicName: teamArabic.Logo,
          value: "35",
        },
        {
          englishName: teamEnglish.Careers,
          arabicName: teamArabic.Careers,
          value: "36",
        },
      ],
      teamUserArray: [
        {
          englishName: teamEnglish.AddTeamMembers,
          arabicName: teamArabic.AddTeamMembers,
          value: "37",
        },
        {
          englishName: teamEnglish.EditTeam,
          arabicName: teamArabic.EditTeam,
          value: "38",
        },
        {
          englishName: teamEnglish.DeleteTeamMember,
          arabicName: teamArabic.DeleteTeamMember,
          value: "39",
        },
        {
          englishName: teamEnglish.ViewUsers,
          arabicName: teamArabic.ViewUsers,
          value: "40",
        },
        {
          englishName: teamEnglish.sizeInArabic,
          arabicName: teamArabic.sizeInArabic,
          value: "41",
        },
        {
          englishName: teamEnglish.BlockUsers,
          arabicName: teamArabic.BlockUsers,
          value: "42",
        },
        {
          englishName: teamEnglish.DownloadUsers,
          arabicName: teamArabic.DownloadUsers,
          value: "43",
        },
        {
          englishName: teamEnglish.DeleteUsers,
          arabicName: teamArabic.DeleteUsers,
          value: "44",
        },
      ],
      ReportsArray: [
        {
          englishName: teamEnglish.ProductReports,
          arabicName: teamArabic.ProductReports,
          value: "45",
        },
        {
          englishName: teamEnglish.DeliveryReports,
          arabicName: teamArabic.DeliveryReports,
          value: "46",
        },
        {
          englishName: teamEnglish.ReturnReports,
          arabicName: teamArabic.ReturnReports,
          value: "47",
        },
        {
          englishName: teamEnglish.MarketingReports,
          arabicName: teamArabic.MarketingReports,
          value: "48",
        },
        {
          englishName: teamEnglish.UsersReports,
          arabicName: teamArabic.UsersReports,
          value: "49",
        },
        {
          englishName: teamEnglish.Refunds,
          arabicName: teamArabic.Refunds,
          value: "50",
        },
        {
          englishName: teamEnglish.Reviews,
          arabicName: teamArabic.Reviews,
          value: "51",
        },
        {
          englishName: teamEnglish.Analytics,
          arabicName: teamArabic.Analytics,
          value: "52",
        },
      ],
      deleteTeamRole: false,
      roleData: [],
      activeRoleData: [],
      page: 1,
      sizePerPage: 10,
      totalSize: 0,
      defaultSorted: [
        {
          dataField: "id",
          order: "asc",
        },
      ],

      order_data: [],
      selectedRoleData: {},

      showPermissionModal: false
    };
  }

  componentDidMount() {
    this.getMember();
    this.getRole();
    this.getActiveRole();
  }

  handleAddPermissionClick = () => {
    this.setState({ showPermissionModal: true, roleModalType: "add" });
  };
  edit_role_handleShow = () => {
    this.setState({ edit_role_modal_show: true, roleModalType: "add" });
  };

  edit_role_handleClose = () => {
    this.setState({
      edit_role_modal_show: false,
      selectedRoleData: {},
      role_name_english: "",
      role_name_arabic: "",
    });
    selectedModules = [];
  };

  add_edit_handleShow = () => {
    this.setState({ add_edit_modal_show: true, modalType: "add" });
  };

  add_edit_handleClose = () => {
    this.setState({ add_edit_modal_show: false }, () => {
      // this.clearState();
    });
  };

  add_edit_handleOnClose = () => {
    this.add_edit_handleClose();
    this.clearState();
  };

  clearState = () => {
    this.setState({
      memberName: "",
      memberEmail: "",
      memberNumber: "",
      roleSelect: "",
      profileImageUrl: "",
    });
  };

  get_order_data = () => {};

  handleTableChange = (
    type,
    { page, sizePerPage, filters, sortField, sortOrder }
  ) => {
    switch (type) {
      case "pagination":
        this.setState(
          {
            page,
            sizePerPage,
          },
          () => this.get_order_data()
        );
        break;
      case "filter":
        let search_val = this.state.search_val;
        let newFilter = {};
        if (Object.keys(filters).length) {
          for (const dataField in filters) {
            newFilter[dataField] = filters[dataField].filterVal;
          }
          newFilter = {
            ...search_val,
            ...newFilter,
          };
        } else {
          newFilter = {
            title: "",
            indicator: "",
            definition: "",
          };
        }
        this.setState(
          {
            search_val: newFilter,
          },
          () => this.get_order_data()
        );
        break;
      case "sort":
        this.setState(
          {
            defaultSorted: [
              {
                dataField: sortField,
                order: sortOrder,
              },
            ],
          },
          () => this.get_order_data()
        );
        break;
      default:
        break;
    }
    return true;
  };

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  handlePhoneChange = (value) => {
    this.setState({ memberNumber: value });
  };

  handleAllChecked = (e) => {
    this.setState((prevState) => ({
      selectedRoleData: {
        ...prevState.selectedRoleData,
        permissions: !e.target.checked
          ? []
          : prevState.permissionsList.reduce((acc, item) => {
              console.log(acc);
              const subModuleIds = item.sub_module.map(({ id }) =>
                id.toString()
              );
              return [...acc, ...subModuleIds];
            }, []),
      },
    }));
  };

  handleCheckBox = (e, { module_id, sub_module_id }) => {
    if (sub_module_id) {
      this.setState((prevState) => ({
        selectedRoleData: {
          ...prevState.selectedRoleData,
          permissions: !e.target.checked
            ? prevState.selectedRoleData.permissions.filter(
                (id) => id != sub_module_id
              )
            : [
                ...prevState.selectedRoleData.permissions,
                sub_module_id.toString(),
              ],
        },
      }));
    }
    if (module_id) {
      this.setState((prevState) => {
        const subModuleIds = prevState.permissionsList
          .find(({ id }) => id == module_id)
          .sub_module.map(({ id }) => id.toString());

        return {
          selectedRoleData: {
            ...prevState.selectedRoleData,
            permissions: !e.target.checked
              ? prevState.selectedRoleData.permissions.filter(
                  (id) => !subModuleIds.includes(id)
                )
              : [...prevState.selectedRoleData.permissions, ...subModuleIds],
          },
        };
      });
    }
  };

  handleSavePermission = () => {
    let data = {
      role_english: this.state.role_name_english,
      role_arabic: this.state.role_name_arabic,
      permissions: selectedModules,
    };

    let path = API_Path.addRole;
    const addRolePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    addRolePromise.then((res) => {
      if (res) {
        toastr.success(res.data.message);
        this.getRole();
        this.getActiveRole();
        this.edit_role_handleClose();
      }
    });
  };

  handleEditPermission = () => {
    let data = {
      role_english: this.state.role_name_english,
      role_arabic: this.state.role_name_arabic,
      permissions: this.state.selectedRoleData.permissions.sort(
        (a, b) => a - b
      ),
      id: this.state.selectedRoleData.id,
    };

    let path = API_Path.editRole;
    const editRolePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    editRolePromise.then((res) => {
      if (res) {
        toastr.success(res.data.message);
        this.edit_role_handleClose();
        this.getRole();
        this.getActiveRole();
      }
    });
  };

  removeThumbnailImages = () => {
    this.setState({ profileImageUrl: "" });
  };

  addProfile = (e) => {
    this.setState({ profileImage: Object.values(e.target.files) }, () => {
      this.setState({ isLoading: true });
      this.addProfileToStorage(this.state.profileImage);
    });
  };

  addProfileToStorage = (files) => {
    var formData = new FormData();
    for (var i = 0; i < files.length; i++) {
      formData.append("file", files[i]);
    }

    let path = API_Path.addFileInS3;
    const addFilePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, formData));
    });

    addFilePromise.then((res) => {
      if (res) {
        this.setState({ profileImageUrl: res.data.data[0] }, () => {
          this.setState({ isLoading: false });
        });
      }
    });
  };

  handleSave = () => {
    let data = {
      first_name: this.state.memberFirstName,
      last_name: this.state.memberLastName,
      password: this.state.memberPassword,
      email: this.state.memberEmail,
      phone: this.state.memberNumber,
      user_role: this.state.roleSelect,
      image: this.state.profileImageUrl,
    };
    let path = API_Path.addMember;
    const addMemberPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    addMemberPromise.then((res) => {
      if (res) {
        this.add_edit_handleClose();
        this.getMember();
        this.clearState();
        toastr.success(res.data.message);
      }
    });
  };

  getMember = () => {
    let data = {};
    let path = API_Path.getMember;
    const getMemberPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getMemberPromise.then((res) => {
      if (res) {
        if (res.data.success) {
          this.setState({
            order_data: res.data.data,
            totalSize: res.data.data.length,
          });
        }
      }
    });
  };

  getRole = () => {
    let data = {
      status: "",
    };
    let path = API_Path.getRole;
    const getRolePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getRolePromise.then((res) => {
      if (res) {
        if (res.data.success) {
          this.setState({ roleData: res.data.data });
        }
      }
    });
  };
  getActiveRole = () => {
    let data = {
      status: "active",
    };
    let path = API_Path.getRole;
    const getActiveRolePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getActiveRolePromise.then((res) => {
      if (res) {
        if (res.data.success) {
          this.setState({ activeRoleData: res.data.data });
        }
      }
    });
  };

  getRoleById = (id) => {
    let data = {
      id: id,
    };
    let path = API_Path.getRoleById;
    const getRoleByIdPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getRoleByIdPromise.then((res) => {
      if (res) {
        this.setState(
          {
            selectedRoleData: res.data.data,
            role_name_english: res.data.data.english,
            role_name_arabic: res.data.data.arabic,
          },
          () => {
            selectedModules = this.state.selectedRoleData.permissions;
            this.setState({
              edit_role_modal_show: true,
              roleModalType: "edit",
            });
          }
        );
      }
    });
  };

  deleteTeamRole = (id) => {
    this.setState({ deleteTeamRole: true, id: id });
  };

  deleteTeamRoleClose = () => {
    this.setState({ deleteTeamRole: false });
  };

  handleDeleteTeamRole = () => {
    let data = {
      id: this.state.id,
    };
    let path = API_Path.deleteRole;
    const deleteRolePromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    deleteRolePromise.then((res) => {
      if (res) {
        toastr.success(res.data.message);
        this.getRole();
        this.getActiveRole();
        this.deleteTeamRoleClose();
      }
    });
  };

  cloneRole = (id) => {
    let data = {
      id: id,
    };
    let path = API_Path.cloneRole;
    const cloneMemberPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    cloneMemberPromise.then((res) => {
      if (res) {
        this.getRole();
      }
    });
  };

  getMemberById = (id) => {
    this.setState({ editedMemberId: id });
    let data = {
      id: id,
    };
    let path = API_Path.getMemberById;
    const getMemberByIdPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getMemberByIdPromise.then((res) => {
      if (res) {
        this.setState(
          {
            memberName: res.data.data[0].name,
            memberEmail: res.data.data[0].email,
            memberNumber: res.data.data[0].phone,
            profileImageUrl: res.data.data[0].image,
            roleSelect: res.data.data[0].user_role,
          },
          () => {
            this.setState({ add_edit_modal_show: true, modalType: "edit" });
          }
        );
      }
    });
  };

  editMember = () => {
    let data = {
      name: this.state.memberName,
      email: this.state.memberEmail,
      phone: this.state.memberNumber,
      user_role: this.state.roleSelect,
      image: this.state.profileImageUrl,
      id: this.state.editedMemberId,
    };
    let path = API_Path.editMember;
    const editMemberPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    editMemberPromise.then((res) => {
      if (res) {
        toastr.success(res.data.message);
        this.setState({ add_edit_modal_show: false }, () => {
          this.getMember();
          this.clearState();
        });
      }
    });
  };

  delete_record = (id) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>Are you sure?</h1>
            <p> Do you want to delete this Banner?</p>
            <button className="btn red-btn me-2" onClick={onClose}>
              No
            </button>
            <button
              className="btn red-btn"
              onClick={() => {
                onClose();
                this.deleteMember(id);
              }}
            >
              Delete
            </button>
          </div>
        );
      },
    });
  };

  deleteMember = (id) => {
    let data = {
      id: id,
    };
    let path = API_Path.deleteMember;
    const deleteMemberPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    deleteMemberPromise.then((res) => {
      if (res) {
        this.getMember();
      }
    });
  };

  cloneMember = (id) => {
    let data = {
      id: id,
    };
    let path = API_Path.cloneMember;
    const cloneMemberPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    cloneMemberPromise.then((res) => {
      if (res) {
        this.getMember();
      }
    });
  };

  handleClickRoleTypeEdit = (id) => {
    this.getPermissions().then(() => this.getRoleById(id));
  };

  getPermissions = () => {
    let data = {
      status: "",
    };
    let path = API_Path.getPermissionsList;
    const getPermissionsPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    return getPermissionsPromise.then((res) => {
      if (res) {
        if (res.data.success) {
          this.setState({ permissionsList: res.data.data });
        }
      }
    });
  };

  render() {
    let Language =
      this.context.language === "english"
        ? TableFieldEnglish
        : TableFieldArabic;
    let buttonLanguage =
      this.context.language === "english" ? buttonEnglish : buttonArabic;
    let titleLanguage =
      this.context.language === "english" ? titleEnglish : titleArabic;
    let teamLanguage =
      this.context.language === "english" ? teamEnglish : teamArabic;

    const isLanguageEnglish = this.context.language === "english";

    const columns = [
      {
        dataField: "id",
        text: "Id",
        hidden: true,
      },
      {
        dataField: "image",
        text: teamLanguage.photo,
        sort: true,
        hidden: false,
        formatter: (cell, row, rowIndex) => {
          return (
            <React.Fragment>
              <img src={row.image} alt="" />
            </React.Fragment>
          );
        },
      },
      {
        dataField: "name",
        text: teamLanguage.fullName,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: teamLanguage.search,
        }),
        formatter: (cell, row, rowIndex) => {
          return (
            <React.Fragment>
              <span>{row.name ?? (row.first_name + " " + row.last_name)}</span>
            </React.Fragment>
          );
        },
      },
      {
        dataField: "email",
        text: teamLanguage.eMail,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: teamLanguage.search,
        }),
      },
      {
        dataField: "phone",
        text: teamLanguage.phoneNumber,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: teamLanguage.search,
        }),
        formatter: (cell, row, rowIndex) => {
          return (
            <React.Fragment>
              <span>{"+" + row.phone}</span>
            </React.Fragment>
          );
        },
      },
      {
        dataField: "user_role",
        // this.context.language === "english" ?  "member_eng" : "member_arb",
        text: teamLanguage.teamRole,
        sort: true,
        hidden: false,
        filter: textFilter({
          placeholder: teamLanguage.search,
        }),
        formatter: (cell, row, rowIndex) => {
          return (
            <React.Fragment>
              <span>
                {
                  this.state.activeRoleData.find(
                    (role) => role.id == row.user_role
                  )?.[
                    this.context.language === "english" ? "english" : "arabic"
                  ]
                }
              </span>
            </React.Fragment>
          );
        },
      },
      {
        dataField: "action",
        text: Language.action,
        hidden: false,
        csvExport: false,
        headerClasses: "text-center",
        classes: "text-center",
        formatter: (cell, row, rowIndex) => {
          return (
            <React.Fragment>
              <Dropdown className="cust-drop">
                <Dropdown.Toggle
                  className="bg-transparent "
                  id="dropdown-basic"
                  align="end"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width={16}
                    height={16}
                    fill="currentColor"
                    className="bi bi-three-dots-vertical"
                    viewBox="0 0 16 16"
                  >
                    <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                  </svg>
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  <Dropdown.Item
                    href="#"
                    onClick={() => this.getMemberById(row.id)}
                  >
                    <svg
                      width={19}
                      height={18}
                      viewBox="0 0 19 19"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
                        fill="#2D2D3B"
                      />
                    </svg>
                    <span>{buttonLanguage.edit}</span>
                  </Dropdown.Item>
                  <Dropdown.Item
                    href="#"
                    onClick={() => this.delete_record(row.id)}
                  >
                    <svg
                      width={18}
                      height={20}
                      viewBox="0 0 18 20"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
                        fill="#2D2D3B"
                      />
                    </svg>
                    <span>{buttonLanguage.delete}</span>
                  </Dropdown.Item>
                  <Dropdown.Item
                    href="#"
                    onClick={() => this.cloneMember(row.id)}
                  >
                    <svg
                      width={20}
                      height={20}
                      viewBox="0 0 18 18"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M10.6665 17.3333H2.33317C1.88656 17.3488 1.45356 17.1782 1.13757 16.8622C0.821587 16.5462 0.650981 16.1132 0.666501 15.6666V7.33329C0.650981 6.88669 0.821587 6.45369 1.13757 6.1377C1.45356 5.82171 1.88656 5.6511 2.33317 5.66662H5.6665V2.33329C5.65098 1.88669 5.82159 1.45368 6.13758 1.1377C6.45356 0.821709 6.88656 0.651103 7.33317 0.666623H15.6665C16.1131 0.651103 16.5461 0.821709 16.8621 1.1377C17.1781 1.45368 17.3487 1.88669 17.3332 2.33329V10.6666C17.3484 11.1132 17.1778 11.546 16.8618 11.8619C16.5459 12.1779 16.113 12.3486 15.6665 12.3333H12.3332V15.6666C12.3484 16.1132 12.1778 16.546 11.8618 16.8619C11.5459 17.1779 11.113 17.3486 10.6665 17.3333ZM2.33317 7.33329V15.6666H10.6665V12.3333H7.33317C6.88663 12.3486 6.45378 12.1779 6.13785 11.8619C5.82192 11.546 5.65123 11.1132 5.6665 10.6666V7.33329H2.33317ZM7.33317 2.33329V10.6666H15.6665V2.33329H7.33317Z"
                        fill="#2D2D3B"
                      />
                    </svg>

                    <span>{teamLanguage.clone}</span>
                  </Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </React.Fragment>
          );
        },
      },
    ];
    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space align-items-center">
            <div className="col-6  text-start rtl-txt-start">
              <div className="common-header-txt">
                <h3>{teamLanguage.teamRoles}</h3>
              </div>
            </div>
            <div className="col-6  text-end rtl-txt-end">
              <button
                type="button"
                onClick={this.handleAddPermissionClick}
                className="btn black-btn"
              >
                {teamLanguage.addPermission}
              </button>
              <button
                type="button"
                onClick={this.edit_role_handleShow}
                className="btn red-btn ms-4"
              >
                {teamLanguage.addTeamRole}
              </button>
            </div>
            <div className="col-12 pt-3">
              <div className="white-box p-0">
                <div className="white-box-team-hdr">
                  {teamLanguage.roleTypes}
                </div>
                <div className="white-box-team-body">
                  <ul className="row me-0">
                    {this.state.roleData.length > 0 &&
                      this.state.roleData.map((item, i) => {
                        return (
                          <li
                            className="col-lg-3 col-md-4 col-sm-6 pe-0 mt-3"
                            key={i}
                          >
                            <div className="d-flex align-items-center rols-type-info">
                              <bdi className="d-block ms-auto">
                                {this.context.language === "english"
                                  ? item.english
                                  : item.arabic}
                              </bdi>
                              <Dropdown className="cust-drop ms-auto">
                                <Dropdown.Toggle
                                  className="bg-transparent p-0 m-0"
                                  id="team-role-1"
                                  align="end"
                                >
                                  <svg
                                    xmlns="http://www.w3.org/2000/svg"
                                    width={16}
                                    height={16}
                                    fill="currentColor"
                                    className="bi bi-three-dots-vertical"
                                    viewBox="0 0 16 16"
                                  >
                                    <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                  </svg>
                                </Dropdown.Toggle>
                                <Dropdown.Menu>
                                  <Dropdown.Item
                                    onClick={() =>
                                      this.handleClickRoleTypeEdit(item.id)
                                    }
                                  >
                                    <svg
                                      width={19}
                                      height={18}
                                      viewBox="0 0 19 19"
                                      fill="none"
                                      xmlns="http://www.w3.org/2000/svg"
                                    >
                                      <path
                                        d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
                                        fill="#2D2D3B"
                                      />
                                    </svg>
                                    <span>{buttonLanguage.edit}</span>
                                  </Dropdown.Item>
                                  {/* <Dropdown.Item
                                    onClick={() => this.deleteTeamRole(item.id)}
                                  >
                                    <svg
                                      width={18}
                                      height={20}
                                      viewBox="0 0 18 20"
                                      fill="none"
                                      xmlns="http://www.w3.org/2000/svg"
                                    >
                                      <path
                                        d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
                                        fill="#2D2D3B"
                                      />
                                    </svg>
                                    <span>{buttonLanguage.delete}</span>
                                  </Dropdown.Item> */}
                                  <Dropdown.Item
                                    onClick={() => this.cloneRole(item.id)}
                                  >
                                    <svg
                                      width={20}
                                      height={15}
                                      viewBox="0 0 18 18"
                                      fill="none"
                                      xmlns="http://www.w3.org/2000/svg"
                                    >
                                      <path
                                        d="M10.6665 17.3333H2.33317C1.88656 17.3488 1.45356 17.1782 1.13757 16.8622C0.821587 16.5462 0.650981 16.1132 0.666501 15.6666V7.33329C0.650981 6.88669 0.821587 6.45369 1.13757 6.1377C1.45356 5.82171 1.88656 5.6511 2.33317 5.66662H5.6665V2.33329C5.65098 1.88669 5.82159 1.45368 6.13758 1.1377C6.45356 0.821709 6.88656 0.651103 7.33317 0.666623H15.6665C16.1131 0.651103 16.5461 0.821709 16.8621 1.1377C17.1781 1.45368 17.3487 1.88669 17.3332 2.33329V10.6666C17.3484 11.1132 17.1778 11.546 16.8618 11.8619C16.5459 12.1779 16.113 12.3486 15.6665 12.3333H12.3332V15.6666C12.3484 16.1132 12.1778 16.546 11.8618 16.8619C11.5459 17.1779 11.113 17.3486 10.6665 17.3333ZM2.33317 7.33329V15.6666H10.6665V12.3333H7.33317C6.88663 12.3486 6.45378 12.1779 6.13785 11.8619C5.82192 11.546 5.65123 11.1132 5.6665 10.6666V7.33329H2.33317ZM7.33317 2.33329V10.6666H15.6665V2.33329H7.33317Z"
                                        fill="#2D2D3B"
                                      />
                                    </svg>
                                    <span>{teamLanguage.clone}</span>
                                  </Dropdown.Item>
                                </Dropdown.Menu>
                              </Dropdown>
                            </div>
                          </li>
                        );
                      })}
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="row common-space align-items-center">
            <div className="col-6  text-start rtl-txt-start">
              <div className="common-header-txt">
                <h3>{teamLanguage.teamMembers}</h3>
              </div>
            </div>
            <div className="col-6  text-end rtl-txt-end">
              <button
                type="button"
                onClick={this.add_edit_handleShow}
                className="btn black-btn"
              >
                {teamLanguage.addTeamMembers}
              </button>
            </div>
            <div className="col-12 pt-3">
              <div className="white-box">
                <div className="custom-table team-table">
                  <div className="table-responsive dataTables_wrapper no-footer">
                    {this.state.order_data && (
                      <DataTable
                        keyField="id"
                        loading={this.state.loading}
                        columns={columns}
                        data={this.state.order_data}
                        page={this.state.page}
                        sizePerPage={this.state.sizePerPage}
                        totalSize={this.state.totalSize}
                        defaultSorted={this.state.defaultSorted}
                        language={this.context.language}
                        onTableChange={this.handleTableChange}
                        selectableRows
                      />
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <Modal
          show={this.state.deleteTeamRole}
          className="cust-modal signout-modal"
          onHide={this.deleteTeamRoleClose}
          size="md"
          centered
        >
          <Modal.Body>
            <div className="text-center p-4">
              <h5 className="fw-bold fs-3">Are you sure?</h5>
              <p className="fs-6 mb-4">Do you want to delete this team role?</p>
              <button
                className="btn red-btn me-2"
                onClick={this.handleDeleteTeamRole}
              >
                Yes
              </button>
              <button
                className="btn red-btn"
                onClick={this.deleteTeamRoleClose}
              >
                No
              </button>
            </div>
          </Modal.Body>
        </Modal>

        <Modal
          dialogClassName="modal-dialog-centered modal-xl edit-user-modal cust-modal fix-edit-role-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.edit_role_modal_show}
          onHide={this.edit_role_handleClose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">{teamLanguage.AddEditRole}</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.edit_role_handleClose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <form>
              <div className="row me-0">
                <div className="form-group col-md-6 pe-0">
                  <label>{teamLanguage.roleNameInEng}</label>
                  <input
                    type="text"
                    name="role_name_english"
                    onChange={this.handleChange}
                    value={this.state.role_name_english}
                    className="form-control input-custom-class"
                    placeholder={teamLanguage.customerCare}
                  />
                </div>
                <div className="form-group col-md-6 pe-0">
                  <label>{teamLanguage.roleNameInArb}</label>
                  <input
                    type="text"
                    name="role_name_arabic"
                    onChange={this.handleChange}
                    value={this.state.role_name_arabic}
                    className="form-control input-custom-class"
                    placeholder="ءﺎﻠﻤﻌﻟا ﺔﻣﺪﺧ ﻒﻇﻮﻣ"
                  />
                </div>
              </div>
              <div className="check-team-popup py-3">
                <div className="cust-checkbox-new">
                  <label className="cust-chk-bx">
                    <input
                      type="checkbox"
                      name="allPermision"
                      onChange={this.handleAllChecked}
                    />
                    <span className="cust-chkmark"></span>
                    <bdi>{teamLanguage.selectAllPermissions}</bdi>
                  </label>
                </div>
              </div>
              <div className="check-team-popup">
                <div className="row">
                  {this.state.permissionsList.map((module) => {
                    let allSelected = false,
                      someSelected = false;
                    if (this.state.selectedRoleData.permissions) {
                      // allSelected = module.sub_module.every(({ id }) =>
                      //   this.state.selectedRoleData.permissions.includes(
                      //     id.toString()
                      //   )
                      // );
                      // if (!allSelected)
                      //   someSelected = module.sub_module.some(({ id }) =>
                      //     this.state.selectedRoleData.permissions.includes(
                      //       id.toString()
                      //     )
                      //   );
                    }
                    return (
                      <div key={module.id} className="col-md-3 mb-3">
                        <ul>
                          <li>
                            <div className="cust-checkbox-new">
                              <label className="cust-chk-bx">
                                <input
                                  name={module.label_eng}
                                  id={module.label_eng}
                                  type="checkbox"
                                  // checked={allSelected}
                                  ref={(ref) => {
                                    if (ref) ref.indeterminate = someSelected;
                                  }}
                                  onChange={(e) =>
                                    this.handleCheckBox(e, {
                                      module_id: module.id,
                                    })
                                  }
                                />
                                <span className="cust-chkmark"></span>
                                <b>
                                  {" "}
                                  <bdi>
                                    {isLanguageEnglish
                                      ? module.label_eng
                                      : module.label_arb}
                                  </bdi>
                                </b>
                              </label>
                            </div>
                          </li>
                          {module.sub_module.map((item, i) => {
                            return (
                              <li key={item.id}>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input
                                      name={item.id}
                                      id={item.label_eng + "-" + i}
                                      // checked={this.state.selectedRoleData?.permissions?.includes(
                                      //   item.id.toString()
                                      // )}
                                      type="checkbox"
                                      onChange={(e) =>
                                        this.handleCheckBox(e, {
                                          sub_module_id: item.id,
                                        })
                                      }
                                    />
                                    <span className="cust-chkmark"></span>

                                    <bdi>
                                      {isLanguageEnglish
                                        ? item.label_eng
                                        : item.label_arb}
                                    </bdi>
                                  </label>
                                </div>
                              </li>
                            );
                          })}
                        </ul>
                      </div>
                    );
                  })}
                </div>
              </div>
              <div className="text-center pt-4">
                <button
                  onClick={
                    this.state.roleModalType === "add"
                      ? this.handleSavePermission
                      : this.handleEditPermission
                  }
                  type="button"
                  className="btn red-btn"
                >
                  {buttonLanguage.save}
                </button>
              </div>
            </form>
          </Modal.Body>
        </Modal>

        <Modal
          dialogClassName="modal-dialog-centered modal-lg edit-user-modal cust-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.add_edit_modal_show}
          onHide={this.add_edit_handleClose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">{teamLanguage.AddEditMember}</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.add_edit_handleOnClose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <form>
              <div className="row me-0">
                <div className="form-group col-md-6 pe-0">
                  <label>{teamLanguage.firstName}</label>
                  <input
                    type="text"
                    name="memberFirstName"
                    value={this.state.memberFirstName}
                    onChange={this.handleChange}
                    className="form-control input-custom-class"
                    placeholder="Mohammed"
                  />
                </div>
                <div className="form-group col-md-6 pe-0">
                  <label>{teamLanguage.lastName}</label>
                  <input
                    type="text"
                    name="memberLastName"
                    value={this.state.memberLastName}
                    onChange={this.handleChange}
                    className="form-control input-custom-class"
                    placeholder="Imran yasir"
                  />
                </div>
                <div className="form-group col-md-6 pe-0">
                  <label>{teamLanguage.eMail}</label>
                  <input
                    type="email"
                    name="memberEmail"
                    value={this.state.memberEmail}
                    onChange={this.handleChange}
                    className="form-control input-custom-class"
                    placeholder="support@libsimarkah.com"
                  />
                </div>
                <div className="form-group col-md-6 pe-0">
                  <label>{teamLanguage.phoneNumber}</label>
                  <PhoneInput
                    disableCountryGuess={true}
                    country="sa"
                    disableDropdown
                    countryCodeEditable={false}
                    placeholder="Enter phone number"
                    value={"+" + this.state.memberNumber}
                    className="form-select-phone"
                    onChange={this.handlePhoneChange}
                  />
                </div>
                <div className="form-group col-md-6 pe-0">
                  <label>{teamLanguage.teamRole}</label>
                  <select
                    name="roleSelect"
                    onChange={this.handleChange}
                    className="form-select input-custom-class"
                  >
                    <option selected>Open this select menu</option>

                    {this.state.activeRoleData.length > 0 &&
                      this.state.activeRoleData.map((item, i) => {
                        return (
                          <option
                            key={i}
                            value={item.id}
                            selected={this.state.roleSelect == item.id}
                          >
                            {this.context.language === "english"
                              ? item.english
                              : item.arabic}
                          </option>
                        );
                      })}
                    {/* <option value="1">Call centre staff</option>
                                        <option value="2">Two</option>
                                        <option value="3">Three</option> */}
                  </select>
                </div>
                <div className="form-group col-md-6 pe-0">
                  <label>{teamLanguage.password}</label>
                  <input
                    type="password"
                    name="memberPassword"
                    value={this.state.memberPassword}
                    onChange={this.handleChange}
                    className="form-control input-custom-class"
                    placeholder="********"
                  />
                </div>
                <div className="form-group col-md-6 pe-0">
                  <label>{teamLanguage.ProfilePhoto}</label>
                  <div className="input-group mb-3">
                    <input
                      type="file"
                      id="imageSizeInput"
                      onChange={this.addProfile}
                      accept="image/*"
                      name="profileImageUrl"
                      className="form-control input-custom-class cust-line-height"
                    />
                  </div>
                </div>
                <div className="form-group col-md-6 mt-3">
                  {this.state.profileImageUrl !== "" && (
                    <div className="img-preview ps-3 wdth-click-main">
                      <ul className="justify-content-center">
                        <div className="img-bdr-main">
                          <div className="img-bdr-main-inr">
                            <li>
                              <div className="img-preview-main position-relative">
                                <img src={this.state.profileImageUrl} alt="" />
                                <div
                                  onClick={this.removeThumbnailImages}
                                  className="remove-img-btn"
                                >
                                  <i className="bi bi-x-circle-fill"></i>
                                </div>
                              </div>
                            </li>
                          </div>
                        </div>
                      </ul>
                    </div>
                  )}
                </div>
                <div className="form-group col-12 text-center pt-4">
                  <button
                    type="button"
                    onClick={
                      this.state.modalType === "add"
                        ? this.handleSave
                        : this.editMember
                    }
                    className="btn red-btn"
                  >
                    {buttonLanguage.save}
                  </button>
                </div>
              </div>
            </form>
          </Modal.Body>
        </Modal>
      </Adminlayout>
    );
  }
}

export default Team;
