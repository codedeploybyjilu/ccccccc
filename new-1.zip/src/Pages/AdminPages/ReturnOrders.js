// /get-admin-modules

// /add-admin-permissions


import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import { confirmAlert } from "react-confirm-alert";
import { Modal, Dropdown, ModalFooter } from "react-bootstrap";
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";
import SearchIcon from "../../images/search-icon.svg";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Link } from "react-router-dom";
import Moment from "moment";
import loader from "../../images/loader.gif";
import {
  API_Path,
  buttonArabic,
  productArabic,
  productEnglish,
  buttonEnglish,
  orderArabic,
  orderEnglish,
  DashboardArabic,
  DashboardEnglish,
  titleArabic,
  titleEnglish,
  UserEnglish,
  UserArabic,
} from "../../const";
import LanguageContext from "../../contexts/languageContext";
import MUITable from "../../Components/MUITable";
import { PostApi } from "../../helper/APIService";

const paymentMethods = [
  { id: "CARDPAYMENT", name: "Card Payment" },
  { id: "APPLEPAY", name: "Apple Pay" },
  { id: "COD", name: "COD" },
  { id: "TABBY", name: "Tabby" },
  { id: "TAMARA", name: "Tamara" },
];

const statusMapping = {
  21: "Pending",
};

const theme = createMuiTheme({
  palette: {
    primary: {
      light: "#757ce8",
      main: "#a81a1c",
      dark: "#002884",
      contrastText: "#fff",
    },
    secondary: {
      light: "#ff7961",
      main: "#f44336",
      dark: "#ba000d",
      contrastText: "#000",
    },
  },
});

class ReturnOrders extends Component {
  static contextType = LanguageContext;
  constructor(props) {
    super(props);
    this.state = {
      changeStatus: false,
      AssignTeam: false,
      search_show: false,
      edit_show: false,
      search_val: "",
      page: 1,
      sizePerPage: 100,
      totalSize: 0,
      totalPage: 1,
      AllCity: "",
      AllArea: "",
      defaultSorted: [
        {
          dataField: "id",
          order: "desc",
        },
      ],
      order_data: [],
      CustomerFilterShippingCompany: null,
      CustomerFilterEmail: null,
      CustomerFilterCity: null,
      CustomerFilterArea: null,
      customFilterPaymentMethod: null,
      OrderFilterStaus: null,
      CustomerFilterName: null,
      NumberFilter: [],
      OrderStatus: null,
      CustomerFilterFromDate: null,
      CustomerFilterToDate: null,
      Order_Tab: "",
      Order_ids: "",
      paymentCheckedData: "",
      paymentcheckpopup: false,
      paymentCheckedloader: false,
      Loader: true,
      orderItemsData: [],
      orderItemsLoader: true,
      orderItemDataLoader: false,
      orderItemsPage: 1,
      hoverId: "",
      callITems: false,
    };
    this.getData = "";
    this.timeOut = "";
    this.itemsRef = React.createRef();
  }

  componentDidMount() {
    let url = window.location.href;
    if (url.includes("?")) {
      let idString = url.split("?")[1];
      this.setState({ search_val: idString.replaceAll("%20", " ") }, () => {
        setTimeout(() => {
          console.log(document.getElementById("all-order"), "[[=[");
          document.getElementById("all-order").checked = true;
        }, 1200);
        this.get_order_data(this.state.page, this.state.sizePerPage, "");
      });
    } else {
      this.get_order_data(this.state.page, this.state.sizePerPage, "21");
    }
    this.get_city_and_area();
    this.get_order_count();
  }

  edit_filterClose = () => {
    this.setState({ search_show: false });
  };

  editfilter_Show = (e) => {
    e.preventDefault();
    this.setState({ search_show: true });
  };

  filter_handleShow = (e) => {
    e.preventDefault();
    this.setState({ search_show: true });
  };

  // edit_handleShow = (e) => {
  //     e.preventDefault()
  //     this.setState({ edit_show: true });
  // }
  // edit_Close = () => {
  //     this.setState({ edit_show: false });
  // }

  // edit_Show = (e) => {
  //     e.preventDefault()
  //     this.setState({ edit_show: true });
  // }

  get_order_count = () => {
    new Promise((resolve) => {
      resolve(PostApi(API_Path.getReturnOrderCount, {}));
    }).then((res) => {
      if (res) {
        if (res.data.success) {
          let Count_data = res.data.data;
          let order_tab = [
            {
              status: 1,
              labelEng: "Pending",
              labelArb: "في الإنتظار",
              id: "pending",
            },
            {
              status: 2,
              labelEng: "Accepted",
              labelArb: "قبلت",
              id: "accepted",
            },
            {
              status: 4,
              labelEng: "Shipped",
              labelArb: "تم الشحن",
              id: "shipped",
            },
            {
              status: 6,
              labelEng: "Delivered",
              labelArb: "تم التوصيل",
              id: "delivered",
            },
            {
              status: 7,
              labelEng: "Approved",
              labelArb: "موافقة",
              id: "approved",
            },
            {
              status: 3,
              labelEng: "Rejected",
              labelArb: "مرفوض",
              id: "rejected",
            },
            {
              status: 5,
              labelEng: "Cancelled",
              labelArb: "ملغى",
              id: "cancelled",
            },
          ];
          let AllCount = Count_data?.reduce((prev, cur) => {
            return prev + cur.count;
          }, 0);
          for (let i = 0; i < order_tab.length; i++) {
            let checked = Count_data?.findIndex(
              (e) => e.status === order_tab[i].status
            );
            if (checked != -1) {
              order_tab[i].count = Count_data[checked]?.count;
            } else {
              order_tab[i].count = AllCount;
            }
          }
          this.setState({ Order_Tab: order_tab }, () => {
            document.getElementById("pending").checked = true;
          });
        }
      }
    });
  };

  get_city_and_area = () => {
    let city_path = API_Path.getCityData;
    let area_path = API_Path.getArea;
    const getCity = new Promise((resolve) => {
      resolve(PostApi(city_path));
    });
    const getArea = new Promise((resolve) => {
      resolve(PostApi(area_path));
    });
    Promise.all([getCity, getArea]).then((res) => {
      if (res[0] && res[1]) {
        this.setState({ AllCity: res[0].data.data, AllArea: res[1].data.data });
      }
    });
  };

  get_order_data = (page, limit, status) => {
    const data = {
      sizePerPage: limit,
      page: page,
      defaultSorted: this.state.defaultSorted,
      searchText: this.state.search_val,
      state: status,
      order_id: this.state.NumberFilter,
      name: this.state.CustomerFilterName,
      pay_method: this.state.customFilterPaymentMethod,
      from: this.state.CustomerFilterFromDate,
      to: this.state.CustomerFilterToDate,
      city_id: this.state.CustomerFilterCity,
      area_id: this.state.CustomerFilterArea,
    };
    let path = API_Path.getReturnOrder;

    const getOrderPromise = new Promise((resolve) => {
      resolve(PostApi(path, data));
    });
    getOrderPromise.then((res) => {
      if (res.data.success) {
        if (document.querySelector('button[aria-label="Close"]')) {
          document.querySelector('button[aria-label="Close"]').click();
        }
        this.setState({
          order_data: res.data.data,
          totalSize: res.data.totalRecord,
          Loader: false,
        });
      } else {
        this.setState({ order_data: [], Loader: false });
      }
    });
  };

  filterChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  filterStartDateChange = (e) => {
    this.setState({ CustomerFilterFromDate: Moment(e).format("YYYY-MM-DD") });
  };

  filterEndDateChange = (e) => {
    this.setState({ CustomerFilterToDate: Moment(e).format("YYYY-MM-DD") });
  };

  numberfilterChange = (e) => {
    if (e.target.value.includes(",")) {
      this.setState({ NumberFilter: e.target.value.split(",") });
    } else {
      this.setState({ NumberFilter: [e.target.value] });
    }
  };

  delete_record = (id) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>Are you sure?</h1>
            <p>You want to delete this file?</p>
            <button className="btn red-btn me-2" onClick={onClose}>
              No
            </button>
            <button
              className="btn red-btn"
              onClick={() => {
                this.finaly_delete_record(id);
                onClose();
              }}
            >
              Yes, Delete it!
            </button>
          </div>
        );
      },
    });
  };

  finaly_delete_record = (id) => {};

  changeStatus = () => {
    this.setState({ changeStatus: true });
  };

  changeStatusClose = () => {
    this.setState({ changeStatus: false });
  };

  AssignTeam = () => {
    this.setState({ AssignTeam: true });
  };

  AssignTeamClose = () => {
    this.setState({ AssignTeam: false });
  };

  PaymentCheckModal = () => {
    this.setState({ paymentcheckpopup: true });
  };
  PaymentCheckModalClose = () => {
    this.setState({ paymentcheckpopup: false }, () => {
      this.get_order_data(
        this.state.page,
        this.state.sizePerPage,
        this.state.OrderStatus
      );
    });
  };

  // onChangeTable = (action, tableState) => {
  //   switch (action) {
  //     case "changePage":
  //       this.changePage(tableState.page)
  //       break;

  //     default:
  //       break;
  //   }
  // }

  selectSatus = (e) => {
    this.setState({ Loader: true });
    // for (let i = 0; i < this.state.Order_Tab.length; i++) {
    //   if (document.getElementById(this.state.Order_Tab[i].id)) {
    //     document.getElementById(this.state.Order_Tab[i].id).checked = false
    //   }

    // }

    let status;
    switch (e.target.id) {
      case "pending":
        status = "21";
        break;
      case "accepted":
        status = "22";
        break;
      case "rejected":
        status = "23";
        break;
      case "shipped":
        status = "24";
        break;
      case "delivered":
        status = "25";
        break;
      case "cancelled":
        status = "26";
        break;
      case "approved":
        status = "27";
        break;
      case "partially-returned":
        status = "28";
        break;

      default:
        break;
    }
    this.setState({ OrderStatus: status }, () => {
      this.get_order_data(
        this.state.page,
        this.state.sizePerPage,
        this.state.OrderStatus
      );
    });
  };

  filterType = (e) => {};

  clearFilter = () => {
    this.setState(
      {
        CustomerFilterShippingCompany: null,
        CustomerFilterEmail: null,
        CustomerFilterCity: null,
        CustomerFilterArea: null,
        OrderFilterStaus: null,
        CustomerFilterName: null,
        NumberFilter: [],
        OrderStatus: null,
        CustomerFilterFromDate: null,
        CustomerFilterToDate: null,
      },
      () => {
        this.get_order_data(
          this.state.page,
          this.state.sizePerPage,
          this.state.OrderStatus
        );
      }
    );
  };
  handleSearch = (e) => {
    this.setState({ search_val: e.target.value }, () => {
      clearTimeout(this.getData);
      this.getData = setTimeout(() => {
        this.get_order_data(
          this.state.page,
          this.state.sizePerPage,
          this.state.OrderStatus
        );
      }, 500);
    });
  };
  handlePaymentCheck = (id) => {
    this.setState({ paymentCheckedloader: true });
    this.PaymentCheckModal();
    let P_checkReq = {
      order_id: id,
    };
    new Promise((resolve) => {
      resolve(PostApi(API_Path.PaymentCheck, P_checkReq));
    }).then((res) => {
      if (res.data.success) {
        this.setState({
          paymentCheckedData: res.data.data,
          paymentCheckedloader: false,
        });
      }
    });
  };
  getOrderItems = (id) => {
    clearTimeout(this.timeOut);
    let reqData = {
      order_id: id,
      page: 1,
      sizePerPage: 7,
    };
    this.setState(
      {
        orderItemsPage: 1,
        orderItemsLoader: true,
        hoverId: id,
        callITems: false,
      },
      () => {
        this.timeOut = setTimeout(() => {
          new Promise((resolve) => {
            resolve(PostApi(API_Path.getItemsById, reqData));
          }).then((res) => {
            if (res.data.data.order_items.length > 0) {
              this.setState({
                orderItemsData: res.data.data.order_items,
                orderItemsLoader: false,
              });
            }
          });
          console.log(id, "idd");
        }, 1000);
      }
    );
  };
  clearEvent = () => {
    clearTimeout(this.timeOut);
  };
  ScrollItems = (e) => {
    const bottom =
      e.target.scrollHeight - e.target.scrollTop === e.target.clientHeight;
    // console.log(e.target.scrollHeight, ":: e.target.scrollHeight", e.target.scrollTop, '::e.target.scrollTop');
    // console.log(!this.state.callITems, "!this.state.callITems");
    if (!this.state.callITems) {
      // console.log(!this.state.callITems, "!this.state.callITems");
      if (e.target.scrollTop == 1) {
        this.setState({ orderItemDataLoader: true });
      }
      if (bottom) {
        this.setState(
          {
            orderItemsPage: this.state.orderItemsPage + 1,
            orderItemDataLoader: true,
          },
          () => {
            let reqData = {
              order_id: this.state.hoverId,
              page: this.state.orderItemsPage,
              sizePerPage: 7,
            };
            new Promise((resolve) => {
              resolve(PostApi(API_Path.getItemsById, reqData));
            }).then((res) => {
              if (res.data.data.order_items.length > 0) {
                let reData = [
                  ...this.state.orderItemsData,
                  ...res.data.data.order_items,
                ];
                this.setState({
                  orderItemsData: reData,
                  orderItemsLoader: false,
                });
              } else {
                this.setState({ orderItemDataLoader: false, callITems: true });
              }
            });

            console.log(this.state.orderItemsPage, "orderItemsPage");
          }
        );
      }
    }
    // if (this.itemsRef.current) {
    //   const { scrollTop, scrollHeight, clientHeight } = this.itemsRef.current;
    //   const isNearBottom = scrollTop - scrollHeight == clientHeight;

    //   if (isNearBottom) {
    //     console.log("Reached bottom");
    //     // DO SOMETHING HERE
    //   }
    // }
    // console.log(e, "[=][");
  };

  render() {
    let titleLanguage =
      this.context.language === "english" ? titleEnglish : titleArabic;
    let ButtonLanguage =
      this.context.language === "english" ? buttonEnglish : buttonArabic;
    let orderLanguage =
      this.context.language === "english" ? orderEnglish : orderArabic;
    let DashboardLanguage =
      this.context.language === "english" ? DashboardEnglish : DashboardArabic;
    let productLanguage =
      this.context.language === "english" ? productEnglish : productArabic;
    let userLanguage =
      this.context.language === "english" ? UserEnglish : UserArabic;
    let columns;

    columns = [
      {
        label: orderLanguage.rmaNo,
        name: "id",
        options: {
          filter: true,
          customBodyRender: (value) => {
            return (
              <>
                <Link to={"return-order-details/" + value}>
                  <a className="fw-bold dark-red-txt">{value}</a>
                </Link>
              </>
            );
          },
        },
      },
      {
        label: orderLanguage.customerName,
        name: "first_name",
        options: {
          filter: true,
          customBodyRender: (value, tableMeta, updateValue) => {
            let data = this.state.order_data[tableMeta.rowIndex];
            let lastName = data.last_name ? data.last_name : "";
            const address = JSON.parse(data.address ?? "{}");
            // let id;
            // this.state.order_data && this.state.order_data.map((item) => id = item.id)
            return (
              <>
                <div className="cust-drop hover-new position-relative">
                  <div className="order-cust-name d-flex align-items-center">
                    <div className="tble-name-fix">
                      {value + " " + lastName}
                    </div>
                    <bdi
                      className={`${
                        data.mark?.replace("Customer", " ").includes("New")
                          ? "new-class"
                          : data.mark?.replace("Customer", " ").includes("Bad")
                          ? "bad-class"
                          : data.mark
                              ?.replace("Customer", " ")
                              .includes("Premium")
                          ? "vip-class"
                          : ""
                      }`}
                    >
                      {data.mark?.replace("Customer", " ").includes("New")
                        ? "New"
                        : data.mark?.replace("Customer", " ").includes("Bad")
                        ? "Bad"
                        : data.mark
                            ?.replace("Customer", " ")
                            .includes("Premium")
                        ? "Vip"
                        : ""}
                    </bdi>
                    <i className="bi bi-chevron-down ms-2"></i>
                  </div>
                  <div className="hover-dropdown">
                    <div className="p-3 border-bottom">
                      <div className="name-text">{value}</div>
                      <div className="grey-text">
                        {address.area_en},{address.city_en}
                      </div>
                      <div className="grey-text">{data.user_orders} Orders</div>
                      <div className="red-txt text-decoration-underline">
                        {data.email}
                      </div>
                    </div>
                    <div className="p-3">
                      <a href={`user-details/${address.user_id}`}>
                        <button className="red-border-btn w-100">
                          {" "}
                          View Customer
                        </button>
                      </a>
                    </div>
                  </div>
                </div>
              </>
            );
          },
        },
      },
      {
        label: orderLanguage.rmaDate,
        name: "createdat",
        options: {
          filter: true,
          customBodyRender: (value) => {
            return <>{Moment(value).format("DD/MM/YYYY hh:mm A")}</>;
          },
        },
      },
      {
        label: orderLanguage.order,
        name: "order_id",
        options: {
          filter: true,
        },
      },
      {
        label: orderLanguage.cityArea,
        name: "CityName",
        options: {
          filter: true,
          customBodyRender: (value, tableMeta, updateValue) => {
            let data = this.state.order_data[tableMeta.rowIndex];
            const address = JSON.parse(data.address ?? "{}");
            // let id;
            // this.state.order_data && this.state.order_data.map((item) => id = item.id)
            if (this.context.language === "english") {
              return (
                <span>
                  {address.city_en} - {address.area_en}
                </span>
              );
            } else {
              return (
                <span>
                  {address.city_ar} - {address.area_ar}
                </span>
              );
            }
          },
        },
      },
      {
        label: orderLanguage.phoneNumber,
        name: "phone",
        options: {
          filter: true,
          customBodyRender: (value) => {
            if (value) {
              return (
                <>
                  {value.substring(0, 3) !== "966"
                    ? 0 + value
                    : 0 + value.substring(0, 3)}
                </>
              );
            }
          },
        },
      },
      {
        label: orderLanguage.value,
        name: "total_paymentable_price",
        options: {
          filter: true,
          sort: false,
          customBodyRender: (value) => {
            return <>{Number(value).toFixed(2) + " "}</>;
          },
        },
      },
      {
        label: orderLanguage.status,
        name: "status",
        options: {
          filter: true,
          sort: false,
          empty: true,
          customBodyRender: (value, tableMeta, updateValue) => {
            let data = this.state.order_data[tableMeta.rowIndex];
            return (
              <span
                className={`staus-span-tag-new status-${statusMapping[
                  value
                ]?.toLowerCase()}`}
                //   value == "21" || value == "2" || value == "3"
                //     ? "prepared"
                //     : value == "4"
                //     ? "ready-to-ship"
                //     : value == "5"
                //     ? "completed"
                //     : "cancelled"
                // }`}
              >
                {statusMapping[value]}
              </span>
            );
          },
        },
      },
      {
        label: orderLanguage.items,
        name: "items",
        options: {
          filter: true,
          sort: false,
          customBodyRender: (value, tableMeta, updateValue) => {
            // let id;
            // this.state.order_data && this.state.order_data.map((item) => id = item.id)
            let data = this.state.order_data[tableMeta.rowIndex];
            return (
              <>
                <div className="cust-drop hover-new position-relative">
                  <span
                    className="order-cust-name"
                    onMouseOver={() => this.getOrderItems(data.id)}
                  >
                    {value}{" "}
                    {value === 1 ? orderLanguage.item : orderLanguage.items}
                    <i className="bi bi-chevron-down ms-2"></i>
                  </span>
                  {this.state.orderItemsLoader ? (
                    <div className="hover-dropdown p-3">
                      <div className="order-items-loader">
                        <div
                          class=" spinner-border text-secondary"
                          role="status"
                        >
                          <span class="sr-only">Loading...</span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    value !== 0 && (
                      <div
                        className="hover-dropdown order-items-scroll p-3"
                        onScroll={(e) => this.ScrollItems(e)}
                      >
                        <div className="issue-comn-part">
                          {this.state.orderItemsData &&
                            this.state.orderItemsData.length > 0 &&
                            this.state.orderItemsData.map((item, i) => {
                              let img = item.image.split(",")[0];
                              if (item.quantity !== 0) {
                                return (
                                  <a href="#" className="data-view mb-3">
                                    <div className="image-box-data me-3">
                                      <img src={img} alt="" />
                                      <span className="cust-qty-span">
                                        {item.quantity}
                                      </span>
                                    </div>
                                    <div className="issue-data">
                                      <div className="red-txt text-decoration-underline">
                                        {item.title_en}
                                      </div>
                                      <div className="grey-text">
                                        {item.size_en}
                                      </div>
                                      <div className="grey-text">
                                        {item.barcode}
                                      </div>
                                    </div>
                                  </a>
                                );
                              }
                            })}
                          {this.state.orderItemDataLoader && (
                            <div className="m-auto text-center loader-spinr">
                              <div
                                class=" spinner-border text-secondary"
                                role="status"
                              >
                                <span class="sr-only">Loading...</span>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    )
                  )}
                </div>
              </>
            );
          },
        },
      },
      {
        label: orderLanguage.track,
        name: "shipping_company",
        options: {
          filter: true,
          sort: false,
          customBodyRender: (value, tableMeta, updateValue) => {
            let data = this.state.order_data[tableMeta.rowIndex];
            return (
              <a href={data.track_url && data.track_url} target="_blank">
                {value}
              </a>
            );
          },
        },
      },
      {
        label: orderLanguage.action,
        name: "id",

        options: {
          filter: true,
          sort: false,
          empty: true,
          customBodyRender: (value, tableMeta, updateValue) => {
            return (
              <Dropdown className="cust-drop">
                <Dropdown.Toggle
                  className="bg-transparent "
                  id="dropdown-basic"
                  align="end"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width={16}
                    height={16}
                    fill="currentColor"
                    className="bi bi-three-dots-vertical"
                    viewBox="0 0 16 16"
                  >
                    <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                  </svg>
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  <Dropdown.Item href={"return-order-details/" + value}>
                    <svg
                      width={19}
                      height={19}
                      viewBox="0 0 19 19"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
                        fill="#2D2D3B"
                      />
                    </svg>
                    <span>{ButtonLanguage.edit}</span>
                  </Dropdown.Item>
                  <Dropdown.Item onClick={this.edit_handleShow}>
                    <svg
                      width={19}
                      height={19}
                      viewBox="0 0 20 18"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M7 0C4.23858 0 2 2.23858 2 5C2 7.76142 4.23858 10 7 10C9.76142 10 12 7.76142 12 5C12 2.23858 9.76142 0 7 0ZM4 5C4 3.34315 5.34315 2 7 2C8.65685 2 10 3.34315 10 5C10 6.65685 8.65685 8 7 8C5.34315 8 4 6.65685 4 5Z"
                        fill="#2D2D3B"
                      ></path>
                      <path
                        d="M14.9084 5.21828C14.6271 5.07484 14.3158 5.00006 14 5.00006V3.00006C14.6316 3.00006 15.2542 3.14956 15.8169 3.43645C15.8789 3.46805 15.9399 3.50121 16 3.5359C16.4854 3.81614 16.9072 4.19569 17.2373 4.65055C17.6083 5.16172 17.8529 5.75347 17.9512 6.37737C18.0496 7.00126 17.9987 7.63958 17.8029 8.24005C17.6071 8.84053 17.2719 9.38611 16.8247 9.83213C16.3775 10.2782 15.8311 10.6119 15.2301 10.8062C14.6953 10.979 14.1308 11.037 13.5735 10.9772C13.5046 10.9698 13.4357 10.9606 13.367 10.9496C12.7438 10.8497 12.1531 10.6038 11.6431 10.2319L11.6421 10.2311L12.821 8.61557C13.0761 8.80172 13.3717 8.92477 13.6835 8.97474C13.9953 9.02471 14.3145 9.00014 14.615 8.90302C14.9155 8.80591 15.1887 8.63903 15.4123 8.41602C15.6359 8.19302 15.8035 7.92024 15.9014 7.62001C15.9993 7.31978 16.0247 7.00063 15.9756 6.68869C15.9264 6.37675 15.8041 6.08089 15.6186 5.82531C15.4331 5.56974 15.1898 5.36172 14.9084 5.21828Z"
                        fill="#2D2D3B"
                      ></path>
                      <path
                        d="M17.9981 18C17.9981 17.475 17.8947 16.9551 17.6938 16.47C17.4928 15.9849 17.1983 15.5442 16.8271 15.1729C16.4558 14.8017 16.0151 14.5072 15.53 14.3062C15.0449 14.1053 14.525 14.0019 14 14.0019V12C14.6821 12 15.3584 12.1163 16 12.3431C16.0996 12.3783 16.1983 12.4162 16.2961 12.4567C17.0241 12.7583 17.6855 13.2002 18.2426 13.7574C18.7998 14.3145 19.2417 14.9759 19.5433 15.7039C19.5838 15.8017 19.6217 15.9004 19.6569 16C19.8837 16.6416 20 17.3179 20 18H17.9981Z"
                        fill="#2D2D3B"
                      ></path>
                      <path
                        d="M14 18H12C12 15.2386 9.76142 13 7 13C4.23858 13 2 15.2386 2 18H0C0 14.134 3.13401 11 7 11C10.866 11 14 14.134 14 18Z"
                        fill="#2D2D3B"
                      ></path>
                    </svg>
                    <span>{ButtonLanguage.assign}</span>
                  </Dropdown.Item>
                  <Dropdown.Item onClick={() => this.delete_record(value)}>
                    <svg
                      width={19}
                      height={19}
                      viewBox="0 0 18 20"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
                        fill="#2D2D3B"
                      />
                    </svg>
                    <span>{orderLanguage.archived}</span>
                  </Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            );
          },
        },
      },
    ];

    const option = {
      responsive: "standard",
      searchOpen: false,
      search: false,
      searchAlwaysOpen: false,
      print: false,
      serverSide: true,
      pagination: true,
      count: this.state.totalSize,
      rowsPerPageOptions: [50, 100, 300, 500],
      customToolbarSelect: (selectedRows, displayData, setSelectedRows) => {
        return (
          <div className="btn-list-order productbtn-list">
            <Dropdown>
              <Dropdown.Toggle className="btn dropdown-toggle cust-search-button mb-0 cust-date me-sm-2 me-0">
                <span className="px-3 py-1">{productLanguage.Applyaction}</span>
              </Dropdown.Toggle>
              <Dropdown.Menu className="cust-drop-box">
                <Dropdown.Item onClick={this.changeStatus}>
                  Change Order Status
                </Dropdown.Item>
                <Dropdown.Item onClick={this.AssignTeam}>
                  Assign Team member
                </Dropdown.Item>
                {this.state.OrderStatus == "11" && (
                  <Dropdown.Item
                    onClick={() =>
                      this.handlePaymentCheck(this.state.Order_ids)
                    }
                  >
                    Check payment
                  </Dropdown.Item>
                )}
              </Dropdown.Menu>
            </Dropdown>
          </div>
        );
      },
      onTableChange: (action, state) => {
        if (action === "changePage") {
          this.setState({ page: state.page + 1, Loader: true }, () => {
            this.get_order_data(
              this.state.page,
              this.state.sizePerPage,
              this.state.OrderStatus
            );
          });
        } else if (action === "changeRowsPerPage") {
          this.setState(
            { sizePerPage: state.rowsPerPage, Loader: true },
            () => {
              this.get_order_data(
                this.state.page,
                this.state.sizePerPage,
                this.state.OrderStatus
              );
            }
          );
        } else if (action === "sort") {
          this.setState(
            {
              defaultSorted: [
                {
                  dataField: state.sortOrder.name,
                  order: state.sortOrder.direction,
                  Loader: true,
                },
              ],
            },
            () => {
              this.get_order_data(
                this.state.page,
                this.state.sizePerPage,
                this.state.OrderStatus
              );
            }
          );
        } else if (action === "rowSelectionChange") {
          let selectedRow = state.selectedRows.data;
          let PC_arr = [];
          for (let i = 0; i < this.state.order_data.length; i++) {
            let checked = selectedRow.findIndex((obj) => obj.index === i);
            if (checked != -1) {
              PC_arr.push(this.state.order_data[i].id);
            }
          }
          this.setState({ Order_ids: PC_arr });
        }
      },
      textLabels: {
        body: {
          noMatch:
            this.context.language === "english"
              ? "the order you are searching for is not found"
              : "الطلب الذي تبحث عنه غير موجود",
          toolTip: "Sort",
          columnHeaderTooltip: (column) =>
            `${productLanguage.Sortfor} ${column.label}`,
        },
        pagination: {
          next: "Next Page >",
          previous: "< Previous Page",
          rowsPerPage: "Rows per page:",
          displayRows: "of",
        },
        toolbar: {
          search: "Search",
          downloadCsv: "Download CSV",
          print: "Print",
          viewColumns: productLanguage.Viewcolumns,
          filterTable: "Filter Table",
        },
        filter: {
          all: false,
          title: false,
          reset: false,
        },
        // viewColumns: {
        //   title: "Show Column",
        //   titleAria: "Show/Hide Table Columns",
        // },
        selectedRows: {
          text: "row(s) selected",
          delete: "",
          deleteAria: "Apply action on Selected Rows",
        },
      },
      // onColumnSortChange: this.onChangeColumnSort,
      selectableRows: true,
      rowsPerPage: this.state.sizePerPage,
      onFilterConfirm: (filterList) => {},
      onFilterDialogOpen: () => {},
      onFilterDialogClose: () => {},
      filter: true,
      filterType: "custom",
      display: true,
      customFilterDialogFooter: (
        currentFilterList,
        applyNewFilters,
        filterList
      ) => {
        return (
          <div
            className="p-0 rounded-3"
            style={{
              fontFamily:
                this.context.language === "english"
                  ? "Poppins"
                  : "Noto Kufi Arabic",
            }}
          >
            <div className="row">
              <div className="col-12 form-group mt-3 d-xl-flex align-items-center">
                <label className="cust-radio mb-0">
                  <input
                    type="radio"
                    id="barcode"
                    name="filter-number"
                    onChange={this.filterType}
                    defaultChecked
                  />
                  <span className="checkmark"></span>
                  <p>{DashboardLanguage.OrderNumber}</p>
                </label>
                <label className="cust-radio mb-0 ms-xl-2">
                  <input
                    type="radio"
                    id="awb"
                    name="filter-number"
                    onChange={this.filterType}
                  />
                  <span className="checkmark"></span>
                  <p>{titleLanguage.AWBNumber}</p>
                </label>
                <label className="cust-radio mb-0 ms-xl-2">
                  <input
                    type="radio"
                    id="invoice"
                    name="filter-number"
                    onChange={this.filterType}
                  />
                  <span className="checkmark"></span>
                  <p>{ButtonLanguage.InvoiceNumber}</p>
                </label>
                <label className="cust-radio mb-0 ms-xl-2">
                  <input
                    type="radio"
                    id="phone"
                    name="filter-number"
                    onChange={this.filterType}
                  />
                  <span className="checkmark"></span>
                  <p>{titleLanguage.Phone}</p>
                </label>
              </div>
              <div className="col-12 form-group">
                <textarea
                  placeholder={productLanguage.TypeLineByLine}
                  className="form-control input-custom-class h-auto"
                  rows={5}
                  name="NumberFilter"
                  onChange={this.numberfilterChange}
                  id="barcodeInput"
                />
                {/* <div>
                  <ul className="d-flex align-items-center flex-wrap">
                    <li className="me-2 mb-3">
                      <bdi className="barcode-bg py-1 px-2 mx-2 rounded">jhdvbgdkj</bdi>
                      <mark className="bg-transparent bi bi-x p-0"></mark>
                    </li>
                  </ul>
                </div> */}
              </div>
              <div className="col-md-6 form-group">
                <label className="d-block">
                  {DashboardLanguage.CustomerName}
                </label>
                <input
                  type="text"
                  className="form-control input-custom-class"
                  placeholder={titleLanguage.EnterCustomername}
                  name="CustomerFilterName"
                  onChange={this.filterChange}
                  value={this.state.CustomerFilterName}
                />
              </div>
              <div className="col-md-6 form-group">
                <label className="d-block">{orderLanguage.orderStatus}</label>
                <select
                  className="form-select input-custom-class"
                  name="OrderStatus"
                  onChange={this.filterChange}
                  value={this.state.OrderStatus}
                >
                  <option value="">Select status</option>
                  <option value="1">{DashboardLanguage.Pending}</option>
                  <option value="2">{orderLanguage.prepared}</option>
                  <option value="3">{orderLanguage.readyToShip}</option>
                  <option value="4">{orderLanguage.shipped}</option>
                  <option value="5">{orderLanguage.delivered}</option>
                  <option value="6">{orderLanguage.cancelled}</option>
                  <option value="7">{orderLanguage.archived}</option>
                  <option value="8">{titleLanguage.Returned}</option>
                  <option value="9">{titleLanguage.PartiallyReturned}</option>
                  <option value="10">{titleLanguage.Refund}</option>
                  <option value="11">{titleLanguage.PendingPayment}</option>
                  <option value="12">{titleLanguage.Disputed}</option>
                </select>
              </div>
              <div className="col-md-6 form-group">
                <label className="d-block">{ButtonLanguage.CustomerCity}</label>
                <select
                  className="form-select input-custom-class"
                  name="CustomerFilterCity"
                  onChange={this.filterChange}
                  value={this.state.CustomerFilterCity}
                >
                  <option value="">{ButtonLanguage.Selectcity}</option>
                  {this.state.AllCity.length > 0 &&
                    this.state.AllCity.map((item) => {
                      return <option value={item.id}>{item.english}</option>;
                    })}
                </select>
              </div>
              <div className="col-md-6 form-group">
                <label className="d-block">{userLanguage.Area}</label>
                <select
                  className="form-select input-custom-class"
                  name="CustomerFilterArea"
                  onChange={this.filterChange}
                  value={this.state.CustomerFilterArea}
                >
                  <option defaultValue>{userLanguage.SelectArea}</option>
                  {this.state.AllArea.length > 0 &&
                    this.state.AllArea.map((item) => {
                      return <option value={item.id}>{item.english}</option>;
                    })}
                </select>
              </div>
              <div className="col-md-6 form-group">
                <label className="d-block">{userLanguage.Email}</label>
                <input
                  type="email"
                  className="form-control input-custom-class"
                  placeholder="Enter customer Email Address"
                  name="CustomerFilterEmail"
                  value={this.state.CustomerFilterEmail}
                  onChange={this.filterChange}
                />
              </div>
              {/* <div className="col-md-6 form-group">
                <label className="d-block">Return Status</label>
                <select className="form-select input-custom-class" >
                  <option defaultValue>Select Return Status</option>
                  <option value="">
                  </option>
                </select>
              </div> */}
              <div className="col-md-6 form-group">
                <label className="d-block">
                  {orderLanguage.shippingMethod}
                </label>
                <select
                  className="form-select input-custom-class"
                  name="CustomerFilterShippingCompany"
                  onChange={this.filterChange}
                  value={this.state.CustomerFilterShippingCompany}
                >
                  <option defaultValue>Select Shipping method</option>
                  <option value=""></option>
                </select>
              </div>
              <div className="col-md-6 form-group">
                <label className="d-block">{orderLanguage.paymentMethod}</label>
                <select
                  className="form-select input-custom-class"
                  name="customFilterPaymentMethod"
                  onChange={this.filterChange}
                  value={this.state.customFilterPaymentMethod}
                >
                  <option defaultValue>Select Payment method</option>
                  {paymentMethods.map((item) => {
                    return (
                      <option key={item.id} value={item.id}>
                        {item.name}
                      </option>
                    );
                  })}
                </select>
              </div>
              <div className="col-md-6 form-group">
                <label className="d-block">{productLanguage.taggedWith}</label>
                <input
                  type="text"
                  className="form-control input-custom-class"
                  placeholder="Enter tag"
                />
              </div>
              <div className="col-md-6 form-group">
                <label className="d-block">
                  {userLanguage.PaymentprocessID}
                </label>
                <input
                  type="text"
                  className="form-control input-custom-class"
                  placeholder="Enter payment process id"
                />
              </div>
              <div className="col-md-6 form-group">
                <label className="d-block">{productLanguage.FromDate}</label>
                <DatePicker
                  name="CustomerFilterFromDate"
                  className="form-control input-custom-class"
                  onChange={this.filterStartDateChange}
                  value={this.state.CustomerFilterFromDate}
                  placeholderText="YYYY-MM-DD"
                />
              </div>
              <div className="col-md-6 form-group">
                <label className="d-block">{productLanguage.ToDate}</label>
                <DatePicker
                  name="CustomerFilterToDate"
                  className="form-control input-custom-class"
                  onChange={this.filterEndDateChange}
                  value={this.state.CustomerFilterToDate}
                  placeholderText="YYYY-MM-DD"
                />
              </div>
              <div className="col-12 form-group text-center mt-5">
                <button
                  type="button"
                  className="btn red-btn"
                  onClick={() =>
                    this.get_order_data(
                      this.state.page,
                      this.state.sizePerPage,
                      this.state.OrderStatus
                    )
                  }
                >
                  {productLanguage.filter}
                </button>
                <button
                  type="button"
                  className="btn red-btn mx-3"
                  onClick={this.clearFilter}
                >
                  {productLanguage.clearAll}
                </button>
              </div>
            </div>
          </div>
        );
      },
    };

    return (
      <Adminlayout>
        {this.state.Loader && (
          <div className="loader-main">
            <div className="loader-inr">
              <img src={loader} alt="" />
            </div>
          </div>
        )}
        <div className="container-fluid return-orders-list-container">
          <div className="row common-space align-items-center">
            <div className="col-6  text-start rtl-txt-start">
              <div className="common-header-txt">
                <h3>{titleLanguage.returnOrders}</h3>
              </div>
            </div>
            {/* <div className="col-6  text-end rtl-txt-end">
              <div className="common-red-btn">
                <a href="#" className="btn red-btn">
                  {ButtonLanguage.exportList}
                </a>
              </div>
            </div> */}
          </div>

          <div className="row common-space">
            <div className="col-md-12">
              <div className="white-box">
                <div className="order-tabs-new">
                  {/* <div className="comn-order-lbl">
                    <input type="radio" id="all-order" name="order-list" onChange={this.selectSatus} defaultChecked />
                    <label className="d-flex align-items-center" htmlFor="all-order">
                      <bdi>All Orders</bdi>
                      <span>95326</span>
                    </label>
                  </div> */}
                  {this.state.Order_Tab.length > 0 &&
                    this.state.Order_Tab.map((item) => {
                      return (
                        <div className="comn-order-lbl">
                          <input
                            type="radio"
                            id={item.id}
                            name="order-list"
                            onChange={this.selectSatus}
                          />
                          <label
                            className="d-flex align-items-center"
                            htmlFor={item.id}
                          >
                            <bdi>
                              {" "}
                              {this.context.language === "english"
                                ? item.labelEng
                                : item.labelArb}
                            </bdi>
                            <span>{item.count}</span>
                          </label>
                        </div>
                      );
                    })}
                  {/* <div className="comn-order-lbl">
                    <input type="radio" id="prepared" name="order-list" onChange={this.selectSatus} />
                    <label className="d-flex align-items-center" htmlFor="prepared">
                      <bdi>prepared</bdi>
                      <span>95326</span>
                    </label>
                  </div>
                  <div className="comn-order-lbl">
                    <input type="radio" id="ready-to-ship" name="order-list" onChange={this.selectSatus} />
                    <label className="d-flex align-items-center" htmlFor="ready-to-ship">
                      <bdi>ready to ship</bdi>
                      <span>95326</span>
                    </label>
                  </div>
                  <div className="comn-order-lbl">
                    <input type="radio" id="shipped" name="order-list" onChange={this.selectSatus} />
                    <label className="d-flex align-items-center" htmlFor="shipped">
                      <bdi>shipped</bdi>
                      <span>95326</span>
                    </label>
                  </div>
                  <div className="comn-order-lbl">
                    <input type="radio" id="delivered" name="order-list" onChange={this.selectSatus} />
                    <label className="d-flex align-items-center" htmlFor="delivered">
                      <bdi>delivered</bdi>
                      <span>95326</span>
                    </label>
                  </div>
                  <div className="comn-order-lbl">
                    <input type="radio" id="cancelled" name="order-list" onChange={this.selectSatus} />
                    <label className="d-flex align-items-center" htmlFor="cancelled">
                      <bdi>cancelled</bdi>
                      <span>95326</span>
                    </label>
                  </div>
                  <div className="comn-order-lbl">
                    <input type="radio" id="archieved" name="order-list" onChange={this.selectSatus} />
                    <label className="d-flex align-items-center" htmlFor="archieved">
                      <bdi>archieved</bdi>
                      <span>95326</span>
                    </label>
                  </div> */}
                  <div className="comn-order-lbl">
                    <Dropdown className="cust-drop">
                      <Dropdown.Toggle
                        className="bg-transparent "
                        id="dropdown-basic"
                        align="end"
                      >
                        {/* <input type="radio" id="more" name="order-list" /> */}
                        {/* <label className="d-flex align-items-center" htmlFor="more"> */}
                        <bdi>{productLanguage.More}</bdi>
                        {/* </label> */}
                      </Dropdown.Toggle>
                      <Dropdown.Menu>
                        <Dropdown.Item
                          id="returned"
                          onClick={(e) => this.selectSatus(e)}
                        >
                          {titleLanguage.Returned}
                        </Dropdown.Item>
                        <Dropdown.Item
                          id="partially-returned"
                          onClick={(e) => this.selectSatus(e)}
                        >
                          {titleLanguage.PartiallyReturned}
                        </Dropdown.Item>
                        <Dropdown.Item
                          id="archieved"
                          onClick={(e) => this.selectSatus(e)}
                        >
                          {titleLanguage.Archieved}
                        </Dropdown.Item>
                        {/* <Dropdown.Item id="refund" onClick={(e) => this.selectSatus(e)}>
                          {titleLanguage.Refund}
                        </Dropdown.Item> */}
                        <Dropdown.Item
                          id="panding-payment"
                          onClick={(e) => this.selectSatus(e)}
                        >
                          {titleLanguage.PendingPayment}
                        </Dropdown.Item>
                        <Dropdown.Item
                          id="disputed"
                          onClick={(e) => this.selectSatus(e)}
                        >
                          {titleLanguage.Disputed}
                        </Dropdown.Item>
                      </Dropdown.Menu>
                    </Dropdown>
                  </div>
                </div>
                <>
                  {/* <div className="btn-list-order">
                  <button
                    className="btn white-btn me-sm-2 me-0"
                    onClick={this.filter_handleShow}
                  >
                    {orderLanguage.filter}{" "}
                    <i className="bi bi-caret-down-fill ms-2" />
                  </button>
                  <Dropdown>
                    <Dropdown.Toggle className="btn dropdown-toggle cust-search-button mb-0 cust-date me-sm-2 me-0">
                      <span>{orderLanguage.selectDate}</span>
                    </Dropdown.Toggle>
                    <Dropdown.Menu className="cust-drop-box fix-box-drop">
                      <div className="row m-0">
                        <div className="col-md-6 form-group pe-0">
                          <label>{orderLanguage.From}</label>
                          <input type="date" className="form-control" />
                        </div>
                        <div className="col-md-6 form-group">
                          <label>{orderLanguage.To}</label>
                          <input type="date" className="form-control" />
                        </div>
                        <div className="col-12">
                          <div
                            className="btn-group pt-3 pb-3 d-block"
                            role="group"
                            aria-label="Basic radio toggle button group"
                          >
                            <ul>
                              <li>
                                <input
                                  type="radio"
                                  className="btn-check date-checked"
                                  name="btnradio"
                                  id="btnradio1"
                                  autoComplete="off"
                                  defaultChecked
                                />
                                <label
                                  className="btn gray-btn-date w-100"
                                  htmlFor="btnradio1"
                                >
                                  {orderLanguage.today}
                                </label>
                              </li>
                              <li>
                                <input
                                  type="radio"
                                  className="btn-check date-checked"
                                  name="btnradio"
                                  id="btnradio2"
                                  autoComplete="off"
                                />
                                <label
                                  className="btn gray-btn-date w-100"
                                  htmlFor="btnradio2"
                                >
                                  {orderLanguage.yesterday}
                                </label>
                              </li>
                              <li>
                                <input
                                  type="radio"
                                  className="btn-check date-checked"
                                  name="btnradio"
                                  id="btnradio3"
                                  autoComplete="off"
                                />
                                <label
                                  className="btn gray-btn-date w-100"
                                  htmlFor="btnradio3"
                                >
                                  {orderLanguage.last_3_Months}
                                </label>
                              </li>

                              <li>
                                <input
                                  type="radio"
                                  className="btn-check date-checked"
                                  name="btnradio"
                                  id="btnradio4"
                                  autoComplete="off"
                                />
                                <label
                                  className="btn gray-btn-date w-100"
                                  htmlFor="btnradio4"
                                >
                                  {orderLanguage.thisYears}
                                </label>
                              </li>
                            </ul>
                          </div>
                          <div className="col-12 text-center">
                            <div className="common-red-btn">
                              <a href="#" className="btn black-btn me-2">
                                {ButtonLanguage.cancel}
                              </a>
                              <a href="add-admin" className="btn red-btn">
                                {ButtonLanguage.update}
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Dropdown.Menu>
                  </Dropdown>
                  <Dropdown>
                    <Dropdown.Toggle className="btn dropdown-toggle cust-search-button mb-0 cust-date me-sm-2 me-0">
                      <span>{orderLanguage.status}</span>
                    </Dropdown.Toggle>
                    <Dropdown.Menu className="cust-drop-box cust-status">
                      <div className="row m-0">
                        <div className="col-md-12">
                          <div className="position-relative">
                            <input
                              className="form-control"
                              type="search"
                              placeholder={orderLanguage.search}
                            />
                          </div>
                          <div className="drop-body-cust">
                            <ul className="mt-3 mb-3">
                              <li>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    {orderLanguage.shipped}
                                  </label>
                                </div>
                              </li>
                              <li>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    {orderLanguage.readyToShip}
                                  </label>
                                </div>
                              </li>
                              <li>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    {orderLanguage.delivered}
                                  </label>
                                </div>
                              </li>
                              <li>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    {orderLanguage.cancelled}
                                  </label>
                                </div>
                              </li>
                              <li>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    {orderLanguage.pendingPayment}
                                  </label>
                                </div>
                              </li>
                              <li>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    {orderLanguage.refunded}
                                  </label>
                                </div>
                              </li>
                              <li>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    {orderLanguage.returning}
                                  </label>
                                </div>
                              </li>
                              <li>
                                <div className="cust-checkbox-new">
                                  <label className="cust-chk-bx">
                                    <input type="checkbox" />
                                    <span className="cust-chkmark" />
                                    {orderLanguage.archived}
                                  </label>
                                </div>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </Dropdown.Menu>
                  </Dropdown>
                </div> */}
                </>
                <div className="custom-table">
                  <div className=" dataTables_wrapper no-footer">
                    {this.state.order_data && (
                      <MuiThemeProvider theme={theme}>
                        <div className="right-menu table-over-fix-class ms-auto position-relative">
                          <MUITable
                            data={this.state.order_data}
                            columns={columns}
                            options={option}
                          />
                          <div className="fix-search d-flex align-items-center">
                            <div
                              className="position-relative search-md-screen"
                              id="search-menu"
                            >
                              <input
                                type="search"
                                name="search"
                                className="form-control top-search ps-5 input-custom-class mb-0"
                                placeholder={orderLanguage.searchPlaceholder}
                                onChange={this.handleSearch}
                              />
                              <span className="search-icn position-absolute ms-3">
                                <img src={SearchIcon} alt="" />
                              </span>
                            </div>
                            {/* <button className="border-0 bg-transparent dark-red-txt w-100">Clear Filter x</button> */}
                          </div>
                        </div>
                      </MuiThemeProvider>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ------------------------modal-------------------------- */}
        <Modal
          dialogClassName="modal-dialog-centered cust-width-modal"
          className="edit-user-modal cust-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.search_show}
          onHide={this.edit_filterClose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">{orderLanguage.filter}</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.edit_filterClose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <form className="row modal-form">
              <div className="col-md-12 form-group text-end mb-3">
                <a href="#" className="red-underline">
                  {orderLanguage.reset}
                </a>
              </div>
              <div className="col-md-6 form-group">
                <label>{orderLanguage.status}</label>
                <select className="form-control form-select">
                  <option>All</option>
                  <option>{DashboardLanguage.Completed}</option>
                  <option>{DashboardLanguage.Pending}</option>
                  <option>{DashboardLanguage.Cancelled}</option>
                </select>
              </div>
              <div className="col-md-6 form-group">
                <label>{orderLanguage.city}</label>
                <Dropdown>
                  <Dropdown.Toggle className="btn dropdown-toggle cust-search-button w-100">
                    <span>New York</span>
                  </Dropdown.Toggle>
                  <Dropdown.Menu className="w-100 cust-drop-box">
                    <div className="u-search-dw">
                      <div className="sear-u-inp p-2 bg-transparent">
                        <div className="position-relative">
                          <input
                            className="form-control"
                            type="search"
                            placeholder={orderLanguage.search}
                          />
                        </div>
                        <div className="drop-body-cust">
                          <ul>
                            <li>
                              <span>New York</span>
                            </li>
                            <li>
                              <span>Austin</span>
                            </li>
                            <li>
                              <span>Columbus</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </Dropdown.Menu>
                </Dropdown>
              </div>
              <div className="col-md-6 form-group">
                <label>{orderLanguage.shippingMethod}</label>
                <select className="form-control form-select">
                  <option>Aramex</option>
                  <option>Libsi Markah</option>
                  <option>UPs Shipping</option>
                  <option>Shipa</option>
                </select>
              </div>
              <div className="col-md-6 form-group">
                <label>{orderLanguage.paymentMethod}</label>
                <select className="form-control form-select">
                  <option>Paypal</option>
                  <option>Google Pay</option>
                  <option>Credit Card</option>
                  <option>COD</option>
                </select>
              </div>
              <div className="col-md-12 form-group text-center mb-3">
                <button type="button" className="btn red-btn">
                  {ButtonLanguage.save}
                </button>
              </div>
            </form>
          </Modal.Body>
        </Modal>

        {/* status order */}
        <Modal
          dialogClassName="modal-dialog-centered edit-user-modal cust-modal"
          size="md"
          show={this.state.changeStatus}
          onHide={this.changeStatusClose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">Change Order Status </h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.changeStatusClose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <form className="row">
              <div className="col-12 form-group">
                <select className="form-select input-custom-class">
                  <option value="">Select status</option>
                  <option value="0">{orderLanguage.prepared}</option>
                  <option value="1">{orderLanguage.readyToShip}</option>
                  <option value="2">{orderLanguage.shipped}</option>
                  <option value="3">{orderLanguage.delivered}</option>
                  <option value="4">{DashboardLanguage.Pending}</option>
                  <option value="5">{orderLanguage.cancelled}</option>
                  <option value="6">{orderLanguage.archived}</option>
                </select>
              </div>
              <div className="col-12 ">
                <button className="btn red-btn w-100">APPLY</button>
              </div>
            </form>
          </Modal.Body>
        </Modal>

        <Modal
          dialogClassName="modal-dialog-centered edit-user-modal cust-modal"
          size="md"
          show={this.state.AssignTeam}
          onHide={this.AssignTeamClose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">Assign Team Member</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.AssignTeamClose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <form className="row">
              <div className="col-12 form-group">
                <select className="form-select input-custom-class">
                  <option value="">Select team member name</option>
                  <option value="0">team name</option>
                </select>
              </div>
              <div className="col-12 ">
                <button className="btn red-btn w-100">APPLY</button>
              </div>
            </form>
          </Modal.Body>
        </Modal>

        <Modal
          dialogClassName="modal-dialog-centered edit-user-modal cust-modal payment-statu-popup"
          size="md"
          show={this.state.paymentcheckpopup}
          onHide={this.PaymentCheckModalClose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">Payment Status</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.PaymentCheckModalClose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            {this.state.paymentCheckedloader ? (
              <div className="loader-main position-absolute">
                <div className="loader-inr">
                  <img src={loader} alt="" />
                </div>
              </div>
            ) : (
              <div className="row">
                <div className="col-12 position-relative">
                  <div>
                    <div className="form-group pb-3 mt-2">
                      <div className="table-responsive table-custom-info">
                        <table className="table">
                          <thead>
                            <tr>
                              <th>Order ID</th>
                              <th>Message</th>
                            </tr>
                          </thead>
                          <tbody>
                            {this.state.paymentCheckedData.length > 0 &&
                              this.state.paymentCheckedData.map((item, i) => {
                                return (
                                  <tr>
                                    <td>{item.orderid}</td>
                                    <td>{item.message}</td>
                                  </tr>
                                );
                              })}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </Modal.Body>
          <ModalFooter>
            <div class="form-group pb-0 my-0 mx-auto">
              <div class="text-md-end text-center">
                <button
                  type="submit"
                  class="red-btn ms-3"
                  onClick={this.PaymentCheckModalClose}
                >
                  Ok
                </button>
              </div>
            </div>
          </ModalFooter>
        </Modal>
      </Adminlayout>
    );
  }
}

export default ReturnOrders;
