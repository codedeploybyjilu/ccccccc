import React, { Component } from 'react'
import Adminlayout from '../../Components/AdminLayout/Adminlayout'
import { APIBaseUrl, API_Path, marketingArabic, marketingEnglish, buttonArabic, buttonEnglish, LIVE_FILE_URL } from "../../const";
import LanguageContext from "../../contexts/languageContext";
import { Modal } from "react-bootstrap"
import { PostApi } from "../../helper/APIService";
import toastr from "toastr";

let dataToAdd = [];
let Custdata = [];
export class AddBundleDiscount extends Component {
    static contextType = LanguageContext;

    constructor(props) {
        super(props)
        this.state = {
            specificProductsShow: false,
            specificProductsPage: 1,
            SpecificProductsData: [],
            selectedData: [],
            selectedDataCustomer: []
        }
    }

    getSpecificProducts = () => {
        this.setState({ searchSpecificProducts: '' },)
        let data = {
            page: this.state.specificProductsPage,
            sizePerPage: 10
        };

        let path = API_Path.getSpecificProducts;
        const getSpecificProductsPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        getSpecificProductsPromise.then((res) => {
            if (res) {
                this.setState({ SpecificProductsData: res.data.data });
            }
        });
    };

    handleProductsSearch = (e) => {
        this.setState({ searchSpecificProducts: e.target.value })

        let data = {
            search_val: e.target.value,
            page: 1,
            sizePerPage: 10
        };

        let path = API_Path.getSpecificProducts;
        const getSpecificProductsPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        getSpecificProductsPromise.then((res) => {
            if (res) {
                this.setState({ SpecificProductsData: res.data.data });
            }
        });
    };

    specificProductsClose = () => {
        this.setState({ specificProductsShow: false });
    };


    handleBrowse1Submit = () => {
        this.getSpecificProducts()
        this.setState({ specificProductsShow: true });

    };

    specificProductsCustomerClose = () => {
        this.setState({ specificProductsCustomerShow: false });
    };


    handleBrowse2Submit = () => {
        this.getSpecificProducts()
        this.setState({ specificProductsCustomerShow: true });

    };



    loadMoreSpecificProducts = () => {
        this.setState({ specificProductsPage: this.state.specificProductsPage + 1, loadmoreLoader: true }, () => {
            let data;
            if (this.state.searchSpecificProducts !== '') {
                data = {
                    page: this.state.specificProductsPage,
                    sizePerPage: 10,
                    search_val: this.state.searchSpecificProducts
                };
            } else {
                data = {
                    page: this.state.specificProductsPage,
                    sizePerPage: 10,
                }
            }
            let path = API_Path.getSpecificProducts;
            const getSpecificProductsPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getSpecificProductsPromise.then((res) => {
                if (res.data.data.length > 0) {

                    this.setState({ SpecificProductsData: [...this.state.SpecificProductsData, ...res.data.data], loadmoreLoader: false });
                } else {
                    this.setState({ loadmoreLoader: false })
                }
            });

        })
    }

    handleCheckboxChange = (e, data) => {
        if (e.target.checked) {
            dataToAdd.push(data);
        } else {
            const idToRemove = data.id;
            const filteredData = dataToAdd.filter((item) => item.id !== idToRemove);
            dataToAdd = filteredData;
        }
    };

    handleAdd = () => {
        if (dataToAdd.length > 0) {
            this.specificProductsClose();
            this.setState(
                {
                    selectedData: dataToAdd,
                    selectedCategoryData: [],
                    // selectedCategoryDataArray: [],
                },
                () => {

                }
            );
        } else {
            toastr.error("Please Select items");
        }
    };

    handleCancel = (data) => {
        const idToRemove = data.id;

        const filteredData = this.state.selectedData.filter((item) => item.id !== idToRemove);
        dataToAdd = filteredData;
        this.setState({ selectedData: filteredData }, () => {
            if (filteredData.length == 0) {
                // document.getElementById("Browse1-validate").style.display = "block";
            }
        });
    };

    handleCheckboxCustChange = (e, data) => {
        if (e.target.checked) {
            Custdata.push(data);
        } else {
            const idToRemove = data.id;
            const filteredData = Custdata.filter((item) => item.id !== idToRemove);
            Custdata = filteredData;
        }
    };

    handleCustAdd = () => {
        if (Custdata.length > 0) {
            this.specificProductsCustomerClose();
            this.setState(
                {
                    selectedDataCustomer: Custdata,
                    selectedCategoryData: [],
                    // selectedCategoryDataArray: [],
                },
                () => {

                }
            );
        } else {
            toastr.error("Please Select items");
        }
    };

    handleCustCancel = (data) => {
        const idToRemove = data.id;

        const filteredData = this.state.selectedDataCustomer.filter((item) => item.id !== idToRemove);
        Custdata = filteredData;
        this.setState({ selectedDataCustomer: filteredData }, () => {
            if (filteredData.length == 0) {
                // document.getElementById("Browse1-validate").style.display = "block";
            }
        });
    };

    render() {
        let marketingLanguage = this.context.language === "english" ? marketingEnglish : marketingArabic;
        let buttonLanguage = this.context.language === "english" ? buttonEnglish : buttonArabic;
        return (
            <Adminlayout>
                <div className='container-fluid'>
                    <div className='row common-space'>
                        <div className="col-8">
                            <div className="common-header-txt">
                                <h3>{marketingLanguage.AddBundle}</h3>
                            </div>
                        </div>
                        <div className="col-4 text-end">
                            <div className="d-inline-flex align-items-center cust-switch-drop border-0 p-0">
                                <label className="switch ms-auto">
                                    <input type="checkbox" name="slider" defaultChecked value="slider" onChange={this.handleSlider} />
                                    <div className="slider round" />
                                </label>
                            </div>
                        </div>
                    </div>
                    <div className='row common-space'>
                        <div className='col-12'>
                            <div className='pb-4'>
                                <div className='white-box'>
                                    <div className='row custom-border-title'>
                                        <div className='col-12'>
                                            <div className='product-header'>
                                                <span>{marketingLanguage.discountDetails}</span><bdi className='grey-text ms-2'> ({marketingLanguage.discountInfo})</bdi>
                                            </div>
                                        </div>
                                    </div>
                                    <form className='row mt-3'>
                                        <div className='col-md-6 mb-3 mb-md-0 form-group'>
                                            <label className='mb-2 lbl-bdi-inr-class'>{marketingLanguage.discountTitle}</label>
                                            <input type="text" className='form-control input-custom-class text-uppercase' />
                                        </div>
                                        <div className='col-md-6 mb-3 mb-md-0 form-group'>
                                            <label className='mb-2 lbl-bdi-inr-class'>{marketingLanguage.maxNumberOfUses}</label>
                                            <input type="text" className='form-control input-custom-class text-uppercase' />
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div className='col-lg-6'>
                            <div className='pb-4'>
                                <div className='white-box'>
                                    <div className='row custom-border-title'>
                                        <div className='col-12'>
                                            <div className='product-header'>
                                                <span>{marketingLanguage.customerBuys}</span>
                                            </div>
                                        </div>
                                    </div>
                                    <form className='row mt-3'>
                                        <div className='col-lg-6 mb-3 form-group'>
                                            <label className='mb-2 lbl-bdi-inr-class'>{marketingLanguage.minQuanity}</label>
                                            <input type="number" className='form-control input-custom-class text-uppercase' />
                                        </div>
                                        <div className='col-lg-6 mb-3 form-group'>
                                            <label className='mb-2 lbl-bdi-inr-class'>{marketingLanguage.anyItemFrom}</label>
                                            <select className='form-select form-control input-custom-class'>
                                                <option>Specific products</option>
                                            </select>
                                        </div>
                                        <div className='col-12 mb-3 form-group'>
                                            <div className="d-flex align-items-center">
                                                <div className="w-100 src-with-btn-class position-relative">
                                                    <label className="mb-1 lbl-bdi-inr-class">Select Specific Product:</label>
                                                </div>
                                                <div className="ps-3 src-with-btn-class-inr">
                                                    <button type="button" name="Browse1" onClick={this.handleBrowse1Submit}>
                                                        {marketingLanguage.Browse}
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-12 form-group pb-3 mt-2">
                                            <div className="table-responsive">
                                                {this.state.selectedData.length > 0 && (
                                                    <table className="table">
                                                        <thead>
                                                            <tr>
                                                                <th>Items</th>
                                                                <th>Barcode</th>
                                                                <th>Name</th>
                                                                <th></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            {this.state.selectedData.map((data, i) => (
                                                                <tr key={i}>
                                                                    <td>
                                                                        {" "}
                                                                        <img src={data.thumbnail} alt="image" className="imgfix-smpl-tbl" />
                                                                    </td>
                                                                    <td>{data.barcode}</td>
                                                                    <td>{data.title_en}</td>
                                                                    <td className="text-end">
                                                                        <button type="button" className="p-0 bg-transparent border-0" onClick={() => this.handleCancel(data)}>
                                                                            <i className="bi bi-x-lg"></i>
                                                                        </button>
                                                                    </td>
                                                                </tr>
                                                            ))}
                                                        </tbody>
                                                    </table>
                                                )}
                                            </div>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                        <div className='col-lg-6'>
                            <div className='pb-4'>
                                <div className='white-box'>
                                    <div className='row custom-border-title'>
                                        <div className='col-12'>
                                            <div className='product-header'>
                                                <span>{marketingLanguage.customerGets}</span><bdi className='grey-text ms-2'>({marketingLanguage.customerInfo})</bdi>
                                            </div>
                                        </div>
                                    </div>
                                    <form className='row mt-3'>
                                        <div className='col-lg-6 mb-3 form-group'>
                                            <label className='mb-2 lbl-bdi-inr-class'>{marketingLanguage.minQuanity}</label>
                                            <input type="number" className='form-control input-custom-class text-uppercase' />
                                        </div>
                                        <div className='col-lg-6 mb-3 form-group'>
                                            <label className='mb-2 lbl-bdi-inr-class'>{marketingLanguage.anyItemFrom}</label>
                                            <select className='form-select form-control input-custom-class'>
                                                <option>Specific products</option>
                                            </select>
                                        </div>
                                        <div className='col-12 mb-3 form-group'>
                                            <div className="d-flex align-items-center">
                                                <div className="w-100 src-with-btn-class position-relative">
                                                    <label className="mb-1 lbl-bdi-inr-class">Select Specific Product:</label>
                                                </div>
                                                <div className="ps-3 src-with-btn-class-inr">
                                                    <button type="button" name="Browse1" onClick={this.handleBrowse2Submit}>
                                                        {marketingLanguage.Browse}
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-12 form-group pb-3 mt-2">
                                            <div className="table-responsive">
                                                {this.state.selectedDataCustomer.length > 0 && (
                                                    <table className="table">
                                                        <thead>
                                                            <tr>
                                                                <th>Items</th>
                                                                <th>Barcode</th>
                                                                <th>Name</th>
                                                                <th></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            {this.state.selectedDataCustomer.map((data, i) => (
                                                                <tr key={i}>
                                                                    <td>
                                                                        {" "}
                                                                        <img src={data.thumbnail} alt="image" className="imgfix-smpl-tbl" />
                                                                    </td>
                                                                    <td>{data.barcode}</td>
                                                                    <td>{data.title_en}</td>
                                                                    <td className="text-end">
                                                                        <button type="button" className="p-0 bg-transparent border-0" onClick={() => this.handleCustCancel(data)}>
                                                                            <i className="bi bi-x-lg"></i>
                                                                        </button>
                                                                    </td>
                                                                </tr>
                                                            ))}
                                                        </tbody>
                                                    </table>
                                                )}
                                            </div>
                                        </div>
                                        <div className='form-group col-12'>
                                            <label className="mb-1 lbl-bdi-inr-class">{marketingLanguage.atADiscount}</label>
                                            <div className='d-flex align-items-center justify-content-around'>
                                                <label className="cust-radio mb-0 me-3">
                                                    <input type="radio" id="free" value="free" name="discount" defaultChecked />
                                                    <span className="checkmark"></span>
                                                    <span>{marketingLanguage.free} </span>
                                                </label>
                                                <label className="cust-radio mb-0 me-3">
                                                    <input type="radio" id="percentage" value="percentage" name="discount" />
                                                    <span className="checkmark"></span>
                                                    <span>{marketingLanguage.percentage} </span>
                                                </label>
                                                <input type="number" className='form-control input-custom-class mb-0' />
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div className='col-12  pb-3'>
                            <div className='white-box'>
                                <div className='row custom-border-title'>
                                    <div className='col-12'>
                                        <div className='product-header'>
                                            <span>{marketingLanguage.Activedates}</span>
                                        </div>
                                    </div>
                                </div>
                                <form className='row mt-3'>
                                    <div className='col-lg-6'>
                                        <div className='row'>
                                            <div className='col-6 mb-3 form-group'>
                                                <label className="mb-2 lbl-bdi-inr-class">{marketingLanguage.Startdate}</label>
                                                <input type="date" name="startdate" className="form-control input-custom-class" />
                                            </div>
                                            <div className='col-6 mb-3  form-group'>
                                                <label className="mb-2 lbl-bdi-inr-class">{marketingLanguage.Starttime}</label>
                                                <input type="time" name="starttime" className="form-control input-custom-class" />
                                            </div>
                                        </div>
                                    </div>
                                    <div className='col-lg-6'>
                                        <div className='row'>
                                            <div className='col-6 mb-3 form-group'>
                                                <label className="mb-2 lbl-bdi-inr-class">{marketingLanguage.EndDate}</label>
                                                <input type="date" name="enddate" className="form-control input-custom-class" />
                                            </div>
                                            <div className='col-6 mb-3  form-group'>
                                                <label className="mb-2 lbl-bdi-inr-class">{marketingLanguage.EndTime}</label>
                                                <input type="time" name="endtime" className="form-control input-custom-class" />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-12">
                                        <label className="cust-chk-bx">
                                            <input name="sizeArabic4" type="checkbox" />
                                            <span className="cust-chkmark"></span>
                                            <bdi>{marketingLanguage.setEndDate}</bdi>
                                        </label>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div className='col-12'>
                            <div className="text-md-end text-center pb-3">
                                <button type="button" id="Cancel" className="black-btn">
                                    {buttonLanguage.cancel}
                                </button>
                                <button type="submit" id="Submit" className="red-btn ms-3">
                                    {buttonLanguage.save}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <Modal
                    dialogClassName="modal-dialog-centered cust-width-modal modal-dialog-scrollable"
                    className="edit-user-modal cust-modal"
                    ref={(el) => {
                        this.dialog = el;
                    }}
                    show={this.state.specificProductsShow}
                    onHide={this.specificProductsClose}
                >
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">{marketingLanguage.SelectSpecificProducts}</h1>
                        </Modal.Title>
                        <button type="button" onClick={this.specificProductsClose} className="close btn-close"></button>
                    </Modal.Header>
                    <Modal.Body>
                        <div className="white-box cuts-popup-tbl p-0">
                            <div className="form-group pb-3">
                                <div className="d-flex align-items-center">
                                    <div className="w-100 src-with-btn-class position-relative">
                                        <input type="text" name="" className="form-control input-custom-class mb-0" placeholder={marketingLanguage.searchCategories} onChange={this.handleProductsSearch} />
                                        <span className="position-absolute">
                                            <i className="bi bi-search"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div className="form-group text-center pb-3 mt-2">
                                <div className="table-responsive">
                                    <table className="table">
                                        <thead>
                                            <tr>
                                                <th></th>
                                                <th>item</th>
                                                <th>Barcode</th>
                                                <th>Name</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {this.state.SpecificProductsData &&
                                                this.state.SpecificProductsData.map((data, i) => (
                                                    <tr key={i}>
                                                        <td>
                                                            <label className="cust-chk-bx">
                                                                <input name="" type="checkbox" onChange={(e) => this.handleCheckboxChange(e, data)} />
                                                                <span className="cust-chkmark"></span>
                                                            </label>
                                                        </td>
                                                        <td>
                                                            {" "}
                                                            <img src={data.thumbnail} alt="image" className="imgfix-smpl-tbl" />
                                                        </td>
                                                        <td>{data.barcode}</td>
                                                        <td>{data.title_en}</td>
                                                    </tr>
                                                ))}
                                        </tbody>
                                    </table>
                                </div>
                                <button type="button" className="red-btn align-item-center mt-3" onClick={this.loadMoreSpecificProducts}>
                                    {this.state.loadmoreLoader ? 'Loading....' : 'LoadMoreProduct'}
                                </button>
                            </div>
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <div className="form-group mx-auto">
                            <div className="text-center">
                                <button type="submit" className="red-btn " name="add" onClick={this.handleAdd}>
                                    {marketingLanguage.add}
                                </button>
                            </div>
                        </div>
                    </Modal.Footer>
                </Modal>

                <Modal
                    dialogClassName="modal-dialog-centered cust-width-modal modal-dialog-scrollable"
                    className="edit-user-modal cust-modal"
                    ref={(el) => {
                        this.dialog = el;
                    }}
                    show={this.state.specificProductsCustomerShow}
                    onHide={this.specificProductsCustomerClose}
                >
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">{marketingLanguage.SelectSpecificProducts}</h1>
                        </Modal.Title>
                        <button type="button" onClick={this.specificProductsCustomerClose} className="close btn-close"></button>
                    </Modal.Header>
                    <Modal.Body>
                        <div className="white-box cuts-popup-tbl p-0">
                            <div className="form-group pb-3">
                                <div className="d-flex align-items-center">
                                    <div className="w-100 src-with-btn-class position-relative">
                                        <input type="text" name="" className="form-control input-custom-class mb-0" placeholder={marketingLanguage.searchProducts} onChange={this.handleProductsSearch} />
                                        <span className="position-absolute">
                                            <i className="bi bi-search"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div className="form-group text-center pb-3 mt-2">
                                <div className="table-responsive">
                                    <table className="table">
                                        <thead>
                                            <tr>
                                                <th></th>
                                                <th>item</th>
                                                <th>Barcode</th>
                                                <th>Name</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {this.state.SpecificProductsData &&
                                                this.state.SpecificProductsData.map((data, i) => (
                                                    <tr key={i}>
                                                        <td>
                                                            <label className="cust-chk-bx">
                                                                <input name="" type="checkbox" onChange={(e) => this.handleCheckboxCustChange(e, data)} />
                                                                <span className="cust-chkmark"></span>
                                                            </label>
                                                        </td>
                                                        <td>
                                                            {" "}
                                                            <img src={data.thumbnail} alt="image" className="imgfix-smpl-tbl" />
                                                        </td>
                                                        <td>{data.barcode}</td>
                                                        <td>{data.title_en}</td>
                                                    </tr>
                                                ))}
                                        </tbody>
                                    </table>
                                </div>
                                <button type="button" className="red-btn align-item-center mt-3" onClick={this.loadMoreSpecificProducts}>
                                    {this.state.loadmoreLoader ? 'Loading....' : 'LoadMoreProduct'}
                                </button>
                            </div>
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <div className="form-group mx-auto">
                            <div className="text-center">
                                <button type="submit" className="red-btn " name="add" onClick={this.handleCustAdd}>
                                    {marketingLanguage.add}
                                </button>
                            </div>
                        </div>
                    </Modal.Footer>
                </Modal>
            </Adminlayout>
        )
    }
}

export default AddBundleDiscount