import React, {
  Component,
  createRef,
  useEffect,
  useRef,
  useState,
} from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import { Modal, Dropdown } from "react-bootstrap";
import { confirmAlert } from "react-confirm-alert";
import toastr from "toastr";
import {
  API_Path,
  buttonArabic,
  buttonEnglish,
  titleArabic,
  titleEnglish,
  productEnglish,
  productArabic,
} from "../../const";
import LanguageContext from "../../contexts/languageContext";
import MUITable from "../../Components/MUITable";
import { GetApi, PostApi } from "../../helper/APIService";
import { Formik } from "formik";
import * as Yup from "yup";
import { CircularProgress } from "@material-ui/core";
import PreviewIcon from "@material-ui/icons/Visibility";
class Marketing extends Component {
  imageRef = createRef();
  static contextType = LanguageContext;
  constructor(props) {
    super(props);
    this.state = {
      frameSets: [],
      frameSetToModify: {},
      showAddModifyModal: false,
      syncing: false,
      syncingFrame: null,
      showPreviewModal: false,
      previewFrame: null,
      loading: true,
      previewLoading: true,
      xmlLoading: false,
      xmlLoadingId: null,
    };
  }

  componentDidMount() {
    this.getFrameSets();
  }

  getFrameSets = () => {
    let data = {
      page: this.state.page,
      sizePerPage: this.state.sizePerPage,
      defaultSorted: this.state.defaultSorted,
    };

    let path = API_Path.getFrameSets;
    const getFrameSetsPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getFrameSetsPromise.then((res) => {
      if (res) {
        if (res.data.success) {
          this.setState({ frameSets: res.data.data, loading: false });
          return;
        }
        this.setState({ frameSets: [], loading: false });
      }
    });
  };

  handleClickAddFrameSet = () => {
    this.setState((state) => ({
      showAddModifyModal: true,
    }));
  };
  handleEditFrameSet = (id) => {
    this.setState((state) => ({
      showAddModifyModal: true,
      frameSetToModify: state.frameSets.find((frameSet) => frameSet.id === id),
    }));
  };

  handleDeleteFrameSet = (id) => {
    let data = { id };
    let path = API_Path.deleteFrameSet;
    const deleteFrameSetPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    deleteFrameSetPromise.then((res) => {
      if (res) {
        if (res.data.success) {
          toastr.success(
            this.context.language === "english"
              ? res.data.message_en
              : res.data.message_ar
          );
          this.getFrameSets();
        } else {
          toastr.error(
            this.context.language === "english"
              ? res.data.message_en
              : res.data.message_ar
          );
        }
      }
    });
  };

  handleDeleteClick = (id) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>Are you sure?</h1>
            <p>You want to delete this frame?</p>
            <button className="btn red-btn me-2" onClick={onClose}>
              No
            </button>
            <button
              className="btn red-btn"
              onClick={() => {
                this.handleDeleteFrameSet(id);
                onClose();
              }}
            >
              Yes, Delete it!
            </button>
          </div>
        );
      },
    });
  };

  handlePreviewFrameSet = (id) => {
    let data = { id };
    let path = API_Path.previewFrameSet;

    this.setState({ previewLoading: true, showPreviewModal: true });

    const previewFrameSetPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    previewFrameSetPromise.then((res) => {
      if (res) {
        if (res.data.success) {
          this.setState({
            previewLoading: false,
            previewFrame: res.data.data,
          });
        } else {
          toastr.error(
            this.context.language === "english"
              ? res.data.message_en
              : res.data.message_ar
          );
        }
      }
    });
  };

  handleGenerateXML = (id) => {
    this.setState({ xmlLoading: true, xmlLoadingId: id });
    let path = API_Path.generateXML;
    const generateXMLPromise = new Promise((resolve, reject) => {
      resolve(GetApi(`${path}?id=${id}`));
    });
    generateXMLPromise.then((res) => {
      this.setState({ xmlLoading: false, xmlLoadingId: null });
      if (res) {
        if (res.data.success) {
          toastr.success(
            this.context.language === "english"
              ? res.data.message_en
              : res.data.message_ar
          );
          this.getFrameSets();
        } else {
          toastr.error(
            this.context.language === "english"
              ? res.data.message_en
              : res.data.message_ar
          );
        }
      }
    });
  };

  handleClosePreviewModal = () => {
    this.setState({
      showPreviewModal: false,
      previewFrame: null,
    });
  };
  handleCloseAddModifyModal = () => {
    this.setState({
      showAddModifyModal: false,
      frameSetToModify: {},
    });
  };

  handleSyncClick = (id) => {
    let data = {
      id: id,
    };
    let path = API_Path.syncFrameSet;

    this.setState({ syncing: true, syncingFrame: id });
    const syncFrameSetPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    syncFrameSetPromise.then((res) => {
      this.setState({ syncing: false, syncingFrame: null });
      if (res) {
        const isEnglish = this.context.language === "english";
        if (res.data.success) {
          toastr.success(isEnglish ? res.data.message_en : res.data.message_ar);
          this.getFrameSets();
        } else {
          toastr.error(isEnglish ? res.data.message_en : res.data.message_ar);
        }
      }
    });
  };

  render() {
    let titleLanguage =
      this.context.language === "english" ? titleEnglish : titleArabic;
    let ButtonLanguage =
      this.context.language === "english" ? buttonEnglish : buttonArabic;
    let productLanguage =
      this.context.language === "english" ? productEnglish : productArabic;

    const columns = [
      {
        label: productLanguage.slNo,
        name: "id",
        options: {
          filter: false,
          sort: false,
        },
      },
      {
        label: productLanguage.frame,
        name: "frame_image",
        options: {
          filter: false,
          sort: false,
          customBodyRender: (value) => (
            <div className="img-hover-main">
              <img className="imgWidth" src={value} alt="" />
              <div className="table-img-hover">
                <img className="h-100 img-fluid" src={value} alt="" />
              </div>
            </div>
          ),
        },
      },
      {
        label: productLanguage.name,
        name: "frame_name",
        options: {
          filter: false,
          sort: false,
        },
      },
      {
        label: productLanguage.language,
        name: "language",
        options: {
          filter: false,
          sort: false,
        },
      },
      {
        label: productLanguage.catalogFeedUrl,
        name: "catalog_feed_url",
        options: {
          filter: false,
          sort: false,
          customBodyRender: (value, { rowIndex }) => {
            return this.state.frameSets[rowIndex].id ===
              this.state.xmlLoadingId && this.state.xmlLoading ? (
              <CircularProgress size={20} />
            ) : (
              value
            );
          },
        },
      },
      {
        label: productLanguage.sync,
        name: "id",
        options: {
          filter: true,
          sort: false,
          customBodyRender: (value) => {
            return (
              <button
                bg="light"
                className="btn feed-sync-btn"
                onClick={() => this.handleSyncClick(value)}
              >
                {this.state.syncing && this.state.syncingFrame === value ? (
                  <CircularProgress size={16} />
                ) : (
                  "Sync"
                )}
              </button>
            );
          },
        },
      },
      {
        label: productLanguage.action,
        name: "id",
        options: {
          filter: false,
          sort: false,
          empty: true,

          customBodyRender: (value) => {
            return (
              <div className="position-relative">
                <Dropdown className="cust-drop">
                  <Dropdown.Toggle
                    className="bg-transparent "
                    id="dropdown-basic"
                    align="end"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width={16}
                      height={16}
                      fill="currentColor"
                      className="bi bi-three-dots-vertical"
                      viewBox="0 0 16 16"
                    >
                      <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                    </svg>
                  </Dropdown.Toggle>
                  <Dropdown.Menu
                    renderOnMount
                    popperConfig={{ strategy: "fixed" }}
                  >
                    <Dropdown.Item
                      onClick={() => this.handlePreviewFrameSet(value)}
                    >
                      <PreviewIcon />
                      <span>{ButtonLanguage.preview}</span>
                    </Dropdown.Item>
                    <Dropdown.Item
                      onClick={() => this.handleEditFrameSet(value)}
                    >
                      <svg
                        width={19}
                        height={19}
                        viewBox="0 0 19 19"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
                          fill="#2D2D3B"
                        />
                      </svg>
                      <span>{ButtonLanguage.edit}</span>
                    </Dropdown.Item>
                    <Dropdown.Item
                      onClick={() => this.handleGenerateXML(value)}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        fill="currentColor"
                        class="bi bi-filetype-xml"
                        viewBox="0 0 16 16"
                      >
                        <path
                          fill-rule="evenodd"
                          d="M14 4.5V14a2 2 0 0 1-2 2v-1a1 1 0 0 0 1-1V4.5h-2A1.5 1.5 0 0 1 9.5 3V1H4a1 1 0 0 0-1 1v9H2V2a2 2 0 0 1 2-2h5.5zM3.527 11.85h-.893l-.823 1.439h-.036L.943 11.85H.012l1.227 1.983L0 15.85h.861l.853-1.415h.035l.85 1.415h.908l-1.254-1.992zm.954 3.999v-2.66h.038l.952 2.159h.516l.946-2.16h.038v2.661h.715V11.85h-.8l-1.14 2.596h-.025L4.58 11.85h-.806v3.999zm4.71-.674h1.696v.674H8.4V11.85h.791z"
                        />
                      </svg>
                      <span>{ButtonLanguage.generateXML}</span>
                    </Dropdown.Item>
                    <Dropdown.Item
                      onClick={() => this.handleDeleteClick(value)}
                    >
                      <svg
                        width={19}
                        height={19}
                        viewBox="0 0 18 20"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
                          fill="#2D2D3B"
                        />
                      </svg>
                      <span>{ButtonLanguage.archive}</span>
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              </div>
            );
          },
        },
      },
    ];

    const option = {
      searchOpen: false,
      search: false,
      searchAlwaysOpen: false,
      print: false,
      serverSide: true,
      pagination: true,
      count: this.state.totalSize,
      tableState: {
        showResponsive: false,
      },
      rowsPerPageOptions: [5, 10, 15, 100],
      onTableChange: (action, state) => {
        if (action === "changePage") {
          this.setState({ page: state.page + 1 }, () => {
            this.getFrameSets();
          });
        } else if (action === "changeRowsPerPage") {
          this.setState({ sizePerPage: state.rowsPerPage }, () => {
            this.getFrameSets();
          });
        }
      },
      textLabels: {
        body: {
          noMatch: this.state.loading ? (
            <CircularProgress size={20} />
          ) : (
            "Sorry, no matching records found"
          ),
          toolTip: "Sort",
          columnHeaderTooltip: (column) =>
            `${productLanguage.Sortfor} ${column.label}`,
        },
        pagination: {
          next: "Next Page >",
          previous: "< Previous Page",
          rowsPerPage: "Rows per page:",
          displayRows: "of",
        },
        selectedRows: {
          text: "row(s) selected",
          delete: "",
          deleteAria: "Apply action on Selected Rows",
        },
      },
      selectableRows: false,
      onFilterConfirm: (filterList) => {
        console.log(filterList);
      },
      onFilterDialogOpen: () => {
        console.log("filter dialog opened");
      },
      onFilterDialogClose: () => {
        console.log("filter dialog closed");
      },
      download: false,
      filter: false,
      viewColumns: false,
      display: true,
    };

    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space align-items-center">
            <div className="col-6  text-start rtl-txt-start">
              <div className="common-header-txt">
                <h3>{titleLanguage.frameSets}</h3>
              </div>
            </div>
            <div className="col-6  text-end rtl-txt-end">
              <div className="common-red-btn">
                <button
                  className="btn red-btn"
                  onClick={this.handleClickAddFrameSet}
                >
                  {productLanguage.addFrameSet}
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="white-box mt-3">
          <div className="custom-table no-responsive">
            {/* <div className="table-responsive dataTables_wrapper no-footer"> */}
            <MUITable
              data={this.state.frameSets}
              columns={columns}
              options={option}
            />
            {/* </div> */}
          </div>
        </div>

        {/* ------------------------modal-------------------------- */}
        <AddModifyModal
          context={this.context}
          show={this.state.showAddModifyModal}
          onHide={this.handleCloseAddModifyModal}
          afterSubmit={() => {
            this.handleCloseAddModifyModal();
            this.getFrameSets();
          }}
          initialValues={this.state.frameSetToModify}
        />
        <PreviewFrameModal
          context={this.context}
          src={this.state.previewFrame}
          show={this.state.showPreviewModal}
          loading={this.state.previewLoading}
          handleClose={this.handleClosePreviewModal}
        />
      </Adminlayout>
    );
  }
}

const AddModifyModal = ({
  show,
  onHide,
  context,
  afterSubmit,
  initialValues,
}) => {
  const isLocaleEnglish = context.language === "english";

  let productLanguage = isLocaleEnglish ? productEnglish : productArabic;
  let Button = isLocaleEnglish ? buttonEnglish : buttonArabic;

  const isEdit = Object.keys(initialValues).length > 0;

  const [frameImage, setFrameImage] = useState(() =>
    initialValues.frame_image ? { url: initialValues.frame_image } : {}
  );
  const [formSubmitting, setFormSubmitting] = useState(false);

  const imageRef = useRef(null);
  const formRef = useRef(null);

  useEffect(() => {
    if (initialValues.frame_image)
      setFrameImage({ url: initialValues.frame_image });
  }, [initialValues.frame_image]);

  const removeFrameImage = () => {
    imageRef.current.value = "";
    setFrameImage({});
  };

  const handleFormSubmit = async (values, { setSubmitting, resetForm }) => {
    let imageS3Path = frameImage.url;

    setFormSubmitting(true);

    if (frameImage.frame) {
      let formData = new FormData();
      formData.append("file", frameImage.frame);

      let path = API_Path.addFrameFileInS3;
      const addFilePromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, formData));
      });

      const res = await addFilePromise;

      if (res) {
        if (!res.data.success) {
          toastr.error(res.data.message);
          setSubmitting(false);
          setFormSubmitting(false);
          return;
        }

        imageS3Path = res.data.data[0];
      } else {
        setSubmitting(false);
        setFormSubmitting(false);
        return;
      }
    }

    let data = {
      frame_name: values.name,
      language: values.language,
      frame_image: imageS3Path,
      ...(isEdit ? { id: initialValues.id } : {}),
    };

    let path = isEdit ? API_Path.updateFrameSet : API_Path.addFrameSet;

    const addModifyFrameSetPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    addModifyFrameSetPromise.then((res) => {
      if (res) {
        console.log("res is :: ", res);
        if (res.data.success) {
          resetForm();
          removeFrameImage();
          setSubmitting(false);
          setFormSubmitting(false);
          afterSubmit();
          toastr.success(
            isLocaleEnglish ? res.data.message_en : res.data.message_ar
          );
        } else {
          setSubmitting(false);
          setFormSubmitting(false);
          toastr.error(
            isLocaleEnglish ? res.data.message_en : res.data.message_ar
          );
        }
      }
    });
  };

  const handleImageChange = (e) => {
    const frame = e.target.files[0];

    console.log(frame);
    if (frame) {
      formRef.current.setFieldValue("frame", frame.name);
      setFrameImage({ frame, url: URL.createObjectURL(frame) });
    }
  };

  const handleClose = () => {
    setFrameImage({});
    imageRef.current = null;
    onHide();
  };

  // console.log(frameImage.url ?? initialValues.frame_image);

  return (
    <Modal
      show={show}
      onHide={handleClose}
      dialogClassName="modal-dialog-centered cust-width-modal"
      className="edit-user-modal cust-modal"
    >
      <Modal.Header>
        <Modal.Title>
          <h1 className="modal-title">
            {isEdit
              ? productLanguage.editFrameSet
              : productLanguage.addFrameSet}
          </h1>
        </Modal.Title>
        <button
          type="button"
          onClick={handleClose}
          className="close btn-close"
        ></button>
      </Modal.Header>
      <Modal.Body>
        <Formik
          innerRef={formRef}
          initialValues={{
            name: initialValues.frame_name ?? "",
            language: initialValues.language ?? "english",
            frame: initialValues.frame_image ?? "",
          }}
          onSubmit={handleFormSubmit}
          validationSchema={Yup.object().shape({
            name: Yup.string().required("Name name is required"),
            language: Yup.string().required("Language name is required"),
            frame: Yup.string().required("Frame is required"),
          })}
        >
          {(props) => {
            const {
              values,
              touched,
              errors,
              handleChange,
              handleBlur,
              handleSubmit,
            } = props;
            return (
              <form className="row" onSubmit={handleSubmit}>
                <div className="form-group col-md-12">
                  <label>
                    {productLanguage.name} <bdi>*</bdi>
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={values.name}
                    onBlur={handleBlur}
                    onChange={handleChange}
                    className="form-control input-custom-class"
                    placeholder="Frame 70%"
                    disabled={isEdit}
                  />
                  {errors.name && touched.name && (
                    <div className="input-feedback text-danger">
                      {errors.name}
                    </div>
                  )}
                </div>
                <div className="form-group col-md-12">
                  <label>
                    {productLanguage.language} <bdi>*</bdi>
                  </label>
                  <select
                    id="language"
                    name="language"
                    value={values.language}
                    onChange={handleChange}
                    className="form-select input-custom-class"
                  >
                    <option value="english">{productLanguage.english}</option>
                    <option value="arabic">{productLanguage.arabic}</option>
                  </select>
                  {errors.language && touched.language && (
                    <div className="input-feedback text-danger">
                      {errors.language}
                    </div>
                  )}
                </div>
                <div className="d-flex gap-3">
                  <div
                    className="form-group col-md"
                    style={{ width: "calc(100% - 100px - 1.5rem)" }}
                  >
                    <label>
                      {productLanguage.addFrame} <bdi>*</bdi>
                    </label>
                    <div className="upload-file-section-new position-relative">
                      <button
                        style={{ height: 45, padding: 0 }}
                        className="btn red-btn text-center position-relative"
                      >
                        <div
                          style={{
                            color: "#fff",
                            backgroundColor: "transparent",
                          }}
                          className="file-area position-relative align-items-start px-4"
                        >
                          <input
                            type="file"
                            ref={imageRef}
                            id="frame-name"
                            accept="image/*"
                            name="frame-name"
                            onBlur={handleBlur}
                            onChange={handleImageChange}
                            style={{ backgroundColor: "transparent" }}
                            className="form-control input-custom-class"
                          />
                          Browse
                          {/* <p
                            className="m-0"
                            style={{
                              width: "100%",
                              whiteSpace: "nowrap",
                              overflow: "hidden",
                              textOverflow: "ellipsis",
                            }}
                          >
                            {frameImage.frame?.name ??
                              frameImage.url ??
                              "No file chosen"}
                          </p> */}
                        </div>
                      </button>
                      <p
                        className="mt-2 mb-0"
                        style={{
                          fontSize: 12,
                          width: "100%",
                          overflow: "hidden",
                          whiteSpace: "nowrap",
                          textOverflow: "ellipsis",
                        }}
                      >
                        {frameImage.frame?.name ??
                          frameImage.url ??
                          "No file chosen"}
                      </p>
                    </div>
                    {errors.frame && touched.frame && (
                      <div className="input-feedback text-danger">
                        {errors.frame}
                      </div>
                    )}
                  </div>
                  {frameImage.url && (
                    <div className="pe-2">
                      <div className="img-preview-main frame-set position-relative">
                        <img src={frameImage.url} alt="frame" />
                        <div className="remove-img-btn">
                          <i
                            onClick={removeFrameImage}
                            className="bi bi-x-circle-fill"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                <div className=" col-md-12 mb-3 mt-3 text-center">
                  <div className="common-red-btn">
                    <button
                      disabled={formSubmitting}
                      type="submit"
                      className="btn red-btn me-2"
                    >
                      {formSubmitting ? (
                        <CircularProgress size={16} color="#fff" />
                      ) : isEdit ? (
                        Button.update
                      ) : (
                        Button.submit
                      )}
                    </button>
                    {/* <div onClick={this.handleReset} className="btn black-btn ">{Button.cancel}</div> */}
                  </div>
                </div>
              </form>
            );
          }}
        </Formik>
      </Modal.Body>
    </Modal>
  );
};

const PreviewFrameModal = ({ show, context, loading, handleClose, src }) => {
  const isLocaleEnglish = context.language === "english";

  let productLanguage = isLocaleEnglish ? productEnglish : productArabic;

  return (
    <Modal
      show={show}
      onHide={handleClose}
      className="edit-frame-modal cust-modal"
      dialogClassName="modal-dialog-centered cust-width-modal"
    >
      <Modal.Header>
        <Modal.Title>
          <h1 className="modal-title">{productLanguage.framePreview}</h1>
        </Modal.Title>
        <button
          type="button"
          onClick={handleClose}
          className="close btn-close"
        ></button>
      </Modal.Header>
      <Modal.Body
        style={{ backgroundColor: "#ddd", height: 400 }}
        className="d-flex align-items-center justify-content-center"
      >
        {loading ? (
          <CircularProgress size={30} />
        ) : (
          <img src={src} alt={"frame-preview"} height={"100%"} />
        )}
      </Modal.Body>
    </Modal>
  );
};

export default Marketing;
