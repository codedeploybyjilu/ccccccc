import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import DataTable from "../../Components/DataTable";
import { textFilter } from "react-bootstrap-table2-filter";
import LanguageContext from "../../contexts/languageContext";
import {
  buttonArabic,
  buttonEnglish,
  ErrorArabic,
  ErrorEnglish,
  TableFieldArabic,
  TableFieldEnglish,
  titleArabic,
  titleEnglish,
} from "../../const";
import MUITable from "../../Components/MUITable";

class Errorlog extends Component {
  static contextType = LanguageContext;
  constructor(props) {
    super(props);
    this.state = {
      page: 1,
      sizePerPage: 10,
      totalSize: 100,
      defaultSorted: [
        {
          dataField: "id",
          order: "asc",
        },
      ],

      options: {
        filter: true,
        responsive: "vertical",
        onColumnSortChange: (changedColumn, direction) =>
          console.log(
            "changedColumn: ",
            changedColumn,
            "direction: ",
            direction
          ),
        onChangeRowsPerPage: (numberOfRows) =>
          console.log("numberOfRows: ", numberOfRows),
        onChangePage: (currentPage) =>
          console.log("currentPage: ", currentPage),
      },
      order_data: [
        {
          id: 1,
          datetime: "25/09/2021 at 7:00 PM",
          devicename: "OnePlus 6T",
          modelname: "6T",
          osversion: "OnePlus Nord CE",
          appversion: "Cordova App Version docs",
        },
        {
          id: 2,
          datetime: "25/09/2021 at 7:00 PM",
          devicename: "OnePlus 6T",
          modelname: "6T",
          osversion: "OnePlus Nord CE",
          appversion: "Cordova App Version docs",
        },
        {
          id: 3,
          datetime: "25/09/2021 at 7:00 PM",
          devicename: "OnePlus 6T",
          modelname: "6T",
          osversion: "OnePlus Nord CE",
          appversion: "Cordova App Version docs",
        },
        {
          id: 4,
          datetime: "25/09/2021 at 7:00 PM",
          devicename: "OnePlus 6T",
          modelname: "6T",
          osversion: "OnePlus Nord CE",
          appversion: "Cordova App Version docs",
        },
        {
          id: 5,
          datetime: "25/09/2021 at 7:00 PM",
          devicename: "OnePlus 6T",
          modelname: "6T",
          osversion: "OnePlus Nord CE",
          appversion: "Cordova App Version docs",
        },
        {
          id: 6,
          datetime: "25/09/2021 at 7:00 PM",
          devicename: "OnePlus 6T",
          modelname: "6T",
          osversion: "OnePlus Nord CE",
          appversion: "Cordova App Version docs",
        },
        {
          id: 7,
          datetime: "25/09/2021 at 7:00 PM",
          devicename: "OnePlus 6T",
          modelname: "6T",
          osversion: "OnePlus Nord CE",
          appversion: "Cordova App Version docs",
        },
        {
          id: 8,
          datetime: "25/09/2021 at 7:00 PM",
          devicename: "OnePlus 6T",
          modelname: "6T",
          osversion: "OnePlus Nord CE",
          appversion: "Cordova App Version docs",
        },
        {
          id: 9,
          datetime: "25/09/2021 at 7:00 PM",
          devicename: "OnePlus 6T",
          modelname: "6T",
          osversion: "OnePlus Nord CE",
          appversion: "Cordova App Version docs",
        },
        {
          id: 10,
          datetime: "25/09/2021 at 7:00 PM",
          devicename: "OnePlus 6T",
          modelname: "6T",
          osversion: "OnePlus Nord CE",
          appversion: "Cordova App Version docs",
        },
      ],
    };
  }

  render() {
    let Language =
      this.context.language === "english"
        ? TableFieldEnglish
        : TableFieldArabic;
    let titleLanguage =
      this.context.language === "english" ? titleEnglish : titleArabic;
    let buttonLanguage =
      this.context.language === "english" ? buttonEnglish : buttonArabic;
    let ErrorLanguage =
      this.context.language === "english" ? ErrorEnglish : ErrorArabic;

    const columns = [
      {
        label: ErrorLanguage.DateTime,
        name: "datetime",
        options: {
          filter: true,
        },
      },
      {
        label: ErrorLanguage.DeviceName,
        name: "devicename",
        options: {
          filter: true,
        },
      },
      {
        label: ErrorLanguage.ModelName,
        name: "modelname",
        options: {
          filter: false,
        },
      },
      {
        label: ErrorLanguage.OsVersion,
        name: "osversion",
        options: {
          filter: true,
        },
      },
      {
        label: ErrorLanguage.AppVersion,
        name: "appversion",
        options: {
          filter: true,
          sort: false,
        },
      },
    ];
    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space align-items-center">
            <div className="col-6 text-start rtl-txt-start">
              <div className="common-header-txt">
                <h3>{titleLanguage.errorLog}</h3>
              </div>
            </div>
            <div className="col-6 text-end rtl-txt-end">
              <div className="common-red-btn">
                <a href="#" className="btn red-btn">
                  {buttonLanguage.exportList}
                </a>
              </div>
            </div>
          </div>
          <div className="row common-space">
            <div className="col-md-12">
              <div className="white-box">
                <div className="custom-table">
                  <div className="table-responsive dataTables_wrapper no-footer">
                    {this.state.order_data && (
                      <MUITable
                        data={this.state.order_data}
                        columns={columns}
                        options={this.state.options}
                      />
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Adminlayout>
    );
  }
}

export default Errorlog;
