import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import DataTable from "../../Components/DataTable";
import { Link } from "react-router-dom";
import { textFilter } from "react-bootstrap-table2-filter";
import "react-confirm-alert/src/react-confirm-alert.css";
import { API_Path, buttonArabic, buttonEnglish, TableFieldArabic, TableFieldEnglish, titleArabic, titleEnglish, locationArabic, locationEnglish, SidebarEnglish, SidebarArabic } from "../../const";
import LanguageContext from "../../contexts/languageContext";
import { Dropdown, Modal } from "react-bootstrap";
import { confirmAlert } from "react-confirm-alert";
import { PostApi } from "../../helper/APIService";
import toastr from "toastr";
import readXlsxFile from "read-excel-file";
import { Formik } from "formik";
import * as Yup from "yup";

export class Location extends Component {
  static contextType = LanguageContext;

  constructor(props) {
    super(props);
    this.state = {
      page: 1,
      sizePerPage: 50,
      totalSize: 0,
      city: "",
      area: "",
      deliveryTimeApprox: "",
      codCharges: "",
      codStatus: true,
      onlineStatus: true,
      ZipCode: "",
      Editcity: "",
      Editarea: "",
      EditcodCharges: "",
      EditcodStatus: "",
      EditZipCode: "",
      defaultSorted: [
        {
          dataField: "id",
          order: "desc",
        },
      ],
      editLocationPopup: false,
      editedId: "",
      oldLocationData: "",
      locationData: [],
      cityData: [],
      deliveryData: [],
      shippingCompanyData: [],
    };
  }

  componentDidMount() {
    this.getShippingData();
    this.getLocation();
  };

  getShippingData = () => {

    let data = {};

    let path = API_Path.getShippingCompany;
    const getShippingDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getShippingDataPromise.then((res) => {
      if (res) {
        this.setState({ shippingCompanyData: res.data.data });
      }
    });
  };

  getLocation = () => {
    let path = API_Path.getShippingCity;
    let data = {
      sizePerPage: this.state.sizePerPage,
      page: this.state.page,
      defaultSorted: this.state.defaultSorted,
      searchText: this.state.search_val
    };
    const getLocationPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getLocationPromise.then((res) => {
      if (res) {
        if (res.data.success) {
          this.setState({ locationData: res.data.data, totalSize: res.data.count }, () => {
          });
        }
      }
    });
  };

  finaly_delete_record = (id) => {
    let path = API_Path.deleteShippingCity;
    let data = {
      id: id,
    };
    const deleteLocationPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    deleteLocationPromise.then((res) => {
      if (res) {
        if (res.data.success) {
          toastr.success(res.data.message);
          this.getLocation();
        } else {
          toastr.error(res.data.message);
        }
      }
    });
  };

  delete_record = (id) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>Are you sure?</h1>
            <p>You want to delete this file?</p>
            <button className="btn red-btn me-2" onClick={onClose}>
              No
            </button>
            <button
              className="btn red-btn"
              onClick={() => {
                this.finaly_delete_record(id);
                onClose();
              }}
            >
              Yes, Delete it!
            </button>
          </div>
        );
      },
    });
  };

  handleSearchChange = (e) => {
    let text = e.target.value;
    this.setState({ search_val: text }, () => {
      clearTimeout(this.getData)
      this.getData = setTimeout(() => {
        this.getLocation();
      }, 500);
    });
  };


  handleTableChange = (type, { page, sizePerPage, filters, sortField, sortOrder }) => {
    switch (type) {
      case "pagination":
        this.setState({ page, sizePerPage, }, () => {
          this.getLocation()
        });
        break;
      case "filter":
        let search_val = this.state.search_val;
        let newFilter = {};
        if (Object.keys(filters).length) {
          for (const dataField in filters) {
            newFilter[dataField] = filters[dataField].filterVal;
          }
          newFilter = { ...search_val, ...newFilter };
        } else {
          newFilter = { title: "", indicator: "", definition: "" };
        }
        this.setState({ search_val: newFilter }, () => {
          this.getLocation()
        });
        break;
      case "sort":
        this.setState({ defaultSorted: [{ dataField: sortField, order: sortOrder }] }, () => {
          this.getLocation()
        });
        break;
      default:
        break;
    }
    return true;
  };

  handleToggleStatus = (id, field) => {
    let path = API_Path.updateShippingStatus;
    let data = {
      id: id,
      field: field
    };
    const updateStatusPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    updateStatusPromise.then((res) => {
      if (res) {
        if (res.data.success) {
          toastr.success(res.data.message);
          this.getLocation();
        } else {
          toastr.error(res.data.message);
        }
      }
    });
  }

  render() {
    let Language = this.context.language === "english" ? TableFieldEnglish : TableFieldArabic;
    let titleLanguage = this.context.language === "english" ? titleEnglish : titleArabic;
    let locationLanguage = this.context.language === "english" ? locationEnglish : locationArabic;
    let sidebarLanguage = this.context.language === "english" ? SidebarEnglish : SidebarArabic;
    let buttonLanguage = this.context.language === "english" ? buttonEnglish : buttonArabic;

    const columns = [
      {
        dataField: "id",
        text: "Id",
        hidden: true,
      },
      {
        dataField: this.context.language === "english" ? "english" : "arabic",
        text: locationLanguage.city,
        sort: true,
        hidden: false,
      },
      {
        dataField: "areas",
        text: locationLanguage.area,
        sort: true,
        hidden: false,
      },
      {
        dataField: "cod_status",
        text: locationLanguage.COD,
        sort: false,
        hidden: false,
        classes: "text-start",
        formatter: (cell, row, rowIndex) => {
          return (
            <React.Fragment>
              <label className="switch ">
                <input type="checkbox" defaultChecked={cell === 1} onChange={() => this.handleToggleStatus(row.id, 'cod_status')} />
                <div className="slider round" />
                <div className="on-off-text" />
              </label>
            </React.Fragment>
          );
        },
      },
      {
        dataField: "online_status",
        text: Language.CardPayment,
        sort: false,
        hidden: false,
        classes: "text-start",
        formatter: (cell, row, rowIndex) => {
          return (
            <React.Fragment>
              <label className="switch ">
                <input type="checkbox" defaultChecked={cell === 1} onChange={() => this.handleToggleStatus(row.id, 'online_status')} />
                <div className="slider round" />
                <div className="on-off-text" />
              </label>
            </React.Fragment>
          );
        },
      },
      {
        dataField: "shipping_company",
        text: locationLanguage.shippingCompany,
        sort: true,
        hidden: false,
        formatter: (cell, row, rowIndex) => {
          let filtered = this.state.shippingCompanyData?.filter((item) => item.id === cell)
          return (
            <React.Fragment>
              <span>{filtered[0]?.english}</span>
            </React.Fragment>
          );
        },
      },
      {
        dataField: "delivery_time",
        text: locationLanguage.approximateDeliveryTime,
        sort: true,
        hidden: false,
      },
      {
        dataField: "shipping_charge",
        text: locationLanguage.shippingCharges,
        sort: true,
        hidden: false,
        class: "text-center",
      },
      {
        dataField: "status",
        text: Language.status,
        sort: false,
        hidden: false,
        class: "text-center",
        formatter: (cell, row, rowIndex) => {
          return (
            <React.Fragment>
              <label className="switch ">
                <input type="checkbox" defaultChecked={cell === 1} onChange={() => this.handleToggleStatus(row.id, 'status')} />
                <div className="slider round" />
              </label>
            </React.Fragment>
          );
        },
      },
      {
        dataField: "action",
        text: Language.action,
        hidden: false,
        csvExport: false,
        headerClasses: "text-center",
        classes: "text-center",
        formatter: (cell, row, rowIndex) => {
          return (
            <React.Fragment>
              <Dropdown className="cust-drop">
                <Dropdown.Toggle className="bg-transparent " id="dropdown-basic" align="end">
                  <svg xmlns="http://www.w3.org/2000/svg" width={16} height={16} fill="currentColor" className="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                    <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                  </svg>
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  <Dropdown.Item href={`editnewcity/${row.id}`}>
                    <svg width={19} height={18} viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z" fill="#2D2D3B" />
                    </svg>
                    <span>{locationLanguage.edit}</span>
                  </Dropdown.Item>
                  <Dropdown.Item href="#" onClick={() => this.delete_record(row.id)}>
                    <svg width={18} height={20} viewBox="0 0 18 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z" fill="#2D2D3B" />
                    </svg>
                    <span>{locationLanguage.delete}</span>
                  </Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </React.Fragment>
          );
        },
      },
    ];

    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space">
            <div className="col-sm-6 text-sm-start text-center rtl-txt-start">
              <div className="common-header-txt">
                <h3>{sidebarLanguage.ShippingZones}</h3>
              </div>
            </div>
            <div className="col-sm-6 text-sm-end text-center rtl-txt-end">
              <div className="common-red-btn">
                <Link to="addnewcity">
                  <a className="btn red-btn">
                    {buttonLanguage.AddNewCity}
                  </a>
                </Link>
              </div>
            </div>
          </div>

          <div className="row common-space">
            <div className="col-md-12">
              <div className="white-box">
                <div className="d-md-flex  user-sec justify-content-end text-center">
                  <div className="me-md-auto mb-3 customer-search-bar position-relative w-100">
                    <input type="search" className="form-control" placeholder={locationLanguage.SearchByCityName} onChange={this.handleSearchChange} />
                    <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M6.31802 1C5.26621 1 4.23803 1.31189 3.36349 1.89622C2.48894 2.48055 1.80732 3.31108 1.40481 4.28279C1.0023 5.2545 0.89699 6.32374 1.10219 7.3553C1.30738 8.38686 1.81388 9.33441 2.55761 10.0781C3.30135 10.8218 4.24893 11.3283 5.28052 11.5335C6.31212 11.7387 7.38139 11.6334 8.35313 11.2309C9.32487 10.8284 10.1554 10.1468 10.7398 9.27228C11.3241 8.39776 11.636 7.36961 11.636 6.31784C11.6359 4.90749 11.0756 3.55493 10.0783 2.55766C9.08102 1.56039 7.72842 1.00009 6.31802 1V1Z" stroke="#C4C4C4" strokeWidth="1.875" strokeMiterlimit="10" />
                      <path d="M10.2856 10.2803L13.9997 13.9942" stroke="#C4C4C4" strokeWidth="1.875" strokeMiterlimit="10" strokeLinecap="round" />
                    </svg>
                  </div>
                </div>
                <div className="custom-table">
                  <div className="table-responsive dataTables_wrapper no-footer">{this.state.locationData && <DataTable keyField="id" loading={this.state.loading} columns={columns} data={this.state.locationData} page={this.state.page} sizePerPage={this.state.sizePerPage} totalSize={this.state.totalSize} defaultSorted={this.state.defaultSorted} language={this.context.language} onTableChange={this.handleTableChange} selectableRows />}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Adminlayout>
    );
  }
}

export default Location;
