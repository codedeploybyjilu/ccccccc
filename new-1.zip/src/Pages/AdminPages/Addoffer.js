import React, { Component } from 'react';
import Adminlayout from '../../Components/AdminLayout/Adminlayout';
import { buttonEnglish, buttonArabic, APIBaseUrl, API_Path, LIVE_FILE_URL } from '../../const';
import { PostApi } from '../../helper/APIService';
import productimg from '../../images/product-placeholder.png'
import toastr from 'toastr';
import LanguageContext from "../../contexts/languageContext";


class Addoffer extends Component {
    static contextType = LanguageContext;
    state = {
        productName: '',
        discount: '',
        date: '',
        itemCode: '',
        mainCategory: '',
        category: '',
        subCategory: '',
        offerImg: productimg,
        maincategoryData: '',
        categoryData: '',
        subCategoryData: '',
        startDate: '',
        endDate: '',
        title_en: '',
        title_ar: '',
        link: '',
        position: ''
    }

    componentDidMount() {
        this.getMainCategoryData();
    }

    handleChange = (e) => {
        this.setState({ [e.target.name]: e.target.value })
    }


    addImageToStorage = () => {
        var formData = new FormData;
        formData.append('file', this.state.offerImg);


        let path = API_Path.addFileInS3
        const addFilePromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, formData));
        });

        addFilePromise.then((res) => {
            if (res) {
                // console.log('res is :: ', res.data.data);
                let imagesUrl = []
                for (let i = 0; i < res.data.data.length; i++) {
                    let obj = {
                        image: res.data.data[i],
                        id: i
                    }
                    imagesUrl.push(obj)

                }
                console.log('array :: ', imagesUrl);

                this.setState({ isImageUploaded: true, offerImg: imagesUrl[0].image })
            }
        });
    }

    getMainCategoryData = () => {

        let data = {}

        let path = API_Path.getMainCategory
        const getMainCategoryPromise = new Promise((resolve, reject) => {
            resolve(PostApi(path, data));
        });

        getMainCategoryPromise.then((res) => {
            if (res) {
                // console.log('res is :: ', res.data.data);
                this.setState({ maincategoryData: res.data.data })
            }
        });
    }

    getCategoryData = (val) => {
        if (val) {

            let data = { 'main_category_id': val }
            let path = API_Path.getCategoryRelative
            const getCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ categoryData: res.data.data })
                }
            });
        } else {


            let data = {}

            let path = API_Path.getCategory
            const getCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ categoryData: res.data.data })
                }
            });
        }
    }

    getSubCategoryData = (val) => {
        // console.log(val);
        if (val) {

            let data = { 'category_id': val }

            let path = API_Path.getSubCategoryRelative
            const getSubCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getSubCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ subCategoryData: res.data.data })
                }
            });
        } else {

            let data = {}

            let path = API_Path.getSubCategory
            const getSubCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getSubCategoryPromise.then((res) => {
                if (res) {
                    // console.log('res is :: ', res.data.data);
                    this.setState({ subCategoryData: res.data.data })
                }
            });
        }

    }

    handleFileInput = (e) => {
        this.setState({ offerImg: e.target.files[0] }, () => {
            this.addImageToStorage()
        })
    }

    handleChange1 = (e) => {
        if (e.target.name == "mainCategory") {
            this.getCategoryData(e.target.value)
        }
        if (e.target.name == "category") {
            this.getSubCategoryData(e.target.value)
        }
    }

    handleSubmit = () => {
        if (this.state.title_ar !== '' &&
            this.state.title_en !== '' &&
            this.state.link !== '' &&
            this.state.offerImg !== '' &&
            this.state.position !== '' &&
            this.state.mainCategory !== '' &&
            this.state.category !== '' &&
            this.state.subCategory !== '' &&
            this.state.discount !== '' &&
            this.state.startDate !== '' &&
            this.state.endDate !== ''
        ) {

            let data = {
                title_ar: this.state.title_ar,
                title_en: this.state.title_en,
                url: this.state.link,
                image: this.state.offerImg,
                position: this.state.position,
                main_category: this.state.mainCategory,
                category: this.state.category,
                discount: this.state.discount,
                sub_category: this.state.subCategory,
                start_timestamp: this.state.startDate,
                end_timestamp: this.state.endDate,
                type: "banner",

            }

            let path = API_Path.addOffer
            const getMainCategoryPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, data));
            });

            getMainCategoryPromise.then((res) => {
                if (res) {
                    console.log('res is :: ', res.data.success);
                    if (res.data.success) {
                        // window.location.href = '/master'
                    }
                }
            });
        } else {
            toastr.error('please fill all field')
        }
    }

    handleCancel = () => {
        this.setState({
            productName: '',
            discount: '',
            date: '',
            itemCode: '',
            mainCategory: '',
            category: '',
            subCategory: '',
            offerImg: productimg,
            maincategoryData: '',
            categoryData: '',
            subCategoryData: '',
            startDate: '',
            endDate: '',
            title_en: '',
            title_ar: '',
            link: '',
            position: ''
        }, () => {
            document.getElementById('offerStartDate').value = ''
            document.getElementById('offerEndDate').value = ''
        })
    }

    render() {
        let ButtonLanguage = this.context.language === "english" ? buttonEnglish : buttonArabic;
        return (
            <Adminlayout>
                <div className="container-fluid">
                    <div className="row common-space">
                        <div className="col-sm-12 text-sm-start text-center">
                            <div className="common-header-txt">
                                <h3>Add Offer</h3>
                            </div>
                        </div>
                    </div>
                    <div className="row common-space">
                        <div className="col-md-12">
                            <div className="white-box">
                                <div className="img-upload">
                                    <div className="avatar-preview">
                                        <div id="imagePreview">
                                            <img className="imagePreviewImage" src={this.state.offerImg == productimg ? productimg : this.state.offerImg} alt="" />
                                        </div>
                                    </div>
                                    <div className="avtar-txt">
                                        <p>Upload your Product</p>
                                        <span>{ButtonLanguage.uploadimagemaxsize} 256*256px.</span>
                                        <div className="avatar-edit">
                                            <input className="d-none" type="file" onChange={this.handleFileInput} id="imageUpload" accept=".png, .jpg, .jpeg" />
                                            <label className="btn red-btn mt-3" htmlFor="imageUpload">
                                                <i className="bi bi-upload me-2" /> {ButtonLanguage.Uploadimage}
                                            </label>
                                        </div>

                                    </div>
                                </div>
                                <div className="row">
                                    <div className="form-group col-md-6">
                                        <label>Title in English</label>
                                        <input type="text" name='title_en' className="form-control input-custom-class " value={this.state.title_en} onChange={this.handleChange} placeholder="Enter Your Porduct Name" />
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>Title in Arabic</label>
                                        <input type="text" name='title_ar' className="form-control input-custom-class " value={this.state.title_ar} onChange={this.handleChange} placeholder="Enter Your Porduct Name" />
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>Link</label>
                                        <input type="text" name='link' className="form-control input-custom-class " value={this.state.link} onChange={this.handleChange} placeholder="Enter Your Porduct Name" />
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>position</label>
                                        <select name='position' onChange={this.handleChange} className="form-select form-control input-custom-class">
                                            <option>Select Main Category </option>
                                            <option value='Main Header'>Main Header</option>
                                            <option value='Middle On Homepage'>Middle On Homepage</option>
                                            <option value='Bottom On Homepage'>Bottom On Homepage</option>
                                            <option value='Product Page Top'>Product Page Top</option>
                                            <option value='Product Page Bottom'>Product Page Bottom</option>
                                        </select>
                                        {/* <input type="text" name='position' className="form-control input-custom-class " value={this.state.position} onChange={this.handleChange} placeholder="Enter Your Porduct Name" /> */}
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>Main - Category</label>
                                        <select name='mainCategory' onChange={this.handleChange} onChangeCapture={this.handleChange1} className="form-select form-control input-custom-class">
                                            <option>Select Main Category </option>
                                            {this.state.maincategoryData && this.state.maincategoryData.length > 0 && this.state.maincategoryData.map((item, i) => {
                                                return (
                                                    <option value={item.id} key={i}>{item.english} | {item.arabic}</option>
                                                )
                                            })}
                                        </select>



                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>Category</label>
                                        <select name='category' onChange={this.handleChange} onChangeCapture={this.handleChange1} className="form-select form-control input-custom-class">
                                            <option>Select Category </option>
                                            {this.state.categoryData && this.state.categoryData.length > 0 && this.state.categoryData.map((item, i) => {
                                                return (
                                                    <option value={item.id} key={i}>{item.english} | {item.arabic}</option>
                                                )
                                            })}
                                        </select>
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>Sub - Category</label>
                                        <select name='subCategory' onChange={this.handleChange} className="form-select form-control input-custom-class">
                                            <option>Select Sub Category</option>
                                            {this.state.subCategoryData && this.state.subCategoryData.length > 0 && this.state.subCategoryData.map((item, i) => {
                                                return (
                                                    <option value={item.id} key={i}>{item.english} | {item.arabic}</option>
                                                )
                                            })}
                                        </select>
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>Discount</label>
                                        <input type="number" name='discount' value={this.state.discount} className="form-control input-custom-class" onChange={this.handleChange} placeholder="Enter Your Discount " />
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>Start Date</label>
                                        <input type="date" name='startDate' id='offerStartDate' className="form-control input-custom-class" onChange={this.handleChange} placeholder="Enter Your Date" />
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>End Date</label>
                                        <input type="date" name='endDate' id='offerEndDate' className="form-control input-custom-class" onChange={this.handleChange} placeholder="Enter Your Date" />
                                    </div>
                                    {/* <div className="form-group col-md-6">
                                        <label>Item Code</label>
                                        <input type="text" name='itemCode' className="form-control input-custom-class" onChange={this.handleChange} placeholder="Enter Your Item Code" />
                                    </div> */}
                                </div>
                            </div>
                        </div>
                        <div className="col-md-12 mt-3 text-sm-start text-center">
                            <div className="common-red-btn">
                                <button onClick={this.handleSubmit} className="btn red-btn  me-2">{ButtonLanguage.submit}</button>
                                <button onClick={this.handleCancel} className="btn black-btn">Cancel</button>
                            </div>

                        </div>
                    </div>

                </div>

            </Adminlayout>
        );
    }
}

export default Addoffer;