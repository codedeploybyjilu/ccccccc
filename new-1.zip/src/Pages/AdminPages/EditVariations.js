import React, { Component } from "react";
import { Formik } from "formik";
import * as Yup from "yup";
import DragDrop from "../../helper/DragDrop";
import dragimg from "../../images/file-upload.svg";
import imgprev from "../../images/img-prev.png";
import productimg from "../../images/product-img.png";
import videoicn from "../../images//video-icn.svg";
import { Dropdown, Modal } from "react-bootstrap";
import toastr from "toastr";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import { APIBaseUrl, API_Path, buttonArabic, buttonEnglish, productArabic, productEnglish } from "../../const";
import { PostApi } from "../../helper/APIService";
import loader from "../../images/loader.gif";
import { confirmAlert } from "react-confirm-alert";
import LanguageContext from "../../contexts/languageContext";
import { Prompt } from "react-router-dom";
import Poster from "../../images/logo.svg"
import { ImageCompress } from "../../Components/ImageCompress";

let ImageFileArray = [];
let variationArray = [];
let variationSizeArray = [];
let editImageArray = [];
let editVariationSizeArray = [];
let deletedIdArray = [];
let objIndex;
let EVobjIndex;

const reorder = (list, startIndex, endIndex) => {
  const result = Array.from(list);
  const [removed] = result.splice(startIndex, 1);
  result.splice(endIndex, 0, removed);

  return result;
};

const grid = 8;

const getItemStyle = (isDragging, draggableStyle) => ({
  // some basic styles to make the items look a bit nicer
  userSelect: "none",
  padding: grid,

  // change background colour if dragging
  background: isDragging ? "#A81A1C" : "#F7F7F7",

  // styles we need to apply on draggables
  ...draggableStyle,
});

const getListStyle = (isDraggingOver, itemsLength) => ({
  background: isDraggingOver ? "#f7f7f7" : "#fff",
  display: "flex",
  flexWrap: "wrap",
  padding: grid,
  width: itemsLength * 150 + 10,
});

class EditVariations extends Component {
  static contextType = LanguageContext;
  constructor(params) {
    super(params);
    this.state = {
      color: [],
      promotion: [],
      selectPromotion: "",
      selectcolor: "",
      selectSize: 0,
      promotionEnglish: "",
      variationName_en: "",
      variationName_ar: "",
      promotionArabic: "",
      price: "",
      discount: "",
      discountPrice: "",
      realprice: "",
      items: "",
      videoFiles: "",
      variationList: "",
      oldVariation: "",
      isVariationShow: false,
      addproduct_show: false,
      editVariantShow: false,
      size_en: "",
      size_ar: "",
      search_val_en: "",
      search_val_ar: "",
      sizeQuantity: "",
      editSize_en: "",
      editSize_ar: "",
      editSizeQuantity: "",
      variationSizeList: [],
      isImageUploaded: false,
      uploadedImages: "",
      isVideoUploaded: true,
      uploadedVideo: "",
      isLoading: false,
      editVariationDetails: "",
      stopUpdateCall: false,
      agesizesData: "",
      brasizesData: "",
      miscData: "",
      internationalsizesData: "",
      numericalsizesData: "",
      editVariationImages: "",
      editVariationVideo: "",
      editVariationNameEn: "",
      editVariationNameAr: "",
      editVariationColor: "",
      editVariationPrice: "",
      editVariationDiscount: "",
      editVariationPromotion: "",
      editVariationRealPrice: "",
      editImageToUpload: "",
      editVariationSizeList: "",
      editVariationAddSize_en: "",
      editVariationAddSize_ar: "",
      editVariationAddSizeQuantity: "",
      editVariationEditSize_en: "",
      editVariationEditSize_ar: "",
      editVariationEditSizeQuantity: "",
      product_id: "",
      oldData: "",
      shouldBlockNavigation: false,
      SizeGroupSizes: '',
      selectedSizeId: '',
      editVariationEditSizeSku: '',
      EditAddVariationSku: '',
      AddVariationSku: '',
      EditVariationSku: '',
      serverImg: '',
      editVariatioinId: '',
      isImageUpdate: false
    };
    this.messagesEndRef = React.createRef();
    this.onDragEnd = this.onDragEnd.bind(this);
  }

  componentDidMount = () => {
    this.getColorData();
    this.getPromotionData();
    // this.getinternationalsizesData();
    // this.getnumericalsizesData();
    // this.getagesizesData();
    // this.getbrasizesData();
    // this.getmiscData();

    let productId = window.location.href;
    productId = productId.substr(productId.lastIndexOf("/") + 1);
    this.setState({ product_id: productId }, () => {
      this.get_product_variation(this.state.product_id);
      // this.get_product_variant(this.state.product_id)
    });
  };

  getmiscData = () => {

    let data = {};

    let path = API_Path.getMisc;
    const getMiscPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getMiscPromise.then((res) => {
      if (res) {
        this.setState({ miscData: res.data.data, SizeGroupSizes: res.data.data });
      }
    });
  };

  getbrasizesData = () => {

    let data = {};

    let path = API_Path.getBrasizes;
    const getBraSizesPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getBraSizesPromise.then((res) => {
      if (res) {
        this.setState({ brasizesData: res.data.data, SizeGroupSizes: res.data.data });
      }
    });
  };

  getagesizesData = () => {

    let data = {};

    let path = API_Path.getAgesizes;
    const getAgesizesPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getAgesizesPromise.then((res) => {
      if (res) {
        this.setState({ agesizesData: res.data.data, SizeGroupSizes: res.data.data });
      }
    });
  };

  getnumericalsizesData = () => {

    let data = {};

    let path = API_Path.getNumericalsizes;
    const getnumericalsizesDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getnumericalsizesDataPromise.then((res) => {
      if (res) {
        this.setState({ numericalsizesData: res.data.data, SizeGroupSizes: res.data.data });
      }
    });
  };

  getinternationalsizesData = () => {

    let data = {};

    let path = API_Path.getInternationalsizes;
    const getinternationalsizesDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getinternationalsizesDataPromise.then((res) => {
      if (res) {
        this.setState({ internationalsizesData: res.data.data, SizeGroupSizes: res.data.data });
      }
    });
  };

  get_product_variation = (id) => {
    variationArray = []
    const data = { product_id: id };
    const GetProductVariationDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(API_Path.getProductVariationById, data));
    });
    GetProductVariationDataPromise.then((res) => {
      if (res) {
        let totalVariationArray = [];
        for (let i = 0; i < res.data.data.length; i++) {
          this.setState({ oldData: res.data.data[i], selectSize: res.data.data[i]?.size_group }, () => {
            if (this.state.selectSize == '1') {
              this.getinternationalsizesData();
            }
            else if (this.state.selectSize == '2') {
              this.getnumericalsizesData();
            }
            else if (this.state.selectSize == '3') {
              this.getagesizesData();
            }
            else if (this.state.selectSize == '4') {
              this.getbrasizesData();
            }
            else if (this.state.selectSize == '5') {
              this.getmiscData();
            }
            let imageArray = [];
            let imageString = this.state.oldData.images;
            imageString = imageString.split(",");
            for (let i = 0; i < imageString.length; i++) {
              let obj = {
                image: imageString[i],
                id: this.makeid(8),
              };
              imageArray.push(obj);
            }

            this.setState({
              price: this.state.oldData.price,
            })

            let data = {
              images: imageArray,
              variationName_en: this.state.oldData.variation_en,
              variationName_ar: this.state.oldData.variation_ar,
              video: this.state.oldData.videos,
              color: this.state.oldData?.color_id,
              promotion: this.state.oldData.promotion_id,
              price: this.state.oldData.price,
              discount: this.state.oldData.discount,
              realPrice: this.state.oldData.discount_price,
              id: this.state.oldData.id,
              sizeList: this.state.oldData.variant,
              size_group: this.state.oldData.size_group,

              // images: this.state.oldData.images,
              // variationName_en: this.state.variationName_en,
              // variationName_ar: this.state.variationName_ar,
              // promotionArabic: this.state.promotionArabic,
              variant: this.state.editVariationSizeList.id,
            };
            variationArray.push(data);
            this.setState(
              {
                variationList: variationArray,
                editVariationDetails: this.state.oldData,
              },
              () => {
                this.props.getVariationList(this.state.variationList);
                let char = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                let sku = char.charAt(this.state.variationList.length)
                this.setState({ skuCode: sku })
              }
            );
          })
        }

        let imageArray = this.state.oldData.images?.split(",");
        for (let j = 0; j < imageArray?.length; j++) {
          let imageData = {
            images: imageArray[j],
            id: this.makeid(8),
          };
          editImageArray.push(imageData);
          this.setState({ editVariationImages: editImageArray });
        }
        let OldVariationSize = this.state.oldData.variant;
        for (let i = 0; i < OldVariationSize?.length; i++) {
          let editvaraiationSizeData = {
            size_en: OldVariationSize[i].size_en,
            size_ar: OldVariationSize[i].size_ar,
            sku: OldVariationSize[i].sku,
            quantity: 0,
            id: OldVariationSize[i].id,
            variation_id: OldVariationSize[i].variation_id,
            size_group: this.state.oldData?.size_group?.toString(),
          };
          editVariationSizeArray.push(editvaraiationSizeData);
          this.setState({
            editVariationSizeList: editVariationSizeArray,
          }, () => {
          });
        }
      }
    });
  };

  // get_product_variant = (id) => {
  //     const data = { product_id: id }
  //     const GetProductVariantDataPromise = new Promise((resolve, reject) => {
  //         resolve(PostApi(API_Path.getProductVariantById, data))
  //     })
  //     GetProductVariantDataPromise.then((res) => {
  //         if (res.status === 200) {
  //             for (let i = 0; i < res.data.data.length; i++) {
  //                 this.setState({ oldData: res.data.data[i] }, () => {
  //                     let data = {
  //                         size: this.state.oldData.size,
  //                         sku: this.props.productCode + 'A' + this.state.oldData.sku,
  //                         quantity: this.state.oldData.quantity,
  //                         sizeListId: (this.state.oldData.id).toString(),
  //                         variation_id: (this.state.oldData.variation_id).toString()
  //                     }
  //                     variationSizeArray.push(data)
  //                     this.setState({ editVariationSizeList: variationSizeArray })
  //                 })
  //             }
  //         }
  //     })
  // }

  handleImageFile = (e) => {
    this.setState({ shouldBlockNavigation: true })
    e.preventDefault();

    let array = Object.values(e.target.files);
    this.setState({ serverImg: array })
    for (let i = 0; i < array.length; i++) {
      let imageObject = {
        src: array[i],
        id: (Math.floor(Math.random() * 1000000) + 1).toString(),
      };

      ImageFileArray.push(imageObject);
      // images.push(URL.createObjectURL(array[i]))
    }

    this.setState({ items: ImageFileArray }, () => {
      document.getElementById("SelectProductImage").value = "";
      if (this.state.items.length > 0) {
        document.getElementById("imageArrayError").style.display = "none";
      }
    });
  };

  onDragEndTable = (e) => {
    if (!e.destination) {
      return;
    }
    const { variationSizeList } = this.state;
    const sorted = reorder(variationSizeList, e.source.index, e.destination.index);
    this.setState({ variationSizeList: sorted });
  };

  onDragEndEditTable = (result) => {
    if (!result.destination) {
      return;
    } else if (result.destination.index == result.source.index) {
      return;
    } else {
      const sorted = reorder(this.state.editVariationSizeList, result.source.index, result.destination.index);
      this.state.editVariationSizeList = sorted;
      variationSizeArray = sorted;
      this.setState({ editVariationSizeList: sorted });
    }
  };

  handleEditImages = (e) => {
    let array = Object.values(e.target.files);
    for (let i = 0; i < array.length; i++) {
      let imageObject = {
        image: array[i],
        id: this.makeid(8),
      };

      editImageArray.push(imageObject);
      // console.log(URL.createObjectURL(array[i]), "[[[[]]]]")
    }
    this.setState({ editVariationImages: editImageArray, isImageUpdate: true });
    // let array = Object.values(e.target.files);
    // this.setState({ editImageToUpload: array }, () => {
    //   var formData = new FormData();
    //   for (var i = 0; i < this.state.editImageToUpload.length; i++) {
    //     formData.append("file", this.state.editImageToUpload[i]);
    //   }

    //   let path = API_Path.addFileInS3;
    //   const addFileInS3Promise = new Promise((resolve, reject) => {
    //     resolve(PostApi(path, formData));
    //   });

    //   addFileInS3Promise.then((res) => {
    //     if (res) {
    //       for (let i = 0; i < res.data.data.length; i++) {
    //         let obj = {
    //           image: res.data.data[i],
    //           id: this.makeid(8),
    //         };
    //         editImageArray.push(obj);
    //       }
    //       this.setState({ editVariationImages: editImageArray });
    //     }
    //   });
    // });
  };

  onDragEnd = (result) => {
    // dropped outside the list
    if (!result.destination) {
      return;
    }
    const items = reorder(this.state.items, result.source.index, result.destination.index);

    this.setState({
      items,
    });
  };

  onDragEndVariant = (result) => {
    if (!result.destination) {
      return;
    }
    if (result.destination.index == result.source.index) {
      return;
    }
    const variant = reorder(this.state.variationList, result.source.index, result.destination.index);
    this.setState({ variationList: variant }, () => {
      this.props.getVariationList(this.state.variationList);
    });
  };

  onEditDragEnd = (result) => {
    // dropped outside the list
    if (!result.destination) {
      return;
    }
    const editVariationImages = reorder(this.state.editVariationImages, result.source.index, result.destination.index);

    this.setState({
      editVariationImages,
    }, () => {
    });
  };

  removeImage = (id) => {
    document.getElementById("SelectProductImage").value = "";
    const filteredimage = this.state.items.filter((item) => item.id !== id);
    ImageFileArray = filteredimage;
    this.setState({ items: filteredimage }, () => {
      if (this.state.items.length == 0) {
        document.getElementById("imageArrayError").style.display = "block";
      }
    });
  };

  editVariationremoveImage = (id) => {
    document.getElementById("SelectProductImage").value = "";
    const filteredimage = this.state.editVariationImages.filter((item) => item.id !== id);
    editImageArray = filteredimage;
    this.setState({ editVariationImages: filteredimage }, () => {
      if (this.state.editVariationImages.length == 0) {
        document.getElementById("imageArrayError").style.display = "block";
      }
    });
  };

  handleEditRow = (item) => {
    this.setState({ editVariantShow: true, editSizeQuantity: item.quantity, editSize_en: item.size_en, editSize_ar: item.size_ar, EditVariationSku: item.sku });
    objIndex = this.state.variationSizeList.findIndex((obj) => obj.variation_id == item.variation_id);
  };

  editVariationEditRow = (item) => {
    this.setState({ editVariationSizeVariantShow: true, editVariationEditSizeQuantity: item.quantity, editVariationEditSize_en: item.size_en, editVariationEditSize_ar: item.size_ar, editVariationEditSizeSku: item.sku });
    EVobjIndex = this.state.editVariationSizeList.findIndex((obj) => obj.id == item.id);
  };

  handleVideoFile = (e) => {
    this.setState({ shouldBlockNavigation: true })
    // let video = [];
    // video.push(e.target.files[0]);
    let video = Object.values(e.target.files);
    this.setState({ videoFiles: video }, () => {
      this.uploadVideoToStorage()
      this.setState({ isVideoUploaded: false });
    });

  };

  removeVideo = () => {
    this.setState({ videoFiles: "", isVideoUploaded: true });
  };

  showVariation = () => {
    this.setState({ isVariationShow: true }, () => {
      let char = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
      let sku = char.charAt(this.state.variationList.length)
      this.setState({ skuCode: sku });

      // let tempArr = [];
      // tempArr = this.state.variationSizeList;
      // tempArr && tempArr.map((item) => {
      //   var obj = item;
      //   obj.sku = this.props.productCode + sku + item.size
      // })
      // this.setState({ variationSizeList: tempArr });

      this.scrollToBottom();
    });
  };

  hideVariation = () => {
    this.setState({ isVariationShow: false, variationSizeList: [] });
    // this.setState({ isVariationShow: false });
  };

  makeid = (length) => {
    let result = "";
    const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  };
  Alphabetmakeid = (length) => {
    let result = "";
    const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  };

  addImageToStorage = async () => {
    let imageArr = this.state.serverImg
    let imgarray = await ImageCompress(imageArr)
    var formData = new FormData();
    for (var i = 0; i < imgarray.length; i++) {
      formData.append("file", imgarray[i]);
    }
    let path = API_Path.addFileInS3;
    const addFileInS3Promise = new Promise((resolve, reject) => {
      resolve(PostApi(path, formData));
    });

    addFileInS3Promise.then((res) => {
      if (res) {
        let imagesUrl = [];
        for (let i = 0; i < res.data.data.length; i++) {
          let obj = {
            image: res.data.data[i],
            id: this.makeid(8),
          };
          imagesUrl.push(obj);
        }
        this.setState({ isImageUploaded: true, uploadedImages: imagesUrl });
      }
    });
  };

  uploadVideoToStorage = () => {
    if (this.state.videoFiles !== "") {


      const formData = new FormData();
      for (let i = 0; i < this.state.videoFiles.length; i++) {
        formData.append("file", this.state.videoFiles[i]);
      }

      let path = API_Path.addFileInS3;
      const addFileInS3Promise = new Promise((resolve, reject) => {
        resolve(PostApi(path, formData));
      });

      addFileInS3Promise.then((res) => {
        if (res) {
          this.setState({ isVideoUploaded: true, videoFiles: res.data.data[0] });
        }
      });
    }
  };

  handleSubmit = () => {
    if (this.state.items === "") {
      document.getElementById("imageArrayError").style.display = "block";
    }
    // if (this.state.selectcolor === "") {
    //   document.getElementById("selectColor").style.display = "block";
    // }
    // if (this.state.colorEnglish === '') {
    //     document.getElementById('englishColor').style.display = 'block'
    // }
    // if (this.state.colorArabic === '') {
    //     document.getElementById('arabicColor').style.display = 'block'
    // }
    if (this.state.price === "") {
      document.getElementById("priceVariant").style.display = "block";
    }
    if (this.state.variationSizeList.length === 0) {
      document.getElementById("variationSizeListError").style.display = "block";
    }
    console.log(this.state.variationSizeList.length)
    if (this.state.items !== "" && this.state.price !== "" && this.state.variationSizeList.length > 0) {
      console.log(this.state.variationSizeList)
      this.setState({ isLoading: true });
      ImageFileArray = [];
      this.addImageToStorage();
      this.uploadVideoToStorage();

      let createVariationInterval = setInterval(() => {
        if (this.state.isImageUploaded || this.state.isVideoUploaded) {
          clearInterval(createVariationInterval);
          this.createVariation();
        }
      }, 3000);
    }
  };

  createVariation = () => {
    let data = {
      images: this.state.uploadedImages,
      variationName_en: this.state.variationName_en,
      variationName_ar: this.state.variationName_ar,
      video: this.state.uploadedVideo,
      color: this.state.selectcolor,
      promotion: this.state.selectPromotion,
      // promotionArabic: this.state.promotionArabic,
      price: this.state.price,
      size_group: this.state.selectSize,
      discount: this.state.discount,
      realPrice: this.state.realprice,
      sizeList: this.state.variationSizeList,
      id: Date.now(),
    };
    variationArray.push(data);
    if (variationArray.length > 0) {
      console.log("create variation")
      this.setState({ variationList: variationArray ? variationArray : [] }, () => {
        this.props.getVariationList(this.state.variationList);
        this.clearState();
        this.setState({ isLoading: false });
        variationSizeArray = [];
      });
    }
  };

  updateVariation = async () => {
    let objectIndex = variationArray.findIndex((obj) => obj.id == this.state.editVariatioinId);
    if (this.state.isImageUpdate) {

      let img = this.state.editVariationImages
      let c_Img = []
      img.map((item) =>
        typeof item.image == 'object' && c_Img.push(item.image)
      )
      console.log(c_Img, "c_Img");
      let compressedImg = await ImageCompress(c_Img)
      var formData = new FormData();
      for (var i = 0; i < Object.values(compressedImg).length; i++) {
        formData.append("file", Object.values(compressedImg)[i]);
      }
      let path = API_Path.addFileInS3;
      const addFileInS3Promise = new Promise((resolve, reject) => {
        resolve(PostApi(path, formData));
      });
      addFileInS3Promise.then((res) => {
        if (res) {
          let finalImg = editImageArray.filter(obj => typeof obj.image !== 'object')
          editImageArray = finalImg
          for (let i = 0; i < res.data.data.length; i++) {
            let obj = {
              image: res.data.data[i],
              id: this.makeid(8),
            };
            editImageArray.push(obj);
          }
          this.setState({ editVariationImages: editImageArray, isLoading: false, isImageUpdate: false }, () => {
            variationArray[objectIndex].images = this.state.editVariationImages;
            variationArray[objectIndex].variationName_en = this.state.editVariationNameEn;
            variationArray[objectIndex].variationName_ar = this.state.editVariationNameAr;
            variationArray[objectIndex].video = this.state.isVideoUploaded ? this.state.videoFiles : this.state.editVariationVideo;
            variationArray[objectIndex].color = this.state.editVariationColor;
            variationArray[objectIndex].promotion = this.state.editVariationPromotion;
            variationArray[objectIndex].price = this.state.editVariationPrice;
            variationArray[objectIndex].discount = this.state.editVariationDiscount;
            variationArray[objectIndex].realPrice = this.state.editVariationRealPrice;
            variationArray[objectIndex].selectedSize = this.state.selectSize;
            variationArray[objectIndex].sizeList = this.state.editVariationSizeList;
            variationArray[objectIndex].deletedVariantId = deletedIdArray;
            variationArray[objectIndex].size_group = this.state.selectSize;

            //Log object to console again.

            if (variationArray.length > 0) {
              this.setState({ variationList: variationArray }, () => {
                this.props.getVariationList(this.state.variationList);
                this.clearState();
                this.setState({ isLoading: false, variationSizeList: [] });
                variationSizeArray = [];
                this.edit_var_Close();
              });
            }
          })
        }
      })
    } else {
      variationArray[objectIndex].images = this.state.editVariationImages;
      variationArray[objectIndex].variationName_en = this.state.editVariationNameEn;
      variationArray[objectIndex].variationName_ar = this.state.editVariationNameAr;
      variationArray[objectIndex].video = this.state.isVideoUploaded ? this.state.videoFiles : this.state.editVariationVideo;
      variationArray[objectIndex].color = this.state.editVariationColor;
      variationArray[objectIndex].promotion = this.state.editVariationPromotion;
      variationArray[objectIndex].price = this.state.editVariationPrice;
      variationArray[objectIndex].discount = this.state.editVariationDiscount;
      variationArray[objectIndex].realPrice = this.state.editVariationRealPrice;
      variationArray[objectIndex].selectedSize = this.state.selectSize;
      variationArray[objectIndex].sizeList = this.state.editVariationSizeList;
      variationArray[objectIndex].deletedVariantId = deletedIdArray;
      variationArray[objectIndex].size_group = this.state.selectSize;

      //Log object to console again.

      if (variationArray.length > 0) {
        this.setState({ variationList: variationArray }, () => {
          this.props.getVariationList(this.state.variationList);
          this.clearState();
          this.setState({ isLoading: false, variationSizeList: [] });
          variationSizeArray = [];
          this.edit_var_Close();
        });
      }

    }
  };

  clearState = () => {
    this.setState({ items: "", videoFiles: "", selectcolor: "", isVariationShow: false, uploadedImages: "", isImageUploaded: false });
  };

  errorContainer = (form, field) => {
    return form.touched[field] && form.errors[field] ? <span className="error text-danger">{form.errors[field]}</span> : null;
  };

  formAttr = (form, field) => ({
    onBlur: form.handleBlur,
    onChange: form.handleChange,
    value: form.values[field],
  });

  handleNumberChange = (e) => {
    if (e.target.value >= 0) {
      this.setState({ [e.target.name]: e.target.value });
    }
  };

  handlePriceChange = (e) => {
    this.setState({ shouldBlockNavigation: true })
    if (e.target.value >= 0) {
      this.setState({ realprice: parseFloat(e.target.value).toFixed(2) })
      if (this.state.realprice !== "") {
        this.setState({ price: e.target.value }, () => {
          document.getElementById("priceVariant").style.display = "none";
          this.setState({ realprice: parseFloat(e.target.value).toFixed(2) });
        });
      } else {
        this.setState({ price: e.target.value }, () => {
          document.getElementById("priceVariant").style.display = "none";
          this.setState({ realprice: parseFloat(e.target.value).toFixed(2) });
        });
      }
    }
  };

  handleDiscountChange = (e) => {
    this.setState({ shouldBlockNavigation: true })
    if (e.target.value >= 0) {
      if (this.state.price !== "") {
        document.getElementById("priceVariant").style.display = "none";
        if (e.target.value < 100) {
          this.setState({ discount: e.target.value }, () => {
            let totalDiscountPrice = (this.state.price / 100) * this.state.discount;
            let updatedRealPrice = this.state.price - totalDiscountPrice;
            this.setState({ realprice: parseFloat(updatedRealPrice).toFixed(2) });
          });
        }
      } else {
        document.getElementById("priceVariant").style.display = "block";
      }
    }
  };

  handleRealPriceChange = (e) => {
    this.setState({ shouldBlockNavigation: true })
    if (e.target.value >= 0) {
      if (this.state.price !== "") {
        document.getElementById("priceVariant").style.display = "none";
        if (parseFloat(e.target.value) <= parseFloat(this.state.price) || e.target.value === "") {
          if (this.state.discount !== '') {
            this.setState({ realprice: e.target.value }, () => {
              let discount = (this.state.realprice / this.state.price) * 100;
              let discountPer = 100 - discount;
              this.setState({ discount: parseFloat(discountPer).toFixed(2) });
            });
          }
        }
      } else {
        document.getElementById("priceVariant").style.display = "block";
      }
    }
  };

  handleEditPriceChange = (e) => {
    if (e.target.value >= 0) {
      if (this.state.editVariationRealPrice !== "") {
        this.setState({ editVariationPrice: e.target.value }, () => {
          document.getElementById("priceVariant").style.display = "none";
          if (this.state.editVariationRealPrice !== "") {
          } else if (this.state.editVariationDiscount !== "") {
            let totalDiscountPrice = (this.state.editVariationPrice / 100) * this.state.editVariationDiscount;
            let updatedRealPrice = this.state.editVariationPrice - totalDiscountPrice;
            this.setState({ editVariationRealPrice: parseFloat(updatedRealPrice).toFixed(2) });
          }
        });

      } else {
        this.setState({ price: e.target.value }, () => {
          document.getElementById("priceVariant").style.display = "none";
          if (this.state.editVariationRealPrice !== "") {
            let discount = (this.state.editVariationRealPrice / this.state.editVariationPrice) * 100;
            let discountPer = 100 - discount;
            this.setState({ editVariationDiscount: parseFloat(discountPer).toFixed(2) });
          } else if (this.state.editVariationDiscount !== "") {
            let totalDiscountPrice = (this.state.editVariationPrice / 100) * this.state.editVariationDiscount;
            let updatedRealPrice = this.state.editVariationPrice - totalDiscountPrice;
            this.setState({ editVariationRealPrice: parseFloat(updatedRealPrice).toFixed(2) });
          }
        });
      }
    }
  };

  handleEditDiscountChange = (e) => {
    if (e.target.value >= 0) {
      if (this.state.editVariationPrice !== "") {
        document.getElementById("priceVariant").style.display = "none";
        if (e.target.value < 100) {
          this.setState({ editVariationDiscount: e.target.value }, () => {
            let totalDiscountPrice = (this.state.editVariationPrice / 100) * this.state.editVariationDiscount;
            let updatedRealPrice = this.state.editVariationPrice - totalDiscountPrice;

            this.setState({ editVariationRealPrice: parseFloat(updatedRealPrice).toFixed(2) });
          });
        }
      } else {
        document.getElementById("priceVariant").style.display = "block";
      }
    }
  };

  handleEditRealPriceChange = (e) => {
    if (e.target.value >= 0) {
      if (this.state.editVariationPrice !== "") {
        document.getElementById("priceVariant").style.display = "none";
        if (parseFloat(e.target.value) < parseFloat(this.state.editVariationPrice) || e.target.value === "") {
          this.setState({ editVariationRealPrice: e.target.value }, () => {
            // this.setState({ realPrice: this.state.price }, () => {
            let discount = (this.state.editVariationRealPrice / this.state.editVariationPrice) * 100;
            let discountPer = 100 - discount;
            this.setState({ editVariationDiscount: parseFloat(discountPer).toFixed(2) });
            // })
          });
        }
      } else {
        document.getElementById("priceVariant").style.display = "block";
      }
    }
  };

  // handleEditNumberChange = (e) => {
  //     if (e.target.value >= 0) {
  //         this.setState({ [e.target.name]: e.target.value }, () => {
  //             if (this.state.editVariationPrice !== '') {
  //                 document.getElementById('priceVariant').style.display = 'none'
  //             } else {
  //                 document.getElementById('priceVariant').style.display = 'block'
  //             }

  //             if (this.state.editVariationRealPrice === '') {
  //                 this.setState({ editVariationDiscount: 0 })
  //             } else {
  //                 this.setState({
  //                     editVariationDiscount: parseInt(100 - (this.state.editVariationRealPrice / this.state.editVariationPrice) * 100),
  //                 })
  //             }
  //         })
  //     }
  // }

  handleSearchFocus = () => {
    if (document.getElementById("pro-list")) {
      document.getElementById("pro-list").classList.add("active");
    }
  };

  handleSearchBlur = () => {
    setTimeout(() => {
      if (document.getElementById("pro-list")) {
        document.getElementById("pro-list").classList.remove("active");
      }
    }, 500);
  };

  handleTextChange = (e) => {
    // var index = e.target.selectedIndex;
    // var el = e.target.childNodes[index]
    // var sizeId = el?.getAttribute('id');
    if (document.getElementById("pro-list")) {
      document.getElementById("pro-list").classList.add("active");
    }

    this.setState({ search_val_en: e.target.value?.split('|')[0], search_val_ar: e.target.value?.split('|')[e.target.value?.split('|')?.length - 1] }, () => {
      // this.setState({ search_val_en: e.target.value?.split('|')[0], search_val_ar: e.target.value?.split('|')[e.target.value?.split('|')?.length - 1], selectedVariantSize: sizeId, size_en: e.target.value?.split('|')[0], size_ar: e.target.value?.split('|')[e.target.value?.split('|')?.length - 1], editSize_en: e.target.value?.split('|')[0], editSize_ar: e.target.value?.split('|')[e.target.value?.split('|')?.length - 1], editVariationAddSize_en: e.target.value?.split('|')[0], editVariationAddSize_ar: e.target.value?.split('|')[e.target.value?.split('|')?.length - 1], editVariationEditSize_en: e.target.value?.split('|')[0], editVariationEditSize_ar: e.target.value?.split('|')[e.target.value?.split('|')?.length - 1] }, () => {
      // if (document.getElementById('errorSize')) {
      //   document.getElementById('errorSize').classList.add('d-none')
      //   document.getElementById('errorSize').classList.remove('d-block')
      // }
      // if (document.getElementById('addErrorSize')) {
      //   document.getElementById('addErrorSize').classList.add('d-none')
      //   document.getElementById('addErrorSize').classList.remove('d-block')
      // }
    });
  };

  handleClickSize = (english, arabic, id) => {
    this.setState({ search_val_en: english, search_val_ar: arabic, size_en: english, size_ar: arabic, editSize_en: english, editSize_ar: arabic, editVariationAddSize_en: english, editVariationAddSize_ar: arabic, editVariationEditSize_en: english, editVariationEditSize_ar: arabic, selectedVariantSize: id, selectedSizeId: id }, () => {
      if (document.getElementById('sizeInput')) {
        document.getElementById('sizeInput').value = this.context.language === 'english' ? english : arabic
      }
      if (document.getElementById('editSizeInput')) {
        document.getElementById('editSizeInput').value = this.context.language === 'english' ? english : arabic
      }
      if (document.getElementById('errorSize')) {
        document.getElementById('errorSize').classList.add('d-none')
        document.getElementById('errorSize').classList.remove('d-block')
      }
      if (document.getElementById('addErrorSize')) {
        document.getElementById('addErrorSize').classList.add('d-none')
        document.getElementById('addErrorSize').classList.remove('d-block')
      }
    });
  }

  handleColorChange = (e) => {
    this.setState({ [e.target.name]: e.target.value, shouldBlockNavigation: true });
  };

  handlePromotionChange = (e) => {
    this.setState({ [e.target.name]: e.target.value, shouldBlockNavigation: true });
  };

  handleQuantityChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  handleClear = (itemToClear) => {
    this.setState({ [itemToClear]: 0 });
  };

  removeVariation = (id) => {
    const filteredVariations = this.state.variationList.filter((item) => item.id !== id);
    variationArray = filteredVariations ? filteredVariations : [];
    this.setState({ variationList: filteredVariations }, () => {
      this.props.getVariationList(this.state.variationList);
    });
  };

  scrollToBottom = () => {
    this.messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
  };

  addpro = () => {
    this.setState({ addproduct_show: true, sizeQuantity: "", AddVariationSku: this.makeid(8) });

    for (let i = 0; i < this.state.variationSizeList.length; i++) {
    }
  };

  editVariationAddPro = () => {
    this.setState({ editVariationAddproduct_show: true, editVariationAddSizeQuantity: "", EditAddVariationSku: this.makeid(8) });
  };

  edit_Close = () => {
    this.setState({ addproduct_show: false, search_val_ar: '', search_val_en: '' });
  };

  editVariationAddProductPopupClose = () => {
    this.setState({ editVariationAddproduct_show: false, search_val_ar: '', search_val_en: '' });
  };

  edit_variation = (variationDetails) => {
    this.setState(
      {
        edit_var: true,
        isVideoUploaded: false,
        editVariationDetails: variationDetails,
        editVariationImages: variationDetails.images,
        editVariationVideo: variationDetails.video,
        editVariationNameEn: variationDetails.variationName_en,
        editVariationNameAr: variationDetails.variationName_ar,
        editVariationColor: variationDetails.color,
        editVariationPromotion: variationDetails.promotion,
        editVariationRealPrice: variationDetails.realPrice,
        editVariationPrice: variationDetails.price,
        editVariationDiscount: variationDetails.discount,
        editVariationSizeList: variationDetails.sizeList,
        editVariatioinId: variationDetails.id,
        selectSize: variationDetails?.size_group,
      },
      () => {
        editImageArray = variationDetails.images;
        editVariationSizeArray = variationDetails.sizeList;
      }
    );
  };

  edit_var_Close = () => {
    this.setState({ edit_var: false });
  };

  handleModalSubmit = () => {
    if (this.state.sizeQuantity !== "") {
      const d = Date.now();
      let nid = d.toString();
      let data = {
        size_en: this.state.size_en,
        size_ar: this.state.size_ar,
        size_id: this.state.selectedSizeId,
        sku: `${(this.state.AddVariationSku + (this.context.language === 'english' ? this.state.size_en : this.state.size_ar)).toUpperCase()}`,
        quantity: this.state.sizeQuantity,
        id: this.Alphabetmakeid(8),
        variation_id: nid,
        size_group: this.state.selectSize,

        // variation_id: this.state.editVariatioinId,
      };
      let addarrsize = []

      this.state.variationSizeList && this.state.variationSizeList.map((item) => {
        addarrsize.push(item.size_en + " | " + item.size_ar)
      })
      if (!addarrsize.includes(data.size_en + " | " + data.size_ar)) {
        variationSizeArray.push(data);
        this.setState({ variationSizeList: variationSizeArray }, () => {
          this.edit_Close();
        });
      } else {
        document.getElementById('addErrorSize').classList.remove('d-none')
        document.getElementById('addErrorSize').classList.add('d-block')
      }
      // variationSizeArray.push(data);
      // let filtered = variationSizeArray.length > 0 && variationSizeArray.filter((item) => item.selectedSize === this.state.selectSize);
      // this.setState({ variationSizeList: filtered ? filtered : [] });
      // this.setState({ variationSizeList: variationSizeArray });

      // this.edit_Close();
      this.setState(
        {
          size_en: "",
          size_ar: "",
          search_val_en: "",
          search_val_ar: "",
          editSizeQuantity: this.state.sizeQuantity,
          // variationSizeList: variationSizeArray,
        },
        () => {
          document.getElementById("variationSizeListError").style.display = "none";
        }
      );
    } else {
      toastr.error("Please add quantity");
    }
  };

  // handleEditVariationAddProModalSubmit = () => {
  //   if (this.state.editVariationAddSizeQuantity !== "") {
  //     let d = this.makeid(8);
  //     let nid = d.toString();
  //     let id = this.state.editVariatioinId;
  //     let vid = id.toString();
  //     let data = {
  //       size_en: this.state.editVariationAddSize_en,
  //       size_ar: this.state.editVariationAddSize_ar,
  //       sku: `${((this.props.productCode) + (this.state.skuCode) + (this.context.language === 'english' ? this.state.editVariationAddSize_en : this.state.editVariationAddSize_ar)).toUpperCase()
  //         }`,
  //       quantity: this.state.editVariationAddSizeQuantity,
  //       sizeListId: nid,
  //       variation_id: vid,
  //       size_group: this.state.selectSize,
  //     };

  //     editVariationSizeArray.push(data);
  //     let filtered = editVariationSizeArray.length > 0 && editVariationSizeArray.filter((item) => item.selectedSize === this.state.selectSize);

  //     this.editVariationAddProductPopupClose();
  //     this.setState(
  //       {
  //         editVariationAddSize_en: "",
  //         editVariationAddSize_ar: "",
  //         // editVariationAddSizeQuantity: this.state.editVariationAddSizeQuantity,
  //         editVariationAddSizeQuantity: "",
  //         editVariationSizeList: filtered ? filtered : [],
  //       },
  //       () => {
  //         document.getElementById("variationSizeListError").style.display = "none";
  //       }
  //     );
  //   } else {
  //     toastr.error("Please add quantity");
  //   }
  // };

  handleEditModalSubmit = (id) => {
    this.state.variationSizeList[objIndex].quantity = this.state.editSizeQuantity;
    this.state.variationSizeList[objIndex].size_en = this.state.editSize_en;
    this.state.variationSizeList[objIndex].size_ar = this.state.editSize_ar;
    this.state.variationSizeList[objIndex].size_id = this.state.selectedSizeId;
    this.state.variationSizeList[objIndex].sku = (this.props.productCode) + (this.state.skuCode) + (this.context.language === 'english' ? this.state.editSize_en : this.state.editSize_ar);
    this.editVariantClose();

  };

  handleAddNewSizeModalSubmit = () => {
    let data = {
      size_en: this.state.editVariationAddSize_en,
      size_ar: this.state.editVariationAddSize_ar,
      size_id: this.state.selectedSizeId,
      sku: (this.state.EditAddVariationSku + (this.context.language === 'english' ? this.state.editVariationAddSize_en : this.state.editVariationAddSize_ar)).toUpperCase(),
      quantity: this.state.editVariationAddSizeQuantity,
      id: this.Alphabetmakeid(8),
      variation_id: this.state.editVariatioinId.toString(),
      size_group: this.state.selectSize,
    };
    let arrsize = []


    this.state.editVariationSizeList && this.state.editVariationSizeList.map((item) => {
      arrsize.push(item.size_en + " | " + item.size_ar)
    })
    if (!arrsize.includes(data.size_en + " | " + data.size_ar)) {
      editVariationSizeArray.push(data);
      this.setState({ editVariationSizeList: editVariationSizeArray, search_val_en: "", search_val_ar: "", }, () => {
        this.editVariationAddProductPopupClose();
      });
    } else {
      document.getElementById('errorSize').classList.remove('d-none')
      document.getElementById('errorSize').classList.add('d-block')
    }
  };

  handleEditVariationEditModalSubmit = (id) => {
    this.state.editVariationSizeList[EVobjIndex].size_en = this.state.editVariationEditSize_en;
    this.state.editVariationSizeList[EVobjIndex].size_ar = this.state.editVariationEditSize_ar;
    this.state.editVariationSizeList[EVobjIndex].size_id = this.state.selectedSizeId;
    this.state.editVariationSizeList[EVobjIndex].quantity = this.state.editVariationEditSizeQuantity;
    // this.state.editVariationSizeList[EVobjIndex].sku = this.props.productCode + this.state.skuCode + (this.context.language === 'english' ? this.state.editVariationEditSize_en : this.state.editVariationEditSize_ar);
    this.editvariationEditsizePopupClose();
  };

  editVariantClose = () => {
    this.setState({ editVariantShow: false });
  };

  editvariationEditsizePopupClose = () => {
    this.setState({ editVariationSizeVariantShow: false });
  };

  handleRemoveRow = (id) => {
    variationSizeArray = this.state.variationSizeList
    console.log(id, '{}==', variationSizeArray);
    const filteredSize = variationSizeArray.length > 0 && variationSizeArray.filter((item) => item.id !== id);
    const filteredSize1 = filteredSize.length > 0 && filteredSize.filter((item) => item.selectedSize === this.state.selectSize);

    variationSizeArray = filteredSize1 ? filteredSize : []
    this.setState({
      variationSizeList: variationSizeArray
    }, () => {
      console.log(this.state.variationSizeList)
    });
  };

  isNumber = (evt) => {
  };

  editVariationRemoveRow = (id) => {
    if (!isNaN(id)) {
      deletedIdArray.push(parseInt(id));
    }
    const filteredSize = this.state.editVariationSizeList.length > 0 && this.state.editVariationSizeList.filter((item) => item.id !== id);
    // const filteredSize1 = filteredSize.length > 0 && filteredSize.filter((item) => item.selectedSize === this.state.selectSize);

    // const filteredSize = editVariationSizeArray.filter((item) => (item.sizeListId ? item.sizeListId !== id : item.id !== id));
    editVariationSizeArray = filteredSize;
    this.setState({ editVariationSizeList: editVariationSizeArray });
  };

  delete_variation = (id) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>Are you sure?</h1>
            <p> Do you want to delet this Variation?</p>
            <button className="btn red-btn me-2" onClick={onClose}>
              No
            </button>
            <button
              className="btn red-btn"
              onClick={() => {
                // this.finaly_delete_record(id);
                onClose();
                this.removeVariation(id);
              }}
            >
              Delete
            </button>
          </div>
        );
      },
    });
  };

  delete_record = (data) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>Are you sure?</h1>
            <p> Do you want to delet this item?</p>
            <button className="btn red-btn me-2" onClick={onClose}>
              No
            </button>
            <button
              className="btn red-btn"
              onClick={() => {
                this.handleRemoveRow(data);
                onClose();
              }}
            >
              Delete
            </button>
          </div>
        );
      },
    });
  };

  editVariationDelete_record = (id) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>Are you sure?</h1>
            <p> Do you want to delet this item?</p>
            <button className="btn red-btn me-2" onClick={onClose}>
              No
            </button>
            <button
              className="btn red-btn"
              onClick={() => {
                // this.finaly_delete_record(id);
                onClose();
                this.editVariationRemoveRow(id);
              }}
            >
              Delete
            </button>
          </div>
        );
      },
    });
  };

  finaly_delete_record = (id) => {
    alert(id);
  };

  getColorData = () => {
    let path = API_Path.getColor;
    const getColorPromise = new Promise((resolve) => {
      resolve(PostApi(path));
    });
    getColorPromise.then((respons) => {
      if (respons) {
        this.setState({ color: respons.data.data });
      }
    });
  };

  handleSizeChange = (e) => {
    this.setState({ shouldBlockNavigation: true, selectSize: e.target.value, ErrMsg: "", ErrMsg1: "", variationSizeList: [], editVariationSizeList: [] }, () => {
      document.getElementById("variationSizeListError").style.display = "none";
      if (this.state.selectSize === '1') {
        this.getinternationalsizesData();
      }
      else if (this.state.selectSize === '2') {
        this.getnumericalsizesData();
      }
      else if (this.state.selectSize === '3') {
        this.getagesizesData();
      }
      else if (this.state.selectSize === '4') {
        this.getbrasizesData();
      }
      else if (this.state.selectSize === '5') {
        this.getmiscData();
      }
    });

    // let filtered = variationSizeArray.length > 0 && variationSizeArray.filter((item) => item.selectedSize === e.target.value);
    // let filtered1 = editVariationSizeArray.length > 0 && editVariationSizeArray.filter((item) => item.selectedSize === e.target.value);

    // if (filtered) {
    //   this.setState({ variationSizeList: filtered ? filtered : [] });
    // } else {
    // this.setState({ variationSizeList: [] });
    // }
    // if (filtered1) {
    //   this.setState({ editVariationSizeList: filtered1 ? filtered1 : [] });
    // } else {
    //   this.setState({ editVariationSizeList: [] });
    // }
    variationSizeArray = [];
    editVariationSizeArray = [];
  };

  getPromotionData = () => {
    let path = API_Path.getPromotion;
    const getPromotionPromise = new Promise((resolve) => {
      resolve(PostApi(path));
    });
    getPromotionPromise.then((respons) => {
      if (respons) {
        this.setState({ promotion: respons.data.data });
      }
    });
  };

  imgChange = (e) => {
  };

  render() {
    let productLanguage = this.context.language === "english" ? productEnglish : productArabic;
    let ButtonLanguage = this.context.language === "english" ? buttonEnglish : buttonArabic;

    return (
      <React.Fragment>
        <Prompt when={this.state.shouldBlockNavigation === true} message="You have unsaved changes, are you sure you want to leave?" />

        {this.state.isLoading && (
          <div className="loader-main">
            <div className="loader-inr">
              <img src={loader} alt="" />
            </div>
          </div>
        )}
        <div ref={this.messagesEndRef}>
          <div className="row common-space">
            <div className="col-md-12">
              <div className="white-box">
                <div className="custom-bx-drop-varant">
                  <div className="img-preview d-inline-block align-middle">
                    <ul>
                      {this.state.variationList.length > 0 && (
                        <DragDropContext onDragEnd={this.onDragEndVariant}>
                          <Droppable droppableId="droppable" direction="horizontal">
                            {(provided, snapshot) => (
                              <div ref={provided.innerRef} style={getListStyle(snapshot.isDraggingOver, this.state.variationList.length)} {...provided.droppableProps}>
                                {this.state.variationList.map((item, index) => (
                                  <Draggable key={item.id.toString()} draggableId={item.id.toString()} index={index}>
                                    {(provided, snapshot) => (
                                      <div ref={provided.innerRef} {...provided.draggableProps} {...provided.dragHandleProps} style={getItemStyle(snapshot.isDragging, provided.draggableProps.style)}>
                                        <li>
                                          <div className="img-preview-main position-relative">
                                            <img src={item.images.length > 0 ? item.images[0].image : ""} alt="" onClick={() => this.edit_variation(item)} />
                                            <div className="remove-img-btn">
                                              <i onClick={() => this.delete_variation(item.id)} className="bi bi-x-circle-fill" />
                                            </div>
                                          </div>
                                        </li>
                                      </div>
                                    )}
                                  </Draggable>
                                ))}
                                {provided.placeholder}
                              </div>
                            )}
                          </Droppable>
                        </DragDropContext>
                      )}
                    </ul>
                  </div>
                  <div onClick={this.showVariation} className="img-with-close-varia position-relative cursor-pointer ms-3 align-middle">
                    <p>
                      <i className="bi bi-plus-lg"></i>
                    </p>
                  </div>
                </div>
                {/* <div className="row flex-wrap align-items-center">
                  {this.state.variationList && this.state.variationList.length > 0 && this.state.variationList.map((item, i) => {
                    return (
                      <div key={i} className="col-md-1 text-center my-3">
                        <div className="img-with-close-varia position-relative">
                          <img src={item.images?.length > 0 ? APIBaseUrl + item.images[0].image : ''} alt="" onClick={() => this.edit_variation(item)} />
                          <div onClick={() => this.delete_variation(item.id)} className="close_variant">
                            <i className="bi bi-x-lg"></i>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                  <div className="col-md-1 text-center my-3 cursor-pointer" onClick={this.showVariation} >
                    <div className="img-with-close-varia position-relative">
                      <p><i className="bi bi-plus-lg"></i></p>
                    </div>
                  </div>
                </div> */}
              </div>
            </div>
          </div>

          {this.state.isVariationShow && (
            <div className="row common-space">
              <div className="col-md-12">
                <div className="white-box">
                  <div className="row">
                    <div className="col-lg-6 mb-lg-0 mb-3">
                      <div className="row ">
                        <div className="col-md-12">
                          <div className="product-in-title d-flex align-items-center pb-3 custom-border-title">
                            <span>{productLanguage.ProductImage}</span>
                          </div>
                        </div>
                        <div className="col-md-12 mt-3">
                          <div className="upload-file-section-new position-relative">
                            <div className="file-selecter text-center position-relative h-auto">
                              <div className="file-area position-relative py-3">
                                <input type="file" name="productImage" id="SelectProductImage" onChange={this.handleImageFile} accept="image/*" multiple />
                                <div className="file-dummy">
                                  <div className="file-upload-content mb-3">
                                    <img className="file-dummy-image" src={dragimg} alt="" />
                                  </div>
                                  <span>
                                    {productLanguage.DragDrop}
                                    <bdi className="d-block">{productLanguage.or}</bdi>
                                  </span>
                                  <button className="btn red-btn mt-3">{productLanguage.BrowseFiles}</button>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div id="imageArrayError" style={{ display: "none" }} className="input-feedback text-danger">
                            Required
                          </div>
                        </div>
                        <div className="col-md-12">
                          <span>{productLanguage.UploadedImageFile}</span>
                          <div className="img-preview">
                            <ul>
                              {this.state.items.length > 0 && (
                                <DragDropContext onDragEnd={this.onDragEnd}>
                                  <Droppable droppableId="droppable" direction="horizontal">
                                    {(provided, snapshot) => (
                                      <div ref={provided.innerRef} style={getListStyle(snapshot.isDraggingOver, this.state.items.length)} {...provided.droppableProps}>
                                        {this.state.items.map((item, index) => (
                                          <Draggable key={item.id} draggableId={item.id} index={index}>
                                            {(provided, snapshot) => (
                                              <div ref={provided.innerRef} {...provided.draggableProps} {...provided.dragHandleProps} style={getItemStyle(snapshot.isDragging, provided.draggableProps.style)}>
                                                <li>
                                                  <div className="img-preview-main position-relative">
                                                    <img src={URL.createObjectURL(item.src)} alt="" />
                                                    <div className="remove-img-btn">
                                                      <i
                                                        onClick={() => {
                                                          this.removeImage(item.id);
                                                        }}
                                                        className="bi bi-x-circle-fill"
                                                      />
                                                    </div>
                                                  </div>
                                                </li>
                                              </div>
                                            )}
                                          </Draggable>
                                        ))}
                                        {provided.placeholder}
                                      </div>
                                    )}
                                  </Droppable>
                                </DragDropContext>
                              )}
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-lg-6 mb-lg-0 mb-3">
                      <div className="row">
                        <div className="col-md-12">
                          <div className="product-in-title d-flex align-items-center pb-3 custom-border-title">
                            <span>{productLanguage.VideoOptional}</span>
                          </div>
                        </div>
                        <div className="col-md-12 mt-3">
                          <div className="upload-file-section-new position-relative">
                            <div className="file-selecter text-center position-relative h-auto">
                              <div className="file-area position-relative py-3">
                                <input type="file" name="licence_image_temp" onChange={this.handleVideoFile} accept="video/*" />
                                <div className="file-dummy">
                                  <div className="file-upload-content mb-3">
                                    <img className="file-dummy-image" src={dragimg} alt="" />
                                  </div>
                                  <span>
                                    {productLanguage.DragDrop}
                                    <bdi className="d-block">or</bdi>
                                  </span>
                                  <button className="btn red-btn mt-3">{productLanguage.UploadVideo}</button>
                                </div>
                              </div>
                            </div>
                          </div>
                          <span>{productLanguage.UploadedVideoFile} (mp4, flv)</span>
                        </div>
                        <div className="col-md-12 mt-3">
                          <span>{productLanguage.UploadedVideoFile}</span>
                          <div className="video-preview">
                            <ul>
                              {this.state.videoFiles && (
                                <li className="gray-bg-video grey-close-btn   my-2">
                                  <div className="video-thumb position-relative p-2">
                                    {/* <video width="100px" height="100px" poster={Poster}> */}
                                    <video width="100px" height="100px">
                                      <source src={this.state.videoFiles} type="video/mp4" />
                                    </video>
                                    {/* <img src="" alt="" /> */}
                                    <div className="video-icn-pro">
                                      <img src={videoicn} alt="" />
                                    </div>
                                    <div className="remove-btn">
                                      <i onClick={this.removeVideo} className="bi bi-x-circle-fill"></i>
                                    </div>
                                  </div>
                                  {/* <div className="vide-prev-txt ms-2">
                                      <p className="mb-0">{this.state.videoFiles[0].name}</p>
                                      <bdi>{this.state.videoFiles.size}</bdi>
                                    </div> */}
                                </li>
                              )}
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-lg-6 mb-lg-0 mb-3">
                      <div className="row">
                        {/* <div className="form-group col-md-6">
                          <label>Variation name in English</label>
                          <input type="text" className="input-custom-class form-control" placeholder="Variaton name" name='variationName_en' defaultValue={this.state.variationName_en} onChange={this.handleTextChange} />
                          <span style={{ display: 'none' }} className="input-feedback text-danger">Required</span>
                        </div>
                        <div className="form-group col-md-6">
                          <label>Variation name in Arabic</label>
                          <input type="text" dir='rtl' className="input-custom-class form-control" placeholder="اسم الاختلاف" name='variationName_ar' defaultValue={this.state.variationName_ar} onChange={this.handleTextChange} />
                          <span style={{ display: 'none' }} className="input-feedback text-danger">Required</span>
                        </div> */}
                        {/* <div className="form-group col-md-6">
                          <label>Color in English</label>
                          <input type="text" className="input-custom-class form-control" name="colorEnglish" value={this.state.colorEnglish} onChange={this.handleTextChange} placeholder="Black" />
                          <span id='englishColor' style={{ display: 'none' }} className="input-feedback text-danger">Required</span>
                        </div>
                        <div className="form-group col-md-6">
                          <label>Color in Arabic</label>
                          <input type="text" className="input-custom-class form-control" name="colorArabic" value={this.state.colorArabic} onChange={this.handleTextChange} placeholder="Black" />
                          <span id='arabicColor' style={{ display: 'none' }} className="input-feedback text-danger">Required</span>
                        </div> */}
                        <div className="form-group col-md-12">
                          <label>{productLanguage.selectColor}</label>
                          <select className="form-select input-custom-class" name="selectcolor" onChange={this.handleColorChange}>
                            <option defaultValue>{productLanguage.selectColor}</option>
                            {/* <option value="0">
                              Multicolor | متعدد اللألوان
                            </option> */}
                            {this.state.color.length > 0 &&
                              this.state.color?.map((item, i) => {
                                return (
                                  <option key={i} value={item.id}>
                                    {item.english} | {item.arabic}
                                  </option>
                                );
                              })}
                          </select>
                          <span id="selectColor" style={{ display: "none" }} className="input-feedback text-danger">
                            Required
                          </span>
                        </div>
                        <div className="form-group col-md-12">
                          <label>{productLanguage.PromotionEnglish}</label>
                          <select className="form-select input-custom-class" name="selectPromotion" onChange={this.handlePromotionChange}>
                            <option defaultValue>{productLanguage.selectPromotion}</option>
                            {this.state.promotion.length > 0 &&
                              this.state.promotion?.map((item, i) => {
                                return (
                                  <option key={i} value={item.id}>
                                    {item.english} | {item.arabic}
                                  </option>
                                );
                              })}
                          </select>
                        </div>
                        {/* <div className="form-group col-md-6">
                          <label>Promotion in Arabic</label>
                          <input type="text" className="input-custom-class form-control" name='promotionArabic' value={this.state.promotionArabic} onChange={this.handleTextChange} placeholder="2 for 50" />
                          <span style={{ display: 'none' }} className="input-feedback text-danger">Required</span>
                        </div> */}
                        <div className="form-group col-md-12">
                          <label>{productLanguage.Price}</label>
                          <input type="number" className="input-custom-class form-control" name="price" value={this.state.price} onChange={this.handlePriceChange} placeholder="200 SAR" />
                          <span id="priceVariant" style={{ display: "none" }} className="input-feedback text-danger">
                            Required
                          </span>
                        </div>
                        <div className="form-group col-md-12">
                          <label>{productLanguage.Discount}</label>
                          <input type="number" className="input-custom-class form-control" name="discount" value={this.state.discount} onChange={this.handleDiscountChange} placeholder="10%" />
                          <span id="discountVariant" style={{ display: "none" }} className="input-feedback text-danger">
                            Required
                          </span>
                        </div>
                        <div className="form-group col-md-12">
                          <label>{productLanguage.realPrice}</label>
                          <input type="number" className="input-custom-class form-control" name="realprice" value={this.state.realprice} onChange={this.handleRealPriceChange} placeholder="100 SAR" />
                          <span id="realpriceVariant" style={{ display: "none" }} className="input-feedback text-danger">
                            Required
                          </span>
                        </div>
                        <div className="form-group col-md-12">
                          <label>{productLanguage.sizeGroup}</label>
                          <select className="form-select input-custom-class" value={this.state.selectSize} name="selectsize" onChange={this.handleSizeChange}>
                            <option value="0">
                              {productLanguage.selectSize}
                            </option>
                            <option value="1">{productLanguage.international}</option>
                            <option value="2">{productLanguage.numerical}</option>
                            <option value="3">{productLanguage.ageWise}</option>
                            <option value="4">{productLanguage.braSize}</option>
                            <option value="5">{productLanguage.misc}</option>
                          </select>
                          <p className="input-feedback text-danger mt-3">{this.state.ErrMsg1}</p>
                        </div>
                        {/* <div className="form-group col-md-12">
                          <label>Discount Price</label>
                          <input type="number" className="input-custom-class form-control" name='discountPrice' value={this.state.discountPrice} onChange={this.handleNumberChange} placeholder="$100" />
                          <span style={{ display: 'none' }} className="input-feedback text-danger"></span>
                        </div> */}
                      </div>
                    </div>
                    <div className="col-lg-6">
                      <div className="row">
                        <div className="col-md-12">
                          <div className="product-in-title d-flex align-items-center">
                            <span>{productLanguage.SelectVariantInfo}</span>
                            <span id="variationSizeListError" style={{ display: "none" }} className="ms-2 input-feedback text-danger fs-6 fw-normal">
                              Required
                            </span>
                          </div>
                        </div>

                        <div className="col-md-12 mt-3">
                          <div className="custom-table-product">
                            <div className="table-responsive dataTables_wrapper no-footer">
                              <DragDropContext onDragEnd={this.onDragEndTable}>
                                <table className="fixed-height-set">
                                  <thead>
                                    <tr>
                                      <th>{productLanguage.size}</th>
                                      <th>SKU</th>
                                      <th>{productLanguage.quantity}</th>
                                      <th>{productLanguage.action}</th>
                                    </tr>
                                  </thead>
                                  {this.state.variationSizeList.length > 0 && this.state.variationSizeList && (
                                    <Droppable droppableId="droppable" direction="vertical">
                                      {(provided) => (
                                        <tbody {...provided.droppableProps} ref={provided.innerRef}>
                                          {this.state.variationSizeList.map((item, index) => (
                                            <Draggable key={item.sizeListId ? item.sizeListId : item.id} draggableId={item.sizeListId ? item.sizeListId : item.id} index={index}>
                                              {(provided) => (
                                                <tr ref={provided.innerRef} {...provided.draggableProps} {...provided.dragHandleProps}>
                                                  <td>{this.context.language === 'english' ? item.size_en : item.size_ar}</td>
                                                  <td>{item.sku}</td>
                                                  <td>{item.quantity}</td>

                                                  <td>
                                                    <Dropdown className="cust-drop">
                                                      <Dropdown.Toggle className="bg-transparent " id="dropdown-basic" align="end">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width={16} height={16} fill="currentColor" className="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                                          <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                                        </svg>
                                                      </Dropdown.Toggle>
                                                      <Dropdown.Menu>
                                                        <Dropdown.Item href="#" className="bi bi-pencil-square me-1" onClick={() => this.handleEditRow(item)}>
                                                          <span>Edit</span>
                                                        </Dropdown.Item>
                                                        <Dropdown.Item href="#" onClick={() => this.delete_record(item.sizeListId ? item.sizeListId : item.id)}>
                                                          <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} fill="currentColor" className="bi bi-trash" viewBox="0 0 16 16">
                                                            <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
                                                            <path fillRule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" />
                                                          </svg>
                                                          <span>Delete</span>
                                                        </Dropdown.Item>
                                                      </Dropdown.Menu>
                                                    </Dropdown>
                                                  </td>
                                                  {/* <td>
                                                    <button className="text-decoration-underline btn text-dark" onClick={() => this.delete_record(item.variation_id)}>
                                                      <span>{ButtonLanguage.clear}</span>
                                                    </button>
                                                  </td> */}
                                                </tr>
                                              )}
                                            </Draggable>
                                          ))}
                                        </tbody>
                                      )}
                                    </Droppable>
                                  )}
                                  {this.state.selectSize <= 0 ? (
                                    <div className="clear_btn cursor-pointer" onClick={() => this.setState({ ErrMsg: "Please select Size Group", ErrMsg1: "Required" })}>
                                      +{productLanguage.Add}
                                    </div>
                                  ) : (
                                    <div className="clear_btn cursor-pointer " onClick={this.addpro}>
                                      +{productLanguage.Add}
                                    </div>
                                  )}
                                  <p className="input-feedback text-danger mt-3">{this.state.ErrMsg}</p>
                                </table>
                              </DragDropContext>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-12 text-center">
                    <div className="common-red-btn">
                      <button onClick={this.handleSubmit} className="btn red-btn me-2">
                        {productLanguage.submit}{" "}
                      </button>
                      <button onClick={this.hideVariation} className="btn black-btn">
                        {productLanguage.cancel}{" "}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          <Modal
            dialogClassName="modal-dialog-centered"
            className="edit-user-modal cust-modal"
            size="lg"
            ref={(el) => {
              this.dialog = el;
            }}
            show={this.state.addproduct_show}
            onHide={this.edit_Close}
          >
            <Modal.Header>
              <Modal.Title>
                <h1 className="modal-title">{productLanguage.SelectVariantInfo}</h1>
              </Modal.Title>
              <button type="button" onClick={this.edit_Close} className="close btn-close"></button>
            </Modal.Header>
            <Modal.Body>
              <div className="row">
                <div className="col-md-4 form-group">
                  <label>{productLanguage.size}</label>
                  {/* <select name="sizeOptions" id="" onChange={this.handleTextChange} className="form-select">
                    <option>{productLanguage.SelectSize}</option>
                    {this.state.SizeGroupSizes &&
                      this.state.SizeGroupSizes.map((item, i) => {
                        return <option key={i} id={item.id}>{item.english} | {item.arabic}</option>;
                      })}
                  </select> */}
                  <div className="position-relative">
                    <input type="text" name="sizeOptions" className="form-control form-select" autoComplete="off" id="sizeInput" value={this.context.language === 'english' ? this.state.search_val_en : this.state.search_val_ar} onChange={this.handleTextChange} onBlur={this.handleSearchBlur} onFocus={this.handleSearchFocus} placeholder={productLanguage.SearchSelectsize} />
                    <div className="opt-product-list start-0 end-0 opt-product-list-cust" id="pro-list">
                      <ul>
                        {
                          this.state.SizeGroupSizes &&
                          this.state.SizeGroupSizes?.filter((search) => this.context.language === 'english' ? (search.english.toLowerCase().includes(this.state.search_val_en)) : (search.english.toLowerCase().includes(this.state.search_val_ar)))?.length === 0 && (
                            <li>There is no sizes.</li>
                          )
                        }
                        {
                          this.state.SizeGroupSizes &&
                          this.state.SizeGroupSizes?.filter((search) => this.context.language === 'english' ? (search.english.toLowerCase().includes(this.state.search_val_en)) : (search.english.toLowerCase().includes(this.state.search_val_ar))).map((item, i) => {
                            return <li key={i} id={item.id} onClick={() => this.handleClickSize(item.english, item.arabic, item.id)}>{item.english} | {item.arabic}</li>;
                          })
                        }
                      </ul>
                    </div>
                  </div>
                  <span className="red-txt d-none" id="addErrorSize">This size already exist.</span>
                </div>
                <div className="col-md-4 form-group">
                  <label>SKU</label>
                  <input type="text" className="form-control input-custom-class" value={this.state.AddVariationSku} readOnly />
                </div>
                <div className="col-md-4 form-group">
                  <label>{productLanguage.quantity}</label>
                  <input type="number" name="sizeQuantity" value={this.state.sizeQuantity} onChange={this.handleQuantityChange} className="form-control input-custom-class m-auto" placeholder="1" />
                </div>

                <div className="col-md-12 text-center">
                  <button onClick={this.handleModalSubmit} className="red-btn">
                    {productLanguage.submit}
                  </button>
                </div>
              </div>
            </Modal.Body>
          </Modal>

          <Modal
            dialogClassName="modal-dialog-centered"
            className="edit-user-modal cust-modal"
            size="lg"
            ref={(el) => {
              this.dialog = el;
            }}
            show={this.state.editVariationAddproduct_show}
            onHide={this.editVariationAddProductPopupClose}
          >
            <Modal.Header>
              <Modal.Title>
                <h1 className="modal-title">{productLanguage.SelectVariantInfo}</h1>
              </Modal.Title>
              <button type="button" onClick={this.editVariationAddProductPopupClose} className="close btn-close"></button>
            </Modal.Header>
            <Modal.Body>
              <div className="row">
                <div className="col-md-4 form-group">
                  <label>{productLanguage.size}</label>
                  {/* <select name="editVariationAddSizeOptions" id="" onChange={this.handleTextChange} className="form-select">
                    <option>{productLanguage.SelectSize}</option>
                    {this.state.SizeGroupSizes &&
                      this.state.SizeGroupSizes.map((item, i) => {
                        return (
                          <>
                          {this.state.editVariationAddSize_en === item.english ? (
                            <option key={i} selected value={item.english + " | " + item.arabic} id={item.id}>
                            {item.english} | {item.arabic}
                              </option>
                              ) : (
                              <option key={i} value={item.english + " | " + item.arabic} id={item.id}>
                              {item.english} | {item.arabic}
                              </option>
                              )}
                          </>
                          );
                        })}
                      </select> */}
                  <div className="position-relative">
                    <input type="text" name="editVariationAddSizeOptions" className="form-control form-select" autoComplete="off" id="editSizeInput" value={this.context.language === 'english' ? this.state.search_val_en : this.state.search_val_ar} onChange={this.handleTextChange} onBlur={this.handleSearchBlur} onFocus={this.handleSearchFocus} placeholder={productLanguage.SearchSelectsize} />
                    <div className="opt-product-list start-0 end-0 opt-product-list-cust" id="pro-list">
                      <ul>
                        {
                          this.state.SizeGroupSizes &&
                          this.state.SizeGroupSizes?.filter((search) => this.context.language === 'english' ? (search.english.toLowerCase().includes(this.state.search_val_en)) : (search.english.toLowerCase().includes(this.state.search_val_ar)))?.length === 0 && (
                            <li>There is no sizes.</li>
                          )
                        }
                        {
                          this.state.SizeGroupSizes &&
                          this.state.SizeGroupSizes?.filter((search) => this.context.language === 'english' ? (search.english.toLowerCase().includes(this.state.search_val_en)) : (search.english.toLowerCase().includes(this.state.search_val_ar)))
                            .map((item, i) => {
                              return (
                                <>
                                  <li key={i} id={item.id} onClick={() => this.handleClickSize(item.english, item.arabic, item.id)}>
                                    {item.english} | {item.arabic}
                                  </li>
                                </>
                              )
                            })
                        }
                      </ul>
                    </div>
                  </div>
                  <span className="red-txt d-none" id="errorSize">This size already exist.</span>
                </div>
                <div className="col-md-4 form-group">
                  <label>SKU</label>
                  <input type="text" className="form-control input-custom-class" value={this.state.EditAddVariationSku} readOnly />
                </div>
                <div className="col-md-4 form-group">
                  <label>{productLanguage.quantity}</label>

                  <input type="number" name="editVariationAddSizeQuantity" value={this.state.editVariationAddSizeQuantity} onChange={this.handleQuantityChange} className="form-control input-custom-class m-auto" placeholder="1" />
                </div>

                <div className="col-md-12 text-center">
                  <button onClick={this.handleAddNewSizeModalSubmit} className="red-btn">
                    {productLanguage.submit}
                  </button>
                </div>
              </div>
            </Modal.Body>
          </Modal>

          <Modal
            dialogClassName="modal-dialog-centered"
            className="edit-user-modal cust-modal"
            size="lg"
            ref={(el) => {
              this.dialog = el;
            }}
            show={this.state.editVariantShow}
            onHide={this.editVariantClose}
          >
            <Modal.Header>
              <Modal.Title>
                <h1 className="modal-title">{productLanguage.SelectVariantInfo}</h1>
              </Modal.Title>
              <button type="button" onClick={this.editVariantClose} className="close btn-close"></button>
            </Modal.Header>
            <Modal.Body>
              <div className="row">
                <div className="col-md-4 form-group">
                  <label>{productLanguage.size}</label>
                  <select name="editSizeOptions" disabled id="" value={this.state.editSize_en + " | " + this.state.editSize_ar} onChange={this.handleTextChange} className="form-select">
                    <option>{productLanguage.SelectSize}</option>

                    {this.state.SizeGroupSizes &&
                      this.state.SizeGroupSizes.map((item, i) => {
                        return (
                          <>
                            {this.state.editVariationAddSize_en === item.english ? (
                              <option key={i} selected value={item.english + " | " + item.arabic}>
                                {item.english} | {item.arabic}
                              </option>
                            ) : (
                              <option key={i} value={item.english + " | " + item.arabic}>
                                {item.english} | {item.arabic}
                              </option>
                            )}
                          </>
                        );
                      })}
                  </select>
                </div>
                <div className="col-md-4 form-group">
                  <label>SKU</label>
                  <input type="text" className="form-control input-custom-class" value={this.state.EditVariationSku} readOnly />
                </div>
                <div className="col-md-4 form-group">
                  <label>{productLanguage.quantity}</label>
                  <input type="number" name="editSizeQuantity" value={this.state.editSizeQuantity} onChange={this.handleQuantityChange} className="form-control input-custom-class m-auto" placeholder="1" />
                </div>
                <div className="col-md-12 text-center">
                  <button onClick={this.handleEditModalSubmit} className="red-btn">
                    {productLanguage.submit}
                  </button>
                </div>
              </div>
            </Modal.Body>
          </Modal>

          <Modal
            dialogClassName="modal-dialog-centered"
            className="edit-user-modal cust-modal"
            size="lg"
            ref={(el) => {
              this.dialog = el;
            }}
            show={this.state.editVariationSizeVariantShow}
            onHide={this.editvariationEditsizePopupClose}
          >
            <Modal.Header>
              <Modal.Title>
                <h1 className="modal-title">{productLanguage.SelectVariantInfo}</h1>
              </Modal.Title>
              <button type="button" onClick={this.editvariationEditsizePopupClose} className="close btn-close"></button>
            </Modal.Header>
            <Modal.Body>
              <div className="row">
                <div className="col-md-4 form-group">
                  <label>{productLanguage.size}</label>
                  <select name="editVariationEditSizeOptions" id="" disabled value={this.state.editVariationEditSize_en + " | " + this.state.editVariationEditSize_ar} onChange={this.handleTextChange} className="form-select">
                    <option>{productLanguage.SelectSize}</option>

                    {this.state.SizeGroupSizes &&
                      this.state.SizeGroupSizes.map((item, i) => {
                        return (
                          <>
                            {this.state.editVariationAddSize_en === item.english ? (
                              <option key={i} selected value={item.english + " | " + item.arabic}>
                                {item.english} | {item.arabic}
                              </option>
                            ) : (
                              <option key={i} value={item.english + " | " + item.arabic}>
                                {item.english} | {item.arabic}
                              </option>
                            )}
                          </>
                        );
                      })}
                  </select>
                </div>
                <div className="col-md-4 form-group">
                  <label>SKU</label>
                  <input type="text" className="form-control input-custom-class" value={this.state.editVariationEditSizeSku} readOnly />
                </div>
                <div className="col-md-4 form-group">
                  <label>{productLanguage.quantity}</label>
                  <input type="number" name="editVariationEditSizeQuantity" value={this.state.editVariationEditSizeQuantity} onChange={this.handleQuantityChange} className="form-control input-custom-class m-auto" placeholder="1" />
                </div>
                <div className="col-md-12 text-center">
                  <button onClick={this.handleEditVariationEditModalSubmit} className="red-btn">
                    {productLanguage.submit}
                  </button>
                </div>
              </div>
            </Modal.Body>
          </Modal>

          <Modal
            dialogClassName="modal-dialog-centered"
            className="edit-user-modal cust-modal bg-modal"
            size="xl"
            ref={(el) => {
              this.dialog = el;
            }}
            show={this.state.edit_var}
            onHide={this.edit_var_Close}
          >
            <Modal.Header>
              <Modal.Title>
                <h1 className="modal-title">{productLanguage.EditVariant}</h1>
              </Modal.Title>
              <button type="button" onClick={this.edit_var_Close} className="close btn-close"></button>
            </Modal.Header>
            <Modal.Body>
              <div className="row">
                <div className="col-md-12">
                  <div className="white-box">
                    <div className="row">
                      <div className="col-lg-6 mb-lg-0 mb-3">
                        <div className="row ">
                          <div className="col-md-12">
                            <div className="product-in-title d-flex align-items-center pb-3 custom-border-title">
                              <span>{productLanguage.ProductImage}</span>
                            </div>
                          </div>
                          <div className="col-md-12 mt-3">
                            <div className="upload-file-section-new position-relative">
                              <div className="file-selecter text-center position-relative h-auto">
                                <div className="file-area position-relative py-3">
                                  <input type="file" name="productImage" id="SelectProductImage" onChange={this.handleEditImages} accept="image/*" multiple />
                                  <div className="file-dummy">
                                    <div className="file-upload-content mb-3">
                                      <img className="file-dummy-image" src={dragimg} alt="" />
                                    </div>
                                    <span>
                                      {productLanguage.DragDrop}
                                      <bdi className="d-block">or</bdi>
                                    </span>
                                    <button className="btn red-btn mt-3">{productLanguage.BrowseFiles}</button>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div id="imageArrayError" style={{ display: "none" }} className="input-feedback text-danger">
                              Required
                            </div>
                          </div>
                          <div className="col-md-12">
                            <span>{productLanguage.UploadedImageFile}</span>
                            <div className="img-preview">
                              <ul>
                                {this.state.editVariationImages?.length > 0 && (
                                  <DragDropContext onDragEnd={this.onEditDragEnd} >
                                    <Droppable droppableId="droppable" direction="horizontal">
                                      {(provided, snapshot) => (
                                        <div ref={provided.innerRef} style={getListStyle(snapshot.isDraggingOver, this.state.editVariationImages.length)} {...provided.droppableProps}>
                                          {this.state.editVariationImages.map((item, index) => (
                                            <Draggable key={item.id} draggableId={item.id} index={index} onChange={this.imgChange(item.image)}>
                                              {(provided, snapshot) => (
                                                <div ref={provided.innerRef} {...provided.draggableProps} {...provided.dragHandleProps} style={getItemStyle(snapshot.isDragging, provided.draggableProps.style)}>
                                                  <li>
                                                    <div className="img-preview-main position-relative">
                                                      <img src={typeof item.image == 'object' ? URL.createObjectURL(item.image) : item.image} alt="" />
                                                      <div className="remove-img-btn">
                                                        <i
                                                          onClick={() => {
                                                            this.editVariationremoveImage(item.id);
                                                          }}
                                                          className="bi bi-x-circle-fill"
                                                        />
                                                      </div>
                                                    </div>
                                                  </li>
                                                </div>
                                              )}
                                            </Draggable>
                                          ))}
                                          {/* {provided.placeholder} */}
                                        </div>
                                      )}
                                    </Droppable>
                                  </DragDropContext>
                                )}
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-lg-6 mb-lg-0 mb-3">
                        <div className="row">
                          <div className="col-md-12">
                            <div className="product-in-title d-flex align-items-center pb-3 custom-border-title">
                              <span>{productLanguage.VideoOptional}</span>
                            </div>
                          </div>
                          <div className="col-md-12 mt-3">
                            <div className="upload-file-section-new position-relative">
                              <div className="file-selecter text-center position-relative h-auto">
                                <div className="file-area position-relative py-3">
                                  <input type="file" name="licence_image_temp" onChange={this.handleVideoFile} accept="video/*" />
                                  <div className="file-dummy">
                                    <div className="file-upload-content mb-3">
                                      <img className="file-dummy-image" src={dragimg} alt="" />
                                    </div>
                                    <span>
                                      {productLanguage.DragDrop}
                                      <bdi className="d-block">or</bdi>
                                    </span>
                                    <button className="btn red-btn mt-3">{productLanguage.UploadVideo}</button>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <span>{productLanguage.UploadedVideoFile} (mp4, flv)</span>
                          </div>
                          <div className="col-md-12 mt-3">
                            <span>{productLanguage.UploadedVideoFile}</span>
                            <div className="video-preview">
                              <ul>
                                {this.state.isVideoUploaded ? this.state.videoFiles && (
                                  <li className="gray-bg-video grey-close-btn   my-2">
                                    <div className="video-thumb position-relative p-2">
                                      {/* <video width="100px" height="100px" poster={Poster}> */}
                                      <video width="100px" height="100px">
                                        <source src={this.state.videoFiles} type="video/mp4" />
                                      </video>
                                      {/* <img src="" alt="" /> */}
                                      <div className="video-icn-pro">
                                        <img src={videoicn} alt="" />
                                      </div>
                                      <div className="remove-btn">
                                        <i onClick={this.removeVideo} className="bi bi-x-circle-fill"></i>
                                      </div>
                                    </div>
                                    {/* <div className="vide-prev-txt ms-2">
                                      <p className="mb-0">{this.state.videoFiles[0].name}</p>
                                      <bdi>{this.state.videoFiles.size}</bdi>
                                    </div> */}
                                  </li>
                                ) : this.state.editVariationVideo && (
                                  <li className="gray-bg-video grey-close-btn   my-2">
                                    <div className="video-thumb position-relative p-2">
                                      {/* <video width="100px" height="100px" poster={Poster}> */}
                                      <video width="100px" height="100px" >
                                        <source src={this.state.editVariationVideo} type="video/mp4" />
                                      </video>
                                      {/* <img src="" alt="" /> */}
                                      <div className="video-icn-pro">
                                        <img src={videoicn} alt="" />
                                      </div>
                                      <div className="remove-btn">
                                        <i onClick={this.removeVideo} className="bi bi-x-circle-fill"></i>
                                      </div>
                                    </div>
                                    {/* <div className="vide-prev-txt ms-2">
                                      <p className="mb-0">{this.state.videoFiles[0].name}</p>
                                      <bdi>{this.state.videoFiles.size}</bdi>
                                    </div> */}
                                  </li>
                                )}
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-lg-6 mb-lg-0 mb-3">
                        <div className="row">
                          {/* <div className="form-group col-md-6">
                            <label>Variation name in English</label>
                            <input type="text" className="input-custom-class form-control" placeholder="Variaton name" name="editVariationNameEn" defaultValue={this.state.editVariationNameEn} onChange={this.handleTextChange} />
                            <span style={{ display: "none" }} className="input-feedback text-danger">
                              Required
                            </span>
                          </div>
                          <div className="form-group col-md-6">
                            <label>Variation name in Arabic</label>
                            <input type="text" dir="rtl" className="input-custom-class form-control" placeholder="اسم الاختلاف" name="editVariationNameAr" defaultValue={this.state.editVariationNameAr} onChange={this.handleTextChange} />
                            <span style={{ display: "none" }} className="input-feedback text-danger">
                              Required
                            </span>
                          </div> */}
                          <div className="form-group col-md-12">
                            <label>{productLanguage.selectColor}</label>
                            <select className="form-select input-custom-class" name="editVariationColor" onChange={this.handleColorChange}>
                              <option defaultValue>{productLanguage.selectColor}</option>
                              {/* <option selected value="0">
                                Multicolor | متعدد اللألوان
                              </option> */}
                              {this.state.color.length > 0 &&
                                this.state.color?.map((item, i) => {
                                  return item.id == this.state.editVariationColor ? (
                                    <option key={i} selected value={item.id}>
                                      {item.english} | {item.arabic}
                                    </option>
                                  ) : (
                                    <option key={i} value={item.id}>
                                      {item.english} | {item.arabic}
                                    </option>
                                  );
                                })}
                            </select>
                            <span id="selectColor" style={{ display: "none" }} className="input-feedback text-danger">
                              Required
                            </span>
                          </div>
                          <div className="form-group col-md-12">
                            <label>{productLanguage.PromotionEnglish}</label>
                            <select className="form-select input-custom-class" name="editVariationPromotion" onChange={this.handlePromotionChange}>
                              <option defaultValue>{productLanguage.selectPromotion}</option>
                              {this.state.promotion &&
                                this.state.promotion.length > 0 &&
                                this.state.promotion.map((item, i) => {
                                  return item.id == this.state.editVariationPromotion ? (
                                    <option key={i} selected value={item.id}>
                                      {item.english} | {item.arabic}
                                    </option>
                                  ) : (
                                    <option key={i} value={item.id}>
                                      {item.english} | {item.arabic}
                                    </option>
                                  );
                                })}
                            </select>
                          </div>
                          <div className="form-group col-md-12">
                            <label>{productLanguage.Price}</label>
                            <input type="number" className="input-custom-class form-control" name="editVariationPrice" value={this.state.editVariationPrice} onChange={this.handleEditPriceChange} placeholder="$200" />
                            <span id="priceVariant" style={{ display: "none" }} className="input-feedback text-danger">
                              Required
                            </span>
                          </div>
                          <div className="form-group col-md-12">
                            <label>{productLanguage.Discount}</label>
                            <input type="number" className="input-custom-class form-control" name="editVariationDiscount" value={this.state.editVariationDiscount} onChange={this.handleEditDiscountChange} placeholder="10%" />
                            <span id="discountVariant" style={{ display: "none" }} className="input-feedback text-danger">
                              Required
                            </span>
                          </div>
                          <div className="form-group col-md-12">
                            <label>{productLanguage.realPrice}</label>
                            <input type="number" className="input-custom-class form-control" name="editVariationRealPrice" value={this.state.editVariationRealPrice} onChange={this.handleEditRealPriceChange} placeholder="$100" />
                            <span id="realpriceVariant" style={{ display: "none" }} className="input-feedback text-danger">
                              Required
                            </span>
                          </div>
                          <div className="form-group col-md-12">
                            <label>{productLanguage.sizeGroup}</label>
                            <select className="form-select input-custom-class" value={this.state.selectSize} name="selectsize" onChange={this.handleSizeChange}>
                              <option value="0" selected>
                                {productLanguage.selectSize}
                              </option>
                              <option value="1">{productLanguage.international}</option>
                              <option value="2">{productLanguage.numerical}</option>
                              <option value="3">{productLanguage.ageWise}</option>
                              <option value="4">{productLanguage.braSize}</option>
                              <option value="5">{productLanguage.misc}</option>
                            </select>
                            <p className="input-feedback text-danger mt-3">{this.state.ErrMsg1}</p>
                          </div>
                        </div>
                      </div>
                      <div className="col-lg-6">
                        <div className="row">
                          <div className="col-md-12">
                            <div className="product-in-title d-flex align-items-center">
                              <span></span>
                              <span id="variationSizeListError" style={{ display: "none" }} className="ms-2 input-feedback text-danger fs-6 fw-normal">
                                Required
                              </span>
                            </div>
                          </div>
                          <div className="col-md-12 mt-3">
                            <div className="custom-table-product">
                              <div className="table-responsive dataTables_wrapper no-footer">
                                <DragDropContext onDragEnd={this.onDragEndEditTable}>
                                  <table className="fixed-height-set">
                                    <thead>
                                      <tr>
                                        <th>{productLanguage.size}</th>
                                        <th>SKU</th>
                                        <th>{productLanguage.quantity}</th>
                                        <th>{productLanguage.sales}</th>
                                        <th>{productLanguage.action}</th>
                                      </tr>
                                    </thead>
                                    {this.state.editVariationSizeList?.length > 0 && (
                                      <Droppable droppableId="droppable" direction="vertical">
                                        {(provided) => (
                                          <tbody {...provided.droppableProps} ref={provided.innerRef}>
                                            {this.state.editVariationSizeList.length > 0 &&
                                              this.state.editVariationSizeList.map((item, index) => {
                                                console.log(item, "////");
                                                return (
                                                  <Draggable key={item.sizeListId ? item.sizeListId : item.id} draggableId={item.sizeListId ? item.sizeListId : item.id.toString()} index={index}>
                                                    {(provided) => (
                                                      <tr ref={provided.innerRef} {...provided.draggableProps} {...provided.dragHandleProps}>
                                                        <td>{this.context.language === 'english' ? item.size_en : item.size_ar}</td>
                                                        <td>{item.sku.toUpperCase()}</td>
                                                        <td>{item.quantity}</td>
                                                        <td>{item.sales === null ? 0 : item.sales}</td>
                                                        <td>
                                                          <Dropdown className="cust-drop">
                                                            <Dropdown.Toggle className="bg-transparent " id="dropdown-basic" align="end">
                                                              <svg xmlns="http://www.w3.org/2000/svg" width={16} height={16} fill="currentColor" className="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                                                <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                                              </svg>
                                                            </Dropdown.Toggle>
                                                            <Dropdown.Menu>
                                                              <Dropdown.Item href="#" className="bi bi-pencil-square me-1" onClick={() => this.editVariationEditRow(item)}>
                                                                <span>Edit</span>
                                                              </Dropdown.Item>
                                                              <Dropdown.Item href="#" onClick={() => this.editVariationDelete_record(item.id)}>
                                                                <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} fill="currentColor" className="bi bi-trash" viewBox="0 0 16 16">
                                                                  <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
                                                                  <path fillRule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" />
                                                                </svg>
                                                                <span>Delete</span>
                                                              </Dropdown.Item>
                                                            </Dropdown.Menu>
                                                          </Dropdown>
                                                        </td>
                                                        {/* <td>
                                                          <button className="text-decoration-underline btn text-dark" onClick={() => this.editVariationDelete_record(item.id)}>
                                                            <span>{ButtonLanguage.clear}</span>
                                                          </button>
                                                        </td> */}
                                                      </tr>
                                                    )}
                                                  </Draggable>
                                                );
                                              })}
                                            {provided.placeholder}
                                          </tbody>
                                        )}
                                      </Droppable>
                                    )}
                                    {this.state.selectSize <= 0 ? (
                                      <div className="clear_btn cursor-pointer" onClick={() => this.setState({ ErrMsg: "Please select Size Group", ErrMsg1: "Required" })}>
                                        +{productLanguage.Add}
                                      </div>
                                    ) : (
                                      <div className="clear_btn cursor-pointer " onClick={this.editVariationAddPro}>
                                        +{productLanguage.Add}
                                      </div>
                                    )}
                                    <p className="input-feedback text-danger mt-3">{this.state.ErrMsg}</p>
                                  </table>
                                </DragDropContext>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-12 text-center">
                      <div className="common-red-btn">
                        <button onClick={this.updateVariation} className="btn red-btn">
                          {productLanguage.submit}{" "}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Modal.Body>
          </Modal>
        </div>
      </React.Fragment>
    );
  }
}

export default EditVariations;
