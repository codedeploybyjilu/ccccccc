import React, { Component } from 'react';
import Adminlayout from '../../Components/AdminLayout/Adminlayout';
import MUITable from "../../Components/MUITable";
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";
import { Dropdown } from 'react-bootstrap';
import SearchIcon from "../../images/search-icon.svg";

class AudianceSegmentDetails extends Component {

    render() {
        const options = {
            responsive: "standard",
            searchOpen: false,
            search: false,
            searchAlwaysOpen: false,
            print: false,
            serverSide: true,
            pagination: true,
            rowsPerPageOptions: [50, 100, 300, 500],
        };

        const columns = [
            {
                name: "device_id",
                label: "Device Id",
            },
            {
                name: "email_address",
                label: "Email Address",
            },
            {
                name: "first_seen",
                label: "First Seen",
            },
            {
                name: "last_seen",
                label: "Last Seen",
            },
        ];

        const data = [
            ["1", "bugayelafou-1470@yopmail.com", "bugay", "26-09-2023 6:19 PM"],
            ["1", "bugayelafou-1470@yopmail.com", "bugay", "26-09-2023 6:19 PM"],
            ["1", "bugayelafou-1470@yopmail.com", "bugay", "26-09-2023 6:19 PM"],
            ["1", "bugayelafou-1470@yopmail.com", "bugay", "26-09-2023 6:19 PM"],
            ["1", "bugayelafou-1470@yopmail.com", "bugay", "26-09-2023 6:19 PM"],
        ];

        const theme = createMuiTheme({
            palette: {
                primary: {
                    light: "#757ce8",
                    main: "#a81a1c",
                    dark: "#002884",
                    contrastText: "#fff",
                },
                secondary: {
                    light: "#ff7961",
                    main: "#f44336",
                    dark: "#ba000d",
                    contrastText: "#000",
                },
            },
        });

        return (
            <Adminlayout>
                <div className="container-fluid">
                    <div className="row common-space">
                        <div className="col-12 text-sm-start text-center rtl-txt-start">
                            <div className="common-header-txt">
                                <h3>
                                    <a href='/audience-segment'>
                                        <svg className='me-2' width="16" height="12" viewBox="0 0 16 12" fill="none"><path d="M3.83 5L7.41 1.41L6 0L0 6L6 12L7.41 10.59L3.83 7H16V5H3.83Z" fill="#2d2d3b"></path></svg>
                                    </a>
                                    Audience Segment Detail
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div className='row common-space'>
                        <div className='col-12'>
                            <div className='white-box'>
                                <div className="row me-0">
                                    <div className="col-lg-3 col-md-6 mb-lg-0 mb-2 pb-lg-0 pb-1 pe-0">
                                        <div className="usrs-dtls-info"><span className="d-block">AUDIENCE NAME</span><bdi className="d-block">adad</bdi></div>
                                    </div>
                                    <div className="col-lg-3 col-md-6 mb-lg-0 mb-2 pb-lg-0 pb-1 pe-0">
                                        <div className="usrs-dtls-info"><span className="d-block">DESCRIPTION</span><bdi className="d-block">ad</bdi></div>
                                    </div>
                                    <div className="col-lg-3 col-md-6 mb-lg-0 mb-2 pb-lg-0 pb-1 pe-0">
                                        <div className="usrs-dtls-info"><span className="d-block">DATE</span><bdi className="d-block">Aug 3, 2023 5:01 PM</bdi></div>
                                    </div>
                                    <div className="col-lg-3 col-md-6 mb-lg-0 mb-2 pb-lg-0 pb-1 pe-0">
                                        <div className="usrs-dtls-info"><span className="d-block">AUDIENCE SIZE</span><bdi className="d-block">0</bdi></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='row common-space'>
                        <div className='col-12'>
                            <div className='fw-usrs-text'>User</div>
                        </div>
                        <div className='col-12'>
                            <div className='white-box'>
                                <div className="custom-table">
                                    <div className=" dataTables_wrapper no-footer">
                                        <MuiThemeProvider theme={theme}>
                                            <div className="right-menu table-over-fix-class ms-auto position-relative">
                                                <MUITable
                                                    columns={columns}
                                                    data={data}
                                                    options={options}
                                                />
                                                <div className="fix-search d-flex align-items-center">
                                                    <div className="position-relative search-sm-screen" id="search-menu">
                                                        <input type="search" name="search" className="form-control top-search ps-5 input-custom-class mb-0" placeholder="" />
                                                        <span className="search-icn position-absolute ms-3">
                                                            <img src={SearchIcon} alt="" />
                                                        </span>
                                                    </div>
                                                    {/* <button className="border-0 bg-transparent dark-red-txt w-100">Clear Filter x</button> */}
                                                </div>
                                            </div>
                                        </MuiThemeProvider>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </Adminlayout>
        );
    }
}

export default AudianceSegmentDetails;
