import React, { Component } from 'react';
import Adminlayout from '../../Components/AdminLayout/Adminlayout';
import { AdminArabic, AdminEnglish, API_Path, buttonArabic, buttonEnglish } from '../../const';
import LanguageContext from '../../contexts/languageContext'
import { Formik } from "formik";
import * as EmailValidator from "email-validator";
import * as Yup from "yup";
import toastr from 'toastr';
import { PostApi } from '../../helper/APIService';
import { withRouter } from 'react-router-dom';

const phoneRegExp = /^(\+?\d{0,4})?\s?-?\s?(\(?\d{3}\)?)\s?-?\s?(\(?\d{3}\)?)\s?-?\s?(\(?\d{4}\)?)?$/;
class AddAdmin extends Component {
    static contextType = LanguageContext;

    state = {
        profilePicture: ''
    }



    buildFormData = (formData, data, parentKey) => {
        if (data && typeof data === 'object' && !(data instanceof Date) && !(data instanceof File)) {
            Object.keys(data).forEach(key => {
                this.buildFormData(formData, data[key], parentKey ? `${parentKey}[${key}]` : key);
            });
        } else {
            const value = data == null ? '' : data;

            formData.append(parentKey, value);
        }
    }

    jsonToFormData = (data) => {
        const formData = new FormData();

        this.buildFormData(formData, data);

        return formData;
    }

    handleChange = (e) => {
        this.setState({ [e.target.name]: e.target.value })
    }

    handleprofilePicture = (e) => {
        this.setState({ profilePicture: e.target.files[0] })
    }

    handleReset = () => {
        console.log('reset');
        document.getElementById('addAdminFirstName').value = ''
        document.getElementById('addAdminLastName').value = ''
        document.getElementById('addAdminEmail').value = ''
        document.getElementById('addAdminNumber').value = ''
        this.setState({ profilePicture: '' })
    }

    render() {
        let Language = this.context.language === 'english' ? AdminEnglish : AdminArabic
        let Button = this.context.language === 'english' ? buttonEnglish : buttonArabic
        return (
            <Adminlayout>
                <div className="container-fluid">
                    <div className="row common-space">
                        <div className="col-sm-6 text-sm-start text-center">
                            <div className="common-header-txt">
                                <h3>{Language.addAdmin}</h3>
                            </div>
                        </div>
                    </div>
                    <div className="row common-space">
                        <div className="col-md-12">
                            <div className="white-box">
                                <Formik
                                    initialValues={{ firstName: '', lastName: '', userName: '', email: '', number: '' }}
                                    onSubmit={(values, { setSubmitting }) => {
                                        console.log("Logging in", values, this.state.profilePicture);

                                        let data = {
                                            username: values.userName,
                                            first_name: values.firstName,
                                            last_name: values.lastName,
                                            email: values.email,
                                            password: "password@123",
                                            phone: values.number,
                                            image: this.state.profilePicture
                                        }

                                        var formData = this.jsonToFormData(data)

                                        let path = API_Path.addAdmin

                                        console.log('path :: ', path)

                                        const AddAdminPromise = new Promise((resolve, reject) => {
                                            resolve(PostApi(path, formData));
                                        });

                                        AddAdminPromise.then((res) => {
                                            if (res) {
                                                console.log('res is :: ', res);
                                                if (res.data.success) {
                                                    toastr.success(res.data.message)
                                                    this.props.history.push('/admin')
                                                    // window.location.href = '/admin'

                                                } else {
                                                    toastr.error(res.data.message)
                                                }

                                            }
                                        });
                                        setSubmitting(false);
                                    }}


                                    validationSchema={

                                        Yup.object().shape({
                                            firstName: Yup.string()
                                                .required("First name is required"),
                                            lastName: Yup.string()
                                                .required('Last name is required'),
                                            userName: Yup.string()
                                                .required('Username is required'),
                                            email: Yup.string().email('Email is not valid').max(255).required('Email is required'),
                                            number: Yup.string()
                                                .required("Phone number is required")
                                                .matches(phoneRegExp, 'Phone number is not valid'),
                                        })
                                    }
                                >
                                    {props => {
                                        const {
                                            values,
                                            touched,
                                            errors,
                                            isSubmitting,
                                            handleChange,
                                            handleBlur,
                                            handleSubmit
                                        } = props;
                                        return (


                                            <form className="row" onSubmit={handleSubmit} >

                                                <div className="form-group col-md-6">
                                                    <label>{Language.firstName}</label>
                                                    <input id='addAdminFirstName' type="text" name='firstName' value={values.firstName} onChange={handleChange}
                                                        onBlur={handleBlur} className="form-control input-custom-class" placeholder="John" />
                                                    {errors.firstName && touched.firstName && (
                                                        <div className="input-feedback text-danger">{errors.firstName}</div>
                                                    )}
                                                </div>
                                                <div className="form-group col-md-6">
                                                    <label>{Language.lastName}</label>
                                                    <input id='addAdminLastName' type="text" name='lastName' value={values.lastName} onChange={handleChange}
                                                        onBlur={handleBlur} className="form-control input-custom-class" placeholder="Doe" />
                                                    {errors.lastName && touched.lastName && (
                                                        <div className="input-feedback text-danger">{errors.lastName}</div>
                                                    )}
                                                </div>
                                                <div className="form-group col-md-6">
                                                    <label>{Language.userName}</label>
                                                    <input id='addAdminUserName' type="text" name='userName' value={values.userName} onChange={handleChange}
                                                        onBlur={handleBlur} className="form-control input-custom-class" placeholder="User Name" />
                                                    {errors.userName && touched.userName && (
                                                        <div className="input-feedback text-danger">{errors.userName}</div>
                                                    )}
                                                </div>
                                                <div className="form-group col-md-6">
                                                    <label>{Language.emailAddress}</label>
                                                    <input id='addAdminEmail' type="email" name='email' value={values.email} onChange={handleChange}
                                                        onBlur={handleBlur} className="form-control input-custom-class" placeholder="Johndeo85@gmail.com" />
                                                    {errors.email && touched.email && (
                                                        <div className="input-feedback text-danger">{errors.email}</div>
                                                    )}
                                                </div>
                                                <div className="form-group col-md-6">
                                                    <label>{Language.mobileNumber}</label>
                                                    <input id='addAdminNumber' type="tel" name='number' value={values.number} onChange={handleChange}
                                                        onBlur={handleBlur} className="form-control input-custom-class" placeholder="+1 1234567895" />
                                                    {errors.number && touched.number && (
                                                        <div className="input-feedback text-danger">{errors.number}</div>
                                                    )}
                                                </div>
                                                <div className="form-group col-md-6">
                                                    <label>{Language.profileImage} ({Language.optional})</label>
                                                    <div className="input-group mb-3">
                                                        <input type="file" accept="image/*" onChange={this.handleprofilePicture} className="form-control input-custom-class cust-line-height" />
                                                    </div>
                                                    <div id='admin-profile-upload' style={{ display: 'none' }} className="input-feedback text-danger">Required</div>

                                                </div>
                                                <div className=" col-md-12 mb-3 mt-3 text-center">
                                                    <div className="common-red-btn">
                                                        <button disabled={isSubmitting} type="submit" className="btn red-btn me-2">{Button.submit}</button>
                                                        {/* <div onClick={this.handleReset} className="btn black-btn ">{Button.cancel}</div> */}
                                                    </div>
                                                </div>

                                            </form>

                                        );
                                    }}
                                </Formik >
                            </div>
                        </div>
                    </div>
                </div>
            </Adminlayout>
        );
    }
}

export default withRouter(AddAdmin);