import React, { Component } from "react";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
import DataTable from "../../Components/DataTable";
import { textFilter } from "react-bootstrap-table2-filter";
import { confirmAlert } from "react-confirm-alert";
import { Modal, Dropdown, Tab, Tabs } from "react-bootstrap";
import Moment from "moment";
import toastr from "toastr";
import {
  API_Path,
  buttonArabic,
  buttonEnglish,
  TableFieldArabic,
  TableFieldEnglish,
  titleArabic,
  titleEnglish,
  productEnglish,
  productArabic,
  marketingArabic,
  marketingEnglish,
} from "../../const";
import LanguageContext from "../../contexts/languageContext";
import MUITable from "../../Components/MUITable";
import { PostApi } from "../../helper/APIService";
import { Link, withRouter } from "react-router-dom";
import SearchIcon from "../../images/search-icon.svg";

class Marketing extends Component {
  static contextType = LanguageContext;
  constructor(props) {
    super(props);
    this.state = {
      AllCouponData: [],
      key: "codes",
      buttonurl: "/add-coupon",
      buttonName: "Add Coupon",
      page: 1,
      sizePerPage: 10,
      totalSize: 0,
      defaultSorted: [
        {
          dataField: "id",
          order: "desc",
        },
      ],
      AllSalesData: null,
      searchedCoupon: "",
    };
  }

  componentDidMount() {
    this.getAllCouponData();
  }

  getAllCouponData = (search) => {
    let data = {
      page: this.state.page,
      sizePerPage: this.state.sizePerPage,
      defaultSorted: this.state.defaultSorted,
      searchText: search && search,
    };

    let path = API_Path.getAllCoupon;
    const getAllCouponPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    getAllCouponPromise.then((res) => {
      if (res) {
        if (res.data.success) {
          let t_data = res.data.data;
          let temp_table2 = res.data.coupon_usage;
          let obj2 = t_data.map((item) => ({
            ...temp_table2.find(
              (value) => value.voucher_code == item.id && value
            ),
            ...item,
          }));
          console.log(obj2, "obj2--");
          this.setState({
            AllCouponData: obj2,
            totalSize: res.data.totalRecord,
          });
        }
      }
    });
  };

  searchCoupone = (e) => {
    this.setState({ searchedCoupon: e.target.value });
    this.getAllCouponData(e.target.value);
  };

  deleteCoupon = (id) => {
    let data = {
      id: id,
    };
    let path = API_Path.deleteCoupon;
    const deleteCouponPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    deleteCouponPromise.then((res) => {
      if (res) {
        if (res.data.success) {
          toastr.success(res.data.message);
          this.getAllCouponData();
        } else {
          toastr.error(res.data.message);
        }
      }
    });
  };

  cloneCoupon = (id) => {
    let data = {
      id: id,
    };
    let path = API_Path.cloneCoupon;
    const cloneCouponPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    cloneCouponPromise.then((res) => {
      if (res) {
        if (res.data.success) {
          toastr.success(res.data.message);
          this.getAllCouponData();
        } else {
          toastr.error(res.data.message);
        }
      }
    });
  };

  setKey = (keyName) => {
    this.setState({ key: keyName });
    let marketingLanguage =
      this.context.language === "english" ? marketingEnglish : marketingArabic;
    if (keyName === "codes") {
      this.setState({
        buttonurl: "/add-coupon",
        buttonName: marketingLanguage.AddCoupon,
      });
    } else if (keyName === "prices") {
      this.setState({
        buttonurl: "/add-discount",
        buttonName: marketingLanguage.AddDiscount,
      });
    } else if (keyName === "bundle") {
      this.setState({
        buttonurl: "/add-bundle-discount",
        buttonName: marketingLanguage.AddDiscount,
      });
    } else if (keyName === "automatic") {
      this.setState({
        buttonurl: "/#",
        buttonName: marketingLanguage.AddDiscount,
      });
    } else if (keyName === "special") {
      this.setState({
        buttonurl: "/#",
        buttonName: marketingLanguage.AddDiscount,
      });
    }
  };
  addEvent = () => {
    if (this.state.key == "codes") {
      this.props.history.push("/add-coupon");
    } else if (this.state.key === "prices") {
      this.props.history.push("/add-discount");
    } else if (this.state.key === "bundle") {
      this.props.history.push("/add-bundle-discount");
    } else if (this.state.key === "automatic") {
    } else if (this.state.key === "special") {
    }
  };

  featured = (id) => {
    const data = {
      id: id,
    };
    const featuredDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(API_Path.updateCouponFeatured, data));
    });
    featuredDataPromise.then((res) => {
      if (res.data.success) {
        this.getAllCouponData();
        toastr.success(res.data.message);
      } else {
        toastr.error(res.data.message);
      }
    });
  };
  StatusChange = (e, id, checked) => {
    console.log(e.target.checked, "[===[", checked);
    // if (e.target.checked) {
    //   if (checked == 0) {
    //     document.getElementById('active_status' + id).classList.add('active')
    //     document.getElementById('btnchecklabel1_' + id).classList.remove('unchecked')
    //     document.getElementById('btnchecklabel1_' + id).classList.add('checked')
    //   } else {
    //     document.getElementById('active_status' + id).classList.remove('active')
    //     document.getElementById('btnchecklabel1_' + id).classList.remove('checked')
    //     document.getElementById('btnchecklabel1_' + id).classList.add('unchecked')
    //   }
    // } else {
    //   if (checked == 0) {
    //     document.getElementById('active_status' + id).classList.add('active')
    //     document.getElementById('btnchecklabel1_' + id).classList.remove('unchecked')
    //     document.getElementById('btnchecklabel1_' + id).classList.add('checked')
    //   } else {
    //     document.getElementById('active_status' + id).classList.remove('active')
    //     document.getElementById('btnchecklabel1_' + id).classList.remove('checked')
    //     document.getElementById('btnchecklabel1_' + id).classList.add('unchecked')
    //   }
    // }
    let status = e.target.checked ? 1 : 0;
    let statusData = {
      id: id,
      status: status,
    };
    new Promise((resolve) => {
      resolve(PostApi(API_Path.ChangeStatus, statusData));
    }).then((res) => {
      console.log(res, "res---==-=-");
      if (res) {
        if (res.data.success) {
          if (this.context.language === "english") {
            toastr.success(res.data.message);
          } else {
            toastr.success("تم تحديث القسيمة بنجاح !!!");
          }
          // setTimeout(() => {
          this.getAllCouponData(this.state.searchedCoupon);
          // }, 500)
        }
      }
    });
  };

  render() {
    let Language =
      this.context.language === "english"
        ? TableFieldEnglish
        : TableFieldArabic;
    let titleLanguage =
      this.context.language === "english" ? titleEnglish : titleArabic;
    let ButtonLanguage =
      this.context.language === "english" ? buttonEnglish : buttonArabic;
    let marketingLanguage =
      this.context.language === "english" ? marketingEnglish : marketingArabic;
    let productLanguage =
      this.context.language === "english" ? productEnglish : productArabic;

    const columns = [
      {
        label: "ID",
        name: "id",
        options: {
          filter: true,
          display: false,
        },
      },
      {
        label: marketingLanguage.Code,
        name: "coupon_code",
        options: {
          filter: true,
        },
      },
      {
        label: marketingLanguage.CodeType,
        name: "discount_type",
        options: {
          filter: true,
        },
      },
      {
        label: marketingLanguage.DiscountValue,
        name: "discount_value",
        options: {
          filter: true,
        },
      },
      {
        label: marketingLanguage.MinimumValue,
        name: "min_amount",
        options: {
          filter: false,
        },
      },
      {
        label: marketingLanguage.CreateDate,
        name: "start_date",
        options: {
          filter: true,
          customBodyRender: (value, tableMeta, updateValue) => {
            return Moment(value).format("DD/MM/YYYY");
          },
        },
      },

      {
        label: marketingLanguage.EndDate,
        name: "end_date",
        options: {
          filter: true,
          sort: false,
          customBodyRender: (value, tableMeta, updateValue) => {
            return value
              ? Moment(value).format("DD/MM/YYYY")
              : this.context.language === "english"
              ? "Not Fixed"
              : "غير محددة";
          },
        },
      },
      {
        label: marketingLanguage.Status,
        name: "status",
        options: {
          filter: true,
          sort: false,
          // empty: true,
          customBodyRender: (value, tableMeta, updateValue) => {
            console.log(value, "[[=]");
            let id = tableMeta.rowData[0];
            return (
              // <div className={`position-relative cust-radios-status ${value === 1 ? 'active' : ''}`} id={'active_status' + tableMeta.rowData[0]}>

              //   <input type="checkbox" defaultChecked={value == 0 ? false : true} id={"btncheckstatus1_" + tableMeta.rowData[0]} autoComplete="off" onChange={(e) => this.StatusChange(e, id, value)} />
              //   <label className={`${value == 1 ? 'checked' : 'unchecked'}`} htmlFor={"btncheckstatus1_" + tableMeta.rowData[0]} id={"btnchecklabel1_" + tableMeta.rowData[0]}>
              //   </label>
              // </div>
              <div className="position-relative">
                <label className="switch">
                  <input
                    type="checkbox"
                    checked={value == 1}
                    onChange={(e) => this.StatusChange(e, id)}
                  />
                  <div className="slider round" />
                </label>
              </div>
              // <span
              //   className={
              //     "staus-span-tag-new status-"
              //   }
              // >
              //   {value}
              // </span>
            );
          },
        },
      },
      {
        label: marketingLanguage.Usage,
        name: "usages",
        options: {
          filter: true,
          sort: false,
        },
      },

      {
        label: marketingLanguage.TotalDiscount,
        name: "coupon_discount",
        options: {
          filter: true,
          sort: false,
          customBodyRender: (value, tableMeta) => {
            return value && value.toFixed(2);
          },
        },
      },
      {
        name: "featured",
        label: marketingLanguage.Featured,
        options: {
          sort: false,
          customBodyRender: (value, tableMeta, updateValue) => {
            return (
              <React.Fragment>
                <input
                  type="checkbox"
                  defaultChecked={value == 0 ? false : true}
                  className="btn-check"
                  id={"btncheck1_" + tableMeta.rowData[0]}
                  autoComplete="off"
                  onChange={() => this.featured(tableMeta.rowData[0])}
                />
                <div className="cust-star-table-rating">
                  {value == 1 ? (
                    <label
                      className="bi bi-star-fill"
                      htmlFor={"btncheck1_" + tableMeta.rowData[0]}
                    />
                  ) : (
                    <label
                      className="bi bi-star"
                      htmlFor={"btncheck1_" + tableMeta.rowData[0]}
                    />
                  )}
                </div>
              </React.Fragment>
            );
          },
        },
      },
      {
        label: marketingLanguage.Action,
        name: "id",
        options: {
          filter: false,
          sort: false,
          empty: true,

          customBodyRender: (value, tableMeta, updateValue) => {
            return (
              <React.Fragment>
                <Dropdown className="cust-drop">
                  <Dropdown.Toggle
                    className="bg-transparent "
                    id="dropdown-basic"
                    align="end"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width={16}
                      height={16}
                      fill="currentColor"
                      className="bi bi-three-dots-vertical"
                      viewBox="0 0 16 16"
                    >
                      <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                    </svg>
                  </Dropdown.Toggle>
                  <Dropdown.Menu>
                    <Dropdown.Item as={Link} to={"edit-coupon/" + value}>
                      <svg
                        width={19}
                        height={19}
                        viewBox="0 0 19 19"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
                          fill="#2D2D3B"
                        />
                      </svg>
                      <span>{ButtonLanguage.edit}</span>
                    </Dropdown.Item>

                    <Dropdown.Item
                      as={"button"}
                      onClick={() => this.cloneCoupon(value)}
                    >
                      <svg
                        width={19}
                        height={19}
                        viewBox="0 0 20 18"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M7 0C4.23858 0 2 2.23858 2 5C2 7.76142 4.23858 10 7 10C9.76142 10 12 7.76142 12 5C12 2.23858 9.76142 0 7 0ZM4 5C4 3.34315 5.34315 2 7 2C8.65685 2 10 3.34315 10 5C10 6.65685 8.65685 8 7 8C5.34315 8 4 6.65685 4 5Z"
                          fill="#2D2D3B"
                        ></path>
                        <path
                          d="M14.9084 5.21828C14.6271 5.07484 14.3158 5.00006 14 5.00006V3.00006C14.6316 3.00006 15.2542 3.14956 15.8169 3.43645C15.8789 3.46805 15.9399 3.50121 16 3.5359C16.4854 3.81614 16.9072 4.19569 17.2373 4.65055C17.6083 5.16172 17.8529 5.75347 17.9512 6.37737C18.0496 7.00126 17.9987 7.63958 17.8029 8.24005C17.6071 8.84053 17.2719 9.38611 16.8247 9.83213C16.3775 10.2782 15.8311 10.6119 15.2301 10.8062C14.6953 10.979 14.1308 11.037 13.5735 10.9772C13.5046 10.9698 13.4357 10.9606 13.367 10.9496C12.7438 10.8497 12.1531 10.6038 11.6431 10.2319L11.6421 10.2311L12.821 8.61557C13.0761 8.80172 13.3717 8.92477 13.6835 8.97474C13.9953 9.02471 14.3145 9.00014 14.615 8.90302C14.9155 8.80591 15.1887 8.63903 15.4123 8.41602C15.6359 8.19302 15.8035 7.92024 15.9014 7.62001C15.9993 7.31978 16.0247 7.00063 15.9756 6.68869C15.9264 6.37675 15.8041 6.08089 15.6186 5.82531C15.4331 5.56974 15.1898 5.36172 14.9084 5.21828Z"
                          fill="#2D2D3B"
                        ></path>
                        <path
                          d="M17.9981 18C17.9981 17.475 17.8947 16.9551 17.6938 16.47C17.4928 15.9849 17.1983 15.5442 16.8271 15.1729C16.4558 14.8017 16.0151 14.5072 15.53 14.3062C15.0449 14.1053 14.525 14.0019 14 14.0019V12C14.6821 12 15.3584 12.1163 16 12.3431C16.0996 12.3783 16.1983 12.4162 16.2961 12.4567C17.0241 12.7583 17.6855 13.2002 18.2426 13.7574C18.7998 14.3145 19.2417 14.9759 19.5433 15.7039C19.5838 15.8017 19.6217 15.9004 19.6569 16C19.8837 16.6416 20 17.3179 20 18H17.9981Z"
                          fill="#2D2D3B"
                        ></path>
                        <path
                          d="M14 18H12C12 15.2386 9.76142 13 7 13C4.23858 13 2 15.2386 2 18H0C0 14.134 3.13401 11 7 11C10.866 11 14 14.134 14 18Z"
                          fill="#2D2D3B"
                        ></path>
                      </svg>
                      <span>{ButtonLanguage.clone}</span>
                    </Dropdown.Item>

                    <Dropdown.Item onClick={() => this.deleteCoupon(value)}>
                      <svg
                        width={19}
                        height={19}
                        viewBox="0 0 18 20"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
                          fill="#2D2D3B"
                        />
                      </svg>
                      <span>{ButtonLanguage.archive}</span>
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              </React.Fragment>
            );
          },
        },
      },
    ];

    const option = {
      responsive: "standard",
      searchOpen: false,
      search: false,
      searchAlwaysOpen: false,
      print: false,
      serverSide: true,
      pagination: true,
      count: this.state.totalSize,
      rowsPerPageOptions: [5, 10, 15, 100],
      onTableChange: (action, state) => {
        if (action === "changePage") {
          this.setState({ page: state.page + 1 }, () => {
            this.getAllCouponData();
          });
        } else if (action === "changeRowsPerPage") {
          this.setState({ sizePerPage: state.rowsPerPage }, () => {
            this.getAllCouponData();
          });
        }
      },
      textLabels: {
        body: {
          noMatch: "Sorry, no matching records found",
          toolTip: "Sort",
          columnHeaderTooltip: (column) =>
            `${productLanguage.Sortfor} ${column.label}`,
        },
        pagination: {
          next: "Next Page >",
          previous: "< Previous Page",
          rowsPerPage: "Rows per page:",
          displayRows: "of",
        },
        toolbar: {
          search: "Search",
          downloadCsv: "Download CSV",
          print: "Print",
          viewColumns: "View Columns",
          filterTable: "Filter Table",
        },
        filter: {
          all: false,
          title: false,
          reset: false,
        },
        selectedRows: {
          text: "row(s) selected",
          delete: "",
          deleteAria: "Apply action on Selected Rows",
        },
      },
      selectableRows: true,
      onFilterConfirm: (filterList) => {
        console.log(filterList);
      },
      onFilterDialogOpen: () => {
        console.log("filter dialog opened");
      },
      onFilterDialogClose: () => {
        console.log("filter dialog closed");
      },
      filter: true,
      filterType: "custom",
      display: true,
    };

    const salescolumns = [
      {
        label: "Sale name",
        name: "sale_name",
        options: {
          filter: true,
        },
      },
      {
        label: "Value",
        name: "value",
        options: {
          filter: true,
        },
      },
      {
        label: "Affected Products",
        name: "affected_products",
        options: {
          filter: true,
        },
      },
      {
        label: "Create date",
        name: "create_date",
        options: {
          filter: true,
        },
      },
      {
        label: "Status",
        name: "status",
        options: {
          filter: true,
          customBodyRender: () => {
            return (
              <>
                <div className="d-inline-flex align-items-center cust-switch-drop border-0 p-0">
                  <label className="switch ms-auto">
                    <input
                      type="checkbox"
                      name="slider"
                      defaultChecked
                      value="slider"
                    />
                    <div className="slider round" />
                  </label>
                </div>
              </>
            );
          },
        },
      },
      {
        label: "Action",
        name: "action",
        options: {
          filter: false,
          sort: false,
          empty: true,

          customBodyRender: (value, tableMeta, updateValue) => {
            return (
              <React.Fragment>
                <Dropdown className="cust-drop">
                  <Dropdown.Toggle
                    className="bg-transparent "
                    id="dropdown-basic"
                    align="end"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width={16}
                      height={16}
                      fill="currentColor"
                      className="bi bi-three-dots-vertical"
                      viewBox="0 0 16 16"
                    >
                      <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                    </svg>
                  </Dropdown.Toggle>
                  <Dropdown.Menu>
                    <Dropdown.Item href="#">
                      <svg
                        width={19}
                        height={19}
                        viewBox="0 0 19 19"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M1.41999 18.579C1.13948 18.5785 0.872062 18.4602 0.682993 18.253C0.490439 18.0475 0.394758 17.7695 0.419993 17.489L0.664993 14.795L11.983 3.481L15.52 7.017L4.20499 18.33L1.51099 18.575C1.47999 18.578 1.44899 18.579 1.41999 18.579ZM16.226 6.31L12.69 2.774L14.811 0.652997C14.9986 0.46522 15.2531 0.359711 15.5185 0.359711C15.7839 0.359711 16.0384 0.46522 16.226 0.652997L18.347 2.774C18.5348 2.96157 18.6403 3.21609 18.6403 3.4815C18.6403 3.74691 18.5348 4.00143 18.347 4.189L16.227 6.309L16.226 6.31Z"
                          fill="#2D2D3B"
                        />
                      </svg>
                      <span>{ButtonLanguage.edit}</span>
                    </Dropdown.Item>

                    <Dropdown.Item>
                      <svg
                        width={19}
                        height={19}
                        viewBox="0 0 18 20"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
                          fill="#2D2D3B"
                        />
                      </svg>
                      <span>Delete</span>
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              </React.Fragment>
            );
          },
        },
      },
    ];
    return (
      <Adminlayout>
        <div className="container-fluid">
          <div className="row common-space align-items-center">
            <div className="col-6  text-start rtl-txt-start">
              <div className="common-header-txt">
                <h3>{titleLanguage.marketing}</h3>
              </div>
            </div>
            <div className="col-6  text-end rtl-txt-end">
              <div className="common-red-btn">
                <a className="btn red-btn" onClick={this.addEvent}>
                  {marketingLanguage.AddCoupon}
                </a>
              </div>
            </div>
          </div>
          <div className="row common-space">
            <div className="col-md-12">
              <div className="market-cysrom-tabs-comn">
                <Tabs
                  activeKey={this.state.key}
                  onSelect={(k) => this.setKey(k)}
                  id="marketing-tabs"
                >
                  <Tab eventKey="codes" title={marketingLanguage.DiscountCodes}>
                    <div className="white-box mt-3">
                      <div className="custom-table">
                        <div className="table-responsive dataTables_wrapper no-footer">
                          {this.state.AllCouponData && (
                            <MUITable
                              data={this.state.AllCouponData}
                              columns={columns}
                              options={option}
                            />
                          )}
                          <div className="fix-search right-menu p-3">
                            <div
                              className="position-relative search-sm-screen"
                              id="search-menu"
                            >
                              <input
                                type="search"
                                name="search"
                                className="form-control top-search ps-5 input-custom-class mb-0"
                                placeholder={productLanguage.search}
                                onChange={this.searchCoupone}
                              />
                              <span className="search-icn position-absolute ms-3">
                                <img src={SearchIcon} alt="" />
                              </span>
                            </div>
                            {/* <button className="border-0 bg-transparent dark-red-txt w-100">Clear Filter x</button> */}
                          </div>
                        </div>
                      </div>
                    </div>
                  </Tab>
                  <Tab eventKey="prices" title={marketingLanguage.SalePrices}>
                    <div className="white-box mt-3">
                      <div className="custom-table">
                        <div className="table-responsive dataTables_wrapper no-footer">
                          {this.state.AllSalesData && (
                            <MUITable
                              data={this.state.AllSalesData}
                              columns={salescolumns}
                              options={this.state.options}
                            />
                          )}
                        </div>
                      </div>
                    </div>
                  </Tab>
                  <Tab
                    eventKey="automatic"
                    title={marketingLanguage.AutomaticDiscounts}
                  >
                    <div className="white-box mt-3">
                      <div className="custom-table">
                        <div className="table-responsive dataTables_wrapper no-footer">
                          table2
                        </div>
                      </div>
                    </div>
                  </Tab>
                  <Tab
                    eventKey="bundle"
                    title={marketingLanguage.BundleDiscounts}
                  >
                    <div className="white-box mt-3">
                      <div className="custom-table">
                        <div className="table-responsive dataTables_wrapper no-footer">
                          table3
                        </div>
                      </div>
                    </div>
                  </Tab>
                  <Tab
                    eventKey="special"
                    title={marketingLanguage.SpecialDiscounts}
                  >
                    <div className="white-box mt-3">
                      <div className="custom-table">
                        <div className="table-responsive dataTables_wrapper no-footer">
                          table4
                        </div>
                      </div>
                    </div>
                  </Tab>
                </Tabs>
              </div>
            </div>
          </div>
        </div>

        {/* ------------------------modal-------------------------- */}
        {/* <Modal dialogClassName="modal-dialog-centered cust-width-modal" className="edit-user-modal cust-modal" ref={el => {
                    this.dialog = el;
                }} show={this.state.search_show} onHide={this.edit_filterClose}>
                    <Modal.Header>
                        <Modal.Title>
                            <h1 className="modal-title">Filter</h1>
                        </Modal.Title>
                        <button type="button" onClick={this.edit_filterClose}
                            className="close btn-close"></button>
                    </Modal.Header>
                    <Modal.Body>

                    </Modal.Body>
                </Modal> */}
      </Adminlayout>
    );
  }
}

export default withRouter(Marketing);
