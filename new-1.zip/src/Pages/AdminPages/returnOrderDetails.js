import React, { Component } from "react";
import { Modal, OverlayTrigger, Tooltip, Accordion } from "react-bootstrap";
import Adminlayout from "../../Components/AdminLayout/Adminlayout";
// import Barcode from "react-barcode";
import { CopyToClipboard } from "react-copy-to-clipboard";
import Verified from "../../images/verify-phone.svg";
// import QRCode from "react-qr-code";
import toastr from "toastr";
import {
  API_Path,
  buttonArabic,
  buttonEnglish,
  orderArabic,
  orderEnglish,
  DashboardArabic,
  DashboardEnglish,
  TableFieldArabic,
  TableFieldEnglish,
  titleArabic,
  titleEnglish,
  UserEnglish,
  UserArabic,
} from "../../const";
import { GetApi, PostApi } from "../../helper/APIService";
import { withRouter } from "react-router-dom";
import LanguageContext from "../../contexts/languageContext";
import moment from "moment";
import loader from "../../images/loader.gif";
import ReturnProductList from "../../Components/return-order-details/ReturnProductList";
import { CircularProgress } from "@material-ui/core";
import RestockModal from "../../Components/return-order-details/RestockModal";

let total1 = 0;
let total2 = 0;
let total_price = 0;

const enableFieldsOnUpdateShipment = {
  10: ["customerName", "phoneNumber", "city", "area", "line_1", "line_2"],
  11: ["customerName", "phoneNumber", "email", "cityArea", "line_1", "line_2"],
};

const STATUS = {
  PENDING: 21,
  ACCEPTED: 22,
  REJECTED: 23,
  SHIPPED: 24,
  DELIVERED: 25,
  CANCELLED: 26,
  APPROVED: 27,
};

class ReturnOrderDetails extends Component {
  static contextType = LanguageContext;
  constructor(props) {
    super(props);
    this.state = {
      sendmsgmodal: "",
      refundmodal: "",
      addnotes: "",
      detailData: null,
      cancelled_item: [],
      returned_item: [],
      products: [],
      acceptedProducts: [],
      rejectedProducts: [],
      create_show: false,
      emailToCopy: "salim@libsimarkah.com",
      addressToCopy: "Near Jamiu KabeerShipping",
      phoneToCopy: "0508946664",
      // invoice edit state
      isBarcodeShow: false,
      invoice_number: "",
      invoice_svg: "",
      tracking_link: "",
      tracking_number: null,
      ShipmentID: "",
      ShipmentCompany: "",
      // cancel item state
      cancelButton: false,
      order_id: null,
      item_id: null,
      user_id: null,
      order_item: [],
      order_status: null,
      orderStatusValue: "",
      checkButton: false,
      optionSelected: false,
      orderStatusCheckBox: true,
      status: null,
      SubTotal: 0,
      total1: 0,
      total2: 0,
      total_price: 0,
      qeneratecode: "",
      barcode: "",
      notes: "",
      barcodeoption: {
        width: 2,
        font: "Poppins",
        rodchanges: null,
      },
      DisplayNotes: "",
      Editaddnotes: false,
      Editnotes: "",
      note_id: "",
      quantity: 1,
      shippingCompany: "",
      labelType: "",
      customerName: "",
      shipmentCustomerName: "",
      phoneNumber: "",
      cityArea: "",
      line_1: "",
      line_2: "",
      referenceNumber: "",
      trackingNumber: "",
      codValue: 0,
      shipmentComments: "",
      shippingCompanyData: [],
      pickupRequest: false,
      ClosingTime: moment().add(3, "day").format("YYYY-MM-DDThh:mm"),
      LastPickupTime: moment().add(2, "day").format("YYYY-MM-DDThh:mm"),
      ReadyTime: moment().format("YYYY-MM-DDThh:mm"),
      PickupDate: moment().add(30, "minute").format("YYYY-MM-DDThh:mm"),
      redboxPickupTime: moment().format("HH:mm"),
      validation: false,
      ShipperData: "",
      ShippingLabel: "",
      createPopup: "",
      PickUpID: "",
      messageTextBox: "",
      CancelItems: [],
      qtys: "1",
      reasons: "",
      RefundMode: "",
      refundAmountType: "",
      RefundDescription: "",
      RefundAmount: "",
      refund_amount: "",
      r_amount: false,
      p_pieces: "",
      shippingUpdateCode: "",
      shippingDescription: "",
      // redboxPickupNotes: '',
      coustom_tracking_link: "",
      qr_invoice_show: false,
      qr_invoice_number: "",
      QRCode: "",
      cancelComfirmModelshow: false,
      installments: [],
      dimensionUnit: "CM",
      dimensionWidth: null,
      dimensionHeigth: null,
      dimensionLength: null,
      weightUnit: "GM",
      weightValue: null,
      loading: true,
      warehouses: [],
      warehouse: "",
      isUpdateShipment: false,
      AllCity: [],
      AllArea: [],
      city: null,
      area: null,

      isShipmentReset: false,
      isPickupStore: false,

      cancelRefundBtnName: null,
      isModalTypeApprove: true,
      showCancelConfirmModal: false,
      cancelSource: "1",
      activeSpinnerBtn: false,

      isAllProductsSelected: false,
      selectedProducts: [],
      sendNotificationToCustomer: true,

      showRestockModal: false,

      refundSummary: {
        itemCount: 0,
        vatPercentage: 0,
        vatValue: 0,
        costOfReturn: 0,
        subTotal: 0,
        total: 0,
      },
    };
  }

  isShippingCompanyRedbox = () => this.state.shippingCompany === "11";

  componentDidMount() {
    let url = window.location.href;
    let idString = url?.split("/")[url?.split("/")?.length - 1];
    let id = parseInt(idString);
    this.setState({ order_id: id });
    this.get_city_and_area();
    this.getOrderDetailData(id);
    this.getNotes(id);
    this.getShippingData();
    this.getSetting();
  }

  getInstallmentDetails = () => {
    const getInstallmentDetailsPromise = new Promise((resolve) => {
      resolve(GetApi(`${API_Path.tabbyInstallments}/${this.state.order_id}`));
    });
    getInstallmentDetailsPromise.then((res) => {
      if (res && res.data.message[0]) {
        const parsedResponse =
          JSON.parse(res.data.message[0].installments)[0] ??
          JSON.parse(res.data.message[0].installments);
        const installments = [
          {
            amount: parsedResponse?.downpayment_total,
            due_date: moment(this.state.detailData.createdat).format("DD-MMM"),
          },
          ...parsedResponse?.installments.map(({ amount, due_date }) => ({
            amount,
            due_date: moment(due_date).format("DD-MMM"),
          })),
        ];
        this.setState({ installments });
      }
    });
  };

  getSetting = () => {
    let path = API_Path.GetSetting;
    new Promise((resolve, reject) => {
      resolve(PostApi(path));
    }).then((res) => {
      if (res) {
        this.setState((state) => ({
          ShipperData: res.data.data[0].shipping,
          shippingCompany:
            state.shippingCompany.length !== 0
              ? state.shippingCompany
              : res.data.data[0]?.shipping?.default_shipping_company[0]?.id,
          ShipmentCompany:
            res.data.data[0]?.shipping?.default_shipping_company[0]?.id,
        }));
      }
    });
  };

  getShippingData = () => {
    let data = {};
    let path = API_Path.getShippingCompany;
    const getShippingDataPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });
    getShippingDataPromise.then((res) => {
      if (res) {
        this.setState({ shippingCompanyData: res.data.data });
      }
    });
  };

  refundmodal = () => {
    this.setState({ refundAmountType: "", RefundMode: "" }, () => {
      this.setState({ refundmodal: true });
    });
  };

  refundmodalclose = () => {
    this.setState({ refundmodal: false });
  };

  addnotes = () => {
    this.setState({ addnotes: true });
  };

  addnotesclose = () => {
    this.setState({ addnotes: false });
  };

  Editaddnotesclose = () => {
    this.setState({ Editaddnotes: false });
  };

  handleNote = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  handleEditNote = (id) => {
    this.state.DisplayNotes.map((item) => {
      if (item.id == id) {
        this.setState({ Editnotes: item.note });
      }
    });
    this.setState({ Editaddnotes: true, note_id: id });
  };

  submitNote = (e) => {
    // this.setState({})
    e.preventDefault();
    this.addnotesclose();
  };

  getShipingLabel = (s_id, id) => {
    let data = {
      ship_id: s_id,
      orderID: id,
    };
    new Promise((resolve) => {
      resolve(PostApi(API_Path.creatLabel, data));
    }).then((res) => {
      this.setState(
        { ShippingLabel: res.data.data.ShipmentLabel.LabelURL },
        () => {
          this.getOrderDetailData(id);
        }
      );
    });
  };
  getWarehouses = () => {
    new Promise((resolve) => {
      resolve(GetApi(API_Path.getPickupLocations));
    }).then((res) => {
      this.setState({
        warehouses: res.data.warehouse,
        warehouse: res.data.warehouse[0]?.id ?? "",
      });
    });
  };

  checkForNull = (object) => {
    const updatedObject = {};

    for (let key in object) {
      if (object[key] === null || object[key] === "null") {
        updatedObject[key] = null;
      } else {
        updatedObject[key] = object[key];
      }
    }

    return updatedObject;
  };

  getOrderDetailData = (id) => {
    let data = {
      id: id,
    };
    this.setState({ loading: true });
    const getDetailDataPromise = new Promise((resolve) => {
      resolve(PostApi(API_Path.getReturnOrderById, data));
    });
    getDetailDataPromise
      .then((response) => {
        if (response) {
          const responseData = response.data.data;
          // console.log('getDetailDataPromise: ', data,API_Path.getOrderById);
          if (responseData) {
            const data = responseData[0];
            if (data.pay_method === "TABBY") this.getInstallmentDetails();

            const shippingCompanyId = data.return_shipping_company_id;

            this.setState(
              (state) =>
                this.checkForNull({
                  detailData: data,
                  barcode: data?.invoice_no !== null ? data?.invoice_no : "",
                  invoice_number:
                    data?.invoice_no !== null ? data?.invoice_no : "",
                  isBarcodeShow: true,
                  invoice_svg: data?.invoice_svg,
                  ShipmentID: data?.return_ship_id,
                  PickUpID: data?.pickup_id,
                  tracking_number: data?.return_ship_id,
                  tracking_link: data?.tracking_link ?? data?.return_track_url,
                  orderStatusValue: data?.status,
                  reason: data?.return_reason,
                  emailToCopy:
                    data?.user_details?.length > 0
                      ? data?.user_details[0]?.email
                      : "",
                  addressToCopy:
                    data?.user_address?.length > 0
                      ? data?.user_address[0]?.line_1
                      : "",
                  phoneToCopy:
                    data?.user_address?.length > 0
                      ? data?.user_address[0]?.phone
                      : "",
                  labelType: "6x4 Thermal printer",
                  addressId: data?.id,
                  shipmentCustomerName: data?.address?.name,
                  line_1: data?.address?.line_1,
                  line_2: data?.address?.line_2,
                  cityArea:
                    data?.address?.city_en + "-" + data?.address?.area_en,
                  city: data?.address?.city_id,
                  area: data?.address?.area_id,
                  phoneNumber:
                    data?.address.phone?.substring(0, 3) !== "966"
                      ? data?.address.phone
                      : data?.address.phone?.substring(3),
                  customerName: data?.user_details[0]?.first_name,
                  email: data?.user_details[0]?.email,
                  referenceNumber: data?.id,
                  trackingNumber: data?.ship_id,
                  ShippingLabel: data.return_label_url,
                  user_id: data.user_id,
                  shippingUpdateCode: data.return_shipment_code, // data.aramex_updateCode,
                  shippingDescription: data.return_shipment_description, // data.aramex_updateDescription,
                  ShipmentCompany: shippingCompanyId
                    ? shippingCompanyId.toString()
                    : state.ShipmentCompany !== ""
                    ? state.ShipmentCompany
                    : "",
                  shippingCompany: shippingCompanyId
                    ? shippingCompanyId.toString()
                    : state.shippingCompany !== ""
                    ? state.shippingCompany
                    : "",
                  coustom_tracking_link: data.return_track_url,
                  qr_invoice_number: data.e_invoice_hash,
                  QRCode: data.e_invoice_hash,
                  qeneratecode: data.e_invoice_hash ?? "",
                  isPickupStore: data.is_store === 1,
                }),
              () => {}
            );
            if (data.invoice_number !== "" && data.invoice_number) {
              this.setState({ isBarcodeShow: true });
            }

            // const productsWithQty = {};

            // data.order_item_list
            //   .filter(({ apply_to_return }) => apply_to_return === 1)
            //   .forEach((item) => {
            //     if (!productsWithQty[item.product_id]) {
            //       const product = { ...item, quantity: 1 };
            //       productsWithQty[item.product_id] = product;
            //     } else {
            //       productsWithQty[item.product_id].quantity++;
            //     }
            //   });

            const products = data.return_order_item_list
              // Object.values(productsWithQty)
              .filter(
                ({ apply_to_return, accept_return, return_rejected }) =>
                  apply_to_return === 1 &&
                  accept_return !== 1 &&
                  return_rejected !== 1
              )
              .map((item) => ({
                ...item,
                quantity: 1,
                details: data.order_item.find(
                  ({ product_id }) => item.product_id === product_id
                ),
              }));

            const acceptedProducts = data.return_order_item_list
              // Object.values(productsWithQty)
              .filter(({ accept_return }) => accept_return === 1)
              .map((item) => ({
                ...item,
                quantity: 1,
                details: data.order_item.find(
                  ({ product_id }) => item.product_id === product_id
                ),
              }));

            const rejectedProducts = data.return_order_item_list
              // Object.values(productsWithQty)
              .filter(({ return_rejected }) => return_rejected === 1)
              .map((item) => ({
                ...item,
                quantity: 1,
                details: data.order_item.find(
                  ({ product_id }) => item.product_id === product_id
                ),
              }));
            // console.log(products, acceptedProducts);

            // total_price =
            //   total_price +
            //   parseInt(data.price) +
            //   parseInt(data.shipping_cost) +
            //   parseInt(data.COD_cost) +
            //   parseInt(data.plateform_cost) +
            //   (parseInt(data.price) * 15) / 100 -
            //   parseInt(data.wallet_cost) -
            //   parseInt(data.coupon_price) -
            //   parseInt(data.discount);

            const acceptedItemsTotalPrice = acceptedProducts.reduce(
              (acc, item) => (acc = acc + item.details.product_price),
              0
            );

            this.setState(
              {
                products,
                acceptedProducts,
                rejectedProducts,
                refundSummary: {
                  itemCount: products.length,
                  vatPercentage: 0,
                  vatValue: 0,
                  costOfReturn: 0,
                  subTotal:
                    // this.state.detailData.final_ordered_price?.toFixed(2),
                    this.state.detailData.total_paymentable_price?.toFixed(2),
                  total: acceptedItemsTotalPrice.toFixed(2),
                },
                codValue:
                  data?.pay_method === "COD"
                    ? acceptedItemsTotalPrice.toFixed(2) -
                      data.order_payments_refund.reduce(
                        (a, b) => (a = a + b.amount),
                        0
                      )
                    : 0, //data?.total_paymentable_price : 0,
                // total_price: parseFloat(total_price)?.toFixed(2),
              },
              () => {
                let pices = this.state.products.reduce(
                  (a, b) => (a = a + b.quantity),
                  0
                );
                this.setState({ p_pieces: pices });
              }
            );

            // ====================================cancel-product==============================================
            // let cancel_item = data.order_item_list.filter(
            //   (item) => item.cancelled === 1
            // );
            // for (let i = 0; i < cancel_item.length; i++) {
            //   let checked = data.order_item.findIndex(
            //     (e) => e.variant_id === cancel_item[i].variant_id
            //   );
            //   if (checked != -1) {
            //     cancel_item[i].img =
            //       data.order_item[checked].image.split(",")[0];
            //     cancel_item[i].title_en = data.order_item[checked].title_en;
            //     cancel_item[i].title_ar = data.order_item[checked].title_ar;
            //     cancel_item[i].color_ar = data.order_item[checked].color_ar;
            //     cancel_item[i].color_en = data.order_item[checked].color_en;
            //     cancel_item[i].size_ar = data.order_item[checked].size_ar;
            //     cancel_item[i].size_en = data.order_item[checked].size_en;
            //     cancel_item[i].barcode = data.order_item[checked].barcode;
            //     cancel_item[i].discounted_price =
            //       data.order_item[checked].discounted_price;
            //     cancel_item[i].paymentable_price =
            //       (data.order_item[checked].discounted_price *
            //         (100 - Number(data.discount_value))) /
            //       100;
            //   }
            // }
            // if (cancel_item.length > 0) {
            //   this.setState(
            //     { cancelled_item: cancel_item, total1: total1 },
            //     () => {
            //       let refund = this.state.cancelled_item.reduce(
            //         (a, b) => (a = a + b.discounted_price),
            //         0
            //       );
            //       this.setState({ total1: refund });
            //     }
            //   );
            // }
            const returned_item = data.order_item.filter((item) => {
              if (item.status == 2) {
                total2 = total2 + parseInt(item.cart_price);
                return item;
              }
            });

            this.setState({ returned_item: returned_item, total2: total2 });
          }
        }
        this.setState({ loading: false });
      })
      .catch((err) => {
        console.log(err);
        this.setState({ loading: false });
      });
  };

  cancelProduct = (order_id, order_status, user_id, order_item) => {
    let data = {
      user_id: user_id,
      cancel_orders: order_item,
    };

    this.setState({ activeSpinnerBtn: true });
    const cancelProductPromise = new Promise((resolve) => {
      resolve(PostApi(API_Path.cancelOrderItem, data));
    });
    cancelProductPromise.then((response) => {
      if (response.data.success) {
        this.createRefundOnCancel();
        if (this.context.language === "english") {
          toastr.success(response.data.message);
        } else {
          toastr.success("منح التماس لإلغاء هذا الأمر");
        }
        for (let i = 0; i < this.state.products.length; i++) {
          document.getElementById("cancel-checked" + i).checked = false;
          document
            .getElementById("order-checked-id" + i)
            .classList.remove("active");
        }
        this.setState({ checkButton: false });

        this.getOrderDetailData(this.state.order_id);
      } else {
        toastr.error(response.data.message);
      }
    });
  };

  editInvoiceData = (
    invoice_number,
    invoice_svg,
    ShipmentID,
    tracking_number,
    tracking_link,
    status
  ) => {
    let fields = {
      shipping_id: ShipmentID,
      invoice_number: invoice_number,
      tracking_number: tracking_number,
      tracking_link: tracking_link,
      invoice_svg: invoice_svg,
      status: status,
    };
    const data = {
      id: this.state.detailData.id,
      fields: fields,
    };
    // console.log("editInvoiceData", data);
    const editInvoiceDataPromise = new Promise((resolve) => {
      resolve(PostApi(API_Path.editInvoiceData, data));
    });
    editInvoiceDataPromise.then((response) => {
      if (response.data.success) {
        toastr.success(response.data.message);

        this.getOrderDetailData(this.state.order_id);
      } else {
        toastr.error(response.data.message);
      }
    });
  };

  handleItemReturnApprove = (isApprove) => {
    if (this.state.selectedProducts.length === 0) {
      toastr.error(
        `Please select items to ${isApprove ? "Approve" : "Reject"}`
      );
      return;
    }

    this.setState({
      isModalTypeApprove: isApprove,
      showCancelConfirmModal: true,
    });
  };

  handleCancel = (e) => {
    let name = e ? e.target.innerText : this.state.cancelRefundBtnName;
    this.setState({ order_status: name === "Cancel Item" ? 6 : 2 }, () => {
      if (
        this.state.checkButton &&
        this.state.order_status !== null &&
        this.state.optionSelected
      ) {
        let arr = this.state.order_item.forEach((item) => {
          if ((item.reason && item.quantity) === "") {
            return false;
          }
        });
        const { refundCalculation, ...order_item } = this.state.order_item[0];
        this.cancelProduct(
          this.state.order_id,
          this.state.order_status,
          this.state.user_id,
          [order_item]
        );
      } else {
        toastr.error("Please Select Reason");
      }
    });
    if (name === "Cancel Item") {
      this.setState({ order_status: 1 }, () => {
        this.setState({ optionSelected: false });
      });
    } else if (name === "Return Item") {
      this.setState({ order_status: 2 }, () => {
        this.setState({ optionSelected: false });
      });
    }
    this.setState({ cancelButton: true }, () => {});
  };

  handleReturnDetailsChange = (e, item, select) => {
    this.setState({ [e.target.name]: e.target.value }, () => {
      let optionSelected;
      if (e.target.option !== 0) {
        optionSelected = true;

        this.setState({ optionSelected: true });
      }
      let obj = { order_id: item.id, reason: e.target.value };
      let checked = true;
      if (this.state.order_item.length > 0) {
        this.state.order_item.filter((value) => {
          if (value.order_product_id === item.id) {
            return (checked = false);
          }
        });
      }
      if (this.state.reasons !== "") {
        let arr;
        if (checked) {
          let newObj = {
            order_id: item.order_id,
            order_product_id: item.id,
            quantity: this.state.qtys,
            reason: this.state.reasons,
            refundCalculation: {
              quantity: item.quantity,
              // price: item.discounted_price,
              price: item.paymentable_price / item.quantity,
            },
          };
          arr = [...this.state.order_item, newObj];
        } else {
          for (let i in this.state.order_item) {
            if (this.state.order_item[i].order_product_id === item.id) {
              this.state.order_item[i].order_id = item.order_id;
              this.state.order_item[i].order_product_id = item.id;
              this.state.order_item[i].quantity = this.state.qtys;
              this.state.order_item[i].reason = this.state.reasons;
            }
          }
          arr = this.state.order_item;
        }
        this.setState(
          {
            order_item: arr,
            order_id: item.order_id,
            user_id: item.user_id,
          }
          // , () => {
          //   console.log(this.state.order_item);

          // }
        );
      }
    });
  };

  DateTimeToTimeStemp = (value) => {
    const date = moment(value).unix(); //new Date(value)
    // const timestamp = date.getTime()
    return date;
  };

  handleCreateShipment = () => {
    // console.log('this.state.createPopup: ', this.state.createPopup);

    if (this.state.createPopup === "pickup") {
      this.setState({ validation: true });
      let ready_time = this.DateTimeToTimeStemp(this.state.ReadyTime);
      let Pickup_date = this.DateTimeToTimeStemp(this.state.PickupDate);
      let lastpickup_time = this.DateTimeToTimeStemp(this.state.LastPickupTime);
      let closing_time = this.DateTimeToTimeStemp(this.state.ClosingTime);
      let pickup_data = {
        orderID: this.state.order_id,
        quntity: this.state.quantity,
        shippingcompany: this.state.ShipmentCompany,
        labletype: this.state.labelType,
        customer: this.state.shipmentCustomerName,
        cityarea: this.state.cityArea?.split("-")[0],
        city: this.state.AllCity?.find((city) => city.id == this.state.city)
          ?.english,
        area: this.state.AllArea?.find((area) => area.id == this.state.area)
          ?.english,
        addess_line1: this.state.line_1,
        addess_line2: this.state.line_2,
        referenceno: this.state.referenceNumber,
        phone: this.state.phoneNumber,
        email: this.state.email,
        Cod: this.state.codValue,
        comment: this.state.shipmentComments,
        PickupDate: Pickup_date,
        ReadyTime: ready_time,
        LastPickupTime: lastpickup_time,
        ClosingTime: closing_time,
      };
      if (this.isShippingCompanyRedbox()) {
        pickup_data.redbox_data = {
          pickup_location_id: this.state.warehouse,
          pickup_location_reference: this.state.warehouses.find(
            ({ id }) => id === this.state.warehouse
          ).reference,
          pickup_time: moment(this.state.redboxPickupTime, "HH:mm").format(
            "MMM DD/MM/yyyy HH:mm"
          ),
          note: this.state.shipmentComments,
        };
      }

      if (ready_time < Pickup_date) {
        if (Pickup_date < lastpickup_time) {
          if (lastpickup_time < closing_time) {
            let path = API_Path.creatPickup;
            const creatPickupPromise = new Promise((resolve, reject) => {
              resolve(PostApi(path, pickup_data));
            });

            creatPickupPromise.then((res) => {
              if (res) {
                if (res.data.data) {
                  toastr.success(res.data.message);
                }
              } else {
                toastr.error(res.data.message);
              }
            });
          } else {
            toastr.error(
              "Last Pickup Time should be earlier then  Closing Time"
            );
          }
        } else {
          toastr.error(" Pickup Time should be earlier then Last Pickup Time");
        }
      } else {
        toastr.error("Redy Time  should be earlier then Pickup Time");
      }
    } else {
      if (!this.state.isUpdateShipment && this.state.pickupRequest) {
        this.setState({ validation: true });
        let ready_time = this.DateTimeToTimeStemp(this.state.ReadyTime);
        let Pickup_date = this.DateTimeToTimeStemp(this.state.PickupDate);
        let lastpickup_time = this.DateTimeToTimeStemp(
          this.state.LastPickupTime
        );
        let closing_time = this.DateTimeToTimeStemp(this.state.ClosingTime);
        let pickup_data = {
          orderID: this.state.order_id,
          quntity: this.state.quantity,
          shippingcompany: this.state.ShipmentCompany,
          labletype: this.state.labelType,
          customer: this.state.shipmentCustomerName,
          cityarea: this.state.cityArea?.split("-")[0],
          city: this.state.AllCity?.find((city) => city.id == this.state.city)
            ?.english,
          area: this.state.AllArea?.find((area) => area.id == this.state.area)
            ?.english,
          addess_line1: this.state.line_1,
          addess_line2: this.state.line_2,
          referenceno: this.state.referenceNumber,
          tracking: this.state.trackingNumber,
          phone: this.state.phoneNumber,
          email: this.state.email,
          Cod: this.state.codValue,
          comment: this.state.shipmentComments,
          PickupDate: Pickup_date,
          ReadyTime: ready_time,
          LastPickupTime: lastpickup_time,
          ClosingTime: closing_time,
        };
        if (this.isShippingCompanyRedbox()) {
          pickup_data.redbox_data = {
            pickup_location_id: this.state.warehouse,
            pickup_location_reference: this.state.warehouses.find(
              ({ id }) => id === this.state.warehouse
            ).reference,
            pickup_time: moment(this.state.redboxPickupTime, "HH:mm").format(
              "MMM DD/MM/yyyy HH:mm"
            ),
            note: this.state.shipmentComments,
          };
        }

        if (ready_time < Pickup_date) {
          if (Pickup_date < lastpickup_time) {
            if (lastpickup_time < closing_time) {
              let path = API_Path.creatPickup;
              const creatPickupPromise = new Promise((resolve, reject) => {
                resolve(PostApi(path, pickup_data));
              });

              creatPickupPromise.then((res) => {
                if (res) {
                  if (res.data.data) {
                    toastr.success(res.data.message);
                  }
                } else {
                  toastr.error(res.data.message);
                }
              });
            } else {
              toastr.error(
                "Last Pickup Time should be earlier then  Closing Time"
              );
            }
          } else {
            toastr.error(
              " Pickup Time should be earlier then Last Pickup Time"
            );
          }
        } else {
          toastr.error("Redy Time  should be earlier then Pickup Time");
        }
      }
      // let data = {
      //   orderID: this.state.order_id,
      //   quntity: this.state.quantity,
      //   shippingcompany: this.state.shippingCompany,
      //   labletype: this.state.labelType,
      //   customer: this.state.shipmentCustomerName,
      //   cityarea: this.state.cityArea?.split("-")[0],
      //   city: this.state.AllCity?.find((city) => city.id == this.state.city)
      //     ?.english,
      //   area: this.state.AllArea?.find((area) => area.id == this.state.area)
      //     ?.english,
      //   addess_line1: this.state.line_1,
      //   addess_line2: this.state.line_2,
      //   referenceno: this.state.referenceNumber,
      //   tracking: this.state.trackingNumber,
      //   phone: this.state.phoneNumber,
      //   email: this.state.email,
      //   Cod: this.state.codValue,
      //   comment: this.state.shipmentComments,
      // };

      // if (this.state.shippingCompany === "10") {
      //   data.COD_cost = this.state.detailData.COD_cost;
      //   data.addressid = this.state.detailData.address.id;
      //   data.pay_method = this.state.detailData.pay_method;
      //   data.order_price = this.state.codValue;
      //   data.reff = this.state.order_id;
      //   data.shipping = this.state.ShipperData;
      // }

      const items = this.state.acceptedProducts.map(({ details: product }) => ({
        id: product.id,
        product_id: product.product_id,
        name: product.title_en,
        quantity: product.quantity,
        description: product.description_en,
        unit_price: product.product_price,
        currency: "SAR",
      }));

      let data = {};
      if (this.isShippingCompanyRedbox()) {
        data = {
          order_id: this.state.order_id,
          return_shipping_company: "Redbox",
          return_shipping_company_id: Number(this.state.shippingCompany),
          customer_name: this.state.customerName,
          customer_email: this.state.email ? this.state.email : "",
          customer_phone: this.state.phoneNumber ? this.state.phoneNumber : "",
          customer_address: `${this.state.line_1} ${this.state.line_2}`,
          customer_city: this.state.cityArea?.split("-")[0],
          cod_amount: this.state.codValue,
          cod_currency: "SAR",
          items,
        };
      } else {
        data = {
          order_id: this.state.order_id,
          quntity: this.state.quantity,
          return_shipping_company_id: Number(this.state.shippingCompany),
          // labletype: this.state.labelType,
          customer: this.state.shipmentCustomerName,
          cityarea: this.state.cityArea?.split("-")[0],
          city: this.state.AllCity?.find((city) => city.id == this.state.city)
            ?.english,
          area: this.state.AllArea?.find((area) => area.id == this.state.area)
            ?.english,
          address_line1: this.state.line_1,
          address_line2: this.state.line_2,
          referenceNo: this.state.referenceNumber,
          // tracking: this.state.trackingNumber,
          phone: this.state.phoneNumber,
          email: this.state.email,
          cod: this.state.codValue,
          comment: this.state.shipmentComments,
          shipper: {
            name: this.state.ShipperData.contact_name,
            email: this.state.ShipperData.email,
            phone: this.state.ShipperData.contact_number,
            city:
              this.context.language === "english"
                ? this.state.ShipperData.city_detail &&
                  this.state.ShipperData.city_detail[0]?.english
                : this.state.ShipperData.city_detail &&
                  this.state.ShipperData.city_detail[0]?.arabic,
            address: this.state.ShipperData.address,
          },
          items,
        };
      }

      let path = this.state.isUpdateShipment
        ? API_Path.updateReturnShipment
        : API_Path.creatReturnShipment;

      const creatShipmentPromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      creatShipmentPromise.then((res) => {
        if (res) {
          if (!res.data.success) {
            toastr.error(
              res.data.message_en
                ? this.context.language === "english"
                  ? res.data.message_en
                  : res.data.message_ar
                : res.data.message
            );
            return;
          }

          toastr.success(
            res.data.message ??
              (this.context.language === "english"
                ? res.data.message_en
                : res.data.message_ar)
          );
          // if (res.data.data) {
          //   if (res.data.data?.Shipments?.[0]?.ID)
          //     this.getShipingLabel(
          //       res.data.data.Shipments[0].ID,
          //       this.state.order_id
          //     );
          //   if (res.data.data?.shipping?.pdf_label)
          //     this.setState(
          //       { ShippingLabel: res.data.data.shipping.pdf_label }
          //       // , () => {
          //       // }
          //     );
          //   }
          this.getOrderDetailData(this.state.order_id);
          this.create_userClose();
        } else {
          toastr.error(
            res?.data?.message ??
              (this.context.language === "english"
                ? "Error creating shipment"
                : "حدث خطأ أثناء إنشاء الشحنة")
          );
        }
      });
    }

    // const path = "https://ws.dev.aramex.net/ShippingAPI.V2/Shipping/Service_1_0.svc/json/CreateShipments";
    // const data = {
    //   ClientInfo: {
    //     UserName: "reem@reem.com",
    //     Password: "123456789",
    //     Version: "1.0",
    //     AccountNumber: "4004636",
    //     AccountPin: "432432",
    //     AccountEntity: "RUH",
    //     AccountCountryCode: "SA",
    //     Source: "24",
    //   },
    // };

    // const createShippmentPromise = new Promise((resolve, reject) => {
    //   resolve(TestPostApi(path, JSON.stringify(data)));
    // });
    // createShippmentPromise.then((response) => {
    //   console.log("response :: ", response);
    // });

    // const path =
    //   "https://ws.aramex.net/shippingapi.v2/shipping/service_1_0.svc/json";

    // const data = {
    //   AccountNumber: "60496246",
    //   AccountEntity: "JED",
    //   AccountPin: "165165",
    //   AccountCountryCode: "SAUDI ARABIA",
    //   UserName: "salim@libsimarkah.com",
    //   Password: "@Libsi123",
    //   Version: "v1",
    //   // Shipper:,
    //   // Consignee: ,
    //   // ShippingDateTime:,
    //   // Source:,
    //   // Details:ShipmentDetails,
    //   // Line1: Address ,
    //   // CountryCode:,
    //   // PersonName:User’s Name,
    //   // CompanyName:Company or Person name,
    //   // PhoneNumber1:Valid Phone Number
    // };
    // const PostApiData = axios
    //   .post(path, data, config)
    //   .then((response) => {
    //     console.log(response.data);
    //     console.log(response);

    //     return response;
    //   })
    //   .catch((err) => {
    //     console.log(err);
    //     return err;
    //   });
    // return PostApiData;
  };

  handleOrderStatus = (e) => {
    this.setState({ orderStatusCheckBox: e.target.value > "5" ? false : true });
    if (e.target.value == "6") {
      this.setState({ cancelComfirmModelshow: true });
    } else {
      this.setState({ orderStatusValue: e.target.value }, () => {
        this.changeOrderStatus(this.state.orderStatusValue);
      });
    }
  };

  handleCloseConfirCancelModal = () => {
    this.setState({ cancelComfirmModelshow: false });
  };

  confirmCancelWholeOrder = () => {
    this.setState({ orderStatusValue: "6" }, () => {
      this.changeOrderStatus(this.state.orderStatusValue);
      this.handleCloseConfirCancelModal();
    });
  };

  changeOrderStatus = (status) => {
    let data = {
      order_status: status,
      return_order_id: this.state.order_id,
    };
    new Promise((resolve) => {
      resolve(PostApi(API_Path.changeReturnOrderStatus, data));
    }).then((res) => {
      if (res) {
        toastr.success(res.data.message);
        this.getOrderDetailData(this.state.order_id);
      }
    });
  };

  edit_userClose = () => {
    this.setState({ search_show: false });
  };

  edit_userShow = (e) => {
    e.preventDefault();
    this.setState({ search_show: true });
  };

  edit_handleShow = (e) => {
    e.preventDefault();
    this.setState({ search_show: true });
  };

  create_handleShow = (value) => {
    // e.preventDefault();
    // this.getSetting()
    if (value === "pickup") {
      this.setState({ pickupRequest: true });
      this.setState({ createPopup: value, create_show: true });
    } else if (value === "shipment") {
      // --- get warehouses for redbox ---
      // if (this.isShippingCompanyRedbox() && this.state.warehouses.length === 0)
      //   this.getWarehouses();

      this.setState({ createPopup: value, create_show: true });
    } else if (value === "updateShipment") {
      if (this.isShippingCompanyRedbox() && this.state.warehouses.length === 0)
        this.getWarehouses();
      this.setState({ isUpdateShipment: true, create_show: true });
    } else {
      let data = {
        shippingcompany: "9",
        shipId: "",
        track_url: this.state.coustom_tracking_link,
        orderID: this.state.order_id,
      };

      let path = API_Path.creatShipment;
      const creatShipmentPromise = new Promise((resolve, reject) => {
        resolve(PostApi(path, data));
      });

      creatShipmentPromise.then((res) => {
        if (res.data.success) {
          if (res.data.data) {
            toastr.success(res.data.message);
          }
        } else {
          toastr.error(res.data.message);
        }
      });
    }
  };

  create_userClose = () => {
    this.setState({ create_show: false });
  };

  create_userShow = (e) => {
    e.preventDefault();
    this.setState({ create_show: true });
  };

  handleChange = (e) => {
    if (e.target.name == "invoice_number") {
      this.setState({ isBarcodeShow: false });
    } else if (e.target.name === "pickupRequest") {
      this.setState({ pickupRequest: e.target.checked });
    } else {
      this.setState({ [e.target.name]: e.target.value });
    }
  };

  // handleSave = () => {
  //   console.log("save button clicked");
  //   this.editInvoiceData(this.state.invoice_number, this.state.invoice_svg, this.state.ShipmentID, this.state.tracking_number, this.state.tracking_link, this.state.orderStatusValue);
  //   this.getOrderDetailData(this.state.order_id);
  // };

  handleSaveInvoiceNumber = () => {
    if (this.state.invoice_number !== "") {
      this.setState({ isBarcodeShow: true }, () => {
        if (this.state.isBarcodeShow == true) {
          let value =
            document.getElementById("barcode-div") &&
            document.getElementById("barcode-div").innerHTML;
          this.setState({ invoice_svg: value }, () => {
            let data = {
              invoice_no: this.state.invoice_number,
              order_id: this.state.order_id,
            };
            let path = API_Path.updateInvoiceNumber;
            const updateInvoiceNumberPromise = new Promise(
              (resolve, reject) => {
                resolve(PostApi(path, data));
              }
            );

            updateInvoiceNumberPromise.then((res) => {
              if (res) {
                this.setState({ barcode: this.state.invoice_number });
                this.handleCloseInvoiceModal();
              } else {
                toastr.error(res.data.message);
              }
            });
          });
        }
      });
    } else {
      toastr.error("Please Add Bill Number");
    }
  };

  handleTrackChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  handleTrack = () => {
    let data = {
      ShipmentID: this.state.ShipmentID,
    };
    let path = API_Path.trackShipment;
    const trackPromise = new Promise((resolve, reject) => {
      resolve(PostApi(path, data));
    });

    trackPromise.then((res) => {
      if (res) {
      } else {
        toastr.error(res.data.message);
      }
    });
  };

  handleShippingOption = (e) => {
    this.setState(
      { ShipmentCompany: e.target.value, shippingCompany: e.target.value },
      () => {}
    );
  };

  handleSelectAllClick = (e) => {
    this.setState((state) => ({
      selectedProducts: e.target.checked ? state.products : [],
    }));
  };

  handleProductSelectForReturn = (e, i, id) => {
    // this.setState({ qtys: "1", reasons: "" });
    const state = this.state;

    if (e.target.checked) {
      const selectedProducts = [
        ...state.selectedProducts,
        state.products.find((item) => item.id === id),
      ];
      this.setState({ checkButton: true, selectedProducts });
    } else {
      const selectedProducts = state.selectedProducts.filter(
        (item) => item.id !== id
      );

      this.setState({ checkButton: false, selectedProducts });
      if (this.state.order_item.length > 0) {
        let updateArr = this.state.order_item.filter(
          (obj) => obj.order_product_id !== id
        );
        this.setState({ order_item: updateArr }, () => {
          console.log("updateArr", updateArr);
          //   console.log(this.state.order_item, "order_itemorder_item");
        });
      }
    }
  };

  sendmsgmodal = () => {
    this.setState({ sendmsgmodal: true, messageTextBox: "" });
  };

  sendmsgmodalclose = () => {
    this.setState({ sendmsgmodal: false });
  };

  qenerate = (e) => {
    this.setState({ qeneratecode: e.target.value });
  };

  barcode = (e) => {
    // this.setState({ barcode: e.target.value });
    if (e.target.name == "invoice_number") {
      this.setState({ isBarcodeShow: false, invoice_number: e.target.value });
    }
  };

  handleMessageChange = (e) => {
    this.setState({
      messageTextBox: e.target.value?.split(
        `Message from Libsimarkah related to order number: ${this.state.order_id}`
      )[
        e.target.value?.split(
          `Message from Libsimarkah related to order number: ${this.state.order_id}`
        )?.length - 1
      ],
    });
  };

  sendMsgViaEmail = (e) => {
    e.preventDefault();
    if (e.target[1].checked) {
      let phoneNo =
        this.state.detailData.user_details[0].phone.substring(0, 3) !== "966"
          ? "966" + this.state.detailData.user_details[0].phone
          : this.state.detailData.user_details[0].phone;
      let wp_url = `https://api.whatsapp.com/send/?phone=${phoneNo}&text=Message+from+Libsimarkah+related+to+order+number%3A+${this.state.order_id}%0A${this.state.messageTextBox}&type=phone_number&app_absent=0`;
      // let wp_url = `https://wa.me/${phoneNo}?text=Message%20from%20Libsimarkah%20related%20to%20order%20number%3a%20${this.state.order_id}%0a${this.state.messageTextBox}`
      window.open(wp_url, "_blank");
    }
    if (e.target[2].checked) {
      let data = {
        phone: this.state.detailData.user_details[0].phone,
        body: `Message from Libsimarkah related to order number: ${this.state.order_id} ${this.state.messageTextBox}`,
      };
      new Promise((resolve) => {
        resolve(PostApi(API_Path.SendMessageViaSMS, data));
      }).then((res) => {
        if (res.data.success) {
          toastr.success(res.data.message);
        }
      });
    }
    if (e.target[3].checked) {
      let data = {
        to: "jinal.mathukiya@rentechdigital.com",
        subject: `Message from Libsimarkah related to order number: ${this.state.order_id}`,
        html: this.state.messageTextBox,
      };
      new Promise((resolve) => {
        resolve(PostApi(API_Path.SendMessageViaEmail, data));
      }).then((res) => {
        if (res.data.success) {
          toastr.success(res.data.message);
        }
      });
    }
    this.sendmsgmodalclose();
  };

  SaveNote = () => {
    let data = {
      order_id: this.state.order_id,
      note: this.state.notes,
    };
    new Promise((resolve) => {
      resolve(PostApi(API_Path.AddNote, data));
    }).then((res) => {
      if (res.data.success) {
        this.setState({ notes: "" });
        toastr.success(res.data.message);
        this.getNotes(this.state.order_id);
      }
    });
  };

  getNotes = (id) => {
    let data = {
      order_id: id,
    };
    new Promise((resolve) => {
      resolve(PostApi(API_Path.GetOrderNotes, data));
    }).then((res) => {
      if (res) {
        if (res.data.success) {
          this.setState({ DisplayNotes: res.data.data });
        }
      }
    });
  };

  handleDelete = (id) => {
    let data = {
      note_id: id,
    };
    new Promise((resolve) => {
      resolve(PostApi(API_Path.DeleteOrderNotes, data));
    }).then((res) => {
      if (res.data.success) {
        toastr.success(res.data.message);
        this.getNotes(this.state.order_id);
      }
    });
  };

  EditNote = () => {
    let data = {
      note_id: this.state.note_id,
      note: this.state.Editnotes,
    };
    new Promise((resolve) => {
      resolve(PostApi(API_Path.EditOrderNotes, data));
    }).then((res) => {
      if (res.data.success) {
        toastr.success(res.data.message);
        this.getNotes(this.state.order_id);
        this.setState({ Editnotes: "" });
        this.Editaddnotesclose();
      }
    });
  };

  handleRefundChange = (e) => {
    this.setState({ [e.target.name]: e.target.value }, () => {
      if (this.state.refundAmountType === "partial") {
        this.setState({ r_amount: true });
      } else {
        this.setState({ r_amount: false });
      }
    });

    // switch (Value) {
    //   case 'card':

    //     break;
    //   case 'wallet':

    //     break;
    //   case 'bank':

    //     break;
    //   case 'full':

    //     break;
    //   case 'custom':

    //     break;

    //   default:
    //     break;
    // }
  };
  handleRefundinputChange = (e) => {
    let totalReFund =
      this.state.detailData &&
      this.state.detailData.order_payments_refund.reduce(
        (a, b) => (a = a + b.amount),
        0
      );
    let refundAmount = parseFloat(e.target.value);
    let MinimiseValue =
      Number(this.state.detailData.total_placed_price) - totalReFund;
    if (refundAmount > 0 && refundAmount <= MinimiseValue) {
      this.setState({ refund_amount: refundAmount });
    } else {
      this.setState({ refund_amount: "" });
    }
  };

  CreateRefund = () => {
    if (this.state.RefundMode !== "") {
      let totalReFund =
        this.state.detailData &&
        this.state.detailData.order_payments_refund.reduce(
          (a, b) => (a = a + b.amount),
          0
        );
      if (
        this.state.refundAmountType === "partial" &&
        this.state.refund_amount !== ""
      ) {
        let refundData = {
          user_id: this.state.user_id,
          order_id: ["TABBY", "TAMARA"].includes(
            this.state.detailData.pay_method
          )
            ? this.state.order_id.toString()
            : this.state.order_id,
          transaction_type: this.state.RefundMode,
          amount_type: this.state.refundAmountType,
          amount: this.state.refund_amount,
          currency: "SAR",
          reason: "requested_by_customer",
          description: this.state.RefundDescription,
          payment_gateway: ["TABBY", "TAMARA"].includes(
            this.state.detailData.pay_method
          )
            ? this.state.detailData.pay_method
            : "HYPER",
        };
        new Promise((resolve) => {
          resolve(PostApi(API_Path.CreateRefund, refundData));
        }).then((res) => {
          this.getOrderDetailData(this.state.order_id);
          this.refundmodalclose();
        });
      } else if (
        this.state.refundAmountType !== "partial" &&
        (
          Number(this.state.detailData.total_placed_price) - totalReFund
        ).toFixed(2) != 0
      ) {
        let refundData = {
          user_id: this.state.user_id,
          order_id: ["TABBY", "TAMARA"].includes(
            this.state.detailData.pay_method
          )
            ? this.state.order_id.toString()
            : this.state.order_id,
          transaction_type: this.state.RefundMode,
          amount_type: this.state.refundAmountType,
          amount: (
            Number(this.state.detailData.total_placed_price) - totalReFund
          ).toFixed(2),
          currency: "SAR",
          reason: "requested_by_customer",
          description: this.state.RefundDescription,
          payment_gateway: ["TABBY", "TAMARA"].includes(
            this.state.detailData.pay_method
          )
            ? this.state.detailData.pay_method
            : "HYPER",
        };
        new Promise((resolve) => {
          resolve(PostApi(API_Path.CreateRefund, refundData));
        }).then((res) => {
          this.getOrderDetailData(this.state.order_id);
          this.refundmodalclose();
        });
      } else {
        toastr.error("Please Enter Refund Amount");
      }
    } else {
      toastr.error("Please Select TransectionType");
    }
  };
  createRefundOnCancel = () => {
    const refundMode =
        this.state.cancelSource === "1"
          ? "wallet"
          : this.state.detailData.pay_method,
      refundAmountType =
        this.state.order_item.length < this.state.products.length ||
        this.state.order_item.some(
          (item) => item.quantity < item.refundCalculation.quantity
        )
          ? "partial"
          : "full",
      refund_amount =
        refundAmountType === "partial"
          ? this.state.order_item.reduce(
              (acc, item) =>
                (acc += item.quantity * item.refundCalculation.price),
              0
            )
          : this.state.detailData.total_paymentable_price;

    if (refundMode !== "") {
      let totalReFund =
        this.state.detailData &&
        this.state.detailData.order_payments_refund.reduce(
          (a, b) => (a = a + b.amount),
          0
        );
      if (refundAmountType === "partial" && refund_amount !== "") {
        let refundData = {
          user_id: this.state.user_id,
          order_id: ["TABBY", "TAMARA"].includes(refundMode)
            ? this.state.order_id.toString()
            : this.state.order_id,
          transaction_type:
            refundMode === "COD"
              ? "wallet"
              : ["TABBY", "TAMARA"].includes(refundMode)
              ? "card"
              : refundMode,
          amount_type: refundAmountType,
          amount: Number(refund_amount),
          currency: "SAR",
          reason: "requested_by_customer",
          description: `cancellation: ${this.state.order_item[0].reason.replaceAll(
            " ",
            "_"
          )}`,
          payment_gateway: ["TABBY", "TAMARA"].includes(refundMode)
            ? refundMode
            : "HYPER",
        };
        new Promise((resolve) => {
          resolve(PostApi(API_Path.CreateRefund, refundData));
        }).then((res) => {
          this.setState({
            activeSpinnerBtn: false,
            showCancelConfirmModal: false,
          });
          this.getOrderDetailData(this.state.order_id);
          this.refundmodalclose();
        });
      } else if (
        refundAmountType !== "partial" &&
        (
          Number(this.state.detailData.total_placed_price) - totalReFund
        ).toFixed(2) != 0
      ) {
        let refundData = {
          user_id: this.state.user_id,
          order_id: ["TABBY", "TAMARA"].includes(refundMode)
            ? this.state.order_id.toString()
            : this.state.order_id,
          transaction_type:
            refundMode === "COD"
              ? "wallet"
              : ["TABBY", "TAMARA"].includes(refundMode)
              ? "card"
              : refundMode,
          amount_type: refundAmountType,
          amount: (
            Number(this.state.detailData.total_placed_price) - totalReFund
          ).toFixed(2),
          currency: "SAR",
          reason: "requested_by_customer",
          description: `cancellation: ${this.state.order_item[0].reason.replaceAll(
            " ",
            "_"
          )}`,
          payment_gateway: ["TABBY", "TAMARA"].includes(refundMode)
            ? refundMode
            : "HYPER",
        };
        new Promise((resolve) => {
          resolve(PostApi(API_Path.CreateRefund, refundData));
        }).then((res) => {
          this.getOrderDetailData(this.state.order_id);
          this.refundmodalclose();
        });
      } else {
        toastr.error("Please Enter Refund Amount");
      }
    } else {
      toastr.error("Please Select TransectionType");
    }
  };
  handleTrackLink = (e) => {
    this.setState({ coustom_tracking_link: e.target.value });
  };

  handleShowInvoiceModal = () => {
    this.getOrderDetailData(this.state.order_id);
    this.setState({ invoice_show: true });
  };

  handleCloseInvoiceModal = () => {
    this.setState({ invoice_show: false });
  };
  handleQrShow = () => {
    this.setState({ qr_invoice_show: true });
  };
  QRCode = (e) => {
    this.setState({ qr_invoice_number: e.target.value });
  };
  handleSaveQRInvoiceNumber = () => {
    let QRdata = {
      e_invoice_hash: this.state.qr_invoice_number,
      order_id: this.state.order_id,
    };
    new Promise((resolve) => {
      resolve(PostApi(API_Path.UpdateQrCode, QRdata));
    }).then((res) => {
      if (res) {
        this.setState({ QRCode: this.state.qr_invoice_number });
        this.handleCloseQrInvoiceModal();
        this.getOrderDetailData(this.state.order_id);
      }
    });
  };
  handleCloseQrInvoiceModal = () => {
    this.setState({ qr_invoice_show: false });
  };

  //  --- reset the shipping company and tracking details ---
  resetTrackingDetails = () => {
    const url = window.location.href;
    const idString = url?.split("/")[url?.split("/")?.length - 1];

    new Promise((resolve) => {
      resolve(
        PostApi(API_Path.resetShipment, {
          order_id: idString,
          tracking_number: this.state.ShipmentID,
        })
      );
    }).then((res) => {
      if (res.data.success) {
        this.setState({ isShipmentReset: true });
        toastr.success(
          this.context.language === "english"
            ? res.data.message_en
            : res.data.message_ar
        );

        this.getOrderDetailData(idString);
      } else {
        toastr.error(
          this.context.language === "english"
            ? res.data.message_en
            : res.data.message_ar
        );
      }
    });
  };

  handleShippingCompanyChange = (e) => {
    if (e.target.value === "11" && this.state.warehouses.length === 0) {
      this.getWarehouses();
    }
    this.handleChange(e);
  };

  get_city_and_area = () => {
    let city_path = API_Path.getCityData;
    let area_path = API_Path.getArea;
    const getCity = new Promise((resolve) => {
      resolve(PostApi(city_path));
    });
    const getArea = new Promise((resolve) => {
      resolve(PostApi(area_path));
    });
    Promise.all([getCity, getArea]).then((res) => {
      if (res[0] && res[1]) {
        this.setState({ AllCity: res[0].data.data, AllArea: res[1].data.data });
      }
    });
  };

  getAreaByCity = (city_id = "1") => {
    let area_path = API_Path.getArea;

    new Promise((resolve) => {
      resolve(PostApi(area_path, { city_id }));
    }).then((res) => {
      if (res) {
        this.setState({ AllArea: res.data.data });
      }
    });
  };

  handleSelectCancelSource = (e, index) => {
    this.setState({ cancelSource: index });
  };

  handleCancelConfirmModalClose = () => {
    this.setState({ showCancelConfirmModal: false, selectedProducts: [] });
  };

  handleChangeSendNotification = (e) => {
    this.setState({ sendNotificationToCustomer: e.target.checked });
  };

  handleApproveRejectSubmit = () => {
    this.setState({ activeSpinnerBtn: true });

    const { selectedProducts, sendNotificationToCustomer } = this.state;

    const payload = {
      user_id: this.state.user_id,
      sendNotification: sendNotificationToCustomer,
      return_orders: selectedProducts.map(
        ({
          details: { id: product_id },
          id: order_product_id,
          return_order_id,
          return_reason,
          order_id,
        }) => ({
          order_id,
          quantity: 1,
          product_id,
          return_order_id,
          order_product_id,
          reason: return_reason,
        })
      ),
    };

    const path = this.state.isModalTypeApprove
      ? API_Path.approveReturn
      : API_Path.rejectReturn;

    const getDetailDataPromise = new Promise((resolve) => {
      resolve(PostApi(path, payload));
    });
    getDetailDataPromise
      .then(({ data }) => {
        this.setState({ activeSpinnerBtn: false });
        if (data.success) {
          toastr.success(data.message);
          this.handleCancelConfirmModalClose();
          this.getOrderDetailData(this.state.order_id);
          return;
        }
        toastr.error(data.message);
      })
      .catch((err) => {
        toastr.error("Something went wrong");
        console.log(err);
        this.setState({ activeSpinnerBtn: false });
      });

    // console.log(payload);
  };

  handleRestockModalClose = () => {
    this.setState({ showRestockModal: false });
  };

  handleRestockModalSave = () => {
    this.setState({ showRestockModal: false });
    this.getOrderDetailData(this.state.order_id);
  };

  handleReceiveClick = () => {
    this.setState({ showRestockModal: true });
  };

  render() {
    console.log(this.state);

    let Language =
      this.context.language === "english"
        ? TableFieldEnglish
        : TableFieldArabic;
    let titleLanguage =
      this.context.language === "english" ? titleEnglish : titleArabic;
    let ButtonLanguage =
      this.context.language === "english" ? buttonEnglish : buttonArabic;
    let UserLanguage =
      this.context.language === "english" ? UserEnglish : UserArabic;
    let orderLanguage =
      this.context.language === "english" ? orderEnglish : orderArabic;
    let DashboardLanguage =
      this.context.language === "english" ? DashboardEnglish : DashboardArabic;
    let totalReFund =
      this.state.detailData &&
      this.state.detailData.order_payments_refund.reduce(
        (a, b) => (a = a + b.amount),
        0
      );
    const canUpdateShipment =
      this.state.ShipmentID &&
      ((this.state.ShipmentCompany === "10" &&
        this.state.shippingUpdateCode === "AY-0001") ||
        (this.state.ShipmentCompany === "11" &&
          ["101", "201"].includes(this.state.shippingUpdateCode)));

    const enableFieldsOnUpdate = this.state.isUpdateShipment
      ? enableFieldsOnUpdateShipment[this.state.ShipmentCompany]
      : null;

    const statusOptions = [
      { value: 21, label: DashboardLanguage.Pending },
      { value: 22, label: orderLanguage.accepted },
      { value: 23, label: orderLanguage.rejected },
      { value: 24, label: orderLanguage.shipped },
      { value: 25, label: DashboardLanguage.Delivered },
      { value: 26, label: orderLanguage.cancelled },
      { value: 27, label: orderLanguage.approved },
    ];

    // const anyPending = this.state.

    const {
      refundSummary,
      orderStatusValue,
      products: orderedProducts,
      acceptedProducts,
      rejectedProducts,
    } = this.state;

    // const products =
    //   orderStatusValue === STATUS.ACCEPTED ? acceptedProducts : orderedProducts;

    return (
      <Adminlayout>
        {this.state.loading && (
          <div className="loader-main">
            <div className="loader-inr">
              <img src={loader} alt="" />
            </div>
          </div>
        )}
        <div className="order-fix-width-part refund-details-container">
          <div className="container-fluid">
            <div className="row common-space align-items-center">
              <div className="col-5  text-start rtl-txt-start">
                <div className="common-header-txt d-flex">
                  <span
                    onClick={() => {
                      this.props.history.goBack();
                    }}
                    className="cursor-pointer me-2"
                  >
                    <svg
                      width="36"
                      height="37"
                      viewBox="0 0 36 37"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <rect
                        y="0.5"
                        width="36"
                        height="36"
                        rx="5"
                        fill="#EFEFEF"
                      />
                      <path
                        d="M26.1666 18.5H9.83325"
                        stroke="#2D2D3B"
                        stroke-width="2.5"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      />
                      <path
                        d="M17.9999 26.6666L9.83325 18.5L17.9999 10.3333"
                        stroke="#2D2D3B"
                        stroke-width="2.5"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      />
                    </svg>
                  </span>
                  <h3>{orderLanguage.returnRequestDetails}</h3>
                </div>
              </div>
              <div className="col-7  text-end rtl-txt-end">
                <div className="common-red-btn">
                  <a
                    target="_blank"
                    rel="noreferrer"
                    className="btn print-btn me-2"
                    href={`order-details-print/${this.state.order_id}`}
                  >
                    <i class="bi bi-printer me-2"></i>
                    {ButtonLanguage.print}
                  </a>
                  {/* <button className="btn red-btn px-5" onClick={this.handleSave}>
                    {ButtonLanguage.save}
                  </button> */}
                </div>
              </div>
            </div>
            <div className="row common-space">
              <div className="col-xl-8 col-lg-6">
                <div className="white-box h-auto">
                  <div className="row align-items-center border-bottom pb-3">
                    <div className="col-xxl-7 text-xxl-start rtl-text-xxl-start text-center">
                      <div className="common-header-txt order-det-header d-flex text-start align-items-center justify-content-xxl-between">
                        <span className="return-details-txt">
                          {orderLanguage.returnId}:{" "}
                          {this.state.detailData && (
                            <span className="order-detail-num">
                              {this.state.detailData.id}
                            </span>
                          )}
                        </span>
                        <div className=" margin-class">
                          <div className="mt-2 reduce-font">
                            <i className="bi bi-calendar3 text-black me-2" />
                            {this.state.detailData && (
                              <span className="text-secondary fs-6">
                                {moment(this.state.detailData.createdat).format(
                                  "DD-MMM-YYYY, hh:mm A "
                                )}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-xxl-5 mt-3 mt-sm-0 text-sm-end text-center">
                      <div className="d-flex justify-content-end align-items-center">
                        <span className="text-secondary fs-6">
                          {orderLanguage.returnStatus} :
                        </span>
                        {/* <span className="status-product pending">Pending</span> */}
                        <select
                          className="form-select form-contol select-dif-color ms-2 w-auto"
                          style={{ backgroundColor: `#4cad45` }}
                          value={orderStatusValue}
                          onChange={this.handleOrderStatus}
                        >
                          {statusOptions.map(({ value, label }) => (
                            <option key={value} value={value}>
                              {label}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>
                  <div className="row common-space">
                    <div className="col-12">
                      <div className="row">
                        {/* if accepted items, then show accepted items else show pending items */}
                        <div className="col-md-12">
                          <div className="custom-border">
                            {orderedProducts.length > 0 && (
                              <ReturnProductList
                                products={orderedProducts}
                                detailData={this.state.detailData}
                                selectedProducts={this.state.selectedProducts}
                                orderStatusValue={orderStatusValue}
                                onSelectAllClick={this.handleSelectAllClick}
                                onProductSelect={
                                  this.handleProductSelectForReturn
                                }
                              />
                            )}
                            {[STATUS.PENDING, STATUS.DELIVERED].includes(
                              orderStatusValue
                            ) && (
                              <div className="row mx-0 my-3">
                                <div className="col-12">
                                  <div className="row mx-0 my-4 modal-form ">
                                    <div className="d-flex gap-4 justify-content-end">
                                      {orderedProducts.length > 0 &&
                                        orderStatusValue === STATUS.PENDING && (
                                          <>
                                            <button
                                              className="w-80 dark-btn"
                                              onClick={() =>
                                                this.handleItemReturnApprove(
                                                  false
                                                )
                                              }
                                            >
                                              {orderLanguage.Reject}
                                            </button>
                                            <button
                                              onClick={() =>
                                                this.handleItemReturnApprove(
                                                  true
                                                )
                                              }
                                              className="red-btn w-80"
                                            >
                                              <span name="return">
                                                {orderLanguage.Approve}
                                              </span>
                                            </button>
                                          </>
                                        )}
                                      {acceptedProducts.length > 0 &&
                                        orderStatusValue ===
                                          STATUS.DELIVERED && !this.state.detailData.restock && (
                                          <>
                                            <button
                                              onClick={this.handleReceiveClick}
                                              className="red-btn w-80"
                                            >
                                              <span>
                                                {orderLanguage.Receive}
                                              </span>
                                            </button>
                                          </>
                                        )}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="col-md-12">
                          <div className="diff-bg-box mt-3">
                            {/* {this.state.detailData &&
                              (this.state.detailData.coupon_discount !== 0 ||
                                this.state.detailData.wallet_cost !== 0) && (
                                <ul>
                                  {this.state.detailData.discount_type ===
                                  "fixed" ? (
                                    <li>
                                      <div className="fix-coupen-class d-flex align-items-center">
                                        <svg
                                          width="15"
                                          height="15"
                                          viewBox="0 0 15 13"
                                          className="me-2"
                                          fill="none"
                                          xmlns="http://www.w3.org/2000/svg"
                                        >
                                          <path
                                            d="M6.59289 1.70776L1.51422 10.1862C1.40951 10.3675 1.35411 10.5731 1.35352 10.7825C1.35293 10.9919 1.40719 11.1978 1.51088 11.3797C1.61457 11.5617 1.76409 11.7132 1.94456 11.8194C2.12504 11.9256 2.33017 11.9827 2.53955 11.985H12.6969C12.9063 11.9827 13.1114 11.9256 13.2919 11.8194C13.4723 11.7132 13.6219 11.5617 13.7256 11.3797C13.8293 11.1978 13.8835 10.9919 13.8829 10.7825C13.8823 10.5731 13.8269 10.3675 13.7222 10.1862L8.64355 1.70776C8.53666 1.53154 8.38615 1.38584 8.20655 1.28473C8.02696 1.18361 7.82433 1.13049 7.61822 1.13049C7.41212 1.13049 7.20949 1.18361 7.02989 1.28473C6.85029 1.38584 6.69979 1.53154 6.59289 1.70776V1.70776Z"
                                            stroke="#A81A1C"
                                            stroke-width="1.5"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                          />
                                          <path
                                            d="M7.61816 4.78973V7.18816"
                                            stroke="#A81A1C"
                                            stroke-width="1.5"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                          />
                                          <path
                                            d="M7.61816 9.58661H7.62499"
                                            stroke="#A81A1C"
                                            stroke-width="1.5"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                          />
                                        </svg>
                                        {orderLanguage.FixedCouponused}
                                      </div>
                                    </li>
                                  ) : this.state.detailData.discount_type ===
                                    "percentage" ? (
                                    <li>
                                      <div className="per-coupen-class d-flex align-items-center">
                                        <svg
                                          width="15"
                                          height="13"
                                          viewBox="0 0 15 13"
                                          className="me-2"
                                          fill="none"
                                          xmlns="http://www.w3.org/2000/svg"
                                        >
                                          <path
                                            d="M6.59289 1.57727L1.51422 10.0557C1.40951 10.237 1.35411 10.4426 1.35352 10.652C1.35293 10.8614 1.40719 11.0673 1.51088 11.2492C1.61457 11.4312 1.76409 11.5828 1.94456 11.6889C2.12504 11.7951 2.33017 11.8522 2.53955 11.8545H12.6969C12.9063 11.8522 13.1114 11.7951 13.2919 11.6889C13.4723 11.5828 13.6219 11.4312 13.7256 11.2492C13.8293 11.0673 13.8835 10.8614 13.8829 10.652C13.8823 10.4426 13.8269 10.237 13.7222 10.0557L8.64355 1.57727C8.53666 1.40105 8.38615 1.25535 8.20655 1.15424C8.02696 1.05312 7.82433 1 7.61822 1C7.41212 1 7.20949 1.05312 7.02989 1.15424C6.85029 1.25535 6.69979 1.40105 6.59289 1.57727V1.57727Z"
                                            stroke="#675621"
                                            stroke-width="1.5"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                          />
                                          <path
                                            d="M7.61816 4.65924V7.05767"
                                            stroke="#675621"
                                            stroke-width="1.5"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                          />
                                          <path
                                            d="M7.61816 9.45612H7.62499"
                                            stroke="#675621"
                                            stroke-width="1.5"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                          />
                                        </svg>
                                        % {orderLanguage.Couponused}
                                      </div>
                                    </li>
                                  ) : (
                                    ""
                                  )}
                                  {this.state.detailData.wallet_cost !==
                                    0 && (
                                    <li>
                                      <div className="wallet-coupen-class d-flex align-items-center">
                                        <svg
                                          width="14"
                                          height="14"
                                          viewBox="0 0 14 14"
                                          className="me-2"
                                          fill="none"
                                          xmlns="http://www.w3.org/2000/svg"
                                        >
                                          <path
                                            d="M7.19993 6.01412C7.02271 6.01412 6.85274 6.08452 6.72742 6.20984C6.6021 6.33516 6.5317 6.50512 6.5317 6.68235V9.35529C6.5317 9.53252 6.6021 9.70249 6.72742 9.82781C6.85274 9.95312 7.02271 10.0235 7.19993 10.0235C7.37716 10.0235 7.54713 9.95312 7.67245 9.82781C7.79776 9.70249 7.86817 9.53252 7.86817 9.35529V6.68235C7.86817 6.50512 7.79776 6.33516 7.67245 6.20984C7.54713 6.08452 7.37716 6.01412 7.19993 6.01412ZM7.45386 3.39463C7.29117 3.3278 7.10869 3.3278 6.946 3.39463C6.86398 3.42644 6.78904 3.47413 6.72549 3.53496C6.66646 3.59992 6.619 3.6745 6.58516 3.75548C6.54775 3.83479 6.52944 3.92175 6.5317 4.00941C6.53119 4.09735 6.54805 4.18453 6.5813 4.26595C6.61455 4.34737 6.66355 4.42142 6.72549 4.48386C6.79044 4.54288 6.86502 4.59035 6.946 4.62419C7.04724 4.66578 7.15714 4.68187 7.26605 4.67104C7.37496 4.66021 7.47955 4.6228 7.57061 4.56209C7.66168 4.50138 7.73644 4.41923 7.78832 4.32286C7.8402 4.22649 7.86762 4.11886 7.86817 4.00941C7.86571 3.83248 7.79649 3.66302 7.67438 3.53496C7.61083 3.47413 7.53589 3.42644 7.45386 3.39463ZM7.19993 0C5.87829 0 4.58632 0.391913 3.48742 1.12618C2.38851 1.86045 1.53202 2.90409 1.02624 4.12513C0.520473 5.34617 0.388141 6.68976 0.645981 7.98601C0.903821 9.28226 1.54025 10.4729 2.4748 11.4075C3.40934 12.342 4.60002 12.9785 5.89627 13.2363C7.19252 13.4941 8.53612 13.3618 9.75716 12.856C10.9782 12.3503 12.0218 11.4938 12.7561 10.3949C13.4904 9.29596 13.8823 8.00399 13.8823 6.68235C13.8823 5.80481 13.7094 4.93587 13.3736 4.12513C13.0378 3.31439 12.5456 2.57773 11.9251 1.95722C11.3046 1.3367 10.5679 0.844483 9.75716 0.508664C8.94642 0.172844 8.07747 0 7.19993 0ZM7.19993 12.0282C6.14262 12.0282 5.10905 11.7147 4.22992 11.1273C3.35079 10.5399 2.6656 9.70496 2.26098 8.72813C1.85637 7.7513 1.7505 6.67642 1.95677 5.63942C2.16304 4.60242 2.67219 3.64988 3.41982 2.90224C4.16746 2.15461 5.12 1.64546 6.157 1.43919C7.194 1.23292 8.26888 1.33878 9.24571 1.7434C10.2225 2.14802 11.0575 2.83321 11.6449 3.71234C12.2323 4.59146 12.5458 5.62504 12.5458 6.68235C12.5458 8.10017 11.9826 9.45991 10.98 10.4625C9.97749 11.465 8.61775 12.0282 7.19993 12.0282Z"
                                            fill="#3F79AA"
                                          />
                                        </svg>
                                        {orderLanguage.Walletbalanceused}
                                      </div>
                                    </li>
                                  )}
                                </ul>
                              )} */}
                            <div className="row">
                              <div className="col-md-12">
                                <p className="refund-strong-txt">
                                  Refund Pending
                                </p>
                              </div>
                            </div>
                            <div className="row">
                              <div className="col-md-3">
                                <p>Return items</p>
                              </div>
                              <div className="col-md-6">
                                <p>{refundSummary.itemCount} item(s)</p>
                              </div>
                              <div className="col-md-3">
                                <p className="text-right fw-500">
                                  SR {refundSummary.subTotal}
                                </p>
                              </div>
                            </div>
                            <div className="row">
                              <div className="col-md-3">
                                <p>Return Items VAT</p>
                              </div>
                              <div className="col-md-6">
                                <p>{refundSummary.vatPercentage}% (Included)</p>
                              </div>
                              <div className="col-md-3">
                                <p className="text-right fw-500">
                                  SR {refundSummary.vatValue}
                                </p>
                              </div>
                            </div>
                            <div className="row">
                              <div className="col-md-3">
                                <p>Cost of Return</p>
                              </div>
                              <div className="col-md-6">
                                <p>
                                  {refundSummary.costOfReturn > 0
                                    ? refundSummary.costOfReturn
                                    : "Nil"}
                                </p>
                              </div>
                              <div className="col-md-3">
                                <p className="text-right">
                                  {refundSummary.costOfReturn}
                                </p>
                              </div>
                            </div>
                            <div className="row">
                              <div className="col-md-3">
                                <p className="refund-strong-txt">
                                  Total Refund :
                                </p>
                              </div>
                              <div className="col-md-6">
                                {this.state.detailData?.order_payments_refund
                                  ?.length > 0 && (
                                  <table className="default-styles total-refund-type-container">
                                    <tbody>
                                      <tr>
                                        <td width={165}>Refund to Card:</td>
                                        <td>SAR 250.00</td>
                                      </tr>
                                      <tr>
                                        <td>Refund to My wallet:</td>
                                        <td>SAR 100.00</td>
                                      </tr>
                                    </tbody>
                                  </table>
                                )}
                              </div>
                              <div className="col-md-3 red-txt ">
                                <p className="text-right fw-600">
                                  SR {refundSummary.total}
                                </p>
                              </div>
                            </div>
                            {/* {this.state.detailData && (
                              <div className="table-footer-pricing text-end ms-auto">
                                <ul>
                                  <li>
                                    <span>{orderLanguage.SubTotal} :</span>
                                    <bdi>
                                      {Language.SR}{" "}
                                      {this.state.detailData
                                        .final_ordered_price > 0
                                        ? this.state.detailData.final_ordered_price?.toFixed(
                                            2
                                          )
                                        : 0}
                                    </bdi>
                                  </li>

                                  {this.state.detailData
                                    .coupon_discount !== 0 &&
                                    this.state.detailData
                                      .coupon_discount !== null && (
                                      <li>
                                        <span>
                                          {orderLanguage.voucher}:{" "}
                                          {
                                            this.state.detailData
                                              .coupon_code
                                          }{" "}
                                          (
                                          {
                                            this.state.detailData
                                              .discount_value
                                          }
                                          {this.state.detailData
                                            .discount_type === "fixed"
                                            ? " SR"
                                            : "%"}
                                          ):
                                        </span>
                                        <bdi>
                                          {Language.SR} -
                                          {this.state.detailData.coupon_discount?.toFixed(
                                            2
                                          )}
                                        </bdi>
                                      </li>
                                    )}
                                  {this.state.detailData
                                    .orderPrice_includeCoupon > 0 && (
                                    <li className="total-price">
                                      <span>
                                        {this.state.detailData.orderPrice_includeCoupon?.toFixed(
                                          2
                                        )}
                                      </span>
                                    </li>
                                  )}

                                  {this.state.detailData
                                    .shipping_cost !== 0 &&
                                    this.state.detailData
                                      .shipping_cost !== null && (
                                      <li>
                                        <span>
                                          {orderLanguage.shippingCharges} :
                                        </span>
                                        <bdi>
                                          {Language.SR}{" "}
                                          {this.state.detailData.shipping_cost?.toFixed(
                                            2
                                          )}
                                        </bdi>
                                      </li>
                                    )}

                                  {this.state.detailData
                                    .plateform_cost !== 0 &&
                                    this.state.detailData
                                      .plateform_cost !== null && (
                                      <li>
                                        <span>Plateform Cost :</span>
                                        <bdi>
                                          {Language.SR}{" "}
                                          {this.state.detailData.plateform_cost?.toFixed(
                                            2
                                          )}
                                        </bdi>
                                      </li>
                                    )}
                                  {this.state.detailData.COD_cost !==
                                    0 &&
                                    this.state.detailData.COD_cost !==
                                      null && (
                                      <li>
                                        <span>
                                          {orderLanguage.CODCharge} :
                                        </span>
                                        <bdi>
                                          {Language.SR}{" "}
                                          {this.state.detailData.COD_cost?.toFixed(
                                            2
                                          )}
                                        </bdi>
                                      </li>
                                    )}

                                  {this.state.detailData.wallet_cost !==
                                    0 &&
                                    this.state.detailData.wallet_cost !==
                                      null && (
                                      <>
                                        <li className="total-price">
                                          <bdi>
                                            {Language.SR}{" "}
                                            {Number(
                                              this.state.detailData
                                                .COD_cost +
                                                this.state.detailData
                                                  .shipping_cost -
                                                this.state.detailData
                                                  .coupon_discount +
                                                this.state.detailData
                                                  .final_ordered_price
                                            ).toFixed(2)}
                                          </bdi>
                                        </li>
                                        <li>
                                          <span>
                                            {orderLanguage.WalletUsed} :
                                          </span>
                                          <bdi>
                                            {Language.SR} -
                                            {this.state.detailData.wallet_cost.toFixed(
                                              2
                                            )}
                                          </bdi>
                                        </li>
                                      </>
                                    )}

                                  <li className="total-price">
                                    <span>
                                      {orderLanguage.GrandTotal} :
                                    </span>
                                    <bdi>
                                      {Language.SR}{" "}
                                      {(this.state.detailData
                                        .total_paymentable_price >= 0 ||
                                        this.state.detailData
                                          .pay_method == "WALLET") &&
                                        this.state.detailData.total_paymentable_price?.toFixed(
                                          2
                                        )}
                                    </bdi>
                                  </li>
                                </ul>
                              </div>
                            )} */}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {acceptedProducts.length > 0 && (
                    <>
                      <div className="row common-space">
                        <div className="col-12 dark-red-txt mb-2 fs-6 fw-500 ps-3">
                          Accepted Items
                        </div>
                        <div className="col-md-12">
                          <div className="custom-border table-bottom-border-none">
                            <ReturnProductList
                              products={acceptedProducts}
                              detailData={this.state.detailData}
                              // selectedProducts={this.state.selectedProducts}
                              orderStatusValue={orderStatusValue}
                              // onSelectAllClick={this.handleSelectAllClick}
                              // onProductSelect={
                              //   this.handleProductSelectForReturn
                              // }
                            />
                          </div>
                        </div>
                      </div>
                    </>
                  )}
                  {rejectedProducts.length > 0 && (
                    <>
                      <div className="row common-space">
                        <div className="col-12 dark-red-txt mb-2 fs-6 fw-500 ps-3">
                          Rejected Items
                        </div>
                        <div className="col-md-12">
                          <div className="custom-border table-bottom-border-none">
                            <ReturnProductList
                              products={rejectedProducts}
                              detailData={this.state.detailData}
                              // selectedProducts={this.state.selectedProducts}
                              orderStatusValue={orderStatusValue}
                              // onSelectAllClick={this.handleSelectAllClick}
                              // onProductSelect={this.handleProductSelectForReturn}
                            />
                          </div>
                        </div>
                      </div>
                    </>
                  )}
                </div>
                <div className="mt-3 ">
                  <a href="orderactivitylog" className="order-details-txt">
                    {orderLanguage.OrderActivityLogs}
                  </a>
                </div>
              </div>
              <div className="col-xl-4 col-lg-6 mt-md-0 mt-3 p-0">
                <div className="order-detail-rgt-main">
                  <Accordion flush>
                    <Accordion.Item>
                      <Accordion.Header>
                        <div className="order-head-txt">
                          <span>{orderLanguage.billingDetails}</span>
                        </div>
                      </Accordion.Header>
                      <Accordion.Body>
                        <div className="table-responsive">
                          <table className="order-table w-100">
                            {this.state.detailData && (
                              <tbody>
                                <tr>
                                  <td>{orderLanguage.customerName}</td>
                                  <td>
                                    <a
                                      href={`user-details/${this.state.detailData?.user_id}`}
                                      className="red-txt"
                                    >
                                      {this.state.detailData?.user_details
                                        .length > 0 &&
                                        this.state.detailData.user_details[0]
                                          .first_name}
                                    </a>
                                  </td>
                                </tr>
                                <tr>
                                  <td>{orderLanguage.Email}</td>
                                  <td>
                                    {this.state.detailData?.user_details
                                      .length > 0 &&
                                      this.state.detailData.user_details[0]
                                        .email}
                                  </td>
                                </tr>
                                <tr>
                                  <td>{orderLanguage.phoneNumber}</td>
                                  <td>
                                    <img
                                      src={Verified}
                                      alt=""
                                      className="me-2"
                                    />
                                    {/* <img src={ErrorImg} alt="" className="me-2"/> */}
                                    {this.state.detailData.user_details.length >
                                      0 &&
                                      this.state.detailData.user_details[0]
                                        .phone}
                                  </td>
                                </tr>
                                <tr>
                                  <td>
                                    {/* <span className="text-decoration-none">{orderLanguage.order}</span> */}
                                    {orderLanguage.orderHistory}
                                  </td>
                                  <td>
                                    <a
                                      href={
                                        "orders?" +
                                        this.state.detailData.user_details[0]
                                          .phone
                                      }
                                      className="red-txt"
                                    >
                                      {this.state.detailData?.total_order
                                        .length > 0 &&
                                        this.state.detailData.total_order[0]
                                          .order_count}{" "}
                                      {orderLanguage.orders}
                                    </a>
                                  </td>
                                </tr>
                                <tr>
                                  <td className="text-start">
                                    <span
                                      className="red-txt text-decoration-none cursor-pointer"
                                      onClick={this.sendmsgmodal}
                                    >
                                      {orderLanguage.SendMessage}
                                    </span>
                                  </td>
                                  {/* <td>
                                    <button className="btn gray-red-txt-btn">
                                      {orderLanguage.DownloadInvoice}
                                    </button>
                                  </td> */}
                                </tr>
                              </tbody>
                            )}
                          </table>
                        </div>
                      </Accordion.Body>
                    </Accordion.Item>
                  </Accordion>
                  <Accordion flush>
                    <Accordion.Item>
                      <Accordion.Header>
                        <div className="order-head-txt">
                          <span>{orderLanguage.PaymentDetails}</span>
                        </div>
                      </Accordion.Header>
                      <Accordion.Body>
                        <div className="table-responsive">
                          <table className="order-table w-100">
                            {this.state.detailData && (
                              <tbody>
                                <tr>
                                  <td>{orderLanguage.paymentMethod}</td>
                                  <td>
                                    {/* <img src={madaicon} className="me-2" /> */}
                                    {this.context.language === "english" &&
                                      (this.state.detailData.pay_method ===
                                      "COD"
                                        ? "COD"
                                        : this.state.detailData.pay_method ===
                                          "cardPayment"
                                        ? "Card Payment"
                                        : this.state.detailData.pay_method ===
                                          "APPLEPAY"
                                        ? "Apple Pay"
                                        : this.state.detailData.pay_method ===
                                          "TABBY"
                                        ? "TABBY"
                                        : this.state.detailData.pay_method ===
                                          "TAMARA"
                                        ? "TAMARA"
                                        : "Full Wallet")}
                                    {this.context.language !== "english" &&
                                      (this.state.detailData.pay_method ===
                                      "COD"
                                        ? "الدفع عند الإستلام"
                                        : this.state.detailData.pay_method ===
                                          "cardPayment"
                                        ? "بطاقة ائتمان"
                                        : this.state.detailData.pay_method ===
                                          "APPLEPAY"
                                        ? "أبل باي"
                                        : this.state.detailData.pay_method ===
                                          "TABBY"
                                        ? "تابي"
                                        : this.state.detailData.pay_method ===
                                          "TAMARA"
                                        ? "تمارا"
                                        : "محفظة كاملة")}
                                  </td>
                                </tr>

                                <tr>
                                  <td>{orderLanguage.RefundAmount}</td>
                                  <td>
                                    <button
                                      className="btn gray-red-txt-btn red-txt"
                                      onClick={this.refundmodal}
                                    >
                                      {orderLanguage.RefundToWallet}
                                    </button>
                                  </td>
                                </tr>
                              </tbody>
                            )}
                          </table>
                        </div>
                        {/* <div className="payment-notes-main">
                          <ul>
                            {this.state.detailData &&
                              this.state.detailData.order_payments_refund.map(
                                (item) => {
                                  return (
                                    <li>
                                      <div className="d-flex payment-detail-note border-top-class py-2">
                                        <div>
                                          <span>{`SR.${
                                            item.amount
                                          } refunded to customer ${
                                            item.transaction_type == "wallet"
                                              ? "Wallet"
                                              : item.transaction_type == "card"
                                              ? "card refund"
                                              : "bank account"
                                          }`}</span>
                                          <span className="note-class">
                                            Note: {item.description}
                                          </span>
                                        </div>
                                        <div className="ms-auto">
                                          <bdi>
                                            {moment(item.createdat).format(
                                              "DD-MMM-YYYY hh:mm A"
                                            )}{" "}
                                          </bdi>
                                        </div>
                                      </div>
                                    </li>
                                  );
                                }
                              )}
                          </ul>
                        </div> */}
                        {/* <div className="border-top-class d-flex amount-refund-class pt-3">
                          <span>{orderLanguage.Amountafterrefund}</span>
                          {this.state.detailData && (
                            <bdi className="ms-auto red-txt fw-bold">
                              {(
                                this.state.detailData.total_placed_price.toFixed(
                                  2
                                ) - totalReFund
                              ).toFixed(2)}
                            </bdi>
                          )}
                        </div> */}
                      </Accordion.Body>
                    </Accordion.Item>
                  </Accordion>
                  {/* --- Tabby installments --- */}
                  {/* {this.state.installments.length > 0 && (
                    <Accordion flush>
                      <Accordion.Item>
                        <Accordion.Header>
                          <div className="order-head-txt d-flex align-items-center">
                            <span>{orderLanguage.InstallmentDetails}</span>
                          </div>
                        </Accordion.Header>
                        <Accordion.Body>
                          <div className="d-flex gap-3 text-center">
                            {this.state.installments.map(
                              ({ amount, due_date }, i) => (
                                <div
                                  key={due_date}
                                  className="py-2 px-3 flex-fill"
                                  style={{
                                    border: "1px solid rgb(212, 212, 212)",
                                    borderRadius: 4,
                                  }}
                                >
                                  <img
                                    src={graphIcons[`graph${25 * (i + 1)}`]}
                                    width={20}
                                    height={20}
                                    alt="installment-icon"
                                  />
                                  <div>
                                    <p
                                      className="m-0 mt-1"
                                      style={{
                                        fontSize: 12,
                                        fontWeight: "bold",
                                      }}
                                    >
                                      {amount}
                                    </p>
                                    <p className="m-0" style={{ fontSize: 12 }}>
                                      {due_date}
                                    </p>
                                  </div>
                                </div>
                              )
                            )}
                          </div>
                        </Accordion.Body>
                      </Accordion.Item>
                    </Accordion>
                  )} */}
                  <Accordion flush>
                    <Accordion.Item>
                      <Accordion.Header>
                        <div className="order-head-txt d-flex align-items-center">
                          <span>{orderLanguage.AddressDetails}</span>
                          {/* <a href="#" className="ms-auto red-underline-txt mb-3">Edit</a> */}
                        </div>
                      </Accordion.Header>
                      <Accordion.Body>
                        <div className="table-responsive">
                          <table className="order-table w-100">
                            {this.state.detailData && (
                              <tbody>
                                <tr>
                                  <td>{orderLanguage.phoneNumber}</td>
                                  <td>
                                    {this.state.detailData.address.phone?.substring(
                                      0,
                                      3
                                    ) !== "966"
                                      ? this.state.detailData.address.phone
                                      : this.state.detailData.address.phone.substring(
                                          3
                                        )}
                                    <OverlayTrigger
                                      placement={"bottom"}
                                      delay={{ show: 250, hide: 400 }}
                                      overlay={
                                        <Tooltip>copy phone number</Tooltip>
                                      }
                                    >
                                      <CopyToClipboard
                                        text={
                                          this.state.detailData?.address?.phone
                                        }
                                        onCopy={() => toastr.success("Copied.")}
                                      >
                                        <svg
                                          className="ms-2  cursor-pointer"
                                          width={20}
                                          height={20}
                                          viewBox="0 0 18 18"
                                          fill="none"
                                          xmlns="http://www.w3.org/2000/svg"
                                        >
                                          <path
                                            d="M10.6665 17.3333H2.33317C1.88656 17.3488 1.45356 17.1782 1.13757 16.8622C0.821587 16.5462 0.650981 16.1132 0.666501 15.6666V7.33329C0.650981 6.88669 0.821587
                                            6.45369 1.13757 6.1377C1.45356 5.82171 1.88656 5.6511 2.33317 5.66662H5.6665V2.33329C5.65098 1.88669 5.82159 1.45368
                                            6.13758 1.1377C6.45356 0.821709 6.88656 0.651103 7.33317 0.666623H15.6665C16.1131 0.651103 16.5461 0.821709
                                            16.8621 1.1377C17.1781 1.45368 17.3487 1.88669 17.3332 2.33329V10.6666C17.3484 11.1132 17.1778 11.546 16.8618
                                            11.8619C16.5459 12.1779 16.113 12.3486 15.6665 12.3333H12.3332V15.6666C12.3484 16.1132 12.1778
                                            16.546 11.8618 16.8619C11.5459 17.1779 11.113 17.3486 10.6665 17.3333ZM2.33317
                                            7.33329V15.6666H10.6665V12.3333H7.33317C6.88663 12.3486 6.45378 12.1779 6.13785 11.8619C5.82192
                                            11.546 5.65123 11.1132 5.6665 10.6666V7.33329H2.33317ZM7.33317 2.33329V10.6666H15.6665V2.33329H7.33317Z"
                                            fill="#2D2D3B"
                                          />
                                        </svg>
                                      </CopyToClipboard>
                                    </OverlayTrigger>
                                  </td>
                                </tr>
                                <tr>
                                  <td>{orderLanguage.cityArea}</td>
                                  <td>
                                    {this.state.detailData.address.city_en}-{" "}
                                    {this.state.detailData.address.area_en}
                                  </td>
                                </tr>
                                <tr>
                                  <td>{orderLanguage.fromAddress}</td>
                                  <td>
                                    {this.state.detailData.address.line_1 +
                                      this.state.detailData.address.line_2}
                                    <OverlayTrigger
                                      placement={"bottom"}
                                      delay={{ show: 250, hide: 400 }}
                                      overlay={<Tooltip>Copy address</Tooltip>}
                                    >
                                      <CopyToClipboard
                                        text={
                                          this.state.detailData.address.line_1 +
                                          this.state.detailData.address.line_2
                                        }
                                        onCopy={() => toastr.success("Copied.")}
                                      >
                                        <svg
                                          className="ms-2 cursor-pointer"
                                          width={20}
                                          height={20}
                                          viewBox="0 0 18 18"
                                          fill="none"
                                          xmlns="http://www.w3.org/2000/svg"
                                        >
                                          <path
                                            d="M10.6665 17.3333H2.33317C1.88656 17.3488 1.45356 17.1782 1.13757 16.8622C0.821587 16.5462 0.650981 16.1132 0.666501 15.6666V7.33329C0.650981 6.88669 0.821587
                                            6.45369 1.13757 6.1377C1.45356 5.82171 1.88656 5.6511 2.33317 5.66662H5.6665V2.33329C5.65098 1.88669 5.82159 1.45368
                                            6.13758 1.1377C6.45356 0.821709 6.88656 0.651103 7.33317 0.666623H15.6665C16.1131 0.651103 16.5461 0.821709
                                            16.8621 1.1377C17.1781 1.45368 17.3487 1.88669 17.3332 2.33329V10.6666C17.3484 11.1132 17.1778 11.546 16.8618
                                            11.8619C16.5459 12.1779 16.113 12.3486 15.6665 12.3333H12.3332V15.6666C12.3484 16.1132 12.1778
                                            16.546 11.8618 16.8619C11.5459 17.1779 11.113 17.3486 10.6665 17.3333ZM2.33317
                                            7.33329V15.6666H10.6665V12.3333H7.33317C6.88663 12.3486 6.45378 12.1779 6.13785 11.8619C5.82192
                                            11.546 5.65123 11.1132 5.6665 10.6666V7.33329H2.33317ZM7.33317 2.33329V10.6666H15.6665V2.33329H7.33317Z"
                                            fill="#2D2D3B"
                                          />
                                        </svg>
                                      </CopyToClipboard>
                                    </OverlayTrigger>
                                  </td>
                                </tr>
                              </tbody>
                            )}
                          </table>
                        </div>
                        <div className="order-head-txt d-flex align-items-center border-top py-3">
                          <span>{orderLanguage.TrackingDetails}</span>
                        </div>
                        <div className="table-responsive">
                          <div className="">
                            <div className="form-group modal-form">
                              <div className="d-flex align-items-center mb-1">
                                <label className="m-0">
                                  {orderLanguage.shippingCompany}
                                </label>
                                {canUpdateShipment && (
                                  <div className="ms-auto">
                                    <button
                                      className="btn dark-red-txt "
                                      onClick={this.resetTrackingDetails}
                                    >
                                      {orderLanguage.reset}
                                    </button>
                                  </div>
                                )}
                              </div>
                              <select
                                className="form-control form-select"
                                value={this.state.ShipmentCompany}
                                onChange={this.handleShippingOption}
                                disabled={this.state.ShipmentCompany === "11"}
                              >
                                {this.state.shippingCompanyData?.map((item) => {
                                  return (
                                    <option key={item.id} value={item.id}>
                                      {this.context.language === "english"
                                        ? item.english
                                        : item.arabic}
                                    </option>
                                  );
                                })}
                              </select>
                            </div>
                          </div>

                          {!this.state.isPickupStore && (
                            <>
                              {/* --- Tracking number --- */}
                              <div className="">
                                <div
                                  className="form-group modal-form"
                                  onChange={this.handleTrackChange}
                                >
                                  <div className="d-flex tracking-modal">
                                    <label>
                                      {orderLanguage.TrackingNumber}
                                    </label>
                                    <span className="ms-auto">
                                      {(this.state.shippingUpdateCode &&
                                        this.state.shippingDescription) !==
                                        "" && (
                                        <span className="text-end">
                                          <bdi className="dark-red-txt me-2">
                                            {this.state.shippingUpdateCode}
                                          </bdi>
                                          {this.state.shippingDescription}
                                        </span>
                                      )}
                                    </span>
                                  </div>
                                  <div className="d-flex ">
                                    <div className="input-group">
                                      {this.state.ShipmentCompany !== "9" && (
                                        <>
                                          <input
                                            type="text"
                                            name="tracking_number"
                                            value={this.state.ShipmentID}
                                            className="form-control"
                                            aria-label="Recipient's username"
                                            aria-describedby="basic-addon2"
                                            readOnly
                                          />
                                          <div className="input-group-append">
                                            <span
                                              className="input-group-text"
                                              id="basic-addon2"
                                            >
                                              <OverlayTrigger
                                                placement={"bottom"}
                                                delay={{ show: 250, hide: 400 }}
                                                overlay={
                                                  <Tooltip>
                                                    copy tracking number
                                                  </Tooltip>
                                                }
                                              >
                                                <CopyToClipboard
                                                  text={this.state.ShipmentID}
                                                  onCopy={() =>
                                                    this.state.ShipmentID
                                                      ? toastr.success(
                                                          "Copied."
                                                        )
                                                      : null
                                                  }
                                                >
                                                  <button
                                                    className="btn btn-text d-flex p-0 border-0"
                                                    disabled={
                                                      !this.state.ShipmentID
                                                    }
                                                  >
                                                    <svg
                                                      className="me-2"
                                                      width={20}
                                                      height={20}
                                                      viewBox="0 0 18 18"
                                                      fill="none"
                                                      xmlns="http://www.w3.org/2000/svg"
                                                    >
                                                      <path
                                                        d="M10.6665 17.3333H2.33317C1.88656 17.3488 1.45356 17.1782 1.13757 16.8622C0.821587 16.5462 0.650981 16.1132 0.666501 15.6666V7.33329C0.650981 6.88669 0.821587
                                                        6.45369 1.13757 6.1377C1.45356 5.82171 1.88656 5.6511 2.33317 5.66662H5.6665V2.33329C5.65098 1.88669 5.82159 1.45368
                                                        6.13758 1.1377C6.45356 0.821709 6.88656 0.651103 7.33317 0.666623H15.6665C16.1131 0.651103 16.5461 0.821709
                                                        16.8621 1.1377C17.1781 1.45368 17.3487 1.88669 17.3332 2.33329V10.6666C17.3484 11.1132 17.1778 11.546 16.8618
                                                        11.8619C16.5459 12.1779 16.113 12.3486 15.6665 12.3333H12.3332V15.6666C12.3484 16.1132 12.1778
                                                        16.546 11.8618 16.8619C11.5459 17.1779 11.113 17.3486 10.6665 17.3333ZM2.33317
                                                        7.33329V15.6666H10.6665V12.3333H7.33317C6.88663 12.3486 6.45378 12.1779 6.13785 11.8619C5.82192
                                                        11.546 5.65123 11.1132 5.6665 10.6666V7.33329H2.33317ZM7.33317
                                                        2.33329V10.6666H15.6665V2.33329H7.33317Z"
                                                        fill="#2D2D3B"
                                                      />
                                                    </svg>
                                                  </button>
                                                </CopyToClipboard>
                                              </OverlayTrigger>
                                              {/* <svg xmlns="http://www.w3.org/2000/svg" width={25} height={25} fill="currentColor" className="bi bi-link-45deg ms-2" viewBox="0 0 18 18">
                                              <path d="M4.715 6.542 3.343 7.914a3 3 0 1 0 4.243 4.243l1.828-1.829A3 3 0 0 0 8.586 5.5L8 6.086a1.002 1.002 0 0 0-.154.199 2 2 0 0 1 .861 3.337L6.88 11.45a2 2 0 1 1-2.83-2.83l.793-.792a4.018 4.018 0 0 1-.128-1.287z" />
                                              <path d="M6.586 4.672A3 3 0 0 0 7.414 9.5l.775-.776a2 2 0 0 1-.896-3.346L9.12 3.55a2 2 0 1 1 2.83 2.83l-.793.792c.112.42.155.855.128 1.287l1.372-1.372a3 3 0 1 0-4.243-4.243L6.586 4.672z" fill="#2D2D3B" />
                                            </svg> */}
                                            </span>
                                          </div>
                                        </>
                                      )}
                                    </div>
                                    <div className="ms-2">
                                      {this.state.ShipmentID !== 0 &&
                                      this.state.ShipmentID ? (
                                        this.state.detailData?.[0]
                                          ?.shipping_company_id === 7 ? (
                                          <a
                                            href={
                                              "https://www.aramex.com/us/en/track/results?mode=0&ShipmentNumber=" +
                                              this.state.ShipmentID
                                            }
                                            rel="noreferrer"
                                            className="black-btn"
                                            target="_blank"
                                          >
                                            {orderLanguage.track}
                                          </a>
                                        ) : this.state.tracking_link ? (
                                          <a
                                            href={this.state.tracking_link}
                                            rel="noreferrer"
                                            className="black-btn"
                                            target="_blank"
                                          >
                                            {orderLanguage.track}
                                          </a>
                                        ) : this.state.coustom_tracking_link !==
                                            "" &&
                                          this.state.ShipmentCompany === "9" ? (
                                          <a
                                            href={
                                              this.state.coustom_tracking_link
                                            }
                                            rel="noreferrer"
                                            className="black-btn"
                                            target="_blank"
                                          >
                                            {orderLanguage.track}
                                          </a>
                                        ) : (
                                          <button
                                            className="black-btn"
                                            onClick={() =>
                                              toastr.error(
                                                "shipment is not created"
                                              )
                                            }
                                          >
                                            {orderLanguage.track}
                                          </button>
                                        )
                                      ) : (
                                        <button
                                          className="black-btn"
                                          onClick={() =>
                                            toastr.error(
                                              "shipment is not created"
                                            )
                                          }
                                        >
                                          {orderLanguage.track}
                                        </button>
                                      )}
                                    </div>
                                  </div>
                                  {this.state.ShipmentID &&
                                    (this.state.ShipmentCompany === "9" ||
                                      this.state.ShipmentCompany === "10" ||
                                      this.state.ShipmentCompany === "11") && (
                                      <div className="form-group">
                                        <input
                                          type="text"
                                          readOnly
                                          name="tracking_link"
                                          className="form-control tracking-link"
                                          value={
                                            this.state.coustom_tracking_link
                                          }
                                          placeholder={
                                            orderLanguage.TrackingLink
                                          }
                                        />
                                      </div>
                                    )}
                                </div>
                              </div>
                              <ul className="table-btn-listed px-0">
                                {!this.state.ShipmentID &&
                                  acceptedProducts.length > 0 && (
                                    <li className="" style={{ flex: 1 }}>
                                      <button
                                        onClick={() =>
                                          this.create_handleShow("shipment")
                                        }
                                        className="btn black-btn w-100"
                                        style={{
                                          fontSize: 14,
                                          paddingInline: 15,
                                        }}
                                      >
                                        {orderLanguage.createReturnShipment}
                                      </button>
                                    </li>
                                  )}
                                {this.state.ShippingLabel && (
                                  <li className="ms-3" style={{ flex: 1 }}>
                                    <a
                                      href={this.state.ShippingLabel}
                                      rel="noreferrer"
                                      className="btn dark-btn py-2 w-100"
                                      style={{
                                        fontSize: 14,
                                        paddingInline: 15,
                                      }}
                                      download={"shipping.pdf"}
                                      target="_blank"
                                    >
                                      {orderLanguage.ReprintLabel}
                                    </a>
                                  </li>
                                )}
                              </ul>
                            </>
                          )}
                        </div>
                      </Accordion.Body>
                    </Accordion.Item>
                  </Accordion>
                  {/* --- Priate notes --- */}
                  <div className="white-box mb-3">
                    <div className="order-head-txt d-flex align-items-center border-bottom py-3">
                      <div>
                        <span>{ButtonLanguage.Privatenote}</span>
                        <p className="mb-0">
                          {ButtonLanguage.Onlyvisibletoyou}
                        </p>
                      </div>
                      <div className="ms-auto">
                        <button
                          className="btn dark-red-txt "
                          onClick={this.addnotes}
                        >
                          + {ButtonLanguage.AddNote}
                        </button>
                      </div>
                    </div>
                    <div className="private-note-main">
                      <ul>
                        {this.state.DisplayNotes.length > 0 &&
                          this.state.DisplayNotes.map((item, i) => {
                            return (
                              <li key={item.id}>
                                <div className="d-flex align-items-center">
                                  <span>
                                    {moment(item.updatedat).format(
                                      "MMM DD, hh:mm A"
                                    )}
                                  </span>
                                  <div className="ms-auto">
                                    <div>
                                      <button className="btn">
                                        <svg
                                          width={17}
                                          height={17}
                                          viewBox="0 0 17 17"
                                          fill="none"
                                          xmlns="http://www.w3.org/2000/svg"
                                          onClick={() =>
                                            this.handleEditNote(item.id)
                                          }
                                        >
                                          <path
                                            d="M1.68333 16.149C1.44956 16.1486 1.22672 16.0501 1.06916 15.8774C0.908699 15.7061 0.828965 15.4745 0.849995 15.2407L1.05416 12.9957L10.4858 3.56738L13.4333 6.51405L4.00416 15.9415L1.75916 16.1457C1.73333 16.1482 1.70749 16.149 1.68333 16.149ZM14.0217 5.92488L11.075 2.97821L12.8425 1.21071C12.9988 1.05423 13.2109 0.966309 13.4321 0.966309C13.6533 0.966309 13.8654 1.05423 14.0217 1.21071L15.7892 2.97821C15.9456 3.13452 16.0336 3.34662 16.0336 3.5678C16.0336 3.78897 15.9456 4.00107 15.7892 4.15738L14.0225 5.92405L14.0217 5.92488Z"
                                            fill="#2D2D3B"
                                          />
                                        </svg>
                                      </button>
                                      <button
                                        className="btn"
                                        onClick={() =>
                                          this.handleDelete(item.id)
                                        }
                                      >
                                        <svg
                                          width={18}
                                          height={20}
                                          viewBox="0 0 18 20"
                                          fill="none"
                                          xmlns="http://www.w3.org/2000/svg"
                                        >
                                          <path
                                            d="M14 20H4C2.89543 20 2 19.1046 2 18V5H0V3H4V2C4 0.89543 4.89543 0 6 0H12C13.1046 0 14 0.89543 14 2V3H18V5H16V18C16 19.1046 15.1046 20 14 20ZM4 5V18H14V5H4ZM6 2V3H12V2H6ZM12 16H10V7H12V16ZM8 16H6V7H8V16Z"
                                            fill="#2D2D3B"
                                          />
                                        </svg>
                                      </button>
                                    </div>
                                  </div>
                                </div>
                                <p>{item.note}</p>
                              </li>
                            );
                          })}
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <RestockModal
          userId={this.state.user_id}
          orderId={this.state.order_id}
          open={this.state.showRestockModal}
          acceptedProducts={acceptedProducts}
          onSave={this.handleRestockModalSave}
          onClose={this.handleRestockModalClose}
        />

        {/* ------------------------modal-cancel-confirm-------------------------- */}
        <Modal
          className=""
          size="lg"
          centered
          show={this.state.showCancelConfirmModal}
          onHide={this.handleCancelConfirmModalClose}
        >
          <Modal.Header className="px-4 mx-2">
            <Modal.Title style={{ fontWeight: 600, fontSize: 22 }}>
              {this.state.isModalTypeApprove
                ? orderLanguage.ApproveItems
                : orderLanguage.RejectItems}
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="p-4 mx-2">
            <div className="return-order-items px-2">
              <h6 className="">
                {this.state.isModalTypeApprove
                  ? orderLanguage.ApproveItemsConfirmationMessage
                  : orderLanguage.RejectItemsConfirmationMessage}
              </h6>
              <div className="grey-box pt-3">
                <div className="cust-checkbox-new">
                  <label className="cust-chk-bx">
                    <input
                      defaultChecked
                      type="checkbox"
                      name="sendNotification"
                      onChange={this.handleChangeSendNotification}
                    />
                    <span className="cust-chkmark" />
                    <span className="ps-2">
                      {orderLanguage.sendNotificationToCustomer}
                    </span>
                  </label>
                </div>
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer className="py-3 px-4 mx-2 d-flex">
            <button
              onClick={this.handleCancelConfirmModalClose}
              disabled={this.state.activeSpinnerBtn}
              className="btn py-2 px-4 red-outlined-btn"
            >
              Cancel
            </button>
            <button
              onClick={this.handleApproveRejectSubmit}
              disabled={this.state.activeSpinnerBtn}
              className="red-btn border-0 py-2 rounded ms-3 d-flex align-center"
            >
              {this.state.activeSpinnerBtn ? (
                // <div class="spinner-border text-light"></div>
                <CircularProgress size={24} color="#fff" />
              ) : (
                "Submit"
                // orderLanguage.CancelItem
              )}
            </button>
          </Modal.Footer>
        </Modal>

        {/* ------------------------modal-shipping-------------------------- */}
        <Modal
          dialogClassName="modal-dialog-centered cust-order-table"
          className="edit-user-modal cust-modal cust-order-table"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.create_show}
          onHide={this.create_userClose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">{ButtonLanguage.ShipmentCreation}</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.create_userClose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            {this.state.detailData && (
              <div
                className={`row modal-form cust-order-modal${
                  this.context.language === "english" ? "" : " ar"
                }`}
              >
                <div className="col-md-6">
                  <div className="row">
                    <div className="col-md-12 mb-3">
                      <div className="modal-txt-head">
                        <span>
                          {this.state.isUpdateShipment
                            ? ButtonLanguage.UpdateShipment
                            : ButtonLanguage.CreateShipment}
                        </span>
                      </div>
                    </div>
                    {!this.isShippingCompanyRedbox() && (
                      <div className="col-md-12 form-group d-flex align-items-center">
                        <label>{ButtonLanguage.QuantityofPieces}</label>
                        {/* <input name="quantity" className="form-control" type="text" placeholder="Enter quantity" onChange={this.handleChange} value={this.state.quantity} /> */}
                        <select
                          name="quantity"
                          className="form-select form-control"
                          onChange={this.handleChange}
                          value={this.state.quantity}
                          required
                          disabled={
                            (enableFieldsOnUpdate &&
                              !enableFieldsOnUpdate.includes("quantity")) ??
                            false
                          }
                        >
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                          <option value="4">4</option>
                          <option value="5">5</option>
                          <option value="6">6</option>
                          <option value="7">7</option>
                          <option value="8">8</option>
                          <option value="9">9</option>
                          <option value="10">10</option>
                        </select>
                      </div>
                    )}

                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.ShippingCompany}</label>
                      <select
                        className="form-select form-control"
                        name="shippingCompany"
                        onChange={this.handleShippingCompanyChange}
                        value={this.state.shippingCompany}
                        disabled={
                          this.state.ShipmentCompany === "11" ||
                          ((enableFieldsOnUpdate &&
                            !enableFieldsOnUpdate.includes(
                              "shippingCompany"
                            )) ??
                            false)
                        }
                        required
                      >
                        <option value="">
                          {ButtonLanguage.ShippingCompany}
                        </option>
                        {this.state.shippingCompanyData?.map((item) => {
                          return (
                            <option key={item.id} value={item.id}>
                              {this.context.language === "english"
                                ? item.english
                                : item.arabic}
                            </option>
                          );
                        })}
                      </select>
                    </div>

                    {/* only redbox */}
                    {/* {(this.state.detailData.shipping_company === "Red Box" ||
                      this.isShippingCompanyRedbox()) && (
                      <div className="col-md-12 form-group d-flex align-items-center">
                        <label>{ButtonLanguage.warehouse}</label>
                        <select
                          name="warehouse"
                          onChange={this.handleChange}
                          value={this.state.warehouse}
                          className="form-select form-control"
                          required
                          disabled={
                            (enableFieldsOnUpdate &&
                              !enableFieldsOnUpdate.includes("warehouse")) ??
                            false
                          }
                        >
                          {this.state.warehouses.map((item) => {
                            return (
                              <option value={item.id} key={item.id}>
                                {item.address}
                              </option>
                            );
                          })}
                        </select>
                      </div>
                    )} */}

                    {/* only redbox */}
                    {/* <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.Labeltype}</label>
                      <select
                        className="form-select form-control"
                        name="labelType"
                        onChange={this.handleChange}
                        value={this.state.labelType}
                        disabled={
                          (enableFieldsOnUpdate &&
                            !enableFieldsOnUpdate.includes("labelType")) ??
                          false
                        }
                      >
                        <option value="">Select label</option>
                        <option value="6x4 Thermal printer" selected>
                          6x4 Thermal printer
                        </option>
                      </select>
                    </div> */}
                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.Customername}</label>
                      <input
                        className="form-control"
                        type="text"
                        placeholder="Enter customer name"
                        name="shipmentCustomerName"
                        onChange={this.handleChange}
                        value={this.state.shipmentCustomerName}
                        disabled={
                          (enableFieldsOnUpdate &&
                            !enableFieldsOnUpdate.includes("customerName")) ??
                          false
                        }
                      />
                    </div>
                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.PhoneNumber}</label>
                      <input
                        className="form-control"
                        type="text"
                        placeholder="Enter phone number"
                        name="phoneNumber"
                        onChange={this.handleChange}
                        value={this.state.phoneNumber}
                        disabled={
                          (enableFieldsOnUpdate &&
                            !enableFieldsOnUpdate.includes("phoneNumber")) ??
                          false
                        }
                      />
                    </div>
                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.EmailAddress}</label>
                      <input
                        className="form-control"
                        type="email"
                        placeholder="Enter email"
                        name="email"
                        onChange={this.handleChange}
                        value={this.state.email}
                        disabled={
                          (enableFieldsOnUpdate &&
                            !enableFieldsOnUpdate.includes("email")) ??
                          false
                        }
                      />
                    </div>
                    {this.state.shippingCompany === "10" ? (
                      <>
                        <div className="col-md-12 form-group d-flex align-items-center">
                          <label>{ButtonLanguage.City}</label>
                          <select
                            className="form-select input-custom-class"
                            name="city"
                            required
                            onChange={(e) => {
                              this.handleChange(e);
                              this.getAreaByCity(e.target.value);
                            }}
                            value={this.state.city}
                            disabled={
                              (enableFieldsOnUpdate &&
                                !enableFieldsOnUpdate.includes("city")) ??
                              false
                            }
                          >
                            <option value="">
                              {ButtonLanguage.Selectcity}
                            </option>
                            {this.state.AllCity.length > 0 &&
                              this.state.AllCity.map((item) => {
                                return (
                                  <option key={item.id} value={item.id}>
                                    {item.english}
                                  </option>
                                );
                              })}
                          </select>
                        </div>
                        <div className="col-md-12 form-group d-flex align-items-center">
                          <label>{UserLanguage.Area}</label>
                          <select
                            className="form-select input-custom-class"
                            name="area"
                            required
                            onChange={this.handleChange}
                            value={this.state.area}
                            disabled={
                              (enableFieldsOnUpdate &&
                                !enableFieldsOnUpdate.includes("area")) ??
                              false
                            }
                          >
                            <option value="">{UserLanguage.SelectArea}</option>
                            {this.state.AllArea.length > 0 &&
                              this.state.AllArea.map((item) => {
                                return (
                                  <option key={item.id} value={item.id}>
                                    {item.english}
                                  </option>
                                );
                              })}
                          </select>
                        </div>
                      </>
                    ) : (
                      <div className="col-md-12 form-group d-flex align-items-center">
                        <label>{ButtonLanguage.CityArea}</label>
                        <input
                          className="form-control"
                          type="text"
                          placeholder="Enter city-area name"
                          name="cityArea"
                          onChange={this.handleChange}
                          value={this.state.cityArea}
                          disabled={
                            (enableFieldsOnUpdate &&
                              !enableFieldsOnUpdate.includes("cityArea")) ??
                            false
                          }
                        />
                      </div>
                    )}
                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.Addressline} 1</label>
                      <input
                        className="form-control"
                        type="text"
                        placeholder="Enter Address line 1"
                        name="line_1"
                        onChange={this.handleChange}
                        value={this.state.line_1}
                        disabled={
                          (enableFieldsOnUpdate &&
                            !enableFieldsOnUpdate.includes("line_1")) ??
                          false
                        }
                      />
                    </div>
                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.Addressline} 2</label>
                      <input
                        className="form-control"
                        type="text"
                        placeholder="Enter Address line 2"
                        name="line_2"
                        onChange={this.handleChange}
                        value={this.state.line_2}
                        disabled={
                          (enableFieldsOnUpdate &&
                            !enableFieldsOnUpdate.includes("line_2")) ??
                          false
                        }
                      />
                    </div>
                    {!this.isShippingCompanyRedbox() && (
                      <div className="col-md-12 form-group d-flex align-items-center">
                        <label>{ButtonLanguage.ReferenceNo}</label>
                        <input
                          className="form-control"
                          type="text"
                          placeholder="Enter Reference number"
                          name="referenceNumber"
                          onChange={this.handleChange}
                          value={this.state.referenceNumber}
                          disabled={
                            (enableFieldsOnUpdate &&
                              !enableFieldsOnUpdate.includes(
                                "referenceNumber"
                              )) ??
                            false
                          }
                        />
                      </div>
                    )}
                    {this.state.isUpdateShipment && (
                      <div className="col-md-12 form-group d-flex align-items-center">
                        <label>{orderLanguage.TrackingNumber}</label>
                        <input
                          className="form-control"
                          type="text"
                          placeholder="Enter Tracking number"
                          name="trackingNumber"
                          onChange={this.handleChange}
                          value={this.state.trackingNumber}
                          disabled={
                            (enableFieldsOnUpdate &&
                              !enableFieldsOnUpdate.includes(
                                "trackingNumber"
                              )) ??
                            false
                          }
                        />
                      </div>
                    )}
                    <div className="col-md-12 form-group d-flex align-items-center">
                      <label>{ButtonLanguage.CODValue}</label>
                      <input
                        className="form-control"
                        type="number"
                        placeholder="Enter COD value"
                        name="codValue"
                        onChange={this.handleChange}
                        value={this.state.codValue}
                        disabled={
                          (enableFieldsOnUpdate &&
                            !enableFieldsOnUpdate.includes("codValue")) ??
                          false
                        }
                      />
                    </div>
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="row">
                    <div className="col-md-12 mb-3">
                      <div className="modal-txt-head">
                        <span>{ButtonLanguage.ShippingTo}</span>
                      </div>
                    </div>
                    <div className="col-md-12">
                      <div className="table-responsive">
                        <table className="order-table w-100">
                          <tbody>
                            <tr>
                              <td>{orderLanguage.shipperName}</td>
                              <td>
                                {this.state.ShipperData.contact_name &&
                                  this.state.ShipperData.contact_name}
                              </td>
                            </tr>
                            <tr>
                              <td>{orderLanguage.Email}</td>
                              <td>
                                {this.state.ShipperData.email
                                  ? this.state.ShipperData.email
                                  : ""}
                              </td>
                            </tr>
                            <tr>
                              <td>{ButtonLanguage.PhoneNumber}</td>
                              <td>
                                {this.state.ShipperData.contact_number
                                  ? this.state.ShipperData.contact_number
                                  : ""}
                              </td>
                            </tr>
                            <tr>
                              <td>{ButtonLanguage.City}</td>
                              <td>
                                {this.context.language === "english"
                                  ? this.state.ShipperData.city_detail &&
                                    this.state.ShipperData.city_detail[0]
                                      ?.english
                                  : this.state.ShipperData.city_detail &&
                                    this.state.ShipperData.city_detail[0]
                                      ?.arabic}
                              </td>
                            </tr>
                            <tr>
                              <td>{ButtonLanguage.Address}</td>
                              <td>
                                {this.state.ShipperData.address &&
                                  this.state.ShipperData.address}
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div className="col-md-12 mt-3">
                      {/* <div className="modal-txt-head">
                        <span>Shipment Comments</span>
                      </div>
                      <div className="custom-border mt-3">
                        <div className="notes-data">
                          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                        </div>
                      </div> */}
                      <div className="modal-txt-head mb-2">
                        <span>{ButtonLanguage.ShipmentComments}</span>
                      </div>
                      <textarea
                        rows="10"
                        name="shipmentComments"
                        className="form-control input-custom-class h-auto p-3"
                        placeholder="Add shipment comments"
                        onChange={this.handleChange}
                        value={this.state.shipmentComments}
                      />
                    </div>

                    {/* --- Pickup request --- */}
                    {/* {this.state.orderStatusValue !== 2 && (
                      <div className="col-md-12 mt-3">
                        <div className="cust-checkbox-new">
                          <label className="cust-chk-bx">
                            <input
                              type="checkbox"
                              name="pickupRequest"
                              onChange={this.handleChange}
                            />
                            <span className="cust-chkmark" />
                            <span className="ps-2">Create pickup request</span>
                          </label>
                        </div>
                      </div>
                    )}
                    {this.state.pickupRequest ? (
                      <div className="col-md-12 mt-3">
                        {this.state.shippingCompany !== "11" ? (
                          <>
                            <div>
                              <label>Ready Time</label>
                              {this.state.ReadyTime === "" &&
                                this.state.validation && (
                                  <span className="red-txt"> Require</span>
                                )}
                              <input
                                type="datetime-local"
                                className="form-control"
                                name="ReadyTime"
                                value={this.state.ReadyTime}
                                onChange={this.handleChange}
                              />
                            </div>
                            <div>
                              <label>Pickup Date</label>
                              {this.state.PickupDate === "" &&
                                this.state.validation && (
                                  <span className="red-txt"> Require</span>
                                )}
                              <input
                                type="datetime-local"
                                className="form-control"
                                name="PickupDate"
                                value={this.state.PickupDate}
                                onChange={this.handleChange}
                                min={moment().format("YYYY-MM-DDT00:00")}
                                max={moment()
                                  .add(7, "day")
                                  .format("YYYY-MM-DDT00:00")}
                              />
                            </div>
                            <div>
                              <label>LastPickup Time</label>
                              {this.state.LastPickupTime === "" &&
                                this.state.validation && (
                                  <span className="red-txt"> Require</span>
                                )}
                              <input
                                type="datetime-local"
                                className="form-control"
                                name="LastPickupTime"
                                value={this.state.LastPickupTime}
                                onChange={this.handleChange}
                              />
                            </div>
                            <div>
                              <label>Closing Time</label>
                              {this.state.ClosingTime === "" &&
                                this.state.validation && (
                                  <span className="red-txt"> Require</span>
                                )}
                              <input
                                type="datetime-local"
                                className="form-control"
                                name="ClosingTime"
                                value={this.state.ClosingTime}
                                onChange={this.handleChange}
                              />
                            </div>
                          </>
                        ) : (
                          <>
                            <div>
                              <label>Pickup Time</label>
                              {this.state.redboxPickupTime === "" &&
                                this.state.validation && (
                                  <span className="red-txt"> Require</span>
                                )}
                              <input
                                type="time"
                                className="form-control"
                                name="redboxPickupTime"
                                value={this.state.redboxPickupTime}
                                onChange={this.handleChange}
                              />
                            </div>
                           
                          </>
                        )}
                      </div>
                    ) : (
                      ""
                    )} */}
                  </div>
                </div>
                {/* <div className="col-md-12 form-group mt-3">
                  <label>Old Shipments :</label>
                  <p className="dark-red-txt">12345687903648.pdf</p>
                </div> */}
              </div>
            )}
          </Modal.Body>
          <Modal.Footer>
            <div className="col-md-12 text-md-end text-center">
              <div className="common-red-btn">
                <button
                  className="btn gray-red-txt-btn me-2"
                  onClick={this.create_userClose}
                >
                  Reset
                </button>
                <button
                  onClick={this.handleCreateShipment}
                  className="btn red-btn "
                >
                  {this.state.isUpdateShipment
                    ? orderLanguage.update
                    : "Create"}
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>

        {/* =======cla refund ========== */}
        <Modal
          dialogClassName="modal-dialog-centered cust-modal-white-content"
          className="cust-white-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.refundmodal}
          onHide={this.refundmodalclose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">{ButtonLanguage.RefundCustomer}</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.refundmodalclose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <div className="row modal-form cust-white-modal align-items-center">
              <div className="col-md-12 form-group">
                <ul>
                  <li>
                    <label className="cust-radio mb-3">
                      <input
                        type="radio"
                        id="1"
                        value="card"
                        name="RefundMode"
                        onChange={this.handleRefundChange}
                      />
                      <span className="checkmark"></span>
                      <span>{ButtonLanguage.RefundCard}</span>
                    </label>
                  </li>
                  <li>
                    <label className="cust-radio mb-3">
                      <input
                        type="radio"
                        id="2"
                        value="wallet"
                        name="RefundMode"
                        onChange={this.handleRefundChange}
                      />
                      <span className="checkmark"></span>
                      <span>{ButtonLanguage.Refundwallet}</span>
                    </label>
                  </li>
                  <li>
                    <label className="cust-radio mb-3">
                      <input
                        type="radio"
                        id="3"
                        value="bank"
                        name="RefundMode"
                        onChange={this.handleRefundChange}
                      />
                      <span className="checkmark"></span>
                      <span>{ButtonLanguage.Refundbanktransfer}</span>
                    </label>
                  </li>
                  {/* {
                    this.state.detailData?.pay_method === "TABBY" && 
                    <li>
                      <label className="cust-radio mb-3">
                        <input type="radio" id="3" value="TABBY" name="RefundMode" onChange={this.handleRefundChange} />
                        <span className="checkmark"></span>
                        <span>{ButtonLanguage.RefundTabby}</span>
                      </label>
                    </li>
                  } */}
                </ul>
                <label>{ButtonLanguage.SetRefundAmount}</label>
                <ul>
                  <li>
                    <label className="cust-radio mb-3">
                      <input
                        type="radio"
                        id="0"
                        value="full"
                        name="refundAmountType"
                        onChange={this.handleRefundChange}
                      />
                      <span className="checkmark"></span>
                      <span>{ButtonLanguage.FullAmount}</span>
                      {this.state.detailData && (
                        <bdi className="ms-3 order-details-txt dark-red-txt">
                          SR{" "}
                          {(
                            Number(this.state.detailData.total_placed_price) -
                            totalReFund
                          ).toFixed(2)}
                        </bdi>
                      )}
                    </label>
                  </li>
                  <li className="d-flex align-items-center">
                    <label className="cust-radio mb-3">
                      <input
                        type="radio"
                        id="1"
                        value="partial"
                        name="refundAmountType"
                        onChange={this.handleRefundChange}
                      />
                      <span className="checkmark"></span>
                      <span>{ButtonLanguage.PartialAmount}</span>
                    </label>
                    {this.state.r_amount ? (
                      <input
                        type="number"
                        className="form-control w-auto ms-2"
                        name="refund_amount"
                        value={this.state.refund_amount}
                        onChange={this.handleRefundinputChange}
                        onWheel={(e) => {
                          e.target?.value?.blur?.();
                        }}
                        min="1"
                      />
                    ) : (
                      ""
                    )}
                  </li>
                </ul>
              </div>
              <div className="col-md-12 form-group">
                <label>{ButtonLanguage.Notes}</label>
                <textarea
                  className="form-control h-auto"
                  rows="4"
                  name="RefundDescription"
                  onChange={this.handleRefundChange}
                ></textarea>
              </div>

              <div className="col-lg-12 text-lg-end text-center">
                <div className="common-red-btn">
                  <button
                    className="btn red-border-btn  me-2"
                    type="button"
                    onClick={this.refundmodalclose}
                  >
                    {ButtonLanguage.cancel}
                  </button>
                  <button
                    className="btn red-btn "
                    type="button"
                    onClick={this.CreateRefund}
                  >
                    {ButtonLanguage.Send}
                  </button>
                </div>
              </div>
            </div>
          </Modal.Body>
        </Modal>

        {/* ========= add note =========== */}
        <Modal
          dialogClassName="modal-dialog-centered cust-modal-white-content"
          className="cust-white-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.addnotes}
          onHide={this.addnotesclose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">{ButtonLanguage.Privatenote}</h1>
              <p>{ButtonLanguage.Onlyvisibletoyou}</p>
            </Modal.Title>
            <button
              type="button"
              onClick={this.addnotesclose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <form onSubmit={this.submitNote}>
              <div className="row modal-form cust-white-modal align-items-center">
                <div className="col-md-12 form-group">
                  <textarea
                    className="form-control h-auto"
                    name="notes"
                    value={this.state.notes}
                    onChange={this.handleNote}
                    rows="4"
                  ></textarea>
                </div>

                <div className="col-lg-12 text-lg-end text-center">
                  <div className="common-red-btn">
                    <button
                      className="btn red-border-btn  me-2"
                      type="reset"
                      onClick={this.addnotesclose}
                    >
                      {ButtonLanguage.cancel}
                    </button>
                    <button
                      className="btn red-btn "
                      type="submit"
                      onClick={this.SaveNote}
                    >
                      {ButtonLanguage.save}
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </Modal.Body>
        </Modal>

        {/* ========= edit note =========== */}
        <Modal
          dialogClassName="modal-dialog-centered cust-modal-white-content"
          className="cust-white-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.Editaddnotes}
          onHide={this.addnotesclose}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">Private note</h1>
              <p>Only visible to you</p>
            </Modal.Title>
            <button
              type="button"
              onClick={this.Editaddnotesclose}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <form onSubmit={this.submitNote}>
              <div className="row modal-form cust-white-modal align-items-center">
                <div className="col-md-12 form-group">
                  <textarea
                    className="form-control h-auto"
                    name="Editnotes"
                    value={this.state.Editnotes}
                    onChange={this.handleNote}
                    rows="4"
                  ></textarea>
                </div>

                <div className="col-lg-12 text-lg-end text-center">
                  <div className="common-red-btn">
                    <button
                      className="btn red-border-btn  me-2"
                      type="reset"
                      onClick={this.Editaddnotesclose}
                    >
                      Cancel
                    </button>
                    <button
                      className="btn red-btn "
                      type="submit"
                      onClick={this.EditNote}
                    >
                      Save
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </Modal.Body>
        </Modal>

        {/* ========= add invoice number =========== */}
        <Modal
          dialogClassName="modal-dialog-centered cust-modal-white-content"
          className="cust-white-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.invoice_show}
          onHide={this.handleCloseInvoiceModal}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">{ButtonLanguage.InvoiceNumber}</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.handleCloseInvoiceModal}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <form onSubmit={this.submitNote}>
              <div className="row modal-form cust-white-modal align-items-center">
                <div className="col-md-12 form-group">
                  <input
                    type="text"
                    className="form-control"
                    placeholder={ButtonLanguage.PleaseEnterInvoiceNumber}
                    name="invoice_number"
                    value={this.state.invoice_number}
                    onChange={this.barcode}
                  />
                </div>

                <div className="col-lg-12 text-lg-end text-center">
                  <div className="common-red-btn">
                    <button
                      className="btn red-border-btn  me-2"
                      type="reset"
                      onClick={this.handleCloseInvoiceModal}
                    >
                      {ButtonLanguage.cancel}
                    </button>
                    <button
                      className="btn black-btn"
                      onClick={this.handleSaveInvoiceNumber}
                    >
                      {ButtonLanguage.save}
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </Modal.Body>
        </Modal>

        {/* ===================================add-qr-e-hash======================================== */}
        <Modal
          dialogClassName="modal-dialog-centered cust-modal-white-content"
          className="cust-white-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.qr_invoice_show}
          onHide={this.handleCloseQrInvoiceModal}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">{ButtonLanguage.InvoiceNumber}</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.handleCloseQrInvoiceModal}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <form onSubmit={this.submitNote}>
              <div className="row modal-form cust-white-modal align-items-center">
                <div className="col-md-12 form-group">
                  <input
                    type="text"
                    className="form-control"
                    placeholder={ButtonLanguage.PleaseEnterInvoiceNumber}
                    name="qr_invoice_number"
                    value={this.state.qr_invoice_number}
                    onChange={this.QRCode}
                  />
                </div>

                <div className="col-lg-12 text-lg-end text-center">
                  <div className="common-red-btn">
                    <button
                      className="btn red-border-btn  me-2"
                      type="reset"
                      onClick={this.handleCloseQrInvoiceModal}
                    >
                      {ButtonLanguage.cancel}
                    </button>
                    <button
                      className="btn black-btn"
                      onClick={this.handleSaveQRInvoiceNumber}
                    >
                      {ButtonLanguage.save}
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </Modal.Body>
        </Modal>

        {/* ===================================confirm-cancel======================================== */}
        <Modal
          dialogClassName="modal-dialog-centered cust-modal-white-content"
          className="cust-white-modal"
          ref={(el) => {
            this.dialog = el;
          }}
          show={this.state.cancelComfirmModelshow}
          onHide={this.handleCloseConfirCancelModal}
        >
          <Modal.Header>
            <Modal.Title>
              <h1 className="modal-title">Cancel Order</h1>
            </Modal.Title>
            <button
              type="button"
              onClick={this.handleCloseConfirCancelModal}
              className="close btn-close"
            ></button>
          </Modal.Header>
          <Modal.Body>
            <div className="row modal-form cust-white-modal align-items-center">
              <p>Are you Sure you want to cancel whole Order.</p>
              <div className="col-lg-12 text-lg-end text-center">
                <div className="common-red-btn">
                  <button
                    className="btn red-border-btn  me-2"
                    type="reset"
                    onClick={this.handleCloseConfirCancelModal}
                  >
                    {ButtonLanguage.No}
                  </button>
                  <button
                    className="btn black-btn"
                    onClick={this.confirmCancelWholeOrder}
                  >
                    {ButtonLanguage.Yes}
                  </button>
                </div>
              </div>
            </div>
          </Modal.Body>
        </Modal>
      </Adminlayout>
    );
  }
}

export default withRouter(ReturnOrderDetails);
