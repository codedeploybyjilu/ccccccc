import React, { Component } from 'react'
import Adminlayout from '../../Components/AdminLayout/Adminlayout'
import DataTable from "../../Components/DataTable";
import { textFilter } from 'react-bootstrap-table2-filter';
import 'react-confirm-alert/src/react-confirm-alert.css';
import { buttonArabic, buttonEnglish, SidebarArabic, SidebarEnglish, TableFieldArabic, TableFieldEnglish, titleArabic, titleEnglish } from '../../const';
import LanguageContext from '../../contexts/languageContext'
import productimg from '../../images/product-img.png'

export class ReturnProduct extends Component {
    static contextType = LanguageContext;

    constructor(props) {
        super(props);
        this.state = {
            page: 1,
            sizePerPage: 10,
            totalSize: 100,
            defaultSorted: [{
                dataField: 'id',
                order: 'asc'
            }],

            order_data: [
                { id: 1, itemcode: '12345', productname: 'Black top', category: 'Kids', subcategory: 'Top', price: '$500', reason: 'Lorem Ipsum', date: '30 Apr 12:30 pm', },
                { id: 2, itemcode: '12345', productname: 'Black top', category: 'Kids', subcategory: 'Top', price: '$500', reason: 'Lorem Ipsum', date: '30 Apr 12:30 pm', },
                { id: 3, itemcode: '12345', productname: 'Black top', category: 'Kids', subcategory: 'Top', price: '$500', reason: 'Lorem Ipsum', date: '30 Apr 12:30 pm', },
                { id: 4, itemcode: '12345', productname: 'Black top', category: 'Kids', subcategory: 'Top', price: '$500', reason: 'Lorem Ipsum', date: '30 Apr 12:30 pm', },
                { id: 5, itemcode: '12345', productname: 'Black top', category: 'Kids', subcategory: 'Top', price: '$500', reason: 'Lorem Ipsum', date: '30 Apr 12:30 pm', },
                { id: 6, itemcode: '12345', productname: 'Black top', category: 'Kids', subcategory: 'Top', price: '$500', reason: 'Lorem Ipsum', date: '30 Apr 12:30 pm', },
                { id: 7, itemcode: '12345', productname: 'Black top', category: 'Kids', subcategory: 'Top', price: '$500', reason: 'Lorem Ipsum', date: '30 Apr 12:30 pm', },
                { id: 8, itemcode: '12345', productname: 'Black top', category: 'Kids', subcategory: 'Top', price: '$500', reason: 'Lorem Ipsum', date: '30 Apr 12:30 pm', },
                { id: 9, itemcode: '12345', productname: 'Black top', category: 'Kids', subcategory: 'Top', price: '$500', reason: 'Lorem Ipsum', date: '30 Apr 12:30 pm', },
                { id: 10, itemcode: '12345', productname: 'Black top', category: 'Kids', subcategory: 'Top', price: '$500', reason: 'Lorem Ipsum', date: '30 Apr 12:30 pm', },
            ],
        }

    }
    get_order_data = () => {
    }


    handleTableChange = (type, { page, sizePerPage, filters, sortField, sortOrder }) => {
        switch (type) {
            case "pagination":
                this.setState({
                    page,
                    sizePerPage
                }, () => this.get_order_data());
                break;
            case "filter":
                let search_val = this.state.search_val;
                let newFilter = {};
                if (Object.keys(filters).length) {
                    for (const dataField in filters) {
                        newFilter[dataField] = filters[dataField].filterVal;
                    }
                    newFilter = {
                        ...search_val,
                        ...newFilter
                    };
                } else {
                    newFilter = {
                        title: '',
                        indicator: '',
                        definition: ''
                    };
                }
                this.setState({
                    search_val: newFilter
                }, () => this.get_order_data())
                break;
            case "sort":
                this.setState({
                    defaultSorted: [{
                        dataField: sortField,
                        order: sortOrder
                    }]
                }, () => this.get_order_data());
                break;
            default:
                break;
        }
        return true;
    }
    render() {
        let Language = this.context.language === 'english' ? TableFieldEnglish : TableFieldArabic
        let ButtonLanguage = this.context.language === 'english' ? buttonEnglish : buttonArabic
        let titleLanguage = this.context.language === 'english' ? titleEnglish : titleArabic
        const columns = [
            {
                dataField: 'id',
                text: 'Id',
                hidden: true,
            },
            {
                dataField: 'photo',
                text: 'Photo',
                sort: true,
                hidden: false,
                formatter: (cell, row, rowIndex) => {
                    return (
                        <React.Fragment>
                            <img src={productimg} alt="" />
                        </React.Fragment>
                    );
                }
            },
            {
                dataField: 'itemcode',
                text: 'Item Code',
                sort: true,
                hidden: false,
            },
            {
                dataField: 'productname',
                text: 'Product Name',
                sort: true,
                hidden: false,
                filter: textFilter({
                    placeholder: titleLanguage.search
                }),
            },
            {
                dataField: 'category',
                text: 'Category',
                sort: true,
                hidden: false,
                filter: textFilter({
                    placeholder: titleLanguage.search
                }),
            },

            {
                dataField: 'subcategory',
                text: 'Sub-Category',
                sort: true,
                hidden: false,
                filter: textFilter({
                    placeholder: titleLanguage.search
                }),
            },
            {
                dataField: 'price',
                text: 'Price',
                sort: true,
                hidden: false,
            },
            {
                dataField: 'reason',
                text: 'Reason',
                sort: true,
                hidden: false,
            },
            {
                dataField: 'date',
                text: 'Date',
                sort: true,
                hidden: false,

            },
        ]
        return (
            <Adminlayout>
                <div className="container-fluid">
                    <div className="row common-space">
                        <div className="col-sm-6 text-sm-start text-center">
                            <div className="common-header-txt">
                                <h3>Return Products</h3>
                            </div>
                        </div>
                        <div className="col-sm-6 text-end">
                            <div className="common-red-btn">
                                <a href="#" className="btn red-btn me-2">Export List</a>
                            </div>
                        </div>
                    </div>

                    <div className="row common-space">
                        <div className="col-md-12">
                            <div className="white-box">
                                <div className="custom-table">
                                    <div className="table-responsive dataTables_wrapper no-footer">
                                        {
                                            this.state.order_data &&
                                            <DataTable
                                                keyField='id'
                                                loading={this.state.loading}
                                                columns={columns}
                                                data={this.state.order_data}
                                                page={this.state.page}
                                                sizePerPage={this.state.sizePerPage}
                                                totalSize={this.state.totalSize}
                                                defaultSorted={this.state.defaultSorted}
                                                onTableChange={this.handleTableChange}
                                                selectableRows
                                                language={this.context.language}
                                            />
                                        }
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </Adminlayout>
        )
    }
}

export default ReturnProduct
