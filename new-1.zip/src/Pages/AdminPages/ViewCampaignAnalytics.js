import React, { Component } from 'react';
import Adminlayout from '../../Components/AdminLayout/Adminlayout';
import PlaceholderImage from "../../images/placeholder-image.svg";
import Chart from "react-apexcharts";

class ViewCampaignAnalytics extends Component {
    render() {

        const chart7 = {
            series: [
                {
                    name: "Dec 27, ’22",
                    data: [100, 80, 165, 150, 245, 200],
                },
            ],
            colors: ["#19CF9C"],
            chart: {
                height: 350,
                type: "line",
                fontFamily: "Poppins,sans-serif",
                stacked: false,
                toolbar: {
                    show: false,
                },
            },
            stroke: {
                show: true,
                width: 2,
                curve: "smooth",
            },
            title: {
                text: "",
                align: 'left',
                floating: false,
                style: {
                    fontSize: '12px',
                    fontWeight: '600',
                    fontFamily: 'Poppins',
                    color: '#5E5E5E'
                },
            },
            grid: {
                show: true,
                borderColor: 'rgba(35, 34, 34, .1)',
                strokeDashArray: 3,
                position: 'back',
                xaxis: {
                    lines: {
                        show: true
                    }
                },
                yaxis: {
                    lines: {
                        show: true
                    }
                },
            },
            legend: {
                show: false,
                position: 'top'
            },
            xaxis: {
                categories: ["12:00 AM", "04:00 AM", "08:00 AM", "12:00 PM", "04:00 PM", "08:00 PM"],
            },
            yaxis: {
                labels: {
                    formatter: function (value) {
                        return "$" + value;
                    }
                },
            },
        };

        return (
            <Adminlayout>
                <div className="container-fluid">
                    <div className="row common-space">
                        <div className="col-12 text-sm-start text-center rtl-txt-start">
                            <div className="common-header-txt">
                                <h3>
                                    <a href='/campaign'>
                                        <svg className='me-2' width="16" height="12" viewBox="0 0 16 12" fill="none"><path d="M3.83 5L7.41 1.41L6 0L0 6L6 12L7.41 10.59L3.83 7H16V5H3.83Z" fill="#2d2d3b"></path></svg>
                                    </a>
                                    Campaign Analytics
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div className='row common-space'>
                        <div className='col-12'>
                            <div className='row me-0'>
                                <div className='col-xxl-5 col-lg-6 pe-0'>
                                    <div className='row me-0'>
                                        <div className='col-md-8 pe-0 pb-2 pb-md-0 mb-1 mb-md-0'>
                                            <div className='white-box h-100'>
                                                <div className='mb-3 campaigns-profile'>
                                                    <img src={PlaceholderImage} loading='lazy' alt='' />
                                                </div>
                                                <div className='usrs-dtls-info mb-3'>
                                                    <span className="d-block">TITLE</span>
                                                    <bdi className="d-block">adas</bdi>
                                                </div>
                                                <div className='usrs-dtls-info mb-3'>
                                                    <span className="d-block">DESCRIPTION</span>
                                                    <bdi className="d-block">adasda</bdi>
                                                </div>
                                                <div className='usrs-dtls-info mb-3'>
                                                    <span className="d-block">AUDIENCE</span>
                                                    <bdi className="d-block">all users</bdi>
                                                </div>
                                                <div className='usrs-dtls-info'>
                                                    <span className="d-block">SCHEDULE TIME</span>
                                                    <bdi className="d-block">February 20,2023 2:07:12 pm</bdi>
                                                </div>
                                            </div>
                                        </div>
                                        <div className='col-md-4 pe-0'>
                                            <div className='row me-0'>
                                                <div className='col-lg-12 pe-0 mb-3'>
                                                    <div className='white-box h-100'>
                                                        <div className="dash-new-box-main">
                                                            <div className="dash-new-box-hdr mb-3">
                                                                <mark className="bg-transparent p-0">
                                                                    <svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <circle cx="25" cy="25" r="25" fill="#EB5A95"></circle>
                                                                        <path
                                                                            d="M25 35C23.8954 35 23 34.1046 23 33H27C27 34.1046 26.1046 35 25 35ZM33 32H17V30L19 29V23.5C19 20.038 20.421 17.793 23 17.18V15H27V17.18C29.579 17.792 31 20.036 31 23.5V29L33 30V32ZM25 18.75C23.7797 18.6712 22.6028 19.2173 21.875 20.2C21.2525 21.1846 20.9471 22.3364 21 23.5V30H29V23.5C29.0528 22.3364 28.7474 21.1846 28.125 20.2C27.3972 19.2173 26.2203 18.6712 25 18.75Z"
                                                                            fill="white"
                                                                        ></path>
                                                                    </svg>
                                                                </mark>
                                                            </div>
                                                            <div className="dash-new-box-ctr d-flex align-items-center"><span>13</span></div>
                                                            <div className="dash-new-box-btm"><p className="mb-0">Push Notifications Sent</p></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className='col-lg-12 pe-0 mb-3'>
                                                    <div className='white-box h-100'>
                                                        <div className="dash-new-box-main">
                                                            <div className="dash-new-box-hdr mb-3">
                                                                <mark className="bg-transparent p-0">
                                                                    <svg width="51" height="50" viewBox="0 0 51 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <circle cx="25.5" cy="25" r="25" fill="#00BBFF"></circle>
                                                                        <path
                                                                            d="M25.5 35C24.3954 35 23.5 34.1046 23.5 33H27.5C27.5 34.1046 26.6046 35 25.5 35ZM33.5 32H17.5V30L19.5 29V23.5C19.5 20.038 20.921 17.793 23.5 17.18V15H27.5V17.18C30.079 17.792 31.5 20.036 31.5 23.5V29L33.5 30V32ZM25.5 18.75C24.2797 18.6712 23.1028 19.2173 22.375 20.2C21.7525 21.1846 21.4471 22.3364 21.5 23.5V30H29.5V23.5C29.5528 22.3364 29.2474 21.1846 28.625 20.2C27.8972 19.2173 26.7203 18.6712 25.5 18.75Z"
                                                                            fill="white"
                                                                        ></path>
                                                                    </svg>
                                                                </mark>
                                                            </div>
                                                            <div className="dash-new-box-ctr d-flex align-items-center"><span>0.00%</span></div>
                                                            <div className="dash-new-box-btm"><p className="mb-0">View Rate</p></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className='col-lg-12 pe-0 mb-3 mb-md-0'>
                                                    <div className='white-box h-100'>
                                                        <div className="dash-new-box-main">
                                                            <div className="dash-new-box-hdr mb-3">
                                                                <mark className="bg-transparent p-0">
                                                                    <svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <circle cx="25" cy="25" r="25" fill="#FF9D4E"></circle>
                                                                        <path
                                                                            d="M25 31.6966C23.3599 31.7167 21.7367 31.3683 20.254 30.678C19.1047 30.1261 18.0727 29.364 17.213 28.4322C16.3024 27.4689 15.5855 26.3445 15.1 25.1187L15 24.8077L15.105 24.4967C15.5908 23.2719 16.3062 22.1478 17.214 21.1831C18.0733 20.2515 19.105 19.4893 20.254 18.9374C21.7367 18.2471 23.3599 17.8987 25 17.9188C26.6401 17.8988 28.2633 18.2471 29.746 18.9374C30.8953 19.4892 31.9274 20.2514 32.787 21.1831C33.6993 22.1452 34.4165 23.2698 34.9 24.4967L35 24.8077L34.895 25.1187C33.3262 29.1376 29.3742 31.7648 25 31.6966ZM25 19.887C21.5959 19.7821 18.4714 21.7324 17.117 24.8077C18.4712 27.8832 21.5958 29.8336 25 29.7283C28.4041 29.833 31.5284 27.8828 32.883 24.8077C31.5304 21.7309 28.4047 19.7799 25 19.887ZM25 27.7601C23.5573 27.7695 22.3094 26.7733 22.021 25.3822C21.7326 23.991 22.4843 22.5934 23.8154 22.0459C25.1465 21.4984 26.6852 21.9538 27.4885 23.1332C28.2919 24.3125 28.1354 25.8864 27.115 26.8901C26.5563 27.4464 25.7948 27.7596 25 27.7601Z"
                                                                            fill="white"
                                                                        ></path>
                                                                    </svg>
                                                                </mark>
                                                            </div>
                                                            <div className="dash-new-box-ctr d-flex align-items-center"><span>0</span></div>
                                                            <div className="dash-new-box-btm"><p className="mb-0">Views</p></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className='col-xxl-7 col-lg-6 pe-0 mt-lg-0 mt-md-2 pt-lg-0 pt-md-1'>
                                    <div className='white-box h-100 p-0'>
                                        <div className='dash-hdr-body-box-hdr d-flex align-items-center p-3 fw-bold'>
                                            <span className="d-block">Notification Analytics</span>
                                        </div>
                                        <div className='dash-hdr-body-box-body'>
                                            <div className='apexcharts-comn-class apexcharts-tiks-last'>
                                                <Chart options={chart7} series={chart7.series} height={300} type="line" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </Adminlayout>
        );
    }
}

export default ViewCampaignAnalytics;
