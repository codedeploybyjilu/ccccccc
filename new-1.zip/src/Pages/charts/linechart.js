import React, { Component } from "react";

import Chart from "react-apexcharts";
class LineChart extends Component {
  state = {
    options: {
      chart: {
        id: "chart-1",
        fontFamily: "poppins, sans-serif",
        foreColor: "#000000",
        toolbar: {
          show: false,
        },

        dropShadow: {
          enabled: true,
          enabledOnSeries: undefined,
          top: 0,
          left: 0,
          blur: 4,
          color: "rgba(38, 207, 255, 0.26)",
          opacity: 0.35,
        },
      },

      xaxis: {
        categories: [
          "Jan",
          "Feb",
          "Mar",
          "Apr",
          "May",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Oct",
          "Nov",
          "Dec",
        ],
      },
      colors: ["#A81A1C"],
      stroke: {
        show: true,
        curve: "smooth",
        width: 2,
        dashArray: 0,
      },
      legend: {
        show: false,
      },
    },
    markers: {
      size: 5,
      colors: "rgba(168, 26, 28, 0.1)",
      strokeColors: "rgba(168, 26, 28, 0.1)",
      strokeWidth: 3,
      strokeOpacity: 1,
      strokeDashArray: 0,
      fillOpacity: 1,
      discrete: [],
      shape: "circle",
      radius: 2,
      offsetX: 0,
      offsetY: 0,
      showNullDataPoints: true,
      hover: {
        size: undefined,
        sizeOffset: 3,
      },
    },
    series: [
      {
        name: "series-1",
        data: [10, 90, 50, 90, 100, 10, 35, 20, 55, 5, 20, 60, 65],
      },
    ],
  };
  render() {
    return (
      <div>
        <Chart
          options={this.state.options}
          series={this.state.series}
          type="line"
          height={300}
        />
      </div>
    );
  }
}

export default LineChart;
