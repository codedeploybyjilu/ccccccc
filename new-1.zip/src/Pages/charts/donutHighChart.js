/* eslint-disable */

import React, { Component } from 'react'

export default class DonutHighChart extends Component {

    componentDidMount() {
        // Build the chart
        Highcharts.chart('donutHigh', {
            chart: {
                style: {
                    fontFamily: 'Poppins, sans-serif'
                },
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },
            colors: ['#A81A1C', '#FFB946', '#0062FF'],
            title: {
                text: ''
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            accessibility: {
                point: {
                    valueSuffix: '%'
                }
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: false
                    },
                    showInLegend: true
                }
            },
            series: [{
                name: 'Status',
                innerSize: '70%',
                colorByPoint: true,
                data: [{
                    name: 'Pending',
                    y: 60,
                    sliced: true,
                    selected: true
                },
                {
                    name: 'Deliverd',
                    y: 10.85
                },
                {
                    name: 'Cancelled',
                    y: 4.67
                }
                ]
            }]
        });
    }

    render() {
        return (
            <div>
                <div id="donutHigh"></div>
            </div>
        )
    }
}
