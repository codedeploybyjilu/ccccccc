import React, { Component } from 'react';
import LanguageContext from "../../contexts/languageContext";
import Chart from "react-apexcharts";

class CustomersChart extends Component {
    static contextType = LanguageContext;

    state = {
        series: [25, 30],
        options: {
            chart: {
                fontFamily: "poppins, sans-serif",
                foreColor: "#000000",
                fontSize: 15,
                toolbar: {
                    show: false,
                },
                zoom: {
                    enabled: false,
                }
            },
            plotOptions: {
                dataLabels: {
                    name: {
                        show: false,
                    },
                    value: {
                        show: false,
                    }
                }
            },
            
            labels: ['NEW CUSTOMERS', 'RETURNING CUSTOMERS'],
            colors: ["#A81A1C", "#696969"]
        },
    };

    render() {
        return (
            <div>
                <Chart
                    options={this.state.options}
                    series={this.state.series}
                    type='radialBar'
                    height={320}
                />
            </div>
        );
    }
}

export default CustomersChart;