import React, { Component } from "react";
import Chart from "react-apexcharts";
import LanguageContext from "../../contexts/languageContext";
import { DashboardArabic, DashboardEnglish } from "../../const";

class DonutChart extends Component {
  static contextType = LanguageContext;

  state = {
    series: [80, 10, 10],

    options: {
      chart: {
        type: "donut",
        fontFamily: "poppins, sans-serif",
        foreColor: "#000000",
        fontSize: 15,
      },
      labels: [
        this.context.language === "english"
          ? DashboardEnglish.Delivered
          : DashboardArabic.Delivered,
        this.context.language === "english"
          ? DashboardEnglish.Pending
          : DashboardArabic.Pending,
        this.context.language === "english"
          ? DashboardEnglish.Cancelled
          : DashboardArabic.Cancelled,
      ],
      colors: ["#A81A1C", "#0062FF", "#FFB946"],
      legend: {
        show: true,
        position: "bottom",
      },
      dataLabels: {
        enabled: false,
        fontSize: "18px",
      },
      tooltip: {
        enabled: false,
      },
      fill: {
        colors: ["#A81A1C", "#0062FF", "#FFB946"],
      },
      states: {
        hover: {
          filter: {
            type: "lighten",
            value: 0.9,
          },
        },
        active: {
          filter: {
            type: "none",
            value: 0,
          },
        },
      },
      stroke: {
        width: 0,
      },
      responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: 300,
            },
            legend: {
              position: "bottom",
            },
          },
        },
      ],
    },
  };

  render() {
    return (
      <div>
        <Chart
          options={this.state.options}
          series={this.state.series}
          type="donut"
          height={320}
        />
      </div>
    );
  }
}

export default DonutChart;
