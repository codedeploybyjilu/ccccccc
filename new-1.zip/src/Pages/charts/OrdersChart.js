import React, { Component } from 'react';
import LanguageContext from "../../contexts/languageContext";
import Chart from "react-apexcharts";

class OrdersChart extends Component {
    static contextType = LanguageContext;

    state = {
        series: [44, 55, 13],
        options: {
            chart: {
                fontFamily: "poppins, sans-serif",
                foreColor: "#000000",
                fontSize: 15,
                toolbar: {
                    show: false,
                },
                zoom: {
                    enabled: false,
                }
            },
            labels: ['Pending', 'Delivered', 'Cancelled'],
            legend: {
                show: true,
                position: "bottom",
            },
            plotOptions: {
                bar: {
                    columnWidth: '95%',
                    distributed: true,
                    borderRadius: 10,
                    dataLabels: {
                        orientation: 'vertical',
                        position: 'bottom' // bottom/center/top
                    }
                }
            },
            dataLabels: {
                enabled: true,
                textAnchor: 'middle',
                distributed: true,
                offsetY: 15,
            },
            tooltip: {
                enabled: false,
            },
            colors: ["#FAA51A", "#A81A1C", "#B6B6BC"],
        },
    };

    render() {
        return (
            <div>
                <Chart
                    options={this.state.options}
                    series={this.state.series}
                    type='donut'
                    height={320}
                />
            </div>
        );
    }
}

export default OrdersChart;