import React, { Component } from 'react';
import LanguageContext from "../../contexts/languageContext";
import Chart from "react-apexcharts";

class PaymentsChart extends Component {
    static contextType = LanguageContext;

    state = {
        series: [25],
        options: {
            chart: {
                fontFamily: "poppins, sans-serif",
                foreColor: "#000000",
                fontSize: 15,
                toolbar: {
                    show: false,
                },
                zoom: {
                    enabled: false,
                }
            },
            plotOptions: {
                radialBar: {
                    hollow: {
                        size: '50%',
                    }
                },
            },
            labels: ['Total Amount'],
            colors: ["#A81A1C"]
        },
    };

    render() {
        return (
            <div>
                <Chart
                    options={this.state.options}
                    series={this.state.series}
                    type='radialBar'
                    height={320}
                />
            </div>
        );
    }
}

export default PaymentsChart;