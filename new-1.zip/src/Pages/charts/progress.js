import React, { Component } from 'react';
import Chart from 'react-apexcharts'


class ProgressChart extends Component {

    state = {
        series: [85.75],
        colors: ["#A81A1C"],
        options: {
            chart: {
                type: 'radialBar',
                fontFamily: 'poppins, sans-serif',
                foreColor: '#000000',
                offsetY: 50,
                sparkline: {
                    enabled: true
                },
            },
            colors: ["#A81A1C"],
            plotOptions: {
                radialBar: {
                    startAngle: -90,
                    endAngle: 90,
                    strokeWidth: '10%',
                    track: {
                        background: 'rgba(168, 26, 28, 0.1)',
                        startAngle: -90,
                        endAngle: 90,
                        strokeWidth: '10%',

                    },
                    hollow: {
                        margin: 0,
                        size: '80%',
                        image: '../../images/happy.png',
                        imageWidth: 64,
                        imageHeight: 64,
                        imageClipped: true,
                    },
                    dataLabels: {
                        name: {
                            show: false,
                        },
                        value: {
                            fontSize: "25px",
                            show: true,
                            fontWeight: 600,
                        }
                    }
                }
            },
            fill: {
                type: "linear",
                gradient: {
                    shade: "",
                    type: "horizontal",
                    gradientToColors: ["#A81A1C"],
                    stops: [0, 100]
                }
            },
            stroke: {
                lineCap: "round"
            },
            labels: ["Progress"],
            responsive: [
                {
                    breakpoint: 1545,
                    options: {
                        chart: {
                            offsetY: 10,
                        },
                    },
                    plotOptions: {
                        hollow: {
                            // margin: ,
                            size: '10%',
                            imageWidth: 0,
                            imageHeight: 0,
                        },
                    }
                }
            ]
        },
    }
    render() {
        return (
            <div>
                <Chart options={this.state.options} series={this.state.series} type="radialBar" height={300} />
            </div>
        );
    }
}

export default ProgressChart;