/* eslint-disable */

import React, { Component } from 'react'

export default class LineHighChart extends Component {

    componentDidMount() {
        Highcharts.chart('lineHigh', {
            chart: {
                type: 'line',
                style: {
                    fontFamily: 'Poppins, sans-serif'
                }
            },
            colors: ['#A81A1C'],

            title: {
                text: ''
            },

            xAxis: {
                categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
            },

            yAxis: {
                type: '',
                accessibility: {
                    rangeDescription: ''
                }
            },

            tooltip: {
                headerFormat: '<b>{series.name}</b><br />',
                pointFormat: 'x = {point.x}, y = {point.y}'
            },

            series: [{
                data: [29.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4]
            }],
            contextButton: {
                enabled: false,
            }

        });
    }

    render() {
        return (
            <div>
                <div id="lineHigh"></div>
            </div>
        )
    }
}
