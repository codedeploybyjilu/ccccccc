import React, { Component } from "react";
import Chart from "react-apexcharts";
import LanguageContext from "../../contexts/languageContext";

class ColumnChart extends Component {
    static contextType = LanguageContext;

    state = {
        series: [{
            data: [{
                x: 'Visitors',
                y: 800
            },
            {
                x: 'Added to cart',
                y: 700
            },
            {
                x: 'Checkout',
                y: 608
            },
            {
                x: 'Address add',
                y: 570
            },
            {
                x: 'Sales',
                y: 440
            }]
        }],


        options: {
            chart: {
                fontFamily: "poppins, sans-serif",
                foreColor: "#000000",
                fontSize: 15,
                toolbar: {
                    show: false,
                },
                zoom: {
                    enabled: false,
                }
            },
            grid: {
                show: false,
            },
            // labels: [
            //     this.context.language === "english"
            //         ? DashboardEnglish.Delivered
            //         : DashboardArabic.Delivered,
            //     this.context.language === "english"
            //         ? DashboardEnglish.Pending
            //         : DashboardArabic.Pending,
            //     this.context.language === "english"
            //         ? DashboardEnglish.Cancelled
            //         : DashboardArabic.Cancelled,
            // ],
            // colors: ["#A81A1C", "#0062FF", "#FFB946"],
            legend: {
                show: false,
                position: "bottom",
            },

            plotOptions: {
                bar: {
                    columnWidth: '95%',
                    distributed: true,
                    borderRadius: 10,
                    dataLabels: {
                        orientation: 'vertical',
                        position: 'bottom' // bottom/center/top
                    }
                }
            },
            xaxis: {
                labels: {
                    show: false,

                }
            },
            yaxis: {
                labels: {
                    show: false,
                }
            },
            dataLabels: {
                enabled: true,
                formatter: function (val, opt) {
                    return opt.w.globals.labels[opt.dataPointIndex] + ":  " + val;
                },
                textAnchor: 'middle',
                distributed: true,
                offsetY: 15,

            },
            tooltip: {
                enabled: false,
            },
            fill: {
                colors: ["#323232", "#502C2D", "#6D2627", "#8B2022", "#A81A1C"],
            },

        },
    };

    render() {
        return (
            <div>
                <Chart
                    options={this.state.options}
                    series={this.state.series}
                    type='bar'
                    height={320}
                />
            </div>
        );
    }
}

export default ColumnChart;
