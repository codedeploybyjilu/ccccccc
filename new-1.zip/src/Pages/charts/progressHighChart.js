/* eslint-disable */

import React, { Component } from 'react'

export default class ProgressHighChart extends Component {

    componentDidMount() {
        var gaugeOptions = {
            chart: {
                type: 'solidgauge',
                style: {
                    fontFamily: 'Poppins, sans-serif',
                    fontSize: '15px',
                },
            },

            title: null,

            pane: {
                center: ['50%', '60%'],
                size: '100%',
                startAngle: -90,
                endAngle: 90,
                background: {
                    backgroundColor:
                        Highcharts.defaultOptions.legend.backgroundColor || '#EEE',
                    innerRadius: '60%',
                    outerRadius: '100%',
                    shape: 'arc'
                }
            },

            exporting: {
                enabled: false
            },

            tooltip: {
                enabled: false
            },

            // the value axis
            yAxis: {
                stops: [
                    [0.1, '#A81A1C'], // green
                    [0.5, '#A81A1C'], // yellow
                    [0.9, '#A81A1C'] // red
                ],
                lineWidth: 0,
                tickWidth: 0,
                minorTickInterval: null,
                tickAmount: 2,
                title: {
                    y: -20
                },
                labels: {
                    y: 16
                }
            },

            plotOptions: {
                solidgauge: {
                    dataLabels: {
                        y: 5,
                        borderWidth: 0,
                        useHTML: true
                    }
                }
            }
        };

        // The speed gauge
        var chartSpeed = Highcharts.chart('container-speed', Highcharts.merge(gaugeOptions, {
            yAxis: {
                min: 0,
                max: 100,
                title: {
                    text: 'Speed'
                }
            },

            credits: {
                enabled: false
            },

            series: [{
                name: 'Speed',
                data: [70],

                tooltip: {
                    valueSuffix: ' km/h'
                }
            }]

        }));
    }

    render() {
        return (
            <div>
                <div id="container-speed"></div>
            </div>
        )
    }
}
