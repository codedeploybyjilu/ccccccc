import React, { Component } from "react";

const Context = React.createContext("english");

export class LanguageStore extends Component {

    state = { language: "english" };

    componentDidMount() {
        // console.log(localStorage.getItem('currentLanguage'));
        if (localStorage.getItem('currentLanguage')) {
            this.setState({ language: localStorage.getItem('currentLanguage') }, () => { this.changeLayoutForRTL(); })
        }
    }


    onLanguageChange = language => {
        this.setState({ language }, () => { this.changeLayoutForRTL(); });
    };

    changeLayoutForRTL = () => {
        // console.log((this.state.language));
        localStorage.setItem('currentLanguage', this.state.language);
        if (this.state.language === 'english') {
            document.getElementById('body-id-admin').style.direction = 'ltr';
            document.getElementById('body-id-admin').classList.remove("rtl");
            document.getElementById('body-id-admin').classList.add("ltr");
        } else if (this.state.language === 'arabic') {
            document.getElementById('body-id-admin').style.direction = 'rtl'
            document.getElementById('body-id-admin').classList.remove("ltr");
            document.getElementById('body-id-admin').classList.add("rtl");
        }

    }

    render() {
        return (
            <Context.Provider
                value={{ ...this.state, onLanguageChange: this.onLanguageChange }}
            >
                {this.props.children}
            </Context.Provider>
        );
    }
}

export default Context;
