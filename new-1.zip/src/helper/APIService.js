const axios = require("axios");

export function GetApi(path) {
  let config = {
    headers: {
      "Content-Type": "application/json",
      Authorization: "bearer " + localStorage.getItem("_a_token"),
    },
  };
  const GetApiData = axios
    .get(path, config)
    .then((response) => {
      return response;
    })
    .catch((err) => {
      console.log(err.response);
      return err.response;
    });
  return GetApiData;
}

export function PostApi(path, data) {
  let config = {
    headers: {
      "Content-Type": "application/json",
      Authorization: "bearer " + localStorage.getItem("_a_token"),
    },
  };
  const PostApiData = axios
    .post(path, data, config)
    .then((response) => {
      return response;
    })
    .catch((err) => {
      console.log(err.response);
      return err.response;
    });
  return PostApiData;
}

