import React from "react";
import { Route, Redirect } from "react-router-dom";
const ProtectedRoute = ({ children, ...rest }) => {
    let Admin
    if (localStorage.getItem("_a_token")) {
        let token = localStorage.getItem("_a_token")
        try {
            if (token.split('.').length > 1) {
                var base64Url = token.split('.')[1];
                var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
                var jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function (c) {
                    return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
                }).join(''));
                Admin = JSON.parse(jsonPayload);
            } else {
                Admin = undefined
            }
        }
        catch (err) {
            // console.log(err, "ttty");
        }
    }
    return (
        <Route
            {...rest}
            render={({ location }) =>
                Admin &&
                    Admin.data[0].role === 2 ? (
                    children
                ) : (
                    <>
                        {console.log(location)};
                        <Redirect
                            to={{
                                pathname: "/login",
                                state: { from: location }
                            }}
                        />
                    </>
                )
            }
        />
    );

};
export default ProtectedRoute;
