import React, { Component } from 'react';
import Routes from './Routes';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import '../node_modules/toastr/build/toastr.css'
import './style.css'
import { LanguageStore } from './contexts/languageContext';


class App extends Component {
  render() {
    return (
      <React.Fragment>
        <LanguageStore>
          <Routes />
        </LanguageStore>
      </React.Fragment>
    );
  }
}

export default App;