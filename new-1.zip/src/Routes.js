import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { createBrowserHistory } from 'history';
import Login from './Pages/Common/login';
import ForgotPassword from './Pages/Common/forgot-password';
import Dashboard from './Pages/AdminPages/Dashboard';
import Admin from './Pages/AdminPages/Admin';
import Users from './Pages/AdminPages/Users';
import Orders from './Pages/AdminPages/Orders';
import AdminDetails from './Pages/AdminPages/Admin_Details';
import UserDetails from './Pages/AdminPages/User_Details';
import AddAdmin from './Pages/AdminPages/Add_Admin';
import Errorlog from './Pages/AdminPages/Errorlog';
import Errorlogdetails from './Pages/AdminPages/Errorlogdetails';
import DeviceInformation from './Pages/AdminPages/DeviceInformation';
import HelpandSupport from './Pages/AdminPages/HelpandSupport';
import Profile from './Pages/AdminPages/Profile';
import Master from './Pages/AdminPages/Master';
import Location from './Pages/AdminPages/Location';
import Products from './Pages/AdminPages/Products';
import Notification from './Pages/AdminPages/Notification';
import Maillisting from './Pages/AdminPages/Maillisting';
import Reports from './Pages/AdminPages/Reports';
import Addoffer from './Pages/AdminPages/Addoffer';
import Orderdetails from './Pages/AdminPages/Orderdetails';
import AddProduct from './Pages/AdminPages/AddProduct';
import ReturnProduct from './Pages/AdminPages/ReturnProduct';
import AddNotification from './Pages/AdminPages/AddNotification';
import Logs from './Pages/AdminPages/Logs';
import Inventory from './Pages/AdminPages/Inventory';
import Productcategory from './Pages/AdminPages/Productcategory';
import Productdetails from './Pages/AdminPages/Productdetails';
import ProtectedRoute from './helper/protectedRoute';
import Draft from './Pages/AdminPages/Draft';
import EditOffer from './Pages/AdminPages/EditOffer';
import Editproduct from './Pages/AdminPages/EditProduct';
import Team from './Pages/AdminPages/Team';
import Sizeguidelines from './Pages/AdminPages/sizeguidelines';
import AddSizeguidelines from './Pages/AdminPages/Add_sizeguideline';
import EditSizeGuideline from './Pages/AdminPages/editSizeGuideline';
import Orderactivitylog from './Pages/AdminPages/Order-activity-log';
import MUITable from './Components/MUITable';
import Marketing from './Pages/AdminPages/Marketing';
import AddCoupon from './Pages/AdminPages/AddCoupon';
import EditCoupon from './Pages/AdminPages/EditCoupon';
import Categories from './Pages/AdminPages/Categories';
import AbandonedCart from './Pages/AdminPages/AbandonedCart';
import AddNewCity from './Pages/AdminPages/AddNewCity';
import Settings from './Pages/AdminPages/Settings';
import AddDiscount from './Pages/AdminPages/AddDiscount';
import AddBundleDiscount from './Pages/AdminPages/AddBundleDiscount';
import Invoice from './Pages/AdminPages/Invoice';
import EditNewCity from './Pages/AdminPages/EditNewCity';
import OrderDetailsPrint from './Pages/AdminPages/OrderDetailsPrint';
import AudienceSegment from './Pages/AdminPages/AudienceSegment';
import CreateUserSegment from './Pages/AdminPages/CreateUserSegment';
import AudianceSegmentDetails from './Pages/AdminPages/AudianceSegmentDetails';
import Campaign from './Pages/AdminPages/Campaign';
import ViewCampaignAnalytics from './Pages/AdminPages/ViewCampaignAnalytics';
import AddCampaign from './Pages/AdminPages/AddCampaign';
import Automations from './Pages/AdminPages/Automations';
import CreateAutomation from './Pages/AdminPages/CreateAutomation';
import FrameSet from './Pages/AdminPages/FrameSet';
import ReturnOrders from './Pages/AdminPages/ReturnOrders';
import ReturnOrderDetails from './Pages/AdminPages/returnOrderDetails';


class Routes extends Component {
    render() {
        return (
            <React.Fragment>
                <Router basename={process.env.PUBLIC_URL + '/'}>
                    <Switch>
                        <Route exact path='/login' component={Login} />
                        <Route exact path='/table' component={MUITable} />
                        <Route exact path='/forgotpassword' component={ForgotPassword} />
                        <ProtectedRoute exact path="/"> <Dashboard /></ProtectedRoute>
                        <ProtectedRoute path="/dashboard"> <Dashboard /></ProtectedRoute>
                        <ProtectedRoute path="/admin"> <Admin /></ProtectedRoute>
                        <ProtectedRoute path="/users"> <Users /></ProtectedRoute>
                        <ProtectedRoute path="/orders"> <Orders /></ProtectedRoute>
                        <ProtectedRoute path="/abandoned-cart"> <AbandonedCart /></ProtectedRoute>
                        <ProtectedRoute path="/return-requests"> <ReturnOrders /></ProtectedRoute>
                        <ProtectedRoute path="/return-order-details"> <ReturnOrderDetails /></ProtectedRoute>
                        <ProtectedRoute path="/user-details/:userId"> <UserDetails /></ProtectedRoute>
                        <ProtectedRoute path="/admin-details/:adminId"> <AdminDetails /></ProtectedRoute>
                        <ProtectedRoute path="/add-admin"> <AddAdmin /></ProtectedRoute>
                        <ProtectedRoute path="/error-log"> <Errorlog /></ProtectedRoute>
                        <ProtectedRoute path="/errorlog-details"> <Errorlogdetails /></ProtectedRoute>
                        <ProtectedRoute path="/device-information"> <DeviceInformation /></ProtectedRoute>
                        <ProtectedRoute path="/helpandsupport"> <HelpandSupport /></ProtectedRoute>
                        <ProtectedRoute path="/profile"> <Profile /></ProtectedRoute>
                        <ProtectedRoute path="/master"> <Master /></ProtectedRoute>
                        <ProtectedRoute path="/marketing"> <Marketing /></ProtectedRoute>
                        <ProtectedRoute path="/add-coupon"> <AddCoupon /></ProtectedRoute>
                        <ProtectedRoute path="/edit-coupon/:id?"> <EditCoupon /></ProtectedRoute>
                        <ProtectedRoute path="/location"> <Location /></ProtectedRoute>
                        <ProtectedRoute path="/products"> <Products /></ProtectedRoute>
                        <ProtectedRoute path="/draft"> <Draft /></ProtectedRoute>
                        <ProtectedRoute path="/frame-set"> <FrameSet /></ProtectedRoute>
                        <ProtectedRoute path="/notification"> <Notification /></ProtectedRoute>
                        <ProtectedRoute path="/mailing-list"> <Maillisting /></ProtectedRoute>
                        <ProtectedRoute path="/reports"> <Reports /></ProtectedRoute>
                        <ProtectedRoute path="/settings"> <Settings /></ProtectedRoute>
                        <ProtectedRoute path="/team"> <Team /></ProtectedRoute>
                        <ProtectedRoute path="/add-offer"> <Addoffer /></ProtectedRoute>
                        <ProtectedRoute path="/add-discount"> <AddDiscount /></ProtectedRoute>
                        <ProtectedRoute path="/order-details/:id?"> <Orderdetails /></ProtectedRoute>
                        <ProtectedRoute path="/order-details-print/:id"> <OrderDetailsPrint /></ProtectedRoute>
                        <ProtectedRoute path="/add-product"> <AddProduct /></ProtectedRoute>
                        <ProtectedRoute path="/return-product"> <ReturnProduct /></ProtectedRoute>
                        <ProtectedRoute path="/add-notification"> <AddNotification /></ProtectedRoute>
                        <ProtectedRoute path="/logs"> <Logs /></ProtectedRoute>
                        <ProtectedRoute path="/inventory"> <Inventory /></ProtectedRoute>
                        <ProtectedRoute path="/product-details/:id?"> <Productdetails /></ProtectedRoute>
                        <ProtectedRoute path="/edit-offer/:id?"> <EditOffer /></ProtectedRoute>
                        <ProtectedRoute path="/productcategory"> <Productcategory /></ProtectedRoute>
                        <ProtectedRoute path="/sizeguideline"> <Sizeguidelines /></ProtectedRoute>
                        <ProtectedRoute path="/addsizeguideline"> <AddSizeguidelines /></ProtectedRoute>
                        <ProtectedRoute path="/addsizeguideline"> <AddSizeguidelines /></ProtectedRoute>
                        <ProtectedRoute path="/orderactivitylog"> <Orderactivitylog /></ProtectedRoute>
                        <ProtectedRoute path="/editsizeguideline/:id"> <EditSizeGuideline /></ProtectedRoute>
                        <ProtectedRoute path="/edit-product/:id"> <Editproduct /></ProtectedRoute>
                        <ProtectedRoute path="/categories"> <Categories /></ProtectedRoute>
                        <ProtectedRoute path="/addnewcity"> <AddNewCity /></ProtectedRoute>
                        <ProtectedRoute path="/editnewcity/:id"> <EditNewCity /></ProtectedRoute>
                        <ProtectedRoute path="/add-bundle-discount"> <AddBundleDiscount /></ProtectedRoute>
                        <ProtectedRoute path="/invoice/:id"> <Invoice /></ProtectedRoute>
                        <ProtectedRoute path="/audience-segment"> <AudienceSegment /></ProtectedRoute>
                        <ProtectedRoute path="/create-user-segment"> <CreateUserSegment /></ProtectedRoute>
                        <ProtectedRoute path="/audience-segment-details"> <AudianceSegmentDetails /></ProtectedRoute>
                        <ProtectedRoute path="/campaign"> <Campaign /></ProtectedRoute>
                        <ProtectedRoute path="/view-campaign-analytics"> <ViewCampaignAnalytics /></ProtectedRoute>
                        <ProtectedRoute path="/add-campaign"> <AddCampaign /></ProtectedRoute>
                        <ProtectedRoute path="/automations"> <Automations /></ProtectedRoute>
                        <ProtectedRoute path="/create-automation"> <CreateAutomation /></ProtectedRoute>
                    </Switch>
                </Router>
            </React.Fragment>
        );
    }
}

export const history = createBrowserHistory({
    basename: process.env.PUBLIC_URL
});

export default Routes;
