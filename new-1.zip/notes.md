NOTES:

Price calculations:

+ Order total
+ Shipping charges
- wallet
- Discount (promocode etc.)

- Refund




Grand total

[initial state]
    order total - wallet - discount + shipping


[after refund]
    order total - wallet - discount + shipping - refund


[after cancellation]
    order total - wallet - discount + shipping - refund






Task delivery responsibility
Delay reason

Requirements if any to Ranjeet







------------------------------------

create pickup
    redbox - check status code of delivered

update shipment
    tracking no field and API integration

redbox reprint label check


label - from and to address

Discuss - shipment status to be checked from webhook for Redbox

confirm button when search

filter store pickup when search

select to be disabled in shipment company

shipping settings



--------------------------------

create-refund - should it be called only for tabby tamara or for all
how refund was handled previously









{
    "success": true,
    "shipment_id": "663e0504007afa1921b47497",
    "tracking_number": "781995328819",
    "shipping_label_url": "https://stage.redboxsa.com/download/shipping-label/663e0504007afa1921b47497.pdf"
}

